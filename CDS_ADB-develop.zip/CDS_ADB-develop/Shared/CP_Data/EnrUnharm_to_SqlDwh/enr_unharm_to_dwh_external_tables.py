# Databricks notebook source
# MAGIC %run "/Shared/CP_Data/Config/config"

# COMMAND ----------

# MAGIC %run "/Shared/CP_Data/Shared_script/main"

# COMMAND ----------

dbutils.widgets.text("source_id", "", "Source ID");
dbutils.widgets.text("project_id", "", "Project ID");
dbutils.widgets.text("dataset", "", "Dataset");
dbutils.widgets.text("enr_unharm_file_path", "", "ENR UNHARM File Path");
dbutils.widgets.text("enr_unharm_file_name", "", "ENR UNHARM File Name");
dbutils.widgets.text('adls_mount_base', '/mnt/ADLS/', 'ADLS Mount Base');
dbutils.widgets.text('source_type', '', 'Source Type');
dbutils.widgets.text('external_table_schema', '', 'External Table Schema');
dbutils.widgets.text('external_table_name', '', 'External Table Name');
dbutils.widgets.text('external_table_data_source', '', 'External Table Data Source');
dbutils.widgets.text('external_table_file_format', '', 'External Table File Format');
dbutils.widgets.text('scd_type', '', 'SCD Type');
dbutils.widgets.text('alds_enriched_unharmonised_file_format', '', 'Enriched Unharmonised Format');
dbutils.widgets.text('enable_databricks_delta', '', 'Databricks Delta Enabled?');

# COMMAND ----------

source_id = dbutils.widgets.get("source_id");
project_id = dbutils.widgets.get("project_id");
dataset = dbutils.widgets.get("dataset");
enr_unharm_file_path = dbutils.widgets.get("enr_unharm_file_path");
enr_unharm_file_name = dbutils.widgets.get("enr_unharm_file_name");
adls_mount_base = dbutils.widgets.get("adls_mount_base");
source_type = dbutils.widgets.get("source_type");
external_table_schema = dbutils.widgets.get("external_table_schema");
external_table_name = dbutils.widgets.get("external_table_name");
external_table_data_source = dbutils.widgets.get("external_table_data_source");
external_table_file_format = dbutils.widgets.get("external_table_file_format");
scd_type = dbutils.widgets.get('scd_type');
alds_enriched_unharmonised_file_format = dbutils.widgets.get('alds_enriched_unharmonised_file_format');
enable_databricks_delta = dbutils.widgets.get('enable_databricks_delta');

# COMMAND ----------

# DBTITLE 1,Define notebook variables
target_adls_layer = 'asdwh';
enr_unharm_file = '';
external_table_ddl = '';

external_table_data_source = dwhExternalTableDataSource if external_table_data_source.strip() == '' else external_table_data_source.strip();
external_table_file_format = dwhExternalTableFileFormat if external_table_file_format.strip() == '' else external_table_file_format.strip();

if source_type.lower() == 'sharepoint':
    enr_unharm_file_name = enr_unharm_file_name.split('_')
    del enr_unharm_file_name[-1]
    enr_unharm_file_name = '_'.join(enr_unharm_file_name).replace('.xlsx', '.parquet');

if '.parquet' not in enr_unharm_file_name:
    enr_unharm_file_name = enr_unharm_file_name + '.parquet'

scd_type = scd_type.lower() if len(scd_type) > 0 else '';

if len(enr_unharm_file_path) > 0 and len(enr_unharm_file_path) > 0:
    if enr_unharm_file_path[0] == '/': # Remove first character of file path if it is '/'
        enr_unharm_file_path = enr_unharm_file_path[1:]

# Change this to dataset
#if len(enr_unharm_file_name) == 0:
#    enr_unharm_file_name_list = enr_unharm_file_name.split('_')
#    del enr_unharm_file_name_list[-1]
#    enr_unharm_file_name = '_'.join(enr_unharm_file_name_list) + '.parquet'

# COMMAND ----------

# DBTITLE 1,Load column attributes from SQL DB
#config_dataset_columns_df = LoadDatasetColumnAttributes();
config_dataset_columns_df = LoadDatasetColumnAttributes(project_id, source_id, dataset);

# Remove any special characters from dataframe
config_dataset_columns_df = replaceSpecialCharactersInColumns(config_dataset_columns_df, columns_special_characters_to_replace)

display(config_dataset_columns_df)

# COMMAND ----------

if config_dataset_columns_df.count() == 0:
  
    dbutils.notebook.exit(json.dumps({'status': 'Failed', 'ExternalTableDDL': '', 'Message': 'There are no column attributes for this dataset.'}))
else:
  
    config_dataset_columns_df = config_dataset_columns_df.distinct()

# COMMAND ----------

if len(external_table_schema) == 0 or len(external_table_name) == 0:
  
    dbutils.notebook.exit(json.dumps({'status': 'Failed', 'ExternalTableDDL': '', 'Message': 'External table schema or name not defined.'}))

# COMMAND ----------

# DBTITLE 1,Convert Dataframe to Dictionary
config_dataset_columns_dict = ConvertDatasetColumnsDFtoDict(config_dataset_columns_df);
print(config_dataset_columns_dict)

# COMMAND ----------

# DBTITLE 1,Load data from ENR_UNHARM
try:

    # Check if DELTA file path variable is not empty and DELTA file exist in ADLS
    #if raw_df is not None and len(delta_file_path_full) > 0 and CheckPathExists(delta_file_path_full) == True:
    enr_unharm_df = None;
    enr_unharm_file = adls_mount_base + enr_unharm_file_path + enr_unharm_file_name
    
    if len(enr_unharm_file) > 0 and CheckPathExists(enr_unharm_file) == True:
      
        #enr_unharm_file = adls_mount_base + enr_unharm_file_path + enr_unharm_file_name
      
        # Load data from DELTA file into DELTA dataframe
        
        if scd_type == 'no_scd':
            
            if alds_enriched_unharmonised_file_format.lower() == 'parquet':
                enr_unharm_df = spark.read.format("parquet").load(enr_unharm_file)
        else:
          
            if enable_databricks_delta.lower() == 'y' or enable_databricks_delta.lower() == 'yes' or int(enable_databricks_delta) == 1:
                enr_unharm_df = spark.read.format("delta").load(enr_unharm_file)
        
        display(enr_unharm_df)
  
except Exception as e:
    print(str(e))
  
    dbutils.notebook.exit(json.dumps({'status': 'Failed', 'ExternalTableDDL': '', 'Message': databricksErrorPrefix + str(e)[0:7998]}))
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,Extract ENR_UNHARM dataset column names
if enr_unharm_df is not None:
  
    print(enr_unharm_file)
  
    enr_unharm_df.printSchema();
    
    enr_unharm_df_columns = enr_unharm_df.columns
    
    print(enr_unharm_df_columns)

# COMMAND ----------

print(config_dataset_columns_dict.keys())

# COMMAND ----------

# DBTITLE 1,Generate external table create query
# Map dataframe columns to column attributes


config_dataset_columns_dict = ConvertDatatypes(target_adls_layer, enr_unharm_df_columns, config_dataset_columns_dict)
#print(config_dataset_columns_dict)

# Force all keys in the dictionary to lower case
config_dataset_columns_dict = {dict_key.lower(): dict_value for dict_key, dict_value in config_dataset_columns_dict.items()}

# COMMAND ----------

print(len(enr_unharm_df_columns))
print(len(config_dataset_columns_dict))

# COMMAND ----------

print(config_dataset_columns_dict)

# COMMAND ----------

if len(config_dataset_columns_dict) > 0:
  
    externa_table_columns_list = [];
    
    row_count = 0;
    row_count2 = 0;
    
    #config_dataset_columns_dict = {dict_key.lower(): dict_value for dict_key, dict_value in config_dataset_columns_dict.items()}
    
    #for column in config_dataset_columns_dict:
    for column in enr_unharm_df_columns:
        
        row_count = row_count + 1;
        
        #if len(column) > 0 and column in config_dataset_columns_dict.keys() and 'asdwh_datatype' in config_dataset_columns_dict[column]:
        if len(column) > 0:
      
            column = replaceSpecialCharactersInString(column, columns_special_characters_to_replace)
            column = column.lower();
          
            if column in config_dataset_columns_dict.keys() and 'asdwh_datatype' in config_dataset_columns_dict[column]:
            #if column.lower() in config_dataset_columns_dict_lower_keys and 'asdwh_datatype' in config_dataset_columns_dict_lower_keys[column.lower()]:
              
                row_count2 = row_count2 + 1;
                
                null_value = ' NULL ';
                if 'source_nullable' in config_dataset_columns_dict[column] and config_dataset_columns_dict[column]['source_nullable'].lower() == 'n':
                    null_value = ' NOT NULL '                
                
                externa_table_columns_list.append("[{0}] {1} {2} \n\t".format(config_dataset_columns_dict[column]['standardised_column_name'], config_dataset_columns_dict[column]['asdwh_datatype'], null_value) );
    
    print(row_count);
    print(row_count2);
    
    if len(externa_table_columns_list) > 0:
      
        externa_table_columns_string = ','.join(externa_table_columns_list);
     
        external_table_ddl = '''IF OBJECT_ID('{0}.{1}') IS NOT NULL DROP EXTERNAL TABLE {0}.{1};
CREATE EXTERNAL TABLE {0}.{1}('''.format(external_table_schema.lower(), external_table_name.lower())
        
        external_table_ddl = external_table_ddl + ','.join(externa_table_columns_list)
        
        external_table_ddl = external_table_ddl + '''
)
WITH (    
    LOCATION='{2}'     
    , DATA_SOURCE={0}
    , FILE_FORMAT={1}
    , REJECT_TYPE = VALUE
    , REJECT_VALUE = 0
);'''.format(external_table_data_source, external_table_file_format, enr_unharm_file_path + enr_unharm_file_name)
            

# COMMAND ----------

dbutils.notebook.exit(json.dumps({'status': 'Succeeded', 'ExternalTableDDL': external_table_ddl.replace('\n', ' ').replace('\t', ' '), 'Message': 'External table query created successfully'}))
