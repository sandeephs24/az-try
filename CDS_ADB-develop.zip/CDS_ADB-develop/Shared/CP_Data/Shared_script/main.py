# Databricks notebook source
# DBTITLE 1,Import Packages and Libraries
import datetime
import json
import pyspark.sql.functions as sf
import pyodbc
from pyspark.sql.functions import lit, col, desc, expr, unix_timestamp, from_unixtime, to_timestamp, asc
from pyspark.sql.types import StringType, StructType, StructField, IntegerType, TimestampType, LongType, DoubleType
from pyspark.sql.window import Window

# COMMAND ----------

# DBTITLE 1,Define Default Variables
# Set current timestamp
tableTimeFormat = '%Y-%m-%d %H:%M:%S'
startTime = datetime.datetime.now().strftime(tableTimeFormat)

# Variables returned to ADF
successMessage = 'File processed successfully';
readCount = 0;
writeCount = 0;
databricksErrorPrefix = 'Databrick Notebook Error - ';

default_effective_end_date = '2999-12-31 00:00:00';
default_termination_date = '9999-12-31 00:00:00';
    
# Set SCD Column namesto be added to data frame
scd_column_valid_from = 'EFFECTIVE_START_DATE';
scd_column_valid_to = 'EFFECTIVE_END_DATE';
scd_column_active = 'IS_RECORD_ACTIVE';
    
# Set row number column to be used in UPSERT logic
row_number_column = "_row_number";

meta_created_dttm_column = 'META_CREATED_DTTM';

# Special characters to be replaced
columns_special_characters_to_replace = ['%', '(', ')', '?', '-']

# Metadata columns
meta_deleted_ind = 'DELETE_IND';
meta_quality_cd = 'META_QUALITY_CD';
meta_action_cd = 'META_ACTION_CD';
meta_created_dttm = 'META_CREATED_DTTM';
meta_creator_nm = 'META_CREATOR_NM';
meta_changed_dttm = 'META_CHANGED_DTTM';
meta_changed_by_nm = 'META_CHANGED_BY_NM';
meta_record_entry_dttm = 'RECORD_ENTRY_DTTM';
meta_checksum_id = 'META_CHECKSUM_ID';
meta_json_source_id = 'META_JSON_SOURCE_IDENTIFIER';
meta_duplicate_record_ind = 'META_DUPLICATE_RECORD_IND';
meta_lineage_key_hash = 'META_LINEAGE_KEY_HASH';
meta_lineage_row_hash = 'META_LINEAGE_ROW_HASH';
meta_version_type_key = 'VERSION_TYPE_KEY';
meta_version_effective_date = 'VERSION_EFFECTIVE_DATE';
meta_version_termination_date = 'VERSION_TERMINATION_DATE';
meta_active_indicator = 'ACTIVE_INDICATOR';
meta_user_key = 'USER_KEY';
meta_report_date = 'REPORT_DT';
meta_data_provider_key = 'DATA_PROVIDER_KEY';
meta_data_provide_service_key = 'DATA_PROVIDER_SERVICE_KEY';
meta_dataset_key = 'DATASET_KEY';
meta_int_source_type_key = 'INTELLIGENCE_SOURCE_TYPE_KEY';
meta_int_source_text = 'INTELLIGENCE_SOURCE_TEXT';
meta_int_source_url = 'INTELLIGENCE_SOURCE_URL';
meta_int_source_image = 'INTELLIGENCE_SOURCE_IMAGE';
meta_int_source_mime_type_key = 'INTELLIGENCE_SOURCE_MIME_TYPE_KEY';

# exlusion list.  
exclusion_list = [meta_deleted_ind,meta_quality_cd,meta_action_cd,meta_created_dttm,meta_creator_nm,meta_changed_dttm,meta_changed_by_nm,meta_record_entry_dttm,meta_checksum_id,meta_json_source_id,meta_duplicate_record_ind,meta_lineage_key_hash,meta_lineage_row_hash,meta_version_type_key,meta_version_effective_date,meta_version_termination_date,meta_active_indicator,meta_user_key,meta_report_date,meta_data_provider_key,meta_data_provide_service_key,meta_dataset_key,meta_int_source_type_key,meta_int_source_text,meta_int_source_url,meta_int_source_image,meta_int_source_mime_type_key];


# COMMAND ----------

# DBTITLE 1,Check File or Filepath Exists
def CheckPathExists(_filepath):
    fs = sc._jvm.org.apache.hadoop.fs.FileSystem.get(sc._jsc.hadoopConfiguration())
    return fs.exists(sc._jvm.org.apache.hadoop.fs.Path(_filepath))

# COMMAND ----------

# DBTITLE 1,Replace Special characters from String Variable
# Remove special character from a string variable
def replaceSpecialCharactersInString(string_variable, columns_special_characters_to_replace):
    
    if len(string_variable) > 0 and len(columns_special_characters_to_replace)>0:
      
        # Replace single space with underscore
        string_variable = string_variable.replace(' ', '_')
        
        # Remove any special character in the string
        for special_character in columns_special_characters_to_replace:
                
            string_variable = string_variable.replace(special_character, '')
            
    return string_variable;

# COMMAND ----------

# DBTITLE 1,Replace Special characters from Dataframe
# Remove special character from a dataframe
def replaceSpecialCharactersInColumns(dataframe, columns_special_characters_to_replace):
  
    if dataframe is not None:
      
        # Replace space with underscore
        dataframe = dataframe.select([sf.col(col).alias(col.replace(' ', '_')) for col in dataframe.columns])
        
        # The steps below removes other special characters                
        columns_list = dataframe.columns
        
        # Loop through data frame column list
        for column in columns_list:
          
            original_column_name = column
          
            # Loop through special characters list
            for special_character in columns_special_characters_to_replace:
              
                if len(column) > 0 and len(special_character) > 0:
                    
                    column = column.replace(special_character, '')
            
            # Rename dataframe column
            dataframe = dataframe.withColumnRenamed(original_column_name, column)
        
    return dataframe

# COMMAND ----------

# DBTITLE 1,Load dataset column attributes from SQL DB
def LoadDatasetColumnAttributes(project_id, source_id, dataset):
  
    config_dataset_columns_query = "(SELECT * FROM [cp_data].[config_dataset_columns] WHERE project_id=" + project_id + " AND  source_id=" + source_id + " AND dataset='" + dataset + "' AND LOWER(status)='active') cdc";
     
    config_dataset_columns_df = spark.read.jdbc(Stratos_sqldb_URL, table=config_dataset_columns_query);
    
    return config_dataset_columns_df;

# COMMAND ----------

# DBTITLE 1,Convert dataframe column to Pyspark dictionary
def ConvertDatasetColumnsDFtoDict(config_dataset_columns_df):
  
    config_dataset_columns_dict = {};
  
    config_dataset_columns_collect = config_dataset_columns_df.collect();
    
    for row in config_dataset_columns_collect:
      
        current_record_source_column_name = replaceSpecialCharactersInString(row.source_column_name, columns_special_characters_to_replace)
      
        if len(current_record_source_column_name)>0:
          
            current_record_source_column_name = current_record_source_column_name.lower();
          
            config_dataset_columns_dict[current_record_source_column_name] = {
              'config_dataset_column_id': row.config_dataset_column_id
              , 'project_id': row.project_id
              , 'source_id': row.source_id
              , 'dataset': row.dataset
              , 'source_column_name': current_record_source_column_name
              , 'source_datatype': row.source_datatype
              , 'source_data_length': row.source_data_length
              , 'source_precision': row.source_precision
              , 'source_nullable': row.source_nullable
              , 'standardised_column_name': replaceSpecialCharactersInString(row.standardised_column_name, columns_special_characters_to_replace)
              , 'status': row.status
            };
            
    return config_dataset_columns_dict;

# COMMAND ----------

  def ConvertDatatypesInDataframe(target_adls_layer, dataFrame, dataset_columns_dict):

    target_adls_layer = target_adls_layer.lower();
    
    target_adls_layer_dataset_dict = {}
    
    if len(dataset_columns_dict) > 0:
      
        print(dataset_columns_dict);
        
        dataset_columns_list = dataFrame.columns;
        
        #for column in dataset_columns_dict:
        for original_column_name in dataset_columns_list:
            
            if len(original_column_name) > 0:
                print("=>"+original_column_name)
                original_column_name = original_column_name.lower();
                column = replaceSpecialCharactersInString(original_column_name, columns_special_characters_to_replace)
                print("=>=>"+column)
                
                # Append metadata column - META_CREATED_DTTM
                if column.lower() in ['meta_created_dttm', 'effective_start_date', 'effective_end_date', 'meta_record_entry_dttm', 'meta_changed_dttm', 'version_effective_date', 'version_termination_date', 'meta_report_date']:                  
                    dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(TimestampType()).alias(column))
                
                # Append metadata column - IS_RECORD_ACTIVE
                elif column.lower() == 'is_record_active':                 
                    dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(IntegerType()).alias(column))
                    
                # Append metadata column - IS_RECORD_ACTIVE
                elif column.lower() in ['meta_action_cd', 'delete_ind', 'meta_quality_cd', 'meta_action_cd', 'meta_creator_nm', 'meta_changed_by_nm', 'meta_checksum_id', 'meta_json_source_identifier', 'meta_duplicate_record_ind', 'meta_lineage_key_hash', 'meta_lineage_row_hash', 'version_type_key', 'active_indicator', 'user_key', 'data_provider_key', 'data_provider_service_key', 'dataset_key', 'intelligence_source_type_key', 'intelligence_source_text', 'intelligence_source_url', 'intelligence_source_image', 'intelligence_source_mime_type_key'
]:                 
                    dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(StringType()).alias(column)) 
                    
                elif column in dataset_columns_dict.keys() and dataset_columns_dict[column] is not None:
                    
                    current_record = dataset_columns_dict[column]
                    current_record_source_datatype = current_record['source_datatype'].lower();
                    current_record_source_data_length = current_record['source_data_length'];
                    current_record_source_precision = current_record['source_precision'];
              
                    print(column + ':' + current_record_source_datatype)
                    
                    if current_record_source_datatype == 'int' or (current_record_source_datatype == 'number' and len(current_record_source_data_length) > 0 and int(current_record_source_data_length) <= 11 and (len(current_record_source_precision) != 0 and int(current_record_source_precision) == 0 or current_record_source_precision is None)):
                    
                        if target_adls_layer == 'enr_unharm':              
                            dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(IntegerType())).withColumnRenamed(original_column_name, column)
                      
                    elif current_record_source_datatype == 'bigint' or (current_record_source_datatype == 'number' and ((len(current_record_source_data_length) and int(current_record_source_data_length) > 11) or len(current_record_source_data_length) ==0 ) and ((len(current_record_source_precision) != 0 and int(current_record_source_precision) == 0) or current_record_source_precision is None or current_record_source_precision == "")):
                    
                        if target_adls_layer == 'enr_unharm':              
                            dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(LongType())).withColumnRenamed(original_column_name, column)
                      
                    elif current_record_source_datatype == 'float' or current_record_source_datatype == 'decimal' or (current_record_source_datatype == 'number' and len(current_record_source_data_length) and int(current_record_source_data_length) > 1 and len(current_record_source_precision) != 0 and int(current_record_source_precision) > 1):
                    
                        if target_adls_layer == 'enr_unharm':              
                            dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(DoubleType())).withColumnRenamed(original_column_name, column)
                      
                    elif current_record_source_datatype == 'char' or current_record_source_datatype == 'nchar' or current_record_source_datatype == 'varchar' or current_record_source_datatype == 'varchar2'or current_record_source_datatype == 'nvarchar'or current_record_source_datatype == 'nvarchar2' or current_record_source_datatype == 'string':
                    
                        if target_adls_layer == 'enr_unharm':              
                            dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(StringType())).withColumnRenamed(original_column_name, column);
                      
                    elif current_record_source_datatype == 'date' or current_record_source_datatype == 'timestamp' or current_record_source_datatype == 'datetime' or current_record_source_datatype == 'datetime2':
                    
                        if target_adls_layer == 'enr_unharm': 
                        
                            #dataFrame = dataFrame.withColumn(original_column_name, to_timestamp(col(original_column_name), dataset_datetime_format))
                        
                            dataFrame = dataFrame.withColumn(original_column_name, from_unixtime(unix_timestamp(col(original_column_name), dataset_datetime_format)).alias(original_column_name))
                            dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(TimestampType())).withColumnRenamed(original_column_name, column);

               
    return dataFrame;    

# COMMAND ----------

# DBTITLE 1,Convert source datatypes to adls datatypes
# Converts datatype based on source column attributes defined in mapping document only
def ConvertSourceDatatypesToADLSDatatypes(target_adls_layer, dataset_columns_dict):

    target_adls_layer = target_adls_layer.lower();
    
    if len(dataset_columns_dict) > 0:
    
        for column in dataset_columns_dict:
            
            if len(column) > 0:
                
                column = replaceSpecialCharactersInString(column, columns_special_characters_to_replace)
              
                # Append metadata column - META_CREATED_DTTM
                if column.lower() == 'meta_created_dttm':
                    
                    dataset_columns_dict['META_CREATED_DTTM'] = {};
                    dataset_columns_dict['META_CREATED_DTTM']['standardised_column_name']= 'META_CREATED_DTTM'
                    dataset_columns_dict['META_CREATED_DTTM'][target_adls_layer + '_datatype'] = 'DATETIME2';
                
                # Append metadata column - EFFECTIVE_START_DATE
                elif column.lower() == 'effective_start_date':
                    
                    dataset_columns_dict['EFFECTIVE_START_DATE'] = {};
                    dataset_columns_dict['EFFECTIVE_START_DATE']['standardised_column_name']= 'EFFECTIVE_START_DATE'
                    dataset_columns_dict['EFFECTIVE_START_DATE'][target_adls_layer + '_datatype'] = 'DATETIME2';
                
                # Append metadata column - EFFECTIVE_END_DATE
                elif column.lower() == 'effective_end_date':
                    
                    dataset_columns_dict['EFFECTIVE_END_DATE'] = {};
                    dataset_columns_dict['EFFECTIVE_END_DATE']['standardised_column_name']= 'EFFECTIVE_END_DATE'
                    dataset_columns_dict['EFFECTIVE_END_DATE'][target_adls_layer + '_datatype'] = 'DATETIME2';
                
                # Append metadata column - IS_RECORD_ACTIVE
                elif column.lower() == 'is_record_active':
                    
                    dataset_columns_dict['IS_RECORD_ACTIVE'] = {};
                    dataset_columns_dict['IS_RECORD_ACTIVE']['standardised_column_name']= 'IS_RECORD_ACTIVE'
                    dataset_columns_dict['IS_RECORD_ACTIVE'][target_adls_layer + '_datatype'] = 'INT';
                    
                elif column in dataset_columns_dict.keys() and dataset_columns_dict[column] is not None:
                    
                    current_record = dataset_columns_dict[column]
                    
                    if current_record['source_datatype'].lower() == 'number' and len(current_record['source_data_length'])>0 and int(current_record['source_data_length']) <= 11 and (int(current_record['source_precision']) == 0 or current_record['source_precision'] is None):
                    
                        if target_adls_layer == 'enr_unharm' or target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'INT';
                      
                    elif current_record['source_datatype'].lower() == 'bigint' or (current_record['source_datatype'].lower() == 'number' and len(current_record['source_data_length'])>0 and int(current_record['source_data_length']) > 11 and (int(current_record['source_precision']) == 0 or current_record['source_precision'] is None)):
                    
                        if target_adls_layer == 'enr_unharm' or target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'BIGINT';
                      
                    elif current_record['source_datatype'].lower() == 'float' or (current_record['source_datatype'].lower() == 'number' and len(current_record['source_data_length'])>0 and int(current_record['source_data_length']) > 1 and int(current_record['source_precision']) > 1):
                    
                        if target_adls_layer == 'enr_unharm':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'DOUBLE';
                    
                        if target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'FLOAT';
                      
                    elif current_record['source_datatype'].lower() == 'char':
                    
                        if target_adls_layer == 'enr_unharm':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'STRING';
                    
                        if target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'NVARCHAR(50)';
                      
                    elif current_record['source_datatype'].lower() == 'varchar' or current_record['source_datatype'].lower() == 'varchar2' or current_record['source_datatype'].lower() == 'string':
                    
                        if target_adls_layer == 'enr_unharm':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'STRING';
                    
                        if target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'NVARCHAR(4000)';
                      
                    elif current_record['source_datatype'].lower() == 'date':
                    
                        if target_adls_layer == 'enr_unharm':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'TIMESTAMP';
                    
                        if target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'DATETIME2';
                      
                    elif current_record['source_datatype'].lower() == 'timestamp':
                    
                        if target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'DATETIME2';
                          
    return dataset_columns_dict;    

# COMMAND ----------

# DBTITLE 1,Convert dataframe datatypes - Compare with columns in mapping document
# Converts datatypes by comparing columns in dataframe to source column attributes defined in mapping document
# Appends the column attributes of the target layer to the source list
def ConvertDatatypes(target_adls_layer, df_columns, dataset_columns_dict, source_type=''):

    target_adls_layer = target_adls_layer.lower();
    
    target_adls_layer_dataset_dict = {}
    
    if len(df_columns) > 0 and len(dataset_columns_dict) > 0:
    
        print(df_columns)
      

    
        for column in df_columns:
            
            if len(column) > 0:
              
                column = replaceSpecialCharactersInString(column, columns_special_characters_to_replace)
                
                print(column)
                #print(dataset_columns_dict)
                
                column = column.lower()
              
                # Append metadata column - META_CREATED_DTTM
                if column.lower() == 'delete_ind':
                    
                    dataset_columns_dict['DELETE_IND'] = {};
                    dataset_columns_dict['DELETE_IND']['standardised_column_name']= 'DELETE_IND'
                    dataset_columns_dict['DELETE_IND'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                
                elif column.lower() == 'meta_quality_cd':
                    dataset_columns_dict['META_QUALITY_CD'] = {};
                    dataset_columns_dict['META_QUALITY_CD']['standardised_column_name']= 'META_QUALITY_CD'
                    dataset_columns_dict['META_QUALITY_CD'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                    
                elif column.lower() == 'meta_action_cd':
                    dataset_columns_dict['META_ACTION_CD'] = {};
                    dataset_columns_dict['META_ACTION_CD']['standardised_column_name']= 'META_ACTION_CD'
                    dataset_columns_dict['META_ACTION_CD'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                    
                elif column.lower() == 'meta_created_dttm':
                    dataset_columns_dict['META_CREATED_DTTM'] = {};
                    dataset_columns_dict['META_CREATED_DTTM']['standardised_column_name']= 'META_CREATED_DTTM'
                    dataset_columns_dict['META_CREATED_DTTM'][target_adls_layer + '_datatype'] = 'DATETIME2';
                    
                elif column.lower() == 'meta_creator_nm':
                    dataset_columns_dict['META_CREATOR_NM'] = {};
                    dataset_columns_dict['META_CREATOR_NM']['standardised_column_name']= 'META_CREATOR_NM'
                    dataset_columns_dict['META_CREATOR_NM'][target_adls_layer + '_datatype'] = 'NVARCHAR(255)';
                    
                elif column.lower() == 'meta_changed_dttm':
                    dataset_columns_dict['META_CHANGED_DTTM'] = {};
                    dataset_columns_dict['META_CHANGED_DTTM']['standardised_column_name']= 'META_CHANGED_DTTM'
                    dataset_columns_dict['META_CHANGED_DTTM'][target_adls_layer + '_datatype'] = 'DATETIME2';
                    
                elif column.lower() == 'meta_changed_by_nm':
                    dataset_columns_dict['META_CHANGED_BY_NM'] = {};
                    dataset_columns_dict['META_CHANGED_BY_NM']['standardised_column_name']= 'META_CHANGED_BY_NM'
                    dataset_columns_dict['META_CHANGED_BY_NM'][target_adls_layer + '_datatype'] = 'NVARCHAR(255)';
                    
                elif column.lower() == 'record_entry_dttm':
                    dataset_columns_dict['RECORD_ENTRY_DTTM'] = {};
                    dataset_columns_dict['RECORD_ENTRY_DTTM']['standardised_column_name']= 'RECORD_ENTRY_DTTM'
                    dataset_columns_dict['RECORD_ENTRY_DTTM'][target_adls_layer + '_datatype'] = 'DATETIME2';
                    
                elif column.lower() == 'meta_checksum_id':
                    dataset_columns_dict['META_CHECKSUM_ID'] = {};
                    dataset_columns_dict['META_CHECKSUM_ID']['standardised_column_name']= 'META_CHECKSUM_ID'
                    dataset_columns_dict['META_CHECKSUM_ID'][target_adls_layer + '_datatype'] = 'NVARCHAR(max)';
                    
                elif column.lower() == 'meta_json_source_identifier':
                    dataset_columns_dict['META_JSON_SOURCE_IDENTIFIER'] = {};
                    dataset_columns_dict['META_JSON_SOURCE_IDENTIFIER']['standardised_column_name']= 'META_JSON_SOURCE_IDENTIFIER'
                    dataset_columns_dict['META_JSON_SOURCE_IDENTIFIER'][target_adls_layer + '_datatype'] = 'NVARCHAR(max)';
                    
                elif column.lower() == 'meta_duplicate_record_ind':
                    dataset_columns_dict['META_DUPLICATE_RECORD_IND'] = {};
                    dataset_columns_dict['META_DUPLICATE_RECORD_IND']['standardised_column_name']= 'META_DUPLICATE_RECORD_IND'
                    dataset_columns_dict['META_DUPLICATE_RECORD_IND'][target_adls_layer + '_datatype'] = 'NVARCHAR(1)';
                    
                elif column.lower() == 'meta_lineage_key_hash':
                    dataset_columns_dict['META_LINEAGE_KEY_HASH'] = {};
                    dataset_columns_dict['META_LINEAGE_KEY_HASH']['standardised_column_name']= 'META_LINEAGE_KEY_HASH'
                    dataset_columns_dict['META_LINEAGE_KEY_HASH'][target_adls_layer + '_datatype'] = 'NVARCHAR(100)';
                    
                elif column.lower() == 'meta_lineage_row_hash':
                    dataset_columns_dict['META_LINEAGE_ROW_HASH'] = {};
                    dataset_columns_dict['META_LINEAGE_ROW_HASH']['standardised_column_name']= 'META_LINEAGE_ROW_HASH'
                    dataset_columns_dict['META_LINEAGE_ROW_HASH'][target_adls_layer + '_datatype'] = 'NVARCHAR(100)';
                    
                elif column.lower() == 'version_type_key':
                    dataset_columns_dict['VERSION_TYPE_KEY'] = {};
                    dataset_columns_dict['VERSION_TYPE_KEY']['standardised_column_name']= 'VERSION_TYPE_KEY'
                    dataset_columns_dict['VERSION_TYPE_KEY'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                    
                elif column.lower() == 'version_effective_date':
                    dataset_columns_dict['VERSION_EFFECTIVE_DATE'] = {};
                    dataset_columns_dict['VERSION_EFFECTIVE_DATE']['standardised_column_name']= 'VERSION_EFFECTIVE_DATE'
                    dataset_columns_dict['VERSION_EFFECTIVE_DATE'][target_adls_layer + '_datatype'] = 'DATETIME2';
                    
                elif column.lower() == 'version_termination_date':
                    dataset_columns_dict['VERSION_TERMINATION_DATE'] = {};
                    dataset_columns_dict['VERSION_TERMINATION_DATE']['standardised_column_name']= 'VERSION_TERMINATION_DATE'
                    dataset_columns_dict['VERSION_TERMINATION_DATE'][target_adls_layer + '_datatype'] = 'DATETIME2';
                    
                elif column.lower() == 'active_indicator':
                    dataset_columns_dict['ACTIVE_INDICATOR'] = {};
                    dataset_columns_dict['ACTIVE_INDICATOR']['standardised_column_name']= 'ACTIVE_INDICATOR'
                    dataset_columns_dict['ACTIVE_INDICATOR'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                
                elif column.lower() == 'user_key':
                    dataset_columns_dict['USER_KEY'] = {};
                    dataset_columns_dict['USER_KEY']['standardised_column_name']= 'USER_KEY'
                    dataset_columns_dict['USER_KEY'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                    
                elif column.lower() == 'report_dt':
                    
                    dataset_columns_dict['REPORT_DT'] = {};
                    dataset_columns_dict['REPORT_DT']['standardised_column_name']= 'REPORT_DT'
                    dataset_columns_dict['REPORT_DT'][target_adls_layer + '_datatype'] = 'DATETIME2';
                    
                elif column.lower() == 'data_provider_key':
                    
                    dataset_columns_dict['DATA_PROVIDER_KEY'] = {};
                    dataset_columns_dict['DATA_PROVIDER_KEY']['standardised_column_name']= 'DATA_PROVIDER_KEY'
                    dataset_columns_dict['DATA_PROVIDER_KEY'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                    
                elif column.lower() == 'data_provider_service_key':
                    
                    dataset_columns_dict['DATA_PROVIDER_SERVICE_KEY'] = {};
                    dataset_columns_dict['DATA_PROVIDER_SERVICE_KEY']['standardised_column_name']= 'DATA_PROVIDER_SERVICE_KEY'
                    dataset_columns_dict['DATA_PROVIDER_SERVICE_KEY'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                    
                elif column.lower() == 'dataset_key':
                    
                    dataset_columns_dict['DATASET_KEY'] = {};
                    dataset_columns_dict['DATASET_KEY']['standardised_column_name']= 'DATASET_KEY'
                    dataset_columns_dict['DATASET_KEY'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                    
                elif column.lower() == 'intelligence_source_type_key':
                    
                    dataset_columns_dict['INTELLIGENCE_SOURCE_TYPE_KEY'] = {};
                    dataset_columns_dict['INTELLIGENCE_SOURCE_TYPE_KEY']['standardised_column_name']= 'INTELLIGENCE_SOURCE_TYPE_KEY'
                    dataset_columns_dict['INTELLIGENCE_SOURCE_TYPE_KEY'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                    
                elif column.lower() == 'intelligence_source_text':
                    
                    dataset_columns_dict['INTELLIGENCE_SOURCE_TEXT'] = {};
                    dataset_columns_dict['INTELLIGENCE_SOURCE_TEXT']['standardised_column_name']= 'INTELLIGENCE_SOURCE_TEXT'
                    dataset_columns_dict['INTELLIGENCE_SOURCE_TEXT'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                    
                elif column.lower() == 'intelligence_source_url':
                    
                    dataset_columns_dict['INTELLIGENCE_SOURCE_URL'] = {};
                    dataset_columns_dict['INTELLIGENCE_SOURCE_URL']['standardised_column_name']= 'INTELLIGENCE_SOURCE_URL'
                    dataset_columns_dict['INTELLIGENCE_SOURCE_URL'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                    
                elif column.lower() == 'intelligence_source_image':
                    
                    dataset_columns_dict['INTELLIGENCE_SOURCE_IMAGE'] = {};
                    dataset_columns_dict['INTELLIGENCE_SOURCE_IMAGE']['standardised_column_name']= 'INTELLIGENCE_SOURCE_IMAGE'
                    dataset_columns_dict['INTELLIGENCE_SOURCE_IMAGE'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                    
                elif column.lower() == 'intelligence_source_mime_type_key':
                    
                    dataset_columns_dict['INTELLIGENCE_SOURCE_MIME_TYPE_KEY'] = {};
                    dataset_columns_dict['INTELLIGENCE_SOURCE_MIME_TYPE_KEY']['standardised_column_name']= 'INTELLIGENCE_SOURCE_MIME_TYPE_KEY'
                    dataset_columns_dict['INTELLIGENCE_SOURCE_MIME_TYPE_KEY'][target_adls_layer + '_datatype'] = 'NVARCHAR(10)';
                    
                # Append metadata column - EFFECTIVE_START_DATE
                elif column.lower() == 'effective_start_date':
                    
                    dataset_columns_dict['EFFECTIVE_START_DATE'] = {};
                    dataset_columns_dict['EFFECTIVE_START_DATE']['standardised_column_name']= 'EFFECTIVE_START_DATE'
                    dataset_columns_dict['EFFECTIVE_START_DATE'][target_adls_layer + '_datatype'] = 'DATETIME2';
                
                # Append metadata column - EFFECTIVE_END_DATE
                elif column.lower() == 'effective_end_date':
                    
                    dataset_columns_dict['EFFECTIVE_END_DATE'] = {};
                    dataset_columns_dict['EFFECTIVE_END_DATE']['standardised_column_name']= 'EFFECTIVE_END_DATE'
                    dataset_columns_dict['EFFECTIVE_END_DATE'][target_adls_layer + '_datatype'] = 'DATETIME2';
                
                # Append metadata column - IS_RECORD_ACTIVE
                elif column.lower() == 'is_record_active':
                    
                    dataset_columns_dict['IS_RECORD_ACTIVE'] = {};
                    dataset_columns_dict['IS_RECORD_ACTIVE']['standardised_column_name']= 'IS_RECORD_ACTIVE'
                    dataset_columns_dict['IS_RECORD_ACTIVE'][target_adls_layer + '_datatype'] = 'INT';
                    
                elif column in dataset_columns_dict.keys() and dataset_columns_dict[column] is not None:
                #elif column.lower() in config_dataset_columns_dict_lower_keys and config_dataset_columns_dict_lower_keys[column.lower()] is not None:
                
                    current_record = dataset_columns_dict[column]
                    
                    print(target_adls_layer+ ':' + column + ':' + current_record['source_datatype'] + ':' + current_record['source_precision'])
                    
                    if current_record['source_datatype'].lower() == 'number' and len(current_record['source_data_length']) > 0 and int(current_record['source_data_length']) <= 11 and (len(current_record['source_precision']) != 0 and int(current_record['source_precision']) == 0 or current_record['source_precision'] is None):
                    
                        if target_adls_layer == 'enr_unharm' or target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'INT';

                      
                    elif current_record['source_datatype'].lower() == 'bigint' or (current_record['source_datatype'].lower() == 'number' and ((len(current_record['source_data_length']) > 0 and int(current_record['source_data_length']) > 11) or len(current_record['source_data_length']) == 0) and ((len(current_record['source_precision']) != 0 and int(current_record['source_precision']) == 0) or current_record['source_precision'] is None or current_record['source_precision'] == "")):
                    
                        if target_adls_layer == 'enr_unharm' or target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'BIGINT';
                      
                    elif current_record['source_datatype'].lower() == 'float' or current_record['source_datatype'].lower() == 'decimal' or (current_record['source_datatype'].lower() == 'number' and len(current_record['source_data_length']) > 0 and int(current_record['source_data_length']) > 1 and len(current_record['source_precision']) != 0 and int(current_record['source_precision']) > 1):
                    
                        if target_adls_layer == 'enr_unharm':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'DOUBLE';
                    
                        if target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'FLOAT';
                      
                    elif current_record['source_datatype'].lower() == 'char' or current_record['source_datatype'].lower() == 'nchar':
                    
                        if target_adls_layer == 'enr_unharm':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'STRING';
                    
                        if target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'NVARCHAR(50)';
                      
                    elif current_record['source_datatype'].lower() == 'varchar' or current_record['source_datatype'].lower() == 'nvarchar' or current_record['source_datatype'].lower() == 'varchar2' or current_record['source_datatype'].lower() == 'nvarchar2' or current_record['source_datatype'].lower() == 'string':
                    
                        if target_adls_layer == 'enr_unharm':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'STRING';
                    
                        if target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'NVARCHAR(max)';
                      
                    elif current_record['source_datatype'].lower() == 'date':
                    
                        if target_adls_layer == 'enr_unharm':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'TIMESTAMP';
                    
                        if target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'DATETIME2';
                      
                    elif current_record['source_datatype'].lower() == 'timestamp' or current_record['source_datatype'].lower() == 'datetime':
                    
                        if target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = 'DATETIME2';
                    else:
                        #print(current_record['source_datatype'])
                        if target_adls_layer == 'asdwh':              
                            dataset_columns_dict[column][target_adls_layer + '_datatype'] = current_record['source_datatype'];

    return dataset_columns_dict;

# COMMAND ----------

#def GetASDWExternalTableDDL(FileWithPath, ASDWFileExternalLocation, ExternalTableName):
#    print("################ IN GetASDWExternalTableDDL #################")
#    #print(FileWithPath, ASDWFileExternalLocation, ExternalTableName)
#    print("################################")
#
#    #f = FileWithPath
#    #Single_f = [x for x in WalkDir(f) if x.split(".")[-1] == 'parquet'][0]
#
#    #ef = ASDWFileExternalLocation
#    table = ExternalTableName
#    o = '''
#      IF EXISTS ( SELECT * FROM sys.external_tables WHERE object_id = OBJECT_ID('{0}') )
#      DROP EXTERNAL TABLE {0};
#      CREATE EXTERNAL TABLE {0}('''.format(table)
#
#    try:
#      df = spark.read.format("parquet").load(Single_f)
#    except:
#      print("ERROR:: Could not read parquet :: " + Single_f)
#      return None
#    
#    map = {"DoubleType": "float", "StringType": 'nvarchar(4000)', "IntegerType": "integer", 'DateType':'date'
#    'TimestampType':'datetime', "LongType": 'bigint'}
#
#    o = o + GetColumnsNamesAndDataTypes(df, map)
#    o = o + '''
#      )
#    WITH (DATA_SOURCE = [PROJECT],LOCATION = N'{0}',FILE_FORMAT = [ParquetFormat],REJECT_TYPE = VALUE,REJECT_VALUE = 0);
#    '.format(ef)
#
#    print("################ DONE GetASDWExternalTableDDL #################")
#    return o

# COMMAND ----------

# DBTITLE 1,UPSERT Data
# This function upserts data and accepts the following parameters
# existing_df: dataframe into which data needs to upsert into
# new_df: dataframe containing data from which data needs to upsert from
# unique_columns_identifier_list: One or more columns that could be used to identify unique records in the dataset
# order_by_column_list: List of columns used to order the dataframe when partitioned
# result_order_column_list: List of columns that could be used to order the dataframe before being returned by the function

def UpsertData(existing_df, new_df, unique_columns_identifier_list, order_by_column_list, result_order_column_list = []):
    
    # Extract historical data into its own dataframe - These don't need to be processed with new records
    # Historical data are those where current=0 and has an end date

    
    archived_df = existing_df.filter(scd_column_active + "=0")  
    
    print("Upsert count 1: " + str(existing_df.count()));
    
    print("Upsert count 2: " + str(new_df.count()));
    
    print("Upsert count 3: " + str(archived_df.count()));
    
    # Extract existing data into its own dataframe - These need to be processed with new records
    # Existing data are those where current=1 and don't have an end date

    existing_df = existing_df.filter(scd_column_active + "=1");
    # default_effective_end_date
    
    print("Upsert count 4: " + str(existing_df.count()));
  
    #display(existing_df);
    print(scd_column_active + "=0");
    print(scd_column_active + "=1");
    
    # Order the new dataframe columns by the existing dataframe columns
    new_df = new_df[existing_df.columns]
    
    # Order the archived dataframe columns by the existing dataframe columns
    archived_df = archived_df[existing_df.columns]
    
    
    # Merge the Existing and New dataframes
    #df_merge = existing_df.union(new_df)
    df_merge = existing_df.unionByName(new_df)
    
    print("Upsert count 5: " + str(df_merge.count()));
        
    if scd_type == 'scd_2_cdc':    
      
      df_merge_columns = df_merge.select([c for c in df_merge.columns if c not in {meta_created_dttm_column}])
      
      df_merge_columns_list = df_merge_columns.columns
      
      # Drop duplicates if coming
      df_merge = df_merge.orderBy(asc(meta_created_dttm_column)).dropDuplicates(subset=[*df_merge_columns_list])
      #df_merge = df_merge.orderBy(meta_created_dttm_column,ascending=True).dropDuplicates(subset=[*df_merge_columns_list])

      
    # Partition the dataframe by the unique columns and order the columns by the columns defined in orderby column
    # Apply row number to number rows in the same partition based on the orderby column
    df_merge = df_merge.withColumn(row_number_column, sf.row_number().over(Window.partitionBy(*unique_columns_identifier_list).orderBy(desc(*order_by_column_list))))

    print("Upsert count 6: " + str(df_merge.count()));

    df_merge = df_merge.withColumn(scd_column_valid_to, 
                           sf.when(
                             (col(row_number_column) > 1) 
                             , lit(startTime).cast(TimestampType()).alias(scd_column_valid_to)
                           )
                           .otherwise(col(scd_column_valid_to))
                         )\
                        .withColumn(scd_column_active, 
                           sf.when(
                             (col(row_number_column) > 1) 
                             , lit(0)
                           )
                           .otherwise(col(scd_column_active))
                         );
    
        # Functionality to update scd2 columns  
    df_merge = df_merge.withColumn(meta_version_termination_date, 
                           sf.when(
                             (col(row_number_column) > 1) & (col(meta_active_indicator) == 'Y' ) 
                             , lit(startTime).cast(TimestampType()).alias(meta_version_termination_date)
                           )
                           .otherwise(col(meta_version_termination_date))
                         )\
                        .withColumn(meta_changed_dttm, 
                           sf.when(
                             (col(row_number_column) > 1) & (col(meta_active_indicator) == 'Y' ) 
                             , lit(startTime).cast(TimestampType()).alias(meta_changed_dttm)
                           )
                           .otherwise(col(meta_changed_dttm))
                         )\
                        .withColumn(meta_action_cd, 
                           sf.when(
                             (col(row_number_column) > 1) & (col(meta_active_indicator ) == 'Y' )  
                             , lit('U')
                           )
                           .otherwise(col(meta_action_cd ))
                         )\
                        .withColumn(meta_active_indicator, 
                           sf.when(
                             (col(row_number_column) > 1) & (col(meta_active_indicator) == 'Y' )  
                             , lit('N')
                           )
                           .otherwise(col(meta_active_indicator ))                                    
                         );
    
    print("Upsert count 7: " + str(df_merge.count()));
    
    archived_df.printSchema();
    existing_df.printSchema();
    df_merge.printSchema();
    
    #display(archived_df);
    # Drop columns based on scd type
#   if scd_type == 'scd_2':
#       
#       # Drop row number column and union the merged data to the archived one
#       df_merge = df_merge.drop(row_number_column).union(archived_df)
#   
#       print("Upsert count 8: " + str(df_merge.count()));
#   else:
#     
#       # Extract only rows where row umber = 1 then drop the row number column
#       df_merge = df_merge.where(df_merge._row_number == 1).drop(row_number_column)

    if scd_type == 'scd_2':
        
        # Drop row number column and union the merged data to the archived one
        df_merge = df_merge.drop(row_number_column).union(archived_df)
    
        print("Upsert count 8: " + str(df_merge.count()));
    elif scd_type =='scd_1':

        df_merge_columns = df_merge.select([c for c in df_merge.columns if c in {meta_lineage_key_hash}]) 

        df_merge_columns_list = df_merge_columns.columns

        # Drop duplicates if coming.  Meta created dttm should not be impacted
        #df_merge = df_merge.orderBy(asc(meta_created_dttm_column)).dropDuplicates(subset=[*df_merge_columns_list])
        # Extract only rows where row umber = 1 then drop the row number column
        df_merge = df_merge.where(df_merge._row_number == 1).drop(row_number_column)
    elif scd_type == 'scd_2_cdc':    
      
        df_merge = df_merge.drop(row_number_column)


        print("Upsert count 9: " + str(df_merge.count()));
        
    
    # Check if columns have been defined to order the data frame before returning
    if len(result_order_column_list) > 0:
      
        # Order the dataframe by the defined columns
        df_merge = df_merge.orderBy(*result_order_column_list)
    
        print("Upsert count 10: " + str(df_merge.count()));
        
    print("Upsert count 11: " + str(df_merge.count()));
    
    return df_merge
    

# COMMAND ----------

# DBTITLE 1,Refresh Harmonized SQL DB table (truncate and reload based on the source_system)
def RefreshSqlDbTbl(tgt_schema_name, tgt_table_name, source_system):
  """
  Loads the data into sql server for curated layer
  tgt_schema_name = 'cp_data'
  tgt_tablename   = 'gtmi_singlecplist'
  source_system   = 'GOLD_TIER_MI'
  """
  try:
    df = spark.sql(f"select * from  vw_{tgt_table_name}_{source_system}")
    print(tgt_schema_name , tgt_table_name, source_system)
    if df.count() > 0:
      print(df.count())
      conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                            'SERVER='+dbServer+';'
                            'DATABASE='+dbDatabase+';UID='+dbUser+';'
                            'PWD='+dbPass
                            )
      cursor = conn.cursor()
      execSQL = f"delete from {tgt_schema_name}.{tgt_table_name} where source_system = upper('{source_system}')"
      conn.autocommit = True
      cursor.execute(execSQL)
      print("Data been Deleted")
      df.write.jdbc(Stratos_sqldb_URL, f"{tgt_schema_name}.{tgt_table_name}", "append")
      print(f"load of {tgt_table_name}  with  is completed")
    else:
      print("Returned Zero Records")
      
  except Exception as e:
    print('Exception raised')
    raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Refresh Curated SQL DB table (truncate and reload complete table)
def RefreshCuratedSqlTbl(tgt_schema_name, tgt_table_name):
  """
  Loads the data into sql server for curated layer
  tgt_schema_name = 'cp_data'
  tgt_tablename   = 'gtmi_singlecplist'
  source_system   = 'GOLD_TIER_MI'
  """
  try:
    df = spark.sql(f"select * from  vw_{tgt_table_name}")
    print(tgt_schema_name , tgt_table_name)
    if df.count() > 0:
      print(df.count())
      conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                            'SERVER='+dbServer_curated+';'
                            'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
                            'PWD='+dbPass
                            )
      cursor = conn.cursor()
      execSQL = f"truncate table {tgt_schema_name}.{tgt_table_name}"
      conn.autocommit = True
      cursor.execute(execSQL)
      print("Data been Deleted")
      df.write.jdbc(Stratos_sqldb_URL_curated, f"{tgt_schema_name}.{tgt_table_name}", "append")
      print(f"load of {tgt_table_name}  with  is completed")
    else:
      print("Returned Zero Records")
      
  except Exception as e:
    print('Exception raised')
    raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Create Temp View from the external tables data set list 
def CreateTempVwFromExternalTables(dataset_list):
    """
    function creates temp views from the dataset_list configured in the notebook, 
    dataset_list should contain the list of the external tables along with the schema
    example [cp_data.tbl_name]
    """
    dataset_dict = dict([(dataset, dataset.replace(".","_")) for dataset in dataset_list])
    view_list = []
    print(f"list of the temporary views thats needs to be created: {dataset_dict}")
    #create dataframe 
    for k, v in dataset_dict.items():
      a = dataset_dict[k]
      a = spark.read.jdbc(url=Stratos_sqldwh_URL, table=f'{k}')
      
      a.createOrReplaceTempView(f"{v}")
      view_list.append(v)
    print('List of views')

    return view_list
  

# COMMAND ----------

# DBTITLE 1,Where Clause - SCD2
def where_clause_for_merge():
    try:  
      delta_data_alias = "delta_data_alias" 
      unharm_data_alias = "unharm_data_alias" 
      deltakeys_list = [] 
      for col in primary_keys.split(","): 
        deltakeys_list.append(unharm_data_alias +"."+col+"="+delta_data_alias+"."+col)
      deltakeys = "AND".join(deltakeys_list)
      deltakeys_matched = deltakeys+ "and unharm_data_alias.IS_RECORD_ACTIVE = delta_data_alias.IS_RECORD_ACTIVE and unharm_data_alias.ACTIVE_INDICATOR = delta_data_alias.ACTIVE_INDICATOR and unharm_data_alias.IS_RECORD_ACTIVE = 1 and unharm_data_alias.ACTIVE_INDICATOR = 'Y'" 
      #deltakeys = deltakeys + " and unharm_data_alias.IS_RECORD_ACTIVE = 1 and unharm_data_alias.ACTIVE_INDICATOR = 'Y'"  
    except Exception as e:  
      raise Exception(e)  
    return deltakeys_matched

# COMMAND ----------

# DBTITLE 1,Set Column Values for Update Active Record to History
def set_col_value_for_update_when_matched(startTime,delta_df_base_columnList,unharm_data_alias):
  import pyspark.sql.functions as sf 
  
  dict_delta_matched_update_history = {};   
  dict_delta_matched_update_history['META_ACTION_CD']=sf.lit('U')
  dict_delta_matched_update_history['META_CHANGED_DTTM']=sf.lit(startTime).cast(TimestampType())
  dict_delta_matched_update_history['VERSION_TERMINATION_DATE']=sf.lit(startTime).cast(TimestampType())
  dict_delta_matched_update_history['ACTIVE_INDICATOR']=sf.lit('N')
  dict_delta_matched_update_history['EFFECTIVE_END_DATE']=sf.lit(startTime).cast(TimestampType())
  dict_delta_matched_update_history['IS_RECORD_ACTIVE']=sf.lit(0)
  #TBD with Dinesh do we need updating existing columns
  for column in delta_df_base_columnList:
    if column not in['META_ACTION_CD','META_CHANGED_DTTM','VERSION_TERMINATION_DATE','ACTIVE_INDICATOR','EFFECTIVE_END_DATE','IS_RECORD_ACTIVE']:
      dict_delta_matched_update_history[column] = unharm_data_alias+"."+column
  return dict_delta_matched_update_history


# COMMAND ----------

# DBTITLE 1,Set Metadata Column Values for New Records
def set_col_value_for_insert_when_not_matched(delta_df_base_columnList,delta_data_alias,default_termination_date): 
  import pyspark.sql.functions as sf  
  startTime = datetime.datetime.now().strftime(tableTimeFormat)
  dict_delta_not_matched_insert = {};   
  dict_delta_not_matched_insert['META_CHANGED_DTTM']=sf.lit(startTime).cast(TimestampType())
  dict_delta_not_matched_insert['VERSION_EFFECTIVE_DATE']=sf.lit(startTime).cast(TimestampType())
  dict_delta_not_matched_insert['EFFECTIVE_START_DATE']=sf.lit(startTime).cast(TimestampType())
  dict_delta_not_matched_insert['VERSION_TERMINATION_DATE']=sf.lit(default_termination_date)
  dict_delta_not_matched_insert['EFFECTIVE_END_DATE']=sf.lit(default_termination_date) 
  for column in delta_df_base_columnList:
    if column not in['META_CHANGED_DTTM','VERSION_EFFECTIVE_DATE','EFFECTIVE_START_DATE','VERSION_TERMINATION_DATE','EFFECTIVE_END_DATE']:
      dict_delta_not_matched_insert[column] = delta_data_alias+"."+column

  
  return (dict_delta_not_matched_insert)

# COMMAND ----------

# DBTITLE 1,Merge for Updates (Active to Inactive Records)
def write_to_unharm_update(delta_file_path_full,deltakeys_matched,dict_delta_matched_update_history,raw_df):
  unharm_delta = DeltaTable.forPath(spark, delta_file_path_full);
  (unharm_delta.alias("unharm_data_alias").merge(raw_df.alias("delta_data_alias"),deltakeys_matched)\
  .whenMatchedUpdate(set=dict_delta_matched_update_history)\
  .execute()
  )

# COMMAND ----------

# DBTITLE 1,Merge for Inserts (version-zero active records for existing and new)
def write_to_unharm_insert(delta_file_path_full,deltakeys_matched,dict_delta_not_matched_insert,raw_df):
  unharm_delta = DeltaTable.forPath(spark, delta_file_path_full);
  (unharm_delta.alias("unharm_data_alias").merge(raw_df.alias("delta_data_alias"),deltakeys_matched)\
  .whenNotMatchedInsert(values=dict_delta_not_matched_insert)\
  .execute()
  )
