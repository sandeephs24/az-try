# Databricks notebook source
# DBTITLE 0,Run the config file
# MAGIC %run "/Shared/CP_Data/Config/config"

# COMMAND ----------

# MAGIC %run "/Shared/CP_Data/Shared_script/main"

# COMMAND ----------

import json

from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 0,Generic Variables
try:
    dbutils.widgets.text('project_id', '', 'Project ID');
    dbutils.widgets.text('source_id', '', 'Source ID');
    dbutils.widgets.text('dataset', '', 'Dataset');  
    dbutils.widgets.text('primary_keys', '', 'Primary keys');
    dbutils.widgets.text('land_file_path', '', 'Land File Path');
    dbutils.widgets.text('land_file_name', '', 'Land File Name');
    dbutils.widgets.text('raw_file_path', '', 'RAW File Path');
    dbutils.widgets.text('raw_file_name', '', 'RAW File Name');

except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

metricLogDict = {}

# COMMAND ----------

try:
    vProjectID = dbutils.widgets.get('project_id');
    vSourceID = dbutils.widgets.get('source_id');
    vDataset = dbutils.widgets.get('dataset');  
    vPrimaryKeys = dbutils.widgets.get('primary_keys');
    vLandFilePath = dbutils.widgets.get('land_file_path');
    vLandFileName = dbutils.widgets.get('land_file_name');
    vRawFilePath = dbutils.widgets.get('raw_file_path');
    vRawFileName = dbutils.widgets.get('raw_file_name');
    metricLogDict['vLandFilePath'] = vLandFilePath
    metricLogDict['vLandFileName'] = vLandFileName
    metricLogDict['vRawFilePath'] = vRawFilePath
    metricLogDict['vRawFileName'] = vRawFileName
    metricLogDict['vPrimaryKeys'] = vPrimaryKeys
    metricLogDict['vDataset'] = vDataset
    
    
    
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

# DBTITLE 0,Extract the file extension
try:
    
    # Set base path for ADLS mount
    vADLSMountBase = '/mnt/ADLS/' 
            
    # generate primary key list
    vPrimaryKeyList = vPrimaryKeys.split(',') 
    if len(vPrimaryKeyList) > 0:
       vPrimaryKeyList = [vPrimaryKeys.strip() for vPrimaryKeys in vPrimaryKeyList]
       for vPrimaryKeys in vPrimaryKeyList:
          vPrimaryKeys = vPrimaryKeys.strip()
    
    vLandFilePath = vADLSMountBase + vLandFilePath + '/' + vLandFileName

    # Autogenerate RAW file name from LAND file name - if not supplied as parameter
    if len(vRawFileName) == 0:
      vRawFileList = vRawFileName.split('_')
      vRawFileName = '_'.join(vRawFileList) + '.parquet'
        
    #vRawFilePath = vADLSMountBase + vRawFilePath + '/' + vRawFileName
    vRawFileTempPath = vADLSMountBase + vRawFilePath + 'temp'    
    vRawFilePath = vADLSMountBase + vRawFilePath  
    #vRawFileName = vRawFileName + '.parquet'

    dfLand = None;
      
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

# DBTITLE 0,Read Data from Source File
try:
  
    # Check if RAW file path and extension variables are not empty and RAW file exist in ADLS
    if len(vLandFilePath) > 0 and CheckPathExists(vLandFilePath) == True:
      dfLand = spark.read.format("avro").load(vLandFilePath)
    
    # Determine raw source columns for row hash.  Ignores meta columns.  Tweak may be required to handle files whete no metadata is present in the dataset_columns table.  
    vColumnList = dfLand.columns    
    vColumnList = [x for x in vColumnList if x not in exclusion_list]
    
    vElements = '[{"DDID":' + vSourceID + ',"DIDN":"' + vDataset + '","Elements":['
        
    dfLand = dfLand.withColumn(meta_checksum_id, lit("|".join(vColumnList)))  
       
    # if no key defined then use record hash
    if len(vPrimaryKeyList) > 1:
      dfLand = dfLand.withColumn(meta_lineage_key_hash , sha2(concat_ws("|", *vPrimaryKeyList), 256))
      dfLand = dfLand.withColumn(meta_json_source_id, concat(lit(vElements), to_json(struct(*vPrimaryKeyList)).cast(StringType()), lit("]}]")))
    else:
      dfLand = dfLand.withColumn(meta_lineage_key_hash , sha2(concat_ws("|", *vColumnList), 256))
      dfLand = dfLand.withColumn(meta_json_source_id, concat(lit(vElements), to_json(struct(*vColumnList)).cast(StringType()), lit("]}]")))
      
    dfLand = dfLand.withColumn(meta_lineage_row_hash, sha2(concat_ws("|", *vColumnList), 256))
    dfLand = dfLand.withColumn(meta_created_dttm, col(meta_created_dttm).cast(TimestampType())); 
    dfLand = dfLand.withColumn(meta_changed_dttm, lit(startTime).cast(TimestampType())); 
    dfLand = dfLand.withColumn(meta_record_entry_dttm, lit(startTime).cast(TimestampType())); 
    dfLand = dfLand.withColumn(meta_report_date, lit(startTime).cast(TimestampType())); 
    dfLand = dfLand.withColumn(meta_changed_by_nm, lit('landing_to_raw'));    
    
    readCount = dfLand.count();
          
except Exception as e:
  print(str(e))
  raise Exception(e)      

# COMMAND ----------

def copy_file(vRawFilePath, vRawFileTempPath, dfCopy, vRawFileName):
  if CheckPathExists(vRawFileTempPath) == True:
    dbutils.fs.rm(vRawFileTempPath,True)
    
  #write file to temp RAW folder
  dfCopy.coalesce(1).write.parquet(vRawFileTempPath)
  #create filename based on folder name
  file = dbutils.fs.ls(vRawFileTempPath)[-1][0]
  #copy file from folder to level above
  dbutils.fs.mv(file,vRawFilePath + '/' + vRawFileName)
  dbutils.fs.rm(vRawFileTempPath,True)

# COMMAND ----------

try:
    # Save data 
    if dfLand is not None:
      copy_file(vRawFilePath, vRawFileTempPath, dfLand, vRawFileName)
      
      writeCount = dfLand.count();
except Exception as e:
  print(str(e))
  raise Exception(e)


# COMMAND ----------

json_metricLogDict = json.dumps(metricLogDict, indent = 4)
dbutils.notebook.exit(json.dumps({'status': 'Succeeded', 'ReadCount': readCount, 'WriteCount': writeCount, 'Message': successMessage, 'metricLogJson':json_metricLogDict}))
