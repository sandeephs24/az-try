# Databricks notebook source
# MAGIC %run "/Shared/CP_Data/Config/config"

# COMMAND ----------

# MAGIC %run "/Shared/CP_Data/Shared_script/main"

# COMMAND ----------

spark.conf.set("spark.sql.avro.compression.codec", "deflate")
spark.conf.set("spark.sql.avro.deflate.level", "5")

# COMMAND ----------

dbutils.widgets.text('RawFilePath', '', 'RAW File Path')
dbutils.widgets.text('RawFileName', '', 'RAW File Name');
dbutils.widgets.text('Dataset', '', 'Dataset');
dbutils.widgets.text('META_CREATED_DTTM', '', 'META_CREATED_DTTM');
dbutils.widgets.text('BWMax_FileName','BWMax_FileName');


# COMMAND ----------

RawFilePath = dbutils.widgets.get('RawFilePath');
RawFileName = dbutils.widgets.get('RawFileName');
Dataset = dbutils.widgets.get('Dataset');
Meta_Created_DTTM=dbutils.widgets.get('META_CREATED_DTTM');
BWMax_FileName = dbutils.widgets.get('BWMax_FileName')
BWMax_FileName =  BWMax_FileName.replace('.avro','')

# COMMAND ----------

FilePath = '/mnt/ADLS/'+RawFilePath+'/'+RawFileName
PathForComp = '/mnt/ADLS/'+RawFilePath+'/'



# COMMAND ----------

try:
  df = spark.read.format("json").load(FilePath)
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

# Remove special character from a dataframe
def replaceSpecialCharactersInColumns(dataframe, columns_special_characters_to_replace):
  
    if dataframe is not None:
      
        # Replace space with underscore
        dataframe = dataframe.select([sf.col(col).alias(col.replace(' ', '_')) for col in dataframe.columns])
        
        # The steps below removes other special characters                
        columns_list = dataframe.columns
        
        # Loop through data frame column list
        for column in columns_list:
          
            original_column_name = column
          
            # Loop through special characters list
            for special_character in columns_special_characters_to_replace:
              
                if len(column) > 0 and len(special_character) > 0:
                    
                    column = column.replace(special_character, '')
            
            # Rename dataframe column
            dataframe = dataframe.withColumnRenamed(original_column_name, column)
        
    return dataframe

# COMMAND ----------

df_replaceSpecialCharacters = replaceSpecialCharactersInColumns(df,'/') 

# COMMAND ----------


if BWMax_FileName != '' :

  RemoveFields = spark.read.format("json").load(PathForComp + BWMax_FileName+'.json');
  rm_cols = set(RemoveFields.columns);
  today_cols = set(df_replaceSpecialCharacters.columns);
  RemoveFields = RemoveFields.drop("DATAPAKID","RECORD","OHREQUID")
  df_replaceSpecialCharacters = df_replaceSpecialCharacters.drop("DATAPAKID","RECORD","OHREQUID")
  #df_replaceSpecialCharacters = replaceSpecialCharactersInColumns(df,'/') 
  RemoveFields =  replaceSpecialCharactersInColumns(RemoveFields,'/') 
  #RemoveFields = RemoveFields.drop(*list(rm_cols-today_cols));
  



# old_file = col1, col2, coln, colm
# new_file = col1, col2

# diff_col = old_file - new_file = coln, colm
# df.drop(diff_col)

# temp_list= [1, 'adf', 2.40]

# COMMAND ----------

#df_replaceSpecialCharacters = df_replaceSpecialCharacters.drop("DATAPAKID","RECORD","OHREQUID")



# COMMAND ----------

if BWMax_FileName != '' :
  df_replaceSpecialCharacters = df_replaceSpecialCharacters.exceptAll(RemoveFields)
  

# COMMAND ----------

readCount=df_replaceSpecialCharacters.count()
print(readCount)

# COMMAND ----------

def rename_file(origin_path, dest_path, file_type, new_name):
  lcase_file_type=file_type.lower()
  filelist = dbutils.fs.ls(origin_path)#list all files from origin path
  filtered_filelist = [x.name for x in filelist if x.name.endswith("."+lcase_file_type)]#keep names of the files that match the type requested
  if len(filtered_filelist) > 1:#check if we have more than 1 files of that type
    print("Too many "+lcase_file_type+" files. You will need a different implementation")
  elif len(filtered_filelist) == 0: #check if there are no files of that type
    print("No "+lcase_file_type+" files found")
  else:
    new_name = new_name.replace("."+file_type, "")
    dbutils.fs.mv(origin_path+"/"+filtered_filelist[0], dest_path+"/"+new_name+"."+file_type)#move the file to a new path (can be the same) 

# COMMAND ----------

def saveToADLS(dataframe, adls_path, file_name, file_format = 'avro'):
    if len(file_format) > 0 and len(adls_path) > 0 and len(file_name) > 0 and dataframe is not None:
      if file_format.lower()== 'avro':
            final_path=adls_path +"/"+ file_name
            dataframe.repartition(1).write.format('com.databricks.spark.avro').mode("overwrite").option('header','true').save(adls_path+'/tempDelta')
            rename_file(adls_path+'/tempDelta',adls_path, file_format, file_name)
            
            dbutils.fs.rm(adls_path+'/tempDelta',True)

# COMMAND ----------

delta_file_path_full = '/mnt/ADLS/'+RawFilePath
print(delta_file_path_full)
df_replaceSpecialCharacters.printSchema()

# COMMAND ----------

try:
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('META_CREATED_DTTM',lit(Meta_Created_DTTM))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('DELETE_IND',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('META_QUALITY_CD',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('META_ACTION_CD',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('META_CREATOR_NM',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('META_CHANGED_DTTM',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('META_CHANGED_BY_NM',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('RECORD_ENTRY_DTTM',lit(Meta_Created_DTTM))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('META_CHECKSUM_ID',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('META_JSON_SOURCE_IDENTIFIER',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('META_DUPLICATE_RECORD_IND',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('META_LINEAGE_KEY_HASH',lit(''))  
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('META_LINEAGE_ROW_HASH',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('VERSION_TYPE_KEY',lit('O'))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('VERSION_EFFECTIVE_DATE',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('VERSION_TERMINATION_DATE',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('ACTIVE_INDICATOR',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('USER_KEY',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('REPORT_DT',lit(''))  
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('DATA_PROVIDER_KEY',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('DATA_PROVIDER_SERVICE_KEY',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('DATASET_KEY',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('INTELLIGENCE_SOURCE_TYPE_KEY',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('INTELLIGENCE_SOURCE_TEXT',lit(''))  
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('INTELLIGENCE_SOURCE_URL',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('INTELLIGENCE_SOURCE_IMAGE',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('INTELLIGENCE_SOURCE_MIME_TYPE_KEY',lit(''))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('DATAPAKID',lit(46233773))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('RECORD',lit(46233773))
  df_replaceSpecialCharacters=df_replaceSpecialCharacters.withColumn('OHREQUID',lit(46233773))
  df_replaceSpecialCharacters.printSchema()
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

df_save = df_replaceSpecialCharacters
df_save.printSchema()

# COMMAND ----------

try:
  saveToADLS(df_save, delta_file_path_full, RawFileName.replace(".json",""), 'avro')
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

writeCount = readCount
print(writeCount)

# COMMAND ----------

import sys
Databytes_read = sys.getsizeof(df_replaceSpecialCharacters)

# COMMAND ----------

dbutils.notebook.exit(json.dumps({'status': 'Succeeded', 'ReadCount': readCount, 'WriteCount': writeCount, 'Message': successMessage, 'Databytes_read': Databytes_read, 'Dataset': Dataset}))
