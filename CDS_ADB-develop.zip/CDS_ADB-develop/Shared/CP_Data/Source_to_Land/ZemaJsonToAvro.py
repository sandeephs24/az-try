# Databricks notebook source
# MAGIC %run "/Shared/CP_Data/Config/config"

# COMMAND ----------

# MAGIC %run "/Shared/CP_Data/Shared_script/main"

# COMMAND ----------

spark.conf.set("spark.sql.avro.compression.codec", "deflate")
spark.conf.set("spark.sql.avro.deflate.level", "5")

# COMMAND ----------

dbutils.widgets.text('RawFilePath', '', 'RAW File Path');
dbutils.widgets.text('RawFileName', '', 'RAW File Name');
dbutils.widgets.text('Dataset', '', 'Dataset');
dbutils.widgets.text('SourceData', '', 'Source Data');
dbutils.widgets.text('META_CREATED_DTTM', '', 'META_CREATED_DTTM');

# COMMAND ----------

RawFilePath = dbutils.widgets.get('RawFilePath');
RawFileName = dbutils.widgets.get('RawFileName');
Dataset = dbutils.widgets.get('Dataset');
SourceData = dbutils.widgets.get('SourceData');
Meta_Created_DTTM=dbutils.widgets.get('META_CREATED_DTTM');

# COMMAND ----------

try:
  df_vwCrossCurrency_API = spark.read.option('multiline','true').json(sc.parallelize([SourceData]))
  df_vwCrossCurrency_API.printSchema()
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

readCount=df_vwCrossCurrency_API.count()
print(readCount)

# COMMAND ----------

def rename_file(origin_path, dest_path, file_type, new_name):
  lcase_file_type=file_type.lower()
  filelist = dbutils.fs.ls(origin_path)#list all files from origin path
  filtered_filelist = [x.name for x in filelist if x.name.endswith("."+lcase_file_type)]#keep names of the files that match the type requested
  if len(filtered_filelist) > 1:#check if we have more than 1 files of that type
    print("Too many "+lcase_file_type+" files. You will need a different implementation")
  elif len(filtered_filelist) == 0: #check if there are no files of that type
    print("No "+lcase_file_type+" files found")
  else:
    new_name = new_name.replace("."+file_type, "")
    dbutils.fs.mv(origin_path+"/"+filtered_filelist[0], dest_path+"/"+new_name+"."+file_type)#move the file to a new path (can be the same) 

# COMMAND ----------

def saveToADLS(dataframe, adls_path, file_name, file_format = 'avro'):
    if len(file_format) > 0 and len(adls_path) > 0 and len(file_name) > 0 and dataframe is not None:
      if file_format.lower()== 'avro':
            final_path=adls_path +"/"+ file_name
            dataframe.repartition(1).write.format('com.databricks.spark.avro').mode("overwrite").option('header','true').save(adls_path+'/tempDelta')
            rename_file(adls_path+'/tempDelta',adls_path, file_format, file_name)
            
            dbutils.fs.rm(adls_path+'/tempDelta',True)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *

#Flatten array of structs and structs
def flatten(df):
   # compute Complex Fields (Lists and Structs) in Schema   
   complex_fields = dict([(field.name, field.dataType)
                             for field in df.schema.fields
                             if type(field.dataType) == ArrayType or  type(field.dataType) == StructType])
   while len(complex_fields)!=0:
      col_name=list(complex_fields.keys())[0]
      print ("Processing :"+col_name+" Type : "+str(type(complex_fields[col_name])))
    
      # if StructType then convert all sub element to columns.
      # i.e. flatten structs
      if (type(complex_fields[col_name]) == StructType):
         expanded = [col(col_name+'.'+k).alias(col_name+'_'+k) for k in [ n.name for n in  complex_fields[col_name]]]
         df=df.select("*", *expanded).drop(col_name)
    
      # if ArrayType then add the Array Elements as Rows using the explode function
      # i.e. explode Arrays
      elif (type(complex_fields[col_name]) == ArrayType):    
         df=df.withColumn(col_name,explode_outer(col_name))
    
      # recompute remaining Complex Fields in Schema       
      complex_fields = dict([(field.name, field.dataType)
                             for field in df.schema.fields
                             if type(field.dataType) == ArrayType or  type(field.dataType) == StructType])
   return df

# COMMAND ----------

try:
  df_flat = flatten(df_vwCrossCurrency_API)
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

df_flat.createOrReplaceTempView('flat_vwCrossCurrency')

# COMMAND ----------

try:
  df_vwcc = spark.sql('select oprDate as DateQuoted, \
                      `Base Currency` BaseCurrency, \
                      Currency, \
                      (case when type = "Bid" then value else null end) BuyRate, \
                      (case when type = "Ask" then value else null end) SellRate, \
                      (case when type = "Mid" then value else null end)  MeanRate, \
                      (case when type = "Working Day" then value else null end)  QuoteDay \
                      from flat_vwCrossCurrency')
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

df_vwcc.createOrReplaceTempView('vwcc_columnms')

# COMMAND ----------

try:
  df_crosscurrency = spark.sql("""
    SELECT DISTINCT DateQuoted, BaseCurrency, Currency, BR as BuyRate, SR as SellRate, MR as MeanRate, QD as QuoteDay from ( 
      SELECT *
      , COALESCE(BuyRate
              , first_value(BuyRate) OVER (PARTITION BY BaseCurrency,Currency ORDER BY BuyRate NULLS LAST)
               ) as BR,
        COALESCE(SellRate
              , first_value(SellRate) OVER (PARTITION BY BaseCurrency,Currency ORDER BY SellRate NULLS LAST)
               ) as SR,
        COALESCE(MeanRate
              , first_value(MeanRate) OVER (PARTITION BY BaseCurrency,Currency ORDER BY MeanRate NULLS LAST)
               ) as MR,
        COALESCE(QuoteDay
              , first_value(QuoteDay) OVER (PARTITION BY BaseCurrency,Currency ORDER BY QuoteDay NULLS LAST)
               ) as QD
      FROM   vwcc_columnms)
    """)
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

df_crosscurrency.createOrReplaceTempView('crosscurrency')
df_crosscurrency.count()

# COMMAND ----------

try:
  df_crossjoin = spark.sql("""
  select
  d1.DateQuoted,
  d1.Currency as Basecurrency,
  d2.Currency,
  cast(d1.BuyRate as double) as ask1,
  cast(d1.SellRate as double) as bid1,
  cast(d1.MeanRate as double) as mid1,
  d1.QuoteDay,
  cast(d2.BuyRate as double) as ask2,
  cast(d2.SellRate as double) as bid2,
  cast(d2.MeanRate as double) as mid2
  from
  crosscurrency d1,
  crosscurrency d2 
  WHERE
  d1.BaseCurrency = d2.BaseCurrency
  """)
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

df_crossjoin.createOrReplaceTempView("vwcrosscurrency")

# COMMAND ----------

try:
  df_viewCrossCurrency = spark.sql("""
  SELECT DateQuoted,
                       BaseCurrency, 
                       Currency, 
                       CASE WHEN (BaseCurrency = Currency) THEN 1
                                           WHEN (BaseCurrency = 'GBP' and Currency = 'USD') THEN cast(Bid2 / Ask1 as DECIMAL(25,6))
                                           WHEN (BaseCurrency = 'EUR' and Currency = 'USD') THEN cast(Bid2 / Ask1 as DECIMAL(25,6))
                                           WHEN (BaseCurrency = 'EUR') THEN cast(Bid2 / Ask1 as DECIMAL(25,6))
                                    ELSE cast(Bid2 / Mid1 as DECIMAL(25,4))
                             END BuyRate,
                       CASE WHEN (BaseCurrency = Currency) THEN 1
                                           WHEN (BaseCurrency = 'GBP' and Currency = 'USD') THEN cast(Ask2 / Bid1  as DECIMAL(25,6))
                                           WHEN (BaseCurrency = 'EUR' and Currency = 'USD') THEN cast(Ask2 / Bid1 as DECIMAL(25,6))
                                           WHEN (BaseCurrency = 'EUR') THEN cast(Ask2 / Mid1 as DECIMAL(25,6))
                                    ELSE cast(Ask2 / Mid1 as DECIMAL(25,4))
                             END SellRate,
                       CASE WHEN (BaseCurrency = Currency) THEN 1
                                           WHEN (BaseCurrency = 'EUR') THEN cast(Mid2 / Mid1 as DECIMAL(25,6))
                                           ELSE cast(Mid2 / Mid1 as DECIMAL(25,4))
                                    END MeanRate,
                        QuoteDay
                from vwcrosscurrency
  """)
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

delta_file_path_full = '/mnt/ADLS/'+RawFilePath
print(delta_file_path_full)
df_viewCrossCurrency.printSchema()

# COMMAND ----------

display(df_viewCrossCurrency)

# COMMAND ----------

try:
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('META_CREATED_DTTM',lit(Meta_Created_DTTM))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('DELETE_IND',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('META_QUALITY_CD',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('META_ACTION_CD',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('META_CREATOR_NM',lit('ZemaJsonToAvro'))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('META_CHANGED_DTTM',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('META_CHANGED_BY_NM',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('RECORD_ENTRY_DTTM',lit(Meta_Created_DTTM))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('META_CHECKSUM_ID',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('META_JSON_SOURCE_IDENTIFIER',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('META_DUPLICATE_RECORD_IND',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('META_LINEAGE_KEY_HASH',lit(''))  
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('META_LINEAGE_ROW_HASH',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('VERSION_TYPE_KEY',lit('O'))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('VERSION_EFFECTIVE_DATE',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('VERSION_TERMINATION_DATE',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('ACTIVE_INDICATOR',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('USER_KEY',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('REPORT_DT',lit(''))  
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('DATA_PROVIDER_KEY',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('DATA_PROVIDER_SERVICE_KEY',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('DATASET_KEY',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('INTELLIGENCE_SOURCE_TYPE_KEY',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('INTELLIGENCE_SOURCE_TEXT',lit(''))  
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('INTELLIGENCE_SOURCE_URL',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('INTELLIGENCE_SOURCE_IMAGE',lit(''))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('INTELLIGENCE_SOURCE_MIME_TYPE_KEY',lit(''))
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

try:
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('META_CREATED_DTTM',lit(Meta_Created_DTTM))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn('DateQuoted',concat(df_viewCrossCurrency["DateQuoted"],lit(' 00:00:00.0000000')))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn("BuyRate",df_viewCrossCurrency.BuyRate.cast(DoubleType()))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn("SellRate",df_viewCrossCurrency.SellRate.cast(DoubleType()))
  df_viewCrossCurrency=df_viewCrossCurrency.withColumn("MeanRate",df_viewCrossCurrency.MeanRate.cast(DoubleType()))
  df_viewCrossCurrency.printSchema()
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

try:
  saveToADLS(df_viewCrossCurrency, delta_file_path_full, RawFileName, 'avro')
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

writeCount = df_viewCrossCurrency.count();

# COMMAND ----------

import sys
Databytes_read = sys.getsizeof(df_viewCrossCurrency)

# COMMAND ----------

dbutils.notebook.exit(json.dumps({'status': 'Succeeded', 'ReadCount': readCount, 'WriteCount': writeCount, 'Message': successMessage, 'Databytes_read': Databytes_read, 'Dataset': Dataset}))
