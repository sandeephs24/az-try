# Databricks notebook source
# MAGIC %run "../Config/config"

# COMMAND ----------

dbutils.widgets.text("api_result", "", "APIResult");
api_result = dbutils.widgets.get("api_result");
print(api_result)

# COMMAND ----------

try:
  df = spark.read.json(sc.parallelize([api_result]))
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

display(df)

# COMMAND ----------

try:
  df=df.withColumnRenamed('ZE-REST-Session','Session_ID')
  df=df.withColumnRenamed('Set-Cookie','Set_Cookie')
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

display(df)

# COMMAND ----------

try:
  import json
  from pyspark.sql.types import StringType
  session=df.first().Session_ID
  dbutils.notebook.exit(json.dumps({
    "Session_ID":  session,
    "Respose_Cookie":df.first().Set_Cookie

  }))
except Exception as e:
  print(str(e))
  raise Exception(e)
