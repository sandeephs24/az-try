# Databricks notebook source
# MAGIC %run "/Shared/CP_Data/Config/config"

# COMMAND ----------

# MAGIC %run "/Shared/CP_Data/Shared_script/main"

# COMMAND ----------

spark.conf.set("spark.sql.avro.compression.codec", "deflate")
spark.conf.set("spark.sql.avro.deflate.level", "5")

# COMMAND ----------

dbutils.widgets.text('RawFilePath', '', 'RAW File Path');
dbutils.widgets.text('RawFileName', '', 'RAW File Name');
dbutils.widgets.text('Dataset', '', 'Dataset');
dbutils.widgets.text('SourceData', '', 'Source Data');
dbutils.widgets.text('META_CREATED_DTTM', '', 'META_CREATED_DTTM');

# COMMAND ----------

RawFilePath = dbutils.widgets.get('RawFilePath');
RawFileName = dbutils.widgets.get('RawFileName');
Dataset = dbutils.widgets.get('Dataset');
SourceData = dbutils.widgets.get('SourceData');
Meta_Created_DTTM=dbutils.widgets.get('META_CREATED_DTTM');

# COMMAND ----------

#SourceData=SourceData.replace("\\","")

# COMMAND ----------

df_API = spark.read.option('multiline','true').json(sc.parallelize([SourceData]))
df_API.printSchema()

# COMMAND ----------

# df_API = df_API.withColumn("load_fcst",df_API.load_fcst.cast(DoubleType()))
# df_API.printSchema()

# COMMAND ----------

readCount=df_API.count()

# COMMAND ----------

def rename_file(origin_path, dest_path, file_type, new_name):
  lcase_file_type=file_type.lower()
  filelist = dbutils.fs.ls(origin_path)#list all files from origin path
  filtered_filelist = [x.name for x in filelist if x.name.endswith("."+lcase_file_type)]#keep names of the files that match the type requested
  if len(filtered_filelist) > 1:#check if we have more than 1 files of that type
    print("Too many "+lcase_file_type+" files. You will need a different implementation")
  elif len(filtered_filelist) == 0: #check if there are no files of that type
    print("No "+lcase_file_type+" files found")
  else:
    new_name = new_name.replace("."+file_type, "")
    dbutils.fs.mv(origin_path+"/"+filtered_filelist[0], dest_path+"/"+new_name+"."+file_type)#move the file to a new path (can be the same) 

# COMMAND ----------

def saveToADLS(dataframe, adls_path, file_name, file_format = 'avro'):
    if len(file_format) > 0 and len(adls_path) > 0 and len(file_name) > 0 and dataframe is not None:
      if file_format.lower()== 'avro':
            final_path=adls_path +"/"+ file_name
            dataframe.repartition(1).write.format('com.databricks.spark.avro').mode("overwrite").option('header','true').save(adls_path+'/tempDelta')
            rename_file(adls_path+'/tempDelta',adls_path, file_format, file_name)
            
            dbutils.fs.rm(adls_path+'/tempDelta',True)

# COMMAND ----------

delta_file_path_full = '/mnt/ADLS/'+RawFilePath
print(delta_file_path_full)
df_API.printSchema()

# COMMAND ----------

df_API=df_API.withColumn('META_CREATED_DTTM',lit(Meta_Created_DTTM))
df_API=df_API.withColumn('DELETE_IND',lit(''))
df_API=df_API.withColumn('META_QUALITY_CD',lit(''))
df_API=df_API.withColumn('META_ACTION_CD',lit(''))
df_API=df_API.withColumn('META_CREATOR_NM',lit('Zema_InterestRateJsonToAvro'))
df_API=df_API.withColumn('META_CHANGED_DTTM',lit(''))
df_API=df_API.withColumn('META_CHANGED_BY_NM',lit(''))
df_API=df_API.withColumn('RECORD_ENTRY_DTTM',lit(Meta_Created_DTTM))
df_API=df_API.withColumn('META_CHECKSUM_ID',lit(''))
df_API=df_API.withColumn('META_JSON_SOURCE_IDENTIFIER',lit(''))
df_API=df_API.withColumn('META_DUPLICATE_RECORD_IND',lit(''))
df_API=df_API.withColumn('META_LINEAGE_KEY_HASH',lit(''))  
df_API=df_API.withColumn('META_LINEAGE_ROW_HASH',lit(''))
df_API=df_API.withColumn('VERSION_TYPE_KEY',lit('O'))
df_API=df_API.withColumn('VERSION_EFFECTIVE_DATE',lit(''))
df_API=df_API.withColumn('VERSION_TERMINATION_DATE',lit(''))
df_API=df_API.withColumn('ACTIVE_INDICATOR',lit(''))
df_API=df_API.withColumn('USER_KEY',lit(''))
df_API=df_API.withColumn('REPORT_DT',lit(''))  
df_API=df_API.withColumn('DATA_PROVIDER_KEY',lit(''))
df_API=df_API.withColumn('DATA_PROVIDER_SERVICE_KEY',lit(''))
df_API=df_API.withColumn('DATASET_KEY',lit(''))
df_API=df_API.withColumn('INTELLIGENCE_SOURCE_TYPE_KEY',lit(''))
df_API=df_API.withColumn('INTELLIGENCE_SOURCE_TEXT',lit(''))  
df_API=df_API.withColumn('INTELLIGENCE_SOURCE_URL',lit(''))
df_API=df_API.withColumn('INTELLIGENCE_SOURCE_IMAGE',lit(''))
df_API=df_API.withColumn('INTELLIGENCE_SOURCE_MIME_TYPE_KEY',lit(''))
df_API.printSchema()

# COMMAND ----------

#df_API.printSchema()

# COMMAND ----------

df_API=df_API.withColumn("value",df_API.value.cast(DoubleType()))

# COMMAND ----------

df_API.printSchema()

# COMMAND ----------

display(df_API)

# COMMAND ----------

saveToADLS(df_API, delta_file_path_full, RawFileName, 'avro')

# COMMAND ----------

writeCount = df_API.count();

# COMMAND ----------

import sys
Databytes_read = sys.getsizeof(df_API)

# COMMAND ----------

dbutils.notebook.exit(json.dumps({'status': 'Succeeded', 'ReadCount': readCount, 'WriteCount': writeCount, 'Message': successMessage, 'Databytes_read': Databytes_read, 'Dataset': Dataset}))
