# Databricks notebook source
# DBTITLE 1,Run the config file
# MAGIC %run "/Shared/CP_Data/Config/config"

# COMMAND ----------

# DBTITLE 1,Import Packages
from pyspark.sql import functions as F
import re

# COMMAND ----------

spark.conf.set("spark.sql.avro.compression.codec", "deflate")
spark.conf.set("spark.sql.avro.deflate.level", "5")

# COMMAND ----------

# DBTITLE 1,Generic Variables
adls_root = '/mnt/ADLS/'
columns_special_characters_to_replace = ['%', '(', ')', '?','\r','/','¢','.']
print(columns_special_characters_to_replace)

# COMMAND ----------

# DBTITLE 1,Generic Functions
def replaceSpecialCharctersInColumns(dataframe, columns_special_characters_to_replace):
  
    if dataframe is not None:
      
        # Replace space with underscore
        #dataframe = dataframe.select([F.col(col).alias(col.strip().replace(' ', '_')) for col in dataframe.columns])
        columns_list = [col.strip().replace(' ', '_') for col in dataframe.columns]
        dataframe= dataframe.toDF(*columns_list)        
        
        # The steps below removes other special characters                
        #columns_list = dataframe.columns
        
        # Loop through data frame column list
        for column in columns_list:
          
            original_column_name = column
            
            # Loop through special characters list
            for special_character in columns_special_characters_to_replace:
              
                if len(column) > 0 and len(special_character) > 0:
                    
                    column = column.replace(special_character, '')
            
            column=re.sub('[^0-9a-zA-Z_]+','',column)
            # Rename dataframe column            
            dataframe = dataframe.withColumnRenamed(original_column_name, column)
        
    return dataframe

# COMMAND ----------

def rename_file(origin_path, dest_path, file_type, new_name):
  lcase_file_type=file_type.lower()
  filelist = dbutils.fs.ls(origin_path)#list all files from origin path
  filtered_filelist = [x.name for x in filelist if x.name.endswith("."+lcase_file_type)]#keep names of the files that match the type requested
  if len(filtered_filelist) > 1:#check if we have more than 1 files of that type
    print("Too many "+lcase_file_type+" files. You will need a different implementation")
  elif len(filtered_filelist) == 0: #check if there are no files of that type
    print("No "+lcase_file_type+" files found")
  else:
    new_name = new_name.replace("."+file_type, "")
    dbutils.fs.mv(origin_path+"/"+filtered_filelist[0], dest_path+"/"+new_name+"."+file_type)#move the file to a new path (can be the same) 

# COMMAND ----------

def saveToADLS(dataframe, adls_path, file_name, file_format = 'avro'):
    if len(file_format) > 0 and len(adls_path) > 0 and len(file_name) > 0 and dataframe is not None:
      if file_format.lower()== 'avro':
            final_path=adls_path +"/"+ file_name
            dataframe.repartition(1).write.format('com.databricks.spark.avro').mode("overwrite").option('header','true').save(adls_path+'/tempDelta')
            rename_file(adls_path+'/tempDelta',adls_path, file_format, file_name)
            
            dbutils.fs.rm(adls_path+'/tempDelta',True)

# COMMAND ----------

# DBTITLE 1,Create Widgets
dbutils.widgets.text("adls_path_source", "", "ADLS Path Source")
dbutils.widgets.text("file_name_source", "", "File Name Source")
dbutils.widgets.text("adls_path_dest", "", "ADLS Path Destination")
dbutils.widgets.text("file_name_dest", "", "File Name Destniation")
dbutils.widgets.text("Col_del_dest", "", "Column Delimiter")

# COMMAND ----------

# DBTITLE 1,Extract values from Widgets
adls_path_source = adls_root+dbutils.widgets.get("adls_path_source")
file_name_source = dbutils.widgets.get("file_name_source")
adls_path_dest   = adls_root+dbutils.widgets.get("adls_path_dest")
file_name_dest   = dbutils.widgets.get("file_name_dest")
Col_del_dest    =  dbutils.widgets.get("Col_del_dest")

if(Col_del_dest is None) or (Col_del_dest==''):
  Col_del_dest=','
  

print(adls_path_source)
print(file_name_source)
print(adls_path_dest)
print(file_name_dest)
print(Col_del_dest)

# COMMAND ----------

# DBTITLE 1,Read Data from Source File
try:
  source_DF = None
  source_DF = spark.read.option("header", "true").option('multiLine', 'true').option('delimiter',Col_del_dest).csv(adls_path_source + "/"+file_name_source)
  display(source_DF)
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

source_DF.count()

# COMMAND ----------

try:
  if source_DF is not None:
      # Replace special characters in column names
      source_DF = replaceSpecialCharctersInColumns(source_DF, columns_special_characters_to_replace)          
      #display(source_DF)
      #Write file to RAW layer
      saveToADLS(source_DF, adls_path_dest, file_name_dest, 'avro')

      #Remove existing file
      #dbutils.fs.rm(adls_path_source + "/"+file_name_source, True)
      
except Exception as e:
  print(str(e))
  raise Exception(e)
