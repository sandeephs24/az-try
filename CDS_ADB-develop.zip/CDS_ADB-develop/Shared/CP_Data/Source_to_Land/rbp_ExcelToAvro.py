# Databricks notebook source
# MAGIC %run "/Shared/CP_Data/Config/config"

# COMMAND ----------

# MAGIC %run "/Shared/CP_Data/Shared_script/main"

# COMMAND ----------

spark.conf.set("spark.sql.avro.compression.codec", "deflate")
spark.conf.set("spark.sql.avro.deflate.level", "5")

# COMMAND ----------

dbutils.widgets.text('RawFilePath', '', 'RAW File Path');
dbutils.widgets.text('RawFileName', '', 'RAW File Name');
dbutils.widgets.text('Dataset', '', 'Dataset');
dbutils.widgets.text('ExcelSheetName', '', 'Excel Sheet Name');
dbutils.widgets.text('ExcelSheetRange', '', 'Excel Sheet Range');
dbutils.widgets.text('ExcelFilePath', '', 'Excel File Path');
dbutils.widgets.text('ExcelFileName', '', 'Excel File Name');
dbutils.widgets.text('META_CREATED_DTTM', '', 'META_CREATED_DTTM');

# COMMAND ----------

RawFilePath = dbutils.widgets.get('RawFilePath');
RawFileName = dbutils.widgets.get('RawFileName');
Dataset = dbutils.widgets.get('Dataset');
ExcelSheetName = dbutils.widgets.get('ExcelSheetName');
ExcelSheetRange = dbutils.widgets.get('ExcelSheetRange');
ExcelFilePath = dbutils.widgets.get('ExcelFilePath');
ExcelFileName = dbutils.widgets.get('ExcelFileName');
Meta_Created_DTTM=dbutils.widgets.get('META_CREATED_DTTM');

# COMMAND ----------

try:
  ExcelSheetAddress =  "'"+ExcelSheetName+"'!"+ ExcelSheetRange
  ExcelPath='/mnt/ADLS/'+ExcelFilePath+'/'+ExcelFileName
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

print(ExcelPath)
print(ExcelSheetAddress)

# COMMAND ----------

try:
  #read excelfile
  ExceldataDF = spark.read.format('com.crealytics.spark.excel') \
  .option('header', True) \
  .option('inferSchema', False) \
  .option('treatEmptyValuesAsNulls', False) \
  .option('dataAddress', ExcelSheetAddress) \
  .option('maxRowsInMemory', 100000)\
  .load(ExcelPath)
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

readCount=ExceldataDF.count()

# COMMAND ----------

try:
  #replace any special characters in Column Name
  columns_special_characters = ['%', '(', ')', '?', '-','/']
  ExceldataDF=replaceSpecialCharactersInColumns(ExceldataDF,columns_special_characters).alias('ExceldataDF')
  ExceldataDF.printSchema()
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

def rename_file(origin_path, dest_path, file_type, new_name):
  lcase_file_type=file_type.lower()
  filelist = dbutils.fs.ls(origin_path)#list all files from origin path
  filtered_filelist = [x.name for x in filelist if x.name.endswith("."+lcase_file_type)]#keep names of the files that match the type requested
  if len(filtered_filelist) > 1:#check if we have more than 1 files of that type
    print("Too many "+lcase_file_type+" files. You will need a different implementation")
  elif len(filtered_filelist) == 0: #check if there are no files of that type
    print("No "+lcase_file_type+" files found")
  else:
    new_name = new_name.replace("."+file_type, "")
    dbutils.fs.mv(origin_path+"/"+filtered_filelist[0], dest_path+"/"+new_name+"."+file_type)#move the file to a new path (can be the same) 

# COMMAND ----------

def saveToADLS(dataframe, adls_path, file_name, file_format = 'avro'):
    if len(file_format) > 0 and len(adls_path) > 0 and len(file_name) > 0 and dataframe is not None:
      if file_format.lower()== 'avro':
            final_path=adls_path +"/"+ file_name
            dataframe.repartition(1).write.format('com.databricks.spark.avro').mode("overwrite").option('header','true').save(adls_path+'/tempDelta')
            rename_file(adls_path+'/tempDelta',adls_path, file_format, file_name)
            
            dbutils.fs.rm(adls_path+'/tempDelta',True)

# COMMAND ----------

delta_file_path_full = '/mnt/ADLS/'+RawFilePath
print(delta_file_path_full)
ExceldataDF.printSchema()

# COMMAND ----------

try:
  ExceldataDF=ExceldataDF.withColumn('META_CREATED_DTTM',lit(Meta_Created_DTTM))
  ExceldataDF=ExceldataDF.withColumn('DELETE_IND',lit(''))
  ExceldataDF=ExceldataDF.withColumn('META_QUALITY_CD',lit(''))
  ExceldataDF=ExceldataDF.withColumn('META_ACTION_CD',lit(''))
  ExceldataDF=ExceldataDF.withColumn('META_CREATOR_NM',lit('EnergyXJsonToAvro'))
  ExceldataDF=ExceldataDF.withColumn('META_CHANGED_DTTM',lit(''))
  ExceldataDF=ExceldataDF.withColumn('META_CHANGED_BY_NM',lit(''))
  ExceldataDF=ExceldataDF.withColumn('RECORD_ENTRY_DTTM',lit(Meta_Created_DTTM))
  ExceldataDF=ExceldataDF.withColumn('META_CHECKSUM_ID',lit(''))
  ExceldataDF=ExceldataDF.withColumn('META_JSON_SOURCE_IDENTIFIER',lit(''))
  ExceldataDF=ExceldataDF.withColumn('META_DUPLICATE_RECORD_IND',lit(''))
  ExceldataDF=ExceldataDF.withColumn('META_LINEAGE_KEY_HASH',lit(''))  
  ExceldataDF=ExceldataDF.withColumn('META_LINEAGE_ROW_HASH',lit(''))
  ExceldataDF=ExceldataDF.withColumn('VERSION_TYPE_KEY',lit('O'))
  ExceldataDF=ExceldataDF.withColumn('VERSION_EFFECTIVE_DATE',lit(''))
  ExceldataDF=ExceldataDF.withColumn('VERSION_TERMINATION_DATE',lit(''))
  ExceldataDF=ExceldataDF.withColumn('ACTIVE_INDICATOR',lit(''))
  ExceldataDF=ExceldataDF.withColumn('USER_KEY',lit(''))
  ExceldataDF=ExceldataDF.withColumn('REPORT_DT',lit(''))  
  ExceldataDF=ExceldataDF.withColumn('DATA_PROVIDER_KEY',lit(''))
  ExceldataDF=ExceldataDF.withColumn('DATA_PROVIDER_SERVICE_KEY',lit(''))
  ExceldataDF=ExceldataDF.withColumn('DATASET_KEY',lit(''))
  ExceldataDF=ExceldataDF.withColumn('INTELLIGENCE_SOURCE_TYPE_KEY',lit(''))
  ExceldataDF=ExceldataDF.withColumn('INTELLIGENCE_SOURCE_TEXT',lit(''))  
  ExceldataDF=ExceldataDF.withColumn('INTELLIGENCE_SOURCE_URL',lit(''))
  ExceldataDF=ExceldataDF.withColumn('INTELLIGENCE_SOURCE_IMAGE',lit(''))
  ExceldataDF=ExceldataDF.withColumn('INTELLIGENCE_SOURCE_MIME_TYPE_KEY',lit(''))
  ExceldataDF.printSchema()
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

ExceldataDF.show(20)

# COMMAND ----------

ExceldataDF.printSchema()

# COMMAND ----------

try:
  saveToADLS(ExceldataDF, delta_file_path_full, RawFileName, 'avro')
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

#delete xls file from land layer

# COMMAND ----------

writeCount = ExceldataDF.count();

# COMMAND ----------

import sys
Databytes_read = sys.getsizeof(ExceldataDF)

# COMMAND ----------

dbutils.notebook.exit(json.dumps({'status': 'Succeeded', 'ReadCount': readCount, 'WriteCount': writeCount, 'Message': successMessage, 'Databytes_read': Databytes_read, 'Dataset': Dataset}))
