# Databricks notebook source
# DBTITLE 1,Read raw
def read_from_raw(raw_file_path_full):
  try:  
    # Check if RAW file path and extension variables are not empty and RAW file exist in ADLS
    raw_df = None
    if len(raw_file_path_full) > 0 and  CheckPathExists(raw_file_path_full) == True: 
      raw_df = spark.read.format("parquet").load(raw_file_path_full)                
    
    return raw_df
  except Exception as e:
    print(str(e))
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,String conversion to list
def strip_convert_string_to_list(primary_keys):
  primary_keys = primary_keys.strip();
  primary_keys_list = primary_keys.split(',') if len(primary_keys) > 0 else [];
  if len(primary_keys_list) > 0:
    primary_keys_list = [primary_key.strip() for primary_key in primary_keys_list]
    for primary_key in primary_keys_list:
      primary_key = primary_key.strip()
  return primary_keys_list

# COMMAND ----------

# DBTITLE 1,Construct raw file path
def construct_raw_file_path(adls_mount_base,raw_file_path,raw_file_name):
    
    raw_file_path_full = '';
    if len(raw_file_path) > 0 and len(raw_file_name) > 0:
        if raw_file_path[0] == '/': # Remove first character of file path if it is '/'
            raw_file_path = raw_file_path[1:]
        if raw_file_path[-1] != '/': # Append '/' to file path if not there
            raw_file_path = raw_file_path + '/'
        raw_file_path_full = adls_mount_base + raw_file_path + raw_file_name
    return  raw_file_path_full 

# COMMAND ----------

# DBTITLE 1,Construct delta file path
  def construct_delta_file_path (adls_mount_base,delta_file_path,delta_file_name):
    delta_file_path_full = '';
    if len(delta_file_path) > 0 and len(delta_file_name) > 0:
        if delta_file_path[0] == '/': # Remove first character of file path if it is '/'
            delta_file_path = delta_file_path[1:]
        if delta_file_path[-1] != '/': # Append '/' to file path if not there
            delta_file_path = delta_file_path + '/'
        delta_file_path_full = adls_mount_base + delta_file_path + delta_file_name
    return delta_file_path_full
