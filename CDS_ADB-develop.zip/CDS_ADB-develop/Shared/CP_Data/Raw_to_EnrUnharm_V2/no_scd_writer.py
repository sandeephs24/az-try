# Databricks notebook source
def remove(delta_file_path_full):
  dbutils.fs.rm(delta_file_path_full, recurse = True)

# COMMAND ----------

def overwrite(alds_enriched_unharmonised_file_format,raw_df,delta_file_path_full):
  raw_df.write.format(alds_enriched_unharmonised_file_format).mode("overwrite").save(delta_file_path_full)

# COMMAND ----------

def write_no_scd(alds_enriched_unharmonised_file_format,raw_df,delta_file_path_full,delta_temp_log):
  if  CheckPathExists(delta_temp_log) == True:
    remove(delta_file_path_full)
  if alds_enriched_unharmonised_file_format.lower() == 'parquet':
     overwrite(alds_enriched_unharmonised_file_format,raw_df,delta_file_path_full)
