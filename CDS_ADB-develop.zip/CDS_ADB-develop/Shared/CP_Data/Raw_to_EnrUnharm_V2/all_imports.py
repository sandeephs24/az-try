# Databricks notebook source
# MAGIC %run "/Shared/CP_Data/Config/config" 

# COMMAND ----------

# MAGIC %run "/Shared/CP_Data/Shared_script/main"

# COMMAND ----------

# MAGIC %run "./raw_to_unharm_reader"

# COMMAND ----------

# MAGIC %run "./raw_to_unharm_processor"

# COMMAND ----------

# MAGIC %run "./scd_type1_writer"

# COMMAND ----------

# MAGIC %run "./no_scd_writer"

# COMMAND ----------

# MAGIC %run "./scd_type2_writer"
