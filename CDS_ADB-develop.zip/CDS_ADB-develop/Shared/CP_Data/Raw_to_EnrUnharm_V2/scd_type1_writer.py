# Databricks notebook source
# DBTITLE 1,Construct where clause for merge operation
def where_clause_for_merge_scd1(primary_keys_list):
    try:  
      delta_data_alias = "delta_data_alias" 
      unharm_data_alias = "unharm_data_alias" 
      deltakeys_list = [] 
      for col in primary_keys_list: 
        deltakeys_list.append(unharm_data_alias +"."+col+" = "+delta_data_alias+"."+col)
      deltakeys = " AND ".join(deltakeys_list)
      deltakeys_matched = deltakeys+ "and unharm_data_alias.IS_RECORD_ACTIVE = delta_data_alias.IS_RECORD_ACTIVE and unharm_data_alias.ACTIVE_INDICATOR = delta_data_alias.ACTIVE_INDICATOR and unharm_data_alias.IS_RECORD_ACTIVE = 1 and unharm_data_alias.ACTIVE_INDICATOR = 'Y'" 
       
    except Exception as e:  
      raise Exception(e)  
    return deltakeys_matched

# COMMAND ----------

# DBTITLE 1,Set column values for update active record to inactive
def set_col_value_for_update_when_matched_scd1(startTime,delta_df_base_columnList,unharm_data_alias):
  import pyspark.sql.functions as sf 
  
  dict_delta_matched_update_history = {};   
  dict_delta_matched_update_history['META_ACTION_CD']=sf.lit('U')
  dict_delta_matched_update_history['META_CHANGED_DTTM']=sf.lit(startTime).cast(TimestampType())
  for column in delta_df_base_columnList:
    if column not in['META_ACTION_CD','META_CHANGED_DTTM']:
      dict_delta_matched_update_history[column] = unharm_data_alias+"."+column
  return dict_delta_matched_update_history


# COMMAND ----------

# DBTITLE 1,Set column values for inserting new active records
def set_col_value_for_insert_when_not_matched_scd1(delta_df_base_columnList,delta_data_alias,default_termination_date): 
  import pyspark.sql.functions as sf  
  startTime = datetime.datetime.now().strftime(tableTimeFormat)
  dict_delta_not_matched_insert = {};   
  dict_delta_not_matched_insert['META_CHANGED_DTTM']=sf.lit(startTime).cast(TimestampType())
  dict_delta_not_matched_insert['VERSION_EFFECTIVE_DATE']=sf.lit(startTime).cast(TimestampType())
  dict_delta_not_matched_insert['EFFECTIVE_START_DATE']=sf.lit(startTime).cast(TimestampType())
  dict_delta_not_matched_insert['VERSION_TERMINATION_DATE']=sf.lit(default_termination_date)
  dict_delta_not_matched_insert['EFFECTIVE_END_DATE']=sf.lit(default_termination_date) 
  for column in delta_df_base_columnList:
    if column not in['META_CHANGED_DTTM','VERSION_EFFECTIVE_DATE','EFFECTIVE_START_DATE','VERSION_TERMINATION_DATE','EFFECTIVE_END_DATE']:
      dict_delta_not_matched_insert[column] = delta_data_alias+"."+column

  
  return (dict_delta_not_matched_insert)

# COMMAND ----------

# DBTITLE 1,Merge for existing matched records with raw records
def write_to_unharm_update_scd1(delta_file_path_full,deltakeys_matched,dict_delta_matched_update_history,raw_df):
  unharm_delta = DeltaTable.forPath(spark, delta_file_path_full);
  (unharm_delta.alias("unharm_data_alias").merge(raw_df.alias("delta_data_alias"),deltakeys_matched)\
  .whenMatchedUpdate(set=dict_delta_matched_update_history)\
  .execute()
  )

# COMMAND ----------

# DBTITLE 1,Merge for Inserts (version-zero new active records )
def write_to_unharm_insert_scd1(delta_file_path_full,deltakeys_matched,dict_delta_not_matched_insert,raw_df):
  unharm_delta = DeltaTable.forPath(spark, delta_file_path_full);
  (unharm_delta.alias("unharm_data_alias").merge(raw_df.alias("delta_data_alias"),deltakeys_matched)\
  .whenNotMatchedInsert(values=dict_delta_not_matched_insert)\
  .execute()
  )

# COMMAND ----------

def write_scd_type1(primary_keys_list,raw_df,tableTimeFormat,startTime,default_termination_date,delta_file_path_full):
  #from delta.tables import *
  #from pyspark.sql.functions import *
  deltakeys_matched = where_clause_for_merge_scd1(primary_keys_list)
  dict_delta_not_matched_insert = {};
  dict_delta_matched_update_history = {};
  delta_df_base_columnList = raw_df.columns
  startTime = datetime.datetime.now().strftime(tableTimeFormat)
  unharm_data_alias ="unharm_data_alias"
  delta_data_alias = "delta_data_alias" 

  #Below dictionary is for the Update Active Record
  dict_delta_matched_update_history = set_col_value_for_update_when_matched_scd1(startTime,delta_df_base_columnList,unharm_data_alias)

  #Below dictionary is for the Insert
  dict_delta_not_matched_insert = set_col_value_for_insert_when_not_matched_scd1(delta_df_base_columnList,delta_data_alias,default_termination_date)

  try:   
    if raw_df is not None:
      write_to_unharm_update_scd1(delta_file_path_full,deltakeys_matched,dict_delta_matched_update_history,raw_df)
      write_to_unharm_insert_scd1(delta_file_path_full,deltakeys_matched,dict_delta_not_matched_insert,raw_df)      
  except Exception as e:
    print(str(e))
    raise Exception(e) 

# COMMAND ----------


