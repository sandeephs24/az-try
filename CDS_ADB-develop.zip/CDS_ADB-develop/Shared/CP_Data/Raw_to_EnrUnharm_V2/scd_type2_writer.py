# Databricks notebook source
# DBTITLE 1,Construct where clause for merge operation
def where_clause_for_merge_scd2(primary_keys_list):
    try:  
      delta_data_alias = "delta_data_alias" 
      unharm_data_alias = "unharm_data_alias" 
      deltakeys_list = [] 
      for col in primary_keys_list: 
        deltakeys_list.append(unharm_data_alias +"."+col+" = "+delta_data_alias+"."+col)
      deltakeys = " AND ".join(deltakeys_list)
      deltakeys_matched = deltakeys+ " and unharm_data_alias.IS_RECORD_ACTIVE = delta_data_alias.IS_RECORD_ACTIVE and unharm_data_alias.ACTIVE_INDICATOR = delta_data_alias.ACTIVE_INDICATOR and unharm_data_alias.IS_RECORD_ACTIVE = 1 and unharm_data_alias.ACTIVE_INDICATOR = 'Y'" 
       
    except Exception as e:  
      raise Exception(e)  
    return deltakeys_matched

# COMMAND ----------

# DBTITLE 1,Set column values for update active record to inactive
def set_col_value_for_update_when_matched_scd2(startTime,unharm_data_alias):
  
  import pyspark.sql.functions as sf 
  print(startTime)
  dict_delta_matched_update_history = {};   
  dict_delta_matched_update_history['META_ACTION_CD']=sf.lit('U')
  dict_delta_matched_update_history['META_CHANGED_DTTM']=sf.lit(startTime).cast(TimestampType())
  dict_delta_matched_update_history['VERSION_TERMINATION_DATE']=sf.lit(startTime).cast(TimestampType())
  dict_delta_matched_update_history['ACTIVE_INDICATOR']=sf.lit('N')
  dict_delta_matched_update_history['EFFECTIVE_END_DATE']=sf.lit(startTime).cast(TimestampType())
  dict_delta_matched_update_history['IS_RECORD_ACTIVE']=sf.lit(0)
  #TBD with Dinesh do we need updating existing columns
  #for column in delta_df_base_columnList:
    #if column not in['META_ACTION_CD','META_CHANGED_DTTM','VERSION_TERMINATION_DATE','ACTIVE_INDICATOR','EFFECTIVE_END_DATE','IS_RECORD_ACTIVE']:
    #  dict_delta_matched_update_history[column] = unharm_data_alias+"."+column
  return dict_delta_matched_update_history


# COMMAND ----------

# DBTITLE 1,Set column values for inserting new active records
def set_col_value_for_insert_when_not_matched_scd2(delta_df_base_columnList,delta_data_alias,default_termination_date, startTime): 
  import pyspark.sql.functions as sf  
  dict_delta_not_matched_insert = {};   
  dict_delta_not_matched_insert['META_CHANGED_DTTM']=sf.lit(startTime).cast(TimestampType())
  dict_delta_not_matched_insert['META_CREATED_DTTM']=sf.lit(startTime).cast(TimestampType())
  dict_delta_not_matched_insert['VERSION_EFFECTIVE_DATE']=sf.lit(startTime).cast(TimestampType())
  dict_delta_not_matched_insert['EFFECTIVE_START_DATE']=sf.lit(startTime).cast(TimestampType())
  dict_delta_not_matched_insert['VERSION_TERMINATION_DATE']=sf.lit(default_termination_date)
  dict_delta_not_matched_insert['EFFECTIVE_END_DATE']=sf.lit(default_termination_date)
  
   
  for column in delta_df_base_columnList:
    if column not in['META_CHANGED_DTTM','VERSION_EFFECTIVE_DATE','EFFECTIVE_START_DATE','VERSION_TERMINATION_DATE','EFFECTIVE_END_DATE','META_CREATED_DTTM']:
      dict_delta_not_matched_insert[column] = delta_data_alias+"."+column

  
  return (dict_delta_not_matched_insert)

# COMMAND ----------

# DBTITLE 1,Merge for updates (active to inactive records)
def write_to_unharm_update_scd2(delta_file_path_full,deltakeys_matched,dict_delta_matched_update_history,raw_df):
  from delta.tables import DeltaTable
  unharm_delta = DeltaTable.forPath(spark, delta_file_path_full);
  (unharm_delta.alias("unharm_data_alias").merge(raw_df.alias("delta_data_alias"),deltakeys_matched)\
  .whenMatchedUpdate(set=dict_delta_matched_update_history)\
  .execute()
  )

# COMMAND ----------

# DBTITLE 1,Merge for Inserts (version-zero active records for existing and new)
def write_to_unharm_insert_scd2(delta_file_path_full,deltakeys_matched,dict_delta_not_matched_insert,raw_df):
  from delta.tables import DeltaTable
  unharm_delta = DeltaTable.forPath(spark, delta_file_path_full);
  (unharm_delta.alias("unharm_data_alias").merge(raw_df.alias("delta_data_alias"),deltakeys_matched)\
  .whenNotMatchedInsert(values=dict_delta_not_matched_insert)\
  .execute()
  )

# COMMAND ----------

def first_time_write(raw_df,delta_file_path_full):
  raw_df.write.format("delta").mode("overwrite").save(delta_file_path_full)

# COMMAND ----------

def append_inactive_duplicate_records(all_inactive_raw_df,delta_file_path_full):
  if (all_inactive_raw_df.count() > 0):
    all_inactive_raw_df.write.format("delta").mode("append").save(delta_file_path_full)

# COMMAND ----------

def drop_columns_from_raw_which_are_not_in_unharm(raw_df, delta_df_base_columnList):
  #case 1: raw upper delta upper
  #case 2: raw upper delta lower
  #case 3: raw lower delta upper
  #case 4: raw lower delta lower
  delta_df_base_columnList_lower = [item.lower() for item in delta_df_base_columnList]
  raw_col_list = raw_df.columns
  colPresentInRawButNotInUnharm = [x for x in raw_col_list if x.lower() not in delta_df_base_columnList_lower]

  print('colPresentInRawButNotInUnharm')
  print(colPresentInRawButNotInUnharm)

  if len(colPresentInRawButNotInUnharm) > 0: 
    print('dropping additional columns')
    raw_df = raw_df.drop(*colPresentInRawButNotInUnharm)

  return raw_df   

# COMMAND ----------

def write_scd_type2_scd2(primary_keys_list,raw_df,tableTimeFormat,startTime,default_termination_date,delta_file_path_full):
  
  deltakeys_matched = where_clause_for_merge_scd2(primary_keys_list)
  dict_delta_not_matched_insert = {};
  dict_delta_matched_update_history = {};
  
  if len(delta_file_path_full) > 0 and CheckPathExists(delta_file_path_full) == True:
    unharm_df = spark.read.format("delta").load(delta_file_path_full) 
    delta_df_base_columnList = unharm_df.columns
    raw_df = drop_columns_from_raw_which_are_not_in_unharm(raw_df, delta_df_base_columnList)
  else:
    delta_df_base_columnList = raw_df.columns

  
  unharm_data_alias ="unharm_data_alias"
  delta_data_alias = "delta_data_alias" 

  #Below dictionary is for the Update Active Record
  dict_delta_matched_update_history = set_col_value_for_update_when_matched_scd2(startTime,unharm_data_alias)

  #Below dictionary is for the Insert
  dict_delta_not_matched_insert = set_col_value_for_insert_when_not_matched_scd2(delta_df_base_columnList,delta_data_alias,default_termination_date, startTime)
  order_by_column_list = [meta_created_dttm_column]
  
  
  try:   
    
      
    raw_df = update_duplicate_records_to_inactive_in_raw_df(raw_df, primary_keys_list, order_by_column_list, startTime)
    
    
    all_active_raw_df = raw_df.filter(raw_df.ACTIVE_INDICATOR == "Y")
    all_inactive_raw_df = raw_df.filter(raw_df.ACTIVE_INDICATOR == "N")

    if len(delta_file_path_full) > 0 and CheckPathExists(delta_file_path_full) == True: 
      write_to_unharm_update_scd2(delta_file_path_full,deltakeys_matched,dict_delta_matched_update_history,all_active_raw_df)
      write_to_unharm_insert_scd2(delta_file_path_full,deltakeys_matched,dict_delta_not_matched_insert,all_active_raw_df)
    else:
      first_time_write(all_active_raw_df,delta_file_path_full)

    append_inactive_duplicate_records(all_inactive_raw_df,delta_file_path_full)

  except Exception as e:
    print(str(e))
    raise Exception(e) 

# COMMAND ----------

def update_duplicate_records_to_inactive_in_raw_df(df_raw, unique_columns_identifier_list, order_by_column_list, startTime):
  from pyspark.sql.window import Window
  import pyspark.sql.functions as sf

  df_raw = df_raw.withColumn(row_number_column, sf.row_number().over(Window.partitionBy(*unique_columns_identifier_list).orderBy(desc(*order_by_column_list))))

  df_raw = df_raw.withColumn(scd_column_valid_to, 
                          sf.when(
                            (col(row_number_column) > 1) 
                            , lit(startTime).cast(TimestampType()).alias(scd_column_valid_to)
                          )
                          .otherwise(col(scd_column_valid_to))
                        )\
                      .withColumn(scd_column_active, 
                          sf.when(
                            (col(row_number_column) > 1) 
                            , lit(0)
                          )
                          .otherwise(col(scd_column_active))
                        ).withColumn(meta_version_termination_date, 
                          sf.when(
                            (col(row_number_column) > 1)
                            , lit(startTime).cast(TimestampType()).alias(meta_version_termination_date)
                          )
                          .otherwise(col(meta_version_termination_date))
                        )\
                      .withColumn(meta_changed_dttm, 
                          sf.when(
                            (col(row_number_column) > 1)
                            , lit(startTime).cast(TimestampType()).alias(meta_changed_dttm)
                          )
                          .otherwise(col(meta_changed_dttm))
                        )\
                      .withColumn(meta_action_cd, 
                          sf.when(
                            (col(row_number_column) > 1) 
                            , lit('U')
                          )
                          .otherwise(col(meta_action_cd ))
                        )\
                      .withColumn(meta_active_indicator, 
                          sf.when(
                            (col(row_number_column) > 1)
                            , lit('N')
                          )
                          .otherwise(col(meta_active_indicator ))                                    
                        );  
  
  df_raw = df_raw.drop(row_number_column)
 
  return df_raw

# COMMAND ----------

def getWriteCount(delta_file_path_full, startTime):
  unharm_df = spark.read.format("delta").load(delta_file_path_full) 
  startTimeTC = sf.lit(startTime).cast(TimestampType())
  writeCount = unharm_df.filter((unharm_df.META_CREATED_DTTM == startTimeTC) & (unharm_df.META_ACTION_CD == "I")).count()
  return writeCount
