# Databricks notebook source
from datetime import datetime
current_dateTime_start = datetime.now()
print(current_dateTime_start)

# COMMAND ----------

# MAGIC %run "./all_imports"

# COMMAND ----------

# DBTITLE 1,Create widgets
try:
  
    dbutils.widgets.text('project_id', '', 'Project ID');
    dbutils.widgets.text('source_id', '', 'Source ID');
    dbutils.widgets.text('dataset', '', 'Dataset');
    dbutils.widgets.text('primary_keys', '', 'Primary keys');
    dbutils.widgets.text('delta_file_path', '', 'Delta File Path');
    dbutils.widgets.text('delta_file_name', '', 'Delta File Name');
    dbutils.widgets.text('raw_file_path', '', 'RAW File Path');
    dbutils.widgets.text('raw_file_name', '', 'RAW File Name');
    dbutils.widgets.text('data_hub', '', 'Data Hub');
    dbutils.widgets.text('load_type', '', 'Load Type');
    dbutils.widgets.text('scd_type', '', 'SCD Type');
    dbutils.widgets.text('adls_mount_base', '/mnt/ADLS/', 'ADLS Mount Base');
    dbutils.widgets.text('enable_databricks_delta', '', 'Databrick DELTA Enabled?');
    dbutils.widgets.text('meta_created_dttm', '', 'Metadate Created Date');
    dbutils.widgets.text('alds_enriched_unharmonised_file_format', '', 'Enriched Unharmonised Format');
    dbutils.widgets.text('delta_key', '', 'Delta Key')
    dbutils.widgets.text('partition_by', '', 'Partition By')
    dbutils.widgets.text('dataset_datetime_format', '', 'Dataset Datetime Format')
  
except Exception as e:
  print(str(e))
  raise Exception(e)


# COMMAND ----------

# DBTITLE 1,Set spark config
spark.conf.set("spark.databricks.delta.formatCheck.enabled", "false")
spark.conf.set("spark.databricks.delta.autoMerge.enabled", "true")

# COMMAND ----------

# DBTITLE 1,Extract values from widgets
try:
  
    project_id = dbutils.widgets.get('project_id');
    source_id = dbutils.widgets.get('source_id');
    dataset = dbutils.widgets.get('dataset');
    primary_keys = dbutils.widgets.get('primary_keys');
    delta_file_path = dbutils.widgets.get('delta_file_path');
    delta_file_name = dbutils.widgets.get('delta_file_name');
    raw_file_path = dbutils.widgets.get('raw_file_path');
    raw_file_name = dbutils.widgets.get('raw_file_name');
    data_hub = dbutils.widgets.get('data_hub');
    load_type = dbutils.widgets.get('load_type');
    scd_type = dbutils.widgets.get('scd_type');
    adls_mount_base = dbutils.widgets.get('adls_mount_base');
    enable_databricks_delta = dbutils.widgets.get('enable_databricks_delta');
    meta_created_dttm = dbutils.widgets.get('meta_created_dttm');
    alds_enriched_unharmonised_file_format = dbutils.widgets.get('alds_enriched_unharmonised_file_format');
    delta_key = dbutils.widgets.get('delta_key');
    partition_by = dbutils.widgets.get('partition_by');
    dataset_datetime_format = dbutils.widgets.get('dataset_datetime_format');
    
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

# DBTITLE 1,Define Variables
try:
    
    # Set base path for ADLS mount
    adls_mount_base = '/mnt/ADLS/' if len(adls_mount_base.strip()) == 0 else adls_mount_base.strip();
    
    target_adls_layer = 'enr_unharm';
    
    #load_type = 'full' if len(load_type.strip()) == 0 else load_type.strip().lower();
    
    dataset_datetime_format = 'yyyy-MM-dd HH:mm:ss.SSSSSSS' if dataset_datetime_format is None or len(dataset_datetime_format) == 0 else dataset_datetime_format;
    
    #delta_key = 'META_CREATED_DTTM' if len(delta_key.strip()) == 0 else delta_key.strip();
    delta_key = delta_key.strip()
    
    
    # Set SCD type
    scd_type = 'scd_2' if len(scd_type.strip()) == 0 else scd_type.lower().strip()
    print(scd_type)    
       
    # Generate primary key list
    primary_keys_list = strip_convert_string_to_list(primary_keys)    

    if len(primary_keys_list) == 0:
        primary_keys_list = [meta_lineage_key_hash]

    # Set default dataframes to NULL
    raw_df = None;
    delta_df = None;
    merged_df = None;
    
    # Change this to dataset
    # Autogenerate DELTA file name from RAW file name - if not supplied as parameter
    if len(delta_file_name) == 0:
        delta_file_name_list = raw_file_name.split('_')
        del delta_file_name_list[-1]
        delta_file_name = '_'.join(delta_file_name_list) + '.parquet'
    
    # Generate RAW file full path and extension
    raw_file_path_full = construct_raw_file_path(adls_mount_base,raw_file_path,raw_file_name)
        
    print(raw_file_path_full)
    # Generate DELTA file full path
    delta_file_path_full = construct_delta_file_path (adls_mount_base,delta_file_path,delta_file_name)
        
    # check temp log for delta folder exsits using path
    delta_temp_log = delta_file_path_full + '/_delta_log'
    
    raw_df_columns_list = []
    startTime = datetime.datetime.now().strftime(tableTimeFormat)
    print(startTime)
  
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

# DBTITLE 1,Read from raw
raw_df = read_from_raw(raw_file_path_full)  

# COMMAND ----------

readCount = 0
if raw_df is not None:
  readCount = raw_df.count()
  raw_df = processor_append_scd_columns(raw_df,default_termination_date,startTime,default_effective_end_date)
  raw_df = processor_alter_based_on_dataset_config_columns(raw_df,project_id, source_id,dataset,target_adls_layer)

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,writer function orchestration
if raw_df is not None:
  if scd_type == 'no_scd':
    write_no_scd(alds_enriched_unharmonised_file_format,raw_df,delta_file_path_full,delta_temp_log)
  elif scd_type == 'scd_1':
    write_scd_type1(primary_keys_list,raw_df,tableTimeFormat,startTime,default_termination_date,delta_file_path_full)
  elif scd_type == 'scd_2':
    write_scd_type2_scd2(primary_keys_list,raw_df,tableTimeFormat,startTime,default_termination_date,delta_file_path_full)  

# COMMAND ----------

writeCount = getWriteCount(delta_file_path_full, startTime)

# COMMAND ----------

from datetime import datetime

current_dateTime_start = datetime.now()
print(current_dateTime_start)

# COMMAND ----------

metricLogDict = {}
json_metricLogDict = json.dumps(metricLogDict, indent = 4)
dbutils.notebook.exit(json.dumps({'status': 'Succeeded', 'ReadCount': readCount, 'WriteCount': writeCount, 'Message': successMessage, 'metricLogJson':json_metricLogDict}))
