# Databricks notebook source
def processor_append_scd_columns(raw_df,default_termination_date,startTime,default_effective_end_date):

    raw_df_columns_list = raw_df.columns;
    # Append SCD columns
    if scd_column_valid_from not in raw_df_columns_list:
        raw_df = raw_df.withColumn(scd_column_valid_from, lit(startTime).cast(TimestampType()));
    if scd_column_valid_to not in raw_df_columns_list:
        raw_df = raw_df.withColumn(scd_column_valid_to, lit(default_effective_end_date).cast(TimestampType()));
    if scd_column_active not in raw_df_columns_list:
        raw_df = raw_df.withColumn(scd_column_active, lit(1));

    # Add values of Metadata columns derived at 
    if meta_action_cd in raw_df_columns_list:
        raw_df = raw_df.withColumn(meta_action_cd, lit('I'));
    #if meta_record_entry_dttm in raw_df_columns_list:
        #raw_df = raw_df.withColumn(meta_record_entry_dttm , lit(meta_record_entry_dttm).cast(TimestampType())); 
    if meta_changed_dttm in raw_df_columns_list:
        raw_df = raw_df.withColumn(meta_changed_dttm, lit(startTime).cast(TimestampType())); 
    
    if meta_created_dttm_column in raw_df_columns_list:
        raw_df = raw_df.withColumn(meta_created_dttm_column, lit(startTime).cast(TimestampType())); 
        
    if meta_changed_by_nm in raw_df_columns_list:
        raw_df = raw_df.withColumn(meta_changed_by_nm, lit('raw_to_enriched_unharmonised'));    
    # duplicate record ind not implemented.  Default value supplied    
    if meta_duplicate_record_ind in raw_df_columns_list:
        raw_df = raw_df.withColumn(meta_duplicate_record_ind, lit('N'));
    if meta_deleted_ind in raw_df_columns_list:
        raw_df = raw_df.withColumn(meta_deleted_ind, lit('N'));
    if meta_version_effective_date in raw_df_columns_list:
        raw_df = raw_df.withColumn(meta_version_effective_date, lit(startTime).cast(TimestampType())); 
    if meta_version_termination_date in raw_df_columns_list:
        raw_df = raw_df.withColumn(meta_version_termination_date, lit(default_termination_date).cast(TimestampType()));  
    if meta_active_indicator in raw_df_columns_list:
        raw_df = raw_df.withColumn(meta_active_indicator, lit('Y'));
    return raw_df

# COMMAND ----------

def processor_alter_based_on_dataset_config_columns(raw_df,project_id, source_id,dataset,target_adls_layer):
  
  config_dataset_columns_df = LoadDatasetColumnAttributes(project_id, source_id, dataset);
  config_dataset_columns_dict = ConvertDatasetColumnsDFtoDict(config_dataset_columns_df);
  raw_df = ConvertDatatypesInDataframe(target_adls_layer, raw_df, config_dataset_columns_dict);  
  return raw_df

# COMMAND ----------


