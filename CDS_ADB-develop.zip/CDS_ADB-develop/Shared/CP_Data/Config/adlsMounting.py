# Databricks notebook source
######Pre-requsites
# 1. Databricks instance should have Databricks scope configured with Azure Keyvault.
# 2. Azure Keyvault should have three keys
#   spn-id  - SPN ID
#   spn-key - Secret for the SPN ID
#   TenantId - Azure Tenant ID
# 3. SPN should have minimum read access on the Gen2 Account

# COMMAND ----------

# DBTITLE 1,Capturing Inputs

try:
    dbutils.widgets.text('adlsAccountName', '', 'ADLS Account Name');
    dbutils.widgets.text('adlsContainerName', '', 'ADLS Container Name');
    dbutils.widgets.text('adlsFolderName', '/', 'ADLS Folder Name');
    dbutils.widgets.text('mountPoint', '', 'Gen2 Mount Point');
    dbutils.widgets.text('databricksScopeName', '', 'Databricks Scope Name');
    dbutils.widgets.dropdown("mountOption", "Mount", ["Mount", "UnMount"])

except Exception as e:
    print(str(e))
    raise Exception(e)

# COMMAND ----------

# DBTITLE 1,Variable assignment from the Inputs
try:
    adlsAccountName = dbutils.widgets.get('adlsAccountName');
    adlsContainerName = dbutils.widgets.get('adlsContainerName');
    adlsFolderName = dbutils.widgets.get('adlsFolderName');
    mountPoint = dbutils.widgets.get('mountPoint');
    mountOption = dbutils.widgets.get('mountOption');
    databricksScopeName = dbutils.widgets.get('databricksScopeName');
except Exception as e:
    print(str(e))
    raise Exception(e)

# COMMAND ----------

#     "dfs.adls.oauth2.client.id": "64955b2c-18ea-4e34-a958-293f622b4a22",
#     "dfs.adls.oauth2.credential": "hVt8Q~Iqvbe_QyOTpCibsq2GxhRacpAcy51alc9v",
#     "dfs.adls.oauth2.refresh.url": "https://login.microsoftonline.com/db1e96a8-a3da-442a-930b-235cac24cd5c/oauth2/token"}

# COMMAND ----------

# DBTITLE 1,Input verification
print(adlsAccountName)
print(adlsContainerName)
print(adlsFolderName)
print(mountPoint)
print(mountOption)
print(databricksScopeName)

# COMMAND ----------

# DBTITLE 1,Retrieving credentials from Keyvault and setting up configs
import os
# Application (Client) ID
applicationId = os.environ.get("ADLS_CLIENT_ID") #"64955b2c-18ea-4e34-a958-293f622b4a22"
 
# Application (Client) Secret Key
# CDSDatabricksDWHScopeDev
authenticationKey = dbutils.secrets.get(scope = os.environ.get("SCOPE_NAME"), key = os.environ.get("ADLS_KEY")) #"hVt8Q~Iqvbe_QyOTpCibsq2GxhRacpAcy51alc9v"
 
# Directory (Tenant) ID
tenandId = "db1e96a8-a3da-442a-930b-235cac24cd5c"
 
endpoint = "https://login.microsoftonline.com/" + tenandId + "/oauth2/token"
source = "abfss://" + adlsContainerName + "@" + adlsAccountName + ".dfs.core.windows.net/" + adlsFolderName 
 
# Connecting using Service Principal secrets and OAuth
configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": applicationId,
           "fs.azure.account.oauth2.client.secret": authenticationKey,
           "fs.azure.account.oauth2.client.endpoint": endpoint}

# COMMAND ----------

# DBTITLE 1,Mount or Unmount based on the input
# Mount ADLS Storage to DBFS only if the directory is not already mounted
if mountOption == "Mount" and  not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
        dbutils.fs.mount(
        source = source,
        mount_point = mountPoint,
        extra_configs = configs)
        print("Mounted ", mountPoint );
        print("Current listing from the mount...");
        dbutils.fs.ls(mountPoint);
        
elif mountOption == "UnMount" and any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
    dbutils.fs.unmount(mountPoint)
print("Available mounts.. ")
dbutils.fs.mounts()

# COMMAND ----------

#dbutils.fs.mounts()
dbutils.fs.ls('/mnt/ADLS/')
