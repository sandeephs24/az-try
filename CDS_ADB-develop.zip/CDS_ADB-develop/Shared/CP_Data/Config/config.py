# Databricks notebook source
#Harmonized SQLDB Connection
import os
scopeName = os.environ.get("SCOPE_NAME")  
dbDatabase = os.environ.get("DB_DATABASE")
dbServer = os.environ.get("DB_SERVER")
dbUser = os.environ.get("DB_USER")
dbPass = dbutils.secrets.get(scope = scopeName, key = "cpdata-sqldb-adb")
dbJdbcPort = "1433"
dbJdbcExtraOptions = "encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
Stratos_sqldb_URL = "jdbc:sqlserver://" + dbServer + ":" + dbJdbcPort + ";database=" + dbDatabase + ";user=" + dbUser+";password=" + dbPass

# COMMAND ----------

# Commented as this is no longer required.
# #Curated SQLDB Connection - Uses same login account as above 
# dbDatabase_curated = os.environ.get("DB_DATABASE_CURATED")
# dbServer_curated = os.environ.get("DB_SERVER_CURATED")
# Stratos_sqldb_URL_curated = "jdbc:sqlserver://" + dbServer_curated + ":" + dbJdbcPort + ";database=" + dbDatabase_curated + ";user=" + dbUser+";password=" + dbPass

# COMMAND ----------

# Commented as this is no longer required.
# #SQLDW Connection
# dwhDatabase = os.environ.get("DWH_DATABASE")
# dwhServer = os.environ.get("DWH_SERVER")
# dwhUser = os.environ.get("DB_USER")
# dwhPass = dbutils.secrets.get(scope = scopeName, key = "cpdata-sqldwh-adb")
# dwhJdbcPort = "1433"
# dwhJdbcExtraOptions = "encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
# Stratos_sqldwh_URL = "jdbc:sqlserver://" + dwhServer + ":" + dwhJdbcPort + ";database=" + dwhDatabase + ";user=" + dwhUser+";password=" + dwhPass

# dwhExternalTableDataSource = dwhUser = os.environ.get("DWH_EXTERNAL_TABLE_DATASOURCE")
# dwhExternalTableFileFormat = 'parquet_format'

# COMMAND ----------

#ADLS Connection - Configs
adlsClientId = os.environ.get("ADLS_CLIENT_ID")
adlsKey = os.environ.get("ADLS_KEY")

configs = {"dfs.adls.oauth2.access.token.provider.type": "ClientCredential",
           "dfs.adls.oauth2.client.id": adlsClientId,
           "dfs.adls.oauth2.credential": dbutils.secrets.get(scope = scopeName, key = adlsKey),
           "dfs.adls.oauth2.refresh.url": "https://login.microsoftonline.com/db1e96a8-a3da-442a-930b-235cac24cd5c/oauth2/token"}

# COMMAND ----------

# Function to mount ADLS
def mount_ADLS():
  dbutils.fs.mount(
  source = "adl://shell01eunadls2lserrccrn.azuredatalakestore.net/",
  mount_point = "/mnt/ADLS/",
  extra_configs = configs)

#mount_ADLS()

# COMMAND ----------

#mount_ADLS()

# COMMAND ----------

dbutils.fs.ls("/mnt/ADLS/PROJECT/")

# COMMAND ----------

#dbutils.fs.unmount("/mnt/ADLS/")

# COMMAND ----------

from pyspark.sql import SparkSession
spark = SparkSession.builder.appName('ops').getOrCreate()

def rename_file(origin_path, dest_path, file_type, new_name):
  filelist = dbutils.fs.ls(origin_path)#list all files from origin path
  filtered_filelist = [x.name for x in filelist if x.name.endswith("."+file_type)]#keep names of the files that match the type requested
  if len(filtered_filelist) > 1:#check if we have more than 1 files of that type
    print("Too many "+file_type+" files. You will need a different implementation")
  elif len(filtered_filelist) == 0: #check if there are no files of that type
    print("No "+file_type+" files found")
  else:
    new_name = new_name.replace("."+file_type, "")
    dbutils.fs.mv(origin_path+"/"+filtered_filelist[0], dest_path+"/"+new_name+"."+file_type)#move the file to a new path (can be the same) changing the name in the process
