# Databricks notebook source
# MAGIC %run "/Shared/CP_Data/Config/config"

# COMMAND ----------

# DBTITLE 1,Execute Main Notebook
# MAGIC %run "/Shared/CP_Data/Shared_script/main"

# COMMAND ----------

# MAGIC %run "./SplitUnharmDataFunctions"

# COMMAND ----------

# DBTITLE 1,Create widgets
try:
  
    dbutils.widgets.text('project_id', '', 'Project ID');
    dbutils.widgets.text('source_id', '', 'Source ID');
    dbutils.widgets.text('dataset', '', 'Dataset');
    dbutils.widgets.text('primary_keys', '', 'Primary keys');
    dbutils.widgets.text('delta_file_path', '', 'Delta File Path');
    dbutils.widgets.text('delta_file_name', '', 'Delta File Name');
    dbutils.widgets.text('raw_file_path', '', 'RAW File Path');
    dbutils.widgets.text('raw_file_name', '', 'RAW File Name');
    dbutils.widgets.text('data_hub', '', 'Data Hub');
    dbutils.widgets.text('load_type', '', 'Load Type');
    dbutils.widgets.text('scd_type', '', 'SCD Type');
    dbutils.widgets.text('adls_mount_base', '/mnt/ADLS/', 'ADLS Mount Base');
    dbutils.widgets.text('enable_databricks_delta', '', 'Databrick DELTA Enabled?');
    dbutils.widgets.text('meta_created_dttm', '', 'Metadate Created Date');
    dbutils.widgets.text('alds_enriched_unharmonised_file_format', '', 'Enriched Unharmonised Format');
    dbutils.widgets.text('delta_key', '', 'Delta Key')
    dbutils.widgets.text('partition_by', '', 'Partition By')
    dbutils.widgets.text('dataset_datetime_format', '', 'Dataset Datetime Format')
    dbutils.widgets.text('writeRawToUnharmSplitFlag', 'N', 'Write Unharm Split Flag')
    dbutils.widgets.text('writeRawToUnharmSplitConfig', '', 'Write Unharm Split Parition')
    
  
except Exception as e:
  print(str(e))
  raise Exception(e)


# COMMAND ----------

spark.conf.set("spark.databricks.delta.formatCheck.enabled", "false")
spark.conf.set("spark.databricks.delta.autoMerge.enabled", "true")
#spark.conf.set("spark.databricks.delta.checkLatestSchemaOnRead", "false")
metricLogDict = {}

# COMMAND ----------

# DBTITLE 1,Extract values from widgets
try:
  
    project_id = dbutils.widgets.get('project_id');
    source_id = dbutils.widgets.get('source_id');
    dataset = dbutils.widgets.get('dataset');
    primary_keys = dbutils.widgets.get('primary_keys');
    delta_file_path = dbutils.widgets.get('delta_file_path');
    delta_file_name = dbutils.widgets.get('delta_file_name');
    raw_file_path = dbutils.widgets.get('raw_file_path');
    raw_file_name = dbutils.widgets.get('raw_file_name');
    data_hub = dbutils.widgets.get('data_hub');
    load_type = dbutils.widgets.get('load_type');
    scd_type = dbutils.widgets.get('scd_type');
    adls_mount_base = dbutils.widgets.get('adls_mount_base');
    enable_databricks_delta = dbutils.widgets.get('enable_databricks_delta');
    meta_created_dttm = dbutils.widgets.get('meta_created_dttm');
    alds_enriched_unharmonised_file_format = dbutils.widgets.get('alds_enriched_unharmonised_file_format');
    delta_key = dbutils.widgets.get('delta_key');
    partition_by = dbutils.widgets.get('partition_by');
    dataset_datetime_format = dbutils.widgets.get('dataset_datetime_format');
    writeRawToUnharmSplitFlag = dbutils.widgets.get('writeRawToUnharmSplitFlag');
    writeRawToUnharmSplitConfig = dbutils.widgets.get('writeRawToUnharmSplitConfig');

    metricLogDict['primary_keys'] = primary_keys
    metricLogDict['delta_file_path'] = delta_file_path
    metricLogDict['delta_file_name'] = delta_file_name
    metricLogDict['raw_file_path'] = raw_file_path
    metricLogDict['raw_file_name'] = raw_file_name
    metricLogDict['load_type'] = load_type
    metricLogDict['scd_type'] = scd_type
    metricLogDict['meta_created_dttm'] = meta_created_dttm
    metricLogDict['delta_key'] = delta_key
    metricLogDict['partition_by'] = partition_by
    metricLogDict['writeRawToUnharmSplitFlag'] = writeRawToUnharmSplitFlag
    metricLogDict['writeRawToUnharmSplitConfig'] = writeRawToUnharmSplitConfig
    print(metricLogDict)
    
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

if len(partition_by) > 0:
    partition_by = partition_by.split(',')
else:
    print(len(partition_by))
print(partition_by)

# COMMAND ----------

# DBTITLE 1,Define Variables
try:
    
    # Set base path for ADLS mount
    adls_mount_base = '/mnt/ADLS/' if len(adls_mount_base.strip()) == 0 else adls_mount_base.strip();
    
    target_adls_layer = 'enr_unharm';
    
    load_type = 'full' if len(load_type.strip()) == 0 else load_type.strip().lower();
    
    dataset_datetime_format = 'yyyy-MM-dd HH:mm:ss.SSSSSSS' if dataset_datetime_format is None or len(dataset_datetime_format) == 0 else dataset_datetime_format;
    
    #delta_key = 'META_CREATED_DTTM' if len(delta_key.strip()) == 0 else delta_key.strip();
    delta_key = delta_key.strip()
    
    
    # Set SCD type
    scd_type = 'scd_2' if len(scd_type.strip()) == 0 else scd_type.lower().strip()
    print(scd_type)
    
    # Set columns by which dataframe will be ordered by when perfoming UPSERT
    #scd_order_by_column_list = [scd_column_valid_from] if len(scd_order_by_column.strip()) == 0 else scd_order_by_column.split(',');
    #scd_order_by_column_list = [] if len(delta_key) == 0 else delta_key.split(',')
    scd_order_by_column_list = [meta_created_dttm_column]
    
    # Generate primary key list
    primary_keys = primary_keys.strip();
    primary_keys_list = primary_keys.split(',') if len(primary_keys) > 0 else [];
    if len(primary_keys_list) > 0:
        primary_keys_list = [primary_key.strip() for primary_key in primary_keys_list]
        for primary_key in primary_keys_list:
            primary_key = primary_key.strip()

    # Set default dataframes to NULL
    raw_df = None;
    delta_df = None;
    merged_df = None;
    
    # Change this to dataset
    # Autogenerate DELTA file name from RAW file name - if not supplied as parameter
    if len(delta_file_name) == 0:
        delta_file_name_list = raw_file_name.split('_')
        del delta_file_name_list[-1]
        delta_file_name = '_'.join(delta_file_name_list) + '.parquet'
    
    # Generate RAW file full path and extension
    raw_file_path_full = '';
    raw_file_extension = '';
    if len(raw_file_path) > 0 and len(raw_file_name) > 0:
        if raw_file_path[0] == '/': # Remove first character of file path if it is '/'
            raw_file_path = raw_file_path[1:]
        if raw_file_path[-1] != '/': # Append '/' to file path if not there
            raw_file_path = raw_file_path + '/'
        raw_file_path_full = adls_mount_base + raw_file_path + raw_file_name    
        raw_file_extension = raw_file_name.split('.')[-1]
    
    # Generate DELTA file full path
    delta_file_path_full = '';
    if len(delta_file_path) > 0 and len(delta_file_name) > 0:
        if delta_file_path[0] == '/': # Remove first character of file path if it is '/'
            delta_file_path = delta_file_path[1:]
        if delta_file_path[-1] != '/': # Append '/' to file path if not there
            delta_file_path = delta_file_path + '/'
        delta_file_path_full = adls_mount_base + delta_file_path + delta_file_name
        
    # check temp log for delta folder exsits using path
    delta_temp_log = delta_file_path_full + '/_delta_log'
    
    raw_df_columns_list = []
  
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

print(primary_keys_list)
print(startTime)
print(scd_order_by_column_list)
print(raw_file_path_full);
print(raw_file_extension);
print(CheckPathExists(raw_file_path_full));
print(delta_file_path_full);
#print(CheckPathExists(delta_file_path_full));
print(dataset_datetime_format);
metricLogDict['raw_file_path_full'] = raw_file_path_full
metricLogDict['delta_file_path_full'] = delta_file_path_full


# COMMAND ----------

#def ConvertDatatypesInDataframe(target_adls_layer, dataFrame, dataset_columns_dict):
#
#    target_adls_layer = target_adls_layer.lower();
#    
#    target_adls_layer_dataset_dict = {}
#    
#    if len(dataset_columns_dict) > 0:
#      
#        print(dataset_columns_dict);
#        
#        dataset_columns_list = dataFrame.columns;
#        
#        #for column in dataset_columns_dict:
#        for original_column_name in dataset_columns_list:
#            
#            if len(original_column_name) > 0:
#                print("=>"+original_column_name)
#                original_column_name = original_column_name.lower();
#                column = replaceSpecialCharactersInString(original_column_name, columns_special_characters_to_replace)
#                print("=>=>"+column)
#                
#                # Append metadata column - META_CREATED_DTTM
#                if column.lower() in ['meta_created_dttm', 'effective_start_date', 'effective_end_date']:                  
#                    dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(TimestampType()).alias(column))
#                
#                # Append metadata column - IS_RECORD_ACTIVE
#                elif column.lower() == 'is_record_active':                 
#                    dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(IntegerType()).alias(column))
#                    
#                elif column in dataset_columns_dict.keys() and dataset_columns_dict[column] is not None:
#                    
#                    current_record = dataset_columns_dict[column]
#                    current_record_source_datatype = current_record['source_datatype'].lower();
#                    current_record_source_data_length = current_record['source_data_length'];
#                    current_record_source_precision = current_record['source_precision'];
#              
#                    print(column + ':' + current_record_source_datatype)
#                    
#                    if current_record_source_datatype == 'int' or (current_record_source_datatype == 'number' and int(current_record_source_data_length) <= 11 and (len(current_record_source_precision) != 0 and int(current_record_source_precision) == 0 or current_record_source_precision is None)):
#                    
#                        if target_adls_layer == 'enr_unharm':              
#                            dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(IntegerType())).withColumnRenamed(original_column_name, column)
#                      
#                    elif current_record_source_datatype == 'bigint' or (current_record_source_datatype == 'number' and int(current_record_source_data_length) > 11 and (len(current_record_source_precision) != 0 and int(current_record_source_precision) == 0 or current_record_source_precision is None)):
#                    
#                        if target_adls_layer == 'enr_unharm':              
#                            dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(LongType())).withColumnRenamed(original_column_name, column)
#                      
#                    elif current_record_source_datatype == 'float' or (current_record_source_datatype == 'number' and int(current_record_source_data_length) > 1 and len(current_record_source_precision) != 0 and int(current_record_source_precision) > 1):
#                    
#                        if target_adls_layer == 'enr_unharm':              
#                            dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(DoubleType())).withColumnRenamed(original_column_name, column)
#                      
#                    elif current_record_source_datatype == 'char' or current_record_source_datatype == 'nchar' or current_record_source_datatype == 'varchar' or current_record_source_datatype == 'varchar2'or current_record_source_datatype == 'nvarchar'or current_record_source_datatype == 'nvarchar2' or current_record_source_datatype == 'string':
#                    
#                        if target_adls_layer == 'enr_unharm':              
#                            dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(StringType())).withColumnRenamed(original_column_name, column);
#                      
#                    elif current_record_source_datatype == 'date' or current_record_source_datatype == 'timestamp' or current_record_source_datatype == 'datetime' or current_record_source_datatype == 'datetime2':
#                    
#                        if target_adls_layer == 'enr_unharm':              
#                            dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].substr(1,19));  
#                            dataFrame = dataFrame.withColumn(original_column_name, from_unixtime(unix_timestamp(col(original_column_name), dataset_datetime_format)).alias(original_column_name))
#                            dataFrame = dataFrame.withColumn(original_column_name, dataFrame[original_column_name].cast(TimestampType())).withColumnRenamed(original_column_name, column);
#                            #dataFrame = dataFrame.withColumn(original_column_name, from_unixtime(unix_timestamp(dataFrame[original_column_name], 'MM/dd/yyy')).cast(TimestampType())).withColumnRenamed(original_column_name, column);
#                            # from_unixtime(unix_timestamp(
#               
#    return dataFrame;    

# COMMAND ----------

config_dataset_columns_df = LoadDatasetColumnAttributes(project_id, source_id, dataset);
display(config_dataset_columns_df)

# COMMAND ----------

# DBTITLE 1,Load new data
try:
  
    # Check if RAW file path and extension variables are not empty and RAW file exist in ADLS
    if len(raw_file_path_full) > 0 and len(raw_file_extension) > 0 and CheckPathExists(raw_file_path_full) == True:

        # If RAW file extension is parquet format
        if raw_file_extension.lower() == 'parquet':
            
            # Load data from RAW file into RAW dataframe
            raw_df = spark.read.format("parquet").load(raw_file_path_full)
            
            raw_df_ColumnList = [x for x in raw_df.columns if x not in exclusion_list]    #added 17-08-23    
            meta_lineage_key_hash_columns = raw_df_ColumnList                             #added 17-08-23
                    
            # Append SCD columns if RAW dataframe is not empty
            if raw_df is not None:
                raw_df_columns_list = raw_df.columns;
                # Append SCD columns
                if scd_column_valid_from not in raw_df_columns_list:
                    raw_df = raw_df.withColumn(scd_column_valid_from, lit(startTime).cast(TimestampType()));
                if scd_column_valid_to not in raw_df_columns_list:
                    raw_df = raw_df.withColumn(scd_column_valid_to, lit(default_effective_end_date).cast(TimestampType()));
                if scd_column_active not in raw_df_columns_list:
                    raw_df = raw_df.withColumn(scd_column_active, lit(1));

                # Add values of Metadata columns derived at 
                if meta_action_cd in raw_df_columns_list:
                    raw_df = raw_df.withColumn(meta_action_cd, lit('I'));
                #if meta_record_entry_dttm in raw_df_columns_list:
                    #raw_df = raw_df.withColumn(meta_record_entry_dttm , lit(meta_record_entry_dttm).cast(TimestampType())); 
                if meta_changed_dttm in raw_df_columns_list:
                    raw_df = raw_df.withColumn(meta_changed_dttm, lit(startTime).cast(TimestampType())); 
                if meta_changed_by_nm in raw_df_columns_list:
                    raw_df = raw_df.withColumn(meta_changed_by_nm, lit('raw_to_enriched_unharmonised'));    
                # duplicate record ind not implemented.  Default value supplied    
                if meta_duplicate_record_ind in raw_df_columns_list:
                    raw_df = raw_df.withColumn(meta_duplicate_record_ind, lit('N'));
                if meta_deleted_ind in raw_df_columns_list:
                    raw_df = raw_df.withColumn(meta_deleted_ind, lit('N'));
                if meta_version_effective_date in raw_df_columns_list:
                    raw_df = raw_df.withColumn(meta_version_effective_date, lit(startTime).cast(TimestampType())); 
                if meta_version_termination_date in raw_df_columns_list:
                    raw_df = raw_df.withColumn(meta_version_termination_date, lit(default_termination_date).cast(TimestampType()));  
                if meta_active_indicator in raw_df_columns_list:
                    raw_df = raw_df.withColumn(meta_active_indicator, lit('Y'));                         
                                                   
                readCount = raw_df.count();
            #display(raw_df);
  
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

# if raw_df is not None:
#     raw_df.printSchema();

# COMMAND ----------

config_dataset_columns_dict = ConvertDatasetColumnsDFtoDict(config_dataset_columns_df);
raw_df = ConvertDatatypesInDataframe(target_adls_layer, raw_df, config_dataset_columns_dict);


# COMMAND ----------

# DBTITLE 1,Load existing data
try:
    if IsSplitUnharmDatasetFlowApplicable(writeRawToUnharmSplitFlag, writeRawToUnharmSplitConfig):
      delta_df = readSplittedDataFromUnharmLayer(adls_mount_base, writeRawToUnharmSplitConfig, delta_file_name, alds_enriched_unharmonised_file_format, scd_type, enable_databricks_delta)  
    else:
      # Check if DELTA file path variable is not empty and DELTA file exist in ADLS
      if raw_df is not None and len(delta_file_path_full) > 0 and CheckPathExists(delta_file_path_full) == True:
  
          # Load data from DELTA file into DELTA dataframe
          if scd_type == 'no_scd' and CheckPathExists(delta_temp_log) == False:
              
              if alds_enriched_unharmonised_file_format.lower() == 'parquet':
                  delta_df = spark.read.format("parquet").load(delta_file_path_full)
          else:
              if scd_type == 'scd_1' and CheckPathExists(delta_temp_log) == False:
                delta_df = spark.read.format("parquet").load(delta_file_path_full)
              else:
                if enable_databricks_delta.lower() == 'y' or enable_databricks_delta.lower() == 'yes' or int(enable_databricks_delta) == 1:
                  delta_df = spark.read.format("delta").load(delta_file_path_full);
          
          #display(delta_df)
  
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

# DBTITLE 1,determine use of legacy or enhanced metadata
if delta_df is not None:
  if meta_lineage_key_hash in delta_df.columns: 
    if delta_df.filter(col(meta_lineage_key_hash).isNull()).count() == 0:  #all the delta_df rows has not null for key hash column  #true for new datasets day1 onwards, 
                                                                           #false for older datasets as they have null values
      print("inside 3rd if")
      enhanced_meta_flag = 1;
    else:
      print("inside 2nd if but else of 3rd if")
      print(delta_df.filter(col(meta_lineage_key_hash).isNull()).count())
      enhanced_meta_flag = 0;
  else:
    # append missing columns to delta dataframe
    for x in [x for x in raw_df.columns if x not in delta_df.columns]:
      delta_df = delta_df.withColumn(x, lit(None))
    print("inside 1st if but else of 2nd if")  
    enhanced_meta_flag = 0;
else:
  print("delta df doesn't exist")
  enhanced_meta_flag = 1;

  print("enhanced_meta_flag value " + str(enhanced_meta_flag))

# COMMAND ----------

# if delta_df is not None:
#     delta_df.printSchema()

# COMMAND ----------

# DBTITLE 1,Merge new data into existing data
try: 
  
    if raw_df is not None:
      
        print(raw_df_columns_list);
      
        # Skip UPSERT if load type is full or no existing data in DELTA
        #if load_type == 'full' or delta_df is None or len(delta_key) == 0 or primary_keys is None or primary_keys == '':
        if scd_type == 'no_scd' or delta_df is None:
            print("Running NO_SCD block......")
            merged_df = raw_df;
        else:
            print("Running SCD type " + scd_type + "......")
            # If primary keys list is empty
            # Remove meta_created_dttm column from the list of columns from RAW
            # Use all column names as primary key
            if len(primary_keys_list) == 0:
                #raw_df_columns_list.remove(meta_created_dttm_column)     #changed 01-06-23
                #primary_keys_list = raw_df_columns_list
                #primary_keys_list = [meta_lineage_key_hash]               #changed 01-06-23
                print("Empty primary key list. Generated primary keys list from all table columns below:")            
                if enhanced_meta_flag == 1:                                 #changed 07-06-23
                  print("Generating Primary Key List")
                  primary_keys_list = [meta_lineage_key_hash]               #changed 07-06-23
                  print(primary_keys_list)
                else :
                  print("Generating hash key values")
                  exclusion_list.extend([scd_column_valid_from,scd_column_valid_to,scd_column_active])
                  vColumnList = [x for x in raw_df_ColumnList if x not in exclusion_list]
                  delta_df_columns_list = [x for x in delta_df.columns if x != meta_lineage_key_hash]
                  delta_df = delta_df.select(*delta_df_columns_list, sf.sha2(sf.concat_ws("|", *vColumnList), 256).alias(meta_lineage_key_hash))

                  meta_lineage_key_hash_columns = vColumnList
                  
                  print("Generating Primary Key")
                  primary_keys_list = [meta_lineage_key_hash]
                  print(primary_keys_list)

            merged_df = UpsertData(
              existing_df = delta_df
              , new_df = raw_df
              , unique_columns_identifier_list = primary_keys_list
              , order_by_column_list = scd_order_by_column_list
              , result_order_column_list = primary_keys_list
            );
            #, order_by_column_list
            #, unique_columns_identifier_list = primary_keys_list
            #, unique_columns_identifier_list = [meta_created_dttm]

except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

metricLogDict['meta_lineage_key_hash_columns'] = meta_lineage_key_hash_columns
metricLogDict['meta_lineage_key_hash'] = meta_lineage_key_hash
metricLogDict['primary_keys_list'] = primary_keys_list
metricLogDict['enhanced_meta_flag'] = enhanced_meta_flag

# COMMAND ----------

if merged_df is not None:
  # derive dataset column list
  merged_column_list = merged_df.columns

  # append legacy metadata columns

  exclusion_extend_list = [scd_column_valid_from,scd_column_valid_to,scd_column_active];    #added line 5-8 on 03/07/2023
  for x in exclusion_extend_list:
    if x not in exclusion_list:
      exclusion_list.append(x)
  #exclusion_list.extend([scd_column_valid_from,scd_column_valid_to,scd_column_active]) #commented on 30-06-2023

  # removed all metadata from list
  merged_column_list = [x for x in merged_column_list if x.upper() not in exclusion_list]

  # append the ordered metadata
  merged_column_list.extend(exclusion_list)
  # reorder columns based on ordered column list

  merged_df = merged_df.select(merged_column_list)  

# COMMAND ----------

# if merged_df is not None:
#     merged_df.printSchema()
#     ## Convert dataframe after merge - in case data type changed
#     #merged_df = ConvertDatatypesInDataframe(target_adls_layer, merged_df, config_dataset_columns_dict);
    

# COMMAND ----------

#if merged_df is not None:
  #merged_df.show();
   #display(merged_df);

# COMMAND ----------

from pyspark.sql.functions import *
writeCount = merged_df.filter(date_format(col(meta_created_dttm_column), "yyyy-MM-dd HH:mm:ss") == lit(meta_created_dttm.split('.')[0])).count();        
print(" writeCount ", str(writeCount))


# COMMAND ----------

# DBTITLE 1,Save merged data
try:
    if IsSplitUnharmDatasetFlowApplicable(writeRawToUnharmSplitFlag, writeRawToUnharmSplitConfig):
      splitDataset(merged_df, writeRawToUnharmSplitConfig, enable_databricks_delta, alds_enriched_unharmonised_file_format,scd_type ,  delta_file_name, partition_by, adls_mount_base, metricLogDict)
    # Save merged data into DELTA lake
    else:
      if merged_df is not None:       
          print("Databricks enabled: " + enable_databricks_delta);
          print("Enriched unharmonised format: " + alds_enriched_unharmonised_file_format);
          print("SCD Type: " + scd_type);      
          # Convert dataframe after merge - in case data type changed
          #merged_df = ConvertDatatypesInDataframe(target_adls_layer, merged_df, config_dataset_columns_dict);
          
          if scd_type == 'no_scd' and CheckPathExists(delta_temp_log) == True:
            dbutils.fs.rm(delta_file_path_full, recurse = True)
          
          if scd_type == 'no_scd':
              if alds_enriched_unharmonised_file_format.lower() == 'parquet':             
                  if len(partition_by) > 0:
                    
                      merged_df.write.format(alds_enriched_unharmonised_file_format).mode("overwrite").partitionBy(partition_by).save(delta_file_path_full) 
                  else:       
                      merged_df.write.format(alds_enriched_unharmonised_file_format).mode("overwrite").save(delta_file_path_full)
          else:
          
              if enable_databricks_delta.lower() == 'y' or enable_databricks_delta.lower() == 'yes' or int(enable_databricks_delta) == 1: 
              
                  if len(partition_by) > 0:
                      merged_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").partitionBy(partition_by).save(delta_file_path_full);
                  else:
                      #merged_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(delta_file_path_full);
                      #merged_df.write.format("delta").mode("overwrite").save(delta_file_path_full);
                      merged_df.write.format("delta").mode("overwrite").option("mergeSchema", "true").save(delta_file_path_full);
          
          #if enable_databricks_delta.lower() == 'y' or enable_databricks_delta.lower() == 'yes' or int(enable_databricks_delta) == 1: 
          #  
          #    if len(partition_by) > 0:
          #        merged_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").partitionBy(partition_by).save(delta_file_path_full);
          #    else:
          #        merged_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").save(delta_file_path_full);
          #    
          #elif alds_enriched_unharmonised_file_format.lower() == 'parquet':
          #  
          #    if len(partition_by) > 0:
          #        merged_df.write.format(alds_enriched_unharmonised_file_format).mode("overwrite").partitionBy(partition_by).save(delta_file_path_full) 
          #    else:       
          #        merged_df.write.format(alds_enriched_unharmonised_file_format).mode("overwrite").save(delta_file_path_full)        

          #writeCount = merged_df.filter(meta_created_dttm_column + " = '" + meta_created_dttm + "'").count();

        
except Exception as e:
  print(str(e))
  raise Exception(e)

# COMMAND ----------

json_metricLogDict = json.dumps(metricLogDict, indent = 4)
dbutils.notebook.exit(json.dumps({'status': 'Succeeded', 'ReadCount': readCount, 'WriteCount': writeCount, 'Message': successMessage, 'metricLogJson':json_metricLogDict}))
