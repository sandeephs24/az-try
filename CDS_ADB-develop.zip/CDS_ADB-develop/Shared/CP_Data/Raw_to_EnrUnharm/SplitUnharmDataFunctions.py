# Databricks notebook source
def IsSplitUnharmDatasetFlowApplicable(writeRawToUnharmSplitFlag,writeRawToUnharmSplitConfig ):
  return writeRawToUnharmSplitFlag is not None and writeRawToUnharmSplitFlag == 'Y' and writeRawToUnharmSplitConfig is not None and len(writeRawToUnharmSplitConfig) > 0

def getDeltaFileFullPath(adls_mount_base, delta_file_path, delta_file_name):
  delta_file_path_full = '';
  if len(delta_file_path) > 0 and len(delta_file_name) > 0:
    if delta_file_path[0] == '/': # Remove first character of file path if it is '/'
        delta_file_path = delta_file_path[1:]
    if delta_file_path[-1] != '/': # Append '/' to file path if not there
        delta_file_path = delta_file_path + '/'
    delta_file_path_full = adls_mount_base + delta_file_path + delta_file_name
  return delta_file_path_full      
     
def readSplittedDataFromUnharmLayer(mountADLSPath, writeRawToUnharmSplitConfig, delta_file_name, alds_enriched_unharmonised_file_format, scd_type, enable_databricks_delta):

  writeRawToUnharmSplitConfigArray=writeRawToUnharmSplitConfig.split('#')
  mergedUnionDF = spark.createDataFrame(data = [],schema = StructType([]))
  counter = 1
  counterLog = 1
  for x in writeRawToUnharmSplitConfigArray:
    QueryFilter = x.split('|')[0]
    FolderPath = x.split('|')[1]
    print(QueryFilter)
    print(FolderPath)
    delta_file_path_full = getDeltaFileFullPath(mountADLSPath, FolderPath, delta_file_name)
    delta_temp_log = delta_file_path_full + '/_delta_log'
    print(delta_file_path_full)
    print(delta_temp_log)
    delta_df = readSingleDatasetFromUnharmLayer(delta_file_path_full, delta_temp_log, alds_enriched_unharmonised_file_format,scd_type, enable_databricks_delta )
    if (len(delta_df.take(1)) > 0):
      print("IN Read......")
      print(delta_df.count())
      if counter == 1:
        mergedUnionDF = delta_df
      else:  
        mergedUnionDF = mergedUnionDF.union(delta_df)
      
      counter = counter + 1
    
    metricLogDict['split_read_unharm_filter'+str(counterLog)] = QueryFilter
    metricLogDict['split_read_unharm_path'+str(counterLog)] = delta_file_path_full
    metricLogDict['split_read_unharm_count'+str(counterLog)] = delta_df.count()
    counterLog = counterLog + 1
    
  print("IN Read Total......")
  print(mergedUnionDF.count())
  if (mergedUnionDF.count() == 0):
    mergedUnionDF = None
    
  return mergedUnionDF


def readSingleDatasetFromUnharmLayer(delta_file_path_full, delta_temp_log, alds_enriched_unharmonised_file_format, scd_type, enable_databricks_delta):
  
  delta_df = spark.createDataFrame(data = [],schema = StructType([]))
  print("delta_file_path_full")
  print(delta_file_path_full)
  print("delta_temp_log")
  print(delta_temp_log)
  
  if len(delta_file_path_full) > 0 and CheckPathExists(delta_file_path_full) == True:
          if scd_type == 'no_scd' and CheckPathExists(delta_temp_log) == False:
              if alds_enriched_unharmonised_file_format.lower() == 'parquet':
                  delta_df = spark.read.format("parquet").load(delta_file_path_full)
          else:
              if scd_type == 'scd_1' and CheckPathExists(delta_temp_log) == False:
                delta_df = spark.read.format("parquet").load(delta_file_path_full)
              else:
                if enable_databricks_delta.lower() == 'y' or enable_databricks_delta.lower() == 'yes' or int(enable_databricks_delta) == 1:
                  delta_df = spark.read.format("delta").load(delta_file_path_full);  

  return delta_df
  
def splitDataset(mainDf, writeRawToUnharmSplitConfig, enable_databricks_delta, alds_enriched_unharmonised_file_format,scd_type ,  delta_file_name, partition_by, mountADLSPath, metricLogDict):
  writeRawToUnharmSplitConfigArray=writeRawToUnharmSplitConfig.split('#')
  print("Total records.....")
  print(mainDf.count())
  counter = 1
  for x in writeRawToUnharmSplitConfigArray:
    QueryFilter = x.split('|')[0]
    FolderPath = x.split('|')[1]
    print(QueryFilter)
    print(FolderPath)
    mainDf.createOrReplaceTempView('df_full')
    df_filtered = sqlContext.sql("select * from df_full " + QueryFilter)
    delta_file_path_full = getDeltaFileFullPath(mountADLSPath, FolderPath, delta_file_name)
    delta_temp_log = delta_file_path_full + '/_delta_log'
    print("writing to following path ..........")
    print(delta_file_path_full)
    print(delta_temp_log)
    print(df_filtered.count())
    metricLogDict['split_write_unharm_filter'+str(counter)] = QueryFilter
    metricLogDict['split_write_unharm_path'+str(counter)] = delta_file_path_full
    metricLogDict['split_write_unharm_count'+str(counter)] = df_filtered.count()
    counter = counter + 1
    
    writeSingleDataset(df_filtered, enable_databricks_delta, alds_enriched_unharmonised_file_format,scd_type , delta_temp_log, delta_file_path_full, partition_by)

  
  

def writeSingleDataset(merged_df, enable_databricks_delta, alds_enriched_unharmonised_file_format,scd_type , delta_temp_log, delta_file_path_full, partition_by):
  if merged_df is not None:       
          print("Databricks enabled: " + enable_databricks_delta);
          print("Enriched unharmonised format: " + alds_enriched_unharmonised_file_format);
          print("SCD Type: " + scd_type);      
          
          if scd_type == 'no_scd' and CheckPathExists(delta_temp_log) == True:
            dbutils.fs.rm(delta_file_path_full, recurse = True)
          
          if scd_type == 'no_scd':
              if alds_enriched_unharmonised_file_format.lower() == 'parquet':             
                  if len(partition_by) > 0:
                    
                      merged_df.write.format(alds_enriched_unharmonised_file_format).mode("overwrite").partitionBy(partition_by).save(delta_file_path_full) 
                  else:       
                      merged_df.write.format(alds_enriched_unharmonised_file_format).mode("overwrite").save(delta_file_path_full)
          else:
          
              if enable_databricks_delta.lower() == 'y' or enable_databricks_delta.lower() == 'yes' or int(enable_databricks_delta) == 1: 
              
                  if len(partition_by) > 0:
                      merged_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").partitionBy(partition_by).save(delta_file_path_full);
                  else:
                      merged_df.write.format("delta").mode("overwrite").option("mergeSchema", "true").save(delta_file_path_full);
