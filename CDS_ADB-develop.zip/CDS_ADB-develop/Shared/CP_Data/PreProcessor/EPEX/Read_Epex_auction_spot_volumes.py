# Databricks notebook source
# MAGIC %run ./WidgetUtil

# COMMAND ----------

SOURCE_PATH = AddAndGetWidgetParameterToNotebook("SOURCE_PATH")
SOURCE_FILE = AddAndGetWidgetParameterToNotebook("SOURCE_FILE")
LAND_PATH= AddAndGetWidgetParameterToNotebook("LAND_PATH")
PERIOD_TYPE= AddAndGetWidgetParameterToNotebook("PERIOD_TYPE")


# COMMAND ----------

def find_country(df):
  
    if 'austria' in df[0]:
         return 'austria'
    if 'great-britain' in df[0]:
         return 'great-britain'
    if 'belgium' in df[0]:
        return 'belgium'
    if 'denmark 1' in df[0]:
        return 'denmark 1'    
    if 'denmark 2' in df[0]:
        return 'denmark 2'
    if 'finland' in df[0]:
        return 'finland'
    if 'france' in df[0]:
        return 'france'
    if 'germany_luxembourg' in df[0]:
        return 'germany_luxembourg'
    if 'netherlands' in df[0]:
        return 'netherlands'
    if 'norway 1' in df[0]:
        return 'norway 1'
    if 'norway 2' in df[0]:
        return 'norway 2'
    if 'norway 3' in df[0]:
        return 'norway 3'
    if 'norway 4' in df[0]:
        return 'norway 4'
    if 'norway 5' in df[0]:
        return 'norway 5'
    if 'poland' in df[0]:
        return 'poland'
    if 'sweden 1' in df[0]:
        return 'sweden 1'
    if 'sweden 2' in df[0]:
        return 'sweden 2'
    if 'sweden 3' in df[0]:
        return 'sweden 3'
    if 'sweden 4' in df[0]:
        return 'sweden 4'
    if 'switzerland' in df[0]:
        return 'switzerland'

# COMMAND ----------

import csv
import glob
import os
import pandas as pd
import datetime 
import numpy as np
from pyspark import SparkContext
from pyspark.sql import SQLContext
import pandavro as pdx

path = SOURCE_PATH
 
all_files = glob.glob(os.path.join(path ,SOURCE_FILE))

for filename in all_files:
                 print(filename)
                 
                 df1 = pd.read_csv(filename,sep =None, header = None, skiprows = 1)
                 df1.columns = df1.iloc[0]
                 df1=df1.loc[1:]
                 df1.rename({'Delivery day': 'Delivery_day'}, axis=1, inplace=True)
                 df1['Delivery_day'] = pd.to_datetime(df1['Delivery_day'],format="%d/%m/%Y")
                 cols = df1.select_dtypes(exclude=['datetime']).columns
                 df1[cols] = df1[cols].apply(pd.to_numeric, downcast='float', errors='coerce')
                 df1.reset_index(drop=True, inplace=True)
                 display(df1)
                 df = pd.read_csv(filename)
                 df = df.T.reset_index().T.reset_index(drop=True)
                 df['AUCTION_REPORT_DATE'] = df[0].str[1:12]
                 df = df.loc[:0]
                 df['MARKET_COUNTRY_NAME'] = df.apply(find_country, axis = 1)
                 df= df.drop(0, axis=1)
                 df['AUCTION_REPORT_DATE'] = pd.to_datetime(df['AUCTION_REPORT_DATE'],format=" %d/%m/%Y")
                 df.reset_index(drop=True, inplace=True)
                 df.info()
                 display(df)
                 # df2 = pd.concat([df,df1],axis=1) 
                 df25 = pd.concat([df.reindex(df1.index, method='ffill'), df1], axis=1)
                 df25.insert(1, 'VENUE_NAME', 'EPEX')
                 if(PERIOD_TYPE == 'hourly'): 
                     df25.insert(2, 'DELIVERY_PERIOD_TYPE', 'DATE TIME - 60 MINUTE GRAIN')
                 if(PERIOD_TYPE == 'halfhourly'):
                     df25.insert(2, 'DELIVERY_PERIOD_TYPE', 'DATE TIME - 30 MINUTE GRAIN')
                 #df25.insert(3, 'MARKET_COUNTRY_NAME', 'great-britain')
                 df25.insert(4, 'COMMODITY_NAME', 'Power Day Ahead Auction')
                 df25.insert(5, 'MEASURE_OF_UNIT', 'MWH')  
                 df25.columns = df25.columns.str.replace(" ", "_")
                 df25.columns = df25.columns.str.replace("-", "_")
                 LAND_FULL_PATH = LAND_PATH +'/'+SOURCE_FILE +'.avro'
                 display(df25)
                 pdx.to_avro(LAND_FULL_PATH, df25)
                 #df25.to_csv(LAND_FULL_PATH)




# COMMAND ----------


