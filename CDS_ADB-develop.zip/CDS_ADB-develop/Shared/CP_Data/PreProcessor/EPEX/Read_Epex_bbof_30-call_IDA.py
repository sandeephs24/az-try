# Databricks notebook source
# MAGIC %run /Shared/CP_Data/Config/config

# COMMAND ----------

# MAGIC %run ./WidgetUtil

# COMMAND ----------

SOURCE_PATH = AddAndGetWidgetParameterToNotebook("SOURCE_PATH")
SOURCE_FILE = AddAndGetWidgetParameterToNotebook("SOURCE_FILE")
LAND_PATH= AddAndGetWidgetParameterToNotebook("LAND_PATH")
PERIOD_TYPE= AddAndGetWidgetParameterToNotebook("PERIOD_TYPE")


# COMMAND ----------

def find_country(file_name):
    if 'austria' in file_name:
         return 'austria'
    if 'great-britain' in file_name:
         return 'great-britain'
    if 'belgium' in file_name:
        return 'belgium'
    if 'denmark 1' in file_name:
        return 'denmark 1'    
    if 'denmark 2' in file_name:
        return 'denmark 2'
    if 'finland' in file_name:
        return 'finland'
    if 'france' in file_name:
        return 'france'
    if 'germany_luxembourg' in file_name:
        return 'germany_luxembourg'
    if 'germany' in file_name:
        return 'germany'
    if 'netherlands' in file_name:
        return 'netherlands'
    if 'norway 1' in file_name:
        return 'norway 1'
    if 'norway 2' in file_name:
        return 'norway 2'
    if 'norway 3' in file_name:
        return 'norway 3'
    if 'norway 4' in file_name:
        return 'norway 4'
    if 'norway 5' in file_name:
        return 'norway 5'
    if 'poland' in file_name:
        return 'poland'
    if 'sweden 1' in file_name:
        return 'sweden 1'
    if 'sweden 2' in file_name:
        return 'sweden 2'
    if 'sweden 3' in file_name:
        return 'sweden 3'
    if 'sweden 4' in file_name:
        return 'sweden 4'
    if 'GB_IDA' in file_name:
         return 'GB'

# COMMAND ----------



# COMMAND ----------

import csv
import glob
import os
import pandas as pd
import datetime 
import numpy as np
from pyspark import SparkContext
from pyspark.sql import SQLContext
import pandavro as pdx
import csv
import glob
import os
import pandas as pd
import datetime 
import numpy as np
from pyspark import SparkContext
from pyspark.sql import SQLContext
import pandavro as pdx
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.functions import *
from IPython.display import display, Markdown, HTML
import requests
import json
from flatten_json import flatten
import itertools
from datetime import date, datetime, timedelta
from datetime import datetime
from calendar import WEDNESDAY, THURSDAY
from time import time
import getpass
from functools import partial

import plotly
import plotly.graph_objs as go
from plotly.offline import plot, iplot
import time
from pyspark.sql import Row
%matplotlib inline
from pyspark.sql.types import IntegerType
pd.set_option('display.float_format', lambda x: '%f' % x)
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

path = SOURCE_PATH
 
all_files = glob.glob(os.path.join(path ,SOURCE_FILE))

for filename in all_files:
                 print(filename)
                 filename1 = filename.split("dbfs")[1]                 
                 metadata_df = spark.read.format("csv").load(filename1).limit(7)
                 sample_str = metadata_df.filter("_c0 like '# Data type(ST)%'").first()["_c0"]
                 sample_data_str = metadata_df.filter("_c0 like 'ST%'").first()["_c0"]
                 sample_str1 = metadata_df.filter("_c0 like '%Auction%'").first()["_c0"]
                 file_source_date = str(sample_str1.split(" ")[1])
                 print(file_source_date)
                 print(file_source_date)
                 Delivery_Date=str(sample_data_str.split(";")[1])
                 Currency=str(sample_data_str.split(";")[2])
                 Creation_Time=str(sample_data_str.split(";")[3])
                 Creation_date=str(sample_data_str.split(";")[4])
                 country_name = find_country(SOURCE_FILE)
                 df1 = pd.read_csv(filename,sep =None, header = None, skiprows = 3)
                 df1. replace(np.nan,'',regex=True)
                 df1.columns = df1.iloc[0]
                #print(df1.columns)
                 n = 4
                 df1.drop(index=df1.index[:n],inplace=True)
                 df1.pop(df1.columns[0])
                 display(df1) 
                 if 'bbof_GB_IDA2' in filename:
                      schema = StructType([StructField("BlockID", StringType(), True),StructField("Block Type", StringType(), True),StructField("BlockCodePRM", StringType(), True),StructField("Execution", StringType(), True),StructField("Limit Price", StringType(), True),StructField("Volume H13 Q1", StringType(), True),StructField("Volume H13 Q2", StringType(), True),StructField("Volume H14 Q1", StringType(), True),StructField("Volume H14 Q2", StringType(), True),StructField("Volume H15 Q1", StringType(), True),StructField("Volume H15 Q2", StringType(), True),StructField("Volume H16 Q1", StringType(), True),StructField("Volume H16 Q2", StringType(), True),StructField("Volume H17 Q1", StringType(), True),StructField("Volume H17 Q2", StringType(), True),StructField("Volume H18 Q1", StringType(), True),StructField("Volume H18 Q2", StringType(), True),StructField("Volume H19 Q1", StringType(), True),StructField("Volume H19 Q2", StringType(), True),StructField("Volume H20 Q1", StringType(), True),StructField("Volume H20 Q2", StringType(), True),StructField("Volume H21 Q1", StringType(), True),StructField("Volume H21 Q2", StringType(), True),StructField("Volume H22 Q1", StringType(), True),StructField("Volume H22 Q2", StringType(), True),StructField("Volume H23 Q1", StringType(), True),StructField("Volume H23 Q2", StringType(), True),StructField("Volume H24 Q1", StringType(), True),StructField("Volume H24 Q2", StringType(), True),StructField("MAR", StringType(), True),StructField("AAR", StringType(), True)])
                 else:
                    schema = StructType([StructField("BlockID", StringType(), True),StructField("Block Type", StringType(), True),StructField("BlockCodePRM", StringType(), True),StructField("Execution", StringType(), True),StructField("Limit Price", StringType(), True),StructField("Volume H01 Q1", StringType(), True),StructField("Volume H01 Q2", StringType(), True),StructField("Volume H02 Q1", StringType(), True),StructField("Volume H02 Q2", StringType(), True),StructField("Volume H03A Q1", StringType(), True),StructField("Volume H03A Q2", StringType(), True),StructField("Volume H03B Q1", StringType(), True),StructField("Volume H03B Q2", StringType(), True),StructField("Volume H04 Q1", StringType(), True),StructField("Volume H04 Q2", StringType(), True),StructField("Volume H05 Q1", StringType(), True),StructField("Volume H05 Q2", StringType(), True),StructField("Volume H06 Q1", StringType(), True),StructField("Volume H06 Q2", StringType(), True),StructField("Volume H07 Q1", StringType(), True),StructField("Volume H07 Q2", StringType(), True),StructField("Volume H08 Q1", StringType(), True),StructField("Volume H08 Q2", StringType(), True),StructField("Volume H09 Q1", StringType(), True),StructField("Volume H09 Q2", StringType(), True),StructField("Volume H10 Q1", StringType(), True),StructField("Volume H10 Q2", StringType(), True),StructField("Volume H11 Q1", StringType(), True),StructField("Volume H11 Q2", StringType(), True),StructField("Volume H12 Q1", StringType(), True),StructField("Volume H12 Q2", StringType(), True),StructField("Volume H13 Q1", StringType(), True),StructField("Volume H13 Q2", StringType(), True),StructField("Volume H14 Q1", StringType(), True),StructField("Volume H14 Q2", StringType(), True),StructField("Volume H15 Q1", StringType(), True),StructField("Volume H15 Q2", StringType(), True),StructField("Volume H16 Q1", StringType(), True),StructField("Volume H16 Q2", StringType(), True),StructField("Volume H17 Q1", StringType(), True),StructField("Volume H17 Q2", StringType(), True),StructField("Volume H18 Q1", StringType(), True),StructField("Volume H18 Q2", StringType(), True),StructField("Volume H19 Q1", StringType(), True),StructField("Volume H19 Q2", StringType(), True),StructField("Volume H20 Q1", StringType(), True),StructField("Volume H20 Q2", StringType(), True),StructField("Volume H21 Q1", StringType(), True),StructField("Volume H21 Q2", StringType(), True),StructField("Volume H22 Q1", StringType(), True),StructField("Volume H22 Q2", StringType(), True),StructField("Volume H23 Q1", StringType(), True),StructField("Volume H23 Q2", StringType(), True),StructField("Volume H24 Q1", StringType(), True),StructField("Volume H24 Q2", StringType(), True),StructField("MAR", StringType(), True),StructField("AAR", StringType(), True)])
                 df = spark.createDataFrame(df1,schema=schema)
  #print(df)
  #display(df1)
                 if 'bbof_GB_IDA2' in filename:
                        df = df.withColumn("Volume_H01_Q1",lit("")).withColumn("Volume_H01_Q2",lit("")).withColumn("Volume_H02_Q1",lit("")).withColumn("Volume_H02_Q2",lit("")).withColumn("Volume_H03A_Q1",lit("")).withColumn("Volume_H03A_Q2",lit("")).withColumn("Volume_H03B_Q1",lit("")).withColumn("Volume_H03B_Q2",lit("")).withColumn("Volume_H04_Q1",lit("")).withColumn("Volume_H04_Q2",lit("")).withColumn("Volume_H05_Q1",lit("")).withColumn("Volume_H05_Q2",lit("")).withColumn("Volume_H06_Q1",lit("")).withColumn("Volume_H06_Q2",lit("")).withColumn("Volume_H07_Q1",lit("")).withColumn("Volume_H07_Q2",lit("")).withColumn("Volume_H08_Q1",lit("")).withColumn("Volume_H08_Q2",lit("")).withColumn("Volume_H09_Q1",lit("")).withColumn("Volume_H09_Q2",lit("")).withColumn("Volume_H10_Q1",lit("")).withColumn("Volume_H10_Q2",lit("")).withColumn("Volume_H11_Q1",lit("")).withColumn("Volume_H11_Q2",lit("")).withColumn("Volume_H12_Q1",lit("")).withColumn("Volume_H12_Q2",lit("")).withColumnRenamed("Volume H13 Q1","Volume_H13_Q1").withColumnRenamed("Volume H13 Q2","Volume_H13_Q2").withColumnRenamed("Volume H14 Q1","Volume_H14_Q1").withColumnRenamed("Volume H14 Q2","Volume_H14_Q2").withColumnRenamed("Volume H15 Q1","Volume_H15_Q1").withColumnRenamed("Volume H15 Q2","Volume_H15_Q2").withColumnRenamed("Volume H16 Q1","Volume_H16_Q1").withColumnRenamed("Volume H16 Q2","Volume_H16_Q2").withColumnRenamed("Volume H17 Q1","Volume_H17_Q1").withColumnRenamed("Volume H17 Q2","Volume_H17_Q2").withColumnRenamed("Volume H18 Q1","Volume_H18_Q1").withColumnRenamed("Volume H18 Q2","Volume_H18_Q2").withColumnRenamed("Volume H19 Q1","Volume_H19_Q1").withColumnRenamed("Volume H19 Q2","Volume_H19_Q2").withColumnRenamed("Volume H20 Q1","Volume_H20_Q1").withColumnRenamed("Volume H20 Q2","Volume_H20_Q2").withColumnRenamed("Volume H21 Q1","Volume_H21_Q1").withColumnRenamed("Volume H21 Q2","Volume_H21_Q2").withColumnRenamed("Volume H22 Q1","Volume_H22_Q1").withColumnRenamed("Volume H22 Q2","Volume_H22_Q2").withColumnRenamed("Volume H23 Q1","Volume_H23_Q1").withColumnRenamed("Volume H23 Q2","Volume_H23_Q2").withColumnRenamed("Volume H24 Q1","Volume_H24_Q1").withColumnRenamed("Volume H24 Q2","Volume_H24_Q2").withColumnRenamed("MAR","MAR").withColumnRenamed("AAR","AAR")
                 else:
                      df = df.withColumnRenamed("Volume H01 Q1","Volume_H01_Q1").withColumnRenamed("Volume H01 Q2","Volume_H01_Q2").withColumnRenamed("Volume H02 Q1","Volume_H02_Q1").withColumnRenamed("Volume H02 Q2","Volume_H02_Q2").withColumnRenamed("Volume H03A Q1","Volume_H03A_Q1").withColumnRenamed("Volume H03A Q2","Volume_H03A_Q2").withColumnRenamed("Volume H03B Q1","Volume_H03B_Q1").withColumnRenamed("Volume H03B Q2","Volume_H03B_Q2").withColumnRenamed("Volume H04 Q1","Volume_H04_Q1").withColumnRenamed("Volume H04 Q2","Volume_H04_Q2").withColumnRenamed("Volume H05 Q1","Volume_H05_Q1").withColumnRenamed("Volume H05 Q2","Volume_H05_Q2").withColumnRenamed("Volume H06 Q1","Volume_H06_Q1").withColumnRenamed("Volume H06 Q2","Volume_H06_Q2").withColumnRenamed("Volume H07 Q1","Volume_H07_Q1").withColumnRenamed("Volume H07 Q2","Volume_H07_Q2").withColumnRenamed("Volume H08 Q1","Volume_H08_Q1").withColumnRenamed("Volume H08 Q2","Volume_H08_Q2").withColumnRenamed("Volume H09 Q1","Volume_H09_Q1").withColumnRenamed("Volume H09 Q2","Volume_H09_Q2").withColumnRenamed("Volume H10 Q1","Volume_H10_Q1").withColumnRenamed("Volume H10 Q2","Volume_H10_Q2").withColumnRenamed("Volume H11 Q1","Volume_H11_Q1").withColumnRenamed("Volume H11 Q2","Volume_H11_Q2").withColumnRenamed("Volume H12 Q1","Volume_H12_Q1").withColumnRenamed("Volume H12 Q2","Volume_H12_Q2").withColumnRenamed("Volume H13 Q1","Volume_H13_Q1").withColumnRenamed("Volume H13 Q2","Volume_H13_Q2").withColumnRenamed("Volume H14 Q1","Volume_H14_Q1").withColumnRenamed("Volume H14 Q2","Volume_H14_Q2").withColumnRenamed("Volume H15 Q1","Volume_H15_Q1").withColumnRenamed("Volume H15 Q2","Volume_H15_Q2").withColumnRenamed("Volume H16 Q1","Volume_H16_Q1").withColumnRenamed("Volume H16 Q2","Volume_H16_Q2").withColumnRenamed("Volume H17 Q1","Volume_H17_Q1").withColumnRenamed("Volume H17 Q2","Volume_H17_Q2").withColumnRenamed("Volume H18 Q1","Volume_H18_Q1").withColumnRenamed("Volume H18 Q2","Volume_H18_Q2").withColumnRenamed("Volume H19 Q1","Volume_H19_Q1").withColumnRenamed("Volume H19 Q2","Volume_H19_Q2").withColumnRenamed("Volume H20 Q1","Volume_H20_Q1").withColumnRenamed("Volume H20 Q2","Volume_H20_Q2").withColumnRenamed("Volume H21 Q1","Volume_H21_Q1").withColumnRenamed("Volume H21 Q2","Volume_H21_Q2").withColumnRenamed("Volume H22 Q1","Volume_H22_Q1").withColumnRenamed("Volume H22 Q2","Volume_H22_Q2").withColumnRenamed("Volume H23 Q1","Volume_H23_Q1").withColumnRenamed("Volume H23 Q2","Volume_H23_Q2").withColumnRenamed("Volume H24 Q1","Volume_H24_Q1").withColumnRenamed("Volume H24 Q2","Volume_H24_Q2").withColumnRenamed("MAR","MAR").withColumnRenamed("AAR","AAR")
  
                 df = df.withColumn("MARKET_COUNTRY_NAME",lit(country_name)).withColumn("AUCTION_REPORT_DATE",lit(file_source_date)).withColumn("VENUE_NAME",lit("EPEX")).withColumn("AUCTION_TYPE",lit("DAILY - MANUAL AUCTION BLOCK BIDS")).withColumn("DELIVERY_PERIOD_TYPE",lit("DATE TIME - 30 MINUTE GRAIN")).withColumn("COMMODITY_NAME",lit("Power Intra Day Auction")).withColumn("CURRENCY",lit(Currency)).withColumn("DELIVERY_DATE",lit(Delivery_Date)).withColumn("CREATION_TIME",lit(Creation_Time)).withColumn("CREATION_DATE",lit(Creation_date)).withColumnRenamed("BlockID","BLOCK_ID").withColumnRenamed("Block Type","BLOCK_TYPE").withColumnRenamed("BlockCodePRM","BLOCK_CODE_PRM").withColumnRenamed("Execution","EXECUTION").withColumnRenamed("Limit Price","LIMIT_PRICE").select("AUCTION_REPORT_DATE","VENUE_NAME","MARKET_COUNTRY_NAME","AUCTION_TYPE","COMMODITY_NAME","DELIVERY_PERIOD_TYPE","DELIVERY_DATE","CURRENCY","CREATION_TIME","CREATION_DATE","BLOCK_ID","BLOCK_TYPE","BLOCK_CODE_PRM","EXECUTION","LIMIT_PRICE","Volume_H01_Q1","Volume_H01_Q2","Volume_H02_Q1","Volume_H02_Q2","Volume_H03A_Q1","Volume_H03A_Q2","Volume_H03B_Q1","Volume_H03B_Q2","Volume_H04_Q1","Volume_H04_Q2","Volume_H05_Q1","Volume_H05_Q2","Volume_H06_Q1","Volume_H06_Q2","Volume_H07_Q1","Volume_H07_Q2","Volume_H08_Q1","Volume_H08_Q2","Volume_H09_Q1","Volume_H09_Q2","Volume_H10_Q1","Volume_H10_Q2","Volume_H11_Q1","Volume_H11_Q2","Volume_H12_Q1","Volume_H12_Q2","Volume_H13_Q1","Volume_H13_Q2","Volume_H14_Q1","Volume_H14_Q2","Volume_H15_Q1","Volume_H15_Q2","Volume_H16_Q1","Volume_H16_Q2","Volume_H17_Q1","Volume_H17_Q2","Volume_H18_Q1","Volume_H18_Q2","Volume_H19_Q1","Volume_H19_Q2","Volume_H20_Q1","Volume_H20_Q2","Volume_H21_Q1","Volume_H21_Q2","Volume_H22_Q1","Volume_H22_Q2","Volume_H23_Q1","Volume_H23_Q2","Volume_H24_Q1","Volume_H24_Q2","MAR","AAR")
                               #df.show(20,False)
                 pandas_df = df.toPandas()
                 display(pandas_df)
                 SOURCE_FILE_END = str(SOURCE_FILE.split(".")[0])
                 print(SOURCE_FILE_END)
                 LAND_FULL_PATH = LAND_PATH +'/'+SOURCE_FILE_END + '.avro'
                 print(LAND_FULL_PATH)
                 #LAND_FULL_PATH = LAND_PATH +'/'+SOURCE_FILE
                 pdx.to_avro(LAND_FULL_PATH, pandas_df)
                 #df.coalesce(1).write.mode('overwrite').format("avro").option("compression","uncompressed").save(LAND_FULL_PATH)
        




# COMMAND ----------


