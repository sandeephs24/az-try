# Databricks notebook source
def AddAndGetWidgetParameterToNotebook(input_name):
  import os

  try:
    input = dbutils.widgets.get(input_name)

    if(input==""):
      print("Please Enter "+ input_name +". The Module will now exit with Errors")
    else:
      print(input_name + " Received : ",input)

  except Exception as e:
    dbutils.widgets.text(input_name,"", label = input_name)

    input = getArgument(input_name)

    print("Manual RUN Encountered :: Exception Occured, Please Enter all params in the Widget Visible")
    
  return input  

# COMMAND ----------


