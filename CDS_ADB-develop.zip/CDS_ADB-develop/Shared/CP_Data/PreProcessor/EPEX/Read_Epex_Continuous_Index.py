# Databricks notebook source
# MAGIC %run ./WidgetUtil

# COMMAND ----------

SOURCE_PATH = AddAndGetWidgetParameterToNotebook("SOURCE_PATH")
SOURCE_FILE = AddAndGetWidgetParameterToNotebook("SOURCE_FILE")
LAND_PATH= AddAndGetWidgetParameterToNotebook("LAND_PATH")
PERIOD_TYPE= AddAndGetWidgetParameterToNotebook("PERIOD_TYPE")


# COMMAND ----------

def find_country(df):
  
    if 'AT' in df[0]:
         return 'AT'
    if 'GB' in df[0]:
         return 'GB'
    if 'BE' in df[0]:
        return 'BE'
    if 'DK1' in df[0]:
        return 'DK1'    
    if 'DK2' in df[0]:
        return 'DK2'
    if 'FI' in df[0]:
        return 'FI'
    if 'FR' in df[0]:
        return 'FR'
    if 'DE' in df[0]:
        return 'DE'
    if 'NL' in df[0]:
        return 'NL'
    if 'NO1' in df[0]:
        return 'NO1'
    if 'NO2' in df[0]:
        return 'NO2'
    if 'NO3' in df[0]:
        return 'NO3'
    if 'NO4' in df[0]:
        return 'NO4'
    if 'NO5' in df[0]:
        return 'NO5'
    if 'PL' in df[0]:
        return 'PL'
    if 'SE1' in df[0]:
        return 'SE1'
    if 'SE2' in df[0]:
        return 'SE2'
    if 'SE3' in df[0]:
        return 'SE3'
    if 'SE4' in df[0]:
        return 'SE4'
    if 'CH' in df[0]:
        return 'CH'

# COMMAND ----------

def find_currency(df):
  
    if 'GBP' in df[0]:
         return 'GBP'
    if 'EUR' in df[0]:
         return 'EUR'
   
        
   

# COMMAND ----------

def find_delivery_period(df):
  
    if 'Industrial Peak' in df['TimeResolution']: 
       return 'DATE TIME - 12 HOUR GRAIN'
    if '15min' in df['TimeResolution']:
       return 'DATE TIME - 15 MINUTE GRAIN'
    if '30min' in df['TimeResolution']:
        return 'DATE TIME - 30 MINUTE GRAIN' 
    if 'Base' in df['TimeResolution'] :
        return 'DATE TIME - 24 HOUR GRAIN'
    if 'Offpeak'in df['TimeResolution']: 
        return 'DATE TIME - 24 HOUR GRAIN'
    if 'Extended Peak' in df['TimeResolution']:
        return 'DATE TIME - 16 HOUR GRAIN'
    if '60min' in df['TimeResolution']:
       return 'DATE TIME - 60 MINUTE GRAIN'  
    if 'Peak' in df['TimeResolution']:
       return 'DATE TIME - 12 MINUTE GRAIN'     
                 
   
        
   

# COMMAND ----------

import csv
import glob
import os
import pandas as pd
import datetime 
import numpy as np
from pyspark import SparkContext
from pyspark.sql import SQLContext
import pandavro as pdx

path = SOURCE_PATH
print(SOURCE_PATH)
print(path)
 
all_files = glob.glob(os.path.join(path ,SOURCE_FILE))

print(all_files)

for filename in all_files:
                 print(filename)
                 df1 = pd.read_csv(filename,sep =None, header = None, skiprows = 1)
                 df1.columns = df1.iloc[0]
                 df1=df1.loc[1:]
                 df1[["IndexName", "TimeResolution","Currency","VolumeUnit"]] = df1[["IndexName", "TimeResolution","Currency","VolumeUnit"]].astype('string') 
                 df1['DeliveryStart'] = pd.to_datetime(df1['DeliveryStart'])
                 df1['DeliveryStart'] = df1['DeliveryStart'].dt.tz_localize(None)
                 df1['DeliveryEnd'] = pd.to_datetime(df1['DeliveryEnd'])
                 df1['DeliveryEnd'] = df1['DeliveryEnd'].dt.tz_localize(None)
                 df1['IndexPrice'] = df1['IndexPrice'].astype(float)
                 df1['IndexVolume'] = df1['IndexVolume'].astype(float)
                 df1.reset_index(drop=True, inplace=True)
                 df1.info()
                 display(df1)
                 df = pd.read_csv(filename)
                 df = df.T.reset_index().T.reset_index(drop=True)
                 #df['AUCTION_REPORT_DATE'] = df[0].str[26:36]
                 l=df[0].astype(str).map(len)[0]
                 print(l)
                 if (l==63) :
                   df['AUCTION_REPORT_DATE'] = df[0].str[26:36]
                 if (l==64):
                   df['AUCTION_REPORT_DATE'] = df[0].str[27:37]
                 df = df.loc[:0]
                 df['MARKET_COUNTRY_NAME'] = df.apply(find_country, axis = 1)
                 df['MARKET_COUNTRY_NAME']=df['MARKET_COUNTRY_NAME'].astype('string')
                 df= df.drop(0, axis=1)
                 df['AUCTION_REPORT_DATE'] = pd.to_datetime(df['AUCTION_REPORT_DATE'])
                 df.reset_index(drop=True, inplace=True)
                 df.info()
                 display(df)
                 df25 = pd.concat([df.reindex(df1.index, method='ffill'), df1], axis=1)
                 df25.info()
                 df25.insert(1, 'VENUE_NAME', 'EPEX')
                 #display(df25)
                 df25.insert(2,'DELIVERY_PERIOD_TYPE',df25.apply(find_delivery_period,axis=1))
                 df25.insert(4, 'COMMODITY_NAME', 'Power Continuous Intra Day')
                 df25.columns = df25.columns.str.replace(" ", "_")
                 df25.columns = df25.columns.str.replace("-", "_")
                 display(df25)
                 print(LAND_PATH) 
                 LAND_FULL_PATH = LAND_PATH +'/'+SOURCE_FILE +'.avro'
                 print (LAND_FULL_PATH)
                 pdx.to_avro(LAND_FULL_PATH, df25)

                 #df25.to_csv(LAND_FULL_PATH)
                 #df25.to_csv("/dbfs/mnt/ADLS/PROJECT/P01873-TRADE_SURVEILLANCE_ANALYTICS/EPEX_TRANSFORMED/Continuous_Index/Continuous_Index-GB-20230108-20230109T000722000Z.csv")
                
                 
                 
        




# COMMAND ----------


