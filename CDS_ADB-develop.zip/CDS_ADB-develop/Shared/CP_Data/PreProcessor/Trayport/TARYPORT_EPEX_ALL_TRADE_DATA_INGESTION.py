# Databricks notebook source
import os

# COMMAND ----------

dbutils.widgets.text("LAND_PATH","/RAW/W01027-TRAYPORT_ANALYTICS_MARKET_ORDER_DEV/")
LAND_PATH = dbutils.widgets.get("LAND_PATH")
print(LAND_PATH)

dbutils.widgets.text("LAST_OFFSET_VALUE","2023-03-14 00:00:00|10641250|10410043|98204")
LAST_OFFSET_VALUE = dbutils.widgets.get("LAST_OFFSET_VALUE")
print(LAST_OFFSET_VALUE)
LAST_OFFSET_VALUE_BEFORE_PROCESSING = LAST_OFFSET_VALUE

dbutils.widgets.text("start_from_last_failed_point","true")
start_from_last_failed_point = dbutils.widgets.get("start_from_last_failed_point")
print(start_from_last_failed_point)



# COMMAND ----------

# MAGIC %run ./../Trayport/Reader_connections_Updated

# COMMAND ----------

count=1
AllInsSeqDataAvroFilePath = "/mnt/ADLS" + LAND_PATH + "TRANSFORMED_FILE/ALL_INS_SEQ_SFTP_DATA.avro"
Instrument_df = getInsSeqData(AllInsSeqDataAvroFilePath)
print(Instrument_df.count())
AllInsSeqDataAvroFileInitialCount = Instrument_df.count()


if (start_from_last_failed_point == "true"):
  Instrument_df = filter_based_on_last_watermark(Instrument_df,LAST_OFFSET_VALUE)

AllInsSeqDataAvroFileAfterWatermarkCount = Instrument_df.count()
print(Instrument_df.count())
Instrument_df = Instrument_df.orderBy(["OriginalTradingStart", "SequenceId", "ItemId"])


# COMMAND ----------

print("start Time:{0}".format(datetime.now()))
allTradeDf, error_code, error_string, last_processed_InstrumentId, last_processed_SequenceId, last_processed_ItemId, last_processed_OriginalTradingStart = getAllPrivateTrades(Instrument_df)

AllPrivateTradeCountWrittenToAvro = allTradeDf.count()
print(error_code)
print(AllPrivateTradeCountWrittenToAvro)
print(last_processed_InstrumentId)
print(last_processed_SequenceId)
print(last_processed_ItemId)
print(last_processed_OriginalTradingStart)

print("\n\ndata fetch completed\n\n")
print("Fetch Time:{0}".format(datetime.now()))

allTradeDf.show()

# COMMAND ----------

extract_Date = datetime.now().strftime("%Y%m%d")

new_last_offset_value_watermark = LAST_OFFSET_VALUE_BEFORE_PROCESSING
if (AllPrivateTradeCountWrittenToAvro > 0):
  allPrivateTradesDf = allTradeDf.withColumn("TradeIndicator",split(col("TradeId"), " ").getItem(1))
  allPrivateTradesDf = allPrivateTradesDf.withColumn("TradeId",split(col("TradeId"), " ").getItem(0))
  allPrivateTradesDf = allPrivateTradesDf.filter(col("venueCode") == "EPEX")
  save_as_single_file_with_custom_name(allPrivateTradesDf,"Epex_AllPrivateTrade_Data", extract_Date, LAND_PATH)
  new_last_offset_value_watermark = str(last_processed_OriginalTradingStart) + "|" +  str(last_processed_InstrumentId) + "|" + str(last_processed_SequenceId) + "|" + str(last_processed_ItemId)

# COMMAND ----------

#jsonResponse = '{"DatabricksReturnJson": {'+ '"' + 'error_code' + '":"' + str(error_code) + '"' + '}}'
jsonResponse = '{"DatabricksReturnJson": {'
jsonResponse = jsonResponse + '"' + 'error_code' + '":"' + str(error_code) + '"' + ','
jsonResponse = jsonResponse + '"' + 'error_string' + '":"' + error_string + '"' + ','
jsonResponse = jsonResponse + '"' + 'last_processed_InstrumentId' + '":"' + str(last_processed_InstrumentId) + '"' + ','
jsonResponse = jsonResponse + '"' + 'last_processed_SequenceId' + '":"' + str(last_processed_SequenceId) + '"' + ','
jsonResponse = jsonResponse + '"' + 'last_processed_ItemId' + '":"' + str(last_processed_ItemId) + '"' + ','
jsonResponse = jsonResponse + '"' + 'last_processed_OriginalTradingStart' + '":"' + str(last_processed_OriginalTradingStart) + '"' + ','
jsonResponse = jsonResponse + '"' + 'new_last_offset_value_watermark' + '":"' + new_last_offset_value_watermark + '"' + ','
jsonResponse = jsonResponse + '"' + 'old_last_offset_value_watermark' + '":"' + LAST_OFFSET_VALUE + '"' + ','
jsonResponse = jsonResponse + '"' + 'AllInsSeqDataAvroFileInitialCount' + '":"' + str(AllInsSeqDataAvroFileInitialCount) + '"' + ','
jsonResponse = jsonResponse + '"' + 'AllInsSeqDataAvroFileAfterWatermarkCount' + '":"' + str(AllInsSeqDataAvroFileAfterWatermarkCount) + '"' + ','
# jsonResponse = jsonResponse + '"' + 'AllTradeCountWrittenToAvro' + '":"' + str(AllTradeCountWrittenToAvro) + '"' + ','
jsonResponse = jsonResponse + '"' + 'AllPrivateTradeCountWrittenToAvro' + '":"' + str(AllPrivateTradeCountWrittenToAvro) + '"'

jsonResponse = jsonResponse + '}}'

print(jsonResponse)
dbutils.notebook.exit(jsonResponse)

# COMMAND ----------


