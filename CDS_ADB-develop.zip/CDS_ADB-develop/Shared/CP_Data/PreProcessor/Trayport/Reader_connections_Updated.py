# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.functions import *
from IPython.display import display, Markdown, HTML

import pandas as pd
import numpy as np
import requests
import json


from datetime import date, datetime, timedelta
from datetime import datetime
from calendar import WEDNESDAY, THURSDAY
from time import time
import getpass
from functools import partial
from  pyspark.sql.functions import regexp_replace
from pyspark.sql.functions import col
import time
from pyspark.sql import Row
from pyspark.sql.types import IntegerType
import glob

# COMMAND ----------

refdata_base_url = 'https://referencedata.trayport.com'
analytics_base_url = 'https://analytics.trayport.com/api'

instruments_url = refdata_base_url + '/instruments'
markets_url = refdata_base_url + '/markets'
sequences_url = refdata_base_url + '/sequences'

trades_url = analytics_base_url + '/trades'
ohlcv_url = analytics_base_url + '/trades/ohlcv'
private_url = analytics_base_url + '/trades/private'
activity_url = analytics_base_url + '/trades/activity'
book_url = analytics_base_url + '/orders/book'
book_top_url = analytics_base_url + '/orders/book/top'

# COMMAND ----------

headers = {}
def getHeaders():
  global headers
  headers = {
    'x-api-key': 'c099216c406f49304d1c99d018412e3d'
  }
  return headers

# COMMAND ----------

params={}
def getParams():
  global params
  params = {}
  return params

# COMMAND ----------

getHeaders()
getParams()

# COMMAND ----------

def get_inst_req(url, params, headers):
  #start_time = time()
  r = requests.get(url, params, headers=headers)
  #duration = time() - start_time
  #print(r.request.url)
  #print(f'Duration: {duration:.3f}s')
  if r.status_code != 200:
    raise Exception(f'Status: {r.status_code}. {r.content.decode()}')
  return r.content

def get_obj(url, params={}, headers=headers):
  content = get_inst_req(url, params, headers)
  return json.loads(content)

def get_df(url, params={}, headers=headers):
  content = get_inst_req(url, {}, getHeaders())
  #print("content:{0}".format(content))
  df = pd.read_json(content, convert_dates=['timestamp','fromTimestamp', 'toTimestamp'])
  if len(df) > 0:
    if 'timestamp' in df.columns:
      df.set_index('timestamp', inplace=True)
  return df

# COMMAND ----------

def _get(url, params, headers = headers):
  """ Uses reference and trayport URL's to collect API data and return JSON."""
  try:
    #time.sleep(0.25)
    #print("url:{0}".format(url))
    r = requests.get(url, params, headers=headers)
    #print("response:{0}".format(json.loads(r.content)))
    r.raise_for_status()
  except requests.exceptions.HTTPError:
    #logger.info(f'URL: {r.requests.url}')
    if r.status_code == 504:
      raise RuntimeError(f'API Gateway has timed-out. Content: {r.content}')
    if r.status_code == 500:
      raise RuntimeError(f'Trayport server error. Content: {r.content}')
    raise RuntimeError(f'Status: {r.status_code}, {r.json()["errors"]}')
    
  try:
    data = json.loads(r.content)
  except json.JSONDecodeError:
    #logger.info(f'JSON not formatted correctly. Content: {r.content}')
    raise RuntimeError(f'Trayport server not returning data correctly.')
  
  return data

# COMMAND ----------

def getMarketIDList():
  markets = spark.createDataFrame(get_df(markets_url))
  marketIDList = markets.select("id").distinct()
  return marketIDList

# COMMAND ----------

def getInstrumentIDList():
  instruments = spark.createDataFrame(get_df(instruments_url))
  instumentIDList = instruments.filter(instruments["name"].contains("EPEX")| instruments["name"].contains("XBID")).select("id").distinct()
  
  return instumentIDList

# COMMAND ----------

count=0
def getMarketMasterList(x):
  global market_df_list
  market_df_list = []
  id = x
  params = {}
  market_url = markets_url+"/"+str(id)
  r = requests.get(market_url, params, headers=headers)
  if r.status_code != 200:
    raise Exception(f'Status: {r.status_code}. {r.content.decode()}')
  #data = flatten(json.loads(r.content.decode()))
  data = []
  data.append(r.content.decode())
  #print("data:{0}".format(r.content.decode()))
  df = pd.DataFrame({c: pd.Series(dtype=t) for c, t in {'id': 'int', 'name': 'str','tradingSpecifications_priceCurrency': 'str','tradingSpecifications_quantityUnit': 'str','tradingSpecifications_notionalCurrency': 'str','tradingSpecifications_notionalQuantityUnit': 'str'}.items()})
  df = pd.DataFrame(data,index=[0])
  df.fillna("",inplace=True)
  if len(df) > 0:
    if 'timestamp' in df.columns:
      df.set_index('timestamp', inplace=True)
  spark_df = spark.createDataFrame(df)
  market_column_list = ['id','name','tradingSpecifications_priceCurrency','tradingSpecifications_quantityUnit','tradingSpecifications_notionalCurrency','tradingSpecifications_notionalQuantityUnit']
  for x in market_column_list:
    if(x.upper() not in (name.upper() for name in spark_df.columns)):
      spark_df = spark_df.withColumn(x,lit(""))
  columns_list = spark_df.columns
  market_df_list.append(spark_df)

# COMMAND ----------

count=0
instrument_df_list = []
def getInstrumentMasterList(x):
  id = x
  params = {}
  global instrument_df_list
  
  instrument_url = instruments_url+"/"+str(id)
  r = requests.get(instrument_url, params, headers=headers)
  if r.status_code != 200:
    raise Exception(f'Status: {r.status_code}. {r.content.decode()}')
  #data = flatten(json.loads(r.content.decode()))
  data = []
  data.append(r.content.decode())
  df = pd.DataFrame({c: pd.Series(dtype=t) for c, t in {'id': 'int', 'name': 'str','tradingSpecifications_priceCurrency': 'str','tradingSpecifications_quantityUnit': 'str','tradingSpecifications_notionalCurrency': 'str','tradingSpecifications_notionalQuantityUnit': 'str'}.items()})
  df = pd.DataFrame(data,index=[0])
  #print("df:{0}".format(df))
  df.fillna("",inplace=True)
  if len(df) > 0:
    if 'timestamp' in df.columns:
      df.set_index('timestamp', inplace=True)
  spark_df = spark.createDataFrame(df)
  instrument_column_list = ['id','name','tradingSpecifications_priceCurrency','tradingSpecifications_quantityUnit','tradingSpecifications_notionalCurrency','tradingSpecifications_notionalQuantityUnit']
  for x in instrument_column_list:
    if(x.upper() not in (name.upper() for name in spark_df.columns)):
      spark_df = spark_df.withColumn(x,lit(""))
  columns_list = spark_df.columns
  #print("spark_df:{0}".format(spark_df))
  instrument_df_list.append(spark_df)
  #print(len(instrument_df_list))
  #return instrument_df_list

# COMMAND ----------

def getMarketSequenceMasterList(x):
  id = x
  params = {}
  instrument_sequence_url = markets_url+"/"+str(id)+"/sequences"
  r = requests.get(instrument_sequence_url, params, headers=headers)
  if r.status_code != 200:
    raise Exception(f'Status: {r.status_code}. {r.content.decode()}')
  data = json.loads(r.content.decode())
  df = pd.DataFrame({c: pd.Series(dtype=t) for c, t in {'id': 'int', 'name': 'str','displayName': 'str','sequenceItems': 'str'}.items()})
  df = pd.DataFrame.from_records(data)
  df.fillna("",inplace=True)
  if len(df) > 0:
    if 'timestamp' in df.columns:
      df.set_index('timestamp', inplace=True)
  spark_df = spark.createDataFrame(df)
  market_sequence_column_list = ['id','name','displayName','sequenceItems']
  for x in market_sequence_column_list:
    if(x.upper() not in (name.upper() for name in spark_df.columns)):
      spark_df = spark_df.withColumn(x,lit(""))
  spark_df = spark_df.withColumn("InstrumentID",lit(id))
  columns_list = spark_df.columns
  #print("columns_list:{0}".format(columns_list))
  market_sequence_df_list.append(spark_df)

# COMMAND ----------

def getInstrumentSequenceMasterList(x):
  id = x
  params = {}
  global instrument_sequence_df_list
  instrument_sequence_url = instruments_url+"/"+str(id)+"/sequences"
  r = requests.get(instrument_sequence_url, params, headers=headers)
  if r.status_code != 200:
    print ('Error ocurred while fetching data from URL:' + instrument_sequence_url)
    raise Exception(f'Status: {r.status_code}. {r.content.decode()}')
  data = json.loads(r.content.decode())
  df = pd.DataFrame({c: pd.Series(dtype=t) for c, t in {'id': 'int', 'name': 'str','displayName': 'str','sequenceItems': 'str'}.items()})
  df = pd.DataFrame.from_records(data)
  df.fillna("",inplace=True)
  if len(df) > 0:
    if 'timestamp' in df.columns:
      df.set_index('timestamp', inplace=True)
  spark_df = spark.createDataFrame(df)
  instrument_sequence_column_list = ['id','name','displayName','sequenceItems']
  for x in instrument_sequence_column_list:
    if(x.upper() not in (name.upper() for name in spark_df.columns)):
      spark_df = spark_df.withColumn(x,lit(""))
  spark_df = spark_df.withColumn("InstrumentID",lit(id)).withColumnRenamed("name","SequenceName").withColumnRenamed("displayName","SequenceDisplayName")
  columns_list = spark_df.columns
  #print("columns_list:{0}".format(columns_list))
  instrument_sequence_df_list.append(spark_df)

# COMMAND ----------

def getInstrumentSequenceItemMasterList(x):
  #print("id : {0}".format(x))
  id = x
  params = {}
  instrument_sequence_item_url = sequences_url+"/"+str(id)+"/sequenceItems"
  r = requests.get(instrument_sequence_item_url, params, headers=headers)
  if r.status_code != 200:
    raise Exception(f'Status: {r.status_code}. {r.content.decode()}')
  #print("content:{0}".format(r.content.decode()))
  if(r.content.decode()!="[]"):
    data = json.loads(r.content.decode())
    #print("data:{0}".format(type(data)))
    df = pd.DataFrame({c: pd.Series(dtype=t) for c, t in {'id': 'int', 'name': 'str','periodStart': 'str','periodEnd': 'str'}.items()})
    #print(df)
    df = pd.DataFrame.from_records(data)
    df.fillna("",inplace=True)
    #print("df:{0}".format(df.columns))
    if len(df) > 0:
      if 'timestamp' in df.columns:
        df.set_index('timestamp', inplace=True)
    spark_df = spark.createDataFrame(df)
    instrument_sequence_item_column_list = ['id','name','periodStart','periodEnd']
    for x in instrument_sequence_item_column_list:
      if(x.upper() not in (name.upper() for name in spark_df.columns)):
        spark_df = spark_df.withColumn(x,lit(""))
    columns_list = spark_df.columns
    #print("columns_list:{0}".format(columns_list))
    instrument_sequence_item_df_list.append(spark_df)

# COMMAND ----------

market_df_list = []
def MarketDF():
  global market_df_list
  market_df_list = []
  marketIDList = getMarketIDList()
  [getMarketMasterList(int(row.id)) for row in marketIDList.collect()]
  market_master_list = reduce(DataFrame.union, market_df_list)
  market_master_list = market_master_list.withColumnRenamed("tradingSpecifications_quantityUnit","quantityUnit").withColumnRenamed("tradingSpecifications_priceCurrency","priceCurrency").withColumnRenamed("tradingSpecifications_notionalCurrency","notionalCurrency").withColumnRenamed("tradingSpecifications_notionalQuantityUnit","notionalQuantityUnit")
  
  return market_master_list

# COMMAND ----------

def InstrumentDF():
  global instrument_df_list
  instrument_df_list = []
  instumentIDList = getInstrumentIDList()
  return instumentIDList

# COMMAND ----------

instrument_sequence_df_list = []
def getSequenceDF(instumentIDList):
  instumentIDList = instumentIDList
  global instrument_df_list
  instrument_df_list = []
  global instrument_sequence_df_list
  instrument_sequence_df_list = []
  [getInstrumentSequenceMasterList(int(row.id)) for row in instumentIDList.collect()]
  instrument_sequence_master_list=reduce(DataFrame.union, instrument_sequence_df_list)
  return instrument_sequence_master_list

# COMMAND ----------

from datetime import date,datetime

def getCurrentDate():
  today = date.today()- timedelta(days=1)
  d1 = today.strftime("%Y%m%d")
  #print(type(d1))
  return d1
#getCurrentDate()

# COMMAND ----------

def getSequenceItemJoinDFSTFP2(from_trading_start, to_trading_end ,SequenceItemReportFilePath):
  sequence_master_list = getSequenceDF(InstrumentDF())
  sequence_master_list.show()
  sequence_master_list.printSchema()
  sequence_master_list.createOrReplaceTempView("sequence_master_list")
  totalSeqMasterCount = sequence_master_list.count()
  file_type = "csv"
  infer_schema = "true"
  first_row_is_header = "true"
  delimiter = ","

  SequenceItemReportdf = spark.read.format(file_type).option("inferSchema", infer_schema).option("header", first_row_is_header).option("sep", delimiter).load(SequenceItemReportFilePath)
  print(SequenceItemReportdf.count())
  totalSFTPFileCount = SequenceItemReportdf.count()
  SequenceItemReportdf.createOrReplaceTempView("SequenceItemReportView")
  query = "select * from SequenceItemReportView where TradingStart >= to_timestamp('{0}') and TradingStart < to_timestamp('{1}')".format(from_trading_start, to_trading_end)
  print(query)
  SequenceItemReportdf1 = spark.sql(query)
  print(SequenceItemReportdf1.count())
  SequenceItemReportdf1.show()
  SequenceItemReportdf1.printSchema()

  SequenceItemReportdf1.createOrReplaceTempView("SequenceItemReportView")
  query = "select * from SequenceItemReportView a join sequence_master_list b on a.SequenceId = b.id"
  print(query)
  joinedDF = spark.sql(query).select("InstrumentID", "SequenceId", "ItemId", "TradingStart", "TradingEnd",
                                       "PeriodStart", "PeriodEnd")
  
  joinedDF = joinedDF.withColumn("OriginalTradingStart",col('TradingStart'))
  joinedDF = joinedDF.withColumn("OriginalTradingEnd",col('TradingEnd'))
  # joinedDF = joinedDF.withColumn("TradingStart",date_format(col('TradingStart'),'yyyy-MM-dd') )
  # joinedDF = joinedDF.withColumn("TradingEnd",date_format(col('TradingEnd'),'yyyy-MM-dd'))
  # joinedDF = joinedDF.withColumn("PeriodStart",to_timestamp(col('PeriodStart')))
  # joinedDF = joinedDF.withColumn("PeriodEnd",to_timestamp(col('PeriodEnd')))
  # joinedDF = joinedDF.withColumn("TradingStart",to_timestamp(concat(col('TradingStart'),lit(" 00:00:00"))))
  # joinedDF = joinedDF.withColumn(
  #             "TradingEnd",
  #             when(
  #             col('TradingStart') == col('TradingEnd'), 
  #             date_add(to_date(col("TradingEnd"),"yyyy-MM-dd"),1)
  #             ).
  #             otherwise(to_date(col("TradingEnd"),"yyyy-MM-dd"))
  #             )
  # joinedDF.show()
  
  # joinedDF = joinedDF.withColumn("TradingEnd",date_format(col('TradingEnd'),'yyyy-MM-dd'))
  # joinedDF = joinedDF.withColumn("TradingEnd",to_timestamp(concat(col('TradingEnd'),lit(" 00:00:00"))))

  print(joinedDF.count())
  joinedDF.show()
  return joinedDF, totalSeqMasterCount, totalSFTPFileCount

# COMMAND ----------

def getInsSeqData(InsSeqJoinedDataAvroFilePath):
  df = spark.read.format("avro").load(InsSeqJoinedDataAvroFilePath)
  return df


# COMMAND ----------

def getOhlcvTradeDataFrame(instrumentId,sequenceId,sequenceItemId,from_date,until,response):
  from pyspark.sql import Row
  instrumentId = instrumentId
  sequenceId = sequenceId
  sequenceItemId = sequenceItemId
  start_date = from_date
  end_date = until
  price_data = Row("instrumentId","sequenceId","sequenceItemId","start_date","end_date","open","high","low","close","volume","fromTimestamp","toTimestamp")
  data = []
  #print("response:{0}".format(response))
  for x in response:
    p = price_data(instrumentId,sequenceId,sequenceItemId,start_date,end_date,str(x["open"]),str(x["high"]),str(x["low"]),str(x["close"]),str(x["volume"]),str(x["fromTimestamp"]),str(x["toTimestamp"]))
    data.append(p)
  rdd=spark.sparkContext.parallelize(data)
  #print(rdd.collect())
  df=spark.createDataFrame(rdd)
  #df.show()
  return df  

# COMMAND ----------

def getTradeDataFrame(instrumentId,sequenceId,sequenceItemId,from_date,until,response):
  from pyspark.sql import Row
  instrumentId = instrumentId
  sequenceId = sequenceId
  sequenceItemId = sequenceItemId
  start_date = from_date
  end_date = until
  #price_data = Row("instrumentId","sequenceId","sequenceItemId","start_date","end_date","tradeId","venueCode","dealDate","price","quantity","aggressorBuy")
  price_data = Row("instrumentId","sequenceId","sequenceItemId","start_date","end_date","tradeId","venueCode","dealDate","price","quantity","aggressorBuy","aggressorOwnedSpread","fromBrokenSpread","initiatorOwnedSpread","aggressorCompanyId","aggressorTraderCompanyName","aggressorTraderId","aggressorTraderName","aggressorDerivativeIndicator","initiatorCompanyId","initiatorTraderCompanyName","initiatorTraderId","initiatorTraderName","initiatorDerivativeIndicator","productClassification")
  data = []
  for x in response:
    if "privateFields" not in x.keys():
      #price_data = Row("instrumentId","sequenceId","sequenceItemId","start_date","end_date","tradeId","venueCode","dealDate","price","quantity","aggressorBuy")
      p = price_data(instrumentId,sequenceId,sequenceItemId,start_date,end_date,str(x["tradeId"]),str(x["venueCode"]),str(x["dealDate"]),str(x["price"]),str(x["quantity"]),str(x["aggressorBuy"]),"","","","","","","","","","","","","","")
    else:
      #print("y:{0}".format(x["privateFields"]))
      if "productClassification" in x["privateFields"].keys():
        productClassification = str(x["privateFields"]["productClassification"])
      else:
        productClassification = ""

      p = price_data(instrumentId,sequenceId,sequenceItemId,start_date,end_date,str(x["tradeId"]),str(x["venueCode"]),str(x["dealDate"]),str(x["price"]),str(x["quantity"]),str(x["aggressorBuy"]),"","","",str(x["privateFields"]["aggressorCompanyId"]),str(x["privateFields"]["aggressorTraderCompanyName"]),str(x["privateFields"]["aggressorTraderId"]),str(x["privateFields"]["aggressorTraderName"]),str(x["privateFields"]["aggressorDerivativeIndicator"]),str(x["privateFields"]["initiatorCompanyId"]),str(x["privateFields"]["initiatorTraderCompanyName"]),str(x["privateFields"]["initiatorTraderId"]),str(x["privateFields"]["initiatorTraderName"]),str(x["privateFields"]["initiatorDerivativeIndicator"]),productClassification)
    data.append(p)
    #data.append(p)
    #print(data)
  rdd=spark.sparkContext.parallelize(data)
  #print(rdd.collect())
  df=spark.createDataFrame(rdd)
  #df.show()
  return df

# COMMAND ----------

def getPrivateTradeDataFrame(sequenceId,sequenceItemId,from_date,until,trading_start,trading_end,response):
  from pyspark.sql import Row
  sequenceId = sequenceId
  sequenceItemId = sequenceItemId
  start_date = from_date
  end_date = until
  price_data = Row("instrumentId","sequenceId","sequenceItemId","start_date","end_date","TRADING_START_DATE","TRADING_END_DATE","tradeId","venueCode","dealDate","lastUpdated","price","quantity","aggressorBuy","aggressorOwnedSpread","fromBrokenSpread","initiatorOwnedSpread","aggressorCompanyId","aggressorTraderCompanyName","aggressorTraderId","aggressorTraderName","aggressorDerivativeIndicator","initiatorCompanyId","initiatorTraderCompanyName","initiatorTraderId","initiatorTraderName","initiatorDerivativeIndicator","productClassification")
  data = []
  for x in response:
    p = price_data(str(x["contract"]["instrumentId"]),sequenceId,sequenceItemId,start_date,end_date,trading_start,trading_end,str(x["tradeId"]),str(x["venueCode"]),str(x["dealDate"]),str(x["lastUpdated"]),str(x["price"]),str(x["quantity"]),str(x["aggressorBuy"]),"","","",str(x["aggressorCompanyId"]),str(x["aggressorTraderCompanyName"]),str(x["aggressorTraderId"]),str(x["aggressorTraderName"]),str(x["aggressorDerivativeIndicator"]),str(x["initiatorCompanyId"]),str(x["initiatorTraderCompanyName"]),str(x["initiatorTraderId"]),str(x["initiatorTraderName"]),str(x["initiatorDerivativeIndicator"]),"")
    data.append(p)
  rdd=spark.sparkContext.parallelize(data)
  df=spark.createDataFrame(rdd)
  return df

# COMMAND ----------

  counter = 1
  def getAllTradeDF(includePrivate,instrumentId,sequenceId,sequenceItemId,from_date,until,PeriodStart, PeriodEnd,contractType):
    instrumentId=str(instrumentId)
    global counter
    global all_trade_data_list
    sequenceId=str(sequenceId)
    sequenceItemId=str(sequenceItemId)
    from_date = from_date.strftime("%Y-%m-%dT%H:%M:%SZ")
    until = until.strftime("%Y-%m-%dT%H:%M:%SZ")
    PeriodStart = PeriodStart.strftime("%Y-%m-%dT%H:%M:%SZ")
    PeriodEnd = PeriodEnd.strftime("%Y-%m-%dT%H:%M:%SZ")
    contractType = str(contractType)
    trayport_headers = getHeaders()
    url_builder = "https://analytics.trayport.com/api/trades?includePrivate="+includePrivate+"&includeEmptyBuckets=false&instrumentId="+instrumentId+"&contractType="+contractType+"&sequenceId="+sequenceId+"&sequenceItemId="+sequenceItemId+"&from="+from_date+"&until="+until
    #print(url_builder)
    data = _get(url_builder,params,trayport_headers)

    if len(data) > 0:

      df = getTradeDataFrame(instrumentId,sequenceId,sequenceItemId,PeriodStart,PeriodEnd,data)
      all_trade_data_list.append(df)
    if (counter%4==0):
      time.sleep(20)
    counter = counter+1
    if (counter%500==0):
      print("Value of counter" + str(counter))

# COMMAND ----------

  counter = 1
  def getAllOhlcvTradeDF(includePrivate,instrumentId,sequenceId,sequenceItemId,from_date,until,contractType,interval,interval_frequency):
    instrumentId=str(instrumentId)
    global counter
    global all_ohlcv_trade_data_list
    sequenceId=str(sequenceId)
    sequenceItemId=str(sequenceItemId)

    from_date = from_date.strftime("%Y-%m-%dT%H:%M:%SZ")
    until = until.strftime("%Y-%m-%dT%H:%M:%SZ")
    contractType = str(contractType)
    trayport_headers = getHeaders()
    interval_frequency = str(interval_frequency)
    interval = str(interval)
    url_builder = "https://analytics.trayport.com/api/trades/ohlcv?includeEmptyBuckets=false&instrumentId="+instrumentId+"&interval="+interval+"&intervalUnit="+interval_frequency+"&contractType="+contractType+"&sequenceId="+sequenceId+"&sequenceItemId="+sequenceItemId+"&from="+from_date+"&until="+until
    #print(url_builder)
    data = _get(url_builder,params,trayport_headers)
    #print("data:{0}".format(len(data)))
    if len(data) > 0:
      df = getOhlcvTradeDataFrame(instrumentId,sequenceId,sequenceItemId,from_date,until,data)
      all_ohlcv_trade_data_list.append(df)
    if (counter%4==0):
      time.sleep(20)
    counter = counter+1
    if (counter%500==0):
      print("Value of counter" + str(counter))  

# COMMAND ----------

all_ohlcv_trade_data_list = []
def getAllOhlcvTrades(instrument_sequenceItem_master_list1):
  global counter
  counter = 1
  global all_ohlcv_trade_data_list
  all_ohlcv_trade_data_list = []
  #until = until.replace(day=1)
  #from_date = until - timedelta(days=30)
  interval = "1"
  interval_frequency="Minute" 
  error_string = ''
  error_code = 0
  last_processed_InstrumentId = 0
  last_processed_SequenceId = 0
  last_processed_ItemId = 0
  last_processed_OriginalTradingStart = ''
  for x in instrument_sequenceItem_master_list1.toLocalIterator():
    try:    
      getAllOhlcvTradeDF("true",
      x.InstrumentID,
      x.SequenceId,
      x.ItemId,
      x.TradingStart,
      x.TradingEnd,
      "SinglePeriod",
      interval,
      interval_frequency)
      last_processed_InstrumentId = x.InstrumentID
      last_processed_SequenceId = x.SequenceId
      last_processed_ItemId = x.ItemId
      last_processed_OriginalTradingStart = x.OriginalTradingStart  
    except Exception as e:
      print("Error occurred while fetching all trades data from OHLCV API")
      error_string = "Error {0}".format(str(e)) 
      print(error_string)
      error_code = -1 
      break
  
  all_ohlcv_trade_data_list1 = spark.createDataFrame(data = [],schema = StructType([]))
  
  if (len(all_ohlcv_trade_data_list) > 0):
    all_ohlcv_trade_data_list1=reduce(DataFrame.union, all_ohlcv_trade_data_list)
  
  return all_ohlcv_trade_data_list1, error_code, error_string, last_processed_InstrumentId, last_processed_SequenceId, last_processed_ItemId, last_processed_OriginalTradingStart

# COMMAND ----------

some_list = []
if len(some_list) == 0:
  print("List is Empty")

# COMMAND ----------

all_trade_data_list = []
def getAllTrades(instrument_sequenceItem_master_list1):
  global counter
  counter = 1
  global all_trade_data_list
  all_trade_data_list = []
  #until = until.replace(day=1)
  #from_date = until - timedelta(days=30)
  error_string = ''
  error_code = 0
  last_processed_InstrumentId = 0
  last_processed_SequenceId = 0
  last_processed_ItemId = 0
  last_processed_OriginalTradingStart = ''
  
  for x in instrument_sequenceItem_master_list1.toLocalIterator():
    try:
      getAllTradeDF("true",x.InstrumentID,x.SequenceId,x.ItemId,x.TradingStart,x.TradingEnd,x.PeriodStart,x.PeriodEnd,"SinglePeriod")
      last_processed_InstrumentId = x.InstrumentID
      last_processed_SequenceId = x.SequenceId
      last_processed_ItemId = x.ItemId
      last_processed_OriginalTradingStart = x.OriginalTradingStart
    except Exception as e:
      print("Error occurred while fetching all trades data from All Trade API")
      error_string = "Error {0}".format(str(e)) 
      print(error_string)
      error_code = -1 
      break
      
  all_trade_data_list1 = spark.createDataFrame(data = [],schema = StructType([]))
  
  if (len(all_trade_data_list) > 0):
    all_trade_data_list1=reduce(DataFrame.union, all_trade_data_list)
  
  return all_trade_data_list1, error_code, error_string, last_processed_InstrumentId, last_processed_SequenceId, last_processed_ItemId, last_processed_OriginalTradingStart

# COMMAND ----------

def getOrderFrame(instrumentId,sequenceId,sequenceItemId,from_date,until,response):
  from pyspark.sql import Row
  instrumentId = instrumentId
  sequenceId = sequenceId
  sequenceItemId = sequenceItemId
  start_date = from_date
  end_date = until
  price_data = Row("instrumentId","sequenceId","sequenceItemId","timestamp","type","price","quantity","clientOrderId","orderStatus","ownerUserId","ownerCompanyId","lastModifierUserId","hiddenQuantity","originalHiddenQuantity","hiddenQtyPriceDelta","gtdExpiryTimestamp","start_date","end_date")
  data = []
  for x in response:
    timestamp = x["timestamp"]
    #data = []
    for y in x["bids"]:
      bids_type = "bids"
      order_bids_data = Row("instrumentId","sequenceId","sequenceItemId","timestamp","type","price","quantity","clientOrderId","orderStatus","ownerUserId","ownerCompanyId","lastModifierUserId","hiddenQuantity","originalHiddenQuantity","hiddenQtyPriceDelta","gtdExpiryTimestamp","start_date","end_date")
      if "privateFields" in x["bids"]:
        for z in y["privateFields"]:
          print("Private bids Order Response:".format(z))
          p = order_bids_data(instrumentId,sequenceId,sequenceItemId,timestamp,bids_type,str(y["price"]),str(y["quantity"]),str(z["clientOrderId"]),str(z["orderStatus"]),str(z["ownerUserId"]),str(z["ownerCompanyId"]),str(z["lastModifierUserId"]),str(z["hiddenQuantity"]),str(z["originalHiddenQuantity"]),str(z["hiddenQtyPriceDelta"]),str(z["gtdExpiryTimestamp"]),start_date,end_date)
      else:
        p = order_bids_data(instrumentId,sequenceId,sequenceItemId,timestamp,bids_type,str(y["price"]),str(y["quantity"]),"","","","","","","","","",start_date,end_date)
      data.append(p)
    for y in x["asks"]:
      bids_type = "asks"
      order_bids_data = Row("instrumentId","sequenceId","sequenceItemId","timestamp","type","price","quantity","clientOrderId","orderStatus","ownerUserId","ownerCompanyId","lastModifierUserId","hiddenQuantity","originalHiddenQuantity","hiddenQtyPriceDelta","gtdExpiryTimestamp","start_date","end_date")
      if "privateFields" in x["asks"]:
        for z in y["privateFields"]:
          print("Private asks Order Response:".format(z))
          p = order_bids_data(instrumentId,sequenceId,sequenceItemId,timestamp,bids_type,str(y["price"]),str(y["quantity"]),str(z["clientOrderId"]),str(z["orderStatus"]),str(z["ownerUserId"]),str(z["ownerCompanyId"]),str(z["lastModifierUserId"]),str(z["hiddenQuantity"]),str(z["originalHiddenQuantity"]),str(z["hiddenQtyPriceDelta"]),str(z["gtdExpiryTimestamp"]),start_date,end_date)
      else:
        p = order_bids_data(instrumentId,sequenceId,sequenceItemId,timestamp,bids_type,str(y["price"]),str(y["quantity"]),"","","","","","","","","",start_date,end_date)
      data.append(p)
    #print(data)
  rdd=spark.sparkContext.parallelize(data)
  #print(rdd.collect())
  df=spark.createDataFrame(rdd)
  #df.show()
  return df

# COMMAND ----------

def getOrderFrame1(instrumentId,sequenceId,sequenceItemId,from_date,until,response):
  from pyspark.sql import Row
  instrumentId = instrumentId
  sequenceId = sequenceId
  sequenceItemId = sequenceItemId
  start_date = from_date
  end_date = until
  price_data = Row("instrumentId","sequenceId","sequenceItemId","timestamp","type","price","quantity","clientOrderId","orderStatus","ownerUserId","ownerCompanyId","lastModifierUserId","hiddenQuantity","originalHiddenQuantity","hiddenQtyPriceDelta","gtdExpiryTimestamp","start_date","end_date")
  data = []
  for x in response:
    timestamp = x["timestamp"]
    #data = []
    for y in x["bids"]:
      bids_type = "bids"
      order_bids_data = Row("instrumentId","sequenceId","sequenceItemId","timestamp","type","price","quantity","clientOrderId","orderStatus","ownerUserId","ownerCompanyId","lastModifierUserId","hiddenQuantity","originalHiddenQuantity","hiddenQtyPriceDelta","gtdExpiryTimestamp","start_date","end_date")
      if "privateFields" in y.keys():
        for z in y["privateFields"]:
          p = order_bids_data(instrumentId,sequenceId,sequenceItemId,timestamp,bids_type,str(y["price"]),str(y["quantity"]),str(z["clientOrderId"]),str(z["orderStatus"]),str(z["ownerUserId"]),str(z["ownerCompanyId"]),str(z["lastModifierUserId"]),str(z["hiddenQuantity"]),str(z["originalHiddenQuantity"]),str(z["hiddenQtyPriceDelta"]),str(z["gtdExpiryTimestamp"]),start_date,end_date)
      else:
        p = order_bids_data(instrumentId,sequenceId,sequenceItemId,timestamp,bids_type,str(y["price"]),str(y["quantity"]),"","","","","","","","","",start_date,end_date)
      data.append(p)
    for y in x["asks"]:
      bids_type = "asks"
      order_bids_data = Row("instrumentId","sequenceId","sequenceItemId","timestamp","type","price","quantity","clientOrderId","orderStatus","ownerUserId","ownerCompanyId","lastModifierUserId","hiddenQuantity","originalHiddenQuantity","hiddenQtyPriceDelta","gtdExpiryTimestamp","start_date","end_date")
      if "privateFields" in y.keys():
        for z in y["privateFields"]:
          p = order_bids_data(instrumentId,sequenceId,sequenceItemId,timestamp,bids_type,str(y["price"]),str(y["quantity"]),str(z["clientOrderId"]),str(z["orderStatus"]),str(z["ownerUserId"]),str(z["ownerCompanyId"]),str(z["lastModifierUserId"]),str(z["hiddenQuantity"]),str(z["originalHiddenQuantity"]),str(z["hiddenQtyPriceDelta"]),str(z["gtdExpiryTimestamp"]),start_date,end_date)
      else:
        p = order_bids_data(instrumentId,sequenceId,sequenceItemId,timestamp,bids_type,str(y["price"]),str(y["quantity"]),"","","","","","","","","",start_date,end_date)
      data.append(p)
    #print(data)
  rdd=spark.sparkContext.parallelize(data)
  #print(rdd.collect())
  df=spark.createDataFrame(rdd)
  return df

# COMMAND ----------

counter = 1
all_order_data_list = []
def getAllOrdersDF1(includePrivate,instrumentId,sequenceId,sequenceItemId,from_date,until,contractType,interval_frequency,interval):
  global counter
  global all_order_data_list
  instrumentId=str(instrumentId)
  sequenceId=str(sequenceId)
  sequenceItemId=str(sequenceItemId)
  from_date = from_date
  until = until
  from_date = datetime.strptime(from_date, "%Y-%m-%dT%H:%M:%SZ")
  until = datetime.strptime(until, "%Y-%m-%dT%H:%M:%SZ")
  from_date = from_date.strftime("%Y-%m-%dT%H:%M:%SZ")
  until = until.strftime("%Y-%m-%dT%H:%M:%SZ")
  contractType = str(contractType)
  interval_frequency = str(interval_frequency)
  interval = str(interval)
  url_builder = "https://analytics.trayport.com/api/orders/book?includePrivate="+includePrivate+"&interval="+interval+"&intervalUnit="+interval_frequency+"&includeEmptyBuckets=false&instrumentId="+instrumentId+"&contractType="+contractType+"&sequenceId="+sequenceId+"&sequenceItemId="+sequenceItemId+"&from="+from_date+"&until="+until
  #print(url_builder)
  r = requests.get(url_builder, params, headers=headers)
  if r.status_code != 200:
    raise Exception(f'Status: {r.status_code}. {r.content.decode()}')
  #print("content:{0}".format(r.content))
  data = flatten(json.loads(r.content.decode()))
  #print("data:{0}".format(type(data)))
  df = pd.DataFrame({c: pd.Series(dtype=t) for c, t in {'timestamp': 'str','bids_price': 'str','bids_quantity': 'str','bids_privateFields_clientOrderId': 'str','bids_privateFields_orderStatus': 'str','bids_privateFields_ownerUserId': 'str','bids_privateFields_ownerCompanyId': 'str','bids_privateFields_lastModifierUserId': 'str','bids_privateFields_hiddenQuantity': 'str','bids_privateFields_originalHiddenQuantity': 'str','bids_privateFields_hiddenQtyPriceDelta': 'str','bids_privateFields_gtdExpiryTimestamp': 'str','asks_price': 'str','asks_quantity': 'str','asks_privateFields_clientOrderId': 'str','asks_privateFields_orderStatus': 'str','asks_privateFields_ownerUserId': 'str','asks_privateFields_ownerCompanyId': 'str','asks_privateFields_lastModifierUserId': 'str','asks_privateFields_hiddenQuantity': 'str','asks_privateFields_originalHiddenQuantity': 'str','asks_privateFields_hiddenQtyPriceDelta': 'str','asks_privateFields_gtdExpiryTimestamp': 'str'}.items()})
  df = pd.DataFrame(data,index=[0])
  df.fillna("",inplace=True)
  if len(df) > 0:
    if 'timestamp' in df.columns:
      df.set_index('timestamp', inplace=True)
  spark_df = spark.createDataFrame(df)
  order_column_list = ['timestamp','bids_price','bids_quantity','bids_privateFields_clientOrderId','bids_privateFields_orderStatus','bids_privateFields_ownerUserId','bids_privateFields_ownerCompanyId','bids_privateFields_lastModifierUserId','bids_privateFields_hiddenQuantity','bids_privateFields_originalHiddenQuantity','bids_privateFields_hiddenQtyPriceDelta','bids_privateFields_gtdExpiryTimestamp','asks_price','asks_quantity','asks_privateFields_clientOrderId','asks_privateFields_orderStatus','asks_privateFields_ownerUserId','asks_privateFields_ownerCompanyId','asks_privateFields_lastModifierUserId','asks_privateFields_hiddenQuantity','asks_privateFields_originalHiddenQuantity','asks_privateFields_hiddenQtyPriceDelta','asks_privateFields_gtdExpiryTimestamp']
  for x in order_column_list:
    if(x.upper() not in (name.upper() for name in spark_df.columns)):
      spark_df = spark_df.withColumn(x,lit(""))
  columns_list = spark_df.columns
  all_order_data_list.append(spark_df)

# COMMAND ----------

counter = 1
def getAllOrdersDF(includePrivate,instrumentId,sequenceId,sequenceItemId,from_date,until,contractType,interval_frequency,interval):
  global counter
  global all_order_data_list
  instrumentId=str(instrumentId)
  sequenceId=str(sequenceId)
  sequenceItemId=str(sequenceItemId)
  from_date = from_date
  until = until
  #print("from_date:{0}".format(type(from_date)))
  #print("until:{0}".format(type(until)))
  #from_date = datetime.strptime(from_date, "%Y-%m-%dT%H:%M:%SZ")
  #until = datetime.strptime(until, "%Y-%m-%dT%H:%M:%SZ")
  #print("from_date2:{0}".format(type(from_date)))
  #print("until2:{0}".format(type(until)))
  #from_date = from_date.strftime("%Y-%m-%dT%H:%M:%SZ")
  #until = until.strftime("%Y-%m-%dT%H:%M:%SZ")
  #print("from_date1:{0}".format(type(from_date)))
  #print("until1:{0}".format(type(until)))
  left_mid_time = from_date.replace(minute=0)
  left_mid_time = from_date.replace(second=0)
  left_mid_time = from_date.replace(hour=12)
  right_mid_time = from_date.replace(minute=0)
  right_mid_time = from_date.replace(second=1)
  right_mid_time = from_date.replace(hour=12)
  left_mid_time = left_mid_time.strftime("%Y-%m-%dT%H:%M:%SZ")
  right_mid_time = right_mid_time.strftime("%Y-%m-%dT%H:%M:%SZ")
  left_mid_time = datetime.strptime(left_mid_time, "%Y-%m-%dT%H:%M:%SZ")
  right_mid_time = datetime.strptime(right_mid_time, "%Y-%m-%dT%H:%M:%SZ")
  right_mid_time = left_mid_time+timedelta(minutes = 1)
  #print("left_mid_time:{0}".format(left_mid_time))
  #print("right_mid_time:{0}".format(right_mid_time))
  from_date = from_date.strftime("%Y-%m-%dT%H:%M:%SZ")
  until = until.strftime("%Y-%m-%dT%H:%M:%SZ")
  left_mid_time = left_mid_time.strftime("%Y-%m-%dT%H:%M:%SZ")
  right_mid_time = right_mid_time.strftime("%Y-%m-%dT%H:%M:%SZ")
  contractType = str(contractType)
  interval_frequency = str(interval_frequency)
  interval = str(interval)
  intCounter = 0
  while(intCounter<2):
    if intCounter == 0:
      url_builder = "https://analytics.trayport.com/api/orders/book?includePrivate="+includePrivate+"&depth=1&interval="+interval+"&intervalUnit="+interval_frequency+"&includeEmptyBuckets=false&instrumentId="+instrumentId+"&contractType="+contractType+"&sequenceId="+sequenceId+"&sequenceItemId="+sequenceItemId+"&from="+from_date+"&until="+left_mid_time
    else:
      url_builder = "https://analytics.trayport.com/api/orders/book?includePrivate="+includePrivate+"&depth=1&interval="+interval+"&intervalUnit="+interval_frequency+"&includeEmptyBuckets=false&instrumentId="+instrumentId+"&contractType="+contractType+"&sequenceId="+sequenceId+"&sequenceItemId="+sequenceItemId+"&from="+right_mid_time+"&until="+until
    print(url_builder)
    data = _get(url_builder,params,headers)
    time.sleep(0.1)
  #print("data:{0}".format(data))
  #print("Order Response:".format(x))
    if len(data) > 0:
      df = getOrderFrame(instrumentId,sequenceId,sequenceItemId,from_date,until,data)
      all_order_data_list.append(df)
    #print("all_order_data_listDF:{0}".format(all_order_data_list))
    if (counter%4==0):
      time.sleep(35)
    counter = counter+1
    intCounter = intCounter+1
  

# COMMAND ----------

#%sh ls -ltr /dbfs/FileStore/all_order_Data/df_021220221/part-00000-tid-452851143174222728-5d70ce72-a560-4020-8523-a7b2f74d6c33-248281-1-c000.csv

# COMMAND ----------

def getAllOrders(instrument_sequenceItem_master_list1):
  global counter
  counter=1
  global all_order_data_list
  all_order_data_list = []
#   until = datetime.now() -timedelta(days=17)
#     until = until.replace(minute=0)
#     until = until.replace(second=0)
#     until = until.replace(hour=0)
#     from_date = from_date.replace(minute=0)
#     from_date = from_date.replace(second=0)
#     from_date = from_date.replace(hour=0)
  interval = "1"
  interval_frequency="Second"
  contractType = "SinglePeriod"
  for x in instrument_sequenceItem_master_list1.toLocalIterator():
    getAllOrdersDF("true",x.InstrumentID,x.SequenceId,x.ItemId,x.TradingStart,x.TradingEnd,contractType,interval_frequency,interval)
  #print("all_order_data_list:{0}".format(all_order_data_list))
  all_order_data_list1=reduce(DataFrame.union, all_order_data_list)
  #print("all_order_data_list1:{0}".format(type(all_order_data_list1)))
  return all_order_data_list1

# COMMAND ----------

# all_order_data_list1=reduce(DataFrame.union, all_order_data_list)

# COMMAND ----------

counter = 1
def getAllTradePrivateDF(sequenceId,sequenceItemId,from_date,until,PeriodStart,PeriodEnd,contractType):
  global counter
  global all_trade_data_list
  sequenceId=str(sequenceId)
  sequenceItemId=str(sequenceItemId)
  from_date = from_date.strftime("%Y-%m-%dT%H:%M:%SZ")
  until = until.strftime("%Y-%m-%dT%H:%M:%SZ")
  PeriodStart = PeriodStart.strftime("%Y-%m-%dT%H:%M:%SZ")
  PeriodEnd = PeriodEnd.strftime("%Y-%m-%dT%H:%M:%SZ")
  contractType = str(contractType)
  trayport_headers = getHeaders()
  url_builder = "https://analytics.trayport.com/api/trades/private?contractType="+contractType+"&sequenceId="+sequenceId+"&sequenceItemId="+sequenceItemId+"&from="+from_date+"&until="+until
  #print(url_builder)
  data = _get(url_builder,params,trayport_headers)
  #print("data:{0}".format(len(data)))
  if len(data) > 0:
    df = getPrivateTradeDataFrame(sequenceId,sequenceItemId,PeriodStart,PeriodEnd,from_date,until,data)
    all_trade_data_list.append(df)
  if (counter%4==0):
    time.sleep(20)
  counter = counter+1
  if (counter % 500 == 0):
      print("Value of counter" + str(counter))

# COMMAND ----------

all_trade_data_list = []
def getAllPrivateTrades(instrument_sequenceItem_master_list1):
  global counter
  counter = 1
  global all_trade_data_list
  all_trade_data_list = []
  error_string = ''
  error_code = 0
  last_processed_InstrumentId = 0
  last_processed_SequenceId = 0
  last_processed_ItemId = 0
  last_processed_OriginalTradingStart = ''
  instrument_sequenceItem_master_list1 = instrument_sequenceItem_master_list1.drop("InstrumentID").dropDuplicates(["SequenceId","ItemId"])
  for x in instrument_sequenceItem_master_list1.toLocalIterator():
    try:
      getAllTradePrivateDF(x.SequenceId, x.ItemId, x.TradingStart, x.TradingEnd, x.PeriodStart, 
                           x.PeriodEnd, "SinglePeriod")
      last_processed_SequenceId = x.SequenceId
      last_processed_ItemId = x.ItemId
      last_processed_OriginalTradingStart = x.OriginalTradingStart
    except Exception as e:
      print("Error occurred while fetching all private data from All Private Trade API")
      error_string = "Error {0}".format(str(e))
      print(error_string)
      error_code = -1
      break
  
  all_trade_data_list1 = spark.createDataFrame(data=[], schema=StructType([]))
  if (len(all_trade_data_list) > 0):
     all_trade_data_list1=reduce(DataFrame.union, all_trade_data_list)

  return all_trade_data_list1, error_code, error_string, last_processed_InstrumentId, last_processed_SequenceId, last_processed_ItemId, last_processed_OriginalTradingStart

# COMMAND ----------

def getActivityTradeDataFrame(from_date,until,response):
  from pyspark.sql import Row
  start_date = from_date
  end_date = until
  price_data = Row("start_date","end_date","contractType","secondSequenceItemId","sequenceItemId","sequenceId","instrumentId","count")
  data = []
  for x in response:
    p = price_data(start_date,end_date,str(x["contractType"]),str(x["secondSequenceItemId"]),str(x["sequenceItemId"]),str(x["sequenceId"]),str(x["instrumentId"]),str(x["count"]))
    data.append(p)
    #print(data)
  rdd=spark.sparkContext.parallelize(data)
  #print(rdd.collect())
  df=spark.createDataFrame(rdd)
  df = df.withColumnRenamed("instrumentId","InstrumentID").withColumnRenamed("sequenceId","SequenceId").withColumnRenamed("sequenceItemId","ItemId").withColumnRenamed("start_date","TradingStart").withColumnRenamed("end_date","TradingEnd")
  return df

# COMMAND ----------

def getActivityTrades():
  all_activity_trade_data_list = []
  until = datetime.now() #-timedelta(days=1)
  until = until.replace(minute=0)
  until = until.replace(second=0)
  until = until.replace(hour=0)
  #until = until.replace(day=1)
  from_date = until - timedelta(days=1)
  from_date = from_date.strftime("%Y-%m-%dT%H:%M:%SZ")
  until = until.strftime("%Y-%m-%dT%H:%M:%SZ")
  url_builder = "https://analytics.trayport.com/api/trades/activity?from="+from_date+"&until="+until
  data = _get(url_builder,params,headers)
  #print("data:{0}".format(len(data)))
  #print("data:{0}".format(data))
  if len(data) > 0:
    df = getActivityTradeDataFrame(from_date,until,data)
    df.createOrReplaceTempView("Activity_Trades")
    return df
  return ""

# COMMAND ----------

from datetime import datetime

# COMMAND ----------

from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import *
def readDatasetConfigAndCreateTempView_Trade_NextK_WithSPN(spark, source_etrm, dataset_name, read_format, view_name,extract_date,LAND_PATH):
  #adls_path = getDatasetConfigForTheTable(spark,source_etrm,dataset_name)
  #print(adls_path)
  file_path = "/mnt/ADLS"+LAND_PATH+"ORIGINAL_FILE/"+extract_date+"/INTRADAY_TRADE_DATA.xlsx"
  print("file_path:{0}".format(file_path))
  df = spark.read.format(read_format).option("header", "true").load(file_path)
  #df = df.drop("_c0")
  df = df.withColumnRenamed("Input Date","Trade_Date").withColumnRenamed("Internal ID","Trade_ID").withColumnRenamed("Counterparty.Misc","Venue").withColumnRenamed("TSO.Fullname","Market_Area").withColumnRenamed("Quality.Description","Delivery_Segment").withColumnRenamed("Delivery Begin","Delivery_Start").withColumnRenamed("Delivery End","Delivery_End").withColumnRenamed("Avg Power(MW)","Quantity").withColumnRenamed("User.Shortname","Trader").withColumnRenamed("Price Description.Core","Price_Description_Core")
  df = df.withColumn('Price', split(df['Price_Description_Core'], ' ').getItem(0)).withColumn('Currency', split((split(df['Price_Description_Core'], ' ').getItem(1)), '/').getItem(0)).withColumn('UOM',  split((split(df['Price_Description_Core'], ' ').getItem(1)), '/').getItem(1))
  df = df.withColumn("Price",regexp_replace('Price', ',', '.'))
  df = df.withColumn("Trade_ID",df.Trade_ID.cast('string'))
  df = df.withColumn("Venue",df.Venue.cast('string'))
  df = df.withColumn("Market_Area",df.Market_Area.cast('string'))
  df = df.withColumn("Delivery_Segment",df.Delivery_Segment.cast('string'))
  df = df.withColumn("Trade_Date", to_timestamp("Trade_Date", "dd.MM.yyyy HH:mm"))
  df = df.withColumn("Delivery_Start", to_timestamp("Delivery_Start", "dd.MM.yyyy"))
  df = df.withColumn("Delivery_End", to_timestamp("Delivery_End", "dd.MM.yyyy"))
  df = df.withColumn("Price",df.Price.cast('decimal(18,3)'))
  df = df.withColumn("Quantity",regexp_replace(col("Quantity"), ",", "."))
  df = df.withColumn("Quantity",df.Quantity.cast('decimal(18,3)'))
  df = df.withColumn("Currency",df.Currency.cast('string'))
  df = df.withColumn("UOM",df.UOM.cast('string'))
  df = df.withColumn("Trader",df.Trader.cast('string'))
  df = df.na.fill(0)
  df = df.withColumnRenamed("Trade_Date","TRADE_DATE").withColumnRenamed("Trade_ID","TRADE_ID").withColumnRenamed("Venue","VENUE").withColumnRenamed("Market_Area","MARKET_AREA").withColumnRenamed("Delivery_Segment","DELIVERY_SEGMENT").withColumnRenamed("Delivery_Start","DELIVERY_START_DATE").withColumnRenamed("Delivery_End","DELIVERY_END_DATE").withColumnRenamed("Quantity","QUANTITY").withColumnRenamed("UOM","UOM").withColumnRenamed("Price","PRICE").withColumnRenamed("Currency","CURRENCY").withColumnRenamed("","PARTICIPANT").withColumnRenamed("Trader","TRADER")
  #df = df.select("Trade_Date","Trade_ID","Venue","Market_Area","Delivery_Segment","Delivery_Start","Delivery_End","Quantity","Price","Currency","UOM","Trader")
  df = df.select("TRADE_DATE","TRADE_ID","VENUE","MARKET_AREA","DELIVERY_SEGMENT","DELIVERY_START_DATE","DELIVERY_END_DATE","QUANTITY","UOM","PRICE","CURRENCY","TRADER")
  df.createOrReplaceTempView(view_name)
  df = spark.sql("select * from {0}".format(view_name))
  df.createOrReplaceTempView(view_name)
  return df

# COMMAND ----------

from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import *
def readDatasetConfigAndCreateTempView_Auction_NextK_WithSPN(spark, source_etrm, dataset_name, read_format, view_name,extract_date,LAND_PATH):
  #adls_path = getDatasetConfigForTheTable(spark,source_etrm,dataset_name)
  #print(adls_path)
  
  file_path = "/mnt/ADLS"+LAND_PATH+"ORIGINAL_FILE/"+extract_date+"/INTRADAY_AUCTION_DATA.xlsx"
  df = spark.read.format(read_format).option("header", "true").load(file_path)
  df = df.withColumnRenamed("Trade_Date","TRADE_DATE").withColumnRenamed(" Trade_ID","TRADE_ID").withColumnRenamed(" Venue","VENUE").withColumnRenamed("Auction_Market_Area","AUCTION_MARKET_AREA").withColumnRenamed("Delivery_Segment","DELIVERY_SEGMENT").withColumnRenamed("Delivery_Start","DELIVERY_START_DATE").withColumnRenamed("Delivery_End","DELIVERY_END_DATE").withColumnRenamed("Participant_Volume","PARTICIPANT_VOLUME").withColumnRenamed("Volume_UOM","VOLUME_UOM").withColumnRenamed("Total_Cleared_Volume","TOTAL_CLEARED_VOLUME").withColumnRenamed("Cleared_Price","CLEARED_PRICE").withColumnRenamed("Price_Currency","PRICE_CURRENCY")
  df.createOrReplaceTempView(view_name)
  df = spark.sql("select * from {0}".format(view_name))
  df.createOrReplaceTempView(view_name)
  return df

# COMMAND ----------

def filter_based_on_last_watermark(instrumentDf,LAST_OFFSET_VALUE):
  last_processed_tradingStart = ''
  last_processed_instrumentId = ''
  last_processed_sequenceId = ''
  last_processed_itemId = ''
  instrumentDf.createOrReplaceTempView("InsSeqData")
  filteredInstrumentDf = instrumentDf
  if (LAST_OFFSET_VALUE != ''):
    values = LAST_OFFSET_VALUE.split("|")
    print(values)
    last_processed_tradingStart = values[0]
    last_processed_instrumentId = int(values[1])
    last_processed_sequenceId = int(values[2])
    last_processed_itemId = int(values[3])
    query = "select * from InsSeqData where OriginalTradingStart > to_timestamp('{0}')".format(last_processed_tradingStart)
    print(query)
    df1 = spark.sql(query)
    query = "select * from InsSeqData where OriginalTradingStart = to_timestamp('{0}') and InstrumentId > {1}".format(last_processed_tradingStart, last_processed_instrumentId)
    print(query)
    df2 = spark.sql(query)
    query = "select * from InsSeqData where OriginalTradingStart = to_timestamp('{0}') and InstrumentId = {1} and SequenceId > {2}".format(last_processed_tradingStart, last_processed_instrumentId, last_processed_sequenceId)
    print(query)
    df3 = spark.sql(query)
    query = "select * from InsSeqData where OriginalTradingStart = to_timestamp('{0}') and InstrumentId = {1} and SequenceId = {2} and ItemId > {3}".format(last_processed_tradingStart, last_processed_instrumentId, last_processed_sequenceId, last_processed_itemId)
    print(query)
    df4 = spark.sql(query)
    filteredInstrumentDf = df1
    filteredInstrumentDf = filteredInstrumentDf.union(df2)
    filteredInstrumentDf = filteredInstrumentDf.union(df3)
    filteredInstrumentDf = filteredInstrumentDf.union(df4)
    
    
    
    
    
  return filteredInstrumentDf

# COMMAND ----------

def save_as_single_file_with_custom_name(dfToBeSaved,folderName, extract_Date, LAND_PATH):
    adls_path = "/mnt/ADLS"+LAND_PATH+"TRANSFORMED_FILE/" + folderName + "/"+extract_Date+"/"
    print(adls_path)
    dfToBeSaved.coalesce(1).write.mode('overwrite').option("compression","uncompressed").format("avro").save(adls_path)
    #dfToBeSaved.coalesce(1).write.mode('overwrite').format("avro").save(adls_path)
    #writeDatasetSynapseConnector(spark,Instrument_df,"Epex_All_Ins_Seq_Data")
    adls_path = "/dbfs/mnt/ADLS"+LAND_PATH+"TRANSFORMED_FILE/" + folderName + "/"+extract_Date+"/"
    target_adls_path = LAND_PATH+"TRANSFORMED_FILE/"
    target_file_name = folderName + "_"+extract_Date+".avro"
    target_final_path = target_adls_path+target_file_name
    all_files = glob.glob(os.path.join(adls_path , "part*"))
    
    for filename in all_files:
      src_file_name = filename.split('dbfs')[1]
      
    dbutils.fs.mv(src_file_name,"/mnt/ADLS"+target_final_path)
    final_extract_date = extract_Date[0:4]+"-"+extract_Date[4:6]+"-"+extract_Date[6:]
    target_file_name1 = folderName + "_"+final_extract_date+".avro"
    target_final_path1 = target_adls_path+target_file_name1
    dbutils.fs.cp("/mnt/ADLS"+target_final_path,"/mnt/ADLS"+target_final_path1)
    dbutils.fs.cp("/mnt/ADLS"+target_final_path1,"/mnt/ADLS"+target_adls_path+ folderName +".avro")
