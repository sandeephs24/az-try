# Databricks notebook source
extract_Date = dbutils.widgets.get("extract_Date")
LAND_PATH = dbutils.widgets.get("LAND_PATH")
print(extract_Date)

print(LAND_PATH)

# COMMAND ----------

# MAGIC %run ./../Trayport/Reader_connections_Updated

# COMMAND ----------

import datetime
SequenceItemReportFilepath = '/mnt/ADLS'+LAND_PATH+'SequenceItemReport.csv'
from_trading_start = extract_Date.split(" ")[0] + " 00:00:00"
currentDate_withZeroTimestamp = datetime.datetime.now().strftime("%Y-%m-%d") + " 00:00:00"
to_trading_end = currentDate_withZeroTimestamp
joinedInsSeqDataDF, totalSeqMasterCount, totalSFTPFileCount = getSequenceItemJoinDFSTFP2(from_trading_start, to_trading_end, SequenceItemReportFilepath)
joinedInsSeqDataDF = joinedInsSeqDataDF.dropDuplicates(["InstrumentID","SequenceId","ItemId"])


# COMMAND ----------

import os
def write_to_landing1(Instrument_df, LAND_PATH ):
  extract_Date = datetime.datetime.now().strftime("%Y%m%d")
  currentDateTimestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
  if Instrument_df.count()>0:
    df = Instrument_df
    Instrument_df.createOrReplaceGlobalTempView("ALL_INS_SEQ_DATA")
    adls_path = "/mnt/ADLS"+LAND_PATH+"TRANSFORMED_FILE/ALL_INS_SEQ_SFTP_DATA/"+extract_Date+"/"
    df.coalesce(1).write.mode('overwrite').option("compression","uncompressed").format("avro").save(adls_path)
    adls_path = "/dbfs/mnt/ADLS"+LAND_PATH+"TRANSFORMED_FILE/ALL_INS_SEQ_SFTP_DATA/"+extract_Date+"/"
    target_adls_path = LAND_PATH+"TRANSFORMED_FILE/"
    target_file_name = "ALL_INS_SEQ_SFTP_DATA_"+extract_Date+".avro"
    target_final_path = target_adls_path+target_file_name
    #print(adls_path)
    #dbutils.fs.ls(adls_path)
    all_files = glob.glob(os.path.join(adls_path , "part*"))
    #print(all_files)
    for filename in all_files:
      #print(filename)
      src_file_name = filename.split('dbfs')[1]
    #dbutils.fs.ls(src_file_name,target_file_name)
    dbutils.fs.mv(src_file_name,"/mnt/ADLS"+target_final_path)
    final_extract_date = extract_Date[0:4]+"-"+extract_Date[4:6]+"-"+extract_Date[6:]
    target_file_name1 = "ALL_INS_SEQ_SFTP_DATA_"+final_extract_date+".avro"
    target_final_path1 = target_adls_path+target_file_name1
    dbutils.fs.cp("/mnt/ADLS"+target_final_path,"/mnt/ADLS"+target_final_path1)
    dbutils.fs.cp("/mnt/ADLS"+target_final_path1,"/mnt/ADLS"+target_adls_path+"ALL_INS_SEQ_SFTP_DATA.avro")

# COMMAND ----------

def get_maxTradingStart_watermark(Instrument_df):
  Instrument_df.createOrReplaceTempView("ALL_INS_SEQ_DATA1")
  maxOffsetQuery = "select max(OriginalTradingStart) max_trading_start from ALL_INS_SEQ_DATA1"
  maxOffsetDF = spark.sql(maxOffsetQuery)
  maxTradingStart=maxOffsetDF.select('max_trading_start').collect()[0][0]
  print(maxTradingStart)
  return maxTradingStart

# COMMAND ----------

if joinedInsSeqDataDF.count()>0:
  
  write_to_landing1(joinedInsSeqDataDF, LAND_PATH)
  maxTradingStart = get_maxTradingStart_watermark(joinedInsSeqDataDF)
  
  
  jsonResponse = '{"DatabricksReturnJson": {'
  jsonResponse = jsonResponse + '"' + 'maxTradingStart' + '":"' + str(maxTradingStart) + '"' + ','
  jsonResponse = jsonResponse + '"' + 'TotalRecordWrittenToAvroFile' + '":"' + str(joinedInsSeqDataDF.count()) + '"' + ','
  jsonResponse = jsonResponse + '"' + 'from_trading_start' + '":"' + str(from_trading_start) + '"' + ','
  jsonResponse = jsonResponse + '"' + 'to_trading_end' + '":"' + str(to_trading_end) + '"' + ','
  jsonResponse = jsonResponse + '"' + 'totalSeqMasterCount' + '":"' + str(totalSeqMasterCount) + '"' + ','
  jsonResponse = jsonResponse + '"' + 'totalSFTPFileCount' + '":"' + str(totalSFTPFileCount) + '"'


  jsonResponse = jsonResponse + '}}'
  dbutils.notebook.exit(jsonResponse)

# COMMAND ----------


