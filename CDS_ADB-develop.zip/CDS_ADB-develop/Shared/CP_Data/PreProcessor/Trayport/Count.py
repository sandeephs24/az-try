# Databricks notebook source
df = spark.read.format("avro").load("/mnt/ADLS/RAW/W01029-TRAYPORT_ANALYTICS_MARKET_ORDER_TEST/TRANSFORMED_FILE/ALL_INS_SEQ_SFTP_DATA.avro")

print("ALL_INS_SEQ_SFTP_DATA:" + str(df.count()))

df = spark.read.format("avro").load("/mnt/ADLS/RAW/W01029-TRAYPORT_ANALYTICS_MARKET_ORDER_TEST/TRANSFORMED_FILE/Epex_AllPrivateTrade_Data.avro")

print("Epex_AllPrivateTrade_Data:" + str(df.count()))

df = spark.read.format("avro").load("/mnt/ADLS/RAW/W01029-TRAYPORT_ANALYTICS_MARKET_ORDER_TEST/TRANSFORMED_FILE/Epex_AllTrade_Data.avro")

print("Epex_AllTrade_Data:" + str(df.count()))

df = spark.read.format("avro").load("/mnt/ADLS/RAW/W01029-TRAYPORT_ANALYTICS_MARKET_ORDER_TEST/TRANSFORMED_FILE/Epex_All_Ohlcv_Trade_Data.avro")

print("Epex_All_Ohlcv_Trade_Data:"+ str(df.count()))
