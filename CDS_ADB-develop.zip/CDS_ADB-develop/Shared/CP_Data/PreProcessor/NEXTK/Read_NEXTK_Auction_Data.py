# Databricks notebook source
# MAGIC %run /Shared/CP_Data/Config/config

# COMMAND ----------

# MAGIC %run ./WidgetUtil

# COMMAND ----------

SOURCE_PATH = AddAndGetWidgetParameterToNotebook("SOURCE_PATH")
SOURCE_FILE = AddAndGetWidgetParameterToNotebook("SOURCE_FILE")
LAND_PATH= AddAndGetWidgetParameterToNotebook("LAND_PATH")
PERIOD_TYPE= AddAndGetWidgetParameterToNotebook("PERIOD_TYPE")


# COMMAND ----------

import csv
import glob
import os
import pandas as pd
import datetime 
import numpy as np
from pyspark import SparkContext
from pyspark.sql import SQLContext
import pandavro as pdx
import csv
import glob
import os
import pandas as pd
import datetime 
import numpy as np
from pyspark import SparkContext
from pyspark.sql import SQLContext
import pandavro as pdx
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.functions import *
from IPython.display import display, Markdown, HTML
import requests
import json


path = SOURCE_PATH 
all_files = glob.glob(os.path.join(path ,SOURCE_FILE))
read_format ='csv'

for filename in all_files:
                 #filename1 = str(SOURCE_FILE.split("/")[1])
                 filename1 = filename.replace("/dbfs","")
                 df = spark.read.format(read_format).option("header", "true").load(filename1)
                 df = df.withColumnRenamed("Trade_Date","TRADE_DATE").withColumnRenamed(" Trade_ID","TRADE_ID").withColumnRenamed(" Venue","VENUE").withColumnRenamed("Auction_Market_Area","AUCTION_MARKET_AREA").withColumnRenamed("Delivery_Segment","DELIVERY_SEGMENT").withColumnRenamed("Delivery_Start","DELIVERY_START_DATE").withColumnRenamed("Delivery_End","DELIVERY_END_DATE").withColumnRenamed("Participant_Volume","PARTICIPANT_VOLUME").withColumnRenamed("Volume_UOM","VOLUME_UOM").withColumnRenamed("Total_Cleared_Volume","TOTAL_CLEARED_VOLUME").withColumnRenamed("Cleared_Price","CLEARED_PRICE").withColumnRenamed("Price_Currency","PRICE_CURRENCY")
                 pandas_df = df.toPandas()
                 #display(pandas_df)
                 SOURCE_FILE_END = str(SOURCE_FILE.split(".")[0])
                 LAND_FULL_PATH = LAND_PATH +'/'+SOURCE_FILE_END + '.avro'
                 #LAND_FULL_PATH = LAND_PATH +'/'+SOURCE_FILE
                 pdx.to_avro(LAND_FULL_PATH, pandas_df)
        




# COMMAND ----------


