# Databricks notebook source
#%fs ls /mnt/ADLS/RAW/W01026-TCP_MARKET_ORDER_DEV/TRANSFORMED_FILE/

# COMMAND ----------

#dbutils.fs.mkdirs("/mnt/ADLS/RAW/W01026-TCP_MARKET_ORDER_DEV/TRANSFORMED_FILE")

# COMMAND ----------

# MAGIC %run /Shared/CP_Data/Config/config

# COMMAND ----------

# MAGIC %run ./WidgetUtil

# COMMAND ----------

SOURCE_PATH = AddAndGetWidgetParameterToNotebook("SOURCE_PATH")
SOURCE_FILE = AddAndGetWidgetParameterToNotebook("SOURCE_FILE")
LAND_PATH= AddAndGetWidgetParameterToNotebook("LAND_PATH")

# COMMAND ----------

import csv
import glob
import os
import pandas as pd
import numpy as np
from pyspark import SparkContext
from pyspark.sql import SQLContext
import pandavro as pdx

path = SOURCE_PATH
print(path)
 
all_files = glob.glob(os.path.join(path ,SOURCE_FILE))
print(all_files)
for filename in all_files:
   
    print(filename)
    delimiter = ';'
    max_columns = max(open(filename, 'r'), key = lambda x: x.count(delimiter)).count(delimiter)
    df = pd.read_csv(filename,sep =';', header = None, skiprows = None, names = list(range(0,max_columns)))
    df
    
    if(SOURCE_FILE == 'DE-AMP-PWR-MRC-D+1'):
        stringtosearch = 'DE-AMP'
        currencytodrop = 'EUR'
        currencycolumntorename = 'GBP'
        currencycolumnrename ='EUR_TO_GBP_RATE'
        DELIVERY_PERIOD='DATE TIME - 60 MINUTE GRAIN'
        Market_area='DE-LU'
        
    if(SOURCE_FILE == 'FR-RTE-PWR-MRC-D+1'):
        stringtosearch = 'FR-RTE'
        currencytodrop = 'EUR'
        currencycolumntorename = 'GBP'
        currencycolumnrename ='EUR_TO_GBP_RATE'
        DELIVERY_PERIOD='DATE TIME - 60 MINUTE GRAIN'
        Market_area='FR'
    ### start of Target dataset #1
    #display(df)
    df1 = df[df.apply(lambda x: x.str.contains('Area set|Auction date time|Auction name|GBP|Period duration')).any(axis=1)]
    #df1
    #dfy=df.set_index([0])
    df3= df.set_index([0]).loc[stringtosearch:df.iloc[-1,0]].reset_index()
    new_header = df3.iloc[0]#grab the first row for the header
    df4 = df3[1:] #take the data less the header row
    df4.columns = new_header 
    #df4
    df5=df4
    ##first convert your columns to a series then apply a cumulative count cumcount to a boolean condition which is True if there is a null occurrence. then use the conditional value to fill the null values.
    col_na = pd.Series(df5.columns)
    #print(col_na)
    col_na = col_na.fillna('unnamed:' + (col_na.groupby(col_na.isnull()).cumcount() + 1).astype(str))
    #print(col_na)
    df5.columns = col_na
    #df5
    df2 =  df5.loc[:,stringtosearch] # extract first column of df5 to set delivery period
    # slice from 'Participant: SHELL' to Portfolio: SHELL-T01
    df6 = df5.loc[:, 'Participant: SHELL':'Portfolio: SHELL-T01']
    df6= df6.drop('Portfolio: SHELL-T01', axis=1)
    df6.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df6.insert(1,'VOLUME_UOM','MWH')
    df6.insert(2, 'PARTICIPANT', 'SHELL TOTAL')
    df6= pd.concat([df2,df6], axis=1)
    df6 = df6.iloc[2:]
    headers = ['DELIVERY_PERIOD','DELIVERY_PERIOD_TYPE','VOLUME_UOM','PARTICIPANT','SCHEDULED_NET','SCHEDULED_PURCHASED','SCHEDULED_SALE','LINEAR_SCHEDULED_NET','LINEAR_SCHEDULED_PURCHASED','LINEAR_SCHEDULED_SALE','BLOCK_SCHEDULED_NET','BLOCK_SCHEDULED_PURCHASED','BLOCK_SCHEDULED_SALE','COMPLEX_SCHEDULED_NET','COMPLEX_SCHEDULED_PURCHASED','COMPLEX_SCHEDULED_SALE']
    df6.columns = headers
    #df6
    # slice from 'Portfolio: SHELL-T01' to Portfolio: SHELL-T02
    df7 = df5.loc[:, 'Portfolio: SHELL-T01':'Portfolio: SHELL-T02']
    df7= df7.drop('Portfolio: SHELL-T02', axis=1)
    df7.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df7.insert(1,'VOLUME_UOM','MWH')
    df7.insert(2, 'PARTICIPANT', 'SHELL-T01')
    df7= pd.concat([df2,df7], axis=1)
    df7 = df7.iloc[2:]
    df7.columns = headers
    #df7
    # slice from 'Portfolio: SHELL-T02' to Portfolio: SHELL-T03
    df8 = df5.loc[:, 'Portfolio: SHELL-T02':'Portfolio: SHELL-T03']
    df8= df8.drop('Portfolio: SHELL-T03', axis=1)
    df8.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df8.insert(1,'VOLUME_UOM','MWH')
    df8.insert(2, 'PARTICIPANT', 'SHELL-T02')
    df8= pd.concat([df2,df8], axis=1)
    df8 = df8.iloc[2:]
    df8.columns = headers
    #df8
    # slice from 'Portfolio: SHELL-T03' to Portfolio: SHELL-T04
    df9 = df5.loc[:, 'Portfolio: SHELL-T03':'Portfolio: SHELL-T04']
    df9= df9.drop('Portfolio: SHELL-T04', axis=1)
    df9.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df9.insert(1,'VOLUME_UOM','MWH')
    df9.insert(2, 'PARTICIPANT', 'SHELL-T03')
    df9= pd.concat([df2,df9], axis=1)
    df9 = df9.iloc[2:]
    df9.columns = headers
    #df9
    # slice from 'Portfolio: SHELL-T04' to Portfolio: SHELL-T05
    df10 = df5.loc[:, 'Portfolio: SHELL-T04':'Portfolio: SHELL-T05']
    df10= df10.drop('Portfolio: SHELL-T05', axis=1)
    df10.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df10.insert(1,'VOLUME_UOM','MWH')
    df10.insert(2, 'PARTICIPANT', 'SHELL-T04')
    df10= pd.concat([df2,df10], axis=1)
    df10 = df10.iloc[2:]
    df10.columns = headers
    #df10
    # slice from 'Portfolio: SHELL-T05' to Portfolio: SHELL-T06
    df11 = df5.loc[:, 'Portfolio: SHELL-T05':'Portfolio: SHELL-T06']
    df11= df11.drop('Portfolio: SHELL-T06', axis=1)
    df11.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df11.insert(1,'VOLUME_UOM','MWH')
    df11.insert(2, 'PARTICIPANT', 'SHELL-T05')
    df11= pd.concat([df2,df11], axis=1)
    df11 = df11.iloc[2:]
    df11.columns = headers
    #df11
    # slice from 'Portfolio: SHELL-T06' to Portfolio: SHELL-T07
    df12 = df5.loc[:, 'Portfolio: SHELL-T06':'Portfolio: SHELL-T07']
    df12= df12.drop('Portfolio: SHELL-T07', axis=1)
    df12.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df12.insert(1,'VOLUME_UOM','MWH')
    df12.insert(2, 'PARTICIPANT', 'SHELL-T06')
    df12= pd.concat([df2,df12], axis=1)
    df12 = df12.iloc[2:]
    df12.columns = headers
    #df12
    # slice from 'Portfolio: SHELL-T07' to Portfolio: SHELL-T08
    df13 = df5.loc[:, 'Portfolio: SHELL-T07':'Portfolio: SHELL-T08']
    df13= df13.drop('Portfolio: SHELL-T08', axis=1)
    df13.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df13.insert(1,'VOLUME_UOM','MWH')
    df13.insert(2, 'PARTICIPANT', 'SHELL-T07')
    df13= pd.concat([df2,df13], axis=1)
    df13 = df13.iloc[2:]
    df13.columns = headers
    #df13
    # slice from 'Portfolio: SHELL-T08' to Portfolio: SHELL-T09
    df14 = df5.loc[:, 'Portfolio: SHELL-T08':'Portfolio: SHELL-T09']
    df14= df14.drop('Portfolio: SHELL-T09', axis=1)
    df14.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df14.insert(1,'VOLUME_UOM','MWH')
    df14.insert(2, 'PARTICIPANT', 'SHELL-T08')
    df14= pd.concat([df2,df14], axis=1)
    df14 = df14.iloc[2:]
    df14.columns = headers
    #df14
    # slice from 'Portfolio: SHELL-T09' to Portfolio: SHELL-T10
    df15 = df5.loc[:, 'Portfolio: SHELL-T09':'Portfolio: SHELL-T10']
    df15= df15.drop('Portfolio: SHELL-T10', axis=1)
    df15.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df15.insert(1,'VOLUME_UOM','MWH')
    df15.insert(2, 'PARTICIPANT', 'SHELL-T09')
    df15= pd.concat([df2,df15], axis=1)
    df15 = df15.iloc[2:]
    df15.columns = headers
    #df15
    # slice from 'Portfolio: SHELL-T09' to Portfolio: SHELL-T10
    df16 = df5.loc[:, 'Portfolio: SHELL-T10':'Portfolio: SHELL-T11']
    df16= df16.drop('Portfolio: SHELL-T11', axis=1)
    df16.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df16.insert(1,'VOLUME_UOM','MWH')
    df16.insert(2, 'PARTICIPANT', 'SHELL-T10')
    df16= pd.concat([df2,df16], axis=1)
    df16 = df16.iloc[2:]
    df16.columns = headers
    #df16
    #Portfolio: SHELL-SABT01
    # slice from 'Portfolio: SHELL-T09' to Portfolio: SHELL-SABT01
    df17 = df5.loc[:, 'Portfolio: SHELL-T11':'Portfolio: SHELL-SABT01']
    df17= df17.drop('Portfolio: SHELL-SABT01', axis=1)
    df17.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df17.insert(1,'VOLUME_UOM','MWH')
    df17.insert(2, 'PARTICIPANT', 'SHELL-T11')
    df17= pd.concat([df2,df17], axis=1)
    df17 = df17.iloc[2:]
    df17.columns = headers
    #df17
    # slice from 'Portfolio: SHELL-SABT01' to Portfolio: SHELL-SABT02
    df18 = df5.loc[:, 'Portfolio: SHELL-SABT01':'Portfolio: SHELL-SABT02']
    df18= df18.drop('Portfolio: SHELL-SABT02', axis=1)
    df18.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df18.insert(1,'VOLUME_UOM','MWH')
    df18.insert(2, 'PARTICIPANT', 'SHELL-SABT01')
    df18= pd.concat([df2,df18], axis=1)
    df18 = df18.iloc[2:]
    df18.columns = headers
    #df18
    # slice from 'Portfolio: SHELL-SABT01' to Portfolio: SHELL-SABT02
    df19 = df5.loc[:, 'Portfolio: SHELL-SABT02':'Portfolio: SHELL-SABT03']
    df19= df19.drop('Portfolio: SHELL-SABT03', axis=1)
    df19.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df19.insert(1,'VOLUME_UOM','MWH')
    df19.insert(2, 'PARTICIPANT', 'SHELL-SABT02')
    df19= pd.concat([df2,df19], axis=1)
    df19 = df19.iloc[2:]
    df19.columns = headers
    #df19
    # slice from 'Portfolio: SHELL-SABT03' to end
    df20 = df5.loc[:,'Portfolio: SHELL-SABT03':'Portfolio: SHELL-PW1']
    df20= df20.drop('Portfolio: SHELL-PW1', axis=1)
    df20.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df20.insert(1,'VOLUME_UOM','MWH')
    df20.insert(2, 'PARTICIPANT', 'SHELL-SABT03')
    df20= pd.concat([df2,df20], axis=1)
    df20 = df20.iloc[2:]
    df20.columns = headers
    #df20
    df30 = df5.loc[:,'Portfolio: SHELL-PW1':'Portfolio: SHELL-PM1']
    df30= df30.drop('Portfolio: SHELL-PM1', axis=1)
    df30.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df30.insert(1,'VOLUME_UOM','MWH')
    df30.insert(2, 'PARTICIPANT', 'SHELL-PW1')
    df30= pd.concat([df2,df30], axis=1)
    df30 = df30.iloc[2:]
    df30.columns = headers
    #
    df31 = df5.loc[:,'Portfolio: SHELL-PM1':]
    df31.insert(0, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df31.insert(1,'VOLUME_UOM','MWH')
    df31.insert(2, 'PARTICIPANT', 'SHELL-PM1')
    df31= pd.concat([df2,df31], axis=1)
    df31 = df31.iloc[2:]
    df31.columns = headers
    #append all shell trade's df's
    df21 = df6.append([df7, df8,df9,df10,df11,df12,df13,df14,df15,df16,df17,df18,df19,df20,df30,df31]).reset_index(drop=True)
    df22 = df1.T
    #df100
    df22.columns = df22.iloc[0]
    #df100
    df22 = df22.iloc[1:]
    df22 = df22.drop(currencytodrop,axis=1)
    df22 = df22.loc[:, df22.columns.notna()]
    df22=df22.dropna(how='all')  #to drop if all values in the row are nan
    df22.columns = ['EPEX_AREA_SET', 'EPEX_AUCTION_NAME', 'AUCTION_DATETIME_UTC','PERIOD_DURATION']
    df22.insert(4, 'EPEX_MARKET_AREA', Market_area)    
    df22.reset_index(drop=True, inplace=True)
    #display(df22)
    df23 = df[df.apply(lambda x: x.str.contains(currencycolumntorename)).any(axis=1)]
    df23= df23.T
    df23.columns = df23.iloc[1]
    df23= df23.iloc[2:]
    df23 = df23.replace(',','.', regex=True)
    df23.rename(columns={currencycolumntorename:currencycolumnrename}, inplace=True)
    df23=df23.dropna(how='all')
    df23.reset_index(drop=True, inplace=True)
    #display(df23)
    df24=pd.concat([df22,df23],axis=1)
    df25 = pd.concat([df24.reindex(df21.index, method='ffill'), df21], axis=1)
    
    df25=df25[['DELIVERY_PERIOD','DELIVERY_PERIOD_TYPE','VOLUME_UOM','PARTICIPANT','SCHEDULED_NET','SCHEDULED_PURCHASED',
                 'SCHEDULED_SALE','LINEAR_SCHEDULED_NET','LINEAR_SCHEDULED_PURCHASED','LINEAR_SCHEDULED_SALE','BLOCK_SCHEDULED_NET',
               'BLOCK_SCHEDULED_PURCHASED','BLOCK_SCHEDULED_SALE','COMPLEX_SCHEDULED_NET','COMPLEX_SCHEDULED_PURCHASED',
               'COMPLEX_SCHEDULED_SALE','EPEX_AREA_SET','EPEX_AUCTION_NAME','AUCTION_DATETIME_UTC','PERIOD_DURATION','EPEX_MARKET_AREA',currencycolumnrename]]
    for col in ['EPEX_AREA_SET', 'EPEX_AUCTION_NAME','AUCTION_DATETIME_UTC','PERIOD_DURATION','EPEX_MARKET_AREA',currencycolumnrename]:
        df25[col].ffill(inplace=True)
    df25 = df25.replace(',','.', regex=True)
    print('DS2')
    df25.insert(0,'DELIVERY_PERIOD_TYPE_CHECKER',pd.to_datetime(df25.DELIVERY_PERIOD,errors='coerce'))
    df25['DELIVERY_PERIOD_TYPE'] = np.where(pd.isna(df25['DELIVERY_PERIOD_TYPE_CHECKER']), 'AGGREGATE', df25['DELIVERY_PERIOD_TYPE'] )
    del df25['DELIVERY_PERIOD_TYPE_CHECKER']
    display(df25) 
    LAND_FULL_PATH2 = LAND_PATH +'/'+SOURCE_FILE + '_2.avro'
    print(LAND_FULL_PATH2)
    pdx.to_avro(LAND_FULL_PATH2,df25)

    ### start of Target dataset #2
    df26 = df5.loc[:, stringtosearch:'Participant: SHELL']
    df26= df26.drop('Participant: SHELL', axis=1)
    #df100.columns = df100.iloc[2]
    df26= df26.iloc[2:]
    df26.columns= ['DELIVERY_PERIOD','MARKET_CLEARED_PRICE','MARKET_CLEARED_VOLUME']
    df26.insert(1, 'DELIVERY_PERIOD_TYPE', DELIVERY_PERIOD)
    df26.insert(3, 'PRICE_ISO_CCY_CODE', currencytodrop)
    df26.insert(5,'VOLUME_UOM','MWH')
    df26.reset_index(drop=True, inplace=True)
    df27 = pd.concat([df24.reindex(df26.index, method='ffill'), df26], axis=1)
    df27=df27[['DELIVERY_PERIOD','DELIVERY_PERIOD_TYPE','MARKET_CLEARED_PRICE','PRICE_ISO_CCY_CODE','MARKET_CLEARED_VOLUME', 'VOLUME_UOM','EPEX_AREA_SET','EPEX_AUCTION_NAME','AUCTION_DATETIME_UTC',currencycolumnrename,'PERIOD_DURATION','EPEX_MARKET_AREA']]
    
    for col in ['EPEX_AREA_SET', 'EPEX_AUCTION_NAME','AUCTION_DATETIME_UTC','PERIOD_DURATION','EPEX_MARKET_AREA',currencycolumnrename]:
          df27[col].ffill(inplace=True)
    df27 = df27.replace(',','.', regex=True)
    df27.insert(0,'DELIVERY_PERIOD_TYPE_CHECKER',pd.to_datetime(df27.DELIVERY_PERIOD,errors='coerce'))
    df27['DELIVERY_PERIOD_TYPE'] = np.where(pd.isna(df27['DELIVERY_PERIOD_TYPE_CHECKER']), 'AGGREGATE', df27['DELIVERY_PERIOD_TYPE'] )
    del df27['DELIVERY_PERIOD_TYPE_CHECKER']
    display(df27)
    LAND_FULL_PATH1 = LAND_PATH +'/'+SOURCE_FILE + '_1.avro'
    print(LAND_FULL_PATH1)
    pdx.to_avro(LAND_FULL_PATH1,df27)



# COMMAND ----------


