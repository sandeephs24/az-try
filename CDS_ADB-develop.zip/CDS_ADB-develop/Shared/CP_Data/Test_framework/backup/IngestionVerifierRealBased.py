# Databricks notebook source
# MAGIC %run "/Shared/CP_Data/Config/config"

# COMMAND ----------

import json
item = dbutils.widgets.get("item")
datasetArray = dbutils.widgets.get("datasetArray")
metaJsonString = dbutils.widgets.get("metaJson")
loadStatusJsonString = dbutils.widgets.get("loadStatusJson")
triggerDetailsJsonString = dbutils.widgets.get("trigger_details_json")
triggerDf = spark.read.json(sc.parallelize([triggerDetailsJsonString]))
triggerDf.show()
triggerDf.printSchema()

adlsPathArrayString = '{' + datasetArray+ '}'

adlsPathJson = json.loads(adlsPathArrayString)
metaJsonObject = json.loads(metaJsonString)
loadStatusJsonObject = json.loads(loadStatusJsonString)
#triggerDetailsJsonObject = json.loads(triggerDetailsJsonString)


# COMMAND ----------


def convertToDictADLSPath(adlsPathJson):
  adlsPathDict = {}
  for key, value in adlsPathJson.items():
    adlsPathDict[key] = value

  return adlsPathDict

def convertToDictMeta(metaJsonObject):

  datasetNameDatasetDict = {}
  for element1 in metaJsonObject:
    datasetDict = {}
    for key, value in element1.items():
      datasetDict[key] = value
    
    datasetNameDatasetDict[datasetDict['dataset']] = datasetDict
  return datasetNameDatasetDict

def convertToDictLoadStatus(loadStatusJsonObject):
  datasetNameLoadStatusDict = {}

  for element2 in loadStatusJsonObject:
    datasetLoadstatusDict = {}
    for key, value in element2.items():
      datasetLoadstatusDict[key] = value
    
    datasetNameLoadStatusDict[datasetLoadstatusDict['source_dataset']] = datasetLoadstatusDict
  
  return datasetNameLoadStatusDict



# COMMAND ----------

def collectMetrics(adlsPathDict, datasetNameDatasetDict, datasetNameLoadStatusDict):
  datasetMetricDict = {}
  for key, value in datasetNameDatasetDict.items():
      adlsPathForDataset = ""
      
      if key in adlsPathDict:
        adlsPathForDataset = adlsPathDict[key]
      
      loadStatusDict = {}
      if key in datasetNameLoadStatusDict:
        loadStatusDict = datasetNameLoadStatusDict[key]

      metricDict = collectMetricsForTheDataset(key, adlsPathForDataset, value, loadStatusDict )
      datasetMetricDict[key] = metricDict
  
  return datasetMetricDict

def collectMetricsForTheDataset(dataset_name, adlsPathForDataset, datasetDict, loadStatusDict):

  try:
    metricDict = {}
    adls_file = loadStatusDict['target_dataset']
    land_file = '/mnt/ADLS/' + adlsPathForDataset + '/' + adls_file
    #df = spark.read.format("avro").load(land_file)
    
    
    metricDict['land_file_path'] = land_file
    metricDict['land_file_record_count'] = "0" 
    #df.count()
    metricDict['loadstatus_target_record_count'] = loadStatusDict['target_record_count']
    metricDict['config_src_load_type'] = datasetDict["config_src_load_type"] 
    metricDict['variable_percentage_wrt_last_N_run'] = loadStatusDict['var_per'] 

    config_json = loadStatusDict['config_json']
    configJsonObject = json.loads(config_json)
    
    for key, value in configJsonObject.items():
      metricDict[key] = value

    # if (metricDict['config_src_load_type'] == 'Inc'):
      
    #   df.createOrReplaceTempView("Temp_IngestionVerifier_AvroLandFile")
    #   max_from_avro_sql = "select max(" + datasetDict["config_inc_column_name"] + ") from Temp_IngestionVerifier_AvroLandFile"
    #   print(max_from_avro_sql)
    #   df1 = spark.sql(max_from_avro_sql)
    #   max_value_from_avro = str(df1.collect()[0][0])
      
    #   if '000' in max_value_from_avro:
    #     str2 = max_value_from_avro.split('.')[0]
    #     max_value_from_avro = str2.split(' ')[0] + 'T' + str2.split(' ')[1]
      
      
    #   metricDict['last_load_value_watermark_table'] = datasetDict["last_load_value"]
    #   metricDict['config_inc_column_name'] = datasetDict["config_inc_column_name"]
    #   metricDict['max_value_from_avro'] = max_value_from_avro
  except Exception as e:
    metricDict['metric_collection_exception'] = "true"
    error_message = str(e)
    metricDict['metric_collection_exception_detail'] = error_message
  return metricDict
  
def check_trend_compare_wrt_avg_last_N_run(metricDict):  
  check_result = "Not Executed"

  if metricDict['variable_percentage_wrt_last_N_run'] is None:
    check_result = "Not Applicable"
  else:
    if (int(metricDict['variable_percentage_wrt_last_N_run']) <= int(metricDict['ingestion_trend_check_variation_percent'])):
      check_result = "Passed"
    else:
      check_result = "Failed"
  
  return check_result
    
def check_watermark_value(metricDict):  
  check_result = "Not Executed"
  if (metricDict['max_value_from_avro'] == metricDict['last_load_value_watermark_table']):
    check_result = "Passed"
  else:
    check_result = "Failed"
  
  return check_result
  
def check_land_file_load_status_count_comparison(metricDict):  
  check_result = "Not Executed"
  if (metricDict['max_value_from_avro'] == metricDict['last_load_value_watermark_table']):
    check_result = "Passed"
  else:
    check_result = "Failed"
  
  return check_result

def check_land_file_access_from_adb(metricDict):  
  check_result = "Not Executed"
  try:
    print(metricDict['land_file_path'])
    df = spark.read.format("avro").load(metricDict['land_file_path'])
    check_result = "Passed"
  except Exception as e:
    print(str(e))
    check_result = "Failed"
  
  
  return check_result


# COMMAND ----------

def apply(func, metricDict):
  return func(metricDict)

# COMMAND ----------

def initializeCheckFunctions(datasetNameDatasetDict, datasetMetricDict):
  datasetCheckFuncDict = {}
  for key,value in datasetNameDatasetDict.items():
    checkFuncDict = {}
    #checkFuncDict['check_land_file_load_status_count_comparison'] = check_land_file_load_status_count_comparison
    #checkFuncDict['check_trend_compare_wrt_avg_last_N_run'] = check_trend_compare_wrt_avg_last_N_run
    checkFuncDict['check_land_file_access_from_adb'] = check_land_file_access_from_adb
    metricDict = datasetMetricDict[key]
    #if (metricDict['config_src_load_type'] == 'Inc'):
    #    checkFuncDict['check_watermark_value'] = check_watermark_value

    datasetCheckFuncDict[key] = checkFuncDict

  return datasetCheckFuncDict

def executeChecks(datasetNameDatasetDict,datasetCheckFuncDict,datasetMetricDict):

  datasetCheckResultDict = {}
  for key, value in datasetNameDatasetDict.items():
    checkResultDict = {}
    metricDict = datasetMetricDict[key]
    checkFuncDict = datasetCheckFuncDict[key]
    for funcName, funcObject in checkFuncDict.items():
      checkResultDict[funcName] = apply(funcObject, metricDict)
    datasetCheckResultDict[key] = checkResultDict

  return(datasetCheckResultDict)  

def prepareReturnJson(datasetMetricDict, datasetCheckResultDict):

  json_checkResultDict = json.dumps(datasetCheckResultDict, indent = 4)
  json_metricDict = json.dumps(datasetMetricDict, indent = 4)

      
  databricksReturnJson = "{"
  databricksReturnJson = databricksReturnJson +  '"' + "DatabricksReturnJson" + '"' + ':'
  databricksReturnJson = databricksReturnJson +  '{'
  databricksReturnJson = databricksReturnJson +  '"' + "checkData" + '"' + ':'
  databricksReturnJson = databricksReturnJson + json_checkResultDict
  databricksReturnJson = databricksReturnJson + ','
  databricksReturnJson = databricksReturnJson +  '"' + "metricData" + '"' + ':'
  databricksReturnJson = databricksReturnJson + json_metricDict
  databricksReturnJson = databricksReturnJson +  '}'
  databricksReturnJson = databricksReturnJson +  '}'

  return databricksReturnJson



# COMMAND ----------

adlsPathDict = convertToDictADLSPath(adlsPathJson)
datasetNameDatasetDict = convertToDictMeta(metaJsonObject)
datasetNameLoadStatusDict = convertToDictLoadStatus(loadStatusJsonObject)
datasetMetricDict = collectMetrics(adlsPathDict, datasetNameDatasetDict, datasetNameLoadStatusDict)
datasetCheckFuncDict = initializeCheckFunctions(datasetNameDatasetDict, datasetMetricDict)
datasetCheckResultDict = executeChecks(datasetNameDatasetDict,datasetCheckFuncDict,datasetMetricDict  )
databricksReturnJson = prepareReturnJson(datasetMetricDict, datasetCheckResultDict)



# COMMAND ----------

dbutils.notebook.exit(databricksReturnJson)
