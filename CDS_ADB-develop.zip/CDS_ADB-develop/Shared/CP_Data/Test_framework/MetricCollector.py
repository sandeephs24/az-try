# Databricks notebook source
  
def collectMetrics(adlsPathDict, datasetNameDatasetDict, datasetNameLoadStatusDict, triggerDf):
  datasetMetricDict = {}
  for key, value in datasetNameDatasetDict.items():
      adlsPathForDataset = ""
      
      if key in adlsPathDict:
        adlsPathForDataset = adlsPathDict[key]
      
      loadStatusDict = {}
      if key in datasetNameLoadStatusDict:
        loadStatusDict = datasetNameLoadStatusDict[key]

      metricDict = collectMetricsForTheDataset(key, adlsPathForDataset, value, loadStatusDict, triggerDf )
      datasetMetricDict[key] = metricDict
  
  return datasetMetricDict

def getTriggerCountForDataset(dataset_name, source_name, triggerDf):
  from pyspark.sql.functions import upper
  from pyspark.sql.functions import instr

  triggerDf.createOrReplaceTempView("TRIGGER_DETAILS")
  trigger_sql1 = "select count(*) as TRIGGER_COUNT_FOR_SOURCE from TRIGGER_DETAILS where (source_list is not null and upper(source_list) = '{}' and dataset_list is null)".format(source_name.upper())
  dfSourceTriggerCount = spark.sql(trigger_sql1)
  sourceTriggerCount = dfSourceTriggerCount.collect()[0][0]

  trigger_sql2 = "select count(*) as TRIGGER_COUNT_FOR_DATASET from TRIGGER_DETAILS where (source_list is not null and upper(source_list) = '{}' and dataset_list is not null and instr(upper(dataset_list), '{}') > 0 )".format(source_name.upper(),dataset_name.upper())
  
  dfDatasetTriggerCount = spark.sql(trigger_sql2)
  datasetTriggerCount = dfDatasetTriggerCount.collect()[0][0]

  totalTriggerCount = sourceTriggerCount + datasetTriggerCount
  return totalTriggerCount

def loadDfFromADLSPathAndCreateTempView(adlsPathWithFileName, viewNameToBeCreated, fileFormat):
  df = spark.read.format(fileFormat).load(adlsPathWithFileName)
  df.createOrReplaceTempView(viewNameToBeCreated)

def collectMetricsForTheDataset(dataset_name, adlsPathForDataset, datasetDict, loadStatusDict, triggerDf):

  try:
    metricDict = {}
    metricDict['metric_collection_exception'] = "false"
    if (len(loadStatusDict) == 0):
      metricDict['load_status_empty_for_dataset'] = "true"
    else:
      metricDict['load_status_empty_for_dataset'] = "false"    
    
    adls_file = loadStatusDict['target_dataset']
    land_file = '/mnt/ADLS/' + adlsPathForDataset + '/' + adls_file
    loadDfFromADLSPathAndCreateTempView(land_file,"Temp_IngestionVerifier_AvroLandFile","avro")
    df = spark.sql("select * from Temp_IngestionVerifier_AvroLandFile")

    metricDict['land_file_path'] = land_file
    metricDict['land_file_record_count'] = df.count()
    metricDict['prev_success_run_target_dataset'] = loadStatusDict['prev_success_run_target_dataset']
    metricDict['prev_success_run_target_record_count'] = loadStatusDict['prev_success_run_target_record_count']
    if metricDict['prev_success_run_target_dataset'] is None:
      print('Previous target data is null')
    else:
      prev_land_file = '/mnt/ADLS/' + adlsPathForDataset + '/' + metricDict['prev_success_run_target_dataset']
      metricDict['prev_land_file_path'] = prev_land_file
      loadDfFromADLSPathAndCreateTempView(metricDict['prev_land_file_path'],"Temp_IngestionVerifier_Prev_AvroLandFile","avro")
    
    metricDict['loadstatus_target_record_count'] = loadStatusDict['target_record_count']
    metricDict['config_src_load_type'] = datasetDict["config_src_load_type"] 
    metricDict['variable_percentage_wrt_last_N_run'] = loadStatusDict['var_per'] 
    metricDict['config_primary_keys'] = datasetDict["config_primary_keys"] 
    

    config_json = loadStatusDict['config_json']
    configJsonObject = json.loads(config_json)
    
    totalTriggerCount = getTriggerCountForDataset(dataset_name,datasetDict['source_name'],triggerDf)
    metricDict['total_trigger_count_applicable_to_dataset'] = totalTriggerCount

      

    for key, value in configJsonObject.items():
      metricDict[key] = value

    if (metricDict['config_src_load_type'] == 'Inc'):
      
      
      max_from_avro_sql = "select max(" + datasetDict["config_inc_column_name"] + ") from Temp_IngestionVerifier_AvroLandFile"
      print(max_from_avro_sql)
      df1 = spark.sql(max_from_avro_sql)
      max_value_from_avro = str(df1.collect()[0][0])
      
      if '000' in max_value_from_avro:
        str2 = max_value_from_avro.split('.')[0]
        max_value_from_avro = str2.split(' ')[0] + 'T' + str2.split(' ')[1]
      
      
      metricDict['last_load_value_watermark_table'] = datasetDict["last_load_value"]
      metricDict['config_inc_column_name'] = datasetDict["config_inc_column_name"]
      metricDict['max_value_from_avro'] = max_value_from_avro
  except Exception as e:
    metricDict['metric_collection_exception'] = "true"
    error_message = str(e)
    metricDict['metric_collection_exception_detail'] = error_message
    print(error_message)
    
    
  return metricDict