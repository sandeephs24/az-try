# Databricks notebook source

def convertToDictADLSPath(adlsPathJson):
  adlsPathDict = {}
  for key, value in adlsPathJson.items():
    adlsPathDict[key] = value

  return adlsPathDict

def convertToDictMeta(metaJsonObject):

  datasetNameDatasetDict = {}
  for element1 in metaJsonObject:
    datasetDict = {}
    for key, value in element1.items():
      datasetDict[key] = value
    
    datasetNameDatasetDict[datasetDict['dataset']] = datasetDict
  return datasetNameDatasetDict

def convertToDictLoadStatus(loadStatusJsonObject):
  datasetNameLoadStatusDict = {}

  for element2 in loadStatusJsonObject:
    datasetLoadstatusDict = {}
    for key, value in element2.items():
      datasetLoadstatusDict[key] = value
    
    datasetNameLoadStatusDict[datasetLoadstatusDict['source_dataset']] = datasetLoadstatusDict
  
  return datasetNameLoadStatusDict