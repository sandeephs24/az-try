# Databricks notebook source
from pyspark.sql.types import StructType,StructField, StringType, IntegerType
from pyspark.sql import functions as F 
from pyspark.sql.functions import col, explode, array, struct, expr, sum, lit 

data2 = [("Anshul","Bisht","10","20","40","20"),
    ("Shalini","Rose","10","20","30","30")
  ]

schema = StructType([ \
    StructField("firstname",StringType(),True), \
    StructField("lastname",StringType(),True), \
    StructField("Jan2022Act", StringType(), True), \
    StructField("Feb2022Act", StringType(), True), \
    StructField("Jan2022Plan", StringType(), True), \
    StructField("Feb2022Plan", StringType(), True)  
  ])

df = spark.createDataFrame(data=data2,schema=schema)
df.printSchema()
display(df)

# COMMAND ----------

df2=( df.melt(
            ids=["firstname","lastname"],
            values=[],
            variableColumnName="variable",
            valueColumnName="value"
        ))

# COMMAND ----------

display(df2)

# COMMAND ----------

df3 = df2.withColumn('Period',expr('substring(Variable,0, 7)'))

df3.show()



# COMMAND ----------

 from pyspark.sql.functions import collect_list
 groupby = ['firstname','lastname','Period']
 
 df_final=df3.groupby(*groupby).agg(collect_list('value').alias("value"))
 df_final.show()

# value need to in 2 columns actual and plan
# period has to be in number

# COMMAND ----------






identifier_columns = ["firstname"] 
#value_columns = ["Jan2022Act","Jan2022Plan","Jan2022Plan","Feb2022Plan"] 

#pd.melt(df,id_vars=['firstname','lastname']
 #           value_vars=['Jan2022Act'], 
 #           var_name='Act', value_name='Plan')

#melt_expression = ['Jan2022Act','Jan2022Plan'] 
#melted_df = df.select(identifier_columns + [F.expr(melt_expression).alias("variable", "value")])  
#melted_df.show()

#melted_df=pd.melt(df, id_vars =['firstname'], value_vars =['Jan2022Act', 'Jan2022Plan'] ,var_name = 'Act', value_name='Plan',col_level=1,ignore_index = 1)
#melted_df.show()

melted_df = df.melt(
    ids=['firstname'],
     values=['Jan2022Act', 'Jan2022Plan','Feb2022Plan','Feb2022Act'],
    variableColumnName="key",valueColumnName="value"
)
melted_df.show()



#melted_df = pd.melt(df, id_vars =['firstname'], value_vars =['Jan2022Act', 'Jan2022Plan'])
#melted_df.show()


#melt_expression = f"stack({len(value_columns)}, {', '.join([f'\'{col}\', {col}' for col in value_columns])})" 
#melted_df = df.select(identifier_columns + [F.expr(melt_expression).alias("variable", "value")]) 
#melted_df.show()

#df1= df.groupby("firstname")
#df1.show()

 





