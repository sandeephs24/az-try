# Databricks notebook source
# MAGIC %run "/Shared/CP_Data/Config/config"

# COMMAND ----------

# MAGIC %run ./InputConverter

# COMMAND ----------

# MAGIC %run ./CheckFactory

# COMMAND ----------

# MAGIC %run ./CheckExecuter

# COMMAND ----------

# MAGIC %run ./OutputConverter

# COMMAND ----------

# MAGIC %run ./MetricCollector

# COMMAND ----------

import json
item = dbutils.widgets.get("item")
datasetArray = dbutils.widgets.get("datasetArray")
metaJsonString = dbutils.widgets.get("metaJson")
loadStatusJsonString = dbutils.widgets.get("loadStatusJson")
triggerDetailsJsonString = dbutils.widgets.get("trigger_details_json")

triggerDf = spark.read.json(sc.parallelize([triggerDetailsJsonString]))
adlsPathArrayString = '{' + datasetArray+ '}'

adlsPathJson = json.loads(adlsPathArrayString)
metaJsonObject = json.loads(metaJsonString)
loadStatusJsonObject = json.loads(loadStatusJsonString)


adlsPathDict = convertToDictADLSPath(adlsPathJson)
datasetNameDatasetDict = convertToDictMeta(metaJsonObject)
datasetNameLoadStatusDict = convertToDictLoadStatus(loadStatusJsonObject)



# COMMAND ----------

datasetMetricDict = collectMetrics(adlsPathDict, datasetNameDatasetDict, datasetNameLoadStatusDict,triggerDf)
print(datasetMetricDict)
datasetCheckFuncDict = initializeCheckFunctions(datasetNameDatasetDict, datasetMetricDict)

# COMMAND ----------

datasetCheckResultDict = executeChecks(datasetNameDatasetDict,datasetCheckFuncDict,datasetMetricDict  )

# COMMAND ----------

databricksReturnJson = prepareReturnJson(datasetMetricDict, datasetCheckResultDict)

# COMMAND ----------

dbutils.notebook.exit(databricksReturnJson)