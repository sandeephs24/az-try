# Databricks notebook source
import json
item = dbutils.widgets.get("item")
adls_folder = dbutils.widgets.get("adls_folder")
adls_file = dbutils.widgets.get("adls_file")
load_status_record = dbutils.widgets.get("load_status_record")

# COMMAND ----------

def collectMetrics(item, adls_folder, adls_file, load_status_record):
  print(item)
  print(adls_folder)
  print(adls_file)
  print(load_status_record)

  
  item_json = json.loads(item)
  load_status_record_json = json.loads(load_status_record)

  metricDict = {}

  land_file = '/mnt/ADLS/' + adls_folder + '/' + adls_file
  df = spark.read.format("avro").load(land_file)
  
  
  metricDict['land_file_path'] = land_file
  metricDict['land_file_record_count'] = df.count()
  metricDict['loadstatus_target_record_count'] = load_status_record_json["target_record_count"]
  metricDict['config_src_load_type'] = item_json["config_src_load_type"] 
  
  if (metricDict['config_src_load_type'] == 'Inc'):
    
    df.createOrReplaceTempView("Temp_IngestionVerifier_AvroLandFile")
    max_from_avro_sql = "select max(" + item_json["config_inc_column_name"] + ") from Temp_IngestionVerifier_AvroLandFile"
    print(max_from_avro_sql)
    df1 = spark.sql(max_from_avro_sql)
    max_value_from_avro = str(df1.collect()[0][0])
    
    if '000' in max_value_from_avro:
      str2 = max_value_from_avro.split('.')[0]
      max_value_from_avro = str2.split(' ')[0] + 'T' + str2.split(' ')[1]
    
    
    metricDict['last_load_value_watermark_table'] = item_json["last_load_value"]
    metricDict['config_inc_column_name'] = item_json["config_inc_column_name"]
    metricDict['max_value_from_avro'] = max_value_from_avro

  return metricDict
  
def check_land_file_load_status_count_comparison(metricDict):  
  check_result = "Not Executed"
  if (metricDict['land_file_record_count'] == metricDict['loadstatus_target_record_count']):
    check_result = "Passed"
  else:
    check_result = "Failed"
  
  return check_result
    
def check_watermark_value(metricDict):  
  check_result = "Not Executed"
  if (metricDict['max_value_from_avro'] == metricDict['last_load_value_watermark_table']):
    check_result = "Passed"
  else:
    check_result = "Failed"
  
  return check_result
  


# COMMAND ----------

def apply(func, metricDict):
  return func(metricDict)

# COMMAND ----------

metricDict = collectMetrics(item, adls_folder, adls_file, load_status_record)

# COMMAND ----------

checkFuncDict = {}
checkFuncDict['check_land_file_load_status_count_comparison'] = check_land_file_load_status_count_comparison

if (metricDict['config_src_load_type'] == 'Inc'):
    checkFuncDict['check_watermark_value'] = check_watermark_value


checkResultDict = {}
for funcName, funcObject in checkFuncDict.items():
  checkResultDict[funcName] = apply(funcObject, metricDict)
    
json_checkResultDict = json.dumps(checkResultDict, indent = 4)
json_metricDict = json.dumps(metricDict, indent = 4)

print(json_checkResultDict)
print(json_metricDict)
overall_status = "Passed"


if ("Failed" in checkResultDict.values()):
    overall_status = "Failed"
    
databricksReturnJson = "{"
databricksReturnJson = databricksReturnJson +  '"' + "DatabricksReturnJson" + '"' + ':'
databricksReturnJson = databricksReturnJson +  '{'
databricksReturnJson = databricksReturnJson +  '"' + "overall_status" + '"' + ':'
databricksReturnJson = databricksReturnJson +  '"' + overall_status + '"' + ','
databricksReturnJson = databricksReturnJson +  '"' + "checkData" + '"' + ':'
databricksReturnJson = databricksReturnJson + json_checkResultDict
databricksReturnJson = databricksReturnJson + ','
databricksReturnJson = databricksReturnJson +  '"' + "metricData" + '"' + ':'
databricksReturnJson = databricksReturnJson + json_metricDict
databricksReturnJson = databricksReturnJson +  '}'
databricksReturnJson = databricksReturnJson +  '}'

dbutils.notebook.exit(databricksReturnJson)
