# Databricks notebook source
  
def ConvertListToDict(a):
    dict1 = {}
    for i in a:
      dict1[i[0]] = i[1]
    
    return dict1 

def check_trend_compare_wrt_avg_last_N_run(metricDict):  
  check_result = "Not Executed"

  if metricDict['variable_percentage_wrt_last_N_run'] is None:
    check_result = "Not Applicable"
  else:
    if (int(metricDict['variable_percentage_wrt_last_N_run']) <= int(metricDict['ingestion_trend_check_variation_percent'])):
      check_result = "Passed"
    else:
      check_result = "Failed"
  
  return check_result
    
def check_watermark_value(metricDict):  
  check_result = "Not Executed"
  if (metricDict['max_value_from_avro'] == metricDict['last_load_value_watermark_table']):
    check_result = "Passed"
  else:
    check_result = "Failed"
  
  return check_result
  
def check_land_file_load_status_count_comparison(metricDict):  
  check_result = "Not Executed"
  if (metricDict['loadstatus_target_record_count'] == metricDict['land_file_record_count']):
    check_result = "Passed"
  else:
    check_result = "Failed"
  
  return check_result

def check_land_file_access_from_adb(metricDict):  
  check_result = "Not Executed"
  try:
    df = spark.read.format("avro").load(metricDict['land_file_path'])
    check_result = "Passed"
  except:
    check_result = "Failed"
  
  
  return check_result

def check_one_trigger_exist_for_the_dataset(metricDict):  
  check_result = "Not Executed"
  if (int(metricDict['total_trigger_count_applicable_to_dataset']) == 1 ):
    check_result = "Passed"
  else:
    check_result = "Failed"
          
  return check_result

def check_if_duplicate_record_in_landing(metricDict):  
  check_result = "Not Executed"
  try:
    primary_keys = metricDict['config_primary_keys']
    if len(primary_keys) > 0 :
      duplicate_sql = "select {}, count(*) from Temp_IngestionVerifier_AvroLandFile group by {}".format(primary_keys, primary_keys)
      print(duplicate_sql)
      dfDuplicate = spark.sql(duplicate_sql)
      duplicateCount = dfDuplicate.count()
      if duplicateCount > 0:
        check_result = "Failed"
      else:
        check_result = "Passed"    
  except Exception as e:
    print(e)
    check_result = "Exception" 
  return check_result


def check_trigger_enabled_for_the_dataset(metricDict):  
  check_result = "Not Executed"
  return check_result

def check_latest_run_is_success(metricDict):  
  check_result = "Not Executed"
  return check_result

def check_columns_removed_comparing_to_previous_landing_files(metricDict):  
  check_result = "Not Executed"
  if not 'prev_success_run_target_dataset' in metricDict:
    check_result = "Not Applicable"
  else:
    (columnsRemovedSetOfString, columnsAddedSetOfString, dataTypeMismatchColumnsdict) = metricsForSchemaDiff()
    if len(columnsRemovedSetOfString) > 0:
      check_result = "Failed"
    else:
      check_result = "Passed"

  return check_result

def check_columns_added_comparing_to_previous_landing_files(metricDict):  
  check_result = "Not Executed"
  if not 'prev_success_run_target_dataset' in metricDict:
    check_result = "Not Applicable"
  else:
    (columnsRemovedSetOfString, columnsAddedSetOfString, dataTypeMismatchColumnsdict) = metricsForSchemaDiff()
    if len(columnsAddedSetOfString) > 0:
      check_result = "Failed"
    else:
      check_result = "Passed"
  
  return check_result

def check_datatype_changed_comparing_to_previous_landing_files(metricDict):  
  check_result = "Not Executed"
  if not 'prev_success_run_target_dataset' in metricDict:
    check_result = "Not Applicable"
  else:
    (columnsRemovedSetOfString, columnsAddedSetOfString, dataTypeMismatchColumnsdict) = metricsForSchemaDiff() 
    if len(dataTypeMismatchColumnsdict) > 0:
      check_result = "Failed"
    else:
      check_result = "Passed"

  return check_result    

def metricsForSchemaDiff():
  currentDf = spark.sql("select * from Temp_IngestionVerifier_AvroLandFile")
  prevDf = spark.sql("select * from Temp_IngestionVerifier_Prev_AvroLandFile")
  currentSchemaDict = ConvertListToDict(currentDf.dtypes)
  prevSchemaDict = ConvertListToDict(prevDf.dtypes)
  

  columnsRemovedSetOfString = currentSchemaDict.keys() - prevSchemaDict.keys()
  columnsAddedSetOfString = prevSchemaDict.keys() - currentSchemaDict.keys()
  columnsCommonSetOfTuple  = currentSchemaDict.items() & prevSchemaDict.items()
  columnsCommonDict = ConvertListToDict(columnsCommonSetOfTuple)

  dataTypeMismatchColumnsdict = {}
  for key in columnsCommonDict.keys():
    if currentSchemaDict[key] != prevSchemaDict[key]:
      dataTypeMismatchColumnsdict[key] = "Current Datatype|" + currentSchemaDict[key] + "|Prev Datatype|" + prevSchemaDict[key]

  return (columnsRemovedSetOfString, columnsAddedSetOfString, dataTypeMismatchColumnsdict)

def check_landing_columns_with_source_schema(metricDict):  
  check_result = "Not Executed"
  return check_result

def check_if_full_load_count_is_more_than_previous(metricDict):  
  check_result = "Not Executed"
  if (metricDict['config_src_load_type'] == 'Full'):
    if (int(metricDict['prev_success_run_target_record_count']) > int(metricDict['land_file_record_count']) ):
      check_result = "Failed"
    else:
      check_result = "Passed"    

  return check_result



def check_if_duplicate_record_in_unharm(metricDict):  
  check_result = "Not Executed"
  return check_result

# COMMAND ----------

def initializeCheckFunctions(datasetNameDatasetDict, datasetMetricDict):
  datasetCheckFuncDict = {}
  for key,value in datasetNameDatasetDict.items():
    checkFuncDict = {}
    checkFuncDict['check_land_file_load_status_count_comparison'] = check_land_file_load_status_count_comparison
    checkFuncDict['check_trend_compare_wrt_avg_last_N_run'] = check_trend_compare_wrt_avg_last_N_run
    checkFuncDict['check_land_file_access_from_adb'] = check_land_file_access_from_adb
    checkFuncDict['check_one_trigger_exist_for_the_dataset'] = check_one_trigger_exist_for_the_dataset
    checkFuncDict['check_if_duplicate_record_in_landing'] = check_if_duplicate_record_in_landing
    checkFuncDict['check_columns_removed_comparing_to_previous_landing_files'] = check_columns_removed_comparing_to_previous_landing_files
    checkFuncDict['check_columns_added_comparing_to_previous_landing_files'] = check_columns_added_comparing_to_previous_landing_files
    checkFuncDict['check_datatype_changed_comparing_to_previous_landing_files'] = check_datatype_changed_comparing_to_previous_landing_files
    
    
    metricDict = datasetMetricDict[key]
    if (metricDict['config_src_load_type'] == 'Inc'):
        checkFuncDict['check_watermark_value'] = check_watermark_value

    datasetCheckFuncDict[key] = checkFuncDict

  return datasetCheckFuncDict