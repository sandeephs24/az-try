# Databricks notebook source
# MAGIC %run "/Shared/CP_Data/Shared_script/main"

# COMMAND ----------

def createDatabricksReturnJson(datasetMetricDict, datasetCheckResultDict):

  json_checkResultDict = json.dumps(datasetCheckResultDict, indent = 4)
  json_metricDict = json.dumps(datasetMetricDict, indent = 4)

      
  databricksReturnJson = "{"
  databricksReturnJson = databricksReturnJson +  '"' + "DatabricksReturnJson" + '"' + ':'
  databricksReturnJson = databricksReturnJson +  '{'
  databricksReturnJson = databricksReturnJson +  '"' + "checkData" + '"' + ':'
  databricksReturnJson = databricksReturnJson + json_checkResultDict
  databricksReturnJson = databricksReturnJson + ','
  databricksReturnJson = databricksReturnJson +  '"' + "metricData" + '"' + ':'
  databricksReturnJson = databricksReturnJson + json_metricDict
  databricksReturnJson = databricksReturnJson +  '}'
  databricksReturnJson = databricksReturnJson +  '}'

  return databricksReturnJson

# COMMAND ----------

# DBTITLE 1,Create Widgets
dbutils.widgets.text('delta_file_path', '', 'Delta File Path');
dbutils.widgets.text('backup_delta_file_path', '', 'Backup Delta File Path');

dbutils.widgets.text('delta_file_name', '', 'Delta File Name');
dbutils.widgets.text('backup_delta_file_name', '', 'Backup Delta File Name');

dbutils.widgets.text('adls_mount_base', '/mnt/ADLS/', 'ADLS Mount Base');
#dbutils.widgets.text('raw_file_path', '', 'RAW File Path');
#dbutils.widgets.text('raw_file_name', '', 'RAW File Name');

dbutils.widgets.text('config_inc_column_name', '', 'config_inc_column_name');
dbutils.widgets.text('config_primary_keys', '', 'config_primary_keys');
dbutils.widgets.text('config_src_load_type', '', 'config_src_load_type');
dbutils.widgets.text('dataset', '', 'dataset');




# COMMAND ----------

spark.conf.set("spark.databricks.delta.formatCheck.enabled", "false")
spark.conf.set("spark.databricks.delta.autoMerge.enabled", "true")
#spark.conf.set("spark.databricks.delta.checkLatestSchemaOnRead", "false")


# COMMAND ----------

# DBTITLE 1,Assign Widget values to variables
delta_file_path = '/mnt/ADLS' + dbutils.widgets.get('delta_file_path');
backup_delta_file_path = '/mnt/ADLS' +  dbutils.widgets.get('backup_delta_file_path');

print(delta_file_path)
print(backup_delta_file_path)
dataset = dbutils.widgets.get('dataset');
delta_file_name = dbutils.widgets.get('delta_file_name');
backup_delta_file_name = dbutils.widgets.get('backup_delta_file_name');

print(delta_file_name)
print(backup_delta_file_name)

delta_full = delta_file_path +delta_file_name
clone_delta_full = backup_delta_file_path +backup_delta_file_name

config_inc_column_name = dbutils.widgets.get('config_inc_column_name')
config_primary_keys = dbutils.widgets.get('config_primary_keys')

print(delta_full)
print(clone_delta_full)

checkResultDictEmpty = {}
metricDict = {}
metricDict['delta_full'] = delta_full
metricDict['clone_delta_full'] = clone_delta_full
metricDict["config_inc_column_name"] = config_inc_column_name
metricDict["config_primary_keys"] = config_primary_keys


  


# COMMAND ----------

if CheckPathExists(clone_delta_full) == False:
  dbutils.notebook.exit(createDatabricksReturnJson(checkResultDictEmpty,checkResultDictEmpty))
  

if CheckPathExists(delta_full) == False:
  dbutils.notebook.exit(createDatabricksReturnJson(checkResultDictEmpty,checkResultDictEmpty))

# COMMAND ----------

def readAndRegisterTempViews(metricDict):
  df_delta = spark.read.format('delta').load(metricDict['delta_full'] )
  backup_df_delta = spark.read.format('delta').load(metricDict['clone_delta_full'] )
  df_delta.createOrReplaceTempView("v1_view")
  backup_df_delta.createOrReplaceTempView("v2_view")
  metricDict["v1_view"] = "v1_view"
  metricDict["v2_view"] = "v2_view"
  return metricDict
  

def initiateMetricAndCorrespondingSQLRunForBoth(metricDict,view_name):
  metricSQLDict = {} 
  metricSQLDict["total_count"] = "select count(*) from {}".format(view_name)
  metricSQLDict["max_config_inc_column_name"] = "select max({}) from {}".format(metricDict["config_inc_column_name"], view_name)
  metricSQLDict["duplicate_count_based_on_pk"] = "select count(*) from (select {}, count(*) from {} where active_indicator = 'Y' group by {} having count(*) > 1) x".format(metricDict["config_primary_keys"], view_name, metricDict["config_primary_keys"])
  return metricSQLDict
  


def initiateCheckAndCorrespondingSQLRunOnce():
  metricSQLCheckDict = {}
  metricSQLCheckDict["hash_key_in_v1_but_not_in_v2"] = "select count(*) from {}".format(table_name)
  metricSQLCheckDict["hash_key_in_v2_but_not_in_v1"] = "select count(*) from {}".format(table_name)
  return metricSQLCheckDict
  
def executeMetricSQLDict(metricSQLDict):
  checkResultDict = {}
  for key, value in metricSQLDict.items():
    df = spark.sql(value)
    return_value = df.collect()[0][0]  
    checkResultDict[key] = return_value
  
  return checkResultDict

def collect_metrics(metricDict):
  metricSQLDictV1 = initiateMetricAndCorrespondingSQLRunForBoth(metricDict,"v1_view")
  metricSQLDictV2 = initiateMetricAndCorrespondingSQLRunForBoth(metricDict,"v2_view")
  metricSQLDictResultV1 = executeMetricSQLDict(metricSQLDictV1)
  metricSQLDictResultV2 = executeMetricSQLDict(metricSQLDictV2)
  #metricSQLCheckDict = initiateCheckAndCorrespondingSQLRunOnce()
  #metricSQLCheckDictResult = executeMetricSQLDict(metricSQLCheckDict)
  masterMetric = {}
  masterMetric["metricSQLDictResultV1"] =   metricSQLDictResultV1
  masterMetric["metricSQLDictResultV2"] =   metricSQLDictResultV2
  #masterMetric["metricSQLCheckDictResult"] =   metricSQLCheckDictResult
  
  return masterMetric

# COMMAND ----------

def check_total_counts_matching(masterMetric):  
  metricSQLDictResultV1 = masterMetric["metricSQLDictResultV1"]
  metricSQLDictResultV2 = masterMetric["metricSQLDictResultV2"]
  
  if (metricSQLDictResultV1["total_count"] != metricSQLDictResultV2["total_count"]):
    return "Failed"
  return "Passed"

def check_max_config_inc_column_name(masterMetric):  
  
  metricSQLDictResultV1 = masterMetric["metricSQLDictResultV1"]
  metricSQLDictResultV2 = masterMetric["metricSQLDictResultV2"]
  if (metricSQLDictResultV1["max_config_inc_column_name"] != metricSQLDictResultV2["max_config_inc_column_name"]):
    return "Failed"
  return "Passed"

def check_duplicate_count_based_on_pk_mathing(masterMetric):  
  
  metricSQLDictResultV1 = masterMetric["metricSQLDictResultV1"]
  metricSQLDictResultV2 = masterMetric["metricSQLDictResultV2"]
  if (metricSQLDictResultV1["duplicate_count_based_on_pk"] != metricSQLDictResultV2["duplicate_count_based_on_pk"]):
    return "Failed"
  return "Passed"

def check_duplicate_count_based_on_pk_zero(masterMetric):  
  
  metricSQLDictResultV1 = masterMetric["metricSQLDictResultV1"]
  metricSQLDictResultV2 = masterMetric["metricSQLDictResultV2"]
  if (metricSQLDictResultV1["duplicate_count_based_on_pk"] != 0 or metricSQLDictResultV2["duplicate_count_based_on_pk"] != 0):
    return "Failed"
  return "Passed"

# COMMAND ----------

metricDict = readAndRegisterTempViews(metricDict)
masterMetric = collect_metrics(metricDict)
print(masterMetric)

# COMMAND ----------

def apply(func, metricDict):
  return func(metricDict)

# COMMAND ----------

# DBTITLE 1,Check1- Check total record count - Unharm and Unharm backup
checkFuncDict = {}
checkFuncDict['check_total_counts_matching'] = check_total_counts_matching
checkFuncDict['check_max_config_inc_column_name'] = check_max_config_inc_column_name
checkFuncDict['check_duplicate_count_based_on_pk_mathing'] = check_duplicate_count_based_on_pk_mathing
checkFuncDict['check_duplicate_count_based_on_pk_zero'] = check_duplicate_count_based_on_pk_zero


checkResultDict = {}
for funcName, funcObject in checkFuncDict.items():
  checkResultDict[funcName] = apply(funcObject, masterMetric)  


overall_status = "Passed"
if ("Failed" in checkResultDict.values()):
    overall_status = "Failed"

datasetCheckResultDict = {}
datasetCheckResultDict[dataset] = checkResultDict

metricDict = {}
metricDict["dummyKey"] = "dummyValue"
datasetMetricDict = {}
datasetMetricDict[dataset] = metricDict
dbutils.notebook.exit(createDatabricksReturnJson(datasetMetricDict,datasetCheckResultDict))

