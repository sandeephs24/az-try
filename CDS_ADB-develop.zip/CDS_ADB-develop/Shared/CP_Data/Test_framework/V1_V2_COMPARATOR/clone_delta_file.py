# Databricks notebook source
dbutils.widgets.text('from_delta_path', '', 'from_delta_path');
dbutils.widgets.text('to_delta_path', '', 'to_delta_path');
from_delta_path = '/mnt/ADLS' + dbutils.widgets.get('from_delta_path');
to_delta_path ='/mnt/ADLS' + dbutils.widgets.get('to_delta_path');


print(from_delta_path)
print(to_delta_path)

# COMMAND ----------

dbutils.fs.cp(from_delta_path,to_delta_path, True )

# COMMAND ----------

df = spark.read.format("delta").load(from_delta_path)
print(df.count())

df = spark.read.format("delta").load(to_delta_path)
print(df.count())

