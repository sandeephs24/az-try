# Databricks notebook source
def prepareReturnJson(datasetMetricDict, datasetCheckResultDict):

  json_checkResultDict = json.dumps(datasetCheckResultDict, indent = 4)
  json_metricDict = json.dumps(datasetMetricDict, indent = 4)

      
  databricksReturnJson = "{"
  databricksReturnJson = databricksReturnJson +  '"' + "DatabricksReturnJson" + '"' + ':'
  databricksReturnJson = databricksReturnJson +  '{'
  databricksReturnJson = databricksReturnJson +  '"' + "checkData" + '"' + ':'
  databricksReturnJson = databricksReturnJson + json_checkResultDict
  databricksReturnJson = databricksReturnJson + ','
  databricksReturnJson = databricksReturnJson +  '"' + "metricData" + '"' + ':'
  databricksReturnJson = databricksReturnJson + json_metricDict
  databricksReturnJson = databricksReturnJson +  '}'
  databricksReturnJson = databricksReturnJson +  '}'

  return databricksReturnJson