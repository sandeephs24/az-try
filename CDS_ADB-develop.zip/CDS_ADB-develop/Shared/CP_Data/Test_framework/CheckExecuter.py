# Databricks notebook source
def apply(func, metricDict):
  return func(metricDict)

# COMMAND ----------

def executeChecks(datasetNameDatasetDict,datasetCheckFuncDict,datasetMetricDict):

  datasetCheckResultDict = {}
  for key, value in datasetNameDatasetDict.items():
    checkResultDict = {}
    metricDict = datasetMetricDict[key]
    checkFuncDict = datasetCheckFuncDict[key]
    for funcName, funcObject in checkFuncDict.items():
      checkResultDict[funcName] = apply(funcObject, metricDict)
    datasetCheckResultDict[key] = checkResultDict

  return(datasetCheckResultDict)  