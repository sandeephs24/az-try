# Databricks notebook source
# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

sens_source_listTables = ['CA_ERATED_STN_AP_OPEN_GRA_001', 'CA_ERATED_STN_AR_OPEN_GRA_001', 'CA_ERATED_TS_AP_OPEN_GRA_001', 'CA_ERATED_TS_AR_OPEN_GRA_001', 'CA_ERATED_GS_AP_OPEN_GRA_001', 'CA_ERATED_GS_AR_OPEN_GRA_001']
adls_source_schema    =  '_SYS_BIC'
source_system = 'saphana'

# COMMAND ----------

# DBTITLE 1,Get Parameters Values
dbutils.widgets.text("Environment", "DEV")
dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path",   "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/SENS/1ST_PARTY/SAPHANA")

ENV  = dbutils.widgets.get("Environment")
SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for Datasets
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_source_listTables])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# MAGIC %sql
# MAGIC clear cache;

# COMMAND ----------

# DBTITLE 1,Open Items Detailed
# MAGIC %sql
# MAGIC create or replace temporary view vw_sap_open_volume_detailed as
# MAGIC (SELECT 'STN_VENDOR' source_system,
# MAGIC        concat('STNSAP_Vendor_', (Replace(Ltrim(Replace(VENDOR, '0', ' ')), ' ', '0'))) account_number, 
# MAGIC        DOCUMENT_NO documentno,
# MAGIC        COMPANY_CD company_code,
# MAGIC        COMPANY_NAME company_name,
# MAGIC        LOC_CURR local_curr,
# MAGIC        CURRENCY_IN_DC doc_curr,
# MAGIC        SUM(CM_AMOUNT_LOC_CURR) open_amt_loc_curr,
# MAGIC        SUM(CM_AMOUNT_IN_DC) open_amt_dc,
# MAGIC        SUM(CM_AMOUNT_IN_USD) open_amt
# MAGIC FROM saphana_ca_erated_stn_ap_open_gra_001
# MAGIC GROUP BY VENDOR, DOCUMENT_NO, COMPANY_CD, COMPANY_NAME, LOC_CURR, CURRENCY_IN_DC)
# MAGIC union all
# MAGIC (SELECT 'STNSAP_CUSTOMER' source_system,
# MAGIC        concat('STNSAP_Customer_', Replace(Ltrim(Replace(CUSTOMER, '0', ' ')), ' ', '0')) account_number, 
# MAGIC        DOCUMENT_NO documentno,
# MAGIC        COMPANY_CD company_code,
# MAGIC        COMPANY_NAME company_name,
# MAGIC        LOC_CURR local_curr,
# MAGIC        CURRENCY_IN_DC doc_curr,
# MAGIC        SUM(CM_AMOUNT_LOC_CURR) open_amt_loc_curr,
# MAGIC        SUM(CM_AMOUNT_IN_DC) open_amt_dc,
# MAGIC        SUM(CM_AMOUNT_IN_USD) open_amt
# MAGIC from saphana_ca_erated_stn_ar_open_gra_001
# MAGIC group by CUSTOMER, DOCUMENT_NO, COMPANY_CD, COMPANY_NAME, LOC_CURR, CURRENCY_IN_DC)
# MAGIC union all
# MAGIC (SELECT 'TSAP_VENDOR' source_system,
# MAGIC        concat('TSAP_Vendor_', Replace(Ltrim(Replace(VENDOR, '0', ' ')), ' ', '0')) account_number, 
# MAGIC        DOCUMENT_NO documentno,
# MAGIC        COMPANY_CD company_code,
# MAGIC        COMPANY_NAME company_name,
# MAGIC        LOC_CURR local_curr,
# MAGIC        CURRENCY_IN_DC doc_curr,
# MAGIC        SUM(CM_AMOUNT_LOC_CURR) open_amt_loc_curr,
# MAGIC        SUM(CM_AMOUNT_IN_DC) open_amt_dc,
# MAGIC        SUM(CM_AMOUNT_IN_USD) open_amt
# MAGIC from saphana_ca_erated_ts_ap_open_gra_001
# MAGIC group by VENDOR, DOCUMENT_NO, COMPANY_CD, COMPANY_NAME, LOC_CURR, CURRENCY_IN_DC)
# MAGIC union all
# MAGIC (SELECT 'TSAP_CUSTOMER' source_system,
# MAGIC        concat('TSAP_Customer_', Replace(Ltrim(Replace(CUSTOMER, '0', ' ')), ' ', '0')) account_number, 
# MAGIC        DOCUMENT_NO documentno,
# MAGIC        COMPANY_CD company_code,
# MAGIC        COMPANY_NAME company_name,
# MAGIC        LOC_CURR local_curr,
# MAGIC        CURRENCY_IN_DC doc_curr,
# MAGIC        SUM(CM_AMOUNT_LOC_CURR) open_amt_loc_curr,
# MAGIC        SUM(CM_AMOUNT_IN_DC) open_amt_dc,
# MAGIC        SUM(CM_AMOUNT_IN_USD) open_amt
# MAGIC from saphana_ca_erated_ts_ar_open_gra_001
# MAGIC group by CUSTOMER, DOCUMENT_NO, COMPANY_CD, COMPANY_NAME, LOC_CURR, CURRENCY_IN_DC)
# MAGIC union all
# MAGIC (SELECT 'GSAP_VENDOR' source_system,
# MAGIC        concat('GSAP_Vendor_', Replace(Ltrim(Replace(VENDOR, '0', ' ')), ' ', '0')) account_number, 
# MAGIC        DOCUMENT_NO documentno,
# MAGIC        COMPANY_CD company_code,
# MAGIC        COMPANY_NAME company_name,
# MAGIC        LOC_CURR local_curr,
# MAGIC        CURRENCY_IN_DC doc_curr,
# MAGIC        SUM(CM_AMOUNT_LOC_CURR) open_amt_loc_curr,
# MAGIC        SUM(CM_AMOUNT_IN_DC) open_amt_dc,
# MAGIC        SUM(CM_AMOUNT_IN_USD) open_amt
# MAGIC from saphana_ca_erated_gs_ap_open_gra_001
# MAGIC group by VENDOR, DOCUMENT_NO, COMPANY_CD, COMPANY_NAME, LOC_CURR, CURRENCY_IN_DC)
# MAGIC union all
# MAGIC (SELECT 'GSAP_CUSTOMER' source_system,
# MAGIC        concat('GSAP_Customer_', Replace(Ltrim(Replace(CUSTOMER, '0', ' ')), ' ', '0')) account_number, 
# MAGIC        DOCUMENT_NO documentno,
# MAGIC        COMPANY_CD company_code,
# MAGIC        COMPANY_NAME company_name,
# MAGIC        LOC_CURR local_curr,
# MAGIC        CURRENCY_IN_DC doc_curr,
# MAGIC        SUM(CM_AMOUNT_LOC_CURR) open_amt_loc_curr,
# MAGIC        SUM(CM_AMOUNT_IN_DC) open_amt_dc,
# MAGIC        SUM(CM_AMOUNT_IN_USD) open_amt
# MAGIC from saphana_ca_erated_gs_ar_open_gra_001
# MAGIC group by CUSTOMER, DOCUMENT_NO, COMPANY_CD, COMPANY_NAME, LOC_CURR, CURRENCY_IN_DC)

# COMMAND ----------

df = spark.sql("select * from vw_sap_open_volume_detailed")
df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'sap_open_volume_detailed')

# COMMAND ----------

# MAGIC %sql
# MAGIC clear cache;

# COMMAND ----------

# DBTITLE 1,Cleared Items
# MAGIC %sql
# MAGIC create or replace temporary view vw_sap_open_ar_ap  as
# MAGIC (SELECT 'STN_VENDOR' source_system,
# MAGIC        concat('STNSAP_Vendor_', (Replace(Ltrim(Replace(VENDOR, '0', ' ')), ' ', '0'))) account_number, 
# MAGIC        0 open_ar,
# MAGIC        SUM(CM_AMOUNT_IN_USD) open_ap
# MAGIC FROM saphana_ca_erated_stn_ap_open_gra_001
# MAGIC GROUP BY VENDOR)
# MAGIC union all
# MAGIC (SELECT 'STNSAP_CUSTOMER' source_system,
# MAGIC        concat('STNSAP_Customer_', Replace(Ltrim(Replace(CUSTOMER, '0', ' ')), ' ', '0')) account_number, 
# MAGIC        SUM(CM_AMOUNT_IN_USD) open_ar,
# MAGIC        0 open_ap
# MAGIC from saphana_ca_erated_stn_ar_open_gra_001
# MAGIC group by CUSTOMER)
# MAGIC union all
# MAGIC (SELECT 'TSAP_VENDOR' source_system,
# MAGIC        concat('TSAP_Vendor_', Replace(Ltrim(Replace(VENDOR, '0', ' ')), ' ', '0')) account_number, 
# MAGIC        0 open_ar,
# MAGIC        SUM(CM_AMOUNT_IN_USD) open_ap
# MAGIC from saphana_ca_erated_ts_ap_open_gra_001
# MAGIC group by VENDOR)
# MAGIC union all
# MAGIC (SELECT 'TSAP_CUSTOMER' source_system,
# MAGIC        concat('TSAP_Customer_', Replace(Ltrim(Replace(CUSTOMER, '0', ' ')), ' ', '0')) account_number, 
# MAGIC        SUM(CM_AMOUNT_IN_USD) open_ar,
# MAGIC        0 open_ap
# MAGIC from saphana_ca_erated_ts_ar_open_gra_001
# MAGIC group by CUSTOMER)
# MAGIC union all
# MAGIC (SELECT 'GSAP_VENDOR' source_system,
# MAGIC        concat('GSAP_Vendor_', Replace(Ltrim(Replace(VENDOR, '0', ' ')), ' ', '0')) account_number, 
# MAGIC        0 as open_ar,
# MAGIC        SUM(CM_AMOUNT_IN_USD) open_ap
# MAGIC from saphana_ca_erated_gs_ap_open_gra_001
# MAGIC group by VENDOR)
# MAGIC union all
# MAGIC (SELECT 'GSAP_CUSTOMER' source_system,
# MAGIC        concat('GSAP_Customer_', Replace(Ltrim(Replace(CUSTOMER, '0', ' ')), ' ', '0')) account_number, 
# MAGIC        SUM(CM_AMOUNT_IN_USD) open_ar,
# MAGIC        0 as open_ap
# MAGIC from saphana_ca_erated_gs_ar_open_gra_001
# MAGIC group by CUSTOMER)

# COMMAND ----------

df = spark.sql("select * from vw_sap_open_ar_ap")
df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'sap_open_ar_ap')
