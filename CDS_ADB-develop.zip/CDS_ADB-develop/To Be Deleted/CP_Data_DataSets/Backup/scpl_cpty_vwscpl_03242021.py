# Databricks notebook source
# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'[scpl].[CPTY_SCPL]')
df.createOrReplaceTempView(f"scpl_CPTY_vwSCPL")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists vw_scpl_cpty_vwscpl_scpl;
# MAGIC create or replace temporary view vw_scpl_cpty_vwscpl_scpl as 
# MAGIC select 
# MAGIC   CptyGroupID
# MAGIC   , CptyID
# MAGIC   , CptyName
# MAGIC   , SystemUniquePrefix
# MAGIC   , GoldTierID
# MAGIC   , GT_LegalEntity
# MAGIC   , GT_DDLevel
# MAGIC   , GT_DDLevelApproved
# MAGIC   , GT_PolicyStatus
# MAGIC   , CptyUpdatedOn
# MAGIC   , current_timestamp() as META_CREATED_DTTM
# MAGIC   , current_timestamp() as EFFECTIVE_START_DATE
# MAGIC   , '9999-12-31' as EFFECTIVE_END_DATE
# MAGIC   , 1 as IS_RECORD_ACTIVE
# MAGIC   , 'SCPL' SOURCE_SYSTEM
# MAGIC   , ErateDate
# MAGIC   , EratedFlag
# MAGIC   , DeactivatedFlag
# MAGIC   , RecordStatusID
# MAGIC   , ProjectName
# MAGIC   , DispositionDetail
# MAGIC from scpl_CPTY_vwSCPL;

# COMMAND ----------

df = spark.sql("select *  from vw_scpl_cpty_vwscpl_scpl")
display(df)

# COMMAND ----------

'''def LoadSCPLToCuratedDB(tgt_schema_name, tgt_table_name, source_system):
  """
  Loads the data into sql server for curated layer
  tgt_schema_name = 'cp_data'
  tgt_tablename   = 'gtmi_singlecplist'
  source_system   = 'GOLD_TIER_MI'
  """
  try:
    df = spark.sql(f"select * from  vw_{tgt_table_name}_{source_system}")
    print(tgt_schema_name , tgt_table_name, source_system)
    if df.count() > 0:
      print(df.count())
      conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                            'SERVER='+dbServer_curated+';'
                            'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
                            'PWD='+dbPass
                            )
      cursor = conn.cursor()
      execSQL = f"delete from {tgt_schema_name}.{tgt_table_name} where source_system = upper('{source_system}')"
      conn.autocommit = True
      cursor.execute(execSQL)
      print("Data been Deleted")
      df.write.jdbc(Stratos_sqldb_URL_curated, f"{tgt_schema_name}.{tgt_table_name}", "append")
      print(f"load of {tgt_table_name}  with  is completed")
    else:
      print("Returned Zero Records")
      
  except Exception as e:
    print('Exception raised')
    raise dbutils.notebook.exit(e)'''

# COMMAND ----------

RefreshCuratedSqlTblWithDelete('pty_counterparty', 'scpl_cpty_vwscpl' , 'SCPL')

# COMMAND ----------


