# Databricks notebook source
# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

dbutils.widgets.text("DataSet_In_List", "")

# COMMAND ----------

dataset_list = ['scpl.ext_cpty_vwscpl_sens']
print(dataset_list)

# COMMAND ----------

print(CreateTempVwFromExternalTables(dataset_list))

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_scpl_cpty_vwscpl_scpl as 
# MAGIC select *, 'SCPL' as SOURCE_SYSTEM from scpl_ext_cpty_vwscpl_sens;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_scpl_cpty_vwscpl_scpl;

# COMMAND ----------

df = spark.sql("select *  from vw_scpl_cpty_vwscpl_scpl")
df.count()

# COMMAND ----------

RefreshSqlDbTbl('pty_counterparty', 'scpl_cpty_vwscpl' , 'SCPL')

# COMMAND ----------


