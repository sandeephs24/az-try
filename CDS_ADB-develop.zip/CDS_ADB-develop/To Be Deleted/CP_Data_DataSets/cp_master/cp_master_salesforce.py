# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

#to read data is ingested in table in curated db instead on ADLS
curated_schema_name= 'SFDC' 
curated_tables_list = ['E_Rate_All_Request__c']

for table_name in curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_SFDC_E_Rate_All_Request__c where E_RATED__C is not null
# MAGIC 
# MAGIC limit 10

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_ErateSalesForce as 
# MAGIC Select ERATE_FLAG,UNIQUE_ID,COUNTERPARTY_NAME,ERATE_COMPLETION_DATE, SYSTEM,META_CREATED_DTTM from (
# MAGIC select distinct  er.e_rated__c as ERATE_FLAG ,
# MAGIC er.UNIQUE_ID__c as UNIQUE_ID,
# MAGIC er.COUNTERPARTY_NAME_in_SYSTEM__c as COUNTERPARTY_NAME,
# MAGIC cast(UNIX_TIMESTAMP(er.e_rate_completion_date__c , "yyyy/MM/dd") as timestamp) as ERATE_COMPLETION_DATE,
# MAGIC --Row_Number() over(partition by er.UNIQUE_ID__c,er.e_rated__c,er.e_rate_completion_date__c,er.system__c
# MAGIC --order by er.CreatedDate desc) rn,
# MAGIC er.system__c as SYSTEM,
# MAGIC current_timestamp as META_CREATED_DTTM
# MAGIC from vw_SFDC_E_Rate_All_Request__c er
# MAGIC where Latest_Actioned_Request_Type__c = 'E-Rate' and Request_Status__c in ('Completed','Previously Actioned')
# MAGIC and er.Request_Type__c = 'E-Rate' and er.Latest_Actioned_Date__C = er.Date_Actioned_DD_MM_YYYY__c) s
# MAGIC 
# MAGIC --and cpty_erated_flag != '?'

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_ErateSalesForce")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC select count (distinct UNIQUE_ID ) from vw_cp_master_ErateSalesForce 

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master_ErateSalesForce')
