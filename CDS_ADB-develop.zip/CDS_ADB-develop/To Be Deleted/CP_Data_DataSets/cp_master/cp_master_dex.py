# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

create_temp_views_per_source_system('WONA_DWH', 'dex')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view  vw_dex_sto_chrgacct as 
# MAGIC select 
# MAGIC TRDG_COMP_MNEM
# MAGIC ,cast(cast(SEQUENCE_NUM as bigint) as string) as SEQUENCE_NUM
# MAGIC ,CHARGE_ACCT_MNEM
# MAGIC ,CHRG_ACCT_TYP_RT_C
# MAGIC ,CHRG_ACCT_TYP_CODE
# MAGIC ,CHARGE_ACCT_NAME
# MAGIC ,OWNING_USERID
# MAGIC ,COMPANY_MNEM
# MAGIC ,CMF_ACCOUNT_NUM
# MAGIC ,SAP_ACCOUNT_NUM
# MAGIC ,CR_CNTLR_NUM
# MAGIC ,LEVEL_NUM
# MAGIC ,LAST_UPDATE_TSTMP
# MAGIC ,DELETED_IND
# MAGIC ,LAST_RUN_TSTMP
# MAGIC ,SDW_VERSION_NUM
# MAGIC ,REACH_IMPORT_IND
# MAGIC ,US_PERS_STAT
# MAGIC ,EU_FNCL_STAT
# MAGIC ,TRDG_ACCT_SPEC_IND
# MAGIC ,CLT_MIFID_CODE
# MAGIC ,ACTIVE_REC_IND
# MAGIC ,CLEARED_CPTY_IND
# MAGIC ,SUPPLY_TRADE_IND
# MAGIC ,MANUFACTURING_IND
# MAGIC ,CLASS_OF_BUS_CODE
# MAGIC ,META_CREATED_DTTM
# MAGIC ,EFFECTIVE_START_DATE
# MAGIC ,EFFECTIVE_END_DATE
# MAGIC ,IS_RECORD_ACTIVE
# MAGIC from dex_sto_chrgacct

# COMMAND ----------

# MAGIC  %sql
# MAGIC  create or replace temporary view vw_cp_master_dex_addr as    --to get the address details
# MAGIC   select distinct compaddr.company_mnem,compaddr.seq_num,
# MAGIC           compaddr.preferred_ind,
# MAGIC           address.active_rec_ind,
# MAGIC           compaddr.address_type_code,
# MAGIC           addrline.last_update_tstmp as addrline_last_update_tstmp,
# MAGIC           compaddr.last_update_tstmp as compaddr_last_update_tstmp,
# MAGIC           address.last_update_tstmp as address_last_update_tstmp,
# MAGIC           concat_ws(' ',collect_list(cast(addrline.description_text as string)) 
# MAGIC           over (partition by compaddr.company_mnem order by addrline.line_num ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)) as full_address
# MAGIC         from dex_sto_compaddr compaddr
# MAGIC         left outer join dex_sto_address address   on compaddr.address_num = address.address_num
# MAGIC         left outer join dex_sto_addrline addrline on address.address_num = addrline.address_num

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_dex_addr")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_dex_base as    --to get the base data as per logic 
# MAGIC select distinct
# MAGIC     company.appv_bkr_ind as APPV_BKR_IND,
# MAGIC     company.company_mnem as L1_ID,
# MAGIC     --concat('DEX_',trim(company.company_mnem),'_',trim(string(chrgacct.sequence_num))) as UNIQUE_ID,
# MAGIC     case when trim(company.company_mnem) is null       then concat('DEX_',trim(string(chrgacct.sequence_num)))
# MAGIC     when trim(string(chrgacct.sequence_num)) is null   then concat('DEX_',trim(company.company_mnem),'_')
# MAGIC     else concat('DEX_',trim(company.company_mnem),'_',trim(string(chrgacct.sequence_num))) 
# MAGIC     end as UNIQUE_ID,
# MAGIC     chrgacct.sequence_num as L2_ID,
# MAGIC     /*case when company.line2_name is null then trim(company.line1_name)
# MAGIC          when company.line1_name is null then trim(company.line2_name)
# MAGIC          else trim(concat(trim(company.line1_name),' ',trim(company.line2_name))) 
# MAGIC     end as NAME,*/
# MAGIC     case when company.line1_name is null and company.line2_name is null then trim(chrgacct.charge_acct_name)
# MAGIC          when company.line2_name is null and company.line1_name is not null then trim(company.line1_name)
# MAGIC          when company.line1_name is null and company.line2_name is not null then trim(company.line2_name)
# MAGIC          else trim(concat(trim(company.line1_name),' ',trim(company.line2_name))) 
# MAGIC     end as NAME,
# MAGIC     company.line1_name as L1_NAME1,
# MAGIC     company.line2_name as L1_NAME2,
# MAGIC     chrgacct.charge_acct_name as L2_NAME1,
# MAGIC     chrgacct.charge_acct_mnem as L1_ID_NEW,
# MAGIC     company.cmf_short_name as CP_SHORT_NAME,
# MAGIC     company.company_type_code as L1_TYPE,
# MAGIC     case when company.company_type_code = 'A' then 'A_Affiliate'
# MAGIC          when company.company_type_code = 'G' then 'G_Government'
# MAGIC          when company.company_type_code = 'A' then 'A_Affiliate'
# MAGIC          when company.company_type_code = 'T' then 'T_3rd_Party'
# MAGIC          else company.company_type_code 
# MAGIC     end as ENTITY_TYPE,
# MAGIC     company.owning_mnem as PARENT,
# MAGIC     chrgacct.chrg_acct_typ_rt_c as L2_TYPE,
# MAGIC     chrgacct.sap_account_num as  SAP_ACCOUNT_NUM,
# MAGIC     case when ltrim('0',trim(chrgacct.sap_account_num)) = '' or chrgacct.sap_account_num is null then null 
# MAGIC          else 'STNSAP'
# MAGIC     end as SAP_SYSTEM,
# MAGIC     case when ltrim('0',trim(chrgacct.sap_account_num)) = '' or chrgacct.sap_account_num is null then null 
# MAGIC          else 'L2'
# MAGIC     end as SAP_LINK_LEVEL,
# MAGIC     ltrim('0',trim(chrgacct.sap_account_num)) as SAP_ACCOUNT_NO,
# MAGIC     case when ltrim('0',trim(chrgacct.sap_account_num)) = '' or chrgacct.sap_account_num is null then null 
# MAGIC          when cast(Substring(trim(chrgacct.sap_account_num),0,1) as double) is not null then lpad(trim(chrgacct.sap_account_num), 10,'0')  
# MAGIC          else trim(chrgacct.sap_account_num)
# MAGIC     end as SAP_ACCOUNT,
# MAGIC     --company.META_CREATED_DTTM,
# MAGIC     case when company.META_CREATED_DTTM is null 
# MAGIC       then chrgacct.META_CREATED_DTTM else company.META_CREATED_DTTM end as META_CREATED_DTTM,
# MAGIC     chrgacct.last_update_tstmp as LAST_UPDATE_TSTMP,
# MAGIC     --case when chrgacct.active_rec_ind = 'N' then 'X' else null end as DEACTIVATED,
# MAGIC     case when chrgacct.last_update_tstmp is null then cast(company.last_update_tstmp as date)
# MAGIC          else cast(chrgacct.last_update_tstmp as date)
# MAGIC     end as CREATED_UPDATED,
# MAGIC     --end as LAST_UPDATE_DATE,
# MAGIC     addr.full_address as FULL_ADDRESS,
# MAGIC     addr.seq_num as SEQ_NUM,
# MAGIC     addr.preferred_ind as PREFERRED_IND,
# MAGIC     --addr.active_rec_ind as ACTIVE_REC_IND,
# MAGIC     chrgacct.active_rec_ind as ACTIVE_REC_IND,
# MAGIC     addr.address_type_code as ADDRESS_TYPE_CODE,
# MAGIC     compcrrg.credit_rating_date as CREDIT_RATING_DATE,
# MAGIC     compcrrg.credit_rating_time as CREDIT_RATING_TIME,
# MAGIC     chrgacct.chrg_acct_typ_code as CHRG_ACCT_TYP_CODE,
# MAGIC     addr.addrline_last_update_tstmp as ADDRLINE_LAST_UPDATE_TSTMP,
# MAGIC     company.last_update_tstmp as COMPANY_LAST_UPDATE_TSTMP,
# MAGIC     addr.compaddr_last_update_tstmp as COMPADDR_LAST_UPDATE_TSTMP,
# MAGIC     addr.address_last_update_tstmp as ADDRESS_LAST_UPDATE_TSTMP,
# MAGIC     compcrrg.credit_rating_code as CREDIT_RATING_CODE,
# MAGIC     case when compcrrg.credit_rating_code = 'P' then 'Y' else 'N' end as ERATE_FLAG,
# MAGIC     case when trim(company.line1_name) is null then '' else concat(company.line1_name,' ') end as LE_NAME_P1,
# MAGIC     case when trim(company.line2_name) is null then '' else concat(company.line2_name,' ') end as LE_NAME_P2,
# MAGIC     case when trim(chrgacct.charge_acct_name) is null then '' else chrgacct.charge_acct_name end as LE_NAME_P3
# MAGIC     from dex_sto_company company
# MAGIC     full outer join vw_dex_sto_chrgacct chrgacct on company.company_mnem = chrgacct.company_mnem  
# MAGIC     left outer join vw_cp_master_dex_addr addr on company.company_mnem = addr.company_mnem
# MAGIC     left outer join dex_sto_compcrrg compcrrg on compcrrg.company_mnem = company.company_mnem   

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_dex_base")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_dex_union as  --to get all records with null SAP Account no. once and other records twice - one for vendor and one for customer
# MAGIC (select *, 1 as rowcount from vw_cp_master_dex_base) 
# MAGIC union all
# MAGIC (select *, 2 as rowcount from vw_cp_master_dex_base where ltrim('0',trim(SAP_ACCOUNT_NUM)) != '' and SAP_ACCOUNT_NUM is not null)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_dex as  --to get the output data in required columns sequence
# MAGIC select 
# MAGIC     APPV_BKR_IND,
# MAGIC     'DEX' as SYSTEM,
# MAGIC     L1_ID,
# MAGIC     UNIQUE_ID,
# MAGIC     L2_ID,
# MAGIC     NAME,
# MAGIC     L1_NAME1,
# MAGIC     L1_NAME2,
# MAGIC     L2_NAME1,
# MAGIC     L1_ID_NEW,
# MAGIC     CP_SHORT_NAME,
# MAGIC     L1_TYPE,
# MAGIC     ENTITY_TYPE,
# MAGIC     PARENT,
# MAGIC     L2_TYPE,
# MAGIC     SAP_ACCOUNT_NUM,
# MAGIC     SAP_SYSTEM,
# MAGIC     case when ltrim('0',trim(SAP_ACCOUNT_NUM)) = '' or SAP_ACCOUNT_NUM is null then null
# MAGIC       else concat('STNSAP_',(case when rowcount = 1 then 'Customer' else 'Vendor' end),'_',ltrim('0',trim(replace(SAP_ACCOUNT_NUM,'_',''))))
# MAGIC     end as SAP_UNIQUE_ID,
# MAGIC     case when ltrim('0',trim(SAP_ACCOUNT_NUM)) = '' or SAP_ACCOUNT_NUM is null then null 
# MAGIC       when rowcount = 1 then 'Customer' else 'Vendor'
# MAGIC     end as SAP_CPTY_TYPE,
# MAGIC     SAP_LINK_LEVEL,
# MAGIC     SAP_ACCOUNT_NO,
# MAGIC     SAP_ACCOUNT,
# MAGIC     CAST(META_CREATED_DTTM AS TIMESTAMP),
# MAGIC     CAST(LAST_UPDATE_TSTMP AS TIMESTAMP),
# MAGIC     --ACTIVE_REC_IND as DEACTIVATED,
# MAGIC     case when  ACTIVE_REC_IND = 'N' then 'Y'  else 'N' end as DEACTIVATED, -- cp_deactivated
# MAGIC     CREATED_UPDATED,
# MAGIC     FULL_ADDRESS,
# MAGIC     SEQ_NUM,
# MAGIC     PREFERRED_IND,
# MAGIC     --ACTIVE_REC_IND,
# MAGIC     --ACTIVE_REC_IND_1,
# MAGIC     ADDRESS_TYPE_CODE,
# MAGIC     cast(CREDIT_RATING_DATE as Date) AS CREDIT_RATING_DATE,
# MAGIC     CREDIT_RATING_TIME,
# MAGIC     CHRG_ACCT_TYP_CODE,
# MAGIC     CAST(ADDRLINE_LAST_UPDATE_TSTMP AS timestamp) AS ADDRLINE_LAST_UPDATE_TSTMP,
# MAGIC     CAST(COMPANY_LAST_UPDATE_TSTMP  AS timestamp) AS COMPANY_LAST_UPDATE_TSTMP,
# MAGIC     CAST(COMPADDR_LAST_UPDATE_TSTMP AS timestamp) AS COMPADDR_LAST_UPDATE_TSTMP,
# MAGIC     CAST(ADDRESS_LAST_UPDATE_TSTMP  AS timestamp) AS ADDRESS_LAST_UPDATE_TSTMP,
# MAGIC     CREDIT_RATING_CODE,
# MAGIC     --concat(LE_NAME_P1,'_',LE_NAME_P2,'_',LE_NAME_P3) as CP_LEGAL_ENTITY_NAME,
# MAGIC     concat(LE_NAME_P1,LE_NAME_P2,LE_NAME_P3) as CP_LEGAL_ENTITY_NAME,
# MAGIC     ERATE_FLAG,
# MAGIC     'WONA_DWH' as SOURCE_SYSTEM    
# MAGIC from vw_cp_master_dex_union

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_dex")
df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master_dex')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_cp_master_dex
# MAGIC where UNIQUE_ID = 'DEX_RSNTDTB_29408'

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_erate_flag as 
# MAGIC select * from
# MAGIC (
# MAGIC   select distinct company_mnem, credit_rating_date, credit_rating_time, credit_rating_code,
# MAGIC   dense_rank() over (partition by company_mnem order by credit_rating_date desc, credit_rating_time desc) as seq_num
# MAGIC   from dex_sto_compcrrg
# MAGIC )
# MAGIC where seq_num = 1

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master as 
# MAGIC select distinct 
# MAGIC     UNIQUE_ID             as cp_unique_id,                      --REQ-26
# MAGIC     L1_ID                 as cp_l1_id,                          --REQ-28
# MAGIC     NAME                  as cp_name,                           --REQ-27
# MAGIC     case when L1_ID_NEW is null                                 --L1_ID = company.company_mnem, L1_ID_NEW = chrgacct.charge_acct_mnem
# MAGIC       then L1_ID else L1_ID_NEW 
# MAGIC     end                   as cp_etrm_account_no,                
# MAGIC     L2_ID                 as cp_l2_id,                          --REQ-29
# MAGIC     L2_NAME1              as cp_l2_name,                        --REQ-30                          
# MAGIC     L1_TYPE               as cp_entity_type,                    --REQ-31
# MAGIC     CREATED_UPDATED       as cp_created_or_updated_date,        --REQ-34
# MAGIC     --case when DEACTIVATED is null then '' else DEACTIVATED  end                   as cp_deactivated,                    --REQ-32
# MAGIC     DEACTIVATED           as cp_deactivated,                     -- REQ-32 changed on 4/20/2021 by rama
# MAGIC     FULL_ADDRESS          as cp_country,                        --REQ-91
# MAGIC     PARENT                as cp_parent,                         --REQ-87
# MAGIC     SYSTEM                as cp_system,                         --REQ-36
# MAGIC     SAP_ACCOUNT_NO        as cp_linked_sap_id,                  --REQ-93
# MAGIC     SAP_CPTY_TYPE         as cp_sap_account_type,               --REQ-38
# MAGIC     SAP_UNIQUE_ID         as cp_sap_unique_id,                  --REQ-97
# MAGIC     SAP_SYSTEM            as cp_linked_sap_system,              --REQ-93
# MAGIC     case when (SAP_UNIQUE_ID is null or length(trim(SAP_UNIQUE_ID)) = 0 ) 
# MAGIC       then 'NO SAP LINK' ELSE 'SAP LINK' 
# MAGIC     END                   as cp_sap_link,                       
# MAGIC     case when B.credit_rating_code = 'P' 
# MAGIC       then 'Y' else 'N' 
# MAGIC     end                   as cp_erate_flag_in_source,           --REQ-9
# MAGIC     CAST(B.credit_rating_date  AS DATE) as cp_erate_date_in_source,           --REQ-10
# MAGIC     cast(null as DATE)  as cp_erate_lifted_date_in_source,    --REQ-11
# MAGIC     APPV_BKR_IND          as cp_broker_indicator,               --REQ-86
# MAGIC     case when L1_ID_NEW is null 
# MAGIC       then L1_ID else L1_ID_NEW 
# MAGIC     end                   as cp_mapping_id,                     
# MAGIC     SOURCE_SYSTEM         as source_system,                     --Metadata Column       
# MAGIC     META_CREATED_DTTM     as meta_created_dttm                  --Metadata Column       
# MAGIC from vw_cp_master_dex A
# MAGIC left outer join vw_cp_master_erate_flag B on A.L1_ID = B.company_mnem

# COMMAND ----------

df = spark.sql("select * from vw_cp_master")
df.count()

# COMMAND ----------

DeleteInsertCuratedSqlTbl('pty_counterparty', 'cp_master', 'WONA_DWH')
