# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# DBTITLE 1,Run dataset dependencies
# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

# source_system , view_prefix_name  parameters to pass to the function
#create_temp_views_per_source_system('ENDUR_GP_NA', 'gpna')
create_temp_views_per_source_system('SLMT', 'slmt')

# COMMAND ----------

#Parameters
dbutils.widgets.text("Environment", "UAT")
dbutils.widgets.text("NON_SENS_ADLS_ENR_UNHARM_Path",   "/mnt/ADLS/PROJECT/P00005-TS-PRE-PROD/ENR_UNHARM/NON-SENS/1ST_PARTY/ENDUR_LNG_PRD/")
dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path",      "/mnt/ADLS/PROJECT/P00005-TS-PRE-PROD/ENR_UNHARM/SENS/1ST_PARTY/ENDUR_LNG_PRD/")

ENV  = dbutils.widgets.get("Environment")
NON_SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("NON_SENS_ADLS_ENR_UNHARM_Path")
SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

#List of tables
#non_sens_full_source_listTables_edw = ['INTERNAL_EXTERNAL', 'PARTY_CLASS', 'PARTY_STATUS', 'NO_YES', 'PARTY_FUNCTION', 'FUNCTION_TYPE']
#non_sens_inc_source_listTables_edw = ['STATES', 'COUNTRY', 'PARTY_GROUP_MEMB', 'PARTY_RATING', 'CREDIT_RATING', 'PARTY_CREDIT_RATING', 'PARTY_RELATIONSHIP']
non_sens_full_source_listTables_edw = ['INTERNAL_EXTERNAL', 'PARTY_CLASS', 'PARTY_STATUS', 'NO_YES', 'PARTY_FUNCTION', 'FUNCTION_TYPE','STATES', 'COUNTRY', 'PARTY_GROUP_MEMB', 'PARTY_RATING', 'CREDIT_RATING', 'PARTY_CREDIT_RATING', 'PARTY_RELATIONSHIP']

#sens_inc_source_listTables_edw =   ['PARTY', 'PERSONNEL', 'PARTY_GROUP', 'PARTY_INFO']
#sens_full_source_listTables_edw =   ['LEGAL_ENTITY']
sens_full_source_listTables_edw =   ['LEGAL_ENTITY','PARTY', 'PERSONNEL', 'PARTY_GROUP', 'PARTY_INFO']

adls_source_schema = 'ENDUR'
source_system = 'endur_lng'

# COMMAND ----------

#Create Dataframe and Temporary Views for Sens Inc Tables from ADLS
#FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_inc_source_listTables_edw])

#create dataframe for Inc load
#dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

#for key,value in dataframedict.items():
#  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

#Create Dataframe and Temporary Views for Sens Full Tables from ADLS
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_full_source_listTables_edw])

#create dataframe for Full load
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# Create Dataframe and Temporary Views for Non-Sens Inc Tables from ADLS
#FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_inc_source_listTables_edw])

#create dataframe for Inc Load
#dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

#for key,value in dataframedict.items():
#  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")
  
# Create Dataframe and Temporary Views for Non-Sens Full Tables from ADLS
FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_full_source_listTables_edw])

#create dataframe for Full Load
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from endur_lng_party where party_id= 26504

# COMMAND ----------

# MAGIC %sql
# MAGIC --select count(*) from endur_lng_PERSONNEL;
# MAGIC --select count(*) from endur_lng_AB_TRAN;
# MAGIC --select count(*) from endur_lng_PARTY_CLASS;
# MAGIC --select count(*) from endur_lng_PARTY_CREDIT_RATING;
# MAGIC --select count(*) from endur_lng_PARTY_GROUP;
# MAGIC --select count(*) from endur_lng_PARTY_GROUP_MEMB;
# MAGIC --select count(*) from endur_lng_PARTY_INFO;
# MAGIC --select count(*) from endur_lng_PARTY_RATING;
# MAGIC --select count(*) from endur_lng_LEGAL_ENTITY;
# MAGIC --select count(*) from endur_lng_PARTY_STATUS;
# MAGIC --select count(*) from endur_lng_AB_TRAN_AGREEMENT;
# MAGIC --select count(*) from endur_lng_INTERNAL_EXTERNAL;
# MAGIC --select count(*) from endur_lng_STATES;
# MAGIC --select count(*) from endur_lng_NO_YES;
# MAGIC --select count(*) from endur_lng_COUNTRY;
# MAGIC --select count(*) from endur_lng_CREDIT_RATING_SOURCE;
# MAGIC --select count(*) from endur_lng_CREDIT_RATING;

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC create or replace temporary view vw_cp_slmt_mrd_business_unit_master as  -- removed ENDUR_LNG in the name at end 
# MAGIC (
# MAGIC   --Step 1.
# MAGIC   with query_one as
# MAGIC   (
# MAGIC   SELECT DISTINCT party.party_id, 
# MAGIC    int_ext.name type, 
# MAGIC    pc.name party_class, 
# MAGIC    party.party_class party_class_id, 
# MAGIC    ps.name status, 
# MAGIC    party.Short_Name, 
# MAGIC    party.Long_Name, 
# MAGIC    per_created.name created_by, 
# MAGIC    CONCAT(per_created.first_name,(' '||per_created.last_name)) created_by_name,
# MAGIC    per_updated.name updated_by, 
# MAGIC    CONCAT(per_updated.first_name,(' '||per_updated.last_name)) le_updated_by_name,
# MAGIC    to_date(party.Last_Update) as Last_Update, 
# MAGIC    party.party_version version, 
# MAGIC    no_yes.name Agency_Activities, 
# MAGIC    party.Linked_Party_Id, 
# MAGIC    le.addr1 address_1, 
# MAGIC    le.addr2 address_2, 
# MAGIC    le.city, 
# MAGIC    states.short_name state, 
# MAGIC    country.name country, 
# MAGIC    le.mail_code, 
# MAGIC    le.phone, 
# MAGIC    le.fax, 
# MAGIC    le.description, 
# MAGIC    le.int_ref1 internal_reference_1, 
# MAGIC    le.int_ref2 internal_reference_2, 
# MAGIC    le.int_ref3 internal_reference_3, 
# MAGIC    pg.short_name party_group, 
# MAGIC    pi_sap_cust.value lng_sap_customer, 
# MAGIC    pi_sap_ven.value lng_sap_vendor, 
# MAGIC    pi_int_sap_cust.value lng_int_sap_customer, 
# MAGIC    pi_int_sap_ven.value lng_int_sap_vendor, 
# MAGIC    pi_comp_code.value lng_company_code, 
# MAGIC    CASE party.int_ext 
# MAGIC      WHEN 0 
# MAGIC      THEN pi_int_remit_rep.value 
# MAGIC      ELSE pi_remit_rep.value 
# MAGIC    END remit_reprotable, 
# MAGIC    pi_qgc_sap_cust.value qgc_sap_cust, 
# MAGIC    pi_qgc_sap_vend.value qgc_sap_vend, 
# MAGIC    pi_sgm_sap_cust.value sgm_sap_cust, 
# MAGIC    pi_sgm_sap_vend.value sgm_sap_vend, 
# MAGIC    pi_sgm_sap_ic_cust.value sgm_sap_ic_cust, 
# MAGIC    pi_sgm_sap_ic_vend.value sgm_sap_ic_vend, 
# MAGIC    pr.name party_rating, 
# MAGIC    pgm.group_id, 
# MAGIC    cr.rating_name,
# MAGIC    to_date(party.meta_created_dttm) as meta_created_dttm
# MAGIC    --+ Date of maximum end date of any load / discharge for any associated deal for any associated party agreement, 
# MAGIC  FROM endur_lng_party party
# MAGIC  left outer join endur_lng_legal_entity le on party.party_id = le.party_id
# MAGIC  left outer join endur_lng_states states on le.state_id = states.state_id
# MAGIC  left outer join endur_lng_country country on le.country = country.id_number
# MAGIC  left outer join endur_lng_party_group_memb pgm on party.party_id           = pgm.party_id
# MAGIC  left outer join endur_lng_party_group pg on pgm.group_id                   = pg.group_id
# MAGIC  left outer join endur_lng_party_info pi_sap_cust on party.party_id         = pi_sap_cust.party_id and  pi_sap_cust.type_id  = 20176
# MAGIC  left outer join endur_lng_party_info pi_sap_ven on party.party_id          = pi_sap_ven.party_id and pi_sap_ven.type_id   = 20174 -- LNG Ext SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_int_sap_cust on party.party_id     = pi_int_sap_cust.party_id and pi_int_sap_cust.type_id  = 20177 -- LNG Int SAP Customer  
# MAGIC  left outer join endur_lng_party_info pi_int_sap_ven on party.party_id      = pi_int_sap_ven.party_id and pi_int_sap_ven.type_id   = 20175 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_comp_code on party.party_id        = pi_comp_code.party_id and pi_comp_code.type_id     = 20173 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_int_remit_rep on party.party_id    = pi_int_remit_rep.party_id and pi_int_remit_rep.type_id = 20183 -- Remit Reportable Internal 
# MAGIC  left outer join endur_lng_party_info pi_remit_rep on party.party_id        = pi_remit_rep.party_id and pi_remit_rep.type_id = 20184 -- Remit Reportable External 
# MAGIC  left outer join endur_lng_party_info pi_qgc_sap_cust on party.party_id     = pi_qgc_sap_cust.party_id and pi_qgc_sap_cust.type_id  = 20166 -- QGC SAP Customer 
# MAGIC  left outer join endur_lng_party_info pi_qgc_sap_vend on party.party_id     = pi_qgc_sap_vend.party_id and pi_qgc_sap_vend.type_id  = 20167 -- QGC SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_cust on party.party_id     = pi_sgm_sap_cust.party_id and pi_sgm_sap_cust.type_id  = 20149 -- SGM SAP Customer 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_vend on party.party_id     = pi_sgm_sap_vend.party_id and pi_sgm_sap_vend.type_id  = 20150 -- SGM SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_ic_cust on party.party_id  = pi_sgm_sap_ic_cust.party_id and pi_sgm_sap_ic_cust.type_id  = 20188 -- SGM SAP IC Customer 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_ic_vend on party.party_id  = pi_sgm_sap_ic_vend.party_id and pi_sgm_sap_ic_vend.type_id  = 20189 -- SGM SAP IC Vendor 
# MAGIC  left outer join endur_lng_party_rating pr on le.party_rating               = pr.id_number
# MAGIC  left outer join endur_lng_party_credit_rating pcr on party.party_id        = pcr.party_id
# MAGIC  left outer join endur_lng_credit_rating cr        on pcr.rating_id         = cr.rating_id,
# MAGIC   endur_lng_party_status ps,
# MAGIC   endur_lng_internal_external int_ext,
# MAGIC   endur_lng_personnel per_created,
# MAGIC   endur_lng_personnel per_updated,
# MAGIC   endur_lng_party_class pc,
# MAGIC   endur_lng_no_yes no_yes
# MAGIC  WHERE party.int_ext               =int_ext.id_number 
# MAGIC  AND party.party_class           = pc.id_number 
# MAGIC  AND party.party_status          = ps.id_number 
# MAGIC  AND party.inputter_id           = per_created.id_number 
# MAGIC  AND party.authoriser_id         = per_updated.id_number 
# MAGIC  AND party.Agency_Activities     = no_yes.id_number
# MAGIC  ),
# MAGIC  
# MAGIC  --Step 3.
# MAGIC  query_two as
# MAGIC  (
# MAGIC  SELECT DISTINCT pf.party_id,  
# MAGIC    p.short_name,  
# MAGIC    p.int_ext,  
# MAGIC    concat_ws(";", collect_list(ft.name)) as functions--,  --Step 4.
# MAGIC    --concat_ws(";", ft.name) as functions--,
# MAGIC    --pr.business_unit_id  
# MAGIC    FROM endur_lng_party_function pf, 
# MAGIC    --left outer join endur_lng_party_relationship pr on pf.party_id = pr.business_unit_id,  
# MAGIC    endur_lng_party p,  
# MAGIC    endur_lng_function_type ft  
# MAGIC  WHERE pf.party_id = p.party_id  
# MAGIC  AND pf.function_type =ft.id_number
# MAGIC  group by pf.party_id, p.short_name, p.int_ext--, pr.business_unit_id, ft.name
# MAGIC  ),
# MAGIC  
# MAGIC  --Step 5.
# MAGIC  query_three as
# MAGIC  ( 
# MAGIC   SELECT DISTINCT pr.legal_entity_id,  
# MAGIC    pr.business_unit_id  
# MAGIC  FROM endur_lng_party_relationship pr 
# MAGIC  )
# MAGIC  
# MAGIC  -- Step 4 - Output 1.
# MAGIC  select query_one.party_id as Party_Id,
# MAGIC 		query_one.type as Type,
# MAGIC 		query_one.status as Status,
# MAGIC 		query_one.short_name as CP_BU_SHORT_NAME,
# MAGIC 		query_one.long_name as CP_BU_LONG_NAME,
# MAGIC 		query_one.created_by as Created_By,
# MAGIC 		query_one.updated_by as LE_Updated_By,
# MAGIC 		query_one.last_update as LE_Last_Updated,
# MAGIC 		query_one.version as Version,
# MAGIC 		--query_one.linked_party_id as Linked_Party_Id,
# MAGIC         --query_three.business_unit_id as linked_party_id,
# MAGIC         nvl(query_three.legal_entity_id,query_one.party_id) as linked_party_id,
# MAGIC 		query_one.party_group as Party_Group,
# MAGIC         query_one.lng_sap_customer as LNG_SAP_Customer,
# MAGIC 		query_one.lng_sap_vendor as LNG_SAP_Vendor,
# MAGIC 		query_one.lng_int_sap_customer as LNG_Int_SAP_Customer,
# MAGIC 		query_one.lng_int_sap_vendor as LNG_Int_SAP_Vendor,
# MAGIC 		query_one.lng_company_code as LNG_Company_Code,
# MAGIC 		query_one.remit_reprotable as Remit_Reportable,
# MAGIC 		query_one.qgc_sap_cust as QGC_SAP_Customer,
# MAGIC 		query_one.qgc_sap_vend as QGC_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_cust as SGM_SAP_Customer,
# MAGIC 		query_one.sgm_sap_vend as SGM_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_ic_cust as SGM_SAP_IC_Customer,
# MAGIC 		query_one.sgm_sap_ic_vend as SGM_SAP_IC_Vendor,
# MAGIC         query_one.party_rating    as Credit_Internal_Rating,
# MAGIC 		query_one.rating_name     as SHELL_CREDIT_RATING,
# MAGIC 		query_two.functions       as BU_Functions,
# MAGIC         'ENDUR_LNG' as source_system,
# MAGIC         query_one.meta_created_dttm
# MAGIC         --query_three.business_unit_id as linked_party_id
# MAGIC   from query_one
# MAGIC   -- Step 4
# MAGIC   left outer join  query_two on query_one.party_id=query_two.party_id
# MAGIC   -- Step 6
# MAGIC   left outer join query_three on query_one.party_id=query_three.business_unit_id
# MAGIC   -- Step 2.
# MAGIC   where query_one.party_class_id !=0 --/*This will exclude all Legal Entities */
# MAGIC   )
# MAGIC  ;
# MAGIC           

# COMMAND ----------

# DBTITLE 1,Testing
#df = spark.sql("select * from vw_cp_slmt_mrd_business_unit_master_ENDUR_LNG") 
df = spark.sql("select * from vw_cp_slmt_mrd_business_unit_master")


# COMMAND ----------

df.count()

# COMMAND ----------

# DBTITLE 1,Load dataset into SQL DB
#RefreshSqlDbTbl('pty_counterparty', 'cp_slmt_mrd_business_unit_master', 'ENDUR_LNG')
RefreshCuratedSqlTbl('pty_counterparty', 'cp_slmt_mrd_business_unit_master')

# COMMAND ----------

#Parameters
dbutils.widgets.text("Environment", "UAT")
dbutils.widgets.text("NON_SENS_ADLS_ENR_UNHARM_Path",   "/mnt/ADLS/PROJECT/P00005-TS-PRE-PROD/ENR_UNHARM/NON-SENS/1ST_PARTY/ENDUR_LNG_PRD/")
dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path",   "/mnt/ADLS/PROJECT/P00005-TS-PRE-PROD/ENR_UNHARM/SENS/1ST_PARTY/ENDUR_LNG_PRD/")

ENV  = dbutils.widgets.get("Environment")
NON_SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("NON_SENS_ADLS_ENR_UNHARM_Path")
SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

#List of tables
#non_sens_full_source_listTables_edw = ['INTERNAL_EXTERNAL', 'PARTY_CLASS', 'PARTY_STATUS', 'NO_YES', 'AB_TRAN_AGREEMENT']
#non_sens_inc_source_listTables_edw = ['STATES', 'COUNTRY', 'PARTY_GROUP_MEMB', 'PARTY_RATING', 'CREDIT_RATING', 'PARTY_CREDIT_RATING', 'PARTY_RELATIONSHIP']
non_sens_full_source_listTables_edw = ['INTERNAL_EXTERNAL', 'PARTY_CLASS', 'PARTY_STATUS', 'NO_YES', 'AB_TRAN_AGREEMENT','STATES', 'COUNTRY', 'PARTY_GROUP_MEMB', 'PARTY_RATING', 'CREDIT_RATING', 'PARTY_CREDIT_RATING', 'PARTY_RELATIONSHIP']

#sens_inc_source_listTables_edw =   [ 'PERSONNEL', 'PARTY_GROUP', 'PARTY_INFO', 'AB_TRAN']
#sens_full_source_listTables_edw =   ['PARTY','LEGAL_ENTITY']
sens_full_source_listTables_edw =   ['PARTY','LEGAL_ENTITY','PERSONNEL', 'PARTY_GROUP', 'PARTY_INFO', 'AB_TRAN']

adls_source_schema = 'ENDUR'
source_system = 'endur_lng'

# COMMAND ----------

#Create Dataframe and Temporary Views for Sens Inc Tables from ADLS
#FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_inc_source_listTables_edw])

#create dataframe for Inc load
#dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

#for key,value in dataframedict.items():
#  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

#Create Dataframe and Temporary Views for Sens Full Tables from ADLS
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_full_source_listTables_edw])

#create dataframe for Full load
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# Create Dataframe and Temporary Views for Non-Sens Inc Tables from ADLS
#FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_inc_source_listTables_edw])

#create dataframe for Inc Load
#dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

#for key,value in dataframedict.items():
#  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")
  
# Create Dataframe and Temporary Views for Non-Sens Full Tables from ADLS
FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_full_source_listTables_edw])

#create dataframe for Full Load
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC   --Step 1.
# MAGIC   create or replace temporary view vw_cp_slmt_mrd_legal_entity_master_tmp1 as  -- removed _ENDUR_LNG in the name at the end. 
# MAGIC   (
# MAGIC   with query_one as
# MAGIC   (
# MAGIC   SELECT DISTINCT party.party_id, 
# MAGIC    int_ext.name type, 
# MAGIC    pc.name party_class, 
# MAGIC    party.party_class party_class_id, 
# MAGIC    ps.name status, 
# MAGIC    party.Short_Name, 
# MAGIC    party.Long_Name, 
# MAGIC    per_created.name created_by, 
# MAGIC    CONCAT(per_created.first_name,(' '||per_created.last_name)) created_by_name,
# MAGIC    per_updated.name updated_by, 
# MAGIC    CONCAT(per_updated.first_name,(' '||per_updated.last_name)) le_updated_by_name,
# MAGIC    to_date(party.Last_Update) as Last_Update, 
# MAGIC    party.party_version version, 
# MAGIC    no_yes.name Agency_Activities, 
# MAGIC    party.Linked_Party_Id, 
# MAGIC    le.addr1 address_1, 
# MAGIC    le.addr2 address_2, 
# MAGIC    le.city, 
# MAGIC    states.short_name state, 
# MAGIC    country.name country, 
# MAGIC    le.mail_code, 
# MAGIC    le.phone, 
# MAGIC    le.fax, 
# MAGIC    le.description, 
# MAGIC    le.int_ref1 internal_reference_1, 
# MAGIC    le.int_ref2 internal_reference_2, 
# MAGIC    le.int_ref3 internal_reference_3, 
# MAGIC    pg.short_name party_group, 
# MAGIC    pi_sap_cust.value lng_sap_customer, 
# MAGIC    pi_sap_ven.value lng_sap_vendor, 
# MAGIC    pi_int_sap_cust.value lng_int_sap_customer, 
# MAGIC    pi_int_sap_ven.value lng_int_sap_vendor, 
# MAGIC    pi_comp_code.value lng_company_code, 
# MAGIC    CASE party.int_ext 
# MAGIC      WHEN 0 
# MAGIC      THEN pi_int_remit_rep.value 
# MAGIC      ELSE pi_remit_rep.value 
# MAGIC    END remit_reprotable, 
# MAGIC    pi_qgc_sap_cust.value qgc_sap_cust, 
# MAGIC    pi_qgc_sap_vend.value qgc_sap_vend, 
# MAGIC    pi_sgm_sap_cust.value sgm_sap_cust, 
# MAGIC    pi_sgm_sap_vend.value sgm_sap_vend, 
# MAGIC    pi_sgm_sap_ic_cust.value sgm_sap_ic_cust, 
# MAGIC    pi_sgm_sap_ic_vend.value sgm_sap_ic_vend, 
# MAGIC    pr.name party_rating, 
# MAGIC    pgm.group_id, 
# MAGIC    cr.rating_name
# MAGIC    --case when pi_ext_sap_ven.type_id   = 20174 or pi_int_sap_ven.type_id   = 20175 then "Vendor"
# MAGIC    --     when pi_ext_sap_cust.type_id   = 20176 or pi_int_sap_cust.type_id   = 20177 then "Customer" end as sap_cpty_type
# MAGIC    --+ Date of maximum end date of any load / discharge for any associated deal for any associated party agreement, 
# MAGIC  FROM endur_lng_party party
# MAGIC  inner join endur_lng_party_status ps on party.party_status          = ps.id_number
# MAGIC  inner join  endur_lng_internal_external int_ext on party.int_ext               =int_ext.id_number 
# MAGIC  inner join endur_lng_personnel per_created on party.inputter_id           = per_created.id_number 
# MAGIC  inner join  endur_lng_personnel per_updated on party.authoriser_id         = per_updated.id_number 
# MAGIC  inner join endur_lng_party_class pc on party.party_class           = pc.id_number 
# MAGIC  inner join endur_lng_no_yes no_yes on party.Agency_Activities     = no_yes.id_number
# MAGIC  left outer join endur_lng_legal_entity le on party.party_id = le.party_id
# MAGIC  left outer join endur_lng_states states on le.state_id = states.state_id
# MAGIC  left outer join endur_lng_country country on le.country = country.id_number
# MAGIC  left outer join endur_lng_party_group_memb pgm on party.party_id = pgm.party_id
# MAGIC  left outer join endur_lng_party_group pg on pgm.group_id = pg.group_id
# MAGIC  left outer join endur_lng_party_info pi_sap_cust on party.party_id = pi_sap_cust.party_id and  pi_sap_cust.type_id  = 20176
# MAGIC  left outer join endur_lng_party_info pi_sap_ven on party.party_id          = pi_sap_ven.party_id and pi_sap_ven.type_id   = 20174 -- LNG Ext SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_int_sap_cust on party.party_id         = pi_int_sap_cust.party_id and pi_int_sap_cust.type_id  = 20177 -- LNG Int SAP Customer  
# MAGIC  left outer join endur_lng_party_info pi_int_sap_ven on party.party_id              = pi_int_sap_ven.party_id and pi_int_sap_ven.type_id   = 20175 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_comp_code on party.party_id              = pi_comp_code.party_id and pi_comp_code.type_id     = 20173 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_int_remit_rep on party.party_id      = pi_int_remit_rep.party_id and pi_int_remit_rep.type_id = 20183 -- Remit Reportable Internal 
# MAGIC  left outer join endur_lng_party_info pi_remit_rep on party.party_id     = pi_remit_rep.party_id and pi_remit_rep.type_id = 20184 -- Remit Reportable External 
# MAGIC  left outer join endur_lng_party_info pi_qgc_sap_cust on party.party_id              = pi_qgc_sap_cust.party_id and pi_qgc_sap_cust.type_id  = 20166 -- QGC SAP Customer 
# MAGIC  left outer join endur_lng_party_info pi_qgc_sap_vend on party.party_id              = pi_qgc_sap_vend.party_id and pi_qgc_sap_vend.type_id  = 20167 -- QGC SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_cust on party.party_id              = pi_sgm_sap_cust.party_id and pi_sgm_sap_cust.type_id  = 20149 -- SGM SAP Customer 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_vend on party.party_id              = pi_sgm_sap_vend.party_id and pi_sgm_sap_vend.type_id  = 20150 -- SGM SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_ic_cust on party.party_id      = pi_sgm_sap_ic_cust.party_id and pi_sgm_sap_ic_cust.type_id  = 20188 -- SGM SAP IC Customer 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_ic_vend on party.party_id       = pi_sgm_sap_ic_vend.party_id and pi_sgm_sap_ic_vend.type_id  = 20189 -- SGM SAP IC Vendor 
# MAGIC  left outer join endur_lng_party_rating pr on le.party_rating             = pr.id_number
# MAGIC  left outer join endur_lng_party_credit_rating pcr on party.party_id  = pcr.party_id
# MAGIC  left outer join endur_lng_credit_rating cr on pcr.rating_id = cr.rating_id
# MAGIC  WHERE  party.party_class != 1
# MAGIC  ),
# MAGIC  orderd AS 
# MAGIC    (SELECT ab.deal_tracking_num, 
# MAGIC      ab.maturity_date, 
# MAGIC      ata.party_agreement_id, 
# MAGIC      ab.internal_lentity lentity, 
# MAGIC      ab.internal_contact,
# MAGIC      ab.last_update,
# MAGIC      ab.trade_date,
# MAGIC      ab.personnel_id,
# MAGIC      row_number() over (partition BY ab.internal_lentity order by ab.maturity_date DESC,ab.deal_tracking_num DESC) AS rn 
# MAGIC      FROM endur_lng_ab_tran ab, 
# MAGIC      endur_lng_ab_tran_agreement ata 
# MAGIC      WHERE ab.tran_num           = ata.tran_num 
# MAGIC      AND ab.current_flag         = 1 
# MAGIC      AND ab.tran_status          =3 --and ab.internal_lentity    IN (21054) 
# MAGIC      AND ata.party_agreement_id <> 0 
# MAGIC      UNION 
# MAGIC    SELECT DISTINCT ab.deal_tracking_num, 
# MAGIC      ab.maturity_date, 
# MAGIC      ata.party_agreement_id, 
# MAGIC      ab.external_lentity lentity, 
# MAGIC      ab.internal_contact,
# MAGIC      ab.last_update,
# MAGIC      ab.trade_date,
# MAGIC      ab.personnel_id,
# MAGIC      row_number() over (partition BY ab.external_lentity order by ab.maturity_date DESC,ab.deal_tracking_num DESC) AS rn 
# MAGIC      FROM endur_lng_ab_tran ab, 
# MAGIC      endur_lng_ab_tran_agreement ata 
# MAGIC      WHERE ab.tran_num           = ata.tran_num 
# MAGIC      AND ab.current_flag         = 1 
# MAGIC      AND ab.tran_status          =3 --and ab.external_lentity    IN (21297) 
# MAGIC      AND ata.party_agreement_id <> 0 
# MAGIC    ), 
# MAGIC    
# MAGIC XYZ as
# MAGIC    ( 
# MAGIC      SELECT ord.deal_tracking_num, 
# MAGIC      ord.maturity_date, 
# MAGIC      ord.party_agreement_id, 
# MAGIC      ord.lentity, 
# MAGIC      prsnl.name as trader_id,
# MAGIC     CONCAT(prsnl.first_name,(' '||prsnl.last_name)) trader_name, 
# MAGIC      ord.trade_date as TRADE_DATE,
# MAGIC     ord.last_update as LAST_UPDATE_DEAL,
# MAGIC      ord.personnel_id as LAST_USER_UPDATE_DEAL,
# MAGIC      ord.rn, 
# MAGIC      row_number() over (partition BY ord.lentity order by ord.maturity_date DESC,ord.deal_tracking_num DESC) AS flag_t 
# MAGIC     FROM orderd ord
# MAGIC     left join endur_lng_personnel prsnl
# MAGIC     on prsnl.id_number = ord.internal_contact
# MAGIC     WHERE ord.rn    =1
# MAGIC     ),
# MAGIC     
# MAGIC     query_three as
# MAGIC     (
# MAGIC     SELECT DISTINCT 
# MAGIC     pr.legal_entity_id,  
# MAGIC     pr.business_unit_id  
# MAGIC     FROM endur_lng_party_relationship pr
# MAGIC     )
# MAGIC     
# MAGIC  SELECT DISTINCT
# MAGIC         query_one.party_id as Party_Id,
# MAGIC 		query_one.type as Type,
# MAGIC 		query_one.party_class as Class,
# MAGIC 		query_one.status as Status,
# MAGIC 		query_one.short_name as CP_LE_SHORT_NAME,
# MAGIC 		query_one.long_name as CP_LE_LONG_NAME,
# MAGIC 		query_one.created_by as Created_By,
# MAGIC 		query_one.created_by_name as Created_By_Name,
# MAGIC 		query_one.updated_by as LE_Updated_By,
# MAGIC 		query_one.le_updated_by_name as LE_Updated_By_Name,
# MAGIC 		to_date(query_one.last_update) as LE_Last_Updated,
# MAGIC 		query_one.version as Version,
# MAGIC 		query_one.agency_activities as Agency_Activities,
# MAGIC 		query_one.address_1 as Address_1,
# MAGIC 		query_one.address_2 as Address_2,
# MAGIC 		query_one.city as City,
# MAGIC 		query_one.state as State,
# MAGIC 		query_one.country as Country,
# MAGIC 		query_one.mail_code as Mail_Code,
# MAGIC 		query_one.phone as Phone,
# MAGIC 		query_one.fax as Fax,
# MAGIC 		query_one.description as Description,
# MAGIC 		query_one.internal_reference_1 as Internal_Reference_1,
# MAGIC 		query_one.internal_reference_2 as Internal_Reference_2,
# MAGIC 		query_one.internal_reference_3 as Internal_Reference_3,
# MAGIC 		query_one.party_group as Party_Group,
# MAGIC 		query_one.lng_sap_customer as LNG_Ext_SAP_Customer,
# MAGIC 		query_one.lng_sap_vendor as LNG_Ext_SAP_Vendor,
# MAGIC 		query_one.lng_int_sap_customer as LNG_Int_SAP_Customer,
# MAGIC 		query_one.lng_int_sap_vendor as LNG_Int_SAP_Vendor,
# MAGIC 		query_one.lng_company_code as LNG_Company_Code,
# MAGIC 		query_one.remit_reprotable as Remit_Reportable,
# MAGIC 		query_one.qgc_sap_cust as QGC_SAP_Customer,
# MAGIC 		query_one.qgc_sap_vend as QGC_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_cust as SGM_SAP_Customer,
# MAGIC 		query_one.sgm_sap_vend as SGM_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_ic_cust as SGM_SAP_IC_Customer,
# MAGIC 		query_one.sgm_sap_ic_vend as SGM_SAP_IC_Vendor,
# MAGIC 		query_one.party_rating as Credit_Internal_Rating,
# MAGIC 		query_one.rating_name as SHELL_CREDIT_RATING,
# MAGIC         abc.party_agreement_id as Agreement_ID,
# MAGIC         abc.deal_tracking_num as Maximum_Deal_Number,
# MAGIC         to_date(abc.maturity_date) as max_end_date,
# MAGIC         abc.trader_id,
# MAGIC         abc.trader_name as Trader_Id_Name,
# MAGIC         to_date(abc.TRADE_DATE) as TRADE_DATE,
# MAGIC         to_date(abc.LAST_UPDATE_DEAL) as LAST_UPDATE_DEAL,
# MAGIC         prsnl.name as LAST_USER_UPDATE_DEAL,
# MAGIC         CONCAT(prsnl.first_name,(' '||prsnl.last_name)) last_user_update_deal_name,
# MAGIC         query_three.business_unit_id as linked_party_id,
# MAGIC         'ENDUR_LNG' as source_system
# MAGIC     from query_one
# MAGIC     left outer join query_three on query_one.party_id = query_three.legal_entity_id
# MAGIC     left outer join XYZ abc on query_one.party_id = abc.lentity
# MAGIC     left outer join endur_lng_personnel prsnl on prsnl.id_number = abc.LAST_USER_UPDATE_DEAL and abc.flag_t=1    
# MAGIC     order by CP_LE_SHORT_NAME
# MAGIC )
# MAGIC   ;   

# COMMAND ----------

# MAGIC %sql
# MAGIC -- removed _ENDUR_LNG in the name 
# MAGIC create or replace temporary view vw_cp_slmt_mrd_legal_entity_master_tmp2 as
# MAGIC SELECT *
# MAGIC FROM
# MAGIC (
# MAGIC     SELECT t.*, ROW_NUMBER() OVER (PARTITION BY party_id, linked_party_id ORDER BY version DESC) rn
# MAGIC     FROM vw_cp_slmt_mrd_legal_entity_master_tmp1 t
# MAGIC ) t
# MAGIC WHERE rn = 1;

# COMMAND ----------

spark.sql("SET spark.sql.parser.quotedRegexColumnNames=true")

# COMMAND ----------

sql("create or replace temporary view vw_cp_slmt_mrd_legal_entity_master as select `(rn)?+.+` from vw_cp_slmt_mrd_legal_entity_master_tmp2").show()

# COMMAND ----------



# COMMAND ----------

# df = spark.sql("select * from vw_cp_slmt_mrd_legal_entity_master_ENDUR_LNG")
df = spark.sql("select * from vw_cp_slmt_mrd_legal_entity_master")

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_slmt_mrd_legal_entity_master')

# COMMAND ----------

# MAGIC %sql
# MAGIC --_ENDUR_LNG rmoved in the names
# MAGIC  create or replace temporary view vw_cp_slmt_bu_le_cons as
# MAGIC select distinct
# MAGIC BU.PARTY_ID as BU_PARTY_ID,
# MAGIC BU.TYPE as BU_TYPE,
# MAGIC BU.STATUS as BU_STATUS,
# MAGIC BU.CP_BU_SHORT_NAME as BU_SHORT_NAME,
# MAGIC BU.CP_BU_LONG_NAME as BU_LONG_NAME,
# MAGIC BU.CREATED_BY as BU_CREATED_BY,
# MAGIC BU.LE_UPDATED_BY as BU_UPDATED_BY,
# MAGIC BU.LE_LAST_UPDATED as BU_LAST_UPDATED,
# MAGIC BU.VERSION as BU_VERSION,
# MAGIC BU.LINKED_PARTY_ID as BU_LINKED_PARTY_ID,
# MAGIC BU.PARTY_GROUP as BU_PARTY_GROUP,
# MAGIC --BU.LNG_SAP_CUSTOMER as BU_LNG_SAP_CUSTOMER,
# MAGIC --BU.LNG_SAP_VENDOR as BU_LNG_SAP_VENDOR,
# MAGIC --BU.LNG_INT_SAP_CUSTOMER as BU_LNG_INT_SAP_CUSTOMER,
# MAGIC --BU.LNG_INT_SAP_VENDOR as BU_LNG_INT_SAP_VENDOR,
# MAGIC --BU.LNG_COMPANY_CODE as BU_LNG_COMPANY_CODE,
# MAGIC --BU.REMIT_REPORTABLE as BU_REMIT_REPORTABLE,
# MAGIC --BU.QGC_SAP_CUSTOMER as BU_QGC_SAP_CUSTOMER,
# MAGIC --BU.QGC_SAP_VENDOR as BU_QGC_SAP_VENDOR,
# MAGIC --BU.SGM_SAP_CUSTOMER as BU_SGM_SAP_CUSTOMER,
# MAGIC --BU.SGM_SAP_VENDOR as BU_SGM_SAP_VENDOR,
# MAGIC --BU.SGM_SAP_IC_CUSTOMER as BU_SGM_SAP_IC_CUSTOMER,
# MAGIC --BU.SGM_SAP_IC_VENDOR as BU_SGM_SAP_IC_VENDOR,
# MAGIC --BU.CREDIT_INTERNAL_RATING as BU_CREDIT_INTERNAL_RATING,
# MAGIC --BU.SHELL_CREDIT_RATING as BU_SHELL_CREDIT_RATING,
# MAGIC BU.BU_FUNCTIONS as BU_FUNCTIONS,
# MAGIC LE.PARTY_ID as LE_PARTY_ID,
# MAGIC LE.TYPE as LE_TYPE,
# MAGIC LE.CLASS as LE_CLASS,
# MAGIC LE.STATUS as LE_STATUS,
# MAGIC LE.CP_LE_SHORT_NAME as LE_SHORT_NAME,
# MAGIC LE.CP_LE_LONG_NAME as LE_LONG_NAME,
# MAGIC LE.CREATED_BY as LE_CREATED_BY,
# MAGIC LE.CREATED_BY_NAME as LE_CREATED_BY_NAME,
# MAGIC LE.LE_UPDATED_BY as LE_UPDATED_BY,
# MAGIC LE.LE_UPDATED_BY_NAME as LE_UPDATED_BY_NAME,
# MAGIC LE.LE_LAST_UPDATED as LE_LAST_UPDATED,
# MAGIC LE.VERSION as LE_VERSION,
# MAGIC LE.AGENCY_ACTIVITIES as LE_AGENCY_ACTIVITIES,
# MAGIC LE.ADDRESS_1 as LE_ADDRESS_1,
# MAGIC LE.ADDRESS_2 as LE_ADDRESS_2,
# MAGIC LE.CITY as LE_CITY,
# MAGIC LE.STATE as LE_STATE,
# MAGIC LE.COUNTRY as LE_COUNTRY,
# MAGIC LE.MAIL_CODE as LE_MAIL_CODE,
# MAGIC LE.PHONE as LE_PHONE,
# MAGIC LE.FAX as LE_FAX,
# MAGIC LE.DESCRIPTION as LE_DESCRIPTION,
# MAGIC LE.INTERNAL_REFERENCE_1 as LE_INTERNAL_REFERENCE_1,
# MAGIC LE.INTERNAL_REFERENCE_2 as LE_INTERNAL_REFERENCE_2,
# MAGIC LE.INTERNAL_REFERENCE_3 as LE_INTERNAL_REFERENCE_3,
# MAGIC LE.PARTY_GROUP as LE_PARTY_GROUP,
# MAGIC LE.LNG_EXT_SAP_CUSTOMER as LE_LNG_EXT_SAP_CUSTOMER,
# MAGIC LE.LNG_EXT_SAP_VENDOR as LE_LNG_EXT_SAP_VENDOR,
# MAGIC LE.LNG_INT_SAP_CUSTOMER as LE_LNG_INT_SAP_CUSTOMER,
# MAGIC LE.LNG_INT_SAP_VENDOR as LE_LNG_INT_SAP_VENDOR,
# MAGIC LE.LNG_COMPANY_CODE as LE_LNG_COMPANY_CODE,
# MAGIC LE.REMIT_REPORTABLE as LE_REMIT_REPORTABLE,
# MAGIC LE.QGC_SAP_CUSTOMER as LE_QGC_SAP_CUSTOMER,
# MAGIC LE.QGC_SAP_VENDOR as LE_QGC_SAP_VENDOR,
# MAGIC LE.SGM_SAP_CUSTOMER as LE_SGM_SAP_CUSTOMER,
# MAGIC LE.SGM_SAP_VENDOR as LE_SGM_SAP_VENDOR,
# MAGIC LE.SGM_SAP_IC_CUSTOMER as LE_SGM_SAP_IC_CUSTOMER,
# MAGIC LE.SGM_SAP_IC_VENDOR as LE_SGM_SAP_IC_VENDOR,
# MAGIC LE.CREDIT_INTERNAL_RATING as LE_CREDIT_INTERNAL_RATING,
# MAGIC LE.SHELL_CREDIT_RATING as LE_SHELL_CREDIT_RATING,
# MAGIC LE.AGREEMENT_ID as LE_AGREEMENT_ID,
# MAGIC LE.MAXIMUM_DEAL_NUMBER as LE_MAXIMUM_DEAL_NUMBER,
# MAGIC LE.MAX_END_DATE as LE_MAX_END_DATE,
# MAGIC LE.TRADER_ID as LE_TRADER_ID,
# MAGIC LE.TRADER_ID_NAME as LE_TRADER_ID_NAME,
# MAGIC LE.TRADE_DATE as LE_TRADE_DATE,
# MAGIC LE.LAST_UPDATE_DEAL as LE_LAST_UPDATE_DEAL,
# MAGIC LE.LAST_USER_UPDATE_DEAL as LE_LAST_USER_UPDATE_DEAL,
# MAGIC LE.LAST_USER_UPDATE_DEAL_NAME as LE_LAST_USER_UPDATE_DEAL_NAME,
# MAGIC LE.LINKED_PARTY_ID as LE_LINKED_PARTY_ID,
# MAGIC 'ENDUR_LNG' as source_system,
# MAGIC BU.meta_created_dttm
# MAGIC from vw_cp_slmt_mrd_business_unit_master BU, vw_cp_slmt_mrd_legal_entity_master LE
# MAGIC where LE.LINKED_PARTY_ID = BU.PARTY_ID;

# COMMAND ----------

df = spark.sql("select * from vw_cp_slmt_bu_le_cons")

# COMMAND ----------

# df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC --select * from vw_cp_slmt_bu_le_cons --_ENDUR_LNG removed

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_slmt_bu_le_cons')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_slmt_sap_accounts as
# MAGIC select distinct PARTY_ID, name, value, COL_NAME, 'ENDUR_LNG' as source_system from (
# MAGIC select
# MAGIC       PARTY_ID,
# MAGIC       case  
# MAGIC       when 1 = 1 then "LNG Ext SAP Customer"
# MAGIC       end
# MAGIC       as Name,
# MAGIC       case  
# MAGIC       when 1 = 1 then LNG_EXT_SAP_CUSTOMER
# MAGIC       end
# MAGIC       as Value,
# MAGIC       case  
# MAGIC       when 1 = 1 then "Customer"
# MAGIC       end
# MAGIC       as COL_NAME
# MAGIC from vw_cp_slmt_mrd_legal_entity_master
# MAGIC union
# MAGIC select  
# MAGIC       PARTY_ID,
# MAGIC       case  
# MAGIC       when 1 = 1 then "LNG Ext SAP Vendor"
# MAGIC       end
# MAGIC       as Name,
# MAGIC       case  
# MAGIC       when 1 = 1 then LNG_EXT_SAP_VENDOR
# MAGIC       end
# MAGIC       as Value,
# MAGIC       case  
# MAGIC       when 1 = 1 then "Vendor"
# MAGIC       end
# MAGIC       as COL_NAME
# MAGIC from vw_cp_slmt_mrd_legal_entity_master
# MAGIC union
# MAGIC select  
# MAGIC       PARTY_ID,
# MAGIC       case  
# MAGIC       when 1 = 1 then "LNG Int SAP Customer"
# MAGIC       end
# MAGIC       as Name,
# MAGIC       case  
# MAGIC       when 1 = 1 then LNG_INT_SAP_CUSTOMER
# MAGIC       end
# MAGIC       as Value,
# MAGIC       case  
# MAGIC       when 1 = 1 then "Customer"
# MAGIC       end
# MAGIC       as COL_NAME
# MAGIC from vw_cp_slmt_mrd_legal_entity_master
# MAGIC union
# MAGIC select  
# MAGIC     PARTY_ID,
# MAGIC     case  
# MAGIC     when 1 = 1 then "LNG Int SAP Vendor"
# MAGIC     end
# MAGIC     as Name,
# MAGIC     case  
# MAGIC     when 1 = 1 then LNG_INT_SAP_VENDOR
# MAGIC     end
# MAGIC     as Value,
# MAGIC     case  
# MAGIC     when 1 = 1 then "Vendor"
# MAGIC     end
# MAGIC     as COL_NAME
# MAGIC from vw_cp_slmt_mrd_legal_entity_master
# MAGIC ) t order by PARTY_ID

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_slmt_sap_accounts_sap as
# MAGIC select distinct PARTY_ID, name, value, COL_NAME, 'ENDUR_LNG' as source_system from (
# MAGIC select
# MAGIC       PARTY_ID, "LNG SAP Customer" as name, nvl(sl_mast_sap.lng_ext_sap_customer,sl_mast_sap.lng_int_sap_customer) as value,
# MAGIC case when sl_mast_sap.lng_ext_sap_customer is not null or trim(sl_mast_sap.lng_ext_sap_customer) <> '' or sl_mast_sap.lng_int_sap_customer is not null or trim(sl_mast_sap.lng_int_sap_customer) <> '' then "Customer" end col_name 
# MAGIC from vw_cp_slmt_mrd_legal_entity_master sl_mast_sap
# MAGIC union
# MAGIC select
# MAGIC       PARTY_ID, "LNG SAP Vendor" as name, nvl(sl_mast_sap.lng_ext_sap_vendor,sl_mast_sap.lng_int_sap_vendor) as value,
# MAGIC case when sl_mast_sap.lng_ext_sap_vendor is not null or trim(sl_mast_sap.lng_ext_sap_vendor) <> '' or sl_mast_sap.lng_int_sap_vendor is not null or trim(sl_mast_sap.lng_int_sap_vendor) <> '' then "Vendor" end col_name 
# MAGIC from vw_cp_slmt_mrd_legal_entity_master sl_mast_sap
# MAGIC ) t order by PARTY_ID

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_cp_slmt_sap_accounts_sap
# MAGIC where party_id = 26166

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_slmt_mrd_legal_entity_master_sap as
# MAGIC select sl_mast_sap.*, 
# MAGIC case when sl_mast_sap.lng_ext_sap_customer is not null or trim(sl_mast_sap.lng_ext_sap_customer) <> '' or sl_mast_sap.lng_int_sap_customer is not null or trim(sl_mast_sap.lng_int_sap_customer) <> '' then "Customer" 
# MAGIC      when sl_mast_sap.lng_ext_sap_vendor is not null or trim(sl_mast_sap.lng_ext_sap_vendor) <> '' or sl_mast_sap.lng_int_sap_vendor is not null or trim(sl_mast_sap.lng_int_sap_vendor) <> '' then "Vendor" end sap_cpty_type 
# MAGIC from vw_cp_slmt_mrd_legal_entity_master sl_mast_sap

# COMMAND ----------

# MAGIC %sql
# MAGIC --select * from vw_cp_slmt_mrd_legal_entity_master_sap where party_id = 20633
# MAGIC 
# MAGIC select * from vw_cp_slmt_mrd_legal_entity_master_sap where party_id = 26166--20633

# COMMAND ----------

# MAGIC %sql
# MAGIC -- select * from vw_cp_slmt_sap_accounts where party_id = 26166

# COMMAND ----------

# df = spark.sql("select * from vw_cp_slmt_sap_accounts_ENDUR_LNG")
df = spark.sql("select * from vw_cp_slmt_sap_accounts")

# COMMAND ----------

# df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_slmt_sap_accounts')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_cp_slmt_sap_accounts
# MAGIC where party_id = 26166

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_bu_functios_split as
# MAGIC select distinct BU_FUNCTIONS from vw_cp_slmt_bu_le_cons

# COMMAND ----------

# MAGIC %sql 
# MAGIC create or replace temporary view vw_cp_slmt_entity as
# MAGIC select 
# MAGIC   BU_FUNCTIONS as Input_6_BU_BU_Functions,
# MAGIC   case when locate('Trading', BU_FUNCTIONS)      >  0 then "Trading" else '' end ||
# MAGIC   case when locate('Scheduling', BU_FUNCTIONS)   >  0 then "/Scheduling" else '' end ||
# MAGIC   case when locate('Broking', BU_FUNCTIONS)      >  0 then "/Broking" else '' end ||
# MAGIC   case when locate('Agency', BU_FUNCTIONS)       >  0 then "/Agency" else '' end ||
# MAGIC   case when locate('Holding Bank', BU_FUNCTIONS) >  0 then "/Holding Bank" else '' end as Entity,
# MAGIC   'ENDUR_LNG' as source_system
# MAGIC from vw_cp_bu_functios_split

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct Entity, ltrim(Entity,'/'), TRIM(LEADING '/' FROM Entity) from vw_cp_slmt_entity

# COMMAND ----------

# MAGIC %sql 
# MAGIC --create or replace temporary view vw_cp_slmt_entity as
# MAGIC --select 
# MAGIC --  BU_FUNCTIONS as Input_6_BU_BU_Functions,
# MAGIC --  case when locate('Trading', BU_FUNCTIONS)      >  0 then "Trading" else '' end ||
# MAGIC --  case when locate('Trading', BU_FUNCTIONS)      >  0 and locate('Scheduling', BU_FUNCTIONS)   >  0 then "/Scheduling" else case when locate('Scheduling', BU_FUNCTIONS)   >  0 then "Scheduling" else '' end end ||
# MAGIC --  case when locate('Scheduling', BU_FUNCTIONS)   >  0  and locate('Broking', BU_FUNCTIONS)      >  0 then "/Broking" else case when locate('Broking', BU_FUNCTIONS)      >  0 then "Broking" else '' end end ||
# MAGIC --  case when locate('Broking', BU_FUNCTIONS)      >  0 and locate('Agency', BU_FUNCTIONS)       >  0 then "/Agency" else case when locate('Agency', BU_FUNCTIONS)       >  0 then "Agency" else '' end end ||
# MAGIC --  case when locate('Agency', BU_FUNCTIONS)       >  0 and locate('Holding Bank', BU_FUNCTIONS) >  0 then "/Holding Bank" else case when locate('Holding Bank', BU_FUNCTIONS) >  0 then "Holding Bank" else '' end end as Entity,
# MAGIC --  'ENDUR_LNG' as source_system
# MAGIC --from vw_cp_bu_functios_split

# COMMAND ----------

df = spark.sql("select * from vw_cp_slmt_entity")

# COMMAND ----------

df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_slmt_entity')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_le_bu_cons_sap_acc as
# MAGIC select
# MAGIC CO.LE_ADDRESS_1,
# MAGIC CO.LE_ADDRESS_2,
# MAGIC CO.LE_AGENCY_ACTIVITIES,
# MAGIC CO.LE_AGREEMENT_ID,
# MAGIC CO.LE_CITY,
# MAGIC CO.LE_CLASS,
# MAGIC CO.LE_COUNTRY,
# MAGIC CO.LE_CREATED_BY,
# MAGIC CO.LE_CREATED_BY_NAME as CREATED_BY_NAME,
# MAGIC CO.LE_CREDIT_INTERNAL_RATING,
# MAGIC CO.LE_DESCRIPTION,
# MAGIC CO.LE_FAX,
# MAGIC CO.LE_INTERNAL_REFERENCE_1,
# MAGIC CO.LE_INTERNAL_REFERENCE_2,
# MAGIC CO.LE_INTERNAL_REFERENCE_3,
# MAGIC CO.LE_LAST_UPDATED,
# MAGIC CO.LE_UPDATED_BY,
# MAGIC CO.LE_UPDATED_BY_NAME,
# MAGIC CO.LE_LINKED_PARTY_ID,
# MAGIC CO.LE_LNG_COMPANY_CODE,
# MAGIC CO.LE_LNG_EXT_SAP_CUSTOMER,
# MAGIC CO.LE_LNG_EXT_SAP_VENDOR,
# MAGIC CO.LE_LNG_INT_SAP_CUSTOMER,
# MAGIC CO.LE_LNG_INT_SAP_VENDOR,
# MAGIC CO.LE_LONG_NAME,
# MAGIC CO.LE_MAIL_CODE,
# MAGIC CO.LE_MAX_END_DATE,
# MAGIC CO.LE_MAXIMUM_DEAL_NUMBER,
# MAGIC CO.LE_PARTY_GROUP,
# MAGIC CO.LE_PARTY_ID,
# MAGIC CO.LE_PHONE,
# MAGIC CO.LE_QGC_SAP_CUSTOMER,
# MAGIC CO.LE_QGC_SAP_VENDOR,
# MAGIC CO.LE_REMIT_REPORTABLE,
# MAGIC CO.LE_SGM_SAP_CUSTOMER,
# MAGIC CO.LE_SGM_SAP_IC_CUSTOMER,
# MAGIC CO.LE_SGM_SAP_IC_VENDOR,
# MAGIC CO.LE_SGM_SAP_VENDOR,
# MAGIC CO.LE_SHELL_CREDIT_RATING as SHELL_CREDIT_RATING,
# MAGIC CO.LE_SHORT_NAME,
# MAGIC CO.LE_STATE,
# MAGIC CO.LE_STATUS,
# MAGIC CO.LE_TRADE_DATE as TRADE_DATE,
# MAGIC CO.LE_TRADER_ID as TRADER_ID,
# MAGIC CO.LE_TRADER_ID_NAME as TRADER_ID_NAME,
# MAGIC CO.LE_TYPE,
# MAGIC CO.LE_VERSION,
# MAGIC CO.LE_LAST_UPDATE_DEAL as LAST_UPDATE_DEAL,
# MAGIC CO.LE_LAST_USER_UPDATE_DEAL as LAST_USER_UPDATE_DEAL,
# MAGIC CO.LE_LAST_USER_UPDATE_DEAL_NAME as LAST_USER_UPDATE_DEAL_NAME,
# MAGIC CO.BU_FUNCTIONS as BU_BU_FUNCTIONS,
# MAGIC CO.BU_CREATED_BY,
# MAGIC CO.BU_LAST_UPDATED as RIGHT_LE_LAST_UPDATED,
# MAGIC CO.BU_UPDATED_BY as RIGHT_LE_UPDATED_BY,
# MAGIC CO.BU_LINKED_PARTY_ID,
# MAGIC CO.BU_LONG_NAME,
# MAGIC CO.BU_PARTY_GROUP,
# MAGIC CO.BU_PARTY_ID,
# MAGIC CO.BU_SHORT_NAME,
# MAGIC CO.BU_STATUS,
# MAGIC CO.BU_TYPE,
# MAGIC CO.BU_VERSION,
# MAGIC SA.PARTY_ID as RIGHT_PARTY_ID,
# MAGIC SA.NAME,
# MAGIC SA.VALUE,
# MAGIC SA.COL_NAME,
# MAGIC 'ENDUR_LNG' as source_system,
# MAGIC CO.meta_created_dttm
# MAGIC from vw_cp_slmt_bu_le_cons CO 
# MAGIC --LEFT OUTER JOIN  vw_cp_slmt_sap_accounts SA ON
# MAGIC LEFT OUTER JOIN  vw_cp_slmt_sap_accounts_sap SA ON
# MAGIC CO.LE_PARTY_ID =  SA.PARTY_ID

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_cp_le_bu_cons_sap_acc where LE_PARTY_ID = 26166

# COMMAND ----------

df = spark.sql("select * from vw_cp_le_bu_cons_sap_acc")

# COMMAND ----------

# df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_le_bu_cons_sap_acc')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_le_bu_cons_sap_credit_rating as
# MAGIC select
# MAGIC SA.LE_PARTY_ID,
# MAGIC SA.LE_TYPE,
# MAGIC SA.LE_CLASS,
# MAGIC SA.LE_STATUS,
# MAGIC SA.LE_SHORT_NAME,
# MAGIC SA.LE_LONG_NAME,
# MAGIC SA.LE_CREATED_BY,
# MAGIC SA.CREATED_BY_NAME,
# MAGIC SA.LE_UPDATED_BY,
# MAGIC SA.LE_UPDATED_BY_NAME,
# MAGIC SA.LE_LAST_UPDATED,
# MAGIC SA.LE_VERSION,
# MAGIC SA.LE_AGENCY_ACTIVITIES,
# MAGIC SA.LE_LINKED_PARTY_ID,
# MAGIC SA.LE_ADDRESS_1,
# MAGIC SA.LE_ADDRESS_2,
# MAGIC SA.LE_CITY,
# MAGIC SA.LE_STATE,
# MAGIC SA.LE_COUNTRY,
# MAGIC SA.LE_MAIL_CODE,
# MAGIC SA.LE_PHONE,
# MAGIC SA.LE_FAX,
# MAGIC SA.LE_DESCRIPTION,
# MAGIC SA.LE_INTERNAL_REFERENCE_1,
# MAGIC SA.LE_INTERNAL_REFERENCE_2,
# MAGIC SA.LE_INTERNAL_REFERENCE_3,
# MAGIC SA.LE_PARTY_GROUP,
# MAGIC SA.LE_LNG_EXT_SAP_CUSTOMER,
# MAGIC SA.LE_LNG_EXT_SAP_VENDOR,
# MAGIC SA.LE_LNG_INT_SAP_CUSTOMER,
# MAGIC SA.LE_LNG_INT_SAP_VENDOR,
# MAGIC SA.LE_LNG_COMPANY_CODE,
# MAGIC SA.LE_REMIT_REPORTABLE,
# MAGIC SA.LE_QGC_SAP_CUSTOMER,
# MAGIC SA.LE_QGC_SAP_VENDOR,
# MAGIC SA.LE_SGM_SAP_CUSTOMER,
# MAGIC SA.LE_SGM_SAP_VENDOR,
# MAGIC SA.LE_SGM_SAP_IC_CUSTOMER,
# MAGIC SA.LE_SGM_SAP_IC_VENDOR,
# MAGIC SA.LE_CREDIT_INTERNAL_RATING,
# MAGIC SA.SHELL_CREDIT_RATING,
# MAGIC SA.LE_AGREEMENT_ID,
# MAGIC SA.LE_MAXIMUM_DEAL_NUMBER,
# MAGIC SA.LE_MAX_END_DATE,
# MAGIC SA.TRADER_ID,
# MAGIC SA.TRADER_ID_NAME,
# MAGIC SA.TRADE_DATE,
# MAGIC SA.LAST_UPDATE_DEAL,
# MAGIC SA.LAST_USER_UPDATE_DEAL,
# MAGIC SA.LAST_USER_UPDATE_DEAL_NAME,
# MAGIC SA.BU_PARTY_ID,
# MAGIC SA.BU_TYPE,
# MAGIC SA.BU_STATUS,
# MAGIC SA.BU_SHORT_NAME,
# MAGIC SA.BU_LONG_NAME,
# MAGIC SA.BU_CREATED_BY,
# MAGIC SA.RIGHT_LE_UPDATED_BY as LEFT_RIGHT_LE_UPDATED_BY,
# MAGIC SA.RIGHT_LE_LAST_UPDATED as LEFT_RIGHT_LE_LAST_UPDATED,
# MAGIC SA.BU_VERSION,
# MAGIC SA.BU_LINKED_PARTY_ID,
# MAGIC SA.BU_PARTY_GROUP,
# MAGIC SA.BU_BU_FUNCTIONS,
# MAGIC SA.RIGHT_PARTY_ID,
# MAGIC SA.NAME,
# MAGIC SA.VALUE,
# MAGIC SA.COL_NAME,
# MAGIC LE.PARTY_ID,
# MAGIC LE.CP_LE_SHORT_NAME as SHORT_NAME,
# MAGIC LE.CP_LE_LONG_NAME as LONG_NAME,
# MAGIC LE.CREATED_BY_NAME as RIGHT_CREATED_BY_NAME,
# MAGIC LE.LE_UPDATED_BY as RIGHT_LE_UPDATED_BY,
# MAGIC LE.LE_UPDATED_BY_NAME as RIGHT_LE_UPDATED_BY_NAME,
# MAGIC LE.LE_LAST_UPDATED as RIGHT_LE_LAST_UPDATED,
# MAGIC LE.TRADER_ID as RIGHT_TRADER_ID,
# MAGIC LE.TRADER_ID_NAME as RIGHT_TRADER_ID_NAME,
# MAGIC LE.TRADE_DATE as RIGHT_TRADE_DATE,
# MAGIC LE.LAST_UPDATE_DEAL as RIGHT_LAST_UPDATE_DEAL,
# MAGIC LE.LAST_USER_UPDATE_DEAL as RIGHT_LAST_USER_UPDATE_DEAL,
# MAGIC LE.LAST_USER_UPDATE_DEAL_NAME AS RIGHT_LAST_USER_UPDATE_DEAL_NAME,
# MAGIC 'ENDUR_LNG' as source_system,
# MAGIC SA.meta_created_dttm
# MAGIC from
# MAGIC vw_cp_le_bu_cons_sap_acc SA Left Outer Join vw_cp_slmt_mrd_legal_entity_master LE
# MAGIC ON SA.LE_PARTY_ID = LE.PARTY_ID

# COMMAND ----------

# df = spark.sql("select * from vw_cp_le_bu_cons_sap_credit_rating_ENDUR_LNG")
df = spark.sql("select * from vw_cp_le_bu_cons_sap_credit_rating")

# COMMAND ----------

# df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_le_bu_cons_sap_credit_rating')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_slmt_master_entity as
# MAGIC select
# MAGIC SA.LE_PARTY_ID,
# MAGIC SA.LE_TYPE,
# MAGIC SA.LE_CLASS,
# MAGIC SA.LE_STATUS,
# MAGIC SA.LE_SHORT_NAME,
# MAGIC SA.LE_LONG_NAME,
# MAGIC SA.LE_CREATED_BY,
# MAGIC SA.CREATED_BY_NAME,
# MAGIC SA.LE_UPDATED_BY,
# MAGIC SA.LE_UPDATED_BY_NAME,
# MAGIC SA.LE_LAST_UPDATED,
# MAGIC SA.LE_VERSION,
# MAGIC SA.LE_AGENCY_ACTIVITIES,
# MAGIC SA.LE_LINKED_PARTY_ID,
# MAGIC SA.LE_ADDRESS_1,
# MAGIC SA.LE_ADDRESS_2,
# MAGIC SA.LE_CITY,
# MAGIC SA.LE_STATE,
# MAGIC SA.LE_COUNTRY,
# MAGIC SA.LE_MAIL_CODE,
# MAGIC SA.LE_PHONE,
# MAGIC SA.LE_FAX,
# MAGIC SA.LE_DESCRIPTION,
# MAGIC SA.LE_INTERNAL_REFERENCE_1,
# MAGIC SA.LE_INTERNAL_REFERENCE_2,
# MAGIC SA.LE_INTERNAL_REFERENCE_3,
# MAGIC SA.LE_PARTY_GROUP,
# MAGIC SA.LE_LNG_EXT_SAP_CUSTOMER,
# MAGIC SA.LE_LNG_EXT_SAP_VENDOR,
# MAGIC SA.LE_LNG_INT_SAP_CUSTOMER,
# MAGIC SA.LE_LNG_INT_SAP_VENDOR,
# MAGIC SA.LE_LNG_COMPANY_CODE,
# MAGIC SA.LE_REMIT_REPORTABLE,
# MAGIC SA.LE_QGC_SAP_CUSTOMER,
# MAGIC SA.LE_QGC_SAP_VENDOR,
# MAGIC SA.LE_SGM_SAP_CUSTOMER,
# MAGIC SA.LE_SGM_SAP_VENDOR,
# MAGIC SA.LE_SGM_SAP_IC_CUSTOMER,
# MAGIC SA.LE_SGM_SAP_IC_VENDOR,
# MAGIC SA.LE_CREDIT_INTERNAL_RATING,
# MAGIC SA.SHELL_CREDIT_RATING,
# MAGIC SA.LE_AGREEMENT_ID,
# MAGIC SA.LE_MAXIMUM_DEAL_NUMBER,
# MAGIC SA.LE_MAX_END_DATE,
# MAGIC SA.TRADER_ID,
# MAGIC SA.TRADER_ID_NAME,
# MAGIC SA.TRADE_DATE,
# MAGIC SA.LAST_UPDATE_DEAL,
# MAGIC SA.LAST_USER_UPDATE_DEAL,
# MAGIC SA.LAST_USER_UPDATE_DEAL_NAME,
# MAGIC SA.BU_PARTY_ID,
# MAGIC SA.BU_TYPE,
# MAGIC SA.BU_STATUS,
# MAGIC SA.BU_SHORT_NAME,
# MAGIC SA.BU_LONG_NAME,
# MAGIC SA.BU_CREATED_BY,
# MAGIC SA.LEFT_RIGHT_LE_UPDATED_BY,
# MAGIC SA.LEFT_RIGHT_LE_LAST_UPDATED,
# MAGIC SA.BU_VERSION,
# MAGIC SA.BU_LINKED_PARTY_ID,
# MAGIC SA.BU_PARTY_GROUP,
# MAGIC SA.BU_BU_FUNCTIONS,
# MAGIC SA.RIGHT_PARTY_ID,
# MAGIC SA.NAME,
# MAGIC SA.VALUE,
# MAGIC SA.COL_NAME,
# MAGIC SA.PARTY_ID,
# MAGIC SA.SHORT_NAME,
# MAGIC SA.LONG_NAME,
# MAGIC SA.RIGHT_CREATED_BY_NAME,
# MAGIC SA.RIGHT_LE_UPDATED_BY,
# MAGIC SA.RIGHT_LE_UPDATED_BY_NAME,
# MAGIC SA.RIGHT_LE_LAST_UPDATED,
# MAGIC SA.RIGHT_TRADER_ID,
# MAGIC SA.RIGHT_TRADER_ID_NAME,
# MAGIC SA.RIGHT_TRADE_DATE,
# MAGIC SA.RIGHT_LAST_UPDATE_DEAL,
# MAGIC SA.RIGHT_LAST_USER_UPDATE_DEAL,
# MAGIC SA.RIGHT_LAST_USER_UPDATE_DEAL_NAME,
# MAGIC --SE.Entity,
# MAGIC TRIM(LEADING '/' FROM SE.Entity) as Entity,
# MAGIC 'ENDUR_LNG' as source_system,
# MAGIC SA.meta_created_dttm
# MAGIC from    vw_cp_le_bu_cons_sap_credit_rating SA 
# MAGIC Left Outer Join vw_cp_slmt_entity          SE ON SA.BU_BU_FUNCTIONS = SE.Input_6_BU_BU_Functions

# COMMAND ----------

df = spark.sql("select * from vw_cp_slmt_master_entity")

# COMMAND ----------

# df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_slmt_master_entity')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_slmt_master as
# MAGIC select distinct
# MAGIC SA.LE_PARTY_ID as ACCOUNT_NO,
# MAGIC "SLMT_" || SA.LE_PARTY_ID as ACTIVITY_ID,
# MAGIC SA.LE_ADDRESS_1 || SA.LE_ADDRESS_2 as ADDRESS,
# MAGIC SA.BU_BU_FUNCTIONS,
# MAGIC SA.BU_CREATED_BY,
# MAGIC SA.BU_LINKED_PARTY_ID,
# MAGIC SA.BU_LONG_NAME,
# MAGIC SA.BU_PARTY_GROUP,
# MAGIC SA.BU_PARTY_ID,
# MAGIC SA.BU_SHORT_NAME,
# MAGIC SA.BU_STATUS,
# MAGIC SA.BU_TYPE,
# MAGIC SA.BU_VERSION,
# MAGIC SA.COL_NAME,
# MAGIC SA.CREATED_BY_NAME,
# MAGIC --CREDIT_RATING --Check with Neeraj about whic is rating_name column for this logic
# MAGIC case when SA.LE_STATUS = 'Suspended' or SA.BU_STATUS = 'Suspended' then 'Y'
# MAGIC      else 'N'
# MAGIC end as DELETED,
# MAGIC SA.Entity,
# MAGIC case when SA.Entity is null or length(trim(SA.Entity)) = 0  then SA.LE_TYPE else SA.LE_TYPE || "_" || SA.Entity end as ENTITY_TYPE,
# MAGIC case when SA.LE_STATUS is null then null when SA.LE_STATUS =  "Suspended" then "N" else "Y" end as L1_ACTIVE_IND,
# MAGIC case when SA.LE_TYPE =  "External" then "EXT" else "INT" end || "_" || 
# MAGIC case when SA.LE_CLASS = "Legal Entity" then "LE" else "BU" end as L1_TYPE,
# MAGIC SA.LE_PARTY_ID as L1_UNIQUE_ID,
# MAGIC case when SA.BU_STATUS is null then null when SA.BU_STATUS = "Suspended" then "N" else "Y" end as L2_ACTIVE_IND,
# MAGIC case when SA.BU_TYPE = "External" then "EXT" else "INT" end as L2_TYPE,
# MAGIC SA.LAST_UPDATE_DEAL,
# MAGIC SA.LAST_USER_UPDATE_DEAL,
# MAGIC SA.LAST_USER_UPDATE_DEAL_NAME,
# MAGIC SA.LE_LAST_UPDATED,
# MAGIC SA.LE_UPDATED_BY,
# MAGIC SA.LE_UPDATED_BY_NAME,
# MAGIC SA.LE_ADDRESS_1,
# MAGIC SA.LE_ADDRESS_2,
# MAGIC SA.LE_AGENCY_ACTIVITIES,
# MAGIC SA.LE_AGREEMENT_ID,
# MAGIC SA.LE_CITY,
# MAGIC SA.LE_CLASS,
# MAGIC SA.LE_COUNTRY,
# MAGIC SA.LE_CREATED_BY,
# MAGIC SA.LE_CREDIT_INTERNAL_RATING,
# MAGIC SA.LE_DESCRIPTION,
# MAGIC SA.LE_FAX,
# MAGIC SA.LE_INTERNAL_REFERENCE_1,
# MAGIC SA.LE_INTERNAL_REFERENCE_2,
# MAGIC SA.LE_INTERNAL_REFERENCE_3,
# MAGIC SA.LE_LINKED_PARTY_ID,
# MAGIC SA.LE_LNG_COMPANY_CODE,
# MAGIC SA.LE_LNG_EXT_SAP_CUSTOMER,
# MAGIC SA.LE_LNG_EXT_SAP_VENDOR,
# MAGIC SA.LE_LNG_INT_SAP_CUSTOMER,
# MAGIC SA.LE_LNG_INT_SAP_VENDOR,
# MAGIC SA.LE_LONG_NAME,
# MAGIC SA.LE_MAIL_CODE,
# MAGIC SA.LE_MAX_END_DATE,
# MAGIC SA.LE_MAXIMUM_DEAL_NUMBER,
# MAGIC SA.LE_PARTY_GROUP,
# MAGIC SA.PARTY_ID,
# MAGIC SA.LE_PHONE,
# MAGIC SA.LE_QGC_SAP_CUSTOMER,
# MAGIC SA.LE_QGC_SAP_VENDOR,
# MAGIC SA.LE_REMIT_REPORTABLE,
# MAGIC SA.LE_SGM_SAP_CUSTOMER,
# MAGIC SA.LE_SGM_SAP_IC_CUSTOMER,
# MAGIC SA.LE_SGM_SAP_IC_VENDOR,
# MAGIC SA.LE_SGM_SAP_VENDOR,
# MAGIC SA.LE_SHORT_NAME,
# MAGIC SA.LE_STATE,
# MAGIC SA.LE_STATUS,
# MAGIC SA.LE_TYPE,
# MAGIC SA.LE_VERSION,
# MAGIC SA.LEFT_RIGHT_LE_LAST_UPDATED,
# MAGIC SA.LEFT_RIGHT_LE_UPDATED_BY,
# MAGIC SA.LONG_NAME,
# MAGIC case when SA.LE_LONG_NAME is null then SA.LE_SHORT_NAME else SA.LE_LONG_NAME end as NAME,
# MAGIC SA.RIGHT_PARTY_ID as PARTY_ID2,
# MAGIC SA.RIGHT_CREATED_BY_NAME,
# MAGIC SA.RIGHT_LAST_UPDATE_DEAL,
# MAGIC SA.RIGHT_LAST_USER_UPDATE_DEAL,
# MAGIC SA.RIGHT_LAST_USER_UPDATE_DEAL_NAME,
# MAGIC SA.RIGHT_LE_LAST_UPDATED,
# MAGIC SA.RIGHT_LE_UPDATED_BY,
# MAGIC SA.RIGHT_LE_UPDATED_BY_NAME,
# MAGIC SA.RIGHT_PARTY_ID,
# MAGIC SA.RIGHT_TRADE_DATE,
# MAGIC SA.RIGHT_TRADER_ID,
# MAGIC SA.RIGHT_TRADER_ID_NAME,
# MAGIC case when trim(SA.VALUE) = '' or trim(SA.VALUE) is null then null 
# MAGIC      when cast(substr(SA.VALUE,1,1) as int) is null then lpad(SA.VALUE,10,"0") else SA.VALUE end as  SAP_ACCOUNT,
# MAGIC --cast(trim(SA.VALUE) as int) as SAP_ACCOUNT_NO,
# MAGIC REPLACE(LTRIM(REPLACE(TRIM(SA.VALUE), '0', ' ')),' ','0') as SAP_ACCOUNT_NO,
# MAGIC case when trim(SA.VALUE) = '' or trim(SA.VALUE) is null then null
# MAGIC      when SA.COL_NAME = "Customer" then "CUSTOMER"
# MAGIC      when SA.COL_NAME = "Vendor"   then "VENDOR" end as SAP_CPTY_TYPE,
# MAGIC case when trim(SA.VALUE) = '' or trim(SA.VALUE) is null then null else "L1" end as SAP_LINK_LEVEL,
# MAGIC case when trim(SA.VALUE) = '' or trim(SA.VALUE) is null then null else "STNSAP" end as SAP_SYSTEM,
# MAGIC --case when trim(SA.VALUE) = '' or trim(SA.VALUE) is null then null
# MAGIC --     when SA.COL_NAME = "Customer" then "STNSAP_Customer_" || trim(SA.VALUE)
# MAGIC --     when SA.COL_NAME = "Vendor" then "STNSAP_Vendor_" || trim(SA.VALUE) end as SAP_UNIQUE_ID,
# MAGIC case when trim(SA.VALUE) = '' or trim(SA.VALUE) is null then null
# MAGIC      when SA.COL_NAME = "Customer" then "STNSAP_Customer_" || REPLACE(LTRIM(REPLACE(trim(SA.VALUE), '0', ' ')),' ','0')
# MAGIC      when SA.COL_NAME = "Vendor" then "STNSAP_Vendor_" || REPLACE(LTRIM(REPLACE(trim(SA.VALUE), '0', ' ')),' ','0') end as SAP_UNIQUE_ID,
# MAGIC SA.SHELL_CREDIT_RATING,
# MAGIC SA.SHORT_NAME,
# MAGIC "SLMT" as SYSTEM,
# MAGIC SA.TRADE_DATE,
# MAGIC SA.TRADER_ID,
# MAGIC SA.TRADER_ID_NAME,
# MAGIC "SLMT_" || SA.LE_PARTY_ID || "_" || SA.BU_PARTY_ID as UNIQUE_ID,
# MAGIC SA.VALUE,
# MAGIC --SA.NAME, This is not used
# MAGIC 'ENDUR_LNG' as source_system,
# MAGIC SA.meta_created_dttm
# MAGIC from
# MAGIC vw_cp_slmt_master_entity SA
# MAGIC --vw_cp_le_bu_cons_sap_credit_rating_ENDUR_LNG SA Left Outer Join vw_cp_slmt_entity_ENDUR_LNG SE
# MAGIC --ON SA.BU_BU_FUNCTIONS = SE.Input_6_BU_BU_Functions

# COMMAND ----------

df = spark.sql("select * from vw_cp_slmt_master")

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_slmt_master')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_slmt_master_consum as
# MAGIC select distinct
# MAGIC   SA.UNIQUE_ID,
# MAGIC   --SA.LE_MAX_END_DATE  as LATEST_END_DATE,
# MAGIC   --SA.TRADE_DATE       as LATEST_TRADE_DATE,
# MAGIC   --SA.LAST_UPDATE_DEAL as LATEST_DEAL_UPDATE_DATE,
# MAGIC   SA.L1_UNIQUE_ID      as L1_ID,
# MAGIC   SA.BU_PARTY_ID       as L2_ID,
# MAGIC   SA.NAME              as L1_NAME,
# MAGIC   SA.SHORT_NAME        as L1_NAME1,
# MAGIC   SA.BU_SHORT_NAME     as L2_NAME1,
# MAGIC   SA.BU_LONG_NAME      as L2_NAME,
# MAGIC   SA.SAP_CPTY_TYPE,
# MAGIC   SA.SAP_ACCOUNT_NO,
# MAGIC   SA.SYSTEM, 
# MAGIC   SA.SAP_UNIQUE_ID,
# MAGIC   SA.SAP_SYSTEM,
# MAGIC   --SA.L1_TYPE,
# MAGIC   SA.ENTITY_TYPE,
# MAGIC   --SA.Entity,  -- not needed
# MAGIC   --SA.ADDRESS,
# MAGIC   SA.BU_PARTY_GROUP             as PARENT,
# MAGIC   --SA.LE_COUNTRY as COUNTRY,
# MAGIC   --SA.LEFT_RIGHT_LE_UPDATED_BY,
# MAGIC   --SA.RIGHT_LE_LAST_UPDATED      as LE_LAST_UPDATED,  --SA.RIGHT_LE_LAST_UPDATED changed from the LE_Last_updated to le_last_update
# MAGIC   SA.LEFT_RIGHT_LE_LAST_UPDATED   as LE_LAST_UPDATED,
# MAGIC   SA.SHELL_CREDIT_RATING        as SHELL_CREDIT_RATING,
# MAGIC   SA.LE_STATUS                  as LE_STATUS,
# MAGIC   SA.DELETED                    as DEACTIVATED, -- new column add in the table after adding in the table remove this comment
# MAGIC   SA.LE_COUNTRY                 as LE_COUNTRY,                            -- new column add in the table 
# MAGIC   CASE WHEN SA.SHELL_CREDIT_RATING ='E' then 'Y' Else 'N' END ERATE_FLAG,
# MAGIC   'ENDUR_LNG'                   as source_system,
# MAGIC   SA.meta_created_dttm
# MAGIC from vw_cp_slmt_master SA

# COMMAND ----------

df = spark.sql("select * from vw_cp_slmt_master_consum")

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_slmt_master_consum')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master as 
# MAGIC select distinct
# MAGIC      UNIQUE_ID          as cp_unique_id                -- req-26
# MAGIC     ,L1_ID    as cp_l1_id                    -- l1_id (req-28)
# MAGIC     ,L1_NAME  as cp_name                     --  l1_name (req-27)
# MAGIC     ,L1_ID   as cp_etrm_account_no          --  same as l1_id for slmt
# MAGIC     ,L2_ID   as cp_l2_id                    -- l2_id (req-29)
# MAGIC     ,L2_NAME as cp_l2_name                  -- l2_name (req-30)
# MAGIC     ,ENTITY_TYPE        as cp_entity_type              -- REQ-31
# MAGIC     ,LE_LAST_UPDATED as cp_created_or_updated_date  -- req-33/req-34
# MAGIC     ,DEACTIVATED  as cp_deactivated              -- req-32
# MAGIC     ,LE_COUNTRY as cp_country                  -- req-91
# MAGIC     ,PARENT                as cp_parent                   -- req-87
# MAGIC     ,SYSTEM                as cp_system                   -- req-36 --same as "SLMT?"
# MAGIC     ,SAP_ACCOUNT_NO        as cp_linked_sap_id            -- REQ-35
# MAGIC     ,SAP_CPTY_TYPE      as cp_sap_account_type         -- REQ-38
# MAGIC     ,SAP_UNIQUE_ID         as cp_sap_unique_id            -- REQ-97
# MAGIC     ,SAP_SYSTEM     as cp_linked_sap_system        -- REQ-93
# MAGIC     ,case when (SAP_UNIQUE_ID is null or length(trim(SAP_UNIQUE_ID)) = 0 ) then  'NO SAP LINK' 
# MAGIC            ELSE 'SAP LINK' 
# MAGIC      END cp_sap_link
# MAGIC     ,ERATE_FLAG as cp_erate_flag_in_source     -- REQ-9
# MAGIC     ,cast(null as string) as cp_erate_date_in_source     -- REQ-10
# MAGIC     ,cast(null as string)       as cp_erate_lifted_date_in_source  -- req-11
# MAGIC     ,cast(null as string)  as cp_broker_indicator 
# MAGIC     ,L1_ID   as cp_mapping_id   
# MAGIC     ,source_system         as source_system
# MAGIC     ,meta_created_dttm     as meta_created_dttm
# MAGIC 
# MAGIC from vw_cp_slmt_master_consum

# COMMAND ----------

DeleteInsertCuratedSqlTbl('pty_counterparty', 'cp_master', 'ENDUR_LNG')
