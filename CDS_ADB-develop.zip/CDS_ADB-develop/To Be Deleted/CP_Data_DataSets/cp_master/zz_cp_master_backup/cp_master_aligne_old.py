# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

#sens_inc_source_listTables = ['Z_DG_CPTY_DATA']
sens_inc_source_listTables = ['Z_DG_CPTY_MASTER','ZCPTY_DATA_LIMIT']
adls_source_schema =  'ZAINET'
source_system = 'ALIGNE'

# COMMAND ----------

# DBTITLE 1,Get Parameter Values
dbutils.widgets.text("Environment", "UAT")
dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path", "/mnt/ADLS/PROJECT/P00005-TS-PRE-PROD/ENR_UNHARM/SENS/1ST_PARTY/ALIGNE_PRD/")

ENV  = dbutils.widgets.get("Environment")
SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for Sens Full Datasets
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_inc_source_listTables])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# MAGIC 
# MAGIC %sql
# MAGIC create or replace temporary view z_dg_cpty_data_date as
# MAGIC (
# MAGIC --Step 1. Select All
# MAGIC with raw_z_dg_cpty_data as
# MAGIC (
# MAGIC      select
# MAGIC      C1_CPTY_ACTIVE
# MAGIC     ,C8_CPTY_AGEN
# MAGIC     ,C11_CPTY_AOP0
# MAGIC     ,C2_CPTY_ADATE0
# MAGIC     ,C15_CPTY_ATIME0
# MAGIC     ,C12_CPTY_AOP1
# MAGIC     ,C3_CPTY_ADATE1
# MAGIC     ,C16_CPTY_ATIME1
# MAGIC     ,C9_CPTY_ALF
# MAGIC     ,C10_CPTY_AOHM
# MAGIC     ,C65_CPTY_ROHM
# MAGIC     ,C64_CPTY_REFRESH
# MAGIC     ,C85_CPTY_ZKEY
# MAGIC     ,C76_CPTY_XKEY
# MAGIC     ,C73_CPTY_UTIL1
# MAGIC     ,C74_CPTY_UTIL2
# MAGIC     ,C31_CPTY_CPTY
# MAGIC     ,C22_CPTY_BRO
# MAGIC     ,C75_CPTY_UVAL
# MAGIC     ,C24_CPTY_CITY
# MAGIC     ,C34_CPTY_DSC
# MAGIC     ,C0_CPTY_ACCT
# MAGIC     ,C27_CPTY_CONTACT
# MAGIC     ,C70_CPTY_TELEPHONE
# MAGIC     ,C38_CPTY_FAX
# MAGIC     ,C71_CPTY_TELEX
# MAGIC     ,C36_CPTY_EMAIL
# MAGIC     ,C4_CPTY_ADDR1
# MAGIC     ,C5_CPTY_ADDR2
# MAGIC     ,C6_CPTY_ADDR3
# MAGIC     ,C7_CPTY_ADDR4
# MAGIC     ,C72_CPTY_TYPE
# MAGIC     ,C26_CPTY_CONFIRM
# MAGIC     ,C49_CPTY_NETGROSS
# MAGIC     ,C54_CPTY_PLCCY
# MAGIC     ,C48_CPTY_NETA
# MAGIC     ,C69_CPTY_SWIFT
# MAGIC     ,C53_CPTY_PAYID
# MAGIC     ,C52_CPTY_PARENT
# MAGIC     ,C77_CPTY_XREF
# MAGIC     ,C78_CPTY_XREF2
# MAGIC     ,C79_CPTY_XREF3
# MAGIC     ,C80_CPTY_XREF4
# MAGIC     ,C81_CPTY_XREFI
# MAGIC     ,C82_CPTY_XREFN
# MAGIC     ,C83_CPTY_XREFN2
# MAGIC     ,C25_CPTY_COMM
# MAGIC     ,C23_CPTY_CHOUSE
# MAGIC     ,C43_CPTY_LOC
# MAGIC     ,C67_CPTY_SALES
# MAGIC     ,C84_CPTY_ZGRID
# MAGIC     ,C50_CPTY_NOVATE
# MAGIC     ,C61_CPTY_PREC1
# MAGIC     ,C39_CPTY_FORM1
# MAGIC     ,C62_CPTY_PREC2
# MAGIC     ,C40_CPTY_FORM2
# MAGIC     ,C41_CPTY_IDATE
# MAGIC     ,C45_CPTY_MARG
# MAGIC     ,C42_CPTY_LIQ
# MAGIC     ,C27_CPTY_CONTACT
# MAGIC     ,C21_CPTY_BID
# MAGIC     ,C51_CPTY_OFFER
# MAGIC     ,C66_CPTY_RSET
# MAGIC     ,C44_CPTY_LOU
# MAGIC     ,C46_CPTY_MKTBASED
# MAGIC     ,C29_CPTY_COSTBASED
# MAGIC     ,C60_CPTY_PPAGMT
# MAGIC     ,C30_CPTY_COSTREF
# MAGIC     ,C57_CPTY_POWERP
# MAGIC     ,C59_CPTY_POWERT
# MAGIC     ,C55_CPTY_POWERG
# MAGIC     ,C56_CPTY_POWERL
# MAGIC     ,C58_CPTY_POWERS
# MAGIC     ,C13_CPTY_APPROVED
# MAGIC     ,C14_CPTY_APPROVEDDSC
# MAGIC     ,C63_CPTY_RECOVERYRATE
# MAGIC     ,C35_CPTY_DUNS
# MAGIC     ,C47_CPTY_NERC
# MAGIC     ,C68_CPTY_SECID
# MAGIC     from 
# MAGIC     ALIGNE_Z_DG_CPTY_DATA
# MAGIC  ),
# MAGIC --Step 2. DATE Table
# MAGIC  DATE as
# MAGIC  (
# MAGIC    select 
# MAGIC     C85_CPTY_ZKEY
# MAGIC    ,min(C2_CPTY_ADATE0) as CREATED
# MAGIC    ,max(C3_CPTY_ADATE1) as Max_C3_CPTY_ADATE1
# MAGIC    from ALIGNE_Z_DG_CPTY_DATA
# MAGIC    group by C85_CPTY_ZKEY
# MAGIC  )
# MAGIC --Step 3. Join
# MAGIC  select raw.*
# MAGIC  ,date.C85_CPTY_ZKEY as R_C85_CPTY_ZKEY
# MAGIC  ,date.CREATED
# MAGIC  ,date.Max_C3_CPTY_ADATE1
# MAGIC  from
# MAGIC  raw_z_dg_cpty_data raw inner join DATE
# MAGIC  on raw.C85_CPTY_ZKEY=date.C85_CPTY_ZKEY and raw.C3_CPTY_ADATE1=date.Max_C3_CPTY_ADATE1
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ALIGNE_Z_DG_CPTY_DATA limit 100

# COMMAND ----------

# MAGIC %sql
# MAGIC describe ALIGNE_Z_DG_CPTY_DATA

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct C43_CPTY_LOC, C4_CPTY_ADDR1, C5_CPTY_ADDR2, C6_CPTY_ADDR3, C7_CPTY_ADDR4 from z_dg_cpty_data_date where C6_CPTY_ADDR3 is Null and C7_CPTY_ADDR4 is Null

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct C43_CPTY_LOC, C4_CPTY_ADDR1, C5_CPTY_ADDR2, C6_CPTY_ADDR3, C7_CPTY_ADDR4 from z_dg_cpty_data_date where C43_CPTY_LOC is Null

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view HARMONIZE as
# MAGIC (
# MAGIC --Step 4. Parent & Child
# MAGIC   with child as
# MAGIC   (
# MAGIC   select * from z_dg_cpty_data_date
# MAGIC   where C72_CPTY_TYPE != 'P'
# MAGIC   ),
# MAGIC   parent as
# MAGIC   (
# MAGIC   select * from z_dg_cpty_data_date
# MAGIC   where C72_CPTY_TYPE = 'P'
# MAGIC   )
# MAGIC --Step 5.PARENT_CHILD
# MAGIC --Step 6. Harmonize
# MAGIC --Step 7. CLEANSE
# MAGIC   select 
# MAGIC   child.C1_CPTY_ACTIVE
# MAGIC   ,child.C65_CPTY_ROHM
# MAGIC   ,child.C85_CPTY_ZKEY
# MAGIC   ,trim(child.C31_CPTY_CPTY) C31_CPTY_CPTY
# MAGIC   ,trim(child.C24_CPTY_CITY) C24_CPTY_CITY
# MAGIC   ,trim(child.C34_CPTY_DSC) C34_CPTY_DSC
# MAGIC   ,trim(child.C0_CPTY_ACCT) C0_CPTY_ACCT
# MAGIC   ,trim(child.C4_CPTY_ADDR1) C4_CPTY_ADDR1
# MAGIC   ,trim(child.C5_CPTY_ADDR2) C5_CPTY_ADDR2
# MAGIC   ,trim(child.C6_CPTY_ADDR3) C6_CPTY_ADDR3
# MAGIC   ,trim(child.C7_CPTY_ADDR4) C7_CPTY_ADDR4
# MAGIC   ,child.C43_CPTY_LOC
# MAGIC   ,child.C72_CPTY_TYPE
# MAGIC   ,child.C52_CPTY_PARENT
# MAGIC   ,child.C13_CPTY_APPROVED
# MAGIC   ,child.CREATED
# MAGIC   ,child.Max_C3_CPTY_ADATE1
# MAGIC   ,parent.C1_CPTY_ACTIVE as PARENT_C1_CPTY_ACTIVE
# MAGIC   ,parent.C65_CPTY_ROHM as PARENT_C65_CPTY_ROHM
# MAGIC   ,parent.C85_CPTY_ZKEY  as PARENT_C85_CPTY_ZKEY
# MAGIC   ,trim(parent.C31_CPTY_CPTY) as PARENT_C31_CPTY_CPTY
# MAGIC   ,trim(parent.C24_CPTY_CITY) as PARENT_C24_CPTY_CITY
# MAGIC   ,trim(parent.C34_CPTY_DSC)as PARENT_C34_CPTY_DSC
# MAGIC   ,trim(parent.C0_CPTY_ACCT)as PARENT_C0_CPTY_ACCT
# MAGIC   ,trim(parent.C4_CPTY_ADDR1) as PARENT_C4_CPTY_ADDR1
# MAGIC   ,trim(parent.C5_CPTY_ADDR2) as PARENT_C5_CPTY_ADDR2
# MAGIC   ,trim(parent.C6_CPTY_ADDR3) as PARENT_C6_CPTY_ADDR3
# MAGIC   ,trim(parent.C7_CPTY_ADDR4) as PARENT_C7_CPTY_ADDR4
# MAGIC   ,parent.C72_CPTY_TYPE as PARENT_C72_CPTY_TYPE
# MAGIC   ,parent.C52_CPTY_PARENT as PARENT_C52_CPTY_PARENT
# MAGIC   ,parent.C13_CPTY_APPROVED as PARENT_C13_CPTY_APPROVED
# MAGIC   ,parent.CREATED as PARENT_CREATED
# MAGIC   ,parent.Max_C3_CPTY_ADATE1 as R_Max_C3_CPTY_ADATE1
# MAGIC 
# MAGIC   from
# MAGIC   child full outer join parent on child.C52_CPTY_PARENT = parent.C31_CPTY_CPTY
# MAGIC )

# COMMAND ----------

#Step 8. CPTY_TYPE
#create static DataFrame for CPTY_TYPE table
l_CPTY_TYPE=[
 ('A','A_Allocation')
,('B','B_Broker')
,('C','C_Counterparty')
,('F','F_FloorBroker')
,('H','H_House')
,('M','M_Match')
,('P','P_Parent')
,('R','R_')
,('S','S_')
,('T','T_') ]

df_CPTY_TYPE = spark.createDataFrame(l_CPTY_TYPE,['CPTY_TYPE','CPTY_TYPE_DESC'])

df_CPTY_TYPE.createOrReplaceTempView('CPTY_TYPE')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view UNIONED_HARMONIZED as
# MAGIC ( 
# MAGIC --Step 9. Join
# MAGIC  with Left_Hamonize_cpty_type as
# MAGIC  (
# MAGIC   select HARMONIZE.*
# MAGIC   ,CPTY_TYPE.CPTY_TYPE as Left_Right_CPTY_TYPE
# MAGIC   ,CPTY_TYPE.CPTY_TYPE_DESC
# MAGIC   from 
# MAGIC   HARMONIZE left join CPTY_TYPE on HARMONIZE.C72_CPTY_TYPE = CPTY_TYPE.CPTY_TYPE
# MAGIC  ),
# MAGIC  Joined_Hamonize_cpty_type as
# MAGIC  (
# MAGIC   select HARMONIZE.*
# MAGIC   ,CPTY_TYPE.CPTY_TYPE as Left_Right_CPTY_TYPE	
# MAGIC   ,CPTY_TYPE.CPTY_TYPE_DESC
# MAGIC   from 
# MAGIC   HARMONIZE inner join CPTY_TYPE on HARMONIZE.C72_CPTY_TYPE = CPTY_TYPE.CPTY_TYPE
# MAGIC  )
# MAGIC  
# MAGIC --Step 10. UNIONED_HARMONIZED
# MAGIC   select * from Left_Hamonize_cpty_type
# MAGIC   union
# MAGIC   select * from Joined_Hamonize_cpty_type
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view Final_Harmonize as
# MAGIC ( 
# MAGIC --Step 11. Join
# MAGIC  with LEFT_UNIONED_HARMONIZED as
# MAGIC  (
# MAGIC  select UNIONED_HARMONIZED.*
# MAGIC  ,CPTY_TYPE.CPTY_TYPE as Right_CPTY_TYPE	
# MAGIC  ,CPTY_TYPE.CPTY_TYPE_DESC as PARENT_CPTY_TYPE_DESC
# MAGIC  from
# MAGIC  UNIONED_HARMONIZED left join CPTY_TYPE on UNIONED_HARMONIZED.PARENT_C72_CPTY_TYPE=CPTY_TYPE.CPTY_TYPE
# MAGIC  ),
# MAGIC  
# MAGIC  JOINED_UNIONED_HARMONIZED as
# MAGIC  (
# MAGIC  select UNIONED_HARMONIZED.*
# MAGIC  ,CPTY_TYPE.CPTY_TYPE as Right_CPTY_TYPE	
# MAGIC  ,CPTY_TYPE.CPTY_TYPE_DESC as PARENT_CPTY_TYPE_DESC	
# MAGIC  from
# MAGIC  UNIONED_HARMONIZED inner join CPTY_TYPE on UNIONED_HARMONIZED.PARENT_C72_CPTY_TYPE=CPTY_TYPE.CPTY_TYPE
# MAGIC  )
# MAGIC 
# MAGIC --Step 12. Union
# MAGIC   select * from LEFT_UNIONED_HARMONIZED
# MAGIC   union
# MAGIC   select * from JOINED_UNIONED_HARMONIZED
# MAGIC  
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view Unioned_final_harmonised as
# MAGIC ( 
# MAGIC --Step 13. Filter
# MAGIC  with Final_Harmonize_TRUE as
# MAGIC  (
# MAGIC  select Final_Harmonize.*
# MAGIC  from Final_Harmonize where
# MAGIC  regexp_replace(trim(C0_CPTY_ACCT), '^[0]*', '') != "" AND C0_CPTY_ACCT is not Null
# MAGIC  ),
# MAGIC  Final_Harmonize_FALSE as
# MAGIC  (
# MAGIC  select Final_Harmonize.*, cast(Null as string) as RowCount 
# MAGIC  from Final_Harmonize where
# MAGIC  regexp_replace(trim(C0_CPTY_ACCT), '^[0]*', '')= "" or C0_CPTY_ACCT is Null
# MAGIC  ),
# MAGIC  Final_Harmonize_TRUE_RC as
# MAGIC  (
# MAGIC  select Final_Harmonize_TRUE.*,'1' as RowCount from Final_Harmonize_TRUE
# MAGIC  union all
# MAGIC  select Final_Harmonize_TRUE.*,'2' as RowCount from Final_Harmonize_TRUE
# MAGIC  )
# MAGIC  select * from Final_Harmonize_TRUE_RC
# MAGIC  union
# MAGIC  select * from Final_Harmonize_FALSE
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC describe Unioned_final_harmonised

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_aligne_master_stg as
# MAGIC (  
# MAGIC select
# MAGIC        concat('ALIGNE_', PARENT_C31_CPTY_CPTY, "_", C31_CPTY_CPTY) as UNIQUE_ID
# MAGIC      , PARENT_C34_CPTY_DSC as cp_legal_entity_name
# MAGIC      , PARENT_C31_CPTY_CPTY as L1_ID --Counterparty Legal Entity ID
# MAGIC      , C31_CPTY_CPTY as L2_ID --Counterparty Business Unit ID
# MAGIC      , C34_CPTY_DSC as cp_business_unit_name --Counterparty Business Unit Name
# MAGIC      , CPTY_TYPE_DESC as ENTITY_TYPE
# MAGIC      , IF(PARENT_C1_CPTY_ACTIVE= 0 and C85_CPTY_ZKEY is Null, 'X', (if (C1_CPTY_ACTIVE = 0, 'X', Null))) as DELETED -- Deactivation Flag
# MAGIC      , CREATED as CREATED_or_UPDATED --Counterparty Create Date (ETRM) Counterparty Update Date (ETRM)
# MAGIC      , regexp_replace(trim(C0_CPTY_ACCT), '^[0]*', '') as SAP_ACCOUNT_NO --Linked SAP Account Number
# MAGIC      , 'ALIGNE' as System
# MAGIC      , IF(regexp_replace(trim(C0_CPTY_ACCT), '^[0]*', '')= "" or C0_CPTY_ACCT is Null, Null, 
# MAGIC        IF(RowCount = 1, 'Customer', 'Vendor')) as SAP_CPTY_TYPE --Linked SAP Account Counterparty Type (Customer/Vendor in ETRM)
# MAGIC      , PARENT_C52_CPTY_PARENT as PARENT
# MAGIC      , if(C43_CPTY_LOC is not Null, C43_CPTY_LOC, trim(concat(C6_CPTY_ADDR3," ",C7_CPTY_ADDR4))) as COUNTRY --Account country of registration (ETRM)
# MAGIC      , IF(regexp_replace(trim(C0_CPTY_ACCT), '^[0]*', '')= "" or C0_CPTY_ACCT is Null, Null, 'STNSAP') as SAP_SYSTEM --Linked SAP System
# MAGIC      
# MAGIC      --Present in the alteryx workflow but not required acc to the mapping
# MAGIC      , trim(concat(C4_CPTY_ADDR1," ",C5_CPTY_ADDR2)) as ADDRESS
# MAGIC      , if(C34_CPTY_DSC is Null, PARENT_C34_CPTY_DSC, C34_CPTY_DSC) as NAME
# MAGIC      , IF(regexp_replace(trim(C0_CPTY_ACCT), '^[0]*', '')= "" or C0_CPTY_ACCT is Null, Null, 
# MAGIC        concat('STNSAP_', IF(RowCount = 1, 'Customer', 'Vendor'), '_', (regexp_replace(trim(C0_CPTY_ACCT), '^[0]*', '')))) as SAP_UNIQUE_ID
# MAGIC      , C0_CPTY_ACCT as L1_ID_NEW
# MAGIC      , C72_CPTY_TYPE as L2_TYPE
# MAGIC      , C34_CPTY_DSC as L2_NAME1
# MAGIC from
# MAGIC       Unioned_final_harmonised
# MAGIC       where CPTY_TYPE_DESC="B_Broker" or CPTY_TYPE_DESC="C_Counterparty"
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC describe vw_cp_aligne_master_stg

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_aligne_master as
# MAGIC (  
# MAGIC select distinct
# MAGIC     stg.*
# MAGIC     , concat(SAP_SYSTEM,'_',SAP_CPTY_TYPE,'_',SAP_ACCOUNT_NO) as Linked_SAP_Unique_ID --ETRM Linked SAP Unique ID
# MAGIC     from
# MAGIC     vw_cp_aligne_master_stg stg
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC describe vw_cp_aligne_master

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct cp_legal_entity_name) from vw_cp_aligne_master

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_cp_aligne_master

# COMMAND ----------

df = spark.sql("select * from vw_cp_aligne_master")

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_aligne_master')
