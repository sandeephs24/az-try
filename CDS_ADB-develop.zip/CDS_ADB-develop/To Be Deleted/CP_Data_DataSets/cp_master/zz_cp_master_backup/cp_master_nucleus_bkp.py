# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

sens_full_source_listTables = ['COMPANIES','VENDOR_MASTER_VIEW','COMPANY_ADDRESSES','LEGAL_ENTITIES']
adls_source_schema =  'NUCDBA'
source_system = 'NUCLEUS'

# COMMAND ----------

# DBTITLE 1,Get Parameter Values
dbutils.widgets.text("Environment", "DEV")
dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path", "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/SENS/1ST_PARTY/NUCLEUS")


ENV  = dbutils.widgets.get("Environment")
SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for Sens Full Datasets
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_full_source_listTables])

#create dataframe for Full load
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

print(dataframedict)
print(FilePathDict)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_nucleus as
# MAGIC select 
# MAGIC 'NUCLEUS_' ||  cast(C.COMPANY_KEY as int)  as UNIQUE_ID, 
# MAGIC C.LONG_NAME as NAME, 
# MAGIC C.COMPANY_KEY as L1_ID,
# MAGIC CASE WHEN LE.CY_ENTITY_KEY IS NOT NULL THEN 'INTERNAL' ELSE 'EXTERNAL' END COMPANY_TYPE, 
# MAGIC CASE WHEN C.ACTIVE_FLAG = 'Y' THEN 'N' ELSE 'Y' END AS DEACTIVATED,
# MAGIC --CASE WHEN C.ACTIVE_FLAG = 'N' THEN 'X' ELSE '' END AS DEACTIVATED, -- for DEACTIVATED logic
# MAGIC cast(C.CREATE_DATE as timestamp) as CREATED,
# MAGIC --C.CREATE_DATE as CREATED_org,
# MAGIC cast(C.MODIFY_DATE as timestamp) as UPDATED,
# MAGIC --C.MODIFY_DATE as UPDATED_org,
# MAGIC --VMV.VENDOR_ID as SAP_ACCOUNT_NO,
# MAGIC TRIM(LEADING '0' FROM VMV.VENDOR_ID)  as SAP_ACCOUNT_NO,
# MAGIC 'NUCLEUS' as SYSTEM,
# MAGIC --'Vendor' as SAP_CPTY_TYPE,
# MAGIC CASE WHEN VMV.VENDOR_ID IS NOT NULL THEN 'Vendor' ELSE NULL END as SAP_CPTY_TYPE,
# MAGIC CA.STE_COU_COUNTRY_CODE as COUNTRY,
# MAGIC --'STNSAP' as SAP_SYSTEM,
# MAGIC CASE WHEN VMV.VENDOR_ID IS NOT NULL THEN 'STNSAP' ELSE NULL END as SAP_SYSTEM,
# MAGIC --CASE WHEN VMV.VENDOR_ID IS NOT NULL THEN 'STNSAP_' || 'VENDOR_' || VMV.VENDOR_ID ELSE NULL END as SAP_UNIQUE_ID,
# MAGIC CASE WHEN VMV.VENDOR_ID IS NOT NULL THEN 'STNSAP_' || 'Vendor_' || TRIM(LEADING '0' FROM VMV.VENDOR_ID) ELSE NULL END as SAP_UNIQUE_ID,
# MAGIC 'NUCLEUS' as source_system,
# MAGIC cast(C.meta_created_dttm as timestamp) as meta_created_dttm
# MAGIC from nucleus_COMPANIES C
# MAGIC LEFT JOIN nucleus_LEGAL_ENTITIES LE -- for COMPANY_TYPE
# MAGIC ON C.COMPANY_KEY = LE.CY_ENTITY_KEY
# MAGIC LEFT JOIN (SELECT VENDOR_ID, SHORTNAME -- for SAP_ACCOUNT_NO
# MAGIC FROM nucleus_VENDOR_MASTER_VIEW VMV
# MAGIC GROUP BY VENDOR_ID, SHORTNAME) VMV
# MAGIC ON NVL(C.COMPANY_CODE, C.SHORT_NAME) = VMV.SHORTNAME
# MAGIC LEFT JOIN (SELECT CO_CY_COMPANY_KEY, STE_COU_COUNTRY_CODE -- for COUNTRY
# MAGIC FROM nucleus_COMPANY_ADDRESSES
# MAGIC GROUP BY CO_CY_COMPANY_KEY, STE_COU_COUNTRY_CODE) CA
# MAGIC ON C.COMPANY_KEY = CA.CO_CY_COMPANY_KEY
# MAGIC ORDER BY L1_ID ASC;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_cp_master_nucleus

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master_nucleus')

# COMMAND ----------

# MAGIC %sql
# MAGIC describe vw_cp_master_nucleus

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master as 
# MAGIC select distinct
# MAGIC      UNIQUE_ID          as cp_unique_id                -- req-26
# MAGIC     ,L1_ID    as cp_l1_id                    -- l1_id (req-28)
# MAGIC     ,NAME  as cp_name                     --  l1_name (req-27)
# MAGIC     ,L1_ID   as cp_etrm_account_no          --  same as l1_id for slmt
# MAGIC     ,cast(null as string)   as cp_l2_id                    -- l2_id (req-29)
# MAGIC     ,cast(null as string) as cp_l2_name                  -- l2_name (req-30)
# MAGIC     ,COMPANY_TYPE        as cp_entity_type              -- REQ-31
# MAGIC     ,IF(CREATED is null, UPDATED, CREATED) as cp_created_or_updated_date  -- req-33/req-34
# MAGIC     ,DEACTIVATED  as cp_deactivated              -- req-32
# MAGIC     ,COUNTRY as cp_country                  -- req-91
# MAGIC     ,cast(null as string)                as cp_parent                   -- req-87
# MAGIC     ,SYSTEM                as cp_system                   -- req-36
# MAGIC     ,SAP_ACCOUNT_NO        as cp_linked_sap_id            -- REQ-35
# MAGIC     ,SAP_CPTY_TYPE      as cp_sap_account_type         -- REQ-38
# MAGIC     ,SAP_UNIQUE_ID         as cp_sap_unique_id            -- REQ-97
# MAGIC     ,SAP_SYSTEM     as cp_linked_sap_system        -- REQ-93
# MAGIC     ,case when (SAP_UNIQUE_ID is null or length(trim(SAP_UNIQUE_ID)) = 0 ) then  'NO SAP LINK' 
# MAGIC            ELSE 'SAP LINK' 
# MAGIC      END cp_sap_link
# MAGIC     ,cast(null as string) as cp_erate_flag_in_source     -- REQ-9
# MAGIC     ,cast(null as string) as cp_erate_date_in_source     -- REQ-10
# MAGIC     ,cast(null as string)       as cp_erate_lifted_date_in_source  -- req-11
# MAGIC     ,cast(null as string)  as cp_broker_indicator 
# MAGIC     ,L1_ID   as cp_mapping_id   
# MAGIC     ,source_system         as source_system
# MAGIC     ,meta_created_dttm     as meta_created_dttm
# MAGIC 
# MAGIC from vw_cp_master_nucleus

# COMMAND ----------

DeleteInsertCuratedSqlTbl('pty_counterparty', 'cp_master', 'NUCLEUS')
