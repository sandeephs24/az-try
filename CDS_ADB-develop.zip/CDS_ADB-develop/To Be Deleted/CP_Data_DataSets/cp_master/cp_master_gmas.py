# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

#sens_inc_source_listTables = ['Z_DG_CPTY_DATA']
sens_inc_source_listTables = ['ORGANISATION','ASSET','PARTY_ROLE','ADDRESS','ADDRESS_USAGE','PARTY_ROLE_TYPE']
adls_source_schema =  'GMAS'
source_system = 'GMAS'

# COMMAND ----------

dbutils.fs.ls("/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/NON-SENS/1ST_PARTY/GMAS/DEV/GMAS.ORGANISATION/")

# COMMAND ----------

dbutils.widgets.text("Environment", "DEV")
dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path", "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/NON-SENS/1ST_PARTY/GMAS/")
ENV  = dbutils.widgets.get("Environment")
SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_inc_source_listTables])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
 # print(key,value)
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# MAGIC %sql
# MAGIC --select distinct active_status from GMAS_ORGANISATION limit 10
# MAGIC select  org.*
# MAGIC FROM 
# MAGIC     GMAS_Organisation org 
# MAGIC     LEFT JOIN GMAS_Party_Role pr ON org.organisation_id = pr.party_id
# MAGIC     LEFT JOIN GMAS_Address_usage au ON pr.party_role_id = au.party_role_id
# MAGIC     LEFT JOIN GMAS_Address ad ON au.address_id = ad.address_id  
# MAGIC     LEFT JOIN GMAS_Asset a ON ad.country_id = a.asset_id
# MAGIC     LEFT JOIN GMAS_party_role_type prt ON pr.party_role_type_id = prt.party_role_type_id
# MAGIC WHERE 
# MAGIC     prt.party_role_type_code NOT IN ('ORGANISATION_MAIN', 'PERSON_MAIN') limit 10

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_SAP_Code_unq_vendon_customer as
# MAGIC 
# MAGIC ( with SAP_Code_unq as 
# MAGIC   (
# MAGIC   select distinct SAP_CODE from GMAS_Party_Role
# MAGIC   ),
# MAGIC   Cust_Vendor as 
# MAGIC   (
# MAGIC   select 'Vendor' as SAP_ACCOUNT_TYPE
# MAGIC   union 
# MAGIC   select 'Customer' as SAP_ACCOUNT_TYPE
# MAGIC   )
# MAGIC   
# MAGIC   select * from SAP_Code_unq join Cust_Vendor on 1 = 1
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_SAP_Code_unq_vendon_customer limit 20

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_gmas_temp as -- view without Req 38 and Req 97
# MAGIC SELECT 
# MAGIC       cast (null as string)      as ERATE_FLAG
# MAGIC     , org.ORGANISATION_FULL_NAME                                                         as NAME
# MAGIC     , 'GMAS_' || cast(org.ORGANISATION_ID as int)                                        as UNIQUE_ID
# MAGIC     , org.ORGANISATION_SHORT_NAME                                                        as L1_ID
# MAGIC     , CASE when org.ACTIVE_STATUS = 'Active' Then 'N' else 'Y' end                       as DEACTIVATED
# MAGIC     , cast(org.CREATED_DT  as timestamp)                                                 as CREATED_DATE
# MAGIC     , cast(null as timestamp)                                                            as ERATE_DATE
# MAGIC     , cast(org.LAST_UPDATED_DT  as timestamp)                                            as UPDATED_DATE
# MAGIC     , pr.SAP_CODE                                                                        as SAP_ACCOUNT_NO
# MAGIC     , 'GMAS'                                                                             as SOURCE_SYSTEM
# MAGIC     , a.asset_name                                                                       as COUNTRY
# MAGIC     , 'STNSAP'                                                                           as SAP_SYSTEM
# MAGIC    -- , a.asset_active_status
# MAGIC     , prt.PARTY_ROLE_TYPE_DESC                                                           as COUNTERPARTY_TYPE
# MAGIC     , org.ORGANISATION_SHORT_NAME                                                        as CPTY_BUSINESS_UNIT_NAME
# MAGIC FROM 
# MAGIC     GMAS_Organisation org 
# MAGIC     LEFT JOIN GMAS_Party_Role pr ON org.organisation_id = pr.party_id
# MAGIC     LEFT JOIN GMAS_Address_usage au ON pr.party_role_id = au.party_role_id
# MAGIC     LEFT JOIN GMAS_Address ad ON au.address_id = ad.address_id  
# MAGIC     LEFT JOIN GMAS_Asset a ON ad.country_id = a.asset_id
# MAGIC     LEFT JOIN GMAS_party_role_type prt ON pr.party_role_type_id = prt.party_role_type_id
# MAGIC WHERE 
# MAGIC     prt.party_role_type_code NOT IN ('ORGANISATION_MAIN', 'PERSON_MAIN')
# MAGIC ORDER BY org.organisation_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_gmas_temp  limit 1000

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_gmas as
# MAGIC Select
# MAGIC   gm.ERATE_FLAG,
# MAGIC   gm.UNIQUE_ID,
# MAGIC   gm.NAME,
# MAGIC   gm.DEACTIVATED,
# MAGIC   gm.L1_ID,
# MAGIC   gm.COUNTRY,
# MAGIC   gm.SAP_SYSTEM,
# MAGIC   gm.UPDATED_DATE,
# MAGIC   gm.CREATED_DATE,
# MAGIC   gm.ERATE_DATE,
# MAGIC   gm.SAP_ACCOUNT_NO,
# MAGIC   vc.SAP_ACCOUNT_TYPE,
# MAGIC   case
# MAGIC     when trim(SAP_ACCOUNT_NO) = ''
# MAGIC     or SAP_ACCOUNT_NO is null then null
# MAGIC     else gm.SAP_SYSTEM || '_' || vc.SAP_ACCOUNT_TYPE || '_' || gm.SAP_ACCOUNT_NO
# MAGIC   end as SAP_UNIQUE_ID,
# MAGIC   gm.SOURCE_SYSTEM,
# MAGIC   current_timestamp as META_CREATED_DTTM,
# MAGIC   gm.CPTY_BUSINESS_UNIT_NAME,
# MAGIC   gm.COUNTERPARTY_TYPE
# MAGIC FROM
# MAGIC   (Select distinct * from vw_gmas_temp) gm
# MAGIC   left join vw_SAP_Code_unq_vendon_customer vc on gm.SAP_ACCOUNT_NO = vc.SAP_CODE

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_cp_master_gmas limit 100

# COMMAND ----------

df_final = spark.sql("select * from vw_cp_master_gmas")
df_final.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master_gmas')

# COMMAND ----------

from pyspark.sql.types import StringType, TimestampType
df_cp_master = df_final.select(col('UNIQUE_ID').alias('cp_unique_id'),                                                   #REQ-26
                         col('L1_ID').alias('cp_l1_id'),                           #REQ-28
                         col('NAME').alias('cp_name'),                          #REQ-27
                         col('L1_ID').alias('cp_etrm_account_no'),                                       #--------
                         lit(None).cast(StringType()).alias('cp_l2_id'),                          #REQ-29
                         lit(None).cast(StringType()).alias('cp_l2_name'),                      #REQ-30
                         lit(None).cast(StringType()).alias('cp_entity_type'),                                                 #REQ-31
                         expr("case when CREATED_DATE is   \
                              Null then UPDATED_DATE else CREATED_DATE end").cast(TimestampType())\
                         .alias('cp_created_or_updated_date'),                                  #REQ-33/34 -------
                         col('DEACTIVATED').alias('cp_deactivated'),                   #REQ-32
                         col('COUNTRY').alias('cp_country'),                                    #REQ-91
                         lit(None).cast(StringType()).alias('cp_parent'),                       #REQ-87
                         col('SOURCE_SYSTEM').alias('cp_system'),                                      #REQ-36
                         col('SAP_ACCOUNT_NO').alias('cp_linked_sap_id'),                       #REQ-35
                         col('SAP_ACCOUNT_TYPE').alias('cp_sap_account_type'),                  #REQ-38
                         col('SAP_UNIQUE_ID').alias('cp_sap_unique_id'),                        #REQ-97
                         col('SAP_SYSTEM').alias('cp_linked_sap_system'),                       #REQ-93
                         expr("case when SAP_UNIQUE_ID is   \
                              Null or SAP_UNIQUE_ID = '' then 'NO SAP LINK' else 'SAP LINK' end")\
                         .alias('cp_sap_link'),
                         lit(None).cast(StringType()).alias('cp_erate_flag_in_source'),                    #REQ-9
                         lit(None).cast(TimestampType()).alias('cp_erate_date_in_source'),                    #REQ-10
                         lit(None).cast(TimestampType()).alias('cp_erate_lifted_date_in_source'),   #REQ-11
                         lit(None).cast(StringType()).alias('cp_broker_indicator'),             #REQ-86
                         col('L1_ID').alias('cp_mapping_id'),
                         col('SOURCE_SYSTEM'),
                         col('meta_created_dttm')
                        
                        
                        ).distinct()

# COMMAND ----------

df_cp_master.createOrReplaceTempView(f"vw_cp_master")

# COMMAND ----------

df_cp_master.count()

# COMMAND ----------

DeleteInsertCuratedSqlTbl('pty_counterparty', 'cp_master', 'GMAS')
