# Databricks notebook source
#make all the imports here
from pyspark.sql.functions import *
import pyodbc

# COMMAND ----------

# MAGIC %sh
# MAGIC curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
# MAGIC curl https://packages.microsoft.com/config/ubuntu/16.04/prod.list > /etc/apt/sources.list.d/mssql-release.list 
# MAGIC apt-get update
# MAGIC ACCEPT_EULA=Y apt-get install msodbcsql17
# MAGIC apt-get -y install unixodbc-dev
# MAGIC sudo apt-get install python3-pip -y
# MAGIC pip3 install --upgrade pyodbc

# COMMAND ----------

sens_source_listTables_rptg = ['VW_MI_Customer_Core' , 'VW_MI_Customer_Core_Extended']
sens_source_listTables_dv =   ['R_CUST_ARCH_GT']
adls_source_schema_rptg    =  'RPTG'
adls_source_schema_dv      =  'DV'
source_system = 'gtmi'

# COMMAND ----------

# DBTITLE 1,Get Parameters Values
dbutils.widgets.text("Environment", "UAT")
dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path",   "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/SENS/1ST_PARTY/GOLD_TIER_MI")
# SENS_ADLS_ENR_UNHARM_Path = "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/SENS/1ST_PARTY/GOLD_TIER_MI"
# ENV = 'UAT'

ENV  = dbutils.widgets.get("Environment")
SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for DV Schema
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema_dv}.{x}/{x}.parquet") for x in sens_source_listTables_dv])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")


# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for RPTG Schema
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema_rptg}.{x}/{x}.parquet") for x in sens_source_listTables_rptg])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# DBTITLE 1,Shared Config for Azure Resources
# MAGIC %run "/Shared/CP_Data/Config/config"

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_gtmi_singlecplist_GOLD_TIER_MI as 
# MAGIC select distinct 
# MAGIC    cc.GoldTier_ID
# MAGIC   ,cast(cc.Policy_Status_Date as  Date )            as GT_KYC_Policy_Status_Date
# MAGIC   ,cc.Country_Of_Operations                         as GT_Country_of_Operations
# MAGIC   ,cc.Legal_Country                                 as GT_Legal_Country
# MAGIC   ,cast(cc.Policy_Last_Review_Date as date)         as GT_Policy_Last_Review_Date
# MAGIC   ,cast(cc.Policy_Next_Review_Date as date)         as GT_Policy_Next_Rereview_Date
# MAGIC   ,cc.Nature_of_business                            as Nature_Of_Business
# MAGIC   ,cc.What_is_your_rationale_for_wanting_to_onboard as Rationale_for_Onboarding
# MAGIC   ,cc.Sanctions_type                                as Sanctions
# MAGIC   ,case when cc.Policy_Status is not null then Policy_Status 
# MAGIC         else cc.Entity_Status
# MAGIC    end                                              as GT_KYC_Policy_Status
# MAGIC   ,cc.Policy_Status                                 as Policy_Status
# MAGIC   ,cc.Entity_Status                                 as Entity_Status
# MAGIC   ,cce.Sectoral_Sanctioning_Body                    as Sectoral_Sanctioning_Body
# MAGIC   ,cce.Customers_Wc_Sanctions_Desc                  as Customers_Wc_Sanctions_Desc
# MAGIC   ,cce.Shell_Customer_Tc_Advice                     as Shell_Customer_Tc_Advice
# MAGIC   ,cc.Related_Party_Status                          as Related_Party_Status
# MAGIC   ,case when cc.DD_Level_Approved is not null then cc.DD_Level_Approved
# MAGIC         else cc.Due_Diligence_Level
# MAGIC    end                                              as KYC_Due_Diligence_Level
# MAGIC   ,cc.DD_Level_Approved
# MAGIC   ,cc.Due_Diligence_Level
# MAGIC   ,cc.Entity_Type                                   as KYC_Entity_Type
# MAGIC   ,cc.Approved_With_Conditions_Flag                 as KYC_Approved_with_Conditions
# MAGIC   ,cc.Rejected_With_Conditions_Flag                 as KYC_Rejected_with_Conditions
# MAGIC   ,cc.Approved_With_Condition_Remarks               as KYC_Approved_with_Conditions_Remarks
# MAGIC   ,''                                               as DNDB_Flag
# MAGIC   ,cast(cc.Policy_Approved_date as date)            as GT_KYC_Policy_Approved_Date
# MAGIC   ,cast(cc.meta_created_dttm  as date)              as meta_created_dttm
# MAGIC   ,'GOLD_TIER_MI'                                   as source_system
# MAGIC from gtmi_vw_mi_customer_core cc           
# MAGIC --left join dndb_list           dndb  on upper(trim(cc.Legal_Name)) =  upper(trim(dndb.Legal_Name))
# MAGIC left join (select distinct 
# MAGIC                  cce.GoldTier_ID
# MAGIC                 ,cce.Sectoral_Sanctioning_Body
# MAGIC                 ,cce.Customers_Wc_Sanctions_Desc
# MAGIC                 ,cce.Shell_Customer_Tc_Advice
# MAGIC            from gtmi_vw_mi_customer_core_extended cce 
# MAGIC            where cce.Record_Active_Flag = 'Y') cce  on  cce.GoldTier_ID = cc.GoldTier_ID
# MAGIC WHERE  cc.Record_Active_Flag = 'Y' 
# MAGIC AND	 cc.GoldTier_ID NOT IN (SELECT distinct GOLDTIER_ID FROM gtmi_R_CUST_ARCH_GT )

# COMMAND ----------

df = spark.sql("select * from vw_gtmi_singlecplist_GOLD_TIER_MI LIMIT 100000")

# COMMAND ----------

# DBTITLE 1,To get the "refreshSqlDbTbl" function is available 
# MAGIC %run "/Shared/CP_Data/Shared_script/main"

# COMMAND ----------

# df.write.format("jdbc").mode("append").option("url", Stratos_sqldb_URL).option("dbtable", "cp_data_user.gtmi_singlecplist").save()
RefreshSqlDbTbl('cp_data_user', 'gtmi_singlecplist', 'GOLD_TIER_MI')
