# Databricks notebook source
# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

# DBTITLE 1,Tables List
non_sens_full_source_listTables = ['CPTY_vwSCPL']
adls_source_schema =  'dbo'
source_system = 'SCPL'

# COMMAND ----------

# DBTITLE 1,Parameters
dbutils.widgets.text("Environment", "UAT")
dbutils.widgets.text("NON_SENS_ADLS_ENR_UNHARM_Path", "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/NON-SENS/1ST_PARTY/SCPL")
ENV  = dbutils.widgets.get("Environment")
NON_SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("NON_SENS_ADLS_ENR_UNHARM_Path")


# COMMAND ----------

FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_full_source_listTables])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# dataset_list = ['scpl.ext_cpty_vwscpl_sens']
# print(dataset_list)

# COMMAND ----------

# print(CreateTempVwFromExternalTables(dataset_list))

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from scpl_CPTY_vwSCPL

# COMMAND ----------

# MAGIC  %sql
# MAGIC create or replace temporary view vw_scpl_cpty_vwscpl_scpl as 
# MAGIC select cptygroupid, cptyid, cptyname, eratedate, eratedflag, deactivatedflag, systemuniqueprefix, goldtierid, gt_legalentity, gt_ddlevel, gt_ddlevelapproved, gt_policystatus, cptyupdatedon, 
# MAGIC        meta_created_dttm, effective_start_date, effective_end_date, is_record_active,'SCPL' as SOURCE_SYSTEM from scpl_CPTY_vwSCPL;

# COMMAND ----------

df = spark.sql("select *  from vw_scpl_cpty_vwscpl_scpl")
df.count()

# COMMAND ----------

RefreshSqlDbTbl('pty_counterparty', 'scpl_cpty_vwscpl' , 'SCPL')

# COMMAND ----------


