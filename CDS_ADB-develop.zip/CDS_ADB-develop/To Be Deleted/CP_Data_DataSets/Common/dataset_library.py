# Databricks notebook source
#make all the imports here
from pyspark.sql.functions import *
import pyodbc

# COMMAND ----------

# MAGIC %run "/Shared/CP_Data/Config/config"

# COMMAND ----------

# MAGIC %run "/Shared/CP_Data/Shared_script/main"

# COMMAND ----------

# MAGIC %sh
# MAGIC curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
# MAGIC curl https://packages.microsoft.com/config/ubuntu/16.04/prod.list > /etc/apt/sources.list.d/mssql-release.list 
# MAGIC apt-get update
# MAGIC ACCEPT_EULA=Y apt-get install msodbcsql17
# MAGIC apt-get -y install unixodbc-dev
# MAGIC sudo apt-get install python3-pip -y
# MAGIC pip3 install --upgrade pyodbc

# COMMAND ----------

def DeleteInsertCuratedSqlTbl(tgt_schema_name, tgt_table_name, source_system):
        """
        Loads the data into sql server for curated layer
        tgt_schema_name = 'cp_data'
        tgt_tablename   = 'gtmi_singlecplist'
        source_system   = 'GOLD_TIER_MI'
        """
        try:
            df = spark.sql(f"select * from  vw_{tgt_table_name}")
            print(tgt_schema_name , tgt_table_name, source_system)
            if df.count() > 0:
                print(df.count())
                conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                                    'SERVER='+dbServer_curated+';'
                                    'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
                                    'PWD='+dbPass
                                    )
                cursor = conn.cursor()
                execSQL = f"delete from {tgt_schema_name}.{tgt_table_name} where source_system = upper('{source_system}')"
                conn.autocommit = True
                cursor.execute(execSQL)
                print("Data been Deleted")
                df.write.jdbc(Stratos_sqldb_URL_curated, f"{tgt_schema_name}.{tgt_table_name}", "append")
                print(f"load of {tgt_table_name}  of {source_system} is completed")
            else:
                print("Returned Zero Records")

        except Exception as e:
            print('Exception raised')
            raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,ADLS
def create_temp_views_per_source_system(source_system,vw_prefix_name):
    """
     create tempviews for adls paths
    """
    src_tables_List= [] # empty to store the table name and filepath
    temp_views_List= [] # temporary views to print the in notebook when called.
    df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'cp_data.config_adls_paths') # read config table to retrieve the adls file paths
    df = df.filter(f"source_system == '{source_system}'")
    IsSAPHANA = True if source_system == 'SAPHANA' else False   #specific to SAPHANA
    df = df.filter("active_flag == 1")
    df.createOrReplaceTempView(f"vw_cp_data_config_adls_paths")
    df_new = df.toPandas()
#     df_new = df_new.filter("active_flag=='Y'")
#     print(df_new.head())
                   
    dataframedict = {}
    for row in df_new.itertuples():
        src_tables_List.append((row.src_table_name,  row.old_adls_full_path, row.new_adls_full_path))
        if row.adls_file_format =='parquet' and row.old_new_adls_path_indicator =='OLD':
          dataframedict[row.src_table_name] = spark.read.format("parquet").load(row.old_adls_full_path).filter(col("IS_RECORD_ACTIVE") == 1)
        elif row.adls_file_format =='delta' and row.old_new_adls_path_indicator =='OLD':
          dataframedict[row.src_table_name] = spark.read.format("delta").load(row.old_adls_full_path).filter(col("IS_RECORD_ACTIVE") == 1)
        elif row.adls_file_format =='parquet' and row.old_new_adls_path_indicator =='NEW':
          dataframedict[row.src_table_name] = spark.read.format("parquet").load(row.new_adls_full_path).filter(col("IS_RECORD_ACTIVE") == 1)
        elif row.adls_file_format =='delta' and row.old_new_adls_path_indicator =='NEW':
          dataframedict[row.src_table_name] = spark.read.format("delta").load(row.new_adls_full_path).filter(col("IS_RECORD_ACTIVE") == 1)
          
    #create the temporary views
    for key,value in dataframedict.items():
    #  if IsSAPHANA == True :
    #    
    #    temp_views_List.append(f"vw_{vw_prefix_name}_{key.split('/')[1]}")
    #    dataframedict[key] = value.createOrReplaceTempView(f"{vw_prefix_name}_{key.split('/')[1]}")
    #  else : 
        temp_views_List.append(f"vw_{vw_prefix_name}_{key}")
        dataframedict[key] = value.createOrReplaceTempView(f"{vw_prefix_name}_{key}")
    print("Temp View Names")
    print(temp_views_List)

# COMMAND ----------

#Parameters
#dbutils.widgets.text("Environment", "UAT")
#dbutils.widgets.text("NON_SENS_ADLS_ENR_UNHARM_Path",   "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/NON-SENS/1ST_PARTY/ENDUR_LNG/")
#dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path",   "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/SENS/1ST_PARTY/ENDUR_LNG/")
#
#ENV  = dbutils.widgets.get("Environment")
#NON_SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("NON_SENS_ADLS_ENR_UNHARM_Path")
#SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

#Create Dataframe and Temporary Views for Sens Tables from ADLS
#FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_source_listTables_edw])
#
##create dataframe 
#dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])
#
#for key,value in dataframedict.items():
#  dataframedict[key] = value.createOrReplaceTempView(f"{key}")

# COMMAND ----------

# Create Dataframe and Temporary Views for Non-Sens Tables from ADLS
#FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_source_listTables_edw])
#
##create dataframe 
#dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])
#
#for key,value in dataframedict.items():
#  dataframedict[key] = value.createOrReplaceTempView(f"{key}")
