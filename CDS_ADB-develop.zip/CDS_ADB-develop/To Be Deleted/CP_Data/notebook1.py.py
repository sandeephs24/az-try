# Databricks notebook source
from IPython.display import display, Markdown, HTML

import pandas as pd
import numpy as np
import requests
import json

from datetime import date, datetime, timedelta
from calendar import WEDNESDAY, THURSDAY
from time import time
import getpass
from functools import partial

import plotly
import plotly.graph_objs as go
from plotly.offline import plot, iplot

%matplotlib inline

pd.set_option('display.float_format', lambda x: '%f' % x)

# COMMAND ----------

refdata_base_url = 'https://referencedata.trayport.com'
analytics_base_url = 'https://analytics.trayport.com/api'

instruments_url = refdata_base_url + '/instruments'
markets_url = refdata_base_url + '/markets'
sequences_url = refdata_base_url + '/sequences'

trades_url = analytics_base_url + '/trades'
ohlcv_url = analytics_base_url + '/trades/ohlcv'
private_url = analytics_base_url + '/trades/private'
activity_url = analytics_base_url + '/trades/activity'
book_url = analytics_base_url + '/orders/book'
book_top_url = analytics_base_url + '/orders/book/top'

# COMMAND ----------

#Create some time variables for last Wednesday (likely to be a trading day!)
#These will be used in future queries throughout the notebook

today = date.today()
MON, TUE, WED, THU, FRI, SAT, SUN = range(7)

def lastWeekday(weekday):
  #Mon = 0, Tue = 1, Sun = 6
  offset = (date.today().weekday() + 6 - weekday) % 7 + 1
  return date.today() - timedelta(days=offset)

last_sunday = lastWeekday(SUN)
last_sunday_open = last_sunday.strftime("%Y-%m-%dT00:00:00Z")
last_sunday_close = last_sunday.strftime("%Y-%m-%dT23:00:00Z")

# COMMAND ----------

#Authorization
#Requests made to the Analytics and Reference Data APIs are authorized by providing an API key in the X-API-KEY header on all requests.

#Entering your API key below will cause it to be used to authorize all requests made from this notebook. Note that if you are pasting the key you may need to use the 'Ctrl + Shift + V' shortcut to allow it to be entered as plain text.

# COMMAND ----------

api_key = getpass.getpass("Please enter your Analytics API key and then press ENTER. Note that you may need to use 'Ctrl + Shift + V' when pasting:\n")
headers = {
    'x-api-key': api_key
}

def get(url, params, headers):
  start_time = time()
  r = requests.get(url, params, headers=headers)
  duration = time() - start_time
  print(r.request.url)
  print(f'Duration: {duration:.3f}s')
  if r.status_code != 200:
    raise Exception(f'Status: {r.status_code}. {r.content.decode()}')
  return r.content

def get_obj(url, params={}, headers=headers):
  content = get(url, params, headers)
  return json.loads(content)

def get_df(url, params={}, headers=headers):
  content = get(url, params, headers)
  df = pd.read_json(content, convert_dates=['timestamp','fromTimestamp', 'toTimestamp'])
  if len(df) > 0:
    if 'timestamp' in df.columns:
      df.set_index('timestamp', inplace=True)
  return df

# COMMAND ----------

#Using the Reference Data API
#Order and trade queries in the Analytics API are specified against a specific contract or commingled market. For example, you might look for trades for NBP Apr-22.

#Contracts are specified by sending the IDs for the instruments (e.g. 10000625 for NBP ICE), the sequence (e.g. 10000305 for Months) and the item (e.g. 220 for Apr-22).

#You can use the Reference Data API to find the IDs for the contracts you wish to query with the Analytics API. The examples below show some common workflows.

# COMMAND ----------

#Finding the instrument
#Suppose that you want to issue a query for UK NGET half-hour trades. You'll need to start by finding the instrument ID. If you don't already know it, you can download a list of all available instruments using the /instruments endpoint:

# COMMAND ----------

instruments = get_df(instruments_url)
instruments

# COMMAND ----------

#This shows the name and ID of each instrument in Trayport's collection. These will match the names and IDs available in Joule and in the Joule Direct API.

#If you know the name of the instrument you're interested in, you can then find it in the list. For example, if you only want trades for the UK NGET EPEX instrument, you can search the list for it by name:

# COMMAND ----------

nget_instrument = instruments[instruments['name'] == 'UK NGET EPEX'].to_dict('records')[0]
nget_instrument

# COMMAND ----------

#Using Commingled Markets
#If you want data for multiple similar instruments (e.g. TTF EEX, TTF ICE, etc.), you can search the instrument list by name:

# COMMAND ----------

nget_instruments = instruments[instruments['name'].apply(lambda n: 'UK NGET' in n)]
nget_instruments

# COMMAND ----------

#The obvious problem with this is knowing which of these instruments can be safely grouped together - you probably don't want to incldue prices for the TTF USD instrument with the Euro-priced products, for example!

#The Reference Data API solves this problem by allowing you to query the 'Commingled' or 'All Venues' markets that you can see in Joule. For example, you may wish to use the 'TTF Hi Cal 51.6*' commingled column from Joule, which contains 18 comparable instruments:



#The /markets endpoint returns a list of all the commingled products available in Joule. You can then search this in the same way you can an instrument list:

# COMMAND ----------

markets = get_df(markets_url)
display(markets)
nget_market = markets[markets['name'] == 'UK NGET'].to_dict('records')[0]
display(nget_market)

# COMMAND ----------

#Finding the delivery period
#Delivery periods are grouped into 'Sequences' of similar items. For example, there are sequences for Gas Months, a sequence for Power Quarters, for Coal Years, etc.

#You can use the Reference Data API to retrieve a list of sequences available for individual instruments or markets:

# COMMAND ----------

get_market_sequences = get_df(refdata_base_url + nget_market['sequences'])
display(nget_market_sequences)

# COMMAND ----------


