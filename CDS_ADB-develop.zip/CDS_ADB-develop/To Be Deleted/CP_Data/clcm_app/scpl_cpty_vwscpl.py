# Databricks notebook source
# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'[scpl].[CPTY_SCPL]')
df.createOrReplaceTempView(f"scpl_CPTY_vwSCPL")

# COMMAND ----------

# MAGIC %sql
# MAGIC drop view if exists vw_scpl_cpty_vwscpl_scpl;
# MAGIC create or replace temporary view vw_scpl_cpty_vwscpl as 
# MAGIC select 
# MAGIC   CptyGroupID
# MAGIC   , CptyID
# MAGIC   , CptyName
# MAGIC   , SystemUniquePrefix
# MAGIC   , GoldTierID
# MAGIC   , GT_LegalEntity
# MAGIC   , GT_DDLevel
# MAGIC   , GT_DDLevelApproved
# MAGIC   , GT_PolicyStatus
# MAGIC   , CptyUpdatedOn
# MAGIC   , current_timestamp() as META_CREATED_DTTM
# MAGIC   , current_timestamp() as EFFECTIVE_START_DATE
# MAGIC   , '9999-12-31' as EFFECTIVE_END_DATE
# MAGIC   , 1 as IS_RECORD_ACTIVE
# MAGIC   , 'SCPL' SOURCE_SYSTEM
# MAGIC   , ErateDate
# MAGIC   , EratedFlag
# MAGIC   , DeactivatedFlag
# MAGIC   , RecordStatusID
# MAGIC   , ProjectName
# MAGIC   , DispositionDetail
# MAGIC   , ReReviewsLiveKeepsProcess
# MAGIC   , ReReviewsLiveBatch
# MAGIC from scpl_CPTY_vwSCPL;

# COMMAND ----------

df = spark.sql("select *  from vw_scpl_cpty_vwscpl")
display(df)

# COMMAND ----------

# DBTITLE 1,Loading to SQL DB Curated
# RefreshCuratedSqlTblWithDelete('pty_counterparty', 'scpl_cpty_vwscpl' , 'SCPL')
RefreshCuratedSqlTbl('pty_counterparty', 'scpl_cpty_vwscpl')

# COMMAND ----------

# DBTITLE 1,Loading to SQL DB Harmonized
## keep this cell until all the user base is moved to Curated sql DB
#df.createOrReplaceTempView("vw_scpl_cpty_vwscpl_scpl") 
#RefreshSqlDbTbl('pty_counterparty', 'scpl_cpty_vwscpl' , 'SCPL')
