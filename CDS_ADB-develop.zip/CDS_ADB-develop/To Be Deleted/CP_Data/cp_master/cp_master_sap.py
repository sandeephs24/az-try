# Databricks notebook source
# MAGIC %sql
# MAGIC Clear CACHE

# COMMAND ----------

# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

# source_system , view_prefix_name  parameters to pass to the function
create_temp_views_per_source_system('SAPHANA', 'sap')
#create_temp_views_per_source_system_saphana('SAPHANA', 'sap')

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct bukrs,butxt from sap_CA_CPDATA_STN_VEND_GRA_001
# MAGIC where bukrs in ('SJTL','SGTP','SETL','ELNG')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_sap_vendor as     --to combine vendor master data from gsap, tsap and stnsap
# MAGIC   select * from
# MAGIC   sap_CA_CPDATA_GS_VEND_GRA_001
# MAGIC   where KTOKK in ('YHMV','YVND','YJVP','YSHL')
# MAGIC   and EKORG in ('US02','US07')
# MAGIC union all
# MAGIC   select * from
# MAGIC   sap_CA_CPDATA_STN_VEND_GRA_001
# MAGIC   where KTOKK in ('ZTPY','ZGRP','ZASC','Z001','Z002','Z004')
# MAGIC union all
# MAGIC   select * from
# MAGIC   sap_CA_CPDATA_TS_VEND_GRA_001

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_sap_vendor as  --to perform output calculations for sap vendor master data
# MAGIC select distinct
# MAGIC   CA_SAP_SYSTEM as SAP_SYSTEM,
# MAGIC   concat(CA_SAP_SYSTEM, '_', CA_CPTY_TYPE, '_', ltrim('0',trim(LIFNR))) as SAP_UNIQUE_ID,
# MAGIC   /*concat(case when NAME1 is null then '' else NAME1 END,
# MAGIC   case when NAME2 is null then '' else concat(' ',NAME2) END,
# MAGIC   case when NAME3 is null then '' else concat(' ',NAME3) END,
# MAGIC   case when NAME4 is null then '' else concat(' ',NAME4) END) as SAP_NAME,*/
# MAGIC   case when NAME1 is null then NAME2
# MAGIC        when NAME2 is null then NAME1
# MAGIC        else concat(NAME1,' ',NAME2)
# MAGIC   end as SAP_NAME,
# MAGIC   NAME3 AS SAP_NAME3,
# MAGIC   NAME4 AS SAP_NAME4,
# MAGIC   ltrim('0',trim(LIFNR)) as SAP_ACCOUNT_NO,     
# MAGIC   concat_ws(',',collect_set(cast(BUKRS as string)) 
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_COMPANY_CODE,
# MAGIC   concat_ws(',',collect_set(cast(BUTXT as string))
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_COMPANY_NAME,  
# MAGIC   LAND1 as SAP_COUNTRY,
# MAGIC   LANDX as SAP_COUNTRY_NAME,
# MAGIC   REGIO as SAP_REGION,
# MAGIC   ORT01 as SAP_CITY,
# MAGIC   STRAS as SAP_ADDRESS,
# MAGIC   PSTLZ as SAP_POSTCODE,
# MAGIC   to_date(CA_ERDAT) as SAP_CREATE_DATE,
# MAGIC   LOEVM as SAP_DEACTIVATED,
# MAGIC   SPERR as SAP_BLOCK_POSTING,
# MAGIC   SPERZ as SAP_BLOCK_PAYMENT,
# MAGIC   SPERM as SAP_BLOCK_PURCHASE,
# MAGIC   concat_ws(',',collect_set(cast(KTOKK as string)) 
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_ACCOUNT_GROUP,
# MAGIC   '' as SAP_SALES_ORG,
# MAGIC   '' as SAP_SALES_ORG_NAME,
# MAGIC   '' as SAP_DISTRIBUTION_CHANNEL,
# MAGIC   '' as SAP_DISTRIBUTION_CHANNEL_NAME,
# MAGIC   '' as SAP_DIVISION,
# MAGIC   '' as SAP_DIVISION_NAME,
# MAGIC   BRSCH as SAP_INDUSTRY_KEY,
# MAGIC   BRTXT as SAP_INDUSTRY_KEY_NAME,
# MAGIC   concat_ws(',',collect_set(cast(EKORG as string)) 
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_PURCHASE_ORG,  
# MAGIC   concat_ws(',',collect_set(cast(EKOTX as string)) 
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_PURCHASE_ORG_NAME,
# MAGIC   concat_ws(',',collect_set(cast(ZAHLS as string)) 
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_PAYMENT_BLOCK,
# MAGIC   concat_ws(',',collect_set(cast(TEXTL as string)) 
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_PAYMENT_BLOCK_REASON,
# MAGIC   to_date(CA_UPDAT) as SAP_CHANGE_DATE,
# MAGIC   META_CREATED_DTTM,
# MAGIC   'SAP_HANA' as SOURCE_SYSTEM
# MAGIC from
# MAGIC vw_sap_vendor

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), count(distinct SAP_ACCOUNT_NO||SAP_SYSTEM) from vw_cp_master_sap_vendor 

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_sap_tsap_stn_customer as    --to combine customer master data from gsap, tsap and stnsap
# MAGIC   select 
# MAGIC   BRSCH,
# MAGIC   BRTXT,
# MAGIC   BUKR as BUKRS,
# MAGIC   BUTXT,
# MAGIC   CA_CPTY_TYPE,
# MAGIC   CA_ERDAT,
# MAGIC   CA_SAP_SYSTEM,
# MAGIC   CA_UPDAT,
# MAGIC   KTOKD,
# MAGIC   KUNNR,
# MAGIC   LAND1,
# MAGIC   LANDX,
# MAGIC   LOEVM,
# MAGIC   NAME1,
# MAGIC   NAME2,
# MAGIC   NAME3,
# MAGIC   NAME4,
# MAGIC   ORT01,
# MAGIC   PSTLZ,
# MAGIC   REGIO,
# MAGIC   SPART,
# MAGIC   SPART_VTEXT,
# MAGIC   SPERR,
# MAGIC   SPERZ,
# MAGIC   STRAS,
# MAGIC   TEXTL,
# MAGIC   VKORG,
# MAGIC   VKORG_VTEXT,
# MAGIC   VTWEG,
# MAGIC   VTWEG_VTEXT,
# MAGIC   ZAHLS,
# MAGIC   META_CREATED_DTTM from
# MAGIC   sap_CA_CPDATA_GS_CUST_GRA_001
# MAGIC   where KTOKD in ('YSTP','KUNA','YGPY','YPAY','YBTP','YDTP')
# MAGIC   and substr(KUNNR,1,1) not in ('Y','J')
# MAGIC   and VKORG in ('US16','USN6','MX01')
# MAGIC   and VTWEG in ('06','07')
# MAGIC union all
# MAGIC   select 
# MAGIC   BRSCH,
# MAGIC   BRTXT,
# MAGIC   BUKRS,
# MAGIC   BUTXT,
# MAGIC   CA_CPTY_TYPE,
# MAGIC   CA_ERDAT,
# MAGIC   CA_SAP_SYSTEM,
# MAGIC   CA_UPDAT,
# MAGIC   KTOKD,
# MAGIC   KUNNR,
# MAGIC   LAND1,
# MAGIC   LANDX,
# MAGIC   LOEVM,
# MAGIC   NAME1,
# MAGIC   NAME2,
# MAGIC   NAME3,
# MAGIC   NAME4,
# MAGIC   ORT01,
# MAGIC   PSTLZ,
# MAGIC   REGIO,
# MAGIC   '' as SPART,
# MAGIC   '' as SPART_VTEXT,
# MAGIC   SPERR,
# MAGIC   SPERZ,
# MAGIC   STRAS,
# MAGIC   TEXTL,
# MAGIC   '' as VKORG,
# MAGIC   '' as VKORG_VTEXT,
# MAGIC   '' as VTWEG,
# MAGIC   '' as VTWEG_VTEXT,
# MAGIC   ZAHLS,
# MAGIC   META_CREATED_DTTM from
# MAGIC   sap_CA_CPDATA_STN_CUST_GRA_001
# MAGIC   where KTOKD in ('ZTPY','ZGRP','ZASC','0004','Z001','Z002','Z004')
# MAGIC union all
# MAGIC   select 
# MAGIC   BRSCH,
# MAGIC   BRTXT,
# MAGIC   BUKRS,
# MAGIC   BUTXT,
# MAGIC   CA_CPTY_TYPE,
# MAGIC   CA_ERDAT,
# MAGIC   CA_SAP_SYSTEM,
# MAGIC   CA_UPDAT,
# MAGIC   KTOKD,
# MAGIC   KUNNR,
# MAGIC   LAND1,
# MAGIC   LANDX,
# MAGIC   LOEVM,
# MAGIC   NAME1,
# MAGIC   NAME2,
# MAGIC   NAME3,
# MAGIC   NAME4,
# MAGIC   ORT01,
# MAGIC   PSTLZ,
# MAGIC   REGIO,
# MAGIC   '' as SPART,
# MAGIC   '' as SPART_VTEXT,
# MAGIC   SPERR,
# MAGIC   SPERZ,
# MAGIC   STRAS,
# MAGIC   TEXTL,
# MAGIC   '' as VKORG,
# MAGIC   '' as VKORG_VTEXT,
# MAGIC   '' as VTWEG,
# MAGIC   '' as VTWEG_VTEXT,
# MAGIC   ZAHLS,
# MAGIC   META_CREATED_DTTM from
# MAGIC   sap_CA_CPDATA_TS_CUST_GRA_001

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_sap_customer as      --to perform output calculations for sap vendor master data
# MAGIC select distinct
# MAGIC   CA_SAP_SYSTEM as SAP_SYSTEM,
# MAGIC   concat(CA_SAP_SYSTEM, '_', CA_CPTY_TYPE, '_', ltrim('0',trim(KUNNR))) as SAP_UNIQUE_ID,
# MAGIC   /*concat(case when NAME1 is null then '' else NAME1 END,
# MAGIC   case when NAME2 is null then '' else concat(' ',NAME2) END,
# MAGIC   case when NAME3 is null then '' else concat(' ',NAME3) END,
# MAGIC   case when NAME4 is null then '' else concat(' ',NAME4) END) as SAP_NAME,*/
# MAGIC   case when NAME1 is null then NAME2
# MAGIC        when NAME2 is null then NAME1
# MAGIC        else concat(NAME1,' ',NAME2)
# MAGIC   end as SAP_NAME,
# MAGIC   NAME3 AS SAP_NAME3,
# MAGIC   NAME4 AS SAP_NAME4,
# MAGIC   ltrim('0',trim(KUNNR)) as SAP_ACCOUNT_NO,    
# MAGIC   concat_ws(',',collect_set(cast(BUKRS as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_COMPANY_CODE,
# MAGIC   concat_ws(',',collect_set(cast(BUTXT as string))
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_COMPANY_NAME,  
# MAGIC   LAND1 as SAP_COUNTRY,
# MAGIC   LANDX as SAP_COUNTRY_NAME,
# MAGIC   REGIO as SAP_REGION,
# MAGIC   ORT01 as SAP_CITY,
# MAGIC   STRAS as SAP_ADDRESS,
# MAGIC   PSTLZ as SAP_POSTCODE,
# MAGIC   to_date(CA_ERDAT) as SAP_CREATE_DATE,
# MAGIC   LOEVM as SAP_DEACTIVATED,
# MAGIC   SPERR as SAP_BLOCK_POSTING,
# MAGIC   SPERZ as SAP_BLOCK_PAYMENT,
# MAGIC   '' as SAP_BLOCK_PURCHASE,
# MAGIC   concat_ws(',',collect_set(cast(KTOKD as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_ACCOUNT_GROUP,
# MAGIC   concat_ws(',',collect_set(cast(VKORG as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_SALES_ORG,
# MAGIC   concat_ws(',',collect_set(cast(VKORG_VTEXT as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_SALES_ORG_NAME,
# MAGIC   concat_ws(',',collect_set(cast(VTWEG as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_DISTRIBUTION_CHANNEL,
# MAGIC   concat_ws(',',collect_set(cast(VTWEG_VTEXT as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_DISTRIBUTION_CHANNEL_NAME,
# MAGIC   concat_ws(',',collect_set(cast(SPART as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_DIVISION,
# MAGIC   concat_ws(',',collect_set(cast(SPART_VTEXT as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_DIVISION_NAME,
# MAGIC   BRSCH as SAP_INDUSTRY_KEY,
# MAGIC   BRTXT as SAP_INDUSTRY_KEY_NAME,
# MAGIC   '' as SAP_PURCHASE_ORG,  
# MAGIC   '' as SAP_PURCHASE_ORG_NAME,
# MAGIC   concat_ws(',',collect_set(cast(ZAHLS as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_PAYMENT_BLOCK,
# MAGIC   concat_ws(',',collect_set(cast(TEXTL as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_PAYMENT_BLOCK_REASON,
# MAGIC   to_date(CA_UPDAT) as SAP_CHANGE_DATE,
# MAGIC   META_CREATED_DTTM,
# MAGIC   'SAP_HANA' as SOURCE_SYSTEM
# MAGIC from
# MAGIC vw_sap_tsap_stn_customer

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*),count(distinct SAP_ACCOUNT_NO,SAP_SYSTEM) from vw_cp_master_sap_customer 

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct zahls,textl from sap_CA_CPDATA_STN_CUST_GRA_001
# MAGIC --where kunnr = '0000010227'

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_sap_master as
# MAGIC   select * from vw_cp_master_sap_vendor
# MAGIC   union all
# MAGIC   select * from vw_cp_master_sap_customer

# COMMAND ----------

df = spark.sql("select * from vw_cp_sap_master")
df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_sap_master')
