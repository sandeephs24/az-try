# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

create_temp_views_per_source_system('GMAS', 'GMAS')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC create or replace temporary view GMAS_Asset as
# MAGIC 
# MAGIC select * from GMAS_ASSET_CARGO
# MAGIC union 
# MAGIC select * from GMAS_ASSET_LOCATION
# MAGIC union 
# MAGIC select * from GMAS_ASSET_ORGANISATION
# MAGIC union 
# MAGIC select * from GMAS_ASSET_PERSON
# MAGIC union 
# MAGIC select * from GMAS_ASSET_VESSEL
# MAGIC union 
# MAGIC select * from GMAS_ASSET_PORT
# MAGIC   

# COMMAND ----------

# MAGIC %sql
# MAGIC --select distinct active_status from GMAS_ORGANISATION limit 10
# MAGIC select  org.*
# MAGIC FROM 
# MAGIC     GMAS_Organisation org 
# MAGIC     LEFT JOIN GMAS_Party_Role pr ON org.organisation_id = pr.party_id
# MAGIC     LEFT JOIN GMAS_Address_usage au ON pr.party_role_id = au.party_role_id
# MAGIC     LEFT JOIN GMAS_Address ad ON au.address_id = ad.address_id  
# MAGIC     LEFT JOIN GMAS_Asset a ON ad.country_id = a.asset_id
# MAGIC     LEFT JOIN GMAS_party_role_type prt ON pr.party_role_type_id = prt.party_role_type_id
# MAGIC WHERE 
# MAGIC     prt.party_role_type_code NOT IN ('ORGANISATION_MAIN', 'PERSON_MAIN') limit 10

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_SAP_Code_unq_vendon_customer as
# MAGIC 
# MAGIC ( with SAP_Code_unq as 
# MAGIC   (
# MAGIC   select distinct SAP_CODE from GMAS_Party_Role
# MAGIC   ),
# MAGIC   Cust_Vendor as 
# MAGIC   (
# MAGIC   select 'Vendor' as SAP_ACCOUNT_TYPE
# MAGIC   union 
# MAGIC   select 'Customer' as SAP_ACCOUNT_TYPE
# MAGIC   )
# MAGIC   
# MAGIC   select * from SAP_Code_unq join Cust_Vendor on 1 = 1
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_gmas_temp as -- view without Req 38 and Req 97
# MAGIC SELECT 
# MAGIC       
# MAGIC       org.ORGANISATION_FULL_NAME                                                         as NAME
# MAGIC     , 'GMAS_' || cast(org.ORGANISATION_ID as int)                                        as UNIQUE_ID
# MAGIC     , cast(cast(org.ORGANISATION_ID as int)  as string)                                  as L2_ID
# MAGIC     , CASE when org.ACTIVE_STATUS = 'Active' Then 'N' else 'Y' end                       as DEACTIVATED
# MAGIC     , cast(org.CREATED_DT  as timestamp)                                                 as CREATED_DATE
# MAGIC     , cast(org.LAST_UPDATED_DT  as timestamp)                                            as UPDATED_DATE
# MAGIC     , trim(pr.SAP_CODE)                                                                        as SAP_ACCOUNT_NO
# MAGIC     , 'GMAS'                                                                             as SOURCE_SYSTEM
# MAGIC     , trim(a.asset_name)                                                                       as COUNTRY
# MAGIC     , 'STNSAP'                                                                           as SAP_SYSTEM
# MAGIC    -- , a.asset_active_status
# MAGIC     , prt.PARTY_ROLE_TYPE_DESC                                                           as COUNTERPARTY_TYPE
# MAGIC     , org.ORGANISATION_SHORT_NAME                                                        as CP_SHORT_NAME
# MAGIC     
# MAGIC FROM 
# MAGIC     GMAS_Organisation org 
# MAGIC     LEFT JOIN GMAS_Party_Role pr ON org.organisation_id = pr.party_id
# MAGIC     LEFT JOIN GMAS_Address_usage au ON pr.party_role_id = au.party_role_id
# MAGIC     LEFT JOIN GMAS_Address ad ON au.address_id = ad.address_id  
# MAGIC     LEFT JOIN GMAS_Asset a ON ad.country_id = a.asset_id
# MAGIC     LEFT JOIN GMAS_party_role_type prt ON pr.party_role_type_id = prt.party_role_type_id
# MAGIC WHERE 
# MAGIC     prt.party_role_type_code NOT IN ('ORGANISATION_MAIN', 'PERSON_MAIN')
# MAGIC ORDER BY org.organisation_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_gmas as
# MAGIC Select
# MAGIC   
# MAGIC   gm.UNIQUE_ID,
# MAGIC   gm.NAME,
# MAGIC   gm.DEACTIVATED,
# MAGIC   gm.L2_ID,
# MAGIC   gm.COUNTRY,
# MAGIC   gm.SAP_SYSTEM,
# MAGIC   gm.UPDATED_DATE,
# MAGIC   gm.CREATED_DATE,
# MAGIC   
# MAGIC   gm.SAP_ACCOUNT_NO,
# MAGIC   vc.SAP_ACCOUNT_TYPE,
# MAGIC   case
# MAGIC     when trim(SAP_ACCOUNT_NO) = ''
# MAGIC     or SAP_ACCOUNT_NO is null then null
# MAGIC     else gm.SAP_SYSTEM || '_' || vc.SAP_ACCOUNT_TYPE || '_' || gm.SAP_ACCOUNT_NO
# MAGIC   end as SAP_UNIQUE_ID,
# MAGIC  
# MAGIC   gm.SOURCE_SYSTEM,
# MAGIC   current_timestamp as META_CREATED_DTTM,
# MAGIC   gm.COUNTERPARTY_TYPE,
# MAGIC   gm.CP_SHORT_NAME
# MAGIC FROM
# MAGIC   (select distinct * from vw_gmas_temp) gm
# MAGIC   left join vw_SAP_Code_unq_vendon_customer vc on gm.SAP_ACCOUNT_NO = vc.SAP_CODE

# COMMAND ----------

df_final = spark.sql("select * from vw_cp_master_gmas")
df_final.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master_gmas')

# COMMAND ----------

from pyspark.sql.functions import regexp_replace as r
df_country = df_final.withColumn('COUNTRY',when(df_final.COUNTRY.contains('Unknown'),None).otherwise(df_final.COUNTRY)).groupby('UNIQUE_ID').agg((collect_set(col('COUNTRY'))).alias('Country')).select(col('UNIQUE_ID'),concat_ws(",",col('COUNTRY')).alias('COUNTRY_C'))
df = df_final.join(df_country,on='UNIQUE_ID',how='Inner')


# COMMAND ----------

from pyspark.sql.types import StringType, TimestampType
df_cp_master = df.select(col('UNIQUE_ID').alias('cp_unique_id'),                                                   #REQ-26
                         lit(None).cast(StringType()).alias('cp_l1_id'),                           #REQ-28
                         col('NAME').alias('cp_name'),                          #REQ-27
                         col('L2_ID').alias('cp_etrm_account_no'),                                       #--------
                         col('L2_ID').alias('cp_l2_id'),                          #REQ-29
                         col('NAME').alias('cp_l2_name'),                      #REQ-30
                         col('COUNTERPARTY_TYPE').alias('cp_entity_type'),   #REQ-31
                        # expr("case when CREATED_DATE is   \
                        #     Null then UPDATED_DATE else CREATED_DATE end").cast(TimestampType())\
                        # .alias('cp_created_or_updated_date'),                                  #REQ-33/34 -------
                         expr("case when CREATED_DATE is null and UPDATED_DATE is not null then UPDATED_DATE \
                          when UPDATED_DATE is null and CREATED_DATE is not null then CREATED_DATE \
                          when CREATED_DATE>=UPDATED_DATE then CREATED_DATE \
                          when UPDATED_DATE>CREATED_DATE then UPDATED_DATE else NULL \
                          end").cast(TimestampType()).alias('cp_created_or_updated_date'),
                         col('DEACTIVATED').alias('cp_deactivated'),                   #REQ-32
                         col('COUNTRY_C').alias('cp_country'),                                    #REQ-91
                         lit(None).cast(StringType()).alias('cp_parent'),                       #REQ-87
                         col('SOURCE_SYSTEM').alias('cp_system'),                                      #REQ-36
                         col('SAP_ACCOUNT_NO').alias('cp_linked_sap_id'),                       #REQ-35
                         col('SAP_ACCOUNT_TYPE').alias('cp_sap_account_type'),                  #REQ-38
                         col('SAP_UNIQUE_ID').alias('cp_sap_unique_id'),                        #REQ-97
                         col('SAP_SYSTEM').alias('cp_linked_sap_system'),                       #REQ-93
                         expr("case when SAP_UNIQUE_ID is   \
                              Null or SAP_UNIQUE_ID = '' then 'NO SAP LINK' else 'SAP LINK' end")\
                         .alias('cp_sap_link'),
                         lit(None).cast(StringType()).alias('cp_erate_flag_in_source'),                    #REQ-9
                         lit(None).cast(TimestampType()).alias('cp_erate_date_in_source'),                    #REQ-10
                         lit(None).cast(TimestampType()).alias('cp_erate_lifted_date_in_source'),   #REQ-11
                         lit(None).cast(StringType()).alias('cp_broker_indicator'),             #REQ-86
                         col('L2_ID').alias('cp_mapping_id'),
                         col('SOURCE_SYSTEM'),
                         col('meta_created_dttm'),
                         col('CP_SHORT_NAME').alias('cp_short_name')
                        ).distinct()

# COMMAND ----------

df_cp_master.createOrReplaceTempView(f"vw_cp_master")

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master', 'GMAS')
