# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

curated_schema_name= 'ENDUR' 
curated_tables_list = ['ENDNA_CRUDE_ACTIVITY']
for table_name in curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")

# COMMAND ----------

# MAGIC %sql
# MAGIC --To get separate records where SAP Account No. is for Customer
# MAGIC create or replace temporary view vw_cp_master_crude_customer as 
# MAGIC select distinct system,
# MAGIC cpty_id as cp_unique_id,
# MAGIC cpty_bunit_id as cp_business_unit_id,
# MAGIC cpty_legal_entity_id  as cp_legal_entity_id,
# MAGIC cpty_legal_entity_long_name as cp_legal_entity_name,
# MAGIC cpty_legal_name as cpty_legal_name,  ---change back to the cpty_legal_name mapping to cp_name, according Brindha on 4/29 , Changed by RK
# MAGIC case when length(trim(cpty_bunit_short_name)) >0 then cpty_bunit_short_name
# MAGIC when length(trim(cpty_bunit_short_name)) = 0 then cpty_bunit_long_name
# MAGIC when length(trim(cpty_bunit_long_name)) = 0 then cpty_legal_entity_short_name
# MAGIC end as cp_short_name,
# MAGIC case when cpty_deactivated_flag = 'Y' 
# MAGIC   then 'Y' else 'N' 
# MAGIC end as cp_deactivation_flag,
# MAGIC cpty_sap_customer_no as sap_account_no,
# MAGIC 'Customer' as sap_account_type,
# MAGIC concat('TSAP_Customer_',cpty_sap_customer_no) as sap_unique_id,
# MAGIC 'TSAP' as linked_sap_system,
# MAGIC concat(
# MAGIC (
# MAGIC   case when cpty_entity_type='Internal' 
# MAGIC     then 'INT'
# MAGIC   when cpty_entity_type='External' 
# MAGIC    then 'EXT' else 'UNKNOWN' end
# MAGIC ), '_BU',
# MAGIC (
# MAGIC   case when trim(right(replace(replace(trim(cpty_bunit_short_name),'-',' '),'_',' '),4)) in ('CRD','EXCH','LSE','MAR','NOC','OPR','PRD','RSK','TRSP') 
# MAGIC     then concat('_',trim(right(replace(replace(trim(cpty_bunit_short_name),'-',' '),'_',' '),4)))
# MAGIC   else '' end
# MAGIC )
# MAGIC ) as cp_entity_type,
# MAGIC --cpty_bunit_long_name  as cp_business_unit_name,
# MAGIC cpty_legal_name as cp_business_unit_name,
# MAGIC cpty_erated_flag as erate_flag,
# MAGIC cast(cpty_create_date as Timestamp) as cp_create_date,
# MAGIC cast(cpty_update_date as Timestamp) as cp_last_update_date,
# MAGIC 'ENDUR_CRUDE' as source_system,
# MAGIC current_timestamp as meta_created_dttm
# MAGIC from vw_ENDUR_ENDNA_CRUDE_ACTIVITY
# MAGIC where cpty_sap_customer_no is not null;

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_crude_customer")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC --To get separate records where SAP Account No. is for Vendor
# MAGIC create or replace temporary view vw_cp_master_crude_vendor as 
# MAGIC select distinct system,
# MAGIC cpty_id as cp_unique_id,
# MAGIC cpty_bunit_id as cp_business_unit_id,
# MAGIC cpty_legal_entity_id  as cp_legal_entity_id,
# MAGIC cpty_legal_entity_long_name as cp_legal_entity_name,
# MAGIC cpty_legal_name as cpty_legal_name, ---change back to the cpty_legal_name mapping to cp_name, according Brindha on 4/29 , Changed by RK
# MAGIC case when length(trim(cpty_bunit_short_name)) >0 then cpty_bunit_short_name
# MAGIC when length(trim(cpty_bunit_short_name)) = 0 then cpty_bunit_long_name
# MAGIC when length(trim(cpty_bunit_long_name)) = 0 then cpty_legal_entity_short_name
# MAGIC end as cp_short_name,
# MAGIC case when cpty_deactivated_flag = 'Y' 
# MAGIC   then 'Y' else 'N' 
# MAGIC end as cp_deactivation_flag,
# MAGIC cpty_sap_vendor_no as sap_account_no,
# MAGIC 'Vendor' as sap_account_type,
# MAGIC concat('TSAP_Vendor_',cpty_sap_vendor_no) as sap_unique_id,
# MAGIC 'TSAP' as linked_sap_system,
# MAGIC concat(
# MAGIC (
# MAGIC   case when cpty_entity_type='Internal' 
# MAGIC     then 'INT'
# MAGIC   when cpty_entity_type='External' 
# MAGIC    then 'EXT' else 'UNKNOWN' end
# MAGIC ), '_BU',
# MAGIC (
# MAGIC   case when trim(right(replace(replace(trim(cpty_bunit_short_name),'-',' '),'_',' '),4)) in ('CRD','EXCH','LSE','MAR','NOC','OPR','PRD','RSK','TRSP') 
# MAGIC     then concat('_',trim(right(replace(replace(trim(cpty_bunit_short_name),'-',' '),'_',' '),4)))
# MAGIC   else '' end
# MAGIC )
# MAGIC ) as cp_entity_type,
# MAGIC --cpty_bunit_long_name  as cp_business_unit_name,
# MAGIC cpty_legal_name as cp_business_unit_name,
# MAGIC cpty_erated_flag as erate_flag,
# MAGIC cast(cpty_create_date as Timestamp) as cp_create_date,
# MAGIC cast(cpty_update_date as Timestamp) as cp_last_update_date,
# MAGIC 'ENDUR_CRUDE' as source_system,
# MAGIC current_timestamp as meta_created_dttm
# MAGIC from vw_ENDUR_ENDNA_CRUDE_ACTIVITY
# MAGIC where cpty_sap_vendor_no is not null;

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_crude_vendor")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC --To get separate records where SAP Account No. is for blank
# MAGIC create or replace temporary view vw_cp_master_crude as 
# MAGIC select distinct system,
# MAGIC cpty_id as cp_unique_id,
# MAGIC cpty_bunit_id as cp_business_unit_id,
# MAGIC cpty_legal_entity_id  as cp_legal_entity_id,
# MAGIC cpty_legal_entity_long_name as cp_legal_entity_name,
# MAGIC cpty_legal_name as cpty_legal_name,  ---change back to the cpty_legal_name mapping to cp_name, according Brindha on 4/29 , Changed by RK
# MAGIC case when length(trim(cpty_bunit_short_name)) >0 then cpty_bunit_short_name
# MAGIC when length(trim(cpty_bunit_short_name)) = 0 then cpty_bunit_long_name
# MAGIC when length(trim(cpty_bunit_long_name)) = 0 then cpty_legal_entity_short_name
# MAGIC end as cp_short_name,
# MAGIC case when cpty_deactivated_flag = 'Y' 
# MAGIC   then 'Y' else 'N' 
# MAGIC end as cp_deactivation_flag,
# MAGIC '' as sap_account_no,
# MAGIC '' as sap_account_type,
# MAGIC '' as sap_unique_id,
# MAGIC '' as linked_sap_system,
# MAGIC concat(
# MAGIC (
# MAGIC   case when cpty_entity_type='Internal' 
# MAGIC     then 'INT'
# MAGIC   when cpty_entity_type='External' 
# MAGIC    then 'EXT' else 'UNKNOWN' end
# MAGIC ), '_BU',
# MAGIC (
# MAGIC   case when trim(right(replace(replace(trim(cpty_bunit_short_name),'-',' '),'_',' '),4)) in ('CRD','EXCH','LSE','MAR','NOC','OPR','PRD','RSK','TRSP') 
# MAGIC     then concat('_',trim(right(replace(replace(trim(cpty_bunit_short_name),'-',' '),'_',' '),4)))
# MAGIC   else '' end
# MAGIC )
# MAGIC ) as cp_entity_type,
# MAGIC --cpty_bunit_long_name  as cp_business_unit_name,
# MAGIC cpty_legal_name as cp_business_unit_name,
# MAGIC cpty_erated_flag as erate_flag,
# MAGIC cast(cpty_create_date as Timestamp) as cp_create_date,
# MAGIC cast(cpty_update_date as Timestamp) as cp_last_update_date,
# MAGIC 'ENDUR_CRUDE' as source_system,
# MAGIC current_timestamp as meta_created_dttm
# MAGIC from vw_ENDUR_ENDNA_CRUDE_ACTIVITY
# MAGIC where cpty_sap_customer_no is null and cpty_sap_vendor_no is null;

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_crude")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_endur_crude as 
# MAGIC select * from vw_cp_master_crude_customer
# MAGIC union all
# MAGIC select * from vw_cp_master_crude_vendor
# MAGIC union all
# MAGIC select * from vw_cp_master_crude

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_endur_crude")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_cp_master_endur_crude
# MAGIC where cp_legal_entity_name is null or cp_legal_entity_name = ''

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master_endur_crude')

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from vw_ENDUR_ENDNA_CRUDE_ACTIVITY

# COMMAND ----------

# df_cp_master = df.select(col('cp_unique_id'),                                                   #REQ-26
#                          col('cp_legal_entity_id').alias('cp_l1_id'),                           #REQ-28
#                          col('cpty_legal_name').alias('cp_name'),                          #REQ-27
#                          col('cp_legal_entity_id').alias('cp_etrm_account_no'),
#                          col('cp_business_unit_id').alias('cp_l2_id'),                          #REQ-29
#                          col('cp_business_unit_name').alias('cp_l2_name'),                      #REQ-30
#                          col('cp_entity_type'),                                                 #REQ-31
#                          expr("case when cp_create_date is   \
#                               Null then cp_last_update_date else cp_create_date end").cast(TimestampType())\
#                          .alias('cp_created_or_updated_date'),                                  #REQ-33/34
#                          col('cp_deactivation_flag').alias('cp_deactivated'),                   #REQ-32
#                          lit(None).cast(StringType()).alias('cp_country'),                      #REQ-91
#                          lit(None).cast(StringType()).alias('cp_parent'),                       #REQ-87
#                          col('system').alias('cp_system'),                                      #REQ-36
#                          col('sap_account_no').alias('cp_linked_sap_id'),                       #REQ-35
#                          col('sap_account_type').alias('cp_sap_account_type'),                  #REQ-38
#                          col('sap_unique_id').alias('cp_sap_unique_id'),                        #REQ-97
#                          col('linked_sap_system').alias('cp_linked_sap_system'),                #REQ-93
#                          expr("case when sap_unique_id is   \
#                               Null or sap_unique_id = '' then 'NO SAP LINK' else 'SAP LINK' end")\
#                          .alias('cp_sap_link'),
#                          col('erate_flag').alias('cp_erate_flag_in_source'),                    #REQ-9
#                          lit(None).cast(TimestampType()).alias('cp_erate_date_in_source'),      #REQ-10
#                          lit(None).cast(TimestampType()).alias('cp_erate_lifted_date_in_source'),   #REQ-11
#                          lit(None).cast(StringType()).alias('cp_broker_indicator'),             #REQ-86
#                          col('cp_unique_id').alias('cp_mapping_id'),
#                          col('source_system'),
#                          col('meta_created_dttm')
                        
                        
#                         )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master as 
# MAGIC select distinct
# MAGIC        cpc.cp_unique_id             as cp_unique_id   --REQ-26
# MAGIC       ,cpc.cp_legal_entity_id       as cp_l1_id       --REQ-28
# MAGIC       ,cpc.cpty_legal_name          as cp_name        --REQ-27
# MAGIC       ,cpc.cp_legal_entity_id       as cp_etrm_account_no 
# MAGIC       ,cpc.cp_business_unit_id      as cp_l2_id       --REQ-29
# MAGIC       ,case when length(trim(crd.cpty_bunit_short_name)) > 0  then crd.cpty_bunit_short_name 
# MAGIC             when length(trim(crd.cpty_bunit_short_name)) = 0 then cpc.cp_business_unit_name
# MAGIC             when length(trim(cpc.cp_business_unit_name)) = 0 then crd.cpty_legal_entity_short_name
# MAGIC         end                          as cp_l2_name
# MAGIC        ,case when length(trim(crd.cpty_bunit_short_name)) > 0  then crd.cpty_bunit_short_name 
# MAGIC           when length(trim(crd.cpty_bunit_short_name)) = 0 then cpc.cp_business_unit_name
# MAGIC           when length(trim(cpc.cp_business_unit_name)) = 0 then crd.cpty_legal_entity_short_name
# MAGIC         end                          as cp_short_name
# MAGIC       ,cpc.cp_entity_type            as cp_entity_type  --  REQ-31
# MAGIC       ,case when cpc.cp_create_date  is null and cp_last_update_date is not null then cast(cp_last_update_date as timestamp) 
# MAGIC             when cp_last_update_date is null and cpc.cp_create_date  is not null then cast(cpc.cp_create_date as timestamp) 
# MAGIC             when cpc.cp_create_date>=cp_last_update_date                         then cast(cpc.cp_create_date as timestamp) 
# MAGIC             when cp_last_update_date>cpc.cp_create_date                          then cast(cp_last_update_date as timestamp) 
# MAGIC         else NULL 
# MAGIC         end                          as cp_created_or_updated_date            
# MAGIC       ,cpc.cp_deactivation_flag      as cp_deactivated                   --REQ-32
# MAGIC       ,cast(null as string)          as cp_country                       --REQ-91
# MAGIC       ,cast(null as string)          as cp_parent                        --REQ-87
# MAGIC       ,cpc.system                    as cp_system                        --REQ-36
# MAGIC       ,cpc.sap_account_no            as cp_linked_sap_id                 --REQ-35
# MAGIC       ,cpc.sap_account_type          as cp_sap_account_type              --REQ-38
# MAGIC       ,cpc.sap_unique_id             as cp_sap_unique_id                 --REQ-97
# MAGIC       ,cpc.linked_sap_system         as cp_linked_sap_system             --REQ-93
# MAGIC       ,case when cpc.sap_unique_id is null or sap_unique_id = '' then 'NO SAP LINK' else 'SAP LINK' end cp_sap_link
# MAGIC       ,cpc.erate_flag                as cp_erate_flag_in_source           --REQ-9
# MAGIC       ,cast(null as timestamp)       as cp_erate_date_in_source           --REQ-10
# MAGIC       ,cast(null as timestamp)       as cp_erate_lifted_date_in_source    --REQ-11
# MAGIC       ,cast(null as string)          as cp_broker_indicator               --REQ-86
# MAGIC       ,cpc.cp_unique_id              as cp_mapping_id                   
# MAGIC       ,cpc.source_system             as source_system
# MAGIC       ,cpc.meta_created_dttm         as meta_created_dttm
# MAGIC       
# MAGIC from vw_cp_master_endur_crude      cpc
# MAGIC join vw_ENDUR_ENDNA_CRUDE_ACTIVITY crd on cpc.cp_unique_id = crd.cpty_id
# MAGIC --where cpc.cp_unique_id = 'ENDNA_CRUDE_31174_31173'

# COMMAND ----------

# df_cp_master.createOrReplaceTempView(f"vw_cp_master")
# df_cp_master.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master', 'ENDUR_CRUDE')
