# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

curated_schema_name= 'IMOS' 
curated_tables_list = ['IMOS_COUNTERPARTY','IMOS_TRANSACTION_DETAILS']
for table_name in curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_IMOS_IMOS_COUNTERPARTY_CPTY as 
# MAGIC select
# MAGIC 'IMOS' as SYSTEM,
# MAGIC 'IMOS_' || Short_Name as UNIQUE_ID,
# MAGIC Full_Name as NAME,
# MAGIC case 
# MAGIC when Type = 'A' then 'Agents'
# MAGIC when Type = 'B' then 'Brokers'
# MAGIC when Type = 'C' then 'Charterers'
# MAGIC when Type = 'F' then 'Bunker Vendors'
# MAGIC when Type = 'M' then 'Misc'
# MAGIC when Type = 'N' then 'Banks'
# MAGIC when Type = 'O' then 'Owners'
# MAGIC when Type = 'P' then 'Port services supplier'
# MAGIC when Type = 'Q' then 'Port/Terminal operator'
# MAGIC when Type = 'R' then 'Receiver'
# MAGIC when Type = 'S' then 'Shipper'
# MAGIC when Type = 'W' then 'Company Info'
# MAGIC when Type = 'X' then 'System used'
# MAGIC end as ENTITY_TYPE,
# MAGIC case when Inactive = 'True' then 'Y' else 'N' end as DEACTIVATED,
# MAGIC Short_Name as L1_ID,
# MAGIC Country as COUNTRY,
# MAGIC 'STNSAP' as SAP_SYSTEM,
# MAGIC Credit_Rating as CREDIT_RATING,
# MAGIC Last_Transaction_Date as Last_Transaction_Date,
# MAGIC Type as Type,
# MAGIC AP_Account,
# MAGIC AR_Account,
# MAGIC Type_Descr,
# MAGIC Last_Update_Gmt,
# MAGIC Last_User_ID,
# MAGIC Rating_Date
# MAGIC from vw_IMOS_IMOS_COUNTERPARTY 

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_IMOS_IMOS_COUNTERPARTY_ACCOUNTS as 
# MAGIC select
# MAGIC cpty1.*, 'Customer' as SAP_CPTY_TYPE
# MAGIC from vw_IMOS_IMOS_COUNTERPARTY_CPTY cpty1
# MAGIC UNION
# MAGIC select
# MAGIC cpty2.*, 'Vendor' as SAP_CPTY_TYPE
# MAGIC from vw_IMOS_IMOS_COUNTERPARTY_CPTY cpty2

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_IMOS_IMOS_COUNTERPARTY_UNIQUE as 
# MAGIC select
# MAGIC SYSTEM,
# MAGIC UNIQUE_ID,
# MAGIC NAME,
# MAGIC ENTITY_TYPE,
# MAGIC DEACTIVATED,
# MAGIC L1_ID,
# MAGIC COUNTRY,
# MAGIC SAP_SYSTEM,
# MAGIC case
# MAGIC when SAP_CPTY_TYPE = 'Vendor'   then AP_Account
# MAGIC when SAP_CPTY_TYPE = 'Customer' then AR_Account end as SAP_ACCOUNT_NO,
# MAGIC CREDIT_RATING,
# MAGIC Last_Transaction_Date,
# MAGIC Type,
# MAGIC SAP_CPTY_TYPE,
# MAGIC Type_Descr,
# MAGIC Last_Update_Gmt,
# MAGIC Last_User_ID,
# MAGIC  Rating_Date
# MAGIC from vw_IMOS_IMOS_COUNTERPARTY_ACCOUNTS

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_imos as 
# MAGIC select
# MAGIC distinct
# MAGIC UNIQUE_ID,
# MAGIC NAME,
# MAGIC Type,
# MAGIC ENTITY_TYPE,
# MAGIC DEACTIVATED,
# MAGIC L1_ID,
# MAGIC COUNTRY,
# MAGIC SAP_SYSTEM,
# MAGIC SAP_ACCOUNT_NO,
# MAGIC CREDIT_RATING,
# MAGIC --cast(Last_Transaction_Date as timestamp) as Last_Transaction_Date,
# MAGIC date_format(cast(Last_Transaction_Date as timestamp), "yyyy-MM-dd") as Last_Transaction_Date,
# MAGIC SAP_CPTY_TYPE,
# MAGIC case when trim(SAP_ACCOUNT_NO) = '' or SAP_ACCOUNT_NO is null then null 
# MAGIC      else SAP_SYSTEM || '_' || SAP_CPTY_TYPE || '_' || SAP_ACCOUNT_NO  end as SAP_UNIQUE_ID,
# MAGIC Type_Descr,
# MAGIC --cast(Last_Update_Gmt as timestamp) as Last_Update_Gmt,
# MAGIC date_format(cast(Last_Update_Gmt as timestamp), "yyyy-MM-dd") as Last_Update_Gmt,
# MAGIC Last_User_ID,
# MAGIC case when CREDIT_RATING ='E' then 'Y' else 'N' end  cp_erate_flag_in_source
# MAGIC --,cast(null as timestamp) as cp_erate_date_in_source
# MAGIC ,case when CREDIT_RATING ='E' then  cast(Rating_Date as timestamp) 
# MAGIC   else cast(null as timestamp) 
# MAGIC   end cp_erate_date_in_source 
# MAGIC ,L1_ID                          as cp_mapping_id
# MAGIC ,SYSTEM
# MAGIC ,'IMOS' as SOURCE_SYSTEM
# MAGIC ,current_timestamp as META_CREATED_DTTM
# MAGIC from vw_IMOS_IMOS_COUNTERPARTY_UNIQUE

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_imos")
df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master_imos')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_imos_entity_type as
# MAGIC select unique_id, concat_ws(',', collect_set(entity_type)) as entity_type from vw_cp_master_imos group by unique_id

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master as 
# MAGIC select  distinct
# MAGIC    cp.unique_id as cp_unique_id
# MAGIC   ,cp.L1_ID     as cp_l1_id
# MAGIC   ,cp.name      as cp_name
# MAGIC   ,cp.L1_ID     as cp_etrm_account_no
# MAGIC   ,cast(null as string) as cp_l2_id
# MAGIC   ,cast(null as string) as cp_l2_name
# MAGIC   ,cpme.ENTITY_TYPE       as cp_entity_type
# MAGIC   ,cast(null as timestamp) as cp_created_or_updated_date
# MAGIC   ,cp.deactivated          as cp_deactivated
# MAGIC   ,cp.country              as cp_country
# MAGIC   ,cast(null as string)    as cp_parent
# MAGIC   ,cp.system               as cp_system 
# MAGIC   ,cp.SAP_ACCOUNT_NO       as cp_linked_sap_id
# MAGIC   ,cp.SAP_CPTY_TYPE        as cp_sap_account_type
# MAGIC   ,cp.SAP_UNIQUE_ID        as cp_sap_unique_id
# MAGIC   ,cp.SAP_SYSTEM           as cp_linked_sap_system
# MAGIC   ,case when (cp.sap_unique_id is null or length(trim(cp.sap_unique_id)) = 0 ) then  'NO SAP LINK' 
# MAGIC            ELSE 'SAP LINK' 
# MAGIC      END cp_sap_link
# MAGIC   ,cp_erate_flag_in_source  as cp_erate_flag_in_source
# MAGIC   ,cp_erate_date_in_source  as cp_erate_date_in_source
# MAGIC   ,cast(null as string)   as cp_erate_lifted_date_in_source
# MAGIC   ,cast(null as string)   as cp_broker_indicator
# MAGIC   ,cp.L1_ID               as cp_mapping_id
# MAGIC   ,cp.SOURCE_SYSTEM       as SOURCE_SYSTEM
# MAGIC   ,cp.meta_created_dttm   as meta_created_dttm
# MAGIC   
# MAGIC from      vw_cp_master_imos cp
# MAGIC left join vw_cp_master_imos_entity_type cpme   on upper(trim(cp.unique_id)) = upper(trim(cpme.unique_id))

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master', 'IMOS')
