# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

#to read data is ingested in table in curated db instead on ADLS
curated_schema_name= 'ENDUR' 
curated_tables_list = ['ENDNA_PROD_ACTIVITY','ENDNA_PROD_SAP_IDS_MAPPING']
for table_name in curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_endur_products as 
# MAGIC select distinct cpty_erated_flag as CP_ERATED_FLAG,
# MAGIC cpty_id as UNIQUE_ID,
# MAGIC --cpty_legal_entity_long_name as L1_LONG_NAME,
# MAGIC activity.cpty_legal_name as L1_LONG_NAME,
# MAGIC cpty_legal_entity_id as L1_ID,
# MAGIC cpty_bunit_id as L2_ID,
# MAGIC /* new cp_l2_name definition as per Paul confirmed with Josephine  changed on 6/3/2021*/
# MAGIC case when length(trim(cpty_bunit_short_name)) >0  then cpty_bunit_short_name
# MAGIC      when length(trim(cpty_bunit_short_name)) = 0 then cpty_bunit_long_name
# MAGIC      when length(trim(cpty_bunit_long_name)) = 0 then cpty_legal_entity_short_name
# MAGIC  end as L2_LONG_NAME,
# MAGIC   /* new cp_short_name definition changed on 6/30/2021*/
# MAGIC  case when length(trim(cpty_bunit_short_name)) >0 then cpty_bunit_short_name
# MAGIC   when length(trim(cpty_bunit_short_name)) = 0 then cpty_bunit_long_name
# MAGIC   when length(trim(cpty_bunit_long_name)) = 0 then cpty_legal_entity_short_name
# MAGIC  end as CP_SHORT_NAME,
# MAGIC cpty_entity_type as ENTITY_TYPE,
# MAGIC cpty_deactivated_flag as DEACTIVATED,
# MAGIC cast(cpty_create_date as timestamp) as CP_CREATE_DATE,
# MAGIC cast(cpty_update_date as timestamp) as CP_UPDATE_DATE,
# MAGIC ltrim('0',trim(mapping.SAP_ID)) as SAP_ID,
# MAGIC 'ENDNA_PROD' as SYSTEM,
# MAGIC --case when mapping.SAP_ID is null then '' else mapping.CUST_VEND_IND_NM end as SAP_CPTY_TYPE,
# MAGIC mapping.CUST_VEND_IND_NM as SAP_CPTY_TYPE,
# MAGIC --case when mapping.SAP_ID is null then '' when mapping.INT_LENTITY_ID = '20034' then 'GSAP' else 'TSAP' end as SAP_SYSTEM,
# MAGIC case when mapping.SAP_ID is null then null when mapping.INT_LENTITY_ID = '20034' then 'GSAP' else 'TSAP' end as SAP_SYSTEM,
# MAGIC concat((case when mapping.INT_LENTITY_ID = '20034' then 'GSAP' else 'TSAP' end), '_', (mapping.CUST_VEND_IND_NM), '_', (mapping.SAP_ID)) as SAP_UNIQUE_ID,
# MAGIC 'ENDUR_PRODUCTS' as SOURCE_SYSTEM,
# MAGIC current_timestamp as META_CREATED_DTTM
# MAGIC from
# MAGIC vw_ENDUR_ENDNA_PROD_ACTIVITY activity
# MAGIC left outer join 
# MAGIC vw_ENDUR_ENDNA_PROD_SAP_IDS_MAPPING mapping
# MAGIC on activity.cpty_bunit_id = mapping.EXT_BUNIT_ID 
# MAGIC where cpty_id not like '%UNKNOWN%'
# MAGIC --and cpty_erated_flag != '?'

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_endur_products")
df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master_endur_products')

# COMMAND ----------

df_cp_master = df.select(col('UNIQUE_ID').alias('cp_unique_id'),                                                   #REQ-26
                         col('L1_ID').alias('cp_l1_id'),                           #REQ-28
                         col('L1_LONG_NAME').alias('cp_name'),                          #REQ-27
                         col('L2_ID').alias('cp_etrm_account_no'),
                         col('L2_ID').alias('cp_l2_id'),                          #REQ-29
                         col('L2_LONG_NAME').alias('cp_l2_name'),                      #REQ-30
                         col('CP_SHORT_NAME').alias('cp_short_name'),
                         col('ENTITY_TYPE').alias('cp_entity_type'),                                                 #REQ-31
                         expr("case when cp_create_date is null and cp_update_date is not null      then cast(cp_update_date as timestamp)\
                               when cp_update_date is null      and cp_create_date is not null      then cast(cp_create_date as timestamp)\
                               when cp_create_date>=cp_update_date                                   then cast(cp_create_date as timestamp)\
                               when cp_update_date>cp_create_date                                   then cast(cp_update_date as timestamp)\
                               else NULL\
                               end as cp_created_or_updated_date "),                #REQ-33/34
                         col('DEACTIVATED').alias('cp_deactivated'),                   #REQ-32
                         lit(None).cast(StringType()).alias('cp_country'),                      #REQ-91
                         lit(None).cast(StringType()).alias('cp_parent'),                       #REQ-87
                         col('SYSTEM').alias('cp_system'),                                      #REQ-36
                         col('SAP_ID').alias('cp_linked_sap_id'),                       #REQ-35
                         col('SAP_CPTY_TYPE').alias('cp_sap_account_type'),                  #REQ-38
                         col('SAP_UNIQUE_ID').alias('cp_sap_unique_id'),                        #REQ-97
                         col('SAP_SYSTEM').alias('cp_linked_sap_system'),                #REQ-93
                         expr("case when SAP_UNIQUE_ID is   \
                              Null or SAP_UNIQUE_ID = '' then 'NO SAP LINK' else 'SAP LINK' end")\
                         .alias('cp_sap_link'),
                         col('CP_ERATED_FLAG').alias('cp_erate_flag_in_source'),                    #REQ-9
                         lit(None).cast(TimestampType()).alias('cp_erate_date_in_source'),      #REQ-10
                         lit(None).cast(TimestampType()).alias('cp_erate_lifted_date_in_source'),   #REQ-11
                         lit(None).cast(StringType()).alias('cp_broker_indicator'),             #REQ-86
                         col('UNIQUE_ID').alias('cp_mapping_id'),
                         col('source_system'),
                         col('meta_created_dttm')
                        
                        
                        )

# COMMAND ----------

df_cp_master.createOrReplaceTempView(f"vw_cp_master")

# COMMAND ----------

df_cp_master.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master', 'ENDUR_PRODUCTS')
