# Databricks notebook source
from pyspark.sql.types import TimestampType, StringType

# COMMAND ----------

# MAGIC %sql 
# MAGIC CLEAR CACHE

# COMMAND ----------

# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

create_temp_views_per_source_system('RADAR', 'RADAR')

# COMMAND ----------

#%sql
#select * from radar_customer_contact where customer_code in
#(select distinct customer_code
#from radar_customer_contact
#where contact_last_name = 'HEAD OFFICE'
#group by customer_code
#having count(distinct contact_seq_num)>1
#limit 10)
#order by customer_code
#limit 10

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_customer_contact as   --Logic to get customer contact details
# MAGIC select customer_code, max(address_line_1) as address_line_1, 
# MAGIC max(address_line_2) as address_line_2, max(address_line_3) as address_line_3, 
# MAGIC max(address_line_4) as address_line_4, max(postal_town) as postal_town, 
# MAGIC max(county_state) as county_state, max(post_zip_code) as post_zip_code, 
# MAGIC max(address_line_5) as address_line_5, max(cntry_mnem) as cntry_mnem
# MAGIC from radar_customer_contact
# MAGIC where contact_last_name = 'HEAD OFFICE'
# MAGIC group by customer_code

# COMMAND ----------

df = spark.sql("select * from vw_customer_contact")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_tsap_code as   --Logic to get TSAP value, TSAP logic and join to be uncommented once Magellan data is available 
# MAGIC select distinct cvc.customer_code, cvc.customer_vendor_ind, 
# MAGIC null as TSAP
# MAGIC /*
# MAGIC case when cvc.customer_vendor_ind = 'C' then
# MAGIC   case when magl.kunnr is null then magl.magellan_sap_vendor_code else magl.kunnr end
# MAGIC when cvc.customer_vendor_ind = 'V' then
# MAGIC   case when magl.lifnr is null then magl.magellan_sap_vendor_code else magl.lifnr end
# MAGIC else null
# MAGIC end as TSAP*/
# MAGIC from radar_customer_vendor_code cvc
# MAGIC /*left outer join 
# MAGIC radar_tsap_zst_fi_magl magl --Magellan dataset to be taken once available
# MAGIC on cvc.customer_code = magl.customer_code
# MAGIC and cvc.vendor_seq_num = magl.vendor_seq_num*/

# COMMAND ----------

df = spark.sql("select * from vw_tsap_code")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_sap_vendor as       --Logic for scenario where SAP Vendor ID exists
# MAGIC SELECT distinct
# MAGIC        'RADAR' as SYSTEM,
# MAGIC        concat('RADAR',
# MAGIC        (case when c.customer_code is null then '' else concat('_',cast(c.customer_code as int)) end),
# MAGIC        (case when cvc.vendor_seq_num is null then '' else concat('_',cast(cvc.vendor_seq_num as int)) end)
# MAGIC        ) as UNIQUE_ID,
# MAGIC        c.business_name as NAME,
# MAGIC        c.customer_type as ENTITY_TYPE,
# MAGIC        --c.active_ind as DEACTIVATED,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DEACTIVATED,
# MAGIC        c.customer_code as L1_ID,
# MAGIC        c.customer_type as L1_TYPE,
# MAGIC        c.created_tstmp as CREATED_UPDATED,
# MAGIC        c.owning_customer_code as PARENT,
# MAGIC        cvc.vendor_seq_num as L2_ID,
# MAGIC        cvc.magellan_company_name as L2_NAME1,
# MAGIC        cvc.customer_vendor_ind as L2_TYPE,
# MAGIC        case when cc.cntry_mnem is null 
# MAGIC          then c.cntry_of_operation_mnem 
# MAGIC          else cc.cntry_mnem 
# MAGIC        end as COUNTRY,
# MAGIC        'STNSAP' as SAP_SYSTEM,      
# MAGIC        ltrim('0',trim(c.sap_vendor_code)) as SAP_ACCOUNT_NO,
# MAGIC        concat(
# MAGIC        (case when address_line_1 is null then '' else concat(address_line_1,' ') end),
# MAGIC        (case when address_line_2 is null then '' else concat(address_line_2,' ') end),
# MAGIC        (case when address_line_3 is null then '' else concat(address_line_3,' ') end),
# MAGIC        (case when address_line_4 is null then '' else address_line_4 end)
# MAGIC        ) as ADDRESS,
# MAGIC        c.sap_vendor_code as SAP_VENDOR_CODE,
# MAGIC        cvc.stn_sap_vendor_code AS STN_SAP_VENDOR_CODE,
# MAGIC        erated_ind as ERATE_FLAG,
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as ACTIVITY_ID,
# MAGIC        --tsap_cd.TSAP as TSAP,
# MAGIC        cvc.magellan_sap_vendor_code as TSAP, --Taken as per the change in logic to get TSAP values from Radar table instead of SAP Tables
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as L1_UNIQUE_ID,
# MAGIC        c.business_name as L1_LONG_NAME,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DELETED,
# MAGIC        case when cc.postal_town is null then cvc.city_txt else cc.postal_town end as CITY,
# MAGIC        case when cc.county_state is null then cvc.region_txt else cc.county_state end as STATE,
# MAGIC        case when cc.post_zip_code is null then cvc.postal_code_txt else cc.post_zip_code end as POSTCODE,
# MAGIC        c.customer_code as ACCOUNT_NO,
# MAGIC        cc.address_line_5 as ADDRESS_LINE_5,
# MAGIC        c.LAST_UPDATE_TSTMP as CUSTOMER_LAST_UPDATE_TSTMP,
# MAGIC        c.active_ind as L1_ACTIVE_IND,
# MAGIC        c.META_CREATED_DTTM as META_CREATED_DTTM,      
# MAGIC        case when cast(Substring(trim(c.sap_vendor_code),0,1) as double) is not null 
# MAGIC          then lpad(trim(c.sap_vendor_code), 10,'0')  
# MAGIC          else trim(c.sap_vendor_code)
# MAGIC        end as SAP_ACCOUNT,
# MAGIC        'L1' as SAP_LINK_LEVEL
# MAGIC FROM
# MAGIC radar_customer c
# MAGIC left outer join radar_customer_vendor_code cvc on c.customer_code = cvc.customer_code
# MAGIC left outer join vw_customer_contact cc on c.customer_code = cc.customer_code
# MAGIC --left outer join vw_tsap_code tsap_cd on c.customer_code = tsap_cd.customer_code  --taking data from Radar table as of now instead of SAP Table
# MAGIC where c.sap_vendor_code is not null and length(ltrim('0',trim(c.sap_vendor_code))) != 0 

# COMMAND ----------

df = spark.sql("select * from vw_sap_vendor")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_sap as  --To get same records twice one for Vendor and other for Customer
# MAGIC select *, concat('STNSAP_Customer_',SAP_ACCOUNT_NO) as SAP_UNIQUE_ID,
# MAGIC        'CUSTOMER' as SAP_CPTY_TYPE,
# MAGIC        'CUSTOMER' as VENDOR_CUSTOMER
# MAGIC from vw_sap_vendor
# MAGIC union
# MAGIC select *, concat('STNSAP_Vendor_',SAP_ACCOUNT_NO) as SAP_UNIQUE_ID,
# MAGIC        'VENDOR' as SAP_CPTY_TYPE,
# MAGIC        'VENDOR' as VENDOR_CUSTOMER
# MAGIC from vw_sap_vendor

# COMMAND ----------

df = spark.sql("select * from vw_sap")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_stn_sap_vendor as   --Logic for scenario where L2_ID and STN SAP Vendor ID exists
# MAGIC SELECT distinct 
# MAGIC        'RADAR' as SYSTEM,
# MAGIC        concat('RADAR',
# MAGIC        (case when c.customer_code is null then '' else concat('_',cast(c.customer_code as int)) end),
# MAGIC        (case when cvc.vendor_seq_num is null then '' else concat('_',cast(cvc.vendor_seq_num as int)) end)
# MAGIC        ) as UNIQUE_ID,
# MAGIC        c.business_name as NAME,
# MAGIC        c.customer_type as ENTITY_TYPE,
# MAGIC        --c.active_ind as DEACTIVATED,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DEACTIVATED,
# MAGIC        c.customer_code as L1_ID,
# MAGIC        c.customer_type as L1_TYPE,
# MAGIC        c.created_tstmp as CREATED_UPDATED,
# MAGIC        c.owning_customer_code as PARENT,
# MAGIC        cvc.vendor_seq_num as L2_ID,
# MAGIC        cvc.magellan_company_name as L2_NAME1,
# MAGIC        cvc.customer_vendor_ind as L2_TYPE,
# MAGIC        case when cc.cntry_mnem is null 
# MAGIC          then c.cntry_of_operation_mnem 
# MAGIC          else cc.cntry_mnem 
# MAGIC        end as COUNTRY,
# MAGIC        'STNSAP' as SAP_SYSTEM,       
# MAGIC        ltrim('0',trim(cvc.stn_sap_vendor_code)) as SAP_ACCOUNT_NO,
# MAGIC        concat(
# MAGIC        (case when address_line_1 is null then '' else concat(address_line_1,' ') end),
# MAGIC        (case when address_line_2 is null then '' else concat(address_line_2,' ') end),
# MAGIC        (case when address_line_3 is null then '' else concat(address_line_3,' ') end),
# MAGIC        (case when address_line_4 is null then '' else address_line_4 end)
# MAGIC        ) as ADDRESS,
# MAGIC        c.sap_vendor_code as SAP_VENDOR_CODE,
# MAGIC        cvc.stn_sap_vendor_code AS STN_SAP_VENDOR_CODE,
# MAGIC        erated_ind as ERATE_FLAG,
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as ACTIVITY_ID,
# MAGIC        --tsap_cd.TSAP as TSAP,
# MAGIC        cvc.magellan_sap_vendor_code as TSAP, --Taken as per the change in logic to get TSAP values from Radar table instead of SAP Tables
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as L1_UNIQUE_ID,
# MAGIC        c.business_name as L1_LONG_NAME,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DELETED,
# MAGIC        case when cc.postal_town is null then cvc.city_txt else cc.postal_town end as CITY,
# MAGIC        case when cc.county_state is null then cvc.region_txt else cc.county_state end as STATE,
# MAGIC        case when cc.post_zip_code is null then cvc.postal_code_txt else cc.post_zip_code end as POSTCODE,
# MAGIC        c.customer_code as ACCOUNT_NO,
# MAGIC        cc.address_line_5 as ADDRESS_LINE_5,
# MAGIC        c.LAST_UPDATE_TSTMP as CUSTOMER_LAST_UPDATE_TSTMP,
# MAGIC        c.active_ind as L1_ACTIVE_IND,
# MAGIC        c.META_CREATED_DTTM as META_CREATED_DTTM,       
# MAGIC        case when cast(Substring(trim(cvc.stn_sap_vendor_code),0,1) as double) is not null 
# MAGIC          then lpad(trim(cvc.stn_sap_vendor_code), 10,'0')  
# MAGIC          else trim(cvc.stn_sap_vendor_code)
# MAGIC        end as SAP_ACCOUNT,
# MAGIC        'L2' as SAP_LINK_LEVEL
# MAGIC FROM
# MAGIC radar_customer c
# MAGIC left OUTER JOIN radar_customer_vendor_code cvc on c.customer_code = cvc.customer_code
# MAGIC left OUTER JOIN vw_customer_contact cc on c.customer_code = cc.customer_code
# MAGIC --left outer join vw_tsap_code tsap_cd on c.customer_code = tsap_cd.customer_code  --taking data from Radar table as of now instead of SAP Table
# MAGIC where cvc.vendor_seq_num is not null and cvc.stn_sap_vendor_code is not null and length(ltrim('0',trim(cvc.stn_sap_vendor_code))) != 0 

# COMMAND ----------

df = spark.sql("select * from vw_stn_sap_vendor")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_stn_sap as   --To get same records twice one for Vendor and other for Customer
# MAGIC select *, concat('STNSAP_Customer_',SAP_ACCOUNT_NO) as SAP_UNIQUE_ID,
# MAGIC        'CUSTOMER' as SAP_CPTY_TYPE,
# MAGIC        'CUSTOMER' as VENDOR_CUSTOMER
# MAGIC from vw_stn_sap_vendor
# MAGIC union
# MAGIC select *, concat('STNSAP_Vendor_',SAP_ACCOUNT_NO) as SAP_UNIQUE_ID,
# MAGIC        'VENDOR' as SAP_CPTY_TYPE,
# MAGIC        'VENDOR' as VENDOR_CUSTOMER
# MAGIC from vw_stn_sap_vendor

# COMMAND ----------

df = spark.sql("select * from vw_stn_sap")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_tsap as    --Logic for scenario where TSAP ID exists, TSAP values taken from Radar table instead of SAP table
# MAGIC SELECT distinct
# MAGIC        'RADAR' as SYSTEM,
# MAGIC        concat('RADAR',
# MAGIC        (case when c.customer_code is null then '' else concat('_',cast(c.customer_code as int)) end),
# MAGIC        (case when cvc.vendor_seq_num is null then '' else concat('_',cast(cvc.vendor_seq_num as int)) end)
# MAGIC        ) as UNIQUE_ID,
# MAGIC        c.business_name as NAME,
# MAGIC        c.customer_type as ENTITY_TYPE,
# MAGIC        --c.active_ind as DEACTIVATED,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DEACTIVATED,
# MAGIC        c.customer_code as L1_ID,
# MAGIC        c.customer_type as L1_TYPE,
# MAGIC        c.created_tstmp as CREATED_UPDATED,
# MAGIC        c.owning_customer_code as PARENT,
# MAGIC        cvc.vendor_seq_num as L2_ID,
# MAGIC        cvc.magellan_company_name as L2_NAME1,
# MAGIC        cvc.customer_vendor_ind as L2_TYPE,
# MAGIC        case when cc.cntry_mnem is null 
# MAGIC          then c.cntry_of_operation_mnem 
# MAGIC          else cc.cntry_mnem 
# MAGIC        end as COUNTRY,
# MAGIC        'TSAP' as SAP_SYSTEM,
# MAGIC        ltrim('0',trim(cvc.magellan_sap_vendor_code)) as SAP_ACCOUNT_NO,
# MAGIC        concat(
# MAGIC        (case when address_line_1 is null then '' else concat(address_line_1,' ') end),
# MAGIC        (case when address_line_2 is null then '' else concat(address_line_2,' ') end),
# MAGIC        (case when address_line_3 is null then '' else concat(address_line_3,' ') end),
# MAGIC        (case when address_line_4 is null then '' else address_line_4 end)
# MAGIC        ) as ADDRESS,
# MAGIC        c.sap_vendor_code as SAP_VENDOR_CODE,
# MAGIC        cvc.stn_sap_vendor_code AS STN_SAP_VENDOR_CODE,
# MAGIC        erated_ind as ERATE_FLAG,
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as ACTIVITY_ID,
# MAGIC        --tsap_cd.TSAP as TSAP,
# MAGIC        cvc.magellan_sap_vendor_code as TSAP,
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as L1_UNIQUE_ID,
# MAGIC        c.business_name as L1_LONG_NAME,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DELETED,
# MAGIC        case when cc.postal_town is null then cvc.city_txt else cc.postal_town end as CITY,
# MAGIC        case when cc.county_state is null then cvc.region_txt else cc.county_state end as STATE,
# MAGIC        case when cc.post_zip_code is null then cvc.postal_code_txt else cc.post_zip_code end as POSTCODE,
# MAGIC        c.customer_code as ACCOUNT_NO,
# MAGIC        cc.address_line_5 as ADDRESS_LINE_5,
# MAGIC        c.LAST_UPDATE_TSTMP as CUSTOMER_LAST_UPDATE_TSTMP,
# MAGIC        c.active_ind as L1_ACTIVE_IND,
# MAGIC        c.META_CREATED_DTTM as META_CREATED_DTTM,
# MAGIC        case when cast(Substring(trim(cvc.magellan_sap_vendor_code),0,1) as double) is not null 
# MAGIC          then lpad(trim(cvc.magellan_sap_vendor_code), 10,'0')  
# MAGIC          else trim(cvc.magellan_sap_vendor_code)
# MAGIC        end as SAP_ACCOUNT,
# MAGIC        'L2' as SAP_LINK_LEVEL,
# MAGIC        concat('TSAP_',
# MAGIC        (case when cvc.customer_vendor_ind = 'C' then 'Customer_' else 'Vendor_' end),
# MAGIC        ltrim('0',trim(cvc.magellan_sap_vendor_code))) as SAP_UNIQUE_ID,
# MAGIC        case when cvc.customer_vendor_ind = 'C' then 'CUSTOMER' else 'VENDOR' end as SAP_CPTY_TYPE,
# MAGIC        case when cvc.customer_vendor_ind = 'C' then 'CUSTOMER' else 'VENDOR' end as VENDOR_CUSTOMER
# MAGIC FROM
# MAGIC radar_customer c
# MAGIC left OUTER JOIN radar_customer_vendor_code cvc on c.customer_code = cvc.customer_code
# MAGIC left OUTER JOIN vw_customer_contact cc on c.customer_code = cc.customer_code
# MAGIC --left outer join vw_tsap_code tsap_cd on c.customer_code = tsap_cd.customer_code
# MAGIC where cvc.vendor_seq_num is not null and cvc.magellan_sap_vendor_code is not null and length(ltrim('0',trim(cvc.magellan_sap_vendor_code))) != 0 

# COMMAND ----------

df = spark.sql("select * from vw_tsap")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_no_sap_code as    --Logic for scenario where no SAP code exists
# MAGIC SELECT distinct
# MAGIC        'RADAR' as SYSTEM,
# MAGIC        concat('RADAR',
# MAGIC        (case when c.customer_code is null then '' else concat('_',cast(c.customer_code as int)) end),
# MAGIC        (case when cvc.vendor_seq_num is null then '' else concat('_',cast(cvc.vendor_seq_num as int)) end)
# MAGIC        ) as UNIQUE_ID,
# MAGIC        c.business_name as NAME,
# MAGIC        c.customer_type as ENTITY_TYPE,
# MAGIC        --c.active_ind as DEACTIVATED,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DEACTIVATED,
# MAGIC        c.customer_code as L1_ID,
# MAGIC        c.customer_type as L1_TYPE,
# MAGIC        c.created_tstmp as CREATED_UPDATED,
# MAGIC        c.owning_customer_code as PARENT,
# MAGIC        cvc.vendor_seq_num as L2_ID,
# MAGIC        cvc.magellan_company_name as L2_NAME1,
# MAGIC        cvc.customer_vendor_ind as L2_TYPE,
# MAGIC        case when cc.cntry_mnem is null 
# MAGIC          then c.cntry_of_operation_mnem 
# MAGIC          else cc.cntry_mnem 
# MAGIC        end as COUNTRY,
# MAGIC        null as SAP_SYSTEM,
# MAGIC        null as SAP_ACCOUNT_NO,
# MAGIC        concat(
# MAGIC        (case when address_line_1 is null then '' else concat(address_line_1,' ') end),
# MAGIC        (case when address_line_2 is null then '' else concat(address_line_2,' ') end),
# MAGIC        (case when address_line_3 is null then '' else concat(address_line_3,' ') end),
# MAGIC        (case when address_line_4 is null then '' else address_line_4 end)
# MAGIC        ) as ADDRESS,
# MAGIC        c.sap_vendor_code as SAP_VENDOR_CODE,
# MAGIC        cvc.stn_sap_vendor_code AS STN_SAP_VENDOR_CODE,
# MAGIC        erated_ind as ERATE_FLAG,
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as ACTIVITY_ID,
# MAGIC        --tsap_cd.TSAP as TSAP,
# MAGIC        cvc.magellan_sap_vendor_code as TSAP, --Taken as per the change in logic to get TSAP values from Radar table instead of SAP Tables
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as L1_UNIQUE_ID,
# MAGIC        c.business_name as L1_LONG_NAME,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DELETED,
# MAGIC        case when cc.postal_town is null then cvc.city_txt else cc.postal_town end as CITY,
# MAGIC        case when cc.county_state is null then cvc.region_txt else cc.county_state end as STATE,
# MAGIC        case when cc.post_zip_code is null then cvc.postal_code_txt else cc.post_zip_code end as POSTCODE,
# MAGIC        c.customer_code as ACCOUNT_NO,
# MAGIC        cc.address_line_5 as ADDRESS_LINE_5,
# MAGIC        c.LAST_UPDATE_TSTMP as CUSTOMER_LAST_UPDATE_TSTMP,
# MAGIC        c.active_ind as L1_ACTIVE_IND,
# MAGIC        c.META_CREATED_DTTM as META_CREATED_DTTM,
# MAGIC        null as SAP_ACCOUNT,
# MAGIC        'L2' as SAP_LINK_LEVEL,
# MAGIC        null as SAP_UNIQUE_ID,
# MAGIC        null as SAP_CPTY_TYPE,
# MAGIC        null as VENDOR_CUSTOMER
# MAGIC FROM
# MAGIC radar_customer c
# MAGIC left OUTER JOIN radar_customer_vendor_code cvc on c.customer_code = cvc.customer_code
# MAGIC left OUTER JOIN vw_customer_contact cc on c.customer_code = cc.customer_code
# MAGIC --left outer join vw_tsap_code tsap_cd on c.customer_code = tsap_cd.customer_code  --taking data from Radar table as of now instead of SAP Table
# MAGIC where (c.sap_vendor_code is null or length(ltrim('0',trim(c.sap_vendor_code))) = 0 ) and 
# MAGIC (cvc.stn_sap_vendor_code is null or length(ltrim('0',trim(cvc.stn_sap_vendor_code))) = 0) and 
# MAGIC --(tsap_cd.TSAP is  null or length(ltrim('0',trim(tsap_cd.TSAP))) = 0)
# MAGIC (cvc.magellan_sap_vendor_code is null or length(ltrim('0',trim(cvc.magellan_sap_vendor_code))) = 0)

# COMMAND ----------

df = spark.sql("select * from vw_no_sap_code")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_radar_union as
# MAGIC select * from vw_sap
# MAGIC union
# MAGIC select * from vw_stn_sap
# MAGIC union
# MAGIC select * from vw_tsap
# MAGIC union
# MAGIC select * from vw_no_sap_code

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_radar_union")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_radar as
# MAGIC select
# MAGIC   SYSTEM,
# MAGIC   UNIQUE_ID,
# MAGIC   NAME,
# MAGIC   ENTITY_TYPE,
# MAGIC   DEACTIVATED,
# MAGIC   L1_ID,
# MAGIC   L1_TYPE,
# MAGIC   cast(CREATED_UPDATED as timestamp) as CREATED_UPDATED,
# MAGIC   PARENT,
# MAGIC   L2_ID,
# MAGIC   L2_NAME1,
# MAGIC   L2_TYPE,
# MAGIC   COUNTRY,
# MAGIC   SAP_SYSTEM,
# MAGIC   SAP_UNIQUE_ID,
# MAGIC   SAP_CPTY_TYPE,
# MAGIC   SAP_ACCOUNT_NO,
# MAGIC   ADDRESS,
# MAGIC   SAP_VENDOR_CODE,
# MAGIC   STN_SAP_VENDOR_CODE,
# MAGIC   ERATE_FLAG,
# MAGIC   ACTIVITY_ID,
# MAGIC   cast(TSAP as string) as TSAP,
# MAGIC   L1_UNIQUE_ID,
# MAGIC   L1_LONG_NAME,
# MAGIC   DELETED,
# MAGIC   CITY,
# MAGIC   STATE,
# MAGIC   POSTCODE,
# MAGIC   ACCOUNT_NO,
# MAGIC   ADDRESS_LINE_5,
# MAGIC   cast(CUSTOMER_LAST_UPDATE_TSTMP as timestamp) as CUSTOMER_LAST_UPDATE_TSTMP,
# MAGIC   L1_ACTIVE_IND,
# MAGIC   cast(META_CREATED_DTTM as timestamp) as META_CREATED_DTTM,
# MAGIC   VENDOR_CUSTOMER,
# MAGIC   SAP_ACCOUNT,
# MAGIC   SAP_LINK_LEVEL,
# MAGIC   'RADAR' as SOURCE_SYSTEM
# MAGIC from vw_cp_master_radar_union

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_radar")
df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master_radar')

# COMMAND ----------

df_cp_master = df.select(col('UNIQUE_ID').alias('cp_unique_id'),                                                      #REQ-26
                         col('L1_ID').alias('cp_l1_id'),                                        #REQ-28
                         col('NAME').alias('cp_name'),                                          #REQ-27
                         col('L1_ID').alias('cp_etrm_account_no'),
                         col('L2_ID').alias('cp_l2_id'),                                        #REQ-29
                         col('L2_NAME1').alias('cp_l2_name'),                                   #REQ-30
                         col('L1_TYPE').alias('cp_entity_type'),                                #REQ-31
#                          expr("case when CREATED_UPDATED is   \
#                               Null then CUSTOMER_LAST_UPDATE_TSTMP else CREATED_UPDATED end").cast(TimestampType())\
#                          .alias('cp_created_or_updated_date'),                                  #REQ-33/34
                         expr("greatest(CUSTOMER_LAST_UPDATE_TSTMP,CREATED_UPDATED)").alias('cp_created_or_updated_date'),
                         col('DEACTIVATED').alias('cp_deactivated'),                            #REQ-32
                         col('COUNTRY').alias('cp_country'),                                    #REQ-91
                         col('PARENT').alias('cp_parent'),                                      #REQ-87
                         col('system').alias('cp_system'),                                      #REQ-36
                         col('SAP_VENDOR_CODE').alias('cp_linked_sap_id'),                      #REQ-35
                         col('VENDOR_CUSTOMER').alias('cp_sap_account_type'),                   #REQ-38
                         col('SAP_UNIQUE_ID').alias('cp_sap_unique_id'),                        #REQ-97
                         col('SAP_SYSTEM').alias('cp_linked_sap_system'),                      #REQ-93
                         expr("case when sap_unique_id is   \
                              Null or sap_unique_id = '' then 'NO SAP LINK' else 'SAP LINK' end")\
                         .alias('cp_sap_link'),
                         col('ERATE_FLAG').alias('cp_erate_flag_in_source'),                    #REQ-9
                         lit(None).cast(TimestampType()).alias('cp_erate_date_in_source'),      #REQ-10
                         lit(None).cast(TimestampType()).alias('cp_erate_lifted_date_in_source'),   #REQ-11
                         lit(None).cast(StringType()).alias('cp_broker_indicator'),                                    #REQ-86
                         col('L1_ID').alias('cp_mapping_id'),
                         col('source_system'),
                         col('meta_created_dttm')
                        
                        
                        )
df_cp_master = df_cp_master.drop_duplicates()

# COMMAND ----------

df_cp_master.createOrReplaceTempView(f"vw_cp_master")
df_cp_master.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master', 'RADAR')
