# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 0,Get Parameters Values
create_temp_views_per_source_system('ENDUR_CANADA_PRODUCTS', 'DBO')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC create or replace temporary view vw_cp_master_endur_canada_products as
# MAGIC select /* format is ENDNA_CAN_LegalEntityID_BusinessUnitID */
# MAGIC        --concat('ENDNA_CAN_', coalesce(ple.party_id,'_'), case when ple.party_id is null then '' else '_' end , coalesce(pbu.party_id,'_'))  AS CP_UNIQUE_ID,  
# MAGIC        concat(coalesce(ple.party_id,''), case when ple.party_id is null then '' else '_' end , coalesce(pbu.party_id,''))  AS CP_UNIQUE_ID,  /* commenting on 10/21/2021  by RK */
# MAGIC        cast (ple.party_id as string)    AS CP_LEGAL_ENTITY_ID,
# MAGIC        ple.short_name  as CP_LEGAL_ENTITY_SHORT_NAME,
# MAGIC        case when ple.long_name is not null and trim(ple.long_name) != ''  then ple.long_name
# MAGIC             when ple.short_name is not null and trim(ple.short_name) != ''  then ple.short_name
# MAGIC             when pbu.long_name is not null and trim(pbu.long_name) != ''  then pbu.long_name
# MAGIC             else pbu.short_name
# MAGIC        end AS CP_LEGAL_ENTITY_NAME,
# MAGIC        cast(pbu.party_id as string)   AS CP_BUSINESS_UNIT_ID,
# MAGIC        pbu.short_name  as CP_BUSINESS_UNIT_SHORT_NAME,
# MAGIC        case when pbu.long_name is not null then pbu.long_name
# MAGIC             else pbu.short_name 
# MAGIC        end AS CP_BUSINESS_UNIT_NAME,
# MAGIC         concat(CASE WHEN pbu.int_ext = 0 THEN 'INT'
# MAGIC                     WHEN pbu.int_ext = 1 THEN 'EXT' 
# MAGIC                     ELSE 'UNKNOWN' 
# MAGIC                     END  ,
# MAGIC                 '_' ,
# MAGIC                 (CASE WHEN pbu.party_class = 0 THEN 'LE'
# MAGIC                       WHEN pbu.party_class = 1 THEN 'BU' 
# MAGIC                       ELSE 'UNKNOWN' 
# MAGIC                       END),
# MAGIC                  CASE when trim(right(replace(replace(trim(pbu.short_name),"-"," "),"_"," "),4)) in 
# MAGIC                 ("CRD","EXCH","LSE","MAR","NOC","OPR","PRD","RSK","TRSP") THEN
# MAGIC                 concat('_',trim(right(replace(replace(trim(pbu.short_name),"-"," "),"_"," "),4)))
# MAGIC                 ELSE ''
# MAGIC                 END )  AS cp_entity_type ,
# MAGIC        case when pbu.party_status in ( 1,0 ) then 'N'
# MAGIC             else 'Y' end as DEACTIVATED,
# MAGIC        cast(Null as timestamp)           AS CP_CREATE_DATE,
# MAGIC        cast(unix_timestamp(pbu.last_update, 'MM/dd/yyyy HH:mm:ss.SSS') as timestamp) as CP_LAST_UPDATE_DATE,
# MAGIC        pri.value                     AS SAP_ACCOUNT_NO,
# MAGIC        pbu.party_status                     AS CP_SYSTEM_STATUS,
# MAGIC        'ENDNA_CAN'                           AS SYSTEM,  -- changed from ENDUR_STUSCO to ENDNA_CAN
# MAGIC        pri.Type                             AS SAP_ACCOUNT_TYPE,
# MAGIC        cle.name                             AS CP_REGISTERED_COUNTRY,
# MAGIC        'MSAP'                             AS LINKED_SAP_SYSTEM,
# MAGIC        current_timestamp as META_CREATED_DTTM,
# MAGIC        case
# MAGIC        when trim(pri.value) = ''
# MAGIC        or pri.value is null then null
# MAGIC        else 'MSAP' || '_' || regexp_replace(pri.Type,'SAP_','') || '_' || pri.value
# MAGIC        end as SAP_UNIQUE_ID
# MAGIC       
# MAGIC       FROM DBO_PARTY pbu
# MAGIC             INNER JOIN DBO_BUSINESS_UNIT bu ON pbu.party_id = bu.party_id
# MAGIC             LEFT OUTER JOIN DBO_PARTY_RELATIONSHIP pr ON pbu.party_id = pr.business_unit_id
# MAGIC             LEFT OUTER JOIN DBO_LEGAL_ENTITY le ON pr.legal_entity_id = le.party_id
# MAGIC             LEFT OUTER JOIN DBO_PARTY ple ON pr.legal_entity_id = ple.party_id
# MAGIC             LEFT OUTER JOIN DBO_PARTY_FUNCTION pf ON ple.party_id = pf.party_id
# MAGIC             LEFT OUTER JOIN DBO_COUNTRY cle ON le.country = cle.id_number
# MAGIC             LEFT OUTER JOIN DBO_COUNTRY cbu ON bu.country = cbu.id_number
# MAGIC             LEFT OUTER JOIN DBO_STATES sle ON le.state_id = sle.state_id
# MAGIC             LEFT OUTER JOIN DBO_STATES sbu ON bu.state_id = sbu.state_id
# MAGIC             LEFT OUTER JOIN (SELECT 'SAP_CUSTOMER' AS Type,  value, party_id
# MAGIC                                    
# MAGIC                                     FROM DBO_PARTY_INFO
# MAGIC                              WHERE type_id in (20001) 
# MAGIC                              UNION ALL
# MAGIC                              SELECT 'SAP_VENDOR' AS Type, value, party_id
# MAGIC                                   
# MAGIC                              FROM DBO_PARTY_INFO
# MAGIC                              WHERE type_id in (20002)) pri ON pri.party_id = bu.party_id

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_endur_canada_products")
df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master_endur_canada_products')

# COMMAND ----------

from pyspark.sql.types import StringType, TimestampType
from pyspark.sql.functions import regexp_replace as r
sap_unique_id = concat(col('LINKED_SAP_SYSTEM'),lit('_'),r(col('SAP_ACCOUNT_TYPE'),'SAP_',''),lit('_'),col('SAP_ACCOUNT_NO'))
df_cp_master = df.select(concat(lit('ENDNA_CAN_'),col('CP_UNIQUE_ID')).alias('cp_unique_id'),                                                   #REQ-26
                         col('CP_LEGAL_ENTITY_ID').alias('cp_l1_id'),                           #REQ-28
                         col('CP_LEGAL_ENTITY_NAME').alias('cp_name'),                          #REQ-27
                         col('CP_BUSINESS_UNIT_ID').alias('cp_etrm_account_no'),                                       #--------
                         col('CP_BUSINESS_UNIT_ID').alias('cp_l2_id'),                          #REQ-29
                         col('CP_BUSINESS_UNIT_NAME').alias('cp_l2_name'),                      #REQ-30
                         col('CP_ENTITY_TYPE').alias('cp_entity_type'),   #REQ-31
                         expr("case when CP_LAST_UPDATE_DATE is not  \
                              Null then CP_LAST_UPDATE_DATE else CP_CREATE_DATE end").cast(TimestampType())\
                         .alias('cp_created_or_updated_date'),                                  #REQ-33/34 -------
                         col('DEACTIVATED').alias('cp_deactivated'),                   #REQ-32
                         col('CP_REGISTERED_COUNTRY').alias('cp_country'),                                    #REQ-91
                         lit(None).cast(StringType()).alias('cp_parent'),                       #REQ-87
                         col('SYSTEM').alias('cp_system'),                                      #REQ-36
                         col('SAP_ACCOUNT_NO').alias('cp_linked_sap_id'),                       #REQ-35
                         r(col('SAP_ACCOUNT_TYPE'),'SAP_','').alias('cp_sap_account_type'),                  #REQ-38
                         sap_unique_id.alias('cp_sap_unique_id'),                        #REQ-97
                         col('LINKED_SAP_SYSTEM').alias('cp_linked_sap_system'),                       #REQ-93
                         
                         expr("case when SAP_ACCOUNT_NO is   \
                              Null or SAP_ACCOUNT_NO = '' then 'NO SAP LINK' else 'SAP LINK' end").alias('cp_sap_link'),
                         lit(None).cast(StringType()).alias('cp_erate_flag_in_source'),                    #REQ-9
                         lit(None).cast(TimestampType()).alias('cp_erate_date_in_source'),                    #REQ-10
                         lit(None).cast(TimestampType()).alias('cp_erate_lifted_date_in_source'),   #REQ-11
                         lit(None).cast(StringType()).alias('cp_broker_indicator'),             #REQ-86
                         col('CP_BUSINESS_UNIT_ID').alias('cp_mapping_id'),
                         col('SYSTEM').alias('SOURCE_SYSTEM'),
                         col('META_CREATED_DTTM'),
                         expr("case when length(trim(CP_BUSINESS_UNIT_SHORT_NAME)) >0 then  CP_BUSINESS_UNIT_SHORT_NAME when length(trim(CP_BUSINESS_UNIT_SHORT_NAME)) = 0 then CP_BUSINESS_UNIT_NAME when length(trim(CP_BUSINESS_UNIT_NAME)) = 0 then CP_LEGAL_ENTITY_SHORT_NAME  end").alias('CP_SHORT_NAME')
                        ).distinct()
                        

# COMMAND ----------

df_cp_master.createOrReplaceTempView(f"vw_cp_master")

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master', 'ENDNA_CAN')

# COMMAND ----------


