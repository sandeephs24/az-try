# Databricks notebook source
# MAGIC %sql
# MAGIC --Clear CACHE
# MAGIC 
# MAGIC select * from vw_gpna_PARTY_INFO;

# COMMAND ----------

# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

# source_system , view_prefix_name  parameters to pass to the function
create_temp_views_per_source_system('ENDUR_GP_NA', 'gpna')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view erate_info as 
# MAGIC select distinct PARTY_ID, 'N' as flag from gpna_PARTY_FUNCTION where Function_TYPE = 1  -- PBI 958878

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_gpna as 
# MAGIC 
# MAGIC SELECT CASE WHEN ple.PARTY_ID IS NULL THEN  CONCAT('ENDNA_GP', '__', pbu.PARTY_ID) 
# MAGIC             ELSE CONCAT('ENDNA_GP', '_', ple.PARTY_ID, '_',pbu.PARTY_ID) END AS cp_unique_id,
# MAGIC         ple.PARTY_ID    AS cp_legal_entity_id,
# MAGIC         ple.short_name  as cp_legal_entity_short_name,
# MAGIC         case when ple.long_NAME is not null and length(trim(ple.long_name)) >0 then ple.long_NAME
# MAGIC             else ple.short_name 
# MAGIC         end AS cp_legal_entity_name,
# MAGIC        pbu.PARTY_ID    AS cp_business_unit_id,
# MAGIC        pbu.short_name  as cp_business_unit_short_name,
# MAGIC        case when pbu.long_name is not null and length(trim(pbu.long_name)) > 0  then pbu.long_NAME
# MAGIC             else pbu.short_name 
# MAGIC         end AS cp_business_unit_name,
# MAGIC        IFNULL(CONCAT(CASE WHEN pbu.INT_EXT = 0 THEN 'INT'
# MAGIC                           WHEN pbu.INT_EXT = 1 THEN 'EXT' 
# MAGIC                           ELSE 'UNKNOWN' 
# MAGIC                        END , 
# MAGIC                        '_' ,
# MAGIC                      CASE WHEN pbu.PARTY_CLASS = 0 THEN 'LE'
# MAGIC                           WHEN pbu.PARTY_CLASS = 1 THEN 'BU' 
# MAGIC                           ELSE 'UNKNOWN' 
# MAGIC                           END,
# MAGIC                     -- check the last 3 characters of last underscore and if it satisfies 'CD' or 'PT' or BKR then concat with those characters in the end
# MAGIC                     CASE WHEN slice(split(trim(pbu.SHORT_NAME), "_"),-1,1)[0] in ('CD', 'PT', 'BKR') then concat('_',slice(split(trim(pbu.SHORT_NAME), "_"),-1,1)[0])
# MAGIC                          else ''
# MAGIC                          end 
# MAGIC                           ), 'UNKNOWN') AS cp_entity_type,              
# MAGIC        CASE WHEN (pbu.PARTY_STATUS <> 1 OR ple.PARTY_STATUS <> 1) THEN 'Y' 
# MAGIC             ELSE 'N' END AS cp_deactivation_flag, -- check the logic   ,, its different between the catalog and alteryx logic
# MAGIC        CAST (NULL AS TIMESTAMP)             AS cp_create_date,
# MAGIC        CAST (pbu.LAST_UPDATE AS TIMESTAMP)  AS cp_last_update_date,
# MAGIC        LTRIM(pri.VALUE)                     AS sap_account_no,
# MAGIC        'ENDNA_GP'                           AS system,
# MAGIC        pbu.party_status                     AS cp_system_status,
# MAGIC        pri.TYPE                             AS sap_account_type,
# MAGIC        PRI.SAP_UNIQUE_ID                    as sap_unique_id,
# MAGIC        ''                                   AS broker_indicator,
# MAGIC        ''                                   AS parent,
# MAGIC        cle.NAME                             AS cp_registered_country,
# MAGIC        'STNSAP'                             AS linked_sap_system,
# MAGIC        coalesce(ef.flag,'Y')                              AS erate_flag, --PBI 958878
# MAGIC        to_date(NULL)                        AS erate_completion_date,
# MAGIC        to_Date(NULL)                        AS erate_lift_date,
# MAGIC        
# MAGIC        --ple.SHORT_NAME                       AS cp_legal_entity_short_name,
# MAGIC        'ENDUR_GP_NA'                        AS source_system,
# MAGIC        case when ple.SHORT_NAME is null then  to_Date(pbu.META_CREATED_DTTM) 
# MAGIC             else to_Date(ple.META_CREATED_DTTM)
# MAGIC          END meta_created_dttm
# MAGIC        
# MAGIC        FROM gpna_PARTY pbu
# MAGIC             INNER JOIN gpna_BUSINESS_UNIT bu ON pbu.PARTY_ID = bu.PARTY_ID
# MAGIC             LEFT OUTER JOIN gpna_PARTY_RELATIONSHIP pr ON pbu.PARTY_ID = pr.BUSINESS_UNIT_ID
# MAGIC             LEFT OUTER JOIN gpna_LEGAL_ENTITY le ON pr.LEGAL_ENTITY_ID = le.PARTY_ID
# MAGIC             LEFT OUTER JOIN gpna_PARTY ple ON pr.LEGAL_ENTITY_ID = ple.PARTY_ID
# MAGIC             LEFT OUTER JOIN gpna_PARTY_FUNCTION pf ON ple.PARTY_ID = pf.PARTY_ID
# MAGIC             LEFT OUTER JOIN erate_info ef ON ef.PARTY_ID = pbu.PARTY_ID                -- PBI 958878
# MAGIC             LEFT OUTER JOIN gpna_COUNTRY cle ON le.COUNTRY = cle.ID_NUMBER
# MAGIC             LEFT OUTER JOIN gpna_COUNTRY cbu ON bu.COUNTRY = cbu.ID_NUMBER
# MAGIC             LEFT OUTER JOIN gpna_STATES sle ON le.STATE_ID = sle.STATE_ID
# MAGIC             LEFT OUTER JOIN gpna_STATES sbu ON bu.STATE_ID = sbu.STATE_ID
# MAGIC             LEFT OUTER JOIN (SELECT 'CUSTOMER' AS Type, REPLACE(LTRIM(REPLACE(value, '0', ' ')),' ','0') as value, PARTY_ID, 
# MAGIC                                      CASE WHEN trim(VALUE) IS NOT NULL and length(trim(VALUE)) >0  THEN  CONCAT('STNSAP_Customer_',REPLACE(LTRIM(REPLACE(trim(value), '0', ' ')),' ','0')) ELSE NULL END  SAP_UNIQUE_ID
# MAGIC                                     FROM gpna_PARTY_INFO
# MAGIC                              WHERE TYPE_ID in (40019,40020)
# MAGIC                              UNION ALL
# MAGIC                              SELECT 'VENDOR' AS Type, REPLACE(LTRIM(REPLACE(value, '0', ' ')),' ','0') as value, PARTY_ID,
# MAGIC                                      CASE WHEN trim(VALUE) IS NOT NULL   and length(trim(VALUE)) >0  THEN  CONCAT('STNSAP_Vendor_',REPLACE(LTRIM(REPLACE(trim(value), '0', ' ')),' ','0'))  ELSE NULL END AS SAP_UNIQUE_ID
# MAGIC                                     FROM gpna_PARTY_INFO
# MAGIC                              WHERE TYPE_ID in (40019,40020)) pri ON pri.PARTY_ID = ple.PARTY_ID

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master_gpna')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master as 
# MAGIC select 
# MAGIC      cp_unique_id          as cp_unique_id                -- req-26
# MAGIC     ,cp_legal_entity_id    as cp_l1_id                    -- l1_id (req-28)
# MAGIC     ,case when cp_business_unit_name is not null and length(trim(cp_business_unit_name)) >0 then cp_business_unit_name 
# MAGIC           else cp_legal_entity_name 
# MAGIC      end  cp_name   
# MAGIC     ,cp_business_unit_id   as cp_etrm_account_no          -- same as l2_id for gpna
# MAGIC     ,cp_business_unit_id   as cp_l2_id                    -- l2_id (req-29)
# MAGIC     ,cp_business_unit_name as cp_l2_name                  -- l2_name (req-30)
# MAGIC     ,cp_entity_type        as cp_entity_type              -- REQ-31
# MAGIC     ,case when cp_create_date  is null and cp_last_update_date is not null then cast(cp_last_update_date as timestamp) 
# MAGIC             when cp_last_update_date is null and cp_create_date  is not null then cast(cp_create_date as timestamp) 
# MAGIC             when cp_create_date>=cp_last_update_date then cast(cp_create_date as timestamp) 
# MAGIC             when cp_last_update_date>cp_create_date then cast(cp_last_update_date as timestamp) 
# MAGIC         else NULL 
# MAGIC       end as cp_created_or_updated_date
# MAGIC     ,cp_deactivation_flag  as cp_deactivated              -- req-32
# MAGIC     ,cp_registered_country as cp_country                  -- req-91
# MAGIC     ,parent                as cp_parent                   -- req-87
# MAGIC     ,system                as cp_system                   -- req-36
# MAGIC     ,sap_account_no        as cp_linked_sap_id            -- REQ-35
# MAGIC     ,sap_account_type      as cp_sap_account_type         -- REQ-38
# MAGIC     ,sap_unique_id         as cp_sap_unique_id            -- REQ-97
# MAGIC     ,linked_sap_system     as cp_linked_sap_system        -- REQ-93
# MAGIC     ,case when (sap_unique_id is null or length(trim(sap_unique_id)) = 0 ) then  'NO SAP LINK' 
# MAGIC            ELSE 'SAP LINK' 
# MAGIC      END cp_sap_link
# MAGIC     ,erate_flag            as cp_erate_flag_in_source     -- REQ-9
# MAGIC     ,erate_completion_date as cp_erate_date_in_source     -- REQ-10
# MAGIC     ,erate_lift_date       as cp_erate_lifted_date_in_source  -- req-11
# MAGIC     ,cast(null as string)  as cp_broker_indicator               -- REQ-86
# MAGIC     ,cp_business_unit_id   as cp_mapping_id              
# MAGIC     ,source_system         as source_system                   --metadatacol
# MAGIC     ,meta_created_dttm     as meta_created_dttm               --metadatacol
# MAGIC 
# MAGIC from vw_cp_master_gpna

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master', 'ENDUR_GP_NA')
