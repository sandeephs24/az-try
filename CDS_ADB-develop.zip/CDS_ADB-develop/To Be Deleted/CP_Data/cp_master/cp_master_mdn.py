# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

create_temp_views_per_source_system('MDN', 'MDN')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC create or replace temporary view vw_mdn_temp as
# MAGIC select rq.REQUEST_ID,crq.LEGAL_ENTITY_LONG_NAME,crq.LEGAL_ENTITY_SHORT_NAME
# MAGIC ,
# MAGIC rqarea.REQUEST_AREA_DESC,
# MAGIC rqtype.REQUEST_TYPE_DESC,
# MAGIC DeskAsgn.REF_OPTION_VALUE as DESK_ASSIGN,
# MAGIC SubUser.USER_ALIAS_NAME SUBMITTER_USER_NAME,
# MAGIC SubUser.USER_EMAIL_ADDRESS    as SUBMITTER_EMAIL ,    
# MAGIC ReqUser.USER_ALIAS_NAME REQUESTER_USER_NAME  ,                                   
# MAGIC ReqUser.USER_EMAIL_ADDRESS as REQUESTER_EMAIL,
# MAGIC step.STEP_DESC,
# MAGIC ac.ACTION_CODE_DESC,
# MAGIC ROW_NUMBER () over (Partition by rq.Request_ID order by timetrack.TIME_TRACKING_ID asc) as ACTION_ORDER,
# MAGIC CASE WHEN timetrack.ACTION_CODE_ID =3 then timetrack.CREATE_USER_DT END as DATE_APPROVED,
# MAGIC UserID.USER_EMAIL_ADDRESS as USER_ID,
# MAGIC UserGroup.GROUP_DESC as ROLE,
# MAGIC rq.CREATE_DT as REQUEST_START_DATE,
# MAGIC crq.GoldTier_ID as GOLDTIER_ID,
# MAGIC concat(cmp.COMP_CODE , ' - ' , cmp.COMP_NAME) as COMPANY,
# MAGIC OrgType.REF_OPTION_VALUE as ORGANISATION_TYPE,
# MAGIC cptype.REF_OPTION_VALUE as COUNTERPARTY_TYPE,
# MAGIC extend.REF_OPTION_VALUE as EXTEND_CHANGE_TYPE,
# MAGIC prio.REF_OPTION_VALUE as PRIORITY,
# MAGIC DueD.REF_OPTION_VALUE as TYPE_OF_DUE_DILIGENCE,
# MAGIC crq.BUSINESS_LINE_ID
# MAGIC 
# MAGIC 
# MAGIC from 
# MAGIC 
# MAGIC MDN_MDN_REQUEST rq  
# MAGIC inner join MDN_MDN_REQUEST_AREA rqarea on rq.REQUEST_AREA_ID = rqarea.REQUEST_AREA_ID
# MAGIC inner join MDN_MDN_COUNTERPARTY_REQUEST crq on rq.REQUEST_ID = crq.REQUEST_ID
# MAGIC inner join MDN_MDN_REQUEST_TYPE rqtype on rq.REQUEST_TYPE_ID = rqtype.REQUEST_TYPE_ID
# MAGIC inner join MDN_MDN_TIME_TRACKING timetrack on timetrack.REQUEST_ID = rq.REQUEST_ID
# MAGIC left join MDN_MDN_COMPANY cmp on cmp.COMP_ID = crq.COMP_ID
# MAGIC left join MDN_MDN_USER_DEFINITION ReqUser on ReqUser.USER_DEFINITION_ID = rq.REQUESTER_NM
# MAGIC left join MDN_MDN_USER_DEFINITION SubUser on SubUser.USER_DEFINITION_ID = crq.CREATE_USER_ID  
# MAGIC left join MDN_MDN_REFERENCE OrgType on OrgType.REF_ID = crq.ORG_TYPE_ID  
# MAGIC left join MDN_MDN_REFERENCE DeskAsgn on DeskAsgn.REF_ID = crq.DESK_ASSIGN_ID   -- DESK
# MAGIC left join MDN_MDN_USER_DEFINITION UserID on UserID.USER_DEFINITION_ID = timetrack.CREATE_USER_ID   
# MAGIC left join MDN_MDN_USER_GROUP UserGroup on UserGroup.GROUP_ID = timetrack.GROUP_ID
# MAGIC inner join MDN_MDN_STEP step on step.STEP_ID = timetrack.STEP_ID
# MAGIC inner join MDN_MDN_ACTION_CODE ac on ac.ACTION_CODE_ID = timetrack.ACTION_CODE_ID
# MAGIC left join MDN_MDN_REFERENCE prio on prio.REF_ID = rq.PRIORITY_DESC_ID  
# MAGIC left join (Select * from MDN_MDN_REFERENCE where REF_ID in (1778,1795)) cptype on crq.ACCOUNT_CUSTOMER_TYPE_ID = cptype.REF_ID
# MAGIC left join MDN_MDN_REFERENCE extend on extend.REF_ID = crq.EXTEND_CHANGE_TYPE_ID
# MAGIC left join MDN_MDN_REFERENCE DueD on DueD.REF_ID = crq.TypeofDueDiligence 

# COMMAND ----------

df_temp = spark.sql('select * from vw_mdn_temp')
df_temp.cache()

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP VIEW IF EXISTS vw_mdn_temp;

# COMMAND ----------

df_temp.createOrReplaceTempView('vw_mdn')

# COMMAND ----------

def remov(x) :
  if x is None:
    return None
  else:
    return x.strip()
    
  
  

# COMMAND ----------

spark.udf.register('rs',remov)

# COMMAND ----------

# DBTITLE 0,Add logic for BusinessLine,Role,SupportingDoc and UpdateType
# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_mdn as
# MAGIC with a as (
# MAGIC select rq.REQUEST_ID,
# MAGIC 
# MAGIC CASE upper(rq.REQUEST_AREA_DESC)	
# MAGIC 		WHEN 'COUNTERPARTY-STUSCO' THEN NULL
# MAGIC 		ELSE
# MAGIC 	  (Select  concat_ws(', ',collect_set(cast (REF.REF_OPTION_VALUE  as string))) FROM MDN_MDN_MULTIPLE_SELECT_VALUE MSV INNER JOIN MDN_MDN_REFERENCE REF ON REF.REF_ID = MSV.REF_ID WHERE MSV.MULTIPLE_SELECT_LINK_ID = rq.REQUEST_ID AND REF.REF_TYPE_ID = 74 AND MSV.DELETE_IND = 0) END as BUSINESSROLE,
# MAGIC       rq.REQUEST_AREA_DESC as REQUEST_AREA,
# MAGIC       rq.REQUEST_TYPE_DESC as REQUEST_TYPE,
# MAGIC       rq.COMPANY as COMPANY_NAME,
# MAGIC       rq.DESK_ASSIGN as DESK_ASSIGN,
# MAGIC       rq.LEGAL_ENTITY_LONG_NAME as LEGAL_ENTITY_LONG_NAME,
# MAGIC       rq.LEGAL_ENTITY_SHORT_NAME as LEGAL_ENTITY_SHORT_NAME,
# MAGIC          
# MAGIC CASE upper(rq.REQUEST_AREA_DESC)	
# MAGIC 		WHEN 'COUNTERPARTY-STUSCO' THEN (SELECT  first(REF_OPTION_VALUE) FROM MDN_MDN_REFERENCE WHERE REF_ID = rq.BUSINESS_LINE_ID and REF_OPTION_VALUE is not null  )
# MAGIC 		WHEN 'COUNTERPARTY-SENA' THEN (SELECT concat_ws(', ',collect_set(CAST(REF.REF_OPTION_VALUE AS string)))
# MAGIC         FROM MDN_MDN_MULTIPLE_SELECT_VALUE MSV INNER JOIN MDN_MDN_REFERENCE REF ON REF.REF_ID = MSV.REF_ID WHERE MSV.MULTIPLE_SELECT_LINK_ID = rq.REQUEST_ID AND REF.REF_TYPE_ID IN (102, 105,106) AND MSV.DELETE_IND = 0 )
# MAGIC 		WHEN 'COUNTERPARTY-WONA' THEN (SELECT concat_ws(', ',collect_set(CAST(REF.REF_OPTION_VALUE AS string))) FROM MDN_MDN_MULTIPLE_SELECT_VALUE MSV INNER JOIN MDN_MDN_REFERENCE REF ON REF.REF_ID = MSV.REF_ID WHERE MSV.MULTIPLE_SELECT_LINK_ID = rq.REQUEST_ID AND REF.REF_TYPE_ID = 124 AND MSV.DELETE_IND = 0) END as  BUSINESSLINE,
# MAGIC         
# MAGIC        rq.REQUEST_START_DATE  as REQUEST_START_DATE,
# MAGIC        rq.SUBMITTER_EMAIL,
# MAGIC        rq.REQUESTER_EMAIL,
# MAGIC        rq.SUBMITTER_USER_NAME,
# MAGIC        rq.REQUESTER_USER_NAME,
# MAGIC        rq.GOLDTIER_ID,
# MAGIC        rq.ORGANISATION_TYPE,
# MAGIC        rq.EXTEND_CHANGE_TYPE,
# MAGIC        rq.STEP_DESC,
# MAGIC        rq.ACTION_CODE_DESC,
# MAGIC        rq.ACTION_ORDER,
# MAGIC        rq.USER_ID,
# MAGIC        rq.ROLE,
# MAGIC        rq.COUNTERPARTY_TYPE,
# MAGIC        (Select concat_ws(', ',collect_set(sd.SUPPORTING_DOC_NAME)) from MDN_MDN_SUPPORTING_DOCUMENT sd 
# MAGIC WHERE sd.SUPPORTING_LINK_ID = rq.REQUEST_ID AND sd.DELETE_IND = 0) as SUPPORTING_DOCUMENT,
# MAGIC        rq.PRIORITY,       
# MAGIC        (SELECT first(REF.REF_OPTION_VALUE) FROM MDN_MDN_MULTIPLE_SELECT_VALUE MSV INNER JOIN MDN_MDN_REFERENCE REF ON REF.REF_ID = MSV.REF_ID 
# MAGIC WHERE MSV.MULTIPLE_SELECT_LINK_ID = rq.REQUEST_ID AND REF.REF_TYPE_ID in (54,135) AND MSV.DELETE_IND = 0 ) UPDATETYPE,
# MAGIC        rq.DATE_APPROVED,
# MAGIC        rq.TYPE_OF_DUE_DILIGENCE,
# MAGIC        'MDN' as SYSTEM,
# MAGIC        current_timestamp as META_CREATED_DTTM
# MAGIC        
# MAGIC 
# MAGIC from vw_mdn rq )
# MAGIC 
# MAGIC 
# MAGIC select REQUEST_ID
# MAGIC       ,BUSINESSROLE as BUSINESS_ROLE
# MAGIC       ,REQUEST_AREA
# MAGIC       ,REQUEST_TYPE
# MAGIC       ,COMPANY_NAME
# MAGIC       ,DESK_ASSIGN
# MAGIC       ,rs(LEGAL_ENTITY_LONG_NAME) as LEGAL_ENTITY_LONG_NAME
# MAGIC       ,rs(LEGAL_ENTITY_SHORT_NAME) as LEGAL_ENTITY_SHORT_NAME
# MAGIC       ,CASE WHEN BUSINESSROLE like '%C&I%' THEN 'C&I (Commercial & Industries)'
# MAGIC             WHEN REQUEST_AREA like '%SENA' and BUSINESSLINE like '%NA G&A%' THEN 'G&A'
# MAGIC             WHEN REQUEST_AREA like '%WONA' and BUSINESSLINE like '%GENERAL & ADMINISTRATIVE VENDOR%' THEN 'G&A'
# MAGIC             WHEN REQUEST_AREA like '%STUSCO' and BUSINESSLINE like '%Crude Lease%' then 'Royalty Payees (Lease)'
# MAGIC             ELSE 'Trading / Business / Companies'
# MAGIC             END as CP_TYPE
# MAGIC       ,BUSINESSLINE as BUSINESS_LINE
# MAGIC       ,CASE WHEN upper(a.REQUEST_AREA) like '%SENA%' THEN concat(REQUEST_AREA,' | ',BUSINESSLINE)
# MAGIC 		    WHEN upper(a.REQUEST_AREA) like '%WONA%' THEN concat(REQUEST_AREA,' | ',BUSINESSLINE,' | ',BUSINESSROLE)
# MAGIC             WHEN REQUEST_AREA like '%STUSCO' THEN concat(REQUEST_AREA,' | ',BUSINESSLINE)
# MAGIC             ELSE null END as  MAPPING
# MAGIC       ,cast(REQUEST_START_DATE as timestamp) as REQUEST_START_DATE
# MAGIC       ,SUBMITTER_EMAIL
# MAGIC       ,REQUESTER_EMAIL
# MAGIC       ,SUBMITTER_USER_NAME
# MAGIC       ,REQUESTER_USER_NAME
# MAGIC       ,GOLDTIER_ID
# MAGIC       ,ORGANISATION_TYPE
# MAGIC       ,EXTEND_CHANGE_TYPE
# MAGIC       ,STEP_DESC
# MAGIC       ,ACTION_CODE_DESC
# MAGIC       ,ACTION_ORDER
# MAGIC       ,USER_ID
# MAGIC       ,ROLE
# MAGIC       ,COUNTERPARTY_TYPE
# MAGIC       ,SUPPORTING_DOCUMENT
# MAGIC       ,PRIORITY
# MAGIC       ,UPDATETYPE
# MAGIC       ,cast(DATE_APPROVED as timestamp) as DATE_APPROVED
# MAGIC       ,TYPE_OF_DUE_DILIGENCE
# MAGIC       ,SYSTEM
# MAGIC       ,META_CREATED_DTTM  
# MAGIC from a

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_mdn")
df.count()

# COMMAND ----------

from time import sleep

tries = 3
for i in range(tries):
    try:
        print("Try :",i+1)
        RefreshCuratedSqlTbl('pty_counterparty', 'cp_master_mdn')
    except:
        if i < tries - 1: 
            sleep(120)
            continue
        else:
            raise
    break

# COMMAND ----------

df_temp.unpersist()
