# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

curated_schema_name= 'SFDC' 
curated_tables_list = ['E_Rate_All_Request__c']
for table_name in curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_ErateSalesForce as 
# MAGIC Select distinct case when upper(Request_Type__c) = 'E-RATE' Then 'Y' Else 'N' End ERATE_FLAG,System_ID__c as UNIQUE_ID,COUNTERPARTY_NAME,ERATE_COMPLETION_DATE, SYSTEM,current_timestamp as META_CREATED_DTTM
# MAGIC 
# MAGIC from ( 
# MAGIC select System_ID__c, Counterparty_Name__c as COUNTERPARTY_NAME,
# MAGIC                            Latest_Actioned_Date__C,
# MAGIC                            Date_Actioned_DD_MM_YYYY__c,
# MAGIC                            cast(UNIX_TIMESTAMP(er.e_rate_completion_date__c , "yyyy/MM/dd") as timestamp) as ERATE_COMPLETION_DATE,
# MAGIC                            Latest_Actioned_Request_Type__c,
# MAGIC                            Request_Type__c,
# MAGIC                            System_Group__c,
# MAGIC                            Comments__c,
# MAGIC                            Request_Info__c,
# MAGIC                            Request_Status__c,
# MAGIC                            Request_Reason__c,
# MAGIC                            er.system__c as SYSTEM,
# MAGIC                            --case when Request_Type__c = 'E-Rate' or Request_Type__c not in('Lift E-Rate', 'Deactivate') then 'Y' ELSE 'N' END erate_flag,
# MAGIC                            ROW_NUMBER() OVER (PARTITION BY System_ID__c  ORDER BY Latest_Actioned_Date__c DESC, Date_Actioned_DD_MM_YYYY__c  DESC  ) as ROW_NUM
# MAGIC                            FROM vw_SFDC_E_Rate_All_Request__c er 
# MAGIC                            -- er.System_ID__c = 'IMOS_SONAGAS'
# MAGIC                            where Request_Type__c  not in ('Deactivate', 'Reactivate')
# MAGIC                            ANd Request_Status__c in ('Completed','Previously Actioned')
# MAGIC )qry where ROW_NUM =1 and upper(Request_Type__c) = 'E-RATE'

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_ErateSalesForce")
df.count()

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'cp_master_ErateSalesForce')
