# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# DBTITLE 1,Run dataset dependencies
# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

#Parameters
dbutils.widgets.text("Environment", "UAT")
dbutils.widgets.text("NON_SENS_ADLS_ENR_UNHARM_Path",   "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/NON-SENS/1ST_PARTY/ENDUR_LNG/")
dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path",   "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/SENS/1ST_PARTY/ENDUR_LNG/")

ENV  = dbutils.widgets.get("Environment")
NON_SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("NON_SENS_ADLS_ENR_UNHARM_Path")
SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

#List of tables
non_sens_full_source_listTables_edw = ['INTERNAL_EXTERNAL', 'PARTY_CLASS', 'PARTY_STATUS', 'NO_YES', 'PARTY_FUNCTION', 'FUNCTION_TYPE']
non_sens_inc_source_listTables_edw = ['STATES', 'COUNTRY', 'PARTY_GROUP_MEMB', 'PARTY_RATING', 'CREDIT_RATING', 'PARTY_CREDIT_RATING', 'PARTY_RELATIONSHIP']
sens_inc_source_listTables_edw =   ['PARTY', 'PERSONNEL', 'PARTY_GROUP', 'PARTY_INFO']
sens_full_source_listTables_edw =   ['LEGAL_ENTITY']
adls_source_schema = 'ENDUR'
source_system = 'endur_lng'

# COMMAND ----------

#Create Dataframe and Temporary Views for Sens Inc Tables from ADLS
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_inc_source_listTables_edw])

#create dataframe for Inc load
dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

#Create Dataframe and Temporary Views for Sens Full Tables from ADLS
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_full_source_listTables_edw])

#create dataframe for Full load
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# Create Dataframe and Temporary Views for Non-Sens Inc Tables from ADLS
FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_inc_source_listTables_edw])

#create dataframe for Inc Load
dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")
  
# Create Dataframe and Temporary Views for Non-Sens Full Tables from ADLS
FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_full_source_listTables_edw])

#create dataframe for Full Load
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# DBTITLE 1,List of Tables SQL DWH
#dataset_list = ['endur_lng.ext_party_sens', 'endur_lng.ext_party_function', 'endur_lng.ext_party_relationship', 'endur_lng.ext_person_sens', 'endur_lng.ext_party_function_type', 'endur_lng.ext_party_class', 'endur_lng.ext_party_credit_rating', 'endur_lng.ext_party_group_sens', 'endur_lng.ext_party_info', 'endur_lng.ext_party_rating', 'endur_lng.ext_party_status', 'endur_lng.ext_internal_external', 'endur_lng.ext_states', 'endur_lng.ext_no_yes', 'endur_lng.ext_country', 'endur_lng.ext_credit_rating', 'endur_lng.ext_party_group_memb', 'endur_lng.ext_legal_entity_sens']
#print(CreateTempVwFromExternalTables(dataset_list))

# COMMAND ----------

# DBTITLE 1,Dataset Logic
#%sql
#create or replace temporary view vw_slmt_mrd_business_unit_master_ENDUR_LNG as 
#(
#  --Step 1.
#  with query_one as
#  (
#  SELECT DISTINCT party.party_id, 
#   int_ext.name type, 
#   pc.name party_class, 
#   party.party_class party_class_id, 
#   ps.name status, 
#   party.Short_Name, 
#   party.Long_Name, 
#   per_created.name created_by, 
#   CONCAT(per_created.first_name,(' '||per_created.last_name)) created_by_name,
#   per_updated.name updated_by, 
#   CONCAT(per_updated.first_name,(' '||per_updated.last_name)) le_updated_by_name,
#   party.Last_Update, 
#   party.party_version version, 
#   no_yes.name Agency_Activities, 
#   party.Linked_Party_Id, 
#   le.addr1 address_1, 
#   le.addr2 address_2, 
#   le.city, 
#   states.short_name state, 
#   country.name country, 
#   le.mail_code, 
#   le.phone, 
#   le.fax, 
#   le.description, 
#   le.int_ref1 internal_reference_1, 
#   le.int_ref2 internal_reference_2, 
#   le.int_ref3 internal_reference_3, 
#   pg.short_name party_group, 
#   pi_ext_sap_cust.value lng_ext_sap_customer, 
#   pi_ext_sap_ven.value lng_ext_sap_vendor, 
#   pi_int_sap_cust.value lng_int_sap_customer, 
#   pi_int_sap_ven.value lng_int_sap_vendor, 
#   pi_comp_code.value lng_company_code, 
#   CASE party.int_ext 
#     WHEN 0 
#     THEN pi_int_remit_rep.value 
#     ELSE pi_ext_remit_rep.value 
#   END remit_reprotable, 
#   pi_qgc_sap_cust.value qgc_sap_cust, 
#   pi_qgc_sap_vend.value qgc_sap_vend, 
#   pi_sgm_sap_cust.value sgm_sap_cust, 
#   pi_sgm_sap_vend.value sgm_sap_vend, 
#   pi_sgm_sap_ic_cust.value sgm_sap_ic_cust, 
#   pi_sgm_sap_ic_vend.value sgm_sap_ic_vend, 
#   pr.name party_rating, 
#   pgm.group_id, 
#   cr.rating_name
#   --+ Date of maximum end date of any load / discharge for any associated deal for any associated party agreement, 
# FROM endur_lng_ext_party_sens party
# left outer join endur_lng_ext_legal_entity_sens le on party.party_id = le.party_id
# left outer join endur_lng_ext_states states on le.state_id = states.state_id
# left outer join endur_lng_ext_country country on le.country = country.id_number
# left outer join endur_lng_ext_party_group_memb pgm on party.party_id = pgm.party_id
# left outer join endur_lng_ext_party_group_sens pg on pgm.group_id = pg.group_id
# left outer join endur_lng_ext_party_info pi_ext_sap_cust on party.party_id = pi_ext_sap_cust.party_id and  pi_ext_sap_cust.type_id  = 20176
# left outer join endur_lng_ext_party_info pi_ext_sap_ven on party.party_id          = pi_ext_sap_ven.party_id and pi_ext_sap_ven.type_id   = 20174 -- LNG Ext SAP Vendor 
# left outer join endur_lng_ext_party_info pi_int_sap_cust on party.party_id         = pi_int_sap_cust.party_id and pi_int_sap_cust.type_id  = 20177 -- LNG Int SAP Customer  
# left outer join endur_lng_ext_party_info pi_int_sap_ven on party.party_id              = pi_int_sap_ven.party_id and pi_int_sap_ven.type_id   = 20175 -- LNG Int SAP Vendor 
# left outer join endur_lng_ext_party_info pi_comp_code on party.party_id              = pi_comp_code.party_id and pi_comp_code.type_id     = 20173 -- LNG Int SAP Vendor 
# left outer join endur_lng_ext_party_info pi_int_remit_rep on party.party_id      = pi_int_remit_rep.party_id and pi_int_remit_rep.type_id = 20183 -- Remit Reportable Internal 
# left outer join endur_lng_ext_party_info pi_ext_remit_rep on party.party_id     = pi_ext_remit_rep.party_id and pi_ext_remit_rep.type_id = 20184 -- Remit Reportable External 
# left outer join endur_lng_ext_party_info pi_qgc_sap_cust on party.party_id              = pi_qgc_sap_cust.party_id and pi_qgc_sap_cust.type_id  = 20166 -- QGC SAP Customer 
# left outer join endur_lng_ext_party_info pi_qgc_sap_vend on party.party_id              = pi_qgc_sap_vend.party_id and pi_qgc_sap_vend.type_id  = 20167 -- QGC SAP Vendor 
# left outer join endur_lng_ext_party_info pi_sgm_sap_cust on party.party_id              = pi_sgm_sap_cust.party_id and pi_sgm_sap_cust.type_id  = 20149 -- SGM SAP Customer 
# left outer join endur_lng_ext_party_info pi_sgm_sap_vend on party.party_id              = pi_sgm_sap_vend.party_id and pi_sgm_sap_vend.type_id  = 20150 -- SGM SAP Vendor 
# left outer join endur_lng_ext_party_info pi_sgm_sap_ic_cust on party.party_id      = pi_sgm_sap_ic_cust.party_id and pi_sgm_sap_ic_cust.type_id  = 20188 -- SGM SAP IC Customer 
# left outer join endur_lng_ext_party_info pi_sgm_sap_ic_vend on party.party_id       = pi_sgm_sap_ic_vend.party_id and pi_sgm_sap_ic_vend.type_id  = 20189 -- SGM SAP IC Vendor 
# left outer join endur_lng_ext_party_rating pr on le.party_rating             = pr.id_number
# left outer join endur_lng_ext_party_credit_rating pcr on party.party_id  = pcr.party_id
# left outer join endur_lng_ext_credit_rating cr on pcr.rating_id = cr.rating_id,
#  endur_lng_ext_party_status ps,
#  endur_lng_ext_internal_external int_ext,
#  endur_lng_ext_person_sens per_created,
#  endur_lng_ext_person_sens per_updated,
#  endur_lng_ext_party_class pc,
#  endur_lng_ext_no_yes no_yes
# WHERE party.int_ext               =int_ext.id_number 
# AND party.party_class           = pc.id_number 
# AND party.party_status          = ps.id_number 
# AND party.inputter_id           = per_created.id_number 
# AND party.authoriser_id         = per_updated.id_number 
# AND party.Agency_Activities     = no_yes.id_number
# ),
# 
# --Step 2.
# query_two as
# (
# SELECT DISTINCT pf.party_id,  
#   p.short_name,  
#   p.int_ext,  
#   concat_ws(";", collect_list(ft.name)) as functions,  --Step 4.
#   pr.business_unit_id  
#   FROM endur_lng_ext_party_function pf 
#   left outer join endur_lng_ext_party_relationship pr on pf.party_id = pr.business_unit_id,  
#   endur_lng_ext_party_sens p,  
#   endur_lng_ext_party_function_type ft  
# WHERE pf.party_id = p.party_id  
# AND pf.function_type =ft.id_number
# group by pf.party_id, p.short_name, p.int_ext, pr.business_unit_id 
# )
# 
# -- Step 5.
# select query_one.party_id as Party_Id,
#		query_one.type as Type,
#		query_one.status as Status,
#		query_one.short_name as Short_Name,
#		query_one.long_name as Long_Name,
#		query_one.created_by as Created_By,
#		query_one.updated_by as LE_Updated_By,
#		query_one.last_update as LE_Last_Updated,
#		query_one.version as Version,
#		query_one.linked_party_id as Linked_Party_Id,
#		query_one.party_group as Party_Group,
#        query_one.lng_ext_sap_customer as LNG_Ext_SAP_Customer,
#		query_one.lng_ext_sap_vendor as LNG_Ext_SAP_Vendor,
#		query_one.lng_int_sap_customer as LNG_Int_SAP_Customer,
#		query_one.lng_int_sap_vendor as LNG_Int_SAP_Vendor,
#		query_one.lng_company_code as LNG_Company_Code,
#		query_one.remit_reprotable as Remit_Reportable,
#		query_one.qgc_sap_cust as QGC_SAP_Customer,
#		query_one.qgc_sap_vend as QGC_SAP_Vendor,
#		query_one.sgm_sap_cust as SGM_SAP_Customer,
#		query_one.sgm_sap_vend as SGM_SAP_Vendor,
#		query_one.sgm_sap_ic_cust as SGM_SAP_IC_Customer,
#		query_one.sgm_sap_ic_vend as SGM_SAP_IC_Vendor,
#        query_one.party_rating as Credit_Internal_Rating,
#		query_one.rating_name as SHELL_CREDIT_RATING,
#		query_two.functions as BU_Functions,
#        'ENDUR_LNG' as source_system
#  from query_one, query_two 
#  -- Step 3.
#  where query_one.party_class_id !=0 --/*This will exclude all Legal Entities */
#  -- Step 4.
#  and query_one.party_id=query_two.party_id)
# ;
          

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_slmt_mrd_business_unit_master_ENDUR_LNG as 
# MAGIC (
# MAGIC   --Step 1.
# MAGIC   with query_one as
# MAGIC   (
# MAGIC   SELECT DISTINCT party.party_id, 
# MAGIC    int_ext.name type, 
# MAGIC    pc.name party_class, 
# MAGIC    party.party_class party_class_id, 
# MAGIC    ps.name status, 
# MAGIC    party.Short_Name, 
# MAGIC    party.Long_Name, 
# MAGIC    per_created.name created_by, 
# MAGIC    CONCAT(per_created.first_name,(' '||per_created.last_name)) created_by_name,
# MAGIC    per_updated.name updated_by, 
# MAGIC    CONCAT(per_updated.first_name,(' '||per_updated.last_name)) le_updated_by_name,
# MAGIC    party.Last_Update, 
# MAGIC    party.party_version version, 
# MAGIC    no_yes.name Agency_Activities, 
# MAGIC    party.Linked_Party_Id, 
# MAGIC    le.addr1 address_1, 
# MAGIC    le.addr2 address_2, 
# MAGIC    le.city, 
# MAGIC    states.short_name state, 
# MAGIC    country.name country, 
# MAGIC    le.mail_code, 
# MAGIC    le.phone, 
# MAGIC    le.fax, 
# MAGIC    le.description, 
# MAGIC    le.int_ref1 internal_reference_1, 
# MAGIC    le.int_ref2 internal_reference_2, 
# MAGIC    le.int_ref3 internal_reference_3, 
# MAGIC    pg.short_name party_group, 
# MAGIC    pi_sap_cust.value lng_sap_customer, 
# MAGIC    pi_sap_ven.value lng_sap_vendor, 
# MAGIC    pi_int_sap_cust.value lng_int_sap_customer, 
# MAGIC    pi_int_sap_ven.value lng_int_sap_vendor, 
# MAGIC    pi_comp_code.value lng_company_code, 
# MAGIC    CASE party.int_ext 
# MAGIC      WHEN 0 
# MAGIC      THEN pi_int_remit_rep.value 
# MAGIC      ELSE pi_remit_rep.value 
# MAGIC    END remit_reprotable, 
# MAGIC    pi_qgc_sap_cust.value qgc_sap_cust, 
# MAGIC    pi_qgc_sap_vend.value qgc_sap_vend, 
# MAGIC    pi_sgm_sap_cust.value sgm_sap_cust, 
# MAGIC    pi_sgm_sap_vend.value sgm_sap_vend, 
# MAGIC    pi_sgm_sap_ic_cust.value sgm_sap_ic_cust, 
# MAGIC    pi_sgm_sap_ic_vend.value sgm_sap_ic_vend, 
# MAGIC    pr.name party_rating, 
# MAGIC    pgm.group_id, 
# MAGIC    cr.rating_name
# MAGIC    --+ Date of maximum end date of any load / discharge for any associated deal for any associated party agreement, 
# MAGIC  FROM endur_lng_party party
# MAGIC  left outer join endur_lng_legal_entity le on party.party_id = le.party_id
# MAGIC  left outer join endur_lng_states states on le.state_id = states.state_id
# MAGIC  left outer join endur_lng_country country on le.country = country.id_number
# MAGIC  left outer join endur_lng_party_group_memb pgm on party.party_id = pgm.party_id
# MAGIC  left outer join endur_lng_party_group pg on pgm.group_id = pg.group_id
# MAGIC  left outer join endur_lng_party_info pi_sap_cust on party.party_id = pi_sap_cust.party_id and  pi_sap_cust.type_id  = 20176
# MAGIC  left outer join endur_lng_party_info pi_sap_ven on party.party_id          = pi_sap_ven.party_id and pi_sap_ven.type_id   = 20174 -- LNG Ext SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_int_sap_cust on party.party_id         = pi_int_sap_cust.party_id and pi_int_sap_cust.type_id  = 20177 -- LNG Int SAP Customer  
# MAGIC  left outer join endur_lng_party_info pi_int_sap_ven on party.party_id              = pi_int_sap_ven.party_id and pi_int_sap_ven.type_id   = 20175 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_comp_code on party.party_id              = pi_comp_code.party_id and pi_comp_code.type_id     = 20173 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_int_remit_rep on party.party_id      = pi_int_remit_rep.party_id and pi_int_remit_rep.type_id = 20183 -- Remit Reportable Internal 
# MAGIC  left outer join endur_lng_party_info pi_remit_rep on party.party_id     = pi_remit_rep.party_id and pi_remit_rep.type_id = 20184 -- Remit Reportable External 
# MAGIC  left outer join endur_lng_party_info pi_qgc_sap_cust on party.party_id              = pi_qgc_sap_cust.party_id and pi_qgc_sap_cust.type_id  = 20166 -- QGC SAP Customer 
# MAGIC  left outer join endur_lng_party_info pi_qgc_sap_vend on party.party_id              = pi_qgc_sap_vend.party_id and pi_qgc_sap_vend.type_id  = 20167 -- QGC SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_cust on party.party_id              = pi_sgm_sap_cust.party_id and pi_sgm_sap_cust.type_id  = 20149 -- SGM SAP Customer 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_vend on party.party_id              = pi_sgm_sap_vend.party_id and pi_sgm_sap_vend.type_id  = 20150 -- SGM SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_ic_cust on party.party_id      = pi_sgm_sap_ic_cust.party_id and pi_sgm_sap_ic_cust.type_id  = 20188 -- SGM SAP IC Customer 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_ic_vend on party.party_id       = pi_sgm_sap_ic_vend.party_id and pi_sgm_sap_ic_vend.type_id  = 20189 -- SGM SAP IC Vendor 
# MAGIC  left outer join endur_lng_party_rating pr on le.party_rating             = pr.id_number
# MAGIC  left outer join endur_lng_party_credit_rating pcr on party.party_id  = pcr.party_id
# MAGIC  left outer join endur_lng_credit_rating cr on pcr.rating_id = cr.rating_id,
# MAGIC   endur_lng_party_status ps,
# MAGIC   endur_lng_internal_external int_ext,
# MAGIC   endur_lng_personnel per_created,
# MAGIC   endur_lng_personnel per_updated,
# MAGIC   endur_lng_party_class pc,
# MAGIC   endur_lng_no_yes no_yes
# MAGIC  WHERE party.int_ext               =int_ext.id_number 
# MAGIC  AND party.party_class           = pc.id_number 
# MAGIC  AND party.party_status          = ps.id_number 
# MAGIC  AND party.inputter_id           = per_created.id_number 
# MAGIC  AND party.authoriser_id         = per_updated.id_number 
# MAGIC  AND party.Agency_Activities     = no_yes.id_number
# MAGIC  ),
# MAGIC  
# MAGIC  --Step 3.
# MAGIC  query_two as
# MAGIC  (
# MAGIC  SELECT DISTINCT pf.party_id,  
# MAGIC    p.short_name,  
# MAGIC    p.int_ext,  
# MAGIC    concat_ws(";", collect_list(ft.name)) as functions,  --Step 4.
# MAGIC    pr.business_unit_id  
# MAGIC    FROM endur_lng_party_function pf 
# MAGIC    left outer join endur_lng_party_relationship pr on pf.party_id = pr.business_unit_id,  
# MAGIC    endur_lng_party p,  
# MAGIC    endur_lng_function_type ft  
# MAGIC  WHERE pf.party_id = p.party_id  
# MAGIC  AND pf.function_type =ft.id_number
# MAGIC  group by pf.party_id, p.short_name, p.int_ext, pr.business_unit_id 
# MAGIC  ),
# MAGIC  
# MAGIC  -- Step 5.
# MAGIC  select query_one.party_id as Party_Id,
# MAGIC 		query_one.type as Type,
# MAGIC 		query_one.status as Status,
# MAGIC 		query_one.short_name as Short_Name,
# MAGIC 		query_one.long_name as Long_Name,
# MAGIC 		query_one.created_by as Created_By,
# MAGIC 		query_one.updated_by as LE_Updated_By,
# MAGIC 		query_one.last_update as LE_Last_Updated,
# MAGIC 		query_one.version as Version,
# MAGIC 		query_one.linked_party_id as Linked_Party_Id,
# MAGIC 		query_one.party_group as Party_Group,
# MAGIC         query_one.lng_sap_customer as LNG_SAP_Customer,
# MAGIC 		query_one.lng_sap_vendor as LNG_SAP_Vendor,
# MAGIC 		query_one.lng_int_sap_customer as LNG_Int_SAP_Customer,
# MAGIC 		query_one.lng_int_sap_vendor as LNG_Int_SAP_Vendor,
# MAGIC 		query_one.lng_company_code as LNG_Company_Code,
# MAGIC 		query_one.remit_reprotable as Remit_Reportable,
# MAGIC 		query_one.qgc_sap_cust as QGC_SAP_Customer,
# MAGIC 		query_one.qgc_sap_vend as QGC_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_cust as SGM_SAP_Customer,
# MAGIC 		query_one.sgm_sap_vend as SGM_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_ic_cust as SGM_SAP_IC_Customer,
# MAGIC 		query_one.sgm_sap_ic_vend as SGM_SAP_IC_Vendor,
# MAGIC         query_one.party_rating as Credit_Internal_Rating,
# MAGIC 		query_one.rating_name as SHELL_CREDIT_RATING,
# MAGIC 		query_two.functions as BU_Functions,
# MAGIC         'ENDUR_LNG' as source_system
# MAGIC   from query_one, query_two 
# MAGIC   -- Step 2.
# MAGIC   where query_one.party_class_id !=0 --/*This will exclude all Legal Entities */
# MAGIC   -- Step 4.
# MAGIC   and query_one.party_id=query_two.party_id)
# MAGIC  ;
# MAGIC           

# COMMAND ----------

# DBTITLE 1,Testing
df = spark.sql("select * from vw_slmt_mrd_business_unit_master_ENDUR_LNG")

# COMMAND ----------

df.count()

# COMMAND ----------

# DBTITLE 1,Load dataset into SQL DB
RefreshSqlDbTbl('pty_counterparty', 'slmt_mrd_business_unit_master', 'ENDUR_LNG')
