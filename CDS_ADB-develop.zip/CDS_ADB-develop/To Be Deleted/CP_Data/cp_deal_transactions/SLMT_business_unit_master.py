# Databricks notebook source
# DBTITLE 1,Run dataset dependencies
# MAGIC %run "./Common/dataset_library"

# COMMAND ----------

# DBTITLE 1,List of Tables SQL DWH
dataset_list = ['endur_lng.ext_party_sens', 'endur_lng.ext_party_function', 'endur_lng.ext_party_relationship', 'endur_lng.ext_person_sens', 'endur_lng.ext_party_function_type', 'endur_lng.ext_party_class', 'endur_lng.ext_party_credit_rating', 'endur_lng.ext_party_group_sens', 'endur_lng.ext_party_info', 'endur_lng.ext_party_rating', 'endur_lng.ext_party_status', 'endur_lng.ext_internal_external', 'endur_lng.ext_states', 'endur_lng.ext_no_yes', 'endur_lng.ext_country', 'endur_lng.ext_credit_rating', 'endur_lng.ext_party_group_memb', 'endur_lng.ext_legal_entity_sens']
print(CreateTempVwFromExternalTables(dataset_list))

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from endur_lng_ext_person_sens

# COMMAND ----------

# DBTITLE 1,Dataset Logic
# MAGIC %sql
# MAGIC create or replace temporary view vw_slmt_mrd_business_unit_master_ENDUR_LNG as 
# MAGIC (
# MAGIC   --Step 1.
# MAGIC   with query_one as
# MAGIC   (
# MAGIC   SELECT DISTINCT party.party_id, 
# MAGIC    int_ext.name type, 
# MAGIC    pc.name party_class, 
# MAGIC    party.party_class party_class_id, 
# MAGIC    ps.name status, 
# MAGIC    party.Short_Name, 
# MAGIC    party.Long_Name, 
# MAGIC    per_created.name created_by, 
# MAGIC    CONCAT(per_created.first_name,(' '||per_created.last_name)) created_by_name,
# MAGIC    per_updated.name updated_by, 
# MAGIC    CONCAT(per_updated.first_name,(' '||per_updated.last_name)) le_updated_by_name,
# MAGIC    party.Last_Update, 
# MAGIC    party.party_version version, 
# MAGIC    no_yes.name Agency_Activities, 
# MAGIC    party.Linked_Party_Id, 
# MAGIC    le.addr1 address_1, 
# MAGIC    le.addr2 address_2, 
# MAGIC    le.city, 
# MAGIC    states.short_name state, 
# MAGIC    country.name country, 
# MAGIC    le.mail_code, 
# MAGIC    le.phone, 
# MAGIC    le.fax, 
# MAGIC    le.description, 
# MAGIC    le.int_ref1 internal_reference_1, 
# MAGIC    le.int_ref2 internal_reference_2, 
# MAGIC    le.int_ref3 internal_reference_3, 
# MAGIC    pg.short_name party_group, 
# MAGIC    pi_ext_sap_cust.value lng_ext_sap_customer, 
# MAGIC    pi_ext_sap_ven.value lng_ext_sap_vendor, 
# MAGIC    pi_int_sap_cust.value lng_int_sap_customer, 
# MAGIC    pi_int_sap_ven.value lng_int_sap_vendor, 
# MAGIC    pi_comp_code.value lng_company_code, 
# MAGIC    CASE party.int_ext 
# MAGIC      WHEN 0 
# MAGIC      THEN pi_int_remit_rep.value 
# MAGIC      ELSE pi_ext_remit_rep.value 
# MAGIC    END remit_reprotable, 
# MAGIC    pi_qgc_sap_cust.value qgc_sap_cust, 
# MAGIC    pi_qgc_sap_vend.value qgc_sap_vend, 
# MAGIC    pi_sgm_sap_cust.value sgm_sap_cust, 
# MAGIC    pi_sgm_sap_vend.value sgm_sap_vend, 
# MAGIC    pi_sgm_sap_ic_cust.value sgm_sap_ic_cust, 
# MAGIC    pi_sgm_sap_ic_vend.value sgm_sap_ic_vend, 
# MAGIC    pr.name party_rating, 
# MAGIC    pgm.group_id, 
# MAGIC    cr.rating_name
# MAGIC    --+ Date of maximum end date of any load / discharge for any associated deal for any associated party agreement, 
# MAGIC  FROM endur_lng_ext_party_sens party
# MAGIC  left outer join endur_lng_ext_legal_entity_sens le on party.party_id = le.party_id
# MAGIC  left outer join endur_lng_ext_states states on le.state_id = states.state_id
# MAGIC  left outer join endur_lng_ext_country country on le.country = country.id_number
# MAGIC  left outer join endur_lng_ext_party_group_memb pgm on party.party_id = pgm.party_id
# MAGIC  left outer join endur_lng_ext_party_group_sens pg on pgm.group_id = pg.group_id
# MAGIC  left outer join endur_lng_ext_party_info pi_ext_sap_cust on party.party_id = pi_ext_sap_cust.party_id and  pi_ext_sap_cust.type_id  = 20176
# MAGIC  left outer join endur_lng_ext_party_info pi_ext_sap_ven on party.party_id          = pi_ext_sap_ven.party_id and pi_ext_sap_ven.type_id   = 20174 -- LNG Ext SAP Vendor 
# MAGIC  left outer join endur_lng_ext_party_info pi_int_sap_cust on party.party_id         = pi_int_sap_cust.party_id and pi_int_sap_cust.type_id  = 20177 -- LNG Int SAP Customer  
# MAGIC  left outer join endur_lng_ext_party_info pi_int_sap_ven on party.party_id              = pi_int_sap_ven.party_id and pi_int_sap_ven.type_id   = 20175 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_ext_party_info pi_comp_code on party.party_id              = pi_comp_code.party_id and pi_comp_code.type_id     = 20173 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_ext_party_info pi_int_remit_rep on party.party_id      = pi_int_remit_rep.party_id and pi_int_remit_rep.type_id = 20183 -- Remit Reportable Internal 
# MAGIC  left outer join endur_lng_ext_party_info pi_ext_remit_rep on party.party_id     = pi_ext_remit_rep.party_id and pi_ext_remit_rep.type_id = 20184 -- Remit Reportable External 
# MAGIC  left outer join endur_lng_ext_party_info pi_qgc_sap_cust on party.party_id              = pi_qgc_sap_cust.party_id and pi_qgc_sap_cust.type_id  = 20166 -- QGC SAP Customer 
# MAGIC  left outer join endur_lng_ext_party_info pi_qgc_sap_vend on party.party_id              = pi_qgc_sap_vend.party_id and pi_qgc_sap_vend.type_id  = 20167 -- QGC SAP Vendor 
# MAGIC  left outer join endur_lng_ext_party_info pi_sgm_sap_cust on party.party_id              = pi_sgm_sap_cust.party_id and pi_sgm_sap_cust.type_id  = 20149 -- SGM SAP Customer 
# MAGIC  left outer join endur_lng_ext_party_info pi_sgm_sap_vend on party.party_id              = pi_sgm_sap_vend.party_id and pi_sgm_sap_vend.type_id  = 20150 -- SGM SAP Vendor 
# MAGIC  left outer join endur_lng_ext_party_info pi_sgm_sap_ic_cust on party.party_id      = pi_sgm_sap_ic_cust.party_id and pi_sgm_sap_ic_cust.type_id  = 20188 -- SGM SAP IC Customer 
# MAGIC  left outer join endur_lng_ext_party_info pi_sgm_sap_ic_vend on party.party_id       = pi_sgm_sap_ic_vend.party_id and pi_sgm_sap_ic_vend.type_id  = 20189 -- SGM SAP IC Vendor 
# MAGIC  left outer join endur_lng_ext_party_rating pr on le.party_rating             = pr.id_number
# MAGIC  left outer join endur_lng_ext_party_credit_rating pcr on party.party_id  = pcr.party_id
# MAGIC  left outer join endur_lng_ext_credit_rating cr on pcr.rating_id = cr.rating_id,
# MAGIC   endur_lng_ext_party_status ps,
# MAGIC   endur_lng_ext_internal_external int_ext,
# MAGIC   endur_lng_ext_person_sens per_created,
# MAGIC   endur_lng_ext_person_sens per_updated,
# MAGIC   endur_lng_ext_party_class pc,
# MAGIC   endur_lng_ext_no_yes no_yes
# MAGIC  WHERE party.int_ext               =int_ext.id_number 
# MAGIC  AND party.party_class           = pc.id_number 
# MAGIC  AND party.party_status          = ps.id_number 
# MAGIC  AND party.inputter_id           = per_created.id_number 
# MAGIC  AND party.authoriser_id         = per_updated.id_number 
# MAGIC  AND party.Agency_Activities     = no_yes.id_number
# MAGIC  ),
# MAGIC  
# MAGIC  --Step 2.
# MAGIC  query_two as
# MAGIC  (
# MAGIC  SELECT DISTINCT pf.party_id,  
# MAGIC    p.short_name,  
# MAGIC    p.int_ext,  
# MAGIC    concat_ws(";", collect_list(ft.name)) as functions,  --Step 4.
# MAGIC    pr.business_unit_id  
# MAGIC    FROM endur_lng_ext_party_function pf 
# MAGIC    left outer join endur_lng_ext_party_relationship pr on pf.party_id = pr.business_unit_id,  
# MAGIC    endur_lng_ext_party_sens p,  
# MAGIC    endur_lng_ext_party_function_type ft  
# MAGIC  WHERE pf.party_id = p.party_id  
# MAGIC  AND pf.function_type =ft.id_number
# MAGIC  group by pf.party_id, p.short_name, p.int_ext, pr.business_unit_id 
# MAGIC  )
# MAGIC  
# MAGIC  -- Step 5.
# MAGIC  select query_one.party_id as Party_Id,
# MAGIC 		query_one.type as Type,
# MAGIC 		query_one.status as Status,
# MAGIC 		query_one.short_name as Short_Name,
# MAGIC 		query_one.long_name as Long_Name,
# MAGIC 		query_one.created_by as Created_By,
# MAGIC 		query_one.updated_by as LE_Updated_By,
# MAGIC 		query_one.last_update as LE_Last_Updated,
# MAGIC 		query_one.version as Version,
# MAGIC 		query_one.linked_party_id as Linked_Party_Id,
# MAGIC 		query_one.party_group as Party_Group,
# MAGIC         query_one.lng_ext_sap_customer as LNG_Ext_SAP_Customer,
# MAGIC 		query_one.lng_ext_sap_vendor as LNG_Ext_SAP_Vendor,
# MAGIC 		query_one.lng_int_sap_customer as LNG_Int_SAP_Customer,
# MAGIC 		query_one.lng_int_sap_vendor as LNG_Int_SAP_Vendor,
# MAGIC 		query_one.lng_company_code as LNG_Company_Code,
# MAGIC 		query_one.remit_reprotable as Remit_Reportable,
# MAGIC 		query_one.qgc_sap_cust as QGC_SAP_Customer,
# MAGIC 		query_one.qgc_sap_vend as QGC_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_cust as SGM_SAP_Customer,
# MAGIC 		query_one.sgm_sap_vend as SGM_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_ic_cust as SGM_SAP_IC_Customer,
# MAGIC 		query_one.sgm_sap_ic_vend as SGM_SAP_IC_Vendor,
# MAGIC         query_one.party_rating as Credit_Internal_Rating,
# MAGIC 		query_one.rating_name as SHELL_CREDIT_RATING,
# MAGIC 		query_two.functions as BU_Functions,
# MAGIC         'ENDUR_LNG' as source_system
# MAGIC   from query_one, query_two 
# MAGIC   -- Step 3.
# MAGIC   where query_one.party_class_id !=0 --/*This will exclude all Legal Entities */
# MAGIC   -- Step 4.
# MAGIC   and query_one.party_id=query_two.party_id)
# MAGIC  ;
# MAGIC           

# COMMAND ----------

# DBTITLE 1,Testing
df = spark.sql("select * from vw_slmt_mrd_business_unit_master_ENDUR_LNG")

# COMMAND ----------

df.count()

# COMMAND ----------

# DBTITLE 1,Load dataset into SQL DB
RefreshSqlDbTbl('pty_counterparty', 'slmt_mrd_business_unit_master', 'ENDUR_LNG')
