# Databricks notebook source
# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

sens_inc_source_listTables = ['Z_RISK_TASKFORCECPDATA']
adls_source_schema =  'ZAINET'
source_system = 'ALIGNE'

# COMMAND ----------

# DBTITLE 1,Get Parameter Values
dbutils.widgets.text("Environment", "DEV")
dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path", "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/SENS/1ST_PARTY/ALIGNE")

ENV  = dbutils.widgets.get("Environment")
SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for Sens Full Datasets
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_inc_source_listTables])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

print(dataframedict)
print(FilePathDict)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_aligne_risk_taskforcedata_aligne as
# MAGIC (
# MAGIC with in_qry as
# MAGIC     (
# MAGIC         select c1_aud_buskey, max(meta_created_dttm) as meta_created_dttm
# MAGIC         from aligne_z_risk_taskforcecpdata
# MAGIC         group by c1_aud_buskey, meta_created_dttm
# MAGIC     )
# MAGIC select 
# MAGIC       c0_report_dat as report_date
# MAGIC     , c1_aud_buskey as deal_contract_no
# MAGIC     , c2_house_id as trading_entity
# MAGIC     , c3_house_fullname as trading_entity_long_name
# MAGIC     , c4_trade_type_dsc as product_trade
# MAGIC     , c5_trade_type3 as instrument_type
# MAGIC     , c6_cpty_acct as cpty_account_number
# MAGIC     , c7_cpty_descr as cpty_long_name
# MAGIC     , c8__buy_sell as buy_sell_indicator
# MAGIC     , c9_trader_name as trader_name
# MAGIC     , c10_book_attr1 as trading_desk
# MAGIC     , c11__amt as volume_traded
# MAGIC     , c12_amt_unit as volume_uom
# MAGIC     , c13_value_func as value_of_deal
# MAGIC     , c14__cdy as price_currency
# MAGIC     , c15_trade_date as trade_date
# MAGIC     , c16_del_datestart as delivery_datestart
# MAGIC     , c17_del_dateend as delivery_dateend
# MAGIC     , c18_manum as contract
# MAGIC     , c19__cdy_attr1_desc as loaded_ctry_code
# MAGIC     , c20__cdy_attr1_desc as discharge_ctry_code
# MAGIC     , c21_cpty_shortname as cpty_short_name
# MAGIC     , c22_cpty_sub_category_dsc as cpty_sub_category_desc
# MAGIC     , c23_numrec as num_of_records
# MAGIC     , meta_created_dttm as meta_created_dttm
# MAGIC     , 'ALIGNE' as source_system
# MAGIC from
# MAGIC       aligne_z_risk_taskforcecpdata ar
# MAGIC       where 
# MAGIC       exists
# MAGIC         (
# MAGIC         select 1
# MAGIC         from in_qry
# MAGIC         where ar.c1_aud_buskey = in_qry.c1_aud_buskey and ar.meta_created_dttm = in_qry.meta_created_dttm
# MAGIC         )
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_aligne_risk_taskforcedata_aligne

# COMMAND ----------

df = spark.sql("select * from vw_aligne_risk_taskforcedata_aligne")

# COMMAND ----------

RefreshSqlDbTbl('pty_counterparty', 'aligne_risk_taskforcedata', 'aligne')

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from aligne_z_risk_taskforcecpdata
