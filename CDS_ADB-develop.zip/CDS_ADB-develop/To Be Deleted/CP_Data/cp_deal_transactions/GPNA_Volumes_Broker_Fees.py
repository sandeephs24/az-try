# Databricks notebook source
# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

sens_full_source_listTables = ['PARTY', 'PHYS_HEADER']
sens_inc_source_listTables = ['PERSONNEL', 'AB_TRAN', 'AB_TRAN_PROVISIONAL', 'GAS_PHYS_PARAM', 'PARAMETER', 'PHYSCASH', 'PROFILE']
non_sens_full_source_listTables = ['BUY_SELL']
non_sens_inc_source_listTables = ['CFLOW_TYPE', 'CURRENCY', 'GAS_PHYS_LOCATION', 'IDX_UNIT', 'INSTRUMENTS', 'PORTFOLIO', 'PROV_TYPE']
adls_source_schema =  'ENDUR'
source_system = 'gpna'

# COMMAND ----------

# DBTITLE 1,Get Parameter Values
dbutils.widgets.text("Environment", "UAT")
dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path", "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/SENS/1ST_PARTY/ENDUR_GP_NA")
dbutils.widgets.text("NON_SENS_ADLS_ENR_UNHARM_Path", "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/NON-SENS/1ST_PARTY/ENDUR_GP_NA")

ENV  = dbutils.widgets.get("Environment")
SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")
NON_SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("NON_SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for Sens Full Datasets
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_full_source_listTables])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for Sens Inc Datasets
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_inc_source_listTables])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for Non-Sens Full Datasets
FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_full_source_listTables])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for Non-Sens Inc Datasets
FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_inc_source_listTables])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_gpna_volumes_broker_fees_ENDUR_GP_NA as
# MAGIC select  
# MAGIC       abt.broker_id
# MAGIC     , bbu.LONG_NAME as broker_long_name
# MAGIC     , ab.internal_lentity
# MAGIC     , ile.long_name as int_le_long_name
# MAGIC     , i.name as ins_type
# MAGIC     , cast(ab.settle_date as date) as cflow_date
# MAGIC     , cast(ab.trade_date as date) as trade_date
# MAGIC     , cast(ab.start_date as date) as contract_start_date
# MAGIC     , cast(ab.maturity_date as date) as contract_end_date
# MAGIC     , 'Pay' as pay_rec
# MAGIC     , abs(abt.reserved_amt) as broker_fee_amount
# MAGIC     , ab.deal_tracking_num
# MAGIC     , cur.name as currency
# MAGIC     , pt.NAME as prov_type
# MAGIC     , po.name as trading_desk
# MAGIC     , per.NAME as trader_name
# MAGIC     , ab.meta_created_dttm as meta_created_dttm
# MAGIC     , 'ENDUR_GP_NA' as source_system
# MAGIC     from 
# MAGIC       gpna_ab_tran ab
# MAGIC     , gpna_ab_tran_provisional abt
# MAGIC     , gpna_instruments i
# MAGIC     , gpna_party bbu
# MAGIC     , gpna_party ile
# MAGIC     , gpna_prov_type pt
# MAGIC     , gpna_currency cur
# MAGIC     , gpna_portfolio po
# MAGIC     , gpna_personnel per
# MAGIC where ab.current_flag = 1
# MAGIC and ab.tran_status <> 5 --Not cancelled
# MAGIC and ab.offset_tran_type = 0 --3P deals only
# MAGIC and cast(ab.trade_date as date) >= '2018-01-01' 
# MAGIC and ab.tran_num = abt.tran_num
# MAGIC and ab.ins_type = i.id_number
# MAGIC and abt.prov_type = pt.ID_NUMBER
# MAGIC and ab.external_bunit = bbu.party_id
# MAGIC and ab.internal_lentity = ile.party_id
# MAGIC and ab.currency = cur.id_number
# MAGIC and ab.internal_portfolio = po.id_number
# MAGIC and ab.internal_contact = per.ID_NUMBER

# COMMAND ----------

df = spark.sql("select * from vw_gpna_volumes_broker_fees_ENDUR_GP_NA")

# COMMAND ----------

RefreshSqlDbTbl('pty_counterparty', 'gpna_volumes_broker_fees', 'ENDUR_GP_NA')
