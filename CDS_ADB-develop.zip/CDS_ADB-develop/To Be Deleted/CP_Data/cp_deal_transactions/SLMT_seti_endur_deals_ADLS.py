# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

#Parameters
dbutils.widgets.text("Environment", "UAT")
dbutils.widgets.text("NON_SENS_ADLS_ENR_UNHARM_Path",   "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/NON-SENS/1ST_PARTY/EDW/")
dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path",   "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/SENS/1ST_PARTY/EDW/")

ENV  = dbutils.widgets.get("Environment")
NON_SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("NON_SENS_ADLS_ENR_UNHARM_Path")
SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

#List of tables
non_sens_full_source_listTables_edw = ['FACT_DEAL_SETI', 'DIM_INS_TYPE','DIM_COUNTERPARTY', 'DIM_LEGAL_ENTITY', 'DIM_PORTFOLIO', 'DIM_PHYS_GAS_LOCATION', 'DIM_BUSINESS_UNIT', 'DIM_EXT_BUSINESS_UNIT', 'DIM_VOLUME_UNIT', 'DIM_TRADER', 'DIM_CURRENCY', 'DIM_CASH_FLOW']
#non_sens_inc_source_listTables_edw = ['STATES', 'COUNTRY', 'PARTY_GROUP_MEMB', 'PARTY_RATING', 'CREDIT_RATING', 'PARTY_CREDIT_RATING', 'PARTY_RELATIONSHIP']
sens_inc_source_listTables_edw =   ['FACT_DEAL_PNL']
#sens_full_source_listTables_edw =   ['LEGAL_ENTITY']
adls_source_schema = 'EDW'
source_system = 'edw'

# COMMAND ----------

#Create Dataframe and Temporary Views for Sens Inc Tables from ADLS
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_inc_source_listTables_edw])

#create dataframe for Inc load
dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# Create Dataframe and Temporary Views for Non-Sens Full Tables from ADLS
FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_full_source_listTables_edw])

#create dataframe for Full Load
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

#dataset_list = ['edw.ext_dim_counterparty', 'edw.ext_dim_ext_business_unit', 'edw.ext_dim_legal_entity','edw.ext_dim_business_unit', 'edw.ext_dim_portfolio', 'edw.ext_dim_trader', 'edw.ext_dim_ins_type', 'edw.ext_fact_deal_seti', 'edw.ext_dim_phys_gas_location', 'edw.ext_dim_cash_flow', 'edw.ext_dim_volume_unit', 'edw.ext_dim_currency', 'edw.ext_fact_deal_pnl_sens' ]
#print(CreateTempVwFromExternalTables(dataset_list))

#non_sens_source_listTables_edw = ['FACT_DEAL_SETI', 'DIM_INS_TYPE INS','DIM_COUNTERPARTY', 'dim_legal_entity', 'dim_Portfolio', 'DIM_PHYS_GAS_LOCATION', 'DIM_BUSINESS_UNIT', 'DIM_EXT_BUSINESS_UNIT', 'DIM_VOLUME_UNIT', 'DIM_TRADER', 'DIM_CURRENCY', 'DIM_CASH_FLOW']
#sens_source_listTables_edw =   ['FACT_DEAL_PNL']
#adls_source_schema = 'EDW'
#source_system = 'edw'

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_slmt_seti_endur_deals_EDW as 
# MAGIC (
# MAGIC with FDP as(  SELECT MIN (REPORT_DATE) AS REP_DATE,
# MAGIC                      MIN(TRAN_NUM) AS TRAN_NUM,
# MAGIC                      DEAL_NUM
# MAGIC                 FROM EDW_FACT_DEAL_PNL FDP
# MAGIC                WHERE     FDP.REPORT_DATE >=
# MAGIC                             '2018-01-01 00:00:00.000'
# MAGIC                      AND DEAL_NUM IN (SELECT DISTINCT
# MAGIC                                              DEAL_NUM
# MAGIC                                         FROM EDW_FACT_DEAL_SETI d
# MAGIC                                        WHERE TRADE_DATE >
# MAGIC                                                 '2018-01-01 00:00:00.000')
# MAGIC             GROUP BY DEAL_NUM ),
# MAGIC     in_qry as
# MAGIC     (  SELECT DEAL_NUM,
# MAGIC               MIN (TRAN_NUM) AS FIRST_TRAN
# MAGIC               FROM EDW_FACT_DEAL_SETI d
# MAGIC               WHERE TRADE_DATE > '2018-01-01 00:00:00.000'
# MAGIC               GROUP BY DEAL_NUM) /* ORIGINAL DEAL VERSION ONLY */
# MAGIC          
# MAGIC          
# MAGIC          SELECT CPTY.COUNTERPARTY_LONGNAME,
# MAGIC          CPTY.COUNTERPARTY_ID,
# MAGIC          XBU.BUSINESS_UNIT AS COUNTERPARTY_BU,
# MAGIC          LE.LEGAL_ENTITY_LONGNAME ,
# MAGIC          LE.LEGAL_ENTITY_ID,
# MAGIC          BU.BUSINESS_UNIT AS INTERNAL_BU,
# MAGIC          P.PORTFOLIO_LONGNAME,
# MAGIC          DT.TRADER,
# MAGIC          DT.TRADER_ID,
# MAGIC          INS.INS_TYPE,
# MAGIC          Case 
# MAGIC          when (d.buy_sell_id= 0) then 'BUY'
# MAGIC          when (d.buy_sell_id= 1) then'SELL' 
# MAGIC          END BUY_SELL,
# MAGIC          Case 
# MAGIC          when (D.PAY_REC_ID= 1) then 'PAY'
# MAGIC          when (D.PAY_REC_ID=0) then 'RECEIVE'
# MAGIC          END PAY_REC,
# MAGIC          LOC.LOCATION_NAME,
# MAGIC          date_format(D.TRADE_DATE, 'yyyyMM') AS TRADE_MONTH,
# MAGIC          PNL.CASH_FLOW,
# MAGIC          SUM (D.QUANTITY) AS DEAL_QUANTITY,
# MAGIC          VU.VOLUME_UNIT AS DEAL_QUANTITY_UNIT,
# MAGIC          SUM (PNL.TOTAL_NOTIONAL_VALUE) AS TOTAL_NOTIONAL_VALUE,
# MAGIC          DCY.CURRENCY AS PAYMENT_CURRENCY,
# MAGIC          COUNT (DISTINCT D.DEAL_NUM) AS DEAL_COUNT,
# MAGIC          'ENDUR_SLMT' as Source_System
# MAGIC          
# MAGIC          FROM EDW_FACT_DEAL_SETI d
# MAGIC             left outer join (SELECT PNL.REPORT_DATE,
# MAGIC                    PNL.DEAL_NUM,
# MAGIC                    PNL.TRAN_NUM,
# MAGIC                    PARAM_NUM,
# MAGIC                    PROFILE_NUM,
# MAGIC                    CF.CASH_FLOW,
# MAGIC                    SUM (RST_TOTAL_NOTIONAL_VALUE) AS TOTAL_NOTIONAL_VALUE
# MAGIC               FROM EDW_FACT_DEAL_PNL PNL, EDW_DIM_CASH_FLOW CF
# MAGIC               WHERE EXISTS (SELECT * from FDP
# MAGIC                            where PNL.REPORT_DATE =  FDP.REP_DATE
# MAGIC                            and PNL.TRAN_NUM=FDP.TRAN_NUM and PNL.DEAL_NUM=FDP.DEAL_NUM
# MAGIC                             )
# MAGIC                    AND CF.CASH_FLOW_ID = PNL.RST_CASH_FLOW_TYPE_ID
# MAGIC           GROUP BY PNL.REPORT_DATE,
# MAGIC                    PNL.DEAL_NUM,
# MAGIC                    PNL.TRAN_NUM,
# MAGIC                    PARAM_NUM,
# MAGIC                    PROFILE_NUM,
# MAGIC                    CF.CASH_FLOW) PNL /* FIRST AVAIALBLE DEAL VALUATION ONLY  */
# MAGIC          on D.TRAN_NUM = PNL.TRAN_NUM AND D.PARAM_NUM = PNL.PARAM_NUM AND D.PROFILE_NUM = PNL.PROFILE_NUM,
# MAGIC         
# MAGIC          EDW_DIM_INS_TYPE INS,
# MAGIC          EDW_DIM_COUNTERPARTY CPTY,
# MAGIC          EDW_dim_legal_entity le,
# MAGIC          EDW_dim_Portfolio p,
# MAGIC          EDW_DIM_PHYS_GAS_LOCATION LOC,
# MAGIC          EDW_DIM_BUSINESS_UNIT BU,
# MAGIC          EDW_DIM_EXT_BUSINESS_UNIT XBU,
# MAGIC          EDW_DIM_VOLUME_UNIT VU,
# MAGIC          EDW_DIM_TRADER DT,
# MAGIC          EDW_DIM_CURRENCY DCY
# MAGIC          
# MAGIC   WHERE  D.TRADE_DATE >= '2018-01-01 00:00:00.000'
# MAGIC          AND INS.INS_TYPE_ID = D.INS_TYPE_ID
# MAGIC          AND cpty.counterparty_id = d.counterparty_id
# MAGIC          AND le.LEGAL_ENTITY_ID = d.LEGAL_ENTITY_ID
# MAGIC          AND p.portfolio_id = d.portfolio_id
# MAGIC          AND D.PHYS_GAS_LOCATION_ID = LOC.LOCATION_ID
# MAGIC          AND D.BUSINESS_UNIT_ID = BU.BUSINESS_UNIT_ID
# MAGIC          AND D.EXT_BUSINESS_UNIT_ID = XBU.EXT_BUSINESS_UNIT_ID
# MAGIC          AND D.TRADER_ID = DT.TRADER_ID
# MAGIC          AND D.QUANTITY_UNIT_ID = VU.VOLUME_UNIT_ID
# MAGIC          AND D.PAYMENT_CURRENCY_ID = DCY.CURRENCY_ID
# MAGIC          AND EXISTS (select * from in_qry WHERE D.DEAL_NUM = in_qry.DEAL_NUM
# MAGIC                       and D.TRAN_NUM = in_qry.FIRST_TRAN)
# MAGIC GROUP BY CPTY.COUNTERPARTY_LONGNAME,
# MAGIC          CPTY.COUNTERPARTY_ID,
# MAGIC          XBU.BUSINESS_UNIT,
# MAGIC          LE.LEGAL_ENTITY_LONGNAME,
# MAGIC          LE.LEGAL_ENTITY_ID,
# MAGIC          BU.BUSINESS_UNIT,
# MAGIC          DT.TRADER,
# MAGIC          DT.TRADER_ID,
# MAGIC          VU.VOLUME_UNIT,
# MAGIC          DCY.CURRENCY,
# MAGIC          P.PORTFOLIO_LONGNAME,
# MAGIC          INS.INS_TYPE,
# MAGIC          d.buy_sell_id,
# MAGIC          D.PAY_REC_ID,
# MAGIC          LOC.LOCATION_NAME,
# MAGIC          PNL.CASH_FLOW,
# MAGIC          date_format(D.TRADE_DATE, 'yyyyMM')
# MAGIC ORDER BY CPTY.COUNTERPARTY_LONGNAME ASC);

# COMMAND ----------

df = spark.sql("select * from vw_slmt_seti_endur_deals_EDW")

# COMMAND ----------

df.count()

# COMMAND ----------

display(df)

# COMMAND ----------

RefreshSqlDbTbl('pty_counterparty', 'slmt_seti_endur_deals', 'EDW')
