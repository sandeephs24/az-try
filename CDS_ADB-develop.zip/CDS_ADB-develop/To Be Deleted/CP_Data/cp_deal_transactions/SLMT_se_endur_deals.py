# Databricks notebook source
# MAGIC %run "./Common/dataset_library"

# COMMAND ----------

dataset_list = ['edw.ext_dim_counterparty', 'edw.ext_dim_ext_business_unit', 'edw.ext_dim_legal_entity','edw.ext_dim_business_unit', 'edw.ext_dim_portfolio', 'edw.ext_dim_trader', 'edw.ext_dim_ins_type', 'edw.ext_fact_deal', 'edw.ext_dim_phys_gas_location', 'edw.ext_dim_cash_flow', 'edw.ext_dim_volume_unit', 'edw.ext_dim_currency', 'edw.ext_fact_deal_pnl_sens' ]
print(CreateTempVwFromExternalTables(dataset_list))

#non_sens_source_listTables_edw = ['DIM_COUNTERPARTY' , 'DIM_EXT_BUSINESS_UNIT', 'DIM_LEGAL_ENTITY', 'DIM_BUSINESS_UNIT', 'DIM_PORTFOLIO', 'DIM_TRADER', 'DIM_INS_TYPE', 'FACT_DEAL', 'DIM_PHYS_GAS_LOCATION', 'DIM_CASH_FLOW', 'DIM_VOLUME_UNIT', 'DIM_CURRENCY']
#sens_source_listTables_edw =   ['FACT_DEAL_PNL']

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_slmt_se_endur_deals_EDW as 
# MAGIC (
# MAGIC with FDP as
# MAGIC     (
# MAGIC     SELECT MIN (REPORT_DATE) AS REP_DATE,
# MAGIC     MIN(TRAN_NUM) AS TRAN_NUM,
# MAGIC     DEAL_NUM
# MAGIC     FROM edw_ext_fact_deal_pnl_sens FDP
# MAGIC     WHERE     FDP.REPORT_DATE >= '2020-08-01 00:00:00.000'
# MAGIC     AND DEAL_NUM IN (SELECT DISTINCT DEAL_NUM
# MAGIC                   FROM edw_ext_FACT_DEAL
# MAGIC                   WHERE TRADE_DATE > '2020-08-01 00:00:00.000')
# MAGIC     GROUP BY DEAL_NUM
# MAGIC     ),
# MAGIC     in_qry as
# MAGIC     ( SELECT DEAL_NUM,
# MAGIC              MIN (TRAN_NUM) AS FIRST_TRAN
# MAGIC              FROM edw_ext_FACT_DEAL d
# MAGIC              WHERE TRADE_DATE > '2020-08-01 00:00:00.000'
# MAGIC              GROUP BY DEAL_NUM) /* ORIGINAL DEAL VERSION ONLY */
# MAGIC 
# MAGIC select CPTY.COUNTERPARTY_LONGNAME,
# MAGIC          CPTY.COUNTERPARTY_ID,
# MAGIC          XBU.BUSINESS_UNIT AS COUNTERPARTY_BU,
# MAGIC          LE.LEGAL_ENTITY_LONGNAME ,
# MAGIC          LE.LEGAL_ENTITY_ID,
# MAGIC          BU.BUSINESS_UNIT AS INTERNAL_BU,
# MAGIC          P.PORTFOLIO_LONGNAME,
# MAGIC          DT.TRADER,
# MAGIC          DT.TRADER_ID,
# MAGIC          INS.INS_TYPE,
# MAGIC          Case 
# MAGIC          when (d.buy_sell_id= 0) then 'BUY'
# MAGIC          when (d.buy_sell_id= 1) then'SELL' 
# MAGIC          END BUY_SELL,
# MAGIC          Case 
# MAGIC          when (D.PAY_REC_ID= 1) then 'PAY'
# MAGIC          when (D.PAY_REC_ID=0) then 'RECEIVE'
# MAGIC          END PAY_REC,
# MAGIC          LOC.LOCATION_NAME,
# MAGIC          date_format(D.TRADE_DATE, 'yyyyMM') AS TRADE_MONTH,
# MAGIC          PNL.CASH_FLOW,
# MAGIC          SUM (D.QUANTITY) AS DEAL_QUANTITY,
# MAGIC          VU.VOLUME_UNIT AS DEAL_QUANTITY_UNIT,
# MAGIC          SUM (PNL.TOTAL_NOTIONAL_VALUE) AS TOTAL_NOTIONAL_VALUE,
# MAGIC          DCY.CURRENCY AS PAYMENT_CURRENCY,
# MAGIC          COUNT (DISTINCT D.DEAL_NUM) AS DEAL_COUNT,
# MAGIC          'endur_slmt' as source_system
# MAGIC          
# MAGIC          from edw_ext_FACT_DEAL d left outer join 
# MAGIC        (SELECT PNL.REPORT_DATE,
# MAGIC                    PNL.DEAL_NUM,
# MAGIC                    PNL.TRAN_NUM,
# MAGIC                    PARAM_NUM,
# MAGIC                    PROFILE_NUM,
# MAGIC                    CF.CASH_FLOW,
# MAGIC                    SUM (RST_TOTAL_NOTIONAL_VALUE) AS TOTAL_NOTIONAL_VALUE
# MAGIC               FROM edw_ext_fact_deal_pnl_sens PNL, edw_ext_DIM_CASH_FLOW CF
# MAGIC              WHERE EXISTS (SELECT * from FDP
# MAGIC                            where PNL.REPORT_DATE =  FDP.REP_DATE
# MAGIC                            and PNL.TRAN_NUM=FDP.TRAN_NUM and PNL.DEAL_NUM=FDP.DEAL_NUM
# MAGIC                           )
# MAGIC                    AND CF.CASH_FLOW_ID = PNL.RST_CASH_FLOW_TYPE_ID
# MAGIC           GROUP BY PNL.REPORT_DATE,
# MAGIC                    PNL.DEAL_NUM,
# MAGIC                    PNL.TRAN_NUM,
# MAGIC                    PARAM_NUM,
# MAGIC                    PROFILE_NUM,
# MAGIC                    CF.CASH_FLOW) PNL /* FIRST AVAIALBLE DEAL VALUATION ONLY  */ 
# MAGIC                    on D.TRAN_NUM = PNL.TRAN_NUM AND D.PARAM_NUM = PNL.PARAM_NUM AND D.PROFILE_NUM = PNL.PROFILE_NUM,
# MAGIC          edw_ext_DIM_INS_TYPE INS,
# MAGIC          edw_ext_DIM_COUNTERPARTY CPTY,
# MAGIC          edw_ext_dim_legal_entity le,
# MAGIC          edw_ext_dim_Portfolio p,
# MAGIC          edw_ext_DIM_PHYS_GAS_LOCATION LOC,
# MAGIC          edw_ext_DIM_BUSINESS_UNIT BU,
# MAGIC          edw_ext_DIM_EXT_BUSINESS_UNIT XBU,
# MAGIC          edw_ext_DIM_VOLUME_UNIT VU,
# MAGIC          edw_ext_DIM_TRADER DT,
# MAGIC          edw_ext_DIM_CURRENCY DCY
# MAGIC        
# MAGIC          where D.TRADE_DATE >= '2020-08-01 00:00:00.000'
# MAGIC          AND INS.INS_TYPE_ID = D.INS_TYPE_ID
# MAGIC          AND cpty.counterparty_id = d.counterparty_id
# MAGIC          AND le.LEGAL_ENTITY_ID = d.LEGAL_ENTITY_ID
# MAGIC          AND p.portfolio_id = d.portfolio_id
# MAGIC          AND D.PHYS_GAS_LOCATION_ID = LOC.LOCATION_ID
# MAGIC          AND D.BUSINESS_UNIT_ID = BU.BUSINESS_UNIT_ID
# MAGIC          AND D.EXT_BUSINESS_UNIT_ID = XBU.EXT_BUSINESS_UNIT_ID
# MAGIC          AND D.TRADER_ID = DT.TRADER_ID
# MAGIC          AND D.QUANTITY_UNIT_ID = VU.VOLUME_UNIT_ID
# MAGIC          AND D.PAYMENT_CURRENCY_ID = DCY.CURRENCY_ID
# MAGIC          AND exists (SELECT * FROM in_qry
# MAGIC                       WHERE D.DEAL_NUM = in_qry.DEAL_NUM
# MAGIC                       and D.TRAN_NUM = in_qry.FIRST_TRAN
# MAGIC                      )
# MAGIC          GROUP BY CPTY.COUNTERPARTY_LONGNAME,
# MAGIC          CPTY.COUNTERPARTY_ID,
# MAGIC          XBU.BUSINESS_UNIT,
# MAGIC          LE.LEGAL_ENTITY_LONGNAME,
# MAGIC          LE.LEGAL_ENTITY_ID,
# MAGIC          BU.BUSINESS_UNIT,
# MAGIC          DT.TRADER,
# MAGIC          DT.TRADER_ID,
# MAGIC          VU.VOLUME_UNIT,
# MAGIC          DCY.CURRENCY,
# MAGIC          P.PORTFOLIO_LONGNAME,
# MAGIC          INS.INS_TYPE,
# MAGIC          d.buy_sell_id,
# MAGIC          D.PAY_REC_ID,
# MAGIC          LOC.LOCATION_NAME,
# MAGIC          PNL.CASH_FLOW,
# MAGIC          date_format(D.TRADE_DATE, 'yyyyMM')
# MAGIC 		 order by CPTY.COUNTERPARTY_LONGNAME
# MAGIC )

# COMMAND ----------

df = spark.sql("select * from vw_slmt_se_endur_deals_EDW")

# COMMAND ----------

df.show()

# COMMAND ----------

df.count()

# COMMAND ----------

# df.write.format("jdbc").mode("append").option("url", Stratos_sqldb_URL).option("dbtable", "cp_data_user.gtmi_singlecplist").save()
RefreshSqlDbTbl('pty_counterparty', 'slmt_se_endur_deals', 'EDW')
