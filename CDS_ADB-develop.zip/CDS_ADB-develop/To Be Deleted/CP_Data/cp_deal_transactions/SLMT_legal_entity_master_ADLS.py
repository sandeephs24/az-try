# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

#Parameters
dbutils.widgets.text("Environment", "UAT")
dbutils.widgets.text("NON_SENS_ADLS_ENR_UNHARM_Path",   "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/NON-SENS/1ST_PARTY/ENDUR_LNG/")
dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path",   "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/SENS/1ST_PARTY/ENDUR_LNG/")

ENV  = dbutils.widgets.get("Environment")
NON_SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("NON_SENS_ADLS_ENR_UNHARM_Path")
SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

#List of tables
non_sens_full_source_listTables_edw = ['INTERNAL_EXTERNAL', 'PARTY_CLASS', 'PARTY_STATUS', 'NO_YES', 'AB_TRAN_AGREEMENT']
non_sens_inc_source_listTables_edw = ['STATES', 'COUNTRY', 'PARTY_GROUP_MEMB', 'PARTY_RATING', 'CREDIT_RATING', 'PARTY_CREDIT_RATING', 'PARTY_RELATIONSHIP']
sens_inc_source_listTables_edw =   ['PARTY', 'PERSONNEL', 'PARTY_GROUP', 'PARTY_INFO', 'AB_TRAN']
sens_full_source_listTables_edw =   ['LEGAL_ENTITY']
adls_source_schema = 'ENDUR'
source_system = 'endur_lng'

# COMMAND ----------

#Create Dataframe and Temporary Views for Sens Inc Tables from ADLS
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_inc_source_listTables_edw])

#create dataframe for Inc load
dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

#Create Dataframe and Temporary Views for Sens Full Tables from ADLS
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_full_source_listTables_edw])

#create dataframe for Full load
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# Create Dataframe and Temporary Views for Non-Sens Inc Tables from ADLS
FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_inc_source_listTables_edw])

#create dataframe for Inc Load
dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")
  
# Create Dataframe and Temporary Views for Non-Sens Full Tables from ADLS
FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_full_source_listTables_edw])

#create dataframe for Full Load
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

#dataset_list = ['endur_lng.ext_internal_external', 'endur_lng.ext_party_class', 'endur_lng.ext_party_status','endur_lng.ext_no_yes', 'endur_lng.ext_states', 'endur_lng.ext_country', 'endur_lng.ext_party_group_memb', 'endur_lng.ext_party_rating', 'endur_lng.ext_party_credit_rating', 'endur_lng.ext_credit_rating', 'endur_lng.ext_ab_deal_agreement', 'endur_lng.ext_party_relationship', 'endur_lng.ext_party_sens', 'endur_lng.ext_person_sens','endur_lng.ext_legal_entity_sens', 'endur_lng.ext_party_group_sens', 'endur_lng.ext_party_info', 'endur_lng.ext_deal_transaction_sens' ]
#print(CreateTempVwFromExternalTables(dataset_list))

#non_sens_source_listTables_edw = ['INTERNAL_EXTERNAL', 'PARTY_CLASS', 'PARTY_STATUS', 'NO_YES', 'STATES', 'COUNTRY', 'PARTY_GROUP_MEMB', 'PARTY_RATING', 'CREDIT_RATING', 'PARTY_CREDIT_RATING', 'AB_TRAN_AGREEMENT', 'PARTY_RELATIONSHIP']
#sens_source_listTables_edw =   ['PARTY', 'PERSONNEL', 'LEGAL_ENTITY', 'PARTY_GROUP', 'PARTY_INFO', 'AB_TRAN']

# COMMAND ----------

#%sql
#
#  --Step 1.
#  create or replace temporary view vw_slmt_mrd_legal_entity_master_ENDUR_LNG as
#  (
#  with query_one as
#  (
#  SELECT DISTINCT party.party_id, 
#   int_ext.name type, 
#   pc.name party_class, 
#   party.party_class party_class_id, 
#   ps.name status, 
#   party.Short_Name, 
#   party.Long_Name, 
#   per_created.name created_by, 
#   CONCAT(per_created.first_name,(' '||per_created.last_name)) created_by_name,
#   per_updated.name updated_by, 
#   CONCAT(per_updated.first_name,(' '||per_updated.last_name)) le_updated_by_name,
#   party.Last_Update, 
#   party.party_version version, 
#   no_yes.name Agency_Activities, 
#   party.Linked_Party_Id, 
#   le.addr1 address_1, 
#   le.addr2 address_2, 
#   le.city, 
#   states.short_name state, 
#   country.name country, 
#   le.mail_code, 
#   le.phone, 
#   le.fax, 
#   le.description, 
#   le.int_ref1 internal_reference_1, 
#   le.int_ref2 internal_reference_2, 
#   le.int_ref3 internal_reference_3, 
#   pg.short_name party_group, 
#   pi_ext_sap_cust.value lng_ext_sap_customer, 
#   pi_ext_sap_ven.value lng_ext_sap_vendor, 
#   pi_int_sap_cust.value lng_int_sap_customer, 
#   pi_int_sap_ven.value lng_int_sap_vendor, 
#   pi_comp_code.value lng_company_code, 
#   CASE party.int_ext 
#     WHEN 0 
#     THEN pi_int_remit_rep.value 
#     ELSE pi_ext_remit_rep.value 
#   END remit_reprotable, 
#   pi_qgc_sap_cust.value qgc_sap_cust, 
#   pi_qgc_sap_vend.value qgc_sap_vend, 
#   pi_sgm_sap_cust.value sgm_sap_cust, 
#   pi_sgm_sap_vend.value sgm_sap_vend, 
#   pi_sgm_sap_ic_cust.value sgm_sap_ic_cust, 
#   pi_sgm_sap_ic_vend.value sgm_sap_ic_vend, 
#   pr.name party_rating, 
#   pgm.group_id, 
#   cr.rating_name
#   --+ Date of maximum end date of any load / discharge for any associated deal for any associated party agreement, 
# FROM endur_lng_ext_party_sens party
# left outer join endur_lng_ext_legal_entity_sens le on party.party_id = le.party_id
# left outer join endur_lng_ext_states states on le.state_id = states.state_id
# left outer join endur_lng_ext_country country on le.country = country.id_number
# left outer join endur_lng_ext_party_group_memb pgm on party.party_id = pgm.party_id
# left outer join endur_lng_ext_party_group_sens pg on pgm.group_id = pg.group_id
# left outer join endur_lng_ext_party_info pi_ext_sap_cust on party.party_id = pi_ext_sap_cust.party_id and  pi_ext_sap_cust.type_id  = 20176
# left outer join endur_lng_ext_party_info pi_ext_sap_ven on party.party_id          = pi_ext_sap_ven.party_id and pi_ext_sap_ven.type_id   = 20174 -- LNG Ext SAP Vendor 
# left outer join endur_lng_ext_party_info pi_int_sap_cust on party.party_id         = pi_int_sap_cust.party_id and pi_int_sap_cust.type_id  = 20177 -- LNG Int SAP Customer  
# left outer join endur_lng_ext_party_info pi_int_sap_ven on party.party_id              = pi_int_sap_ven.party_id and pi_int_sap_ven.type_id   = 20175 -- LNG Int SAP Vendor 
# left outer join endur_lng_ext_party_info pi_comp_code on party.party_id              = pi_comp_code.party_id and pi_comp_code.type_id     = 20173 -- LNG Int SAP Vendor 
# left outer join endur_lng_ext_party_info pi_int_remit_rep on party.party_id      = pi_int_remit_rep.party_id and pi_int_remit_rep.type_id = 20183 -- Remit Reportable Internal 
# left outer join endur_lng_ext_party_info pi_ext_remit_rep on party.party_id     = pi_ext_remit_rep.party_id and pi_ext_remit_rep.type_id = 20184 -- Remit Reportable External 
# left outer join endur_lng_ext_party_info pi_qgc_sap_cust on party.party_id              = pi_qgc_sap_cust.party_id and pi_qgc_sap_cust.type_id  = 20166 -- QGC SAP Customer 
# left outer join endur_lng_ext_party_info pi_qgc_sap_vend on party.party_id              = pi_qgc_sap_vend.party_id and pi_qgc_sap_vend.type_id  = 20167 -- QGC SAP Vendor 
# left outer join endur_lng_ext_party_info pi_sgm_sap_cust on party.party_id              = pi_sgm_sap_cust.party_id and pi_sgm_sap_cust.type_id  = 20149 -- SGM SAP Customer 
# left outer join endur_lng_ext_party_info pi_sgm_sap_vend on party.party_id              = pi_sgm_sap_vend.party_id and pi_sgm_sap_vend.type_id  = 20150 -- SGM SAP Vendor 
# left outer join endur_lng_ext_party_info pi_sgm_sap_ic_cust on party.party_id      = pi_sgm_sap_ic_cust.party_id and pi_sgm_sap_ic_cust.type_id  = 20188 -- SGM SAP IC Customer 
# left outer join endur_lng_ext_party_info pi_sgm_sap_ic_vend on party.party_id       = pi_sgm_sap_ic_vend.party_id and pi_sgm_sap_ic_vend.type_id  = 20189 -- SGM SAP IC Vendor 
# left outer join endur_lng_ext_party_rating pr on le.party_rating             = pr.id_number
# left outer join endur_lng_ext_party_credit_rating pcr on party.party_id  = pcr.party_id
# left outer join endur_lng_ext_credit_rating cr on pcr.rating_id = cr.rating_id,
#  endur_lng_ext_party_status ps,
#  endur_lng_ext_internal_external int_ext,
#  endur_lng_ext_person_sens per_created,
#  endur_lng_ext_person_sens per_updated,
#  endur_lng_ext_party_class pc,
#  endur_lng_ext_no_yes no_yes
# WHERE party.int_ext               =int_ext.id_number 
# AND party.party_class           = pc.id_number 
# AND party.party_status          = ps.id_number 
# AND party.inputter_id           = per_created.id_number 
# AND party.authoriser_id         = per_updated.id_number 
# AND party.Agency_Activities     = no_yes.id_number
# and party.party_class != 1
# ),
# orderd AS 
#   (SELECT ab.deal_tracking_num, 
#     ab.maturity_date, 
#     ata.party_agreement_id, 
#     ab.internal_lentity lentity, 
#     ab.internal_contact,
#     ab.last_update,
#     ab.trade_date,
#     ab.personnel_id,
#     row_number() over (partition BY ab.internal_lentity order by ab.maturity_date DESC,ab.deal_tracking_num DESC) AS rn 
#     FROM endur_lng_ext_deal_transaction_sens ab, 
#     endur_lng_ext_ab_deal_agreement ata 
#     WHERE ab.tran_num           = ata.tran_num 
#     AND ab.current_flag         = 1 
#     AND ab.tran_status          =3 --and ab.internal_lentity    IN (21054) 
#     AND ata.party_agreement_id <> 0 
#     UNION 
#   SELECT DISTINCT ab.deal_tracking_num, 
#     ab.maturity_date, 
#     ata.party_agreement_id, 
#     ab.external_lentity lentity, 
#     ab.internal_contact,
#     ab.last_update,
#     ab.trade_date,
#     ab.personnel_id,
#     row_number() over (partition BY ab.external_lentity order by ab.maturity_date DESC,ab.deal_tracking_num DESC) AS rn 
#     FROM endur_lng_ext_deal_transaction_sens ab, 
#     endur_lng_ext_ab_deal_agreement ata 
#     WHERE ab.tran_num           = ata.tran_num 
#     AND ab.current_flag         = 1 
#     AND ab.tran_status          =3 --and ab.external_lentity    IN (21297) 
#     AND ata.party_agreement_id <> 0 
#   ), 
#   
#XYZ as
#   ( 
#     SELECT ord.deal_tracking_num, 
#     ord.maturity_date, 
#     ord.party_agreement_id, 
#     ord.lentity, 
#     prsnl.name as trader_id,
#    CONCAT(prsnl.first_name,(' '||prsnl.last_name)) trader_name, 
#     ord.trade_date as TRADE_DATE,
#    ord.last_update as LAST_UPDATE_DEAL,
#     ord.personnel_id as LAST_USER_UPDATE_DEAL,
#     ord.rn, 
#     row_number() over (partition BY ord.lentity order by ord.maturity_date DESC,ord.deal_tracking_num DESC) AS flag_t 
#    FROM orderd ord
#    left join endur_lng_ext_person_sens prsnl
#    on prsnl.id_number = ord.internal_contact
#    WHERE ord.rn    =1
#    ),
#    
#    query_three as
#    (
#    SELECT DISTINCT 
#    pr.legal_entity_id,  
#    pr.business_unit_id  
#    FROM endur_lng_ext_party_relationship pr
#    )
#    
# SELECT DISTINCT
#        query_one.party_id as Party_Id,
#		query_one.type as Type,
#		query_one.party_class as Class,
#		query_one.status as Status,
#		query_one.short_name as Short_Name,
#		query_one.long_name as Long_Name,
#		query_one.created_by as Created_By,
#		query_one.created_by_name as Created_By_Name,
#		query_one.updated_by as LE_Updated_By,
#		query_one.le_updated_by_name as LE_Updated_By_Name,
#		query_one.last_update as LE_Last_Updated,
#		query_one.version as Version,
#		query_one.agency_activities as Agency_Activities,
#		query_one.address_1 as Address_1,
#		query_one.address_2 as Address_2,
#		query_one.city as City,
#		query_one.state as State,
#		query_one.country as Country,
#		query_one.mail_code as Mail_Code,
#		query_one.phone as Phone,
#		query_one.fax as Fax,
#		query_one.description as Description,
#		query_one.internal_reference_1 as Internal_Reference_1,
#		query_one.internal_reference_2 as Internal_Reference_2,
#		query_one.internal_reference_3 as Internal_Reference_3,
#		query_one.party_group as Party_Group,
#		query_one.lng_ext_sap_customer as LNG_Ext_SAP_Customer,
#		query_one.lng_ext_sap_vendor as LNG_Ext_SAP_Vendor,
#		query_one.lng_int_sap_customer as LNG_Int_SAP_Customer,
#		query_one.lng_int_sap_vendor as LNG_Int_SAP_Vendor,
#		query_one.lng_company_code as LNG_Company_Code,
#		query_one.remit_reprotable as Remit_Reportable,
#		query_one.qgc_sap_cust as QGC_SAP_Customer,
#		query_one.qgc_sap_vend as QGC_SAP_Vendor,
#		query_one.sgm_sap_cust as SGM_SAP_Customer,
#		query_one.sgm_sap_vend as SGM_SAP_Vendor,
#		query_one.sgm_sap_ic_cust as SGM_SAP_IC_Customer,
#		query_one.sgm_sap_ic_vend as SGM_SAP_IC_Vendor,
#		query_one.party_rating as Credit_Internal_Rating,
#		query_one.rating_name as SHELL_CREDIT_RATING,
#        abc.party_agreement_id as Agreement_ID,
#        abc.deal_tracking_num as Maximum_Deal_Number,
#        abc.maturity_date as max_end_date,
#        abc.trader_id,
#        abc.trader_name as Trader_Id_Name,
#        abc.TRADE_DATE,
#        abc.LAST_UPDATE_DEAL,
#        prsnl.name as LAST_USER_UPDATE_DEAL,
#        CONCAT(prsnl.first_name,(' '||prsnl.last_name)) last_user_update_deal_name,
#        query_three.business_unit_id as linked_party_id,
#        'ENDUR_SLMT' as source_system
#    from query_one, query_three, XYZ abc
#    left join endur_lng_ext_person_sens prsnl
#    on prsnl.id_number = abc.LAST_USER_UPDATE_DEAL
#    where abc.flag_t=1
#    and query_one.party_id = abc.lentity
#    and query_one.party_id = query_three.legal_entity_id
#    order by Short_Name
#)
#  ;   

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC   --Step 1.
# MAGIC   create or replace temporary view vw_slmt_mrd_legal_entity_master_ENDUR_LNG as
# MAGIC   (
# MAGIC   with query_one as
# MAGIC   (
# MAGIC   SELECT DISTINCT party.party_id, 
# MAGIC    int_ext.name type, 
# MAGIC    pc.name party_class, 
# MAGIC    party.party_class party_class_id, 
# MAGIC    ps.name status, 
# MAGIC    party.Short_Name, 
# MAGIC    party.Long_Name, 
# MAGIC    per_created.name created_by, 
# MAGIC    CONCAT(per_created.first_name,(' '||per_created.last_name)) created_by_name,
# MAGIC    per_updated.name updated_by, 
# MAGIC    CONCAT(per_updated.first_name,(' '||per_updated.last_name)) le_updated_by_name,
# MAGIC    party.Last_Update, 
# MAGIC    party.party_version version, 
# MAGIC    no_yes.name Agency_Activities, 
# MAGIC    party.Linked_Party_Id, 
# MAGIC    le.addr1 address_1, 
# MAGIC    le.addr2 address_2, 
# MAGIC    le.city, 
# MAGIC    states.short_name state, 
# MAGIC    country.name country, 
# MAGIC    le.mail_code, 
# MAGIC    le.phone, 
# MAGIC    le.fax, 
# MAGIC    le.description, 
# MAGIC    le.int_ref1 internal_reference_1, 
# MAGIC    le.int_ref2 internal_reference_2, 
# MAGIC    le.int_ref3 internal_reference_3, 
# MAGIC    pg.short_name party_group, 
# MAGIC    pi_sap_cust.value lng_sap_customer, 
# MAGIC    pi_sap_ven.value lng_sap_vendor, 
# MAGIC    pi_int_sap_cust.value lng_int_sap_customer, 
# MAGIC    pi_int_sap_ven.value lng_int_sap_vendor, 
# MAGIC    pi_comp_code.value lng_company_code, 
# MAGIC    CASE party.int_ext 
# MAGIC      WHEN 0 
# MAGIC      THEN pi_int_remit_rep.value 
# MAGIC      ELSE pi_remit_rep.value 
# MAGIC    END remit_reprotable, 
# MAGIC    pi_qgc_sap_cust.value qgc_sap_cust, 
# MAGIC    pi_qgc_sap_vend.value qgc_sap_vend, 
# MAGIC    pi_sgm_sap_cust.value sgm_sap_cust, 
# MAGIC    pi_sgm_sap_vend.value sgm_sap_vend, 
# MAGIC    pi_sgm_sap_ic_cust.value sgm_sap_ic_cust, 
# MAGIC    pi_sgm_sap_ic_vend.value sgm_sap_ic_vend, 
# MAGIC    pr.name party_rating, 
# MAGIC    pgm.group_id, 
# MAGIC    cr.rating_name
# MAGIC    --+ Date of maximum end date of any load / discharge for any associated deal for any associated party agreement, 
# MAGIC  FROM endur_lng_party party
# MAGIC  left outer join endur_lng_legal_entity le on party.party_id = le.party_id
# MAGIC  left outer join endur_lng_states states on le.state_id = states.state_id
# MAGIC  left outer join endur_lng_country country on le.country = country.id_number
# MAGIC  left outer join endur_lng_party_group_memb pgm on party.party_id = pgm.party_id
# MAGIC  left outer join endur_lng_party_group pg on pgm.group_id = pg.group_id
# MAGIC  left outer join endur_lng_party_info pi_sap_cust on party.party_id = pi_sap_cust.party_id and  pi_sap_cust.type_id  = 20176
# MAGIC  left outer join endur_lng_party_info pi_sap_ven on party.party_id          = pi_sap_ven.party_id and pi_sap_ven.type_id   = 20174 -- LNG Ext SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_int_sap_cust on party.party_id         = pi_int_sap_cust.party_id and pi_int_sap_cust.type_id  = 20177 -- LNG Int SAP Customer  
# MAGIC  left outer join endur_lng_party_info pi_int_sap_ven on party.party_id              = pi_int_sap_ven.party_id and pi_int_sap_ven.type_id   = 20175 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_comp_code on party.party_id              = pi_comp_code.party_id and pi_comp_code.type_id     = 20173 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_int_remit_rep on party.party_id      = pi_int_remit_rep.party_id and pi_int_remit_rep.type_id = 20183 -- Remit Reportable Internal 
# MAGIC  left outer join endur_lng_party_info pi_remit_rep on party.party_id     = pi_remit_rep.party_id and pi_remit_rep.type_id = 20184 -- Remit Reportable External 
# MAGIC  left outer join endur_lng_party_info pi_qgc_sap_cust on party.party_id              = pi_qgc_sap_cust.party_id and pi_qgc_sap_cust.type_id  = 20166 -- QGC SAP Customer 
# MAGIC  left outer join endur_lng_party_info pi_qgc_sap_vend on party.party_id              = pi_qgc_sap_vend.party_id and pi_qgc_sap_vend.type_id  = 20167 -- QGC SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_cust on party.party_id              = pi_sgm_sap_cust.party_id and pi_sgm_sap_cust.type_id  = 20149 -- SGM SAP Customer 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_vend on party.party_id              = pi_sgm_sap_vend.party_id and pi_sgm_sap_vend.type_id  = 20150 -- SGM SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_ic_cust on party.party_id      = pi_sgm_sap_ic_cust.party_id and pi_sgm_sap_ic_cust.type_id  = 20188 -- SGM SAP IC Customer 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_ic_vend on party.party_id       = pi_sgm_sap_ic_vend.party_id and pi_sgm_sap_ic_vend.type_id  = 20189 -- SGM SAP IC Vendor 
# MAGIC  left outer join endur_lng_party_rating pr on le.party_rating             = pr.id_number
# MAGIC  left outer join endur_lng_party_credit_rating pcr on party.party_id  = pcr.party_id
# MAGIC  left outer join endur_lng_credit_rating cr on pcr.rating_id = cr.rating_id,
# MAGIC   endur_lng_party_status ps,
# MAGIC   endur_lng_internal_external int_ext,
# MAGIC   endur_lng_personnel per_created,
# MAGIC   endur_lng_personnel per_updated,
# MAGIC   endur_lng_party_class pc,
# MAGIC   endur_lng_no_yes no_yes
# MAGIC  WHERE party.int_ext               =int_ext.id_number 
# MAGIC  AND party.party_class           = pc.id_number 
# MAGIC  AND party.party_status          = ps.id_number 
# MAGIC  AND party.inputter_id           = per_created.id_number 
# MAGIC  AND party.authoriser_id         = per_updated.id_number 
# MAGIC  AND party.Agency_Activities     = no_yes.id_number
# MAGIC  and party.party_class != 1
# MAGIC  ),
# MAGIC  orderd AS 
# MAGIC    (SELECT ab.deal_tracking_num, 
# MAGIC      ab.maturity_date, 
# MAGIC      ata.party_agreement_id, 
# MAGIC      ab.internal_lentity lentity, 
# MAGIC      ab.internal_contact,
# MAGIC      ab.last_update,
# MAGIC      ab.trade_date,
# MAGIC      ab.personnel_id,
# MAGIC      row_number() over (partition BY ab.internal_lentity order by ab.maturity_date DESC,ab.deal_tracking_num DESC) AS rn 
# MAGIC      FROM endur_lng_ab_tran ab, 
# MAGIC      endur_lng_ab_tran_agreement ata 
# MAGIC      WHERE ab.tran_num           = ata.tran_num 
# MAGIC      AND ab.current_flag         = 1 
# MAGIC      AND ab.tran_status          =3 --and ab.internal_lentity    IN (21054) 
# MAGIC      AND ata.party_agreement_id <> 0 
# MAGIC      UNION 
# MAGIC    SELECT DISTINCT ab.deal_tracking_num, 
# MAGIC      ab.maturity_date, 
# MAGIC      ata.party_agreement_id, 
# MAGIC      ab.external_lentity lentity, 
# MAGIC      ab.internal_contact,
# MAGIC      ab.last_update,
# MAGIC      ab.trade_date,
# MAGIC      ab.personnel_id,
# MAGIC      row_number() over (partition BY ab.external_lentity order by ab.maturity_date DESC,ab.deal_tracking_num DESC) AS rn 
# MAGIC      FROM endur_lng_ab_tran ab, 
# MAGIC      endur_lng_ab_tran_agreement ata 
# MAGIC      WHERE ab.tran_num           = ata.tran_num 
# MAGIC      AND ab.current_flag         = 1 
# MAGIC      AND ab.tran_status          =3 --and ab.external_lentity    IN (21297) 
# MAGIC      AND ata.party_agreement_id <> 0 
# MAGIC    ), 
# MAGIC    
# MAGIC XYZ as
# MAGIC    ( 
# MAGIC      SELECT ord.deal_tracking_num, 
# MAGIC      ord.maturity_date, 
# MAGIC      ord.party_agreement_id, 
# MAGIC      ord.lentity, 
# MAGIC      prsnl.name as trader_id,
# MAGIC     CONCAT(prsnl.first_name,(' '||prsnl.last_name)) trader_name, 
# MAGIC      ord.trade_date as TRADE_DATE,
# MAGIC     ord.last_update as LAST_UPDATE_DEAL,
# MAGIC      ord.personnel_id as LAST_USER_UPDATE_DEAL,
# MAGIC      ord.rn, 
# MAGIC      row_number() over (partition BY ord.lentity order by ord.maturity_date DESC,ord.deal_tracking_num DESC) AS flag_t 
# MAGIC     FROM orderd ord
# MAGIC     left join endur_lng_personnel prsnl
# MAGIC     on prsnl.id_number = ord.internal_contact
# MAGIC     WHERE ord.rn    =1
# MAGIC     ),
# MAGIC     
# MAGIC     query_three as
# MAGIC     (
# MAGIC     SELECT DISTINCT 
# MAGIC     pr.legal_entity_id,  
# MAGIC     pr.business_unit_id  
# MAGIC     FROM endur_lng_party_relationship pr
# MAGIC     )
# MAGIC     
# MAGIC  SELECT DISTINCT
# MAGIC         query_one.party_id as Party_Id,
# MAGIC 		query_one.type as Type,
# MAGIC 		query_one.party_class as Class,
# MAGIC 		query_one.status as Status,
# MAGIC 		query_one.short_name as Short_Name,
# MAGIC 		query_one.long_name as Long_Name,
# MAGIC 		query_one.created_by as Created_By,
# MAGIC 		query_one.created_by_name as Created_By_Name,
# MAGIC 		query_one.updated_by as LE_Updated_By,
# MAGIC 		query_one.le_updated_by_name as LE_Updated_By_Name,
# MAGIC 		query_one.last_update as LE_Last_Updated,
# MAGIC 		query_one.version as Version,
# MAGIC 		query_one.agency_activities as Agency_Activities,
# MAGIC 		query_one.address_1 as Address_1,
# MAGIC 		query_one.address_2 as Address_2,
# MAGIC 		query_one.city as City,
# MAGIC 		query_one.state as State,
# MAGIC 		query_one.country as Country,
# MAGIC 		query_one.mail_code as Mail_Code,
# MAGIC 		query_one.phone as Phone,
# MAGIC 		query_one.fax as Fax,
# MAGIC 		query_one.description as Description,
# MAGIC 		query_one.internal_reference_1 as Internal_Reference_1,
# MAGIC 		query_one.internal_reference_2 as Internal_Reference_2,
# MAGIC 		query_one.internal_reference_3 as Internal_Reference_3,
# MAGIC 		query_one.party_group as Party_Group,
# MAGIC 		query_one.lng_sap_customer as LNG_Ext_SAP_Customer,
# MAGIC 		query_one.lng_sap_vendor as LNG_Ext_SAP_Vendor,
# MAGIC 		query_one.lng_int_sap_customer as LNG_Int_SAP_Customer,
# MAGIC 		query_one.lng_int_sap_vendor as LNG_Int_SAP_Vendor,
# MAGIC 		query_one.lng_company_code as LNG_Company_Code,
# MAGIC 		query_one.remit_reprotable as Remit_Reportable,
# MAGIC 		query_one.qgc_sap_cust as QGC_SAP_Customer,
# MAGIC 		query_one.qgc_sap_vend as QGC_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_cust as SGM_SAP_Customer,
# MAGIC 		query_one.sgm_sap_vend as SGM_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_ic_cust as SGM_SAP_IC_Customer,
# MAGIC 		query_one.sgm_sap_ic_vend as SGM_SAP_IC_Vendor,
# MAGIC 		query_one.party_rating as Credit_Internal_Rating,
# MAGIC 		query_one.rating_name as SHELL_CREDIT_RATING,
# MAGIC         abc.party_agreement_id as Agreement_ID,
# MAGIC         abc.deal_tracking_num as Maximum_Deal_Number,
# MAGIC         abc.maturity_date as max_end_date,
# MAGIC         abc.trader_id,
# MAGIC         abc.trader_name as Trader_Id_Name,
# MAGIC         abc.TRADE_DATE,
# MAGIC         abc.LAST_UPDATE_DEAL,
# MAGIC         prsnl.name as LAST_USER_UPDATE_DEAL,
# MAGIC         CONCAT(prsnl.first_name,(' '||prsnl.last_name)) last_user_update_deal_name,
# MAGIC         query_three.business_unit_id as linked_party_id,
# MAGIC         'ENDUR_SLMT' as source_system
# MAGIC     from query_one, query_three, XYZ abc
# MAGIC     left join endur_lng_personnel prsnl
# MAGIC     on prsnl.id_number = abc.LAST_USER_UPDATE_DEAL
# MAGIC     where abc.flag_t=1
# MAGIC     and query_one.party_id = abc.lentity
# MAGIC     and query_one.party_id = query_three.legal_entity_id
# MAGIC     order by Short_Name
# MAGIC )
# MAGIC   ;   

# COMMAND ----------

df = spark.sql("select * from vw_slmt_mrd_legal_entity_master_ENDUR_LNG")

# COMMAND ----------

df.count()

# COMMAND ----------

RefreshSqlDbTbl('pty_counterparty', 'slmt_mrd_legal_entity_master', 'ENDUR_LNG')
