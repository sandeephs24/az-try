# Databricks notebook source
# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

sens_full_source_listTables = ['PARTY', 'PHYS_HEADER']
sens_inc_source_listTables = ['PERSONNEL', 'AB_TRAN', 'AB_TRAN_PROVISIONAL', 'GAS_PHYS_PARAM', 'PARAMETER', 'PHYSCASH', 'PROFILE']
non_sens_full_source_listTables = ['BUY_SELL']
non_sens_inc_source_listTables = ['CFLOW_TYPE', 'CURRENCY', 'GAS_PHYS_LOCATION', 'IDX_UNIT', 'INSTRUMENTS', 'PORTFOLIO', 'PROV_TYPE']
adls_source_schema =  'ENDUR'
source_system = 'gpna'

# COMMAND ----------

# DBTITLE 1,Get Parameter Values
dbutils.widgets.text("Environment", "UAT")
dbutils.widgets.text("SENS_ADLS_ENR_UNHARM_Path", "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/SENS/1ST_PARTY/ENDUR_GP_NA")
dbutils.widgets.text("NON_SENS_ADLS_ENR_UNHARM_Path", "/mnt/ADLS/PROJECT/P00004-TS-DEV/ENR_UNHARM/NON-SENS/1ST_PARTY/ENDUR_GP_NA")

ENV  = dbutils.widgets.get("Environment")
SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("SENS_ADLS_ENR_UNHARM_Path")
NON_SENS_ADLS_ENR_UNHARM_Path = dbutils.widgets.get("NON_SENS_ADLS_ENR_UNHARM_Path")

# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for Sens Full Datasets
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_full_source_listTables])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for Sens Inc Datasets
FilePathDict = dict([(x, f"{SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in sens_inc_source_listTables])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for Non-Sens Full Datasets
FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_full_source_listTables])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("parquet").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# DBTITLE 1,Create Dataframe and Temporary Views for Non-Sens Inc Datasets
FilePathDict = dict([(x, f"{NON_SENS_ADLS_ENR_UNHARM_Path}/{ENV}/{adls_source_schema}.{x}/{x}.parquet") for x in non_sens_inc_source_listTables])

#create dataframe 
dataframedict =  dict([(k, spark.read.format("delta").load(v).filter(col("IS_RECORD_ACTIVE") == 1)) for (k,v) in FilePathDict.items()])

for key,value in dataframedict.items():
  dataframedict[key] = value.createOrReplaceTempView(f"{source_system}_{key}")

# COMMAND ----------

# MAGIC %sql
# MAGIC select add_months(trunc(current_date, 'year') , -24),
# MAGIC        add_months(trunc(current_date, 'year') , 12)

# COMMAND ----------

df_gpna_ab_tran = spark.sql("""select external_bunit, external_lentity , internal_lentity ,  trade_date ,  start_date ,  maturity_date ,ins_type , tran_status ,  current_flag , offset_tran_type ,
                                      deal_tracking_num , internal_portfolio,  ab.ins_num as ins_num,  ins_type,  internal_contact , buy_sell, meta_created_dttm
                                from  gpna_ab_tran  ab
                               where  trade_date >= add_months(trunc(current_date, 'year') , -24) 
                                 and  maturity_date >= add_months(trunc(current_date, 'year') , -24)
                            """ )
df_gpna_ab_tran = df_gpna_ab_tran.filter("current_flag == 1 and tran_status != 5 and offset_tran_type == 0")
df_gpna_ab_tran = df_gpna_ab_tran.filter(~df_gpna_ab_tran.ins_type.isin([48000, 48020, 48030, 1000023]))

df_gpna_ab_tran.createOrReplaceTempView("gpna_ab_tran")
df_gpna_ab_tran.count()

# COMMAND ----------

[%sql
create or replace temporary view vw_gpna_volumes_flow_data_phys_ENDUR_GP_NA as 
select 
       ab.external_bunit
      ,EBU.LONG_NAME             as bu_long_name
      ,ab.external_lentity
      ,ele.long_name             as le_long_name
      ,ab.internal_lentity
      ,ile.long_name             as int_le_long_name
      ,gpl.location_name         as location_name
      ,po.name                   as trading_desk
      , i.name                   as ins_type
      ,PER.NAME                  as trader_name
      ,'Gas'                     as product_traded
      ,'NA'                      as product_grade
      , bs.name                  as buy_sell
      ,cur.name                  as currency
      ,iu.unit_label             as UOM
      ,ab.trade_date             as trade_date
      ,ab.start_date             as contract_start_date
      ,ab.maturity_date          as contract_end_date
      ,pro.start_date            as leg_start_date
      ,pro.end_date              as leg_end_date
      ,abs(PRO.NOTNL)            as volume 
      ,abs(PRO.PYMT)             as value
      ,ab.deal_tracking_num
      ,ab.meta_created_dttm      as META_CREATED_DTTM
      ,'ENDUR_GP_NA'             as SOURCE_SYSTEM
from       gpna_ab_tran      ab
inner join gpna_party        ebu    on ab.external_bunit     = ebu.party_id
inner join gpna_party        ele    on ab.external_lentity   = ele.party_id
inner join gpna_party        ile    on ab.internal_lentity   = ile.party_id
inner join gpna_portfolio    po     on ab.internal_portfolio = po.id_number
inner join gpna_instruments  i      on ab.ins_type           = i.id_number
inner join gpna_personnel    per    on ab.internal_contact   = PER.ID_NUMBER
inner join gpna_buy_sell     bs     on ab.buy_sell           = BS.ID_NUMBER
inner join gpna_parameter    p      on ab.ins_num            = p.ins_num
inner join gpna_currency     cur    on p.currency            = cur.id_number
inner join gpna_idx_unit     iu     on iu.unit_id            = p.unit
inner join gpna_profile      pro    on p.param_seq_num       = pro.param_seq_num and p.ins_num = pro.ins_num
inner join gpna_parameter    phys_p on phys_p.ins_num        = p.ins_num and phys_p.settlement_type = 2
inner join gpna_gas_phys_param gpp  on phys_p.ins_num = gpp.ins_num and phys_p.param_seq_num = gpp.param_seq_num
inner join gpna_gas_phys_location gpl on gpp.location_id = gpl.location_id
left  join gpna_phys_header  ph     on ph.ins_num            = ab.ins_num

where (   (p.param_seq_num > 1 and nvl(ph.pricing_level, -1) = 0 and p.settlement_type = 1)
           OR (p.param_seq_num = 0 and nvl(ph.pricing_level, -1) in (-1, 1)))
       and ((phys_p.param_seq_num = 1 and nvl(ph.pricing_level, -1) = 0 and p.settlement_type = 1)
           OR (p.param_seq_num = 0 and nvl(ph.pricing_level, -1) in (-1, 1)))

# COMMAND ----------

df = spark.sql("select * from vw_gpna_volumes_flow_data_phys_ENDUR_GP_NA")
df.count()

# COMMAND ----------

RefreshSqlDbTbl('pty_counterparty', 'gpna_volumes_flow_data_phys', 'ENDUR_GP_NA')

# COMMAND ----------


