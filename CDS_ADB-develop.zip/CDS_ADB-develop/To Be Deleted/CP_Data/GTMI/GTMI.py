# Databricks notebook source
# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

# source_system , view_prefix_name  parameters to pass to the function
create_temp_views_per_source_system('GOLD_TIER_MI', 'gtmi')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_gtmi_singlecplist as 
# MAGIC select distinct 
# MAGIC    cc.GoldTier_ID
# MAGIC   ,cc.Legal_Name                                    as Cust_Legal_Name
# MAGIC   --,cc.Policy_Status_Date                            as GT_KYC_Policy_Status_Date1
# MAGIC   ,cast(cc.Policy_Status_Date as  timestamp)       as GT_KYC_Policy_Status_Date
# MAGIC   ,cc.Country_Of_Operations                         as GT_Country_of_Operations
# MAGIC   ,cc.Legal_Country                                 as GT_Legal_Country
# MAGIC   --,cc.Policy_Last_Review_Date                       as GT_Policy_Last_Review_Date
# MAGIC   --,cc.Policy_Next_Review_Date                       as GT_Policy_Next_Rereview_Date
# MAGIC   ,cast(cc.Policy_Last_Review_Date as timestamp)    as GT_Policy_Last_Review_Date
# MAGIC   ,cast(cc.Policy_Next_Review_Date as timestamp)    as GT_Policy_Next_Rereview_Date
# MAGIC   ,cc.Nature_of_business                            as Nature_Of_Business
# MAGIC   ,cc.What_is_your_rationale_for_wanting_to_onboard as Rationale_for_Onboarding
# MAGIC   ,cc.Sanctions_type                                as Sanctions
# MAGIC   ,case when cc.Policy_Status is not null then Policy_Status 
# MAGIC         else cc.Entity_Status
# MAGIC    end                                              as GT_KYC_Policy_Status
# MAGIC   ,cc.Policy_Status                                 as Policy_Status
# MAGIC   ,cc.Entity_Status                                 as Entity_Status
# MAGIC   ,cce.Sectoral_Sanctioning_Body                    as Sectoral_Sanctioning_Body
# MAGIC   ,cce.Customers_Wc_Sanctions_Desc                  as Customers_Wc_Sanctions_Desc
# MAGIC   ,cce.Shell_Customer_Tc_Advice                     as Shell_Customer_Tc_Advice
# MAGIC   ,cc.Related_Party_Status                          as Related_Party_Status
# MAGIC   ,case when cc.DD_Level_Approved   is not null or length(trim(cc.DD_Level_Approved)) > 0 then cc.DD_Level_Approved
# MAGIC         when cc.Due_Diligence_Level is not null or length(trim(Due_Diligence_Level)) > 0  then cc.Due_Diligence_Level
# MAGIC         else cc.DD_Level_Override
# MAGIC    end                                              as KYC_Due_Diligence_Level
# MAGIC   ,cc.DD_Level_Approved
# MAGIC   ,cc.Due_Diligence_Level
# MAGIC   ,cc.Entity_Type                                   as KYC_Entity_Type
# MAGIC   ,cc.Approved_With_Conditions_Flag                 as KYC_Approved_with_Conditions
# MAGIC   ,cc.Rejected_With_Conditions_Flag                 as KYC_Rejected_with_Conditions
# MAGIC   ,cc.Approved_With_Condition_Remarks               as KYC_Approved_with_Conditions_Remarks
# MAGIC   ,cc.DNDB_List                                     as DNDB_Flag
# MAGIC   --,cc.Policy_Approved_date                          as GT_KYC_Policy_Approved_Date
# MAGIC   ,cast(cc.Policy_Approved_date as timestamp)       as GT_KYC_Policy_Approved_Date
# MAGIC   ,cc.Policy_Risk_Level                             as cust_Policy_Risk_Level
# MAGIC   ,cc.complete_Date                                 as cust_complete_Date
# MAGIC   ,cc.create_Date                                   as cust_create_date
# MAGIC   --,cast(cc.complete_Date  as timestamp)             as cust_complete_Date
# MAGIC   --,cast(cc.create_Date    as timestamp)             as cust_create_date
# MAGIC   ,cc.DD_Level_Override                             as DD_Level_Override
# MAGIC   --,cc.Policy_Next_Review_Date_Override              as Policy_Next_Review_Date_Override /*not needed as per Berry, Russell on Dec 4th 2020*/
# MAGIC   ,cast(cc.meta_created_dttm   as timestamp)             as meta_created_dttm
# MAGIC   ,'GOLD_TIER_MI'                                   as source_system
# MAGIC   
# MAGIC from gtmi_vw_mi_customer_core cc           
# MAGIC --left join dndb_list           dndb  on upper(trim(cc.Legal_Name)) =  upper(trim(dndb.Legal_Name))
# MAGIC left join (select distinct 
# MAGIC                  cce.GoldTier_ID
# MAGIC                 ,cce.Sectoral_Sanctioning_Body
# MAGIC                 ,cce.Customers_Wc_Sanctions_Desc
# MAGIC                 ,cce.Shell_Customer_Tc_Advice
# MAGIC            from gtmi_vw_mi_customer_core_extended cce 
# MAGIC            where cce.Record_Active_Flag = 'Y') cce  on  cce.GoldTier_ID = cc.GoldTier_ID
# MAGIC WHERE  cc.Record_Active_Flag = 'Y' 
# MAGIC AND	 cc.GoldTier_ID NOT IN (SELECT distinct GOLDTIER_ID FROM gtmi_R_CUST_ARCH_GT )

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'gtmi_singlecplist') # loading to curated sql db 
