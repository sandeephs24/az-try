# Databricks notebook source
# DBTITLE 1,Run the Main notebook which contains reusable functions
# MAGIC %run "/CGR/Shared_Scripts/Main"

# COMMAND ----------

# DBTITLE 1,Create Widgets
try:
  
    dbutils.widgets.text('mdm_party_file', '', 'MDM Party File');
    dbutils.widgets.text('counter_party_xref_file', '', 'Counter Party XREF File');
    dbutils.widgets.text('counter_party_scope_xref_file', '', 'Counter Party Scope XREF File');
    dbutils.widgets.text('counter_party_scope_file', '', 'Counter Party Scope File');
    dbutils.widgets.text('counter_party_xref_mapping_file', '', 'Counter Party XREF Mapping File');
    dbutils.widgets.text('pipeline_run_id', default_pipeline_run_id, 'Pipeline Run Id');
    
    dbutils.widgets.text('usecase_code', 'CGR', 'Usecase Code');
    dbutils.widgets.text('source_layer_code', 'UNHARM', 'Source Layer Code');
    dbutils.widgets.text('target_layer_code', 'CURATED', 'Target Layer Code');
    dbutils.widgets.text('created_by', 'Data Factory', 'Created By');
  
except Exception as e:
  print(str(e))
  
  dbutils.notebook.exit(json.dumps({'status': 'Failed', 'ReadCount': 0, 'WriteCount': 0, 'Message': str(e)[0:7998]}))
  raise Exception(e)

# COMMAND ----------

# DBTITLE 1,Read data from Widget
try:
  
    mdm_party_file = dbutils.widgets.get('mdm_party_file');
    counter_party_xref_file = dbutils.widgets.get('counter_party_xref_file');
    counter_party_scope_xref_file = dbutils.widgets.get('counter_party_scope_xref_file');
    counter_party_scope_file = dbutils.widgets.get('counter_party_scope_file');
    counter_party_xref_mapping_file = dbutils.widgets.get('counter_party_xref_mapping_file');
    pipeline_run_id = dbutils.widgets.get('pipeline_run_id');
    
    usecase_code = dbutils.widgets.get('usecase_code');
    source_layer_code = dbutils.widgets.get('source_layer_code');
    target_layer_code = dbutils.widgets.get('target_layer_code');
    created_by = dbutils.widgets.get('created_by');
    
except Exception as e:
  print(str(e))
  
  dbutils.notebook.exit(json.dumps({'status': 'Failed', 'ReadCount': 0, 'WriteCount': 0, 'Message': databricksErrorPrefix + str(e)[0:7998]}))
  raise Exception(e)

# COMMAND ----------

# DBTITLE 1,Load active data from files
mdm_party_df = None;
if mdm_party_file is not None and len(mdm_party_file) > 0:
    mdm_party_df = spark.read.format("parquet").load(mdm_party_file)
    mdm_party_df = mdm_party_df.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_mdm_party);

mdm_counterparty_xref_df = None;
if counter_party_xref_file is not None and len(counter_party_xref_file) > 0:
    mdm_counterparty_xref_df = spark.read.format("parquet").load(counter_party_xref_file)
    mdm_counterparty_xref_df = mdm_counterparty_xref_df.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_counterparty_xref);
    
mdm_counterparty_scope_xref_df = None;
if counter_party_scope_xref_file is not None and len(counter_party_scope_xref_file) > 0:
    mdm_counterparty_scope_xref_df = spark.read.format("parquet").load(counter_party_scope_xref_file)
    mdm_counterparty_scope_xref_df = mdm_counterparty_scope_xref_df.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_counterparty_scope_xref);
    
mdm_counterparty_scope_df = None;
if counter_party_scope_file is not None and len(counter_party_scope_file) > 0:
    mdm_counterparty_scope_df = spark.read.format("parquet").load(counter_party_scope_file)
    mdm_counterparty_scope_df = mdm_counterparty_scope_df.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_counterparty_scope);

if counter_party_xref_mapping_file is not None and len(counter_party_xref_mapping_file) > 0:
    mdm_counterparty_xref_mapping = spark.read.format("parquet").load(counter_party_xref_mapping_file)
    mdm_counterparty_xref_mapping_df = mdm_counterparty_xref_mapping.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_counterparty_xref_mapping );
    
    #MDM_COUNTERPARTY_XREF_MAPPING = MDM_COUNTERPARTY_XREF_MAPPING.filter(col("SOURCE_SYSTEM_CODE") == "MDM")

# COMMAND ----------

# DBTITLE 1,Validate Data
###########################################################################
################### Please do not delete this cell ########################
###########################################################################

##status_description
##source_dataset
##load_status
#    
#test_valaidation_df = mdm_party_df.withColumn('validation_column_1', lit(None)).withColumn('validation_column_2', lit(None))
#
#validation_results = ValidateSourceData(dataframe=test_valaidation_df, columns=['validation_column_1', 'validation_column_1'], validation_type='mandatory_column', source_dataset='MDM_PARTY')
#print(validation_results)
#
#if len(validation_results) > 0:
#  
#    # Update log table
#    for validation_result in validation_results:
#        if len(validation_result) > 0:
#            print(validation_result['source_dataset'])
#            UpdateProcessLog(usecase_code, pipeline_run_id, validation_result['source_dataset'], source_layer_code, validation_result['validation_status'], created_by, dbServer_curated, dbDatabase_curated, status_description=validation_result['validation_message'])
#    
#    # Fail notebook
#    error_message = databricks_error_prefix + str(validation_results)[0:7998]
#    dbutils.notebook.exit(json.dumps({'status': 'Failed', 'ReadCount': 0, 'WriteCount': 0, 'Message': error_message}))
#    #raise Exception(error_message)
#    
#print(len(validation_results));

# COMMAND ----------

# DBTITLE 1,Merge data
# Perform lookups from contributor records to golden records

# Extract source system description and remove duplicate records
source_system_df = mdm_counterparty_xref_mapping.select('SOURCE_SYSTEM_CODE').distinct();
source_system_df = source_system_df.select(when(col("SOURCE_SYSTEM_CODE") == 'ENERGY_CREDIT', 'ENCR').
                                                   when(col("SOURCE_SYSTEM_CODE") == 'GOLDTIER', 'GLDT').
                                                   when(col("SOURCE_SYSTEM_CODE") == 'ENDUR_GPNA', 'ENGP').
                                                   when(col("SOURCE_SYSTEM_CODE") == 'NUCLEUS', 'NCLS').
                                                   when(col("SOURCE_SYSTEM_CODE") == 'STNSAP', 'STSP').
                                                   when(col("SOURCE_SYSTEM_CODE") == 'ALIGNE', 'ALGN').
                                                   otherwise("Not in Scope").alias("SOURCE_SYSTEM_CODE")
                                            , col("SOURCE_SYSTEM_CODE").alias("SOURCE_SYSTEM_NAME"))

company_type_df = mdm_party_df.select('COMPANY_TYPE_CODE', 'COMPANY_TYPE_NAME').distinct();
entity_type_df = mdm_party_df.select('ENTITY_TYPE_CODE', 'ENTITY_TYPE_NAME').distinct();
legal_classification_df = mdm_party_df.select('LEGAL_CLASSIFICATION_CODE', 'LEGAL_CLASSIFICATION_NAME').distinct();
operating_region_df = mdm_party_df.select('OPERATING_REGION_CODE', 'OPERATING_REGION_NAME').distinct();
kyc_level_of_dd_df = mdm_party_df.select('KYC_LEVEL_OF_DD_CODE', 'KYC_LEVEL_OF_DD_NAME').distinct()


mdm_party_mdmid_globalpartyid_df = mdm_party_df.select('MDM_ID', 'GLOBAL_PARTY_ID').distinct();
mdm_counterparty_xref_mapping_subset_df = mdm_counterparty_xref_mapping_df.select('MDM_ID', 'SOURCE_PARTY_PRIMARY_KEY').distinct();
mdm_counterparty_xref_mapping_subset_df = mdm_counterparty_xref_mapping_subset_df.join(mdm_party_mdmid_globalpartyid_df, ['MDM_ID'], 'left');


address_country_df = mdm_party_df.select(col('ADDR_COUNTRY_CODE').alias('COUNTRY'), col('ADDR_COUNTRY_NAME').alias('COUNTRY_NAME')).distinct()
raw_address_country_df = address_country_df.withColumnRenamed("COUNTRY", "RAW_COUNTRY").withColumnRenamed("COUNTRY_NAME", "RAW_COUNTRY_FULLNAME")


mdm_counterparty_xref_df = mdm_counterparty_xref_df.join(source_system_df, ['SOURCE_SYSTEM_CODE'], 'left')\
                                                   .join(company_type_df, ['COMPANY_TYPE_CODE'], 'left')\
                                                   .join(entity_type_df, ['ENTITY_TYPE_CODE'], 'left')\
                                                   .join(kyc_level_of_dd_df, kyc_level_of_dd_df.KYC_LEVEL_OF_DD_CODE==mdm_counterparty_xref_df.kyc_status_level_of_dd, 'left')\
                                                   .join(legal_classification_df, legal_classification_df['LEGAL_CLASSIFICATION_CODE']==mdm_counterparty_xref_df['legal_classification'], 'left')\
                                                   .join(operating_region_df, operating_region_df['OPERATING_REGION_CODE']==mdm_counterparty_xref_df['legal_classification'], 'left')\
                                                   .join(mdm_counterparty_xref_mapping_subset_df, ['SOURCE_PARTY_PRIMARY_KEY'], 'left')\
                                                   .join(address_country_df, ['COUNTRY'], 'left')\
                                                   .join(raw_address_country_df, ['RAW_COUNTRY'], 'left')


business_area_df = mdm_counterparty_scope_df.select('BUSINESS_AREA_CODE', 'BUSINESS_AREA_NAME').distinct()
commodity_df = mdm_counterparty_scope_df.select('COMMODITY_CODE', 'COMMODITY_NAME').distinct()
counterparty_role_df = mdm_counterparty_scope_df.select('COUNTERPARTY_ROLE_CODE', 'COUNTERPARTY_ROLE_NAME').distinct()
shell_company_df = mdm_counterparty_scope_df.select('SHELL_COMPANY_CODE', 'SHELL_COMPANY_NAME').distinct()

mdm_counterparty_scope_xref_df = mdm_counterparty_scope_xref_df.join(source_system_df, ['SOURCE_SYSTEM_CODE'], 'left')\
                                                               .join(mdm_counterparty_xref_mapping_subset_df, ['SOURCE_PARTY_PRIMARY_KEY'], 'left')\
                                                               .join(business_area_df, business_area_df['BUSINESS_AREA_CODE']==mdm_counterparty_scope_xref_df['BUSINESS_AREA_CD'], 'left')\
                                                               .join(commodity_df, commodity_df['COMMODITY_CODE']==mdm_counterparty_scope_xref_df['COMMODITY_CD'], 'left')\
                                                               .join(counterparty_role_df, counterparty_role_df['COUNTERPARTY_ROLE_CODE']==mdm_counterparty_scope_xref_df['COUNTERPARTY_ROLE_CD'], 'left')\
                                                               .join(shell_company_df, shell_company_df['SHELL_COMPANY_CODE']==mdm_counterparty_scope_xref_df['SHELL_COMPANY_CD'], 'left')

mdm_counterparty_scope_df = mdm_counterparty_scope_df.join(mdm_party_mdmid_globalpartyid_df, ['MDM_ID'], 'left')

# COMMAND ----------

print('COUNTERPARTY')
print(mdm_party_df.columns)
print('\nCOUNTERPARTY XREF')
print(mdm_counterparty_xref_df.columns)
print('\nCOUNTERPARTY SCOPE XREF')
print(mdm_counterparty_scope_xref_df.columns)
print('\nCOUNTERPARTY SCOPE')
print(mdm_counterparty_scope_df.columns)
print('\nCOUNTERPARTYXREF MAPPING')
print(mdm_counterparty_xref_mapping_df.columns)

# COMMAND ----------

# DBTITLE 1,Counterparty
mdm_party_cpt_df = None;
mdm_counterparty_xref_cpt_df = None;
cpt_df = None;

if mdm_party_df is not None:
    
    mdm_party_cpt_df = mdm_party_df.select(
                                   col('GLOBAL_PARTY_ID').alias('GLOBAL_PARTY_ID')
                                   , col('MDM_ID').alias('SOURCE_SYSTEM_PARTY_ID')
                                   , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                   , lit('MDM').alias('SOURCE_SYSTEM_DESCRIPTION')
                                   , col('COMPANY_TYPE_CODE')
                                   , col('COMPANY_TYPE_NAME').alias('COMPANY_TYPE_DESCRIPTION')
                                   , col('ENTITY_TYPE_CODE')
                                   , col('ENTITY_TYPE_NAME').alias('ENTITY_TYPE_DESCRIPTION')
                                   , col('US_GOVERNMENT_INDICATOR').alias('GOVERNMENT_INTERMEDIARY_IND')
                                   , col('IS_REGISTERED_INDICATOR').alias('IS_REGISTERED_IND')
                                   , col('LEGAL_CLASSIFICATION_CODE')
                                   , col('LEGAL_CLASSIFICATION_NAME').alias('LEGAL_CLASSIFICATION_DESCRIPTION')
                                   , col('LEGAL_NAME')
                                   , col('NATURE_OF_BUSINESS')
                                   , col('OPERATING_REGION_CODE')
                                   , col('OPERATING_REGION_NAME').alias('OPERATING_REGION_DESCRIPTION')
                                   , col('TAX_WAIVER_INDICATOR').alias('TAX_WAIVER_SIGNOFF_IND')
                                   , col('KYC_LEVEL_OF_DD_NAME').alias('KYC_LEVEL_OF_DD_DESCRIPTION')
                               ).distinct().filter("GLOBAL_PARTY_ID IS NOT NULL")
  
if mdm_counterparty_xref_df is not None:
                                   #col('IDENTIFICATION_VALUE').alias('GLOBAL_PARTY_ID')
    mdm_counterparty_xref_cpt_df = mdm_counterparty_xref_df.select(
                                   col('GLOBAL_PARTY_ID')
                                   , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYSTEM_PARTY_ID')
                                   , col('SOURCE_SYSTEM_CODE')
                                   , col('SOURCE_SYSTEM_NAME').alias('SOURCE_SYSTEM_DESCRIPTION') 
                                   , col('COMPANY_TYPE_CODE')
                                   , col('COMPANY_TYPE_CODE').alias('COMPANY_TYPE_DESCRIPTION')                       ## Get from COUNTERPARTY table
                                   , col('ENTITY_TYPE_CODE')
                                   , col('ENTITY_TYPE_CODE').alias('ENTITY_TYPE_DESCRIPTION')                         ## Get from COUNTERPARTY table
                                   , col('US_GOVT_IND').alias('GOVERNMENT_INTERMEDIARY_IND')
                                   , col('IS_REGISTERED').alias('IS_REGISTERED_IND')
                                   , col('LEGAL_CLASSIFICATION').alias('LEGAL_CLASSIFICATION_CODE')
                                   , col('LEGAL_CLASSIFICATION').alias('LEGAL_CLASSIFICATION_DESCRIPTION')       ## Get from COUNTERPARTY table
                                   , col('LEGAL_NAME')      
                                   , col('NATURE_OF_BUSINESS')
                                   , col('OPERATING_REGION_CD').alias('OPERATING_REGION_CODE')
                                   , col('OPERATING_REGION_CD').alias('OPERATING_REGION_DESCRIPTION') ## Get from COUNTERPARTY table
                                   , col('TAX_WAIVER_SIGNOFF_INDICATOR').alias('TAX_WAIVER_SIGNOFF_IND')
                                   , col('KYC_LEVEL_OF_DD_CODE').alias('KYC_LEVEL_OF_DD_DESCRIPTION')                                 ## CONFIRM THIS with the team
                           ).distinct().filter("SOURCE_PARTY_PRIMARY_KEY IS NOT NULL")

if mdm_party_cpt_df is not None and mdm_counterparty_xref_cpt_df is not None:
    mdm_counterparty_xref_cpt_df = mdm_counterparty_xref_cpt_df[mdm_party_cpt_df.columns];
    
cpt_df = mdm_party_cpt_df.union(mdm_counterparty_xref_cpt_df).distinct();

cpt_df = cpt_df.withColumn('GLOBAL_PARTY_ID', when(cpt_df.GLOBAL_PARTY_ID.isNull(), lit(default_value_for_nulls)).otherwise(cpt_df.GLOBAL_PARTY_ID))\
               .withColumn('SOURCE_SYSTEM_PARTY_ID', when(lower(cpt_df.SOURCE_SYSTEM_CODE) == 'mdm', lit(default_value_for_nulls)).otherwise(cpt_df.SOURCE_SYSTEM_PARTY_ID))

# COMMAND ----------

print(mdm_party_cpt_df.count());
print(mdm_counterparty_xref_cpt_df.count());
print(cpt_df.count());

print(mdm_party_cpt_df.distinct().count());
print(mdm_counterparty_xref_cpt_df.distinct().count());
print(cpt_df.distinct().count());

# COMMAND ----------

# DBTITLE 1,Counterparty - Save
if cpt_df.count() > 0:
    UpsertDataToSQLDB(pipeline_run_id, 'MDM_CGR', 'COUNTERPARTY', cpt_df, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated, fullRefresh=True, write_mode='append', source_dataset='COUNTERPARTY,COUNTERPARTY_XREF')

# COMMAND ----------

# DBTITLE 1,Counterparty Identification
mdm_party_cpt_id_df = None;
mdm_counterparty_xref_cpt_id_df = None;
cpt_id_df = None;

if mdm_party_df is not None:
  
    mdm_party_cpt_id_df = mdm_party_df.select(
                                   col('GLOBAL_PARTY_ID').alias('GLOBAL_PARTY_ID')
                                   , col('MDM_ID').alias('SOURCE_SYSTEM_PARTY_ID')
                                   , col('MDM_IDENTIFIER_ID').alias('SOURCE_SYSTEM_IDENTIFIER_KEY')
                                   , col('IDENTIFICATION_TYPE_CODE')
                                   , col('IDENTIFICATION_TYPE_NAME').alias('IDENTIFICATION_TYPE_DESCRIPTION')
                                   , col('IDENTIFICATION_NUMBER')
                                   , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                   , col('STATE_CODE')
                                   , col('STATE_NAME')
                                   #, col('REGION_STATE').alias('REGIONAL_STATE_CODE')
                                   , lit('').alias('REGIONAL_STATE_NAME')
                                   , col('COUNTRY_NAME').alias('COUNTRY_CODE')
                                   , col('COUNTRY_NAME').alias('COUNTRY_DESCRIPTION')
                               ).distinct().filter("MDM_IDENTIFIER_ID IS NOT NULL")
    
    mdm_party_cpt_id_df = mdm_party_cpt_id_df.withColumn('REGIONAL_STATE_CODE', when((col('STATE_CODE').isNull() & col('STATE_NAME').isNull()), default_value_for_nulls)\
                                                                                .otherwise(concat(mdm_party_cpt_id_df.STATE_CODE, lit(' - '), mdm_party_cpt_id_df.STATE_NAME)))
    
    mdm_party_cpt_id_df = mdm_party_cpt_id_df.drop(*['STATE_CODE', 'STATE_NAME'])
  
if mdm_counterparty_xref_df is not None:
    
    mdm_counterparty_xref_cpt_id_df = mdm_counterparty_xref_df.select(
                                   col('GLOBAL_PARTY_ID')
                                   , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYSTEM_PARTY_ID')
                                   , col('CP_IDENTIFIER_PRIMARY_KEY').alias('SOURCE_SYSTEM_IDENTIFIER_KEY')
                                   , col('IDENTIFICATION_TYPE_CODE')
                                   , col('IDENTIFICATION_TYPE_CODE').alias('IDENTIFICATION_TYPE_DESCRIPTION')                            # Confirm source
                                   , col('IDENTIFICATION_VALUE').alias('IDENTIFICATION_NUMBER')      
                                   , col('SOURCE_SYSTEM_CODE')
                                   , col('IDENTIFIER_REGION_STATE').alias('REGIONAL_STATE_CODE')
                                   , lit('').alias('REGIONAL_STATE_NAME')                                        # Confirm source
                                   , col('IDENTIFIER_COUNTRY').alias('COUNTRY_CODE')
                                   , col('IDENTIFIER_COUNTRY').alias('COUNTRY_DESCRIPTION')                                        # Confirm source
                           ).distinct().filter("CP_IDENTIFIER_PRIMARY_KEY IS NOT NULL")

if mdm_party_cpt_id_df is not None and mdm_counterparty_xref_cpt_id_df is not None:
    mdm_counterparty_xref_cpt_id_df = mdm_counterparty_xref_cpt_id_df[mdm_party_cpt_id_df.columns];
    
cpt_id_df = mdm_party_cpt_id_df.union(mdm_counterparty_xref_cpt_id_df).distinct();

cpt_id_df = cpt_id_df.withColumn('GLOBAL_PARTY_ID', when(cpt_id_df.GLOBAL_PARTY_ID.isNull(), lit(default_value_for_nulls)).otherwise(cpt_id_df.GLOBAL_PARTY_ID))\
                     .withColumn('IDENTIFICATION_NUMBER', when(cpt_id_df.IDENTIFICATION_NUMBER.isNull(), lit(default_value_for_nulls)).otherwise(cpt_id_df.IDENTIFICATION_NUMBER))\
                     .withColumn('SOURCE_SYSTEM_PARTY_ID', when(lower(cpt_id_df.SOURCE_SYSTEM_CODE) == 'mdm', lit(default_value_for_nulls)).otherwise(cpt_id_df.SOURCE_SYSTEM_PARTY_ID))                      

# COMMAND ----------

# DBTITLE 1,Counterparty Identification - Save
if cpt_id_df.count() > 0:
    UpsertDataToSQLDB(pipeline_run_id, 'MDM_CGR', 'COUNTERPARTY_IDENTIFICATION', cpt_id_df, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated, fullRefresh=True, write_mode='append', source_dataset='COUNTERPARTY,COUNTERPARTY_XREF')

# COMMAND ----------

# DBTITLE 1,Counterparty Address
mdm_party_cpt_addr_df = None;
mdm_counterparty_xref_cpt_addr_df = None;
cpt_addr_df = None;

if mdm_party_df is not None:
    
    mdm_party_cpt_addr_df = mdm_party_df.select(
                                   col('GLOBAL_PARTY_ID').alias('GLOBAL_PARTY_ID')
                                   , col('MDM_ID').alias('SOURCE_SYSTEM_PARTY_ID')
                                   , col('MDM_ADDRESS_ID').alias('SOURCE_SYSTEM_ADDRESS_KEY')
                                   , col('ADDRESS_TYPE_CODE')
                                   , col('ADDRESS_TYPE_NAME').alias('ADDRESS_TYPE_DESCRIPTION')
                                   , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                   , col('LEGAL_NAME') 
                                   , lit('').alias('TRADING_SHORT_NAME')                       # This column is popuated in report from CPTY_SCP table
                                   , col('ADDRESS_LINE_1')
                                   , col('ADDRESS_LINE_2')
                                   , col('ADDRESS_LINE_3')
                                   , col('ADDRESS_LINE_4')
                                   , col('CITY')
                                   , col('REGION_STATE').alias('REGION_STATE_CODE')
                                   , lit('').alias('REGION_STATE_NAME')
                                   , col('POSTAL_CODE')
                                   , col('ADDR_COUNTRY_NAME').alias('COUNTRY_NAME')
                                   , lit(None).alias('RAW_ADDRESS_LINE_1')
                                   , lit(None).alias('RAW_ADDRESS_LINE_2')
                                   , lit(None).alias('RAW_ADDRESS_LINE_3')
                                   , lit(None).alias('RAW_ADDRESS_LINE_4')
                                   , lit(None).alias('RAW_CITY')
                                   , lit(None).alias('RAW_REGION_STATE')
                                   , lit(None).alias('RAW_POSTAL_CODE')
                                   , lit(None).alias('RAW_COUNTRY')
                                   , lit('').alias('RAW_REGION_STATE_NAME')
                                   , col('PARTY_TYPE_CODE')
                               ).distinct().filter("MDM_ADDRESS_ID IS NOT NULL")
  
if mdm_counterparty_xref_df is not None:
        
    mdm_counterparty_xref_cpt_addr_df = mdm_counterparty_xref_df.select(
                                   col('GLOBAL_PARTY_ID')
                                   , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYSTEM_PARTY_ID')
                                   , col('CP_ADDR_PRIMARY_KEY').alias('SOURCE_SYSTEM_ADDRESS_KEY')
                                   , col('ADDRESS_TYPE_CD').alias('ADDRESS_TYPE_CODE')
                                   , lit(None).alias('ADDRESS_TYPE_DESCRIPTION')
                                   , col('SOURCE_SYSTEM_CODE')
                                   , col('LEGAL_NAME') 
                                   , lit('').alias('TRADING_SHORT_NAME')                       # This column is popuated in report from CPTY_SCO table
                                   , col('ADDRESS_LINE_1')
                                   , col('ADDRESS_LINE_2')
                                   , col('ADDRESS_LINE_3')
                                   , col('ADDRESS_LINE_4')
                                   , col('CITY')
                                   , col('REGION_STATE').alias('REGION_STATE_CODE')
                                   , lit('').alias('REGION_STATE_NAME')
                                   , col('POSTAL_CD').alias('POSTAL_CODE')
                                   , col('COUNTRY_NAME')
                                   , col('RAW_ADDRESS_LINE_1')
                                   , col('RAW_ADDRESS_LINE_2')
                                   , col('RAW_ADDRESS_LINE_3')
                                   , col('RAW_ADDRESS_LINE_4')
                                   , col('RAW_CITY')
                                   , col('RAW_REGION_STATE')
                                   , col('RAW_POSTAL_CD').alias('RAW_POSTAL_CODE')
                                   , col('RAW_COUNTRY_FULLNAME').alias('RAW_COUNTRY')
                                   , lit('').alias('RAW_REGION_STATE_NAME')
                                   , col('PARTY_TYPE_CODE')
                           ).distinct().filter("CP_ADDR_PRIMARY_KEY IS NOT NULL")

if mdm_party_cpt_addr_df is not None and mdm_counterparty_xref_cpt_addr_df is not None:
    mdm_counterparty_xref_cpt_addr_df = mdm_counterparty_xref_cpt_addr_df[mdm_party_cpt_addr_df.columns];
    
cpt_addr_df = mdm_party_cpt_addr_df.union(mdm_counterparty_xref_cpt_addr_df).distinct();

cpt_addr_df = cpt_addr_df.withColumn('GLOBAL_PARTY_ID', when(cpt_addr_df.GLOBAL_PARTY_ID.isNull(), lit(default_value_for_nulls)).otherwise(cpt_addr_df.GLOBAL_PARTY_ID))\
                         .withColumn('SOURCE_SYSTEM_PARTY_ID', when(lower(cpt_addr_df.SOURCE_SYSTEM_CODE) == 'mdm', lit(default_value_for_nulls)).otherwise(cpt_addr_df.SOURCE_SYSTEM_PARTY_ID)) 

# COMMAND ----------

# DBTITLE 1,Counterparty Address - Save
if cpt_addr_df.count() > 0:
    UpsertDataToSQLDB(pipeline_run_id, 'MDM_CGR', 'COUNTERPARTY_ADDRESS', cpt_addr_df, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated, fullRefresh=True, write_mode='append', source_dataset='COUNTERPARTY,COUNTERPARTY_XREF')

# COMMAND ----------

# DBTITLE 1,Counterparty Scope
mdm_party_cpt_scp_df = None;
mdm_counterparty_xref_cpt_scp_df = None;
cpt_scp_df = None;

if mdm_counterparty_scope_df is not None:
    
    mdm_party_cpt_scp_df = mdm_counterparty_scope_df.select(
                                   col('GLOBAL_PARTY_ID').alias('GLOBAL_PARTY_ID')
                                   , col('MDM_ID').alias('SOURCE_SYSTEM_PARTY_ID')
                                   , col('COUNTERPARTY_SCOPE_ID').alias('SOURCE_SYS_CP_SCOPE_KEY')
                                   , col('CREDIT_STATUS_CODE').alias('CREDIT_ASSESSED_STATUS_CODE')
                                   , lit('').alias('CREDIT_ASSESSED_STATUS_DESCRIPTION')
                                   , col('COUNTERPARTY_SHORT_NAME')
                                   , col('COUNTERPARTY_LONG_NAME')
                                   , col('SCOPE_ACTIVE_INDICATOR')
                                   , col('SHELL_COMPANY_CODE')
                                   , concat(col('SHELL_COMPANY_CODE'), lit(' - '), col('SHELL_COMPANY_NAME')).alias('SHELL_COMPANY_DESCRIPTION')
                                   , col('BUSINESS_AREA_CODE')
                                   , col('BUSINESS_AREA_NAME').alias('BUSINESS_AREA_DESCRIPTION')
                                   , col('SERVICE_TYPE_CODE')
                                   , col('SERVICE_TYPE_NAME').alias('SERVICE_TYPE_DESCRIPTION')
                                   , col('COMMODITY_CODE')
                                   , col('COMMODITY_NAME').alias('COMMODITY_DESCRIPTION')
                                   , col('COUNTERPARTY_ROLE_CODE')
                                   , col('COUNTERPARTY_ROLE_NAME').alias('COUNTERPARTY_ROLE_DESCRIPTION')
                                   , col('TRADING_DESK_CODE')
                                   , col('TRADING_DESK_NAME').alias('TRADING_DESK_DESCRIPTION')
                                   , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                   , lit('').alias('SOURCE_SYSTEM_DESCRIPTION')
                               ).distinct().filter("COUNTERPARTY_SCOPE_ID IS NOT NULL")
  
if mdm_counterparty_scope_xref_df is not None:
        
    mdm_counterparty_xref_cpt_scp_df = mdm_counterparty_scope_xref_df.select(
                                   col('GLOBAL_PARTY_ID')
                                   , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYSTEM_PARTY_ID')
                                   , col('CPS_PRIMARY_KEY').alias('SOURCE_SYS_CP_SCOPE_KEY')
                                   , lit('').alias('CREDIT_ASSESSED_STATUS_CODE')
                                   , lit('').alias('CREDIT_ASSESSED_STATUS_DESCRIPTION')
                                   , col('COUNTERPARTY_SHORT_NAME')
                                   , col('COUNTERPARTY_LONG_NAME')
                                   , col('SCOPE_ACTIVE_INDICATOR').substr(1, 1).alias('SCOPE_ACTIVE_INDICATOR')
                                   , col('SHELL_COMPANY_CD').alias('SHELL_COMPANY_CODE')
                                   , concat(col('SHELL_COMPANY_CD'), lit(' - '), col('SHELL_COMPANY_NAME')).alias('SHELL_COMPANY_DESCRIPTION')
                                   , col('BUSINESS_AREA_CD').alias('BUSINESS_AREA_CODE')
                                   , col('BUSINESS_AREA_NAME').alias('BUSINESS_AREA_DESCRIPTION')
                                   , col('SERVICE_TYPE_CD').alias('SERVICE_TYPE_CODE')
                                   , col('SERVICE_TYPE_CD').alias('SERVICE_TYPE_DESCRIPTION')
                                   , col('COMMODITY_CD').alias('COMMODITY_CODE')
                                   , col('COMMODITY_NAME').alias('COMMODITY_DESCRIPTION')
                                   , col('COUNTERPARTY_ROLE_CD').alias('COUNTERPARTY_ROLE_CODE')
                                   , col('COUNTERPARTY_ROLE_NAME').alias('COUNTERPARTY_ROLE_DESCRIPTION')
                                   , col('TRADING_DESK_CD').alias('TRADING_DESK_CODE')
                                   , col('TRADING_DESK_CD').alias('TRADING_DESK_DESCRIPTION')
                                   , col('SOURCE_SYSTEM_CODE').alias('SOURCE_SYSTEM_CODE')
                                   , lit('').alias('SOURCE_SYSTEM_DESCRIPTION')
                           ).distinct().filter("CPS_PRIMARY_KEY IS NOT NULL")
    
    mdm_counterparty_xref_cpt_scp_df = mdm_counterparty_xref_cpt_scp_df.withColumn('BUSINESS_AREA_CODE', when(lower(col('BUSINESS_AREA_CODE')) == 'na', col('BUSINESS_AREA_DESCRIPTION')).otherwise(col('BUSINESS_AREA_CODE')))\
                                                                       .withColumn('COMMODITY_CODE', when(lower(col('COMMODITY_CODE')) == 'na', col('COMMODITY_DESCRIPTION')).otherwise(col('COMMODITY_CODE')))\
                                                                       .withColumn('COUNTERPARTY_ROLE_CODE', when(lower(col('COUNTERPARTY_ROLE_CODE')) == 'na', col('COUNTERPARTY_ROLE_DESCRIPTION')).otherwise(col('COUNTERPARTY_ROLE_CODE')))

if mdm_party_cpt_scp_df is not None and mdm_counterparty_xref_cpt_scp_df is not None:
    mdm_counterparty_xref_cpt_scp_df = mdm_counterparty_xref_cpt_scp_df[mdm_party_cpt_scp_df.columns];
    
cpt_scp_df = mdm_party_cpt_scp_df.union(mdm_counterparty_xref_cpt_scp_df).distinct();

cpt_scp_df = cpt_scp_df.withColumn('GLOBAL_PARTY_ID', when(cpt_scp_df.GLOBAL_PARTY_ID.isNull(), lit(default_value_for_nulls)).otherwise(cpt_scp_df.GLOBAL_PARTY_ID))\
                       .withColumn('SOURCE_SYSTEM_PARTY_ID', when(lower(cpt_scp_df.SOURCE_SYSTEM_CODE) == 'mdm', lit(default_value_for_nulls)).otherwise(cpt_scp_df.SOURCE_SYSTEM_PARTY_ID))               

# COMMAND ----------

# DBTITLE 1,Counterparty Scope - Save
if cpt_scp_df.count() > 0:
    UpsertDataToSQLDB(pipeline_run_id, 'MDM_CGR', 'COUNTERPARTY_SCOPE', cpt_scp_df, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated, fullRefresh=True, write_mode='append', source_dataset='COUNTERPARTY_SCOPE,COUNTERPARTY_SCOPE_XREF')

# COMMAND ----------

# DBTITLE 1,Counterparty Status
mdm_party_cpt_st_df = None;
mdm_counterparty_xref_cpt_st_df = None;
cpt_st_df = None;

if mdm_counterparty_scope_df is not None:
    
    mdm_party_cpt_st_df = mdm_party_df.select(
            col('GLOBAL_PARTY_ID').alias('GLOBAL_PARTY_ID')
            , col('MDM_ID').alias('SOURCE_SYSTEM_PARTY_ID')
            , col('MDM_KYC_Id').alias('SOURCE_SYSTEM_KYC_KEY')
            , col('KYC_LEVEL_OF_DD_CODE')
            , col('KYC_LEVEL_OF_DD_NAME').alias('KYC_LEVEL_OF_DD_DESCRIPTION')
            , lit('MDM').alias('SOURCE_SYSTEM_CODE')
            , col('KYC_REVIEW_DATE')
            , col('KYC_NEXT_REVIEW_DATE')
            , col('KYC_REVIEW_CONDITION')
            , col('KYC_STATUS_VALUE_CODE').alias('KYC_REVIEW_STATUS')
            , col('PARTY_STATUS_TYPE_CODE')
            , col('PARTY_STATUS_VALUE_CODE')
            , col('ACTIVE_STATUS_CODE')
            , col('PARTY_STATUS_EFFECTIVE_DATE')
            ).filter("SOURCE_SYSTEM_KYC_KEY IS NOT NULL").distinct();

  
if mdm_counterparty_scope_xref_df is not None:
  
    mdm_counterparty_xref_cpt_st_df = mdm_counterparty_xref_df.select(
            col('GLOBAL_PARTY_ID')
            , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYSTEM_PARTY_ID')
            , lit('').alias('SOURCE_SYSTEM_KYC_KEY')
            , col('KYC_LEVEL_OF_DD_CODE')
            , col('KYC_LEVEL_OF_DD_NAME').alias('KYC_LEVEL_OF_DD_DESCRIPTION')
            , col('SOURCE_SYSTEM_CODE').alias('SOURCE_SYSTEM_CODE')
            , col('KYC_STATUS_REVIEW_DATE').alias('KYC_REVIEW_DATE')
            , col('KYC_STATUS_NEXT_REVIEW_DATE').alias('KYC_NEXT_REVIEW_DATE')
            , col('KYC_STATUS_REVIEW_CONDITION_DESCRIPTION').alias('KYC_REVIEW_CONDITION')
            , col('KYC_STATUS_VALUE').alias('KYC_REVIEW_STATUS')
            , col('PARTY_STATUS_CD').alias('PARTY_STATUS_TYPE_CODE')
            , f.split(col('PARTY_STATUS_VALUE_CD'), '[|]')[1].alias('PARTY_STATUS_VALUE_CODE')
            , col('ACTIVE_STATUS_CODE')
            , lit(None).alias('PARTY_STATUS_EFFECTIVE_DATE')
            ).filter("SOURCE_SYSTEM_KYC_KEY IS NOT NULL AND SOURCE_SYSTEM_KYC_KEY != ''").distinct();


    
    
if mdm_party_cpt_st_df is not None and mdm_counterparty_xref_cpt_st_df is not None:
    mdm_counterparty_xref_cpt_st_df = mdm_counterparty_xref_cpt_st_df[mdm_party_cpt_st_df.columns];
    
party_status_type_union_df = mdm_party_cpt_st_df.union(mdm_counterparty_xref_cpt_st_df);

party_status_type_extended_df = party_status_type_union_df.withColumn('DNDB_STATUS', when(lower(col('PARTY_STATUS_TYPE_CODE')) == 'dndb_status', col('PARTY_STATUS_VALUE_CODE')).otherwise(lit(None)))\
                                            .withColumn('SANCTION_STATUS', when(lower(col('PARTY_STATUS_TYPE_CODE')) == 'sanction_type_status', col('PARTY_STATUS_VALUE_CODE')).otherwise(lit(None)))\
                                            .withColumn('KYC_CLEARED_FOR_DEAL_STATUS', when(lower(col('PARTY_STATUS_TYPE_CODE')) == 'kyc_cleared_for_deals_status', col('PARTY_STATUS_VALUE_CODE')).otherwise(lit(None)))\
                                            .withColumn('ACTIVE_STATUS', when(lower(col('ACTIVE_STATUS_CODE')).isin(['inactive', 'active']), col('ACTIVE_STATUS_CODE')).otherwise(lit(None)))\
                                            .withColumn('DNDB_EFFECTIVE_DATE', when(lower(col('PARTY_STATUS_TYPE_CODE')) == 'dndb_status', col('PARTY_STATUS_EFFECTIVE_DATE')).otherwise(lit(None)))\
                                            .withColumn('SANCTION_EFFECTIVE_DATE', when(lower(col('PARTY_STATUS_TYPE_CODE')) == 'sanction_type_status', col('PARTY_STATUS_EFFECTIVE_DATE')).otherwise(lit(None)))\
                                            .withColumn('KYC_CLEARED_FOR_DEAL_EFFECTIVE_DATE', when(lower(col('PARTY_STATUS_TYPE_CODE')) == 'kyc_cleared_for_deals_status', col('PARTY_STATUS_EFFECTIVE_DATE')).otherwise(lit(None)))\

party_status_type_trimmed_df = party_status_type_extended_df.drop(*['PARTY_STATUS_TYPE_CODE', 'PARTY_STATUS_VALUE_CODE'])

cpt_st_df = party_status_type_trimmed_df.groupBy([party_status_type_trimmed_df['GLOBAL_PARTY_ID']
                                                     , party_status_type_trimmed_df['SOURCE_SYSTEM_PARTY_ID']
                                                     , party_status_type_trimmed_df['SOURCE_SYSTEM_KYC_KEY']
                                                     , party_status_type_trimmed_df['KYC_LEVEL_OF_DD_CODE']
                                                     , party_status_type_trimmed_df['KYC_LEVEL_OF_DD_DESCRIPTION']
                                                     , party_status_type_trimmed_df['SOURCE_SYSTEM_CODE']
                                                     , party_status_type_trimmed_df['KYC_REVIEW_DATE']
                                                     , party_status_type_trimmed_df['KYC_NEXT_REVIEW_DATE']
                                                     , party_status_type_trimmed_df['KYC_REVIEW_CONDITION']
                                                     , party_status_type_trimmed_df['KYC_REVIEW_STATUS']
                                                 ]).agg(f.max(party_status_type_trimmed_df['DNDB_STATUS']).alias('DNDB_STATUS')
                                                     , f.max(party_status_type_trimmed_df['SANCTION_STATUS']).alias('SANCTION_STATUS')
                                                     , f.max(party_status_type_trimmed_df['KYC_CLEARED_FOR_DEAL_STATUS']).alias('KYC_CLEARED_FOR_DEAL_STATUS')
                                                     , f.max(party_status_type_trimmed_df['ACTIVE_STATUS']).alias('ACTIVE_STATUS')
                                                     , f.max(party_status_type_trimmed_df['DNDB_EFFECTIVE_DATE']).alias('DNDB_EFFECTIVE_DATE')
                                                     , f.max(party_status_type_trimmed_df['SANCTION_EFFECTIVE_DATE']).alias('SANCTION_EFFECTIVE_DATE')
                                                     , f.max(party_status_type_trimmed_df['KYC_CLEARED_FOR_DEAL_EFFECTIVE_DATE']).alias('KYC_CLEARED_FOR_DEAL_EFFECTIVE_DATE')
                                                 );

cpt_st_df = cpt_st_df.withColumn('GLOBAL_PARTY_ID', when(cpt_st_df.GLOBAL_PARTY_ID.isNull(), lit(default_value_for_nulls)).otherwise(cpt_st_df.GLOBAL_PARTY_ID))\
                     .withColumn('SOURCE_SYSTEM_PARTY_ID', when(lower(cpt_st_df.SOURCE_SYSTEM_CODE) == 'mdm', lit(default_value_for_nulls)).otherwise(cpt_st_df.SOURCE_SYSTEM_PARTY_ID))

# COMMAND ----------

# DBTITLE 1,Counterparty Status - Save
if cpt_st_df.count() > 0:
    UpsertDataToSQLDB(pipeline_run_id, 'MDM_CGR', 'COUNTERPARTY_STATUS', cpt_st_df, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated, fullRefresh=True, write_mode='append', source_dataset='COUNTERPARTY,COUNTERPARTY_XREF')

# COMMAND ----------

# DBTITLE 1,Refresh the Curated Views
# MAGIC %run "/CGR/Curated/views_all"
