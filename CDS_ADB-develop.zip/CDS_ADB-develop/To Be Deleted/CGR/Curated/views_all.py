# Databricks notebook source
# MAGIC %run "/CGR/Shared_Scripts/Main"

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,COUNTERPARTY
src_table_name = 'COUNTERPARTY';
tgt_view_name = src_table_name;

custom_query_counterparty = f"""
create view {tgt_schema_name}.{tgt_view_name}  as
select
   DISTINCT
   CPT.GLOBAL_PARTY_ID,
   CPT.SOURCE_SYSTEM_PARTY_ID,
   CPT.SOURCE_SYSTEM_CODE,
   CPT.SOURCE_SYSTEM_DESCRIPTION,
   CPT.COMPANY_TYPE_CODE,
   CPT.COMPANY_TYPE_DESCRIPTION,
   CPT.ENTITY_TYPE_CODE,
   CPT.ENTITY_TYPE_DESCRIPTION,
   CPT.LEGAL_CLASSIFICATION_CODE,
   CPT.LEGAL_CLASSIFICATION_DESCRIPTION,
   CPT.OPERATING_REGION_CODE,
   CPT.OPERATING_REGION_DESCRIPTION,
   CPT.LEGAL_NAME,
   CPT.NATURE_OF_BUSINESS,
   CPT.GOVERNMENT_INTERMEDIARY_IND,
   CPT.IS_REGISTERED_IND,
   CPT.TAX_WAIVER_SIGNOFF_IND,
   CPT_ST.KYC_LEVEL_OF_DD_CODE,
   CPT_ST.KYC_LEVEL_OF_DD_DESCRIPTION,
   CPT_ST.KYC_CLEARED_FOR_DEAL_STATUS,
   CPT_ST.ACTIVE_STATUS
from
   MDM_CGR.COUNTERPARTY  CPT 
   LEFT JOIN MDM_CGR.COUNTERPARTY_STATUS CPT_ST 
     ON CPT.GLOBAL_PARTY_ID=CPT_ST.GLOBAL_PARTY_ID
        AND CPT.SOURCE_SYSTEM_PARTY_ID=CPT_ST.SOURCE_SYSTEM_PARTY_ID
        AND CPT.SOURCE_SYSTEM_CODE=CPT_ST.SOURCE_SYSTEM_CODE
""";

CreateSQLDBView(tgt_schema_name=tgt_schema_name, tgt_view_name=tgt_view_name, create_view_query=custom_query_counterparty)

# COMMAND ----------

# DBTITLE 1,COUNTERPARTY_ADDRESS
src_table_name = 'COUNTERPARTY_ADDRESS';
tgt_view_name = src_table_name;
columns = f"""
GLOBAL_PARTY_ID
, SOURCE_SYSTEM_PARTY_ID
, SOURCE_SYSTEM_ADDRESS_KEY
, SOURCE_SYSTEM_CODE
, ADDRESS_TYPE_CODE
, ADDRESS_TYPE_DESCRIPTION
, LEGAL_NAME
, CASE 
	WHEN ADDRESS_LINE_1 IS NULL OR LOWER(PARTY_TYPE_CODE) NOT IN ('person') THEN ADDRESS_LINE_1
  ELSE
    CASE 
      WHEN LOWER(PARTY_TYPE_CODE) IN ('person') AND is_member('{authorized_user_group}') =1 THEN ADDRESS_LINE_1 
    ELSE '{masked_value_default}' 
  END
END AS ADDRESS_LINE_1
, CASE 
	WHEN ADDRESS_LINE_2 IS NULL OR LOWER(PARTY_TYPE_CODE) NOT IN ('person') THEN ADDRESS_LINE_2
  ELSE
    CASE 
      WHEN LOWER(PARTY_TYPE_CODE) IN ('person') AND is_member('{authorized_user_group}') =1 THEN ADDRESS_LINE_2 
    ELSE '{masked_value_default}' 
  END
END AS ADDRESS_LINE_2
, CASE 
	WHEN ADDRESS_LINE_3 IS NULL OR LOWER(PARTY_TYPE_CODE) NOT IN ('person') THEN ADDRESS_LINE_3
  ELSE
    CASE 
      WHEN LOWER(PARTY_TYPE_CODE) IN ('person') AND is_member('{authorized_user_group}') =1 THEN ADDRESS_LINE_3 
    ELSE '{masked_value_default}' 
  END
END AS ADDRESS_LINE_3
, CASE 
	WHEN ADDRESS_LINE_4 IS NULL OR LOWER(PARTY_TYPE_CODE) NOT IN ('person') THEN ADDRESS_LINE_4
  ELSE
    CASE 
      WHEN LOWER(PARTY_TYPE_CODE) IN ('person') AND is_member('{authorized_user_group}') =1 THEN ADDRESS_LINE_4
    ELSE '{masked_value_default}' 
  END
END AS ADDRESS_LINE_4
, CITY
, REGION_STATE_CODE
, CASE 
	WHEN POSTAL_CODE IS NULL OR LOWER(PARTY_TYPE_CODE) NOT IN ('person') THEN POSTAL_CODE
  ELSE
    CASE 
      WHEN LOWER(PARTY_TYPE_CODE) IN ('person') AND is_member('{authorized_user_group}') =1 THEN POSTAL_CODE 
    ELSE '{masked_value_default}' 
  END
END AS POSTAL_CODE
, COUNTRY_NAME
, CASE 
	WHEN RAW_ADDRESS_LINE_1 IS NULL OR LOWER(PARTY_TYPE_CODE) NOT IN ('person') THEN RAW_ADDRESS_LINE_1
  ELSE
    CASE 
      WHEN LOWER(PARTY_TYPE_CODE) IN ('person') AND is_member('{authorized_user_group}') =1 THEN RAW_ADDRESS_LINE_1 
    ELSE '{masked_value_default}' 
  END
END AS RAW_ADDRESS_LINE_1
, CASE 
	WHEN RAW_ADDRESS_LINE_2 IS NULL OR LOWER(PARTY_TYPE_CODE) NOT IN ('person') THEN RAW_ADDRESS_LINE_2
  ELSE
    CASE 
      WHEN LOWER(PARTY_TYPE_CODE) IN ('person') AND is_member('{authorized_user_group}') =1 THEN RAW_ADDRESS_LINE_2 
    ELSE '{masked_value_default}' 
  END
END AS RAW_ADDRESS_LINE_2
, CASE 
	WHEN RAW_ADDRESS_LINE_3 IS NULL OR LOWER(PARTY_TYPE_CODE) NOT IN ('person') THEN RAW_ADDRESS_LINE_3
  ELSE
    CASE 
      WHEN LOWER(PARTY_TYPE_CODE) IN ('person') AND is_member('{authorized_user_group}') =1 THEN RAW_ADDRESS_LINE_3 
    ELSE '{masked_value_default}' 
  END
END AS RAW_ADDRESS_LINE_3
, CASE 
	WHEN RAW_ADDRESS_LINE_4 IS NULL OR LOWER(PARTY_TYPE_CODE) NOT IN ('person') THEN RAW_ADDRESS_LINE_4
  ELSE
    CASE 
      WHEN LOWER(PARTY_TYPE_CODE) IN ('person') AND is_member('{authorized_user_group}') =1 THEN RAW_ADDRESS_LINE_4 
    ELSE '{masked_value_default}' 
  END
END AS RAW_ADDRESS_LINE_4
, RAW_CITY
, RAW_REGION_STATE
, CASE 
	WHEN RAW_POSTAL_CODE IS NULL OR LOWER(PARTY_TYPE_CODE) NOT IN ('person') THEN RAW_POSTAL_CODE
  ELSE
    CASE 
      WHEN LOWER(PARTY_TYPE_CODE) IN ('person') AND is_member('{authorized_user_group}') =1 THEN RAW_POSTAL_CODE 
    ELSE '{masked_value_default}' 
  END
END AS RAW_POSTAL_CODE
, RAW_COUNTRY
, REGION_STATE_NAME
, RAW_REGION_STATE_NAME""";

CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,COUNTERPARTY_IDENTIFICATION
src_table_name = 'COUNTERPARTY_IDENTIFICATION';
tgt_view_name = src_table_name;
#columns = 'GLOBAL_PARTY_ID, SOURCE_SYSTEM_PARTY_ID, SOURCE_SYSTEM_CODE, IDENTIFICATION_TYPE_CODE, IDENTIFICATION_NUMBER, REGIONAL_STATE_CODE, REGIONAL_STATE_NAME, COUNTRY_CODE';
columns = f"""
GLOBAL_PARTY_ID
, SOURCE_SYSTEM_PARTY_ID
, SOURCE_SYSTEM_IDENTIFIER_KEY
, SOURCE_SYSTEM_CODE
, IDENTIFICATION_TYPE_CODE
, IDENTIFICATION_TYPE_DESCRIPTION
, CASE 
	WHEN IDENTIFICATION_TYPE_CODE IS NULL OR LOWER(IDENTIFICATION_TYPE_CODE) NOT IN ('tax id') THEN IDENTIFICATION_NUMBER
  ELSE
    CASE 
      WHEN LOWER(IDENTIFICATION_TYPE_CODE) IN ('tax id') AND is_member('{authorized_user_group}') =1 THEN IDENTIFICATION_NUMBER 
    ELSE '{masked_value_default}' 
  END
END AS IDENTIFICATION_NUMBER
, REGIONAL_STATE_CODE
, REGIONAL_STATE_NAME
, COUNTRY_CODE
, COUNTRY_DESCRIPTION""";

CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,COUNTERPARTY_SCOPE
src_table_name = 'COUNTERPARTY_SCOPE';
tgt_view_name = src_table_name;
columns = f"""
GLOBAL_PARTY_ID
, SOURCE_SYSTEM_PARTY_ID
, SOURCE_SYS_CP_SCOPE_KEY
, COUNTERPARTY_SHORT_NAME
, COUNTERPARTY_LONG_NAME
, SCOPE_ACTIVE_INDICATOR
, BUSINESS_AREA_CODE
, BUSINESS_AREA_DESCRIPTION
, COMMODITY_CODE
, COMMODITY_DESCRIPTION
, COUNTERPARTY_ROLE_CODE
, COUNTERPARTY_ROLE_DESCRIPTION
, SERVICE_TYPE_CODE
, SERVICE_TYPE_DESCRIPTION
, SOURCE_SYSTEM_CODE
, SOURCE_SYSTEM_DESCRIPTION
, CREDIT_ASSESSED_STATUS_CODE
, CREDIT_ASSESSED_STATUS_DESCRIPTION
, SHELL_COMPANY_CODE
, SHELL_COMPANY_DESCRIPTION
,TRADING_DESK_CODE
,TRADING_DESK_DESCRIPTION""";

CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,COUNTERPARTY_STATUS
src_table_name = 'COUNTERPARTY_STATUS';
tgt_view_name = src_table_name;
columns = f"""
GLOBAL_PARTY_ID
, SOURCE_SYSTEM_PARTY_ID
, SOURCE_SYSTEM_KYC_KEY
, SOURCE_SYSTEM_CODE
, DNDB_STATUS
, SANCTION_STATUS
, KYC_CLEARED_FOR_DEAL_STATUS
, ACTIVE_STATUS
, DNDB_EFFECTIVE_DATE
, SANCTION_EFFECTIVE_DATE
, KYC_CLEARED_FOR_DEAL_EFFECTIVE_DATE
, KYC_REVIEW_STATUS
, KYC_LEVEL_OF_DD_CODE
, KYC_LEVEL_OF_DD_DESCRIPTION
, KYC_REVIEW_DATE
, KYC_NEXT_REVIEW_DATE
, KYC_REVIEW_CONDITION""";

CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,DIM_BUSINESS_AREA
#src_table_name = 'DIM_BUSINESS_AREA';
#tgt_view_name = src_table_name;
#columns = """
#BUSINESS_AREA_CODE
#, SOURCE_SYSTEM_CODE
#, COALESCE (BUSINESS_AREA_NAME, BUSINESS_AREA_DESC, BUSINESS_AREA_CODE) AS BUSINESS_AREA_DESC
#, ACTIVE_IND""";
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,DIM_COMMODITY
#src_table_name = 'DIM_COMMODITY';
#tgt_view_name = src_table_name;
#columns = """
#COMMODITY_CODE
#, SOURCE_SYSTEM_CODE
#, COALESCE (COMMODITY_NAME, COMMODITY_DESC, COMMODITY_CODE) AS COMMODITY_DESC
#, ACTIVE_IND""";
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,DIM_COMPANY_TYPE
#src_table_name = 'DIM_COMPANY_TYPE';
#tgt_view_name = src_table_name;
#columns = """
#COMPANY_TYPE_CODE
#, SOURCE_SYSTEM_CODE
#, COALESCE (COMPANY_TYPE_NAME, COMPANY_TYPE_DESC, COMPANY_TYPE_CODE) AS COMPANY_TYPE_DESC
#, ACTIVE_IND""";
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,DIM_COUNTERPARTY_ROLE
#src_table_name = 'DIM_COUNTERPARTY_ROLE';
#tgt_view_name = src_table_name;
#columns = """
#COUNTERPARTY_ROLE_CODE
#, SOURCE_SYSTEM_CODE
#, COALESCE (COUNTERPARTY_ROLE_NAME, COUNTERPARTY_ROLE_DESC, COUNTERPARTY_ROLE_CODE) AS COUNTERPARTY_ROLE_DESC
#, ACTIVE_IND""";
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,DIM_ENTITY_TYPE
#src_table_name = 'DIM_ENTITY_TYPE';
#tgt_view_name = src_table_name;
#columns = """
#ENTITY_TYPE_CODE
#, SOURCE_SYSTEM_CODE
#, COALESCE (ENTITY_TYPE_NAME, ENTITY_TYPE_DESC, ENTITY_TYPE_CODE) AS ENTITY_TYPE_DESC
#, ACTIVE_IND""";
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,DIM_IDENTIFICATION_TYPE
#src_table_name = 'DIM_IDENTIFICATION_TYPE';
#tgt_view_name = src_table_name;
#columns = """
#IDENTIFICATION_TYPE_CODE
#, SOURCE_SYSTEM_CODE
#, COALESCE (IDENTIFICATION_TYPE_NAME, IDENTIFICATION_TYPE_DESC, IDENTIFICATION_TYPE_CODE) AS IDENTIFICATION_TYPE_DESC
#, ACTIVE_IND""";
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,DIM_LEGAL_CLASSIFICATION
#src_table_name = 'DIM_LEGAL_CLASSIFICATION';
#tgt_view_name = src_table_name;
#columns = """
#LEGAL_CLASSIFICATION_CODE
#, SOURCE_SYSTEM_CODE
#, COALESCE (LEGAL_CLASSIFICATION_NAME, LEGAL_CLASSIFICATION_DESC, LEGAL_CLASSIFICATION_CODE) AS LEGAL_CLASSIFICATION_DESC
#, ACTIVE_IND""";
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,DIM_OPERATING_REGION
#src_table_name = 'DIM_OPERATING_REGION';
#tgt_view_name = src_table_name;
#columns = """
#OPERATING_REGION_CODE
#, SOURCE_SYSTEM_CODE
#, COALESCE (OPERATING_REGION_NAME, OPERATING_REGION_DESC, OPERATING_REGION_CODE) AS OPERATING_REGION_DESC
#, ACTIVE_IND""";
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,DIM_REVIEW_STATUS
#src_table_name = 'DIM_REVIEW_STATUS';
#tgt_view_name = src_table_name;
#columns = """
#REVIEW_STATUS_CODE
#, SOURCE_SYSTEM_CODE
#, COALESCE (REVIEW_STATUS_NAME, REVIEW_STATUS_DESC, REVIEW_STATUS_CODE) AS REVIEW_STATUS_DESC
#, ACTIVE_IND""";
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,DIM_SERVICE_TYPE
#src_table_name = 'DIM_SERVICE_TYPE';
#tgt_view_name = src_table_name;
#columns = """
#SERVICE_TYPE_CODE
#, SOURCE_SYSTEM_CODE
#, COALESCE (SERVICE_TYPE_NAME, SERVICE_TYPE_DESC, SERVICE_TYPE_CODE) AS SERVICE_TYPE_DESC
#, ACTIVE_IND""";
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,DIM_SHELL_COMPANY
#src_table_name = 'DIM_SHELL_COMPANY';
#tgt_view_name = src_table_name;
#columns = """
#SHELL_COMPANY_CODE
#, SOURCE_SYSTEM_CODE
#, COALESCE (SHELL_COMPANY_NAME, SHELL_COMPANY_DESC, SHELL_COMPANY_CODE) AS SHELL_COMPANY_DESC
#, ACTIVE_IND""";
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,DIM_TRADING_DESK
#src_table_name = 'DIM_TRADING_DESK';
#tgt_view_name = src_table_name;
#columns = """
#TRADING_DESK_CODE
#, SOURCE_SYSTEM_CODE
#, COALESCE (TRADING_DESK_NAME, TRADING_DESK_DESC, TRADING_DESK_CODE) AS TRADING_DESK_DESC
#, ACTIVE_IND""";
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,KYC_LEVEL_OF_DD
#src_table_name = 'KYC_LEVEL_OF_DD';
#tgt_view_name = src_table_name;
#columns = """KYC_LEVEL_OF_DD_CODE
#, SOURCE_SYSTEM_CODE
#, COALESCE (KYC_LEVEL_OF_DD_NAME, KYC_LEVEL_OF_DD_DESC, KYC_LEVEL_OF_DD_CODE) AS KYC_LEVEL_OF_DD_DESC
#, ACTIVE_IND""";
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)

# COMMAND ----------

# DBTITLE 1,SOURCE_SYSTEM
#src_table_name = 'SOURCE_SYSTEM';
#tgt_view_name = src_table_name;
#columns = """
#SOURCE_SYSTEM_CODE
#, COALESCE (SOURCE_SYSTEM_NAME, SOURCE_SYSTEM_CODE) AS SOURCE_SYSTEM_DESC
#, ACTIVE_IND""";
##columns = 'SOURCE_SYSTEM_CODE, SOURCE_SYSTEM_NAME, ACTIVE_IND';
#
#CreateSQLDBView(src_schema_name, src_table_name, tgt_schema_name, tgt_view_name, columns)
