# Databricks notebook source
# MAGIC %run "/CGR/Shared_Scripts/Main"

# COMMAND ----------

try:
  
    dbutils.widgets.text('pipeline_run_id', '999999999999999', 'Pipeline Run Id');
  
except Exception as e:
  print(str(e))
  
  dbutils.notebook.exit(json.dumps({'status': 'Failed', 'ReadCount': 0, 'WriteCount': 0, 'Message': str(e)[0:7998]}))
  raise Exception(e)

# COMMAND ----------

# DBTITLE 1,DIM_BUSINESS_AREA
query_dim_business_area = """select
   BA.BUSINESS_AREA_CODE,
   SRC.SOURCE_SYSTEM_CODE,
   BA.BUSINESS_AREA_DESC,
   BA.ACTIVE_IND
from
   ENT_LEGAL_ENTITY_REF_DATA.BUSINESS_AREA BA Left join
  ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC  	
  ON BA.SOURCE_SYSTEM_ID =SRC.SOURCE_SYSTEM_ID""";

dim_business_area_df = SqldbToDataframe(query_dim_business_area)

if dim_business_area_df.count() > 0:
  
    merge_columns = 'BUSINESS_AREA_CODE,SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'DIM_BUSINESS_AREA', dim_business_area_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(dim_business_area_df)

# COMMAND ----------

# DBTITLE 1,DIM_COMMODITY
query_dim_commodity = """select
   CMD.COMMODITY_CODE,
   SRC.SOURCE_SYSTEM_CODE,
   CMD.COMMODITY_DESC,
   CMD.ACTIVE_IND
from
  ENT_LEGAL_ENTITY_REF_DATA.COMMODITY CMD Left join
  ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC  	
  ON CMD.SOURCE_SYSTEM_ID =SRC.SOURCE_SYSTEM_ID"""

dim_commodity_df = SqldbToDataframe(query_dim_commodity)

if dim_commodity_df.count() > 0:
  
    merge_columns = 'COMMODITY_CODE,SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'DIM_COMMODITY', dim_commodity_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(dim_commodity_df)

# COMMAND ----------

# DBTITLE 1,DIM_COMPANY_TYPE
query_dim_company_type = """select
   CPY.COMPANY_TYPE_CODE,
   SRC.SOURCE_SYSTEM_CODE,
   CPY.COMPANY_TYPE_DESC,
   CPY.ACTIVE_IND
from
   ENT_LEGAL_ENTITY_REF_DATA.COMPANY_TYPE CPY LEFT JOIN 
   ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC         
   ON CPY.SOURCE_SYSTEM_ID =SRC.SOURCE_SYSTEM_ID"""

dim_company_type_df = SqldbToDataframe(query_dim_company_type)

if dim_company_type_df.count() > 0:
  
    merge_columns = 'COMPANY_TYPE_CODE,SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'DIM_COMPANY_TYPE', dim_company_type_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(dim_company_type_df)

# COMMAND ----------

# DBTITLE 1,DIM_ENTITY_TYPE
query_dim_entity_type = """select
   ENTY.ENTITY_TYPE_CODE,
   SRC.SOURCE_SYSTEM_CODE,
   ENTY.ENTITY_TYPE_DESC,
   ENTY.ACTIVE_IND
from
   ENT_LEGAL_ENTITY_REF_DATA.ENTITY_TYPE ENTY LEFT JOIN 
   ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC         
   ON ENTY.SOURCE_SYSTEM_ID =SRC.SOURCE_SYSTEM_ID"""

dim_entity_type_df = SqldbToDataframe(query_dim_entity_type)

if dim_entity_type_df.count() > 0:
  
    merge_columns = 'ENTITY_TYPE_CODE,SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'DIM_ENTITY_TYPE', dim_entity_type_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(dim_entity_type_df)

# COMMAND ----------

# DBTITLE 1,DIM_IDENTIFICATION_TYPE
query_dim_identification_type = """select
   ID_TYP.IDENTIFICATION_TYPE_CODE,
   SRC.SOURCE_SYSTEM_CODE,
   ID_TYP.IDENTIFICATION_TYPE_DESC,
   ID_TYP.ACTIVE_IND
from
   ENT_LEGAL_ENTITY_REF_DATA.IDENTIFICATION_TYPE ID_TYP Left join
  ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC  	
  ON ID_TYP.SOURCE_SYSTEM_ID =SRC.SOURCE_SYSTEM_ID"""

dim_identification_type_df = SqldbToDataframe(query_dim_identification_type)

if dim_identification_type_df.count() > 0:
  
    merge_columns = 'IDENTIFICATION_TYPE_CODE,SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'DIM_IDENTIFICATION_TYPE', dim_identification_type_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(dim_identification_type_df)

# COMMAND ----------

# DBTITLE 1,DIM_LEGAL_CLASSIFICATION
query_dim_legal_classification = """select
   LGL_CLS.LEGAL_CLASSIFICATION_CODE,
   SRC.SOURCE_SYSTEM_CODE,
   LGL_CLS.LEGAL_CLASSIFICATION_DESC,
   LGL_CLS.ACTIVE_IND
from
   ENT_LEGAL_ENTITY_REF_DATA.LEGAL_CLASSIFICATION LGL_CLS LEFT JOIN 
   ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC         
   ON LGL_CLS.SOURCE_SYSTEM_ID =SRC.SOURCE_SYSTEM_ID"""

dim_legal_classification_df = SqldbToDataframe(query_dim_legal_classification)

if dim_legal_classification_df.count() > 0:
  
    merge_columns = 'LEGAL_CLASSIFICATION_CODE,SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'DIM_LEGAL_CLASSIFICATION', dim_legal_classification_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(dim_legal_classification_df)

# COMMAND ----------

# DBTITLE 1,DIM_OPERATING_REGION
query_dim_operating_region = """select
   OPR.OPERATING_REGION_CD as OPERATING_REGION_CODE,
   SRC.SOURCE_SYSTEM_CODE,
   OPR.OPERATING_REGION_DESC,
   OPR.ACTIVE_IND
from
  ENT_LEGAL_ENTITY_REF_DATA.OPERATING_REGION OPR LEFT JOIN 
   ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC         
   ON  OPR.SOURCE_SYSTEM_ID =SRC.SOURCE_SYSTEM_ID"""

dim_operating_region_df = SqldbToDataframe(query_dim_operating_region)

if dim_operating_region_df.count() > 0:
  
    merge_columns = 'OPERATING_REGION_CODE,SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'DIM_OPERATING_REGION', dim_operating_region_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(dim_operating_region_df)

# COMMAND ----------

# DBTITLE 1,DIM_REVIEW_STATUS
query_dim_review_status = """select
   REV_ST.REVIEW_STATUS_CODE,
   SRC.SOURCE_SYSTEM_CODE,
   REV_ST.REVIEW_STATUS_DESC,
   REV_ST.ACTIVE_IND
from
   ENT_LEGAL_ENTITY_REF_DATA.REVIEW_STATUS REV_ST Left join
  ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC  	
  ON REV_ST.SOURCE_SYSTEM_ID =SRC.SOURCE_SYSTEM_ID"""

dim_review_status_df = SqldbToDataframe(query_dim_review_status)

if dim_review_status_df.count() > 0:
  
    merge_columns = 'REVIEW_STATUS_CODE,SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'DIM_REVIEW_STATUS', dim_review_status_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(dim_review_status_df)

# COMMAND ----------

# DBTITLE 1,DIM_SERVICE_TYPE
query_dim_service_type = """select
   ST.SERVICE_TYPE_CODE,
   SRC.SOURCE_SYSTEM_CODE,
   ST.SERVICE_TYPE_DESC,
   ST.ACTIVE_IND
from
   ENT_LEGAL_ENTITY_REF_DATA.SERVICE_TYPE ST Left join
  ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC  	
  ON ST.SOURCE_SYSTEM_ID =SRC.SOURCE_SYSTEM_ID"""

dim_service_type_df = SqldbToDataframe(query_dim_service_type)

if dim_service_type_df.count() > 0:
  
    merge_columns = 'SERVICE_TYPE_CODE,SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'DIM_SERVICE_TYPE', dim_service_type_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(dim_service_type_df)

# COMMAND ----------

# DBTITLE 1,DIM_SHELL_COMPANY
query_dim_shell_company = """select
   SH_CMP.SHELL_COMPANY_CODE,
   SRC.SOURCE_SYSTEM_CODE,
   SH_CMP.SHELL_COMPANY_DESC,
   SH_CMP.ACTIVE_IND
from
   ENT_LEGAL_ENTITY_REF_DATA.SHELL_COMPANY SH_CMP Left join
  ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC  	
  ON SH_CMP.SOURCE_SYSTEM_ID =SRC.SOURCE_SYSTEM_ID"""

dim_shell_company_df = SqldbToDataframe(query_dim_shell_company)

if dim_shell_company_df.count() > 0:
  
    merge_columns = 'SHELL_COMPANY_CODE,SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'DIM_SHELL_COMPANY', dim_shell_company_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(dim_shell_company_df)

# COMMAND ----------

# DBTITLE 1,DIM_TRADING_DESK
query_dim_trading_desk = """select
   TD.TRADING_DESK_CODE,
   SRC.SOURCE_SYSTEM_CODE,
   TD.TRADING_DESK_DESC,
   TD.ACTIVE_IND
from
   ENT_LEGAL_ENTITY_REF_DATA.TRADING_DESK TD Left join
  ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC  	
  ON TD.SOURCE_SYSTEM_ID =SRC.SOURCE_SYSTEM_ID"""

dim_trading_desk_df = SqldbToDataframe(query_dim_trading_desk)

if dim_trading_desk_df.count() > 0:
  
    merge_columns = 'TRADING_DESK_CODE,SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'DIM_TRADING_DESK', dim_trading_desk_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(dim_trading_desk_df)

# COMMAND ----------

# DBTITLE 1,KYC_LEVEL_OF_DD
query_kyc_level_of_dd = """select
   DD.KYC_LEVEL_OF_DD_CD AS KYC_LEVEL_OF_DD_CODE,
   SRC.SOURCE_SYSTEM_CODE,
   DD.KYC_LEVEL_OF_DD_DESC,
   DD.ACTIVE_IND
from
   ENT_LEGAL_ENTITY_REF_DATA.KYC_LEVEL_OF_DD DD Left join
  ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC  	
  ON DD.SOURCE_SYSTEM_ID =SRC.SOURCE_SYSTEM_ID""";

kyc_level_of_dd_df = SqldbToDataframe(query_kyc_level_of_dd)

if kyc_level_of_dd_df.count() > 0:
  
    merge_columns = 'KYC_LEVEL_OF_DD_CODE,SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'DIM_KYC_LEVEL_OF_DD', kyc_level_of_dd_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(kyc_level_of_dd_df)

# COMMAND ----------

# DBTITLE 1,SOURCE_SYSTEM
query_source_system = """select
   SOURCE_SYSTEM_CODE,
   SOURCE_SYSTEM_NAME AS SOURCE_SYSTEM_DESC,
   ACTIVE_IND
from
  ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC"""

source_system_df = SqldbToDataframe(query_source_system)

if source_system_df.count() > 0:
  
    merge_columns = 'SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'SOURCE_SYSTEM', source_system_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(source_system_df)

# COMMAND ----------

# DBTITLE 1,DIM_COUNTERPARTY_ROLE
query_dim_counterparty_role = """select
   RL.COUNTERPARTY_ROLE_CODE,
   SRC.SOURCE_SYSTEM_CODE,
   RL.COUNTERPARTY_ROLE_DESC,
   RL.ACTIVE_IND
from
   ENT_LEGAL_ENTITY_REF_DATA.COUNTERPARTY_ROLE RL 
Left join
  ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM SRC  	
  ON RL.SOURCE_SYSTEM_ID =SRC.SOURCE_SYSTEM_ID
where
  RL.ACTIVE_IND='Y'"""

dim_counterparty_role_df = SqldbToDataframe(query_dim_counterparty_role)

if dim_counterparty_role_df.count() > 0:
  
    merge_columns = 'COUNTERPARTY_ROLE_CODE,SOURCE_SYSTEM_CODE';
    UpsertDataToSQLDB('MDM_CGR', 'DIM_COUNTERPARTY_ROLE', dim_counterparty_role_df, merge_columns, db_url=Stratos_sqldb_URL_curated, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)

display(dim_counterparty_role_df)
