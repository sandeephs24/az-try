# Databricks notebook source
#make all the imports here
import json
import pyspark.sql.functions as sf
import pyodbc

from pyspark.sql.functions import *
from pyspark.sql import functions as f
from pyspark.sql.types import StringType, StructType, StructField, IntegerType, TimestampType, LongType, DoubleType, 
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %run "/Shared/CP_Data/Config/config"

# COMMAND ----------

# DBTITLE 1,Define Variables
staging_table_suffix = "_STAGING_CGR"
backup_table_suffix = '_BACKUP_CGR'
default_value_for_nulls = ''

databricks_error_prefix = 'Databricks error: '
default_status_description='Process succeeded'
load_status_success = 'Success'
load_status_failed='failed'

default_pipeline_run_id = '999999999999999'

# Use case code and dataset properties - used in upserting records into watermak and load status table
usecase_code = 'CGR';
dataset_mdm_party = 'MDM_PARTY';
dataset_mdm_counterparty_scope = 'MDM_COUNTERPARTY_SCOPE';
dataset_mdm_counterparty_xref = 'MDM_COUNTERPARTY_XREF';
dataset_mdm_counterparty_scope_xref = 'MDM_COUNTERPARTY_SCOPE_XREF';
dataset_mdm_counterparty_xref_mapping = 'MDM_COUNTERPARTY_XREF_MAPPING';
dataset_standard_values = 'STANDARD_VALUES_REF_DATA';

meta_created_date_mdm_party = '';
meta_created_date_counterparty_xref = '';
meta_created_date_counterparty_scope_xref = '';
meta_created_date_counterparty_scope = '';
meta_created_date_counterparty_xref_mapping = '';
meta_created_date_standard_values = '';

# New watermark value variables - To save to watermark tabler in SQL DB
new_watermark_value_mdm_party = None;
new_watermark_value_mdm_counterparty_xref = None;
new_watermark_value_counterparty_xref_mapping = None;
new_watermark_value_mdm_counterparty_scope_xref = None;
new_watermark_value_counterparty_scope = None;
new_watermark_value_sanction_list = None;
new_watermark_value_reference_sheet = None;
#######################################

######### Variables for Curated DB VIEWS #########
src_schema_name = 'MDM_CGR';
tgt_schema_name = 'MDM_CGR_VW';
authorized_user_group = 'VALID_ACCESS_GROUP_NAME';
masked_value_default = 'XXXXXXXXXX';
#################################################

# COMMAND ----------

def SqldbToDataframe(custom_query, db_url = Stratos_sqldb_URL):
  
    custom_query_df = None;
    
    if len(custom_query) > 1:
      
        custom_query_string = f"""({custom_query}) custom_query""";
         
        custom_query_df = spark.read.jdbc(db_url, table=custom_query_string);
        
    return custom_query_df;

# COMMAND ----------

# Sync datafrom harmonized SQL DB to Curated SQL DB table
def SyncHarmonizedDataToCuratedTable(query='', tgt_schema_name='', tgt_table_name='', write_mode='append'):
    
    harmonized_data_df = None;
    if len(query) > 0:
        harmonized_data_df = LoadDataFromSQLDB(query=query)
        
    if harmonized_data_df is not None and harmonized_data_df.count() > 0:
        
        # Write data to Curated SQL DB
        harmonized_data_df.write.jdbc(Stratos_sqldb_URL_curated, f"{tgt_schema_name}.{tgt_table_name}", write_mode)
      
        display(harmonized_data_df)    

# COMMAND ----------

def SaveDataToSQLDB(tgt_schema_name, tgt_table_name, dataframe, write_mode='append'):
    
    if dataframe is not None \
        and tgt_schema_name is not None and len(tgt_schema_name) > 0 \
        and tgt_table_name is not None and len(tgt_table_name) > 0:
        
        try:
          
            #df = spark.sql(f"select * from  {tgt_schema_name}.{tgt_table_name}")
            df = LoadSourceSystemFromDB(tgt_schema_name, tgt_table_name)
            
            reseed_value = 1           
            if df.count() > 0:
                reseed_value = 0
              
            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                                      'SERVER='+dbServer+';'
                                      'DATABASE='+dbDatabase+';UID='+dbUser+';'
                                      'PWD='+dbPass
                                  )
            cursor = conn.cursor()
            
            # Delete records from the table and reset the auto-increment counter
            execSQL = f"delete from {tgt_schema_name}.{tgt_table_name}; DBCC CHECKIDENT ( '{tgt_schema_name}.{tgt_table_name}', RESEED, " + str(reseed_value) + " )"
            conn.autocommit = True
            cursor.execute(execSQL)
            print("Data been Deleted")
              
            #dataframe.write.jdbc(Stratos_sqldb_URL, f"{tgt_schema_name}.{tgt_table_name}", write_mode)
            #print(f"load of {tgt_table_name}  with  is completed")
            
        except Exception as e:
          print('Exception raised')
          raise dbutils.notebook.exit(e)

# COMMAND ----------

#def ExecuteCustomSQLQuery(custom_query, dbServer=dbServer, dbDatabase=dbDatabase, dbUser=dbUser, dbPass=dbPass):
#    if custom_query is not None and len(custom_query) > 0:
#      
#        try:
#        
#            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
#                                      'SERVER='+dbServer+';'
#                                      'DATABASE='+dbDatabase+';UID='+dbUser+';'
#                                      'PWD='+dbPass
#                                  )
#            cursor = conn.cursor();
#            conn.autocommit = True
#            cursor.execute(custom_query)
#            cursor.close()
#            conn.close()
#              
#        except Exception as e:
#          print('Exception raised')
#          raise dbutils.notebook.exit(e)

def ExecuteCustomSQLQuery(custom_query, dbServer=dbServer, dbDatabase=dbDatabase, dbUser=dbUser, dbPass=dbPass, return_result=False):
  
    results_to_return = None;
    if custom_query is not None and len(custom_query) > 0:
      
        try:
        
            conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                                      'SERVER='+dbServer+';'
                                      'DATABASE='+dbDatabase+';UID='+dbUser+';'
                                      'PWD='+dbPass
                                  )
            cursor = conn.cursor();
            conn.autocommit = True
            
            query_result = cursor.execute(custom_query)  
            
            if return_result == True:            
                results_to_return = cursor.fetchall();
              
            cursor.close()
            conn.close()
                
        except Exception as e:
          print('Exception raised')
          raise dbutils.notebook.exit(e)            
            
    if return_result == True:               
        return results_to_return;

# COMMAND ----------

def LoadWatermarkValue(usecase_code, dataset, dbServer=dbServer, dbDatabase=dbDatabase, return_result=False):
    
    last_watermark_value = None
    if usecase_code is not None and len(usecase_code) > 0 and dataset is not None and len(dataset) > 0:
      
        sp_query = "EXEC CGR.usp_load_watermark_value @usecase_code='" + usecase_code + "', @dataset='" + dataset + "'"
        last_watermark_value_list = ExecuteCustomSQLQuery(sp_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated, return_result=True)
        
        if len(last_watermark_value_list) > 0:
            
            last_watermark_value = last_watermark_value_list[0][0] if last_watermark_value_list[0] is not None and last_watermark_value_list[0][0] is not None else None;
        
    return last_watermark_value;

# COMMAND ----------

def UpsertWatermarkValue(usecase_code, dataset, last_load_value, dbServer=dbServer, dbDatabase=dbDatabase):
    
    if usecase_code is not None and len(usecase_code) > 0 and dataset is not None and len(dataset) > 0 and last_load_value is not None and len(str(last_load_value)) > 0:
      
        #sp_query = "EXEC CGR.usp_upsert_watermark @usecase_code='" + usecase_code + "', @dataset='" + dataset + "', @last_load_value='" + last_load_value + "';"
        sp_query = f"""EXEC CGR.usp_upsert_watermark @usecase_code='{usecase_code}', @dataset='{dataset}', @last_load_value='{last_load_value}';"""
        #print(sp_query);
        #last_watermark_value_list = ExecuteCustomSQLQuery(sp_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)
        ExecuteCustomSQLQuery(sp_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)
        

# COMMAND ----------

def LoadSourceSystemFromDB(tgt_schema_name, tgt_table_name):
  
    source_system_query = "(SELECT * FROM [" + tgt_schema_name + "].[" + tgt_table_name + "]) cdc";
     
    source_system_df = spark.read.jdbc(Stratos_sqldb_URL, table=source_system_query);
    
    return source_system_df;
  
def LoadDataFromSQLDB(tgt_schema_name='', tgt_table_name='', query='', connection_url=''):
    
    query = "(" + query + ") custom_query" if len(query) > 0 else "(SELECT * FROM [" + tgt_schema_name + "].[" + tgt_table_name + "]) custom_query";
    
    connection_url = Stratos_sqldb_URL if len(connection_url)==0 else connection_url;
    
    #print(query)
     
    source_system_df = spark.read.jdbc(connection_url, table=query);
    
    return source_system_df;

# COMMAND ----------

def CreateSQLDBView(src_schema_name='', src_table_name='', tgt_schema_name='', tgt_view_name='', columns='', create_view_query=''):
    
    drop_view_query = '';
      
    if len(create_view_query) == 0 and len(src_schema_name) > 0 and len(src_table_name) > 0 and len(tgt_schema_name) > 0 and len(tgt_view_name) > 0:
        # Create View
        
        create_view_query = f"""
        CREATE View {tgt_schema_name}.{tgt_view_name} 
        AS 
        SELECT 
          {columns} 
        FROM {src_schema_name}.{src_table_name}  
        Go
        """
    
    if len(create_view_query) > 0:
        drop_view_query = f"""DROP VIEW if EXISTS {tgt_schema_name}.{tgt_view_name};""";
      
    #print(create_view_query)
                      
    if len(create_view_query) > 0:
        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                          'SERVER='+dbServer_curated+';'
                          'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
                          'PWD='+dbPass
                      )
        cursor = conn.cursor()
        
        conn.autocommit = True
                      
        if len(drop_view_query) > 0:
            cursor.execute(drop_view_query)
            
        cursor.execute(create_view_query)
        cursor.close()
        conn.close()

# COMMAND ----------

def GenerateSCDMergeQuery(columns, merge_columns, source_table, target_table, scd_type='scd_1'):
    
    target_column_alias = 'Target';
    source_column_alias = 'Source';
    
    columns_list = columns.split(',')
    
    # Columns on which to join Source and Target tables
    merge_columns_list = merge_columns.split(",") if merge_columns is not None and len(merge_columns) > 0 else [];
    join_columns_list = [];
    if len(merge_columns_list) > 0:
        join_columns_list = [target_column_alias+'.'+merge_column+'='+source_column_alias+'.'+merge_column if len(merge_column) > 0 else '' for merge_column in merge_columns_list];
        
    join_column = ' AND '.join(join_columns_list) if len(join_columns_list) > 0 else '';
    
    # Generate columns to be updated
    update_columns = '';
    merge_update_list = list(set(columns_list)-set(merge_columns_list));
    update_columns_list = [];
    if len(merge_update_list) > 0:
        update_columns_list = [target_column_alias+'.'+merge_column.strip()+'='+source_column_alias+'.'+merge_column.strip() if len(merge_column.strip()) > 0 else '' for merge_column in merge_update_list];
        
    # If SCD 2 - Tweak logic
    
    update_column = ', '.join(update_columns_list) if len(update_columns_list) > 0 else '';
    
    # Generate INSERT column names and values
    insert_columns = '';
    insert_columns_values = '';
    if len(columns_list) > 0:
        for column in columns_list:
            column = column.strip()
            if len(column) > 0:
                insert_columns += column + ', ';
                insert_columns_values += source_column_alias + '.' + column + ', '
    
    # Remove last 2 characters 
    insert_columns = insert_columns[:-2] if len(insert_columns) > 0 else '';
    insert_columns_values = insert_columns_values[:-2] if len(insert_columns_values) > 0 else '';    
    
    merge_query = '';
  
    if columns is not None and source_table is not None and  target_table is not None \
      and  len(columns) > 0 and len(target_table) > 0 and len(source_table) > 0:
        
        if scd_type == 'scd_1':
          
            merge_query = f"""MERGE {target_table} AS {target_column_alias}
                              USING (SELECT DISTINCT * FROM {source_table}) AS {source_column_alias} 
                                    ON {join_column}
                              WHEN MATCHED THEN
                                  UPDATE SET {update_column}
                              WHEN NOT MATCHED THEN
                                  INSERT ({insert_columns}) 
                                  VALUES ({insert_columns_values});""";

        elif scd_type == 'scd_2':
          
            when_matched_condition = target_column_alias + ".END_DATE='2999-12-31'"
            when_matched_update_columns = target_column_alias + ".END_DATE=DATEADD(day,-1," + target_column_alias + ".EFFECTIVE_DATE)"
                  
            merge_query = f"""MERGE {target_table} AS {target_column_alias}
                              USING (SELECT DISTINCT * FROM {source_table}) AS {source_column_alias} 
                                    ON {join_column}
                              WHEN MATCHED AND {when_matched_condition} THEN
                                  UPDATE SET {when_matched_update_columns};
                                  
                              INSERT INTO {target_table} ({insert_columns})
                              SELECT
                                  {insert_columns}
                              FROM {source_table}
                                  """;
            
            # MERGE didn't work because of foreign key relationship in tables
            #merge_query = f"""INSERT INTO {target_table} ({insert_columns})
            #                  SELECT
            #                      {insert_columns}
            #                  FROM
            #                      ( MERGE {target_table} AS {target_column_alias}
            #                        USING {source_table} AS {source_column_alias}
            #                        ON ({join_column})
            #                        WHEN NOT MATCHED THEN
            #                            INSERT ({insert_columns}) 
            #                            VALUES ({insert_columns_values})
            #                        WHEN MATCHED AND {when_matched_condition} THEN
            #                             UPDATE SET {when_matched_update_columns}
            #                        OUTPUT $Action Action_Out,
            #                                {insert_columns_values}
            #                      ) AS MERGE_OUT
            #                  WHERE MERGE_OUT.Action_Out = 'UPDATE';""";
    
    
    return merge_query;

# COMMAND ----------

#def UpsertDataToSQLDB(tgt_schema_name, tgt_table_name, dataframe, merge_columns, write_mode='overwrite', db_url=Stratos_sqldb_URL, scd_type='scd_1', dbServer=dbServer, dbDatabase=dbDatabase, alter_staging_columns=''):
#    
#    try:
#    
#        # Staging table name
#        tgt_table_name_staging = '';        
#        if tgt_table_name is not None and len(tgt_table_name) > 0:
#            tgt_table_name_staging = tgt_table_name + staging_table_suffix
#            
#        # Main table name
#        main_table_name = tgt_schema_name + '.' + tgt_table_name + ''
#        # Staging table name
#        staging_table_name = tgt_schema_name + '.' + tgt_table_name_staging + ''
#        
#        # Get column names
#        source_columns_list = dataframe.columns        
#        source_columns = ', '.join(source_columns_list)
#        
#        # Create CREATE staging table query
#        # staging_table_create_query = f"""IF OBJECT_ID('{tgt_schema_name}.{tgt_table_name_staging}', 'U') IS NULL  
#        # SELECT TOP 0 {source_columns} INTO {tgt_schema_name}.{tgt_table_name_staging} FROM {tgt_schema_name}.{tgt_table_name}"""
#        staging_table_create_query = f"""IF OBJECT_ID('{staging_table_name}', 'U') IS NULL  
#        SELECT TOP 0 {source_columns} INTO {staging_table_name} FROM {main_table_name}"""
#        
#        # Create Staging table if it doesn't exist
#        ExecuteCustomSQLQuery(staging_table_create_query, dbServer=dbServer, dbDatabase=dbDatabase)
#        
#        alter_staging_columns = alter_staging_columns.replace('##StagingTableName##', staging_table_name) if alter_staging_columns is not None and len(alter_staging_columns) > 0 else '';
#        # Execute clustered index creation
#        if alter_staging_columns is not None and len(alter_staging_columns) > 0:
#            ExecuteCustomSQLQuery(alter_staging_columns, dbServer=dbServer, dbDatabase=dbDatabase)
#        
#        # Create clustered index
#        clustered_index_create_query = f"""IF OBJECT_ID('{staging_table_name}', 'U') IS NOT NULL
#        CREATE CLUSTERED INDEX IX_{tgt_schema_name}_{tgt_table_name_staging} ON {staging_table_name}({merge_columns})""";
#        ExecuteCustomSQLQuery(clustered_index_create_query, dbServer=dbServer, dbDatabase=dbDatabase)
#        
#        
#        # Load data into Staging table
#        dataframe.write.jdbc(db_url, f"{tgt_schema_name}.{tgt_table_name_staging}", write_mode)
#        
#        # Generate UPSERT query
#        merge_query = GenerateSCDMergeQuery(source_columns, merge_columns, staging_table_name, main_table_name, scd_type)
#        
#        # Execute UPSERT query
#        ExecuteCustomSQLQuery(merge_query, dbServer=dbServer, dbDatabase=dbDatabase)
#        
#        print(merge_query)
#      
#        # Generate DROP staging query
#        staging_table_drop_query = f"""IF OBJECT_ID('{tgt_schema_name}.{tgt_table_name_staging}', 'U') IS NOT NULL  
#        DROP TABLE {tgt_schema_name}.{tgt_table_name_staging}"""
#          
#        # Drop Staging table if it exist
#        ExecuteCustomSQLQuery(staging_table_drop_query, dbServer=dbServer, dbDatabase=dbDatabase)
#          
#    except Exception as e:
#      
#        # Generate DROP staging query
#        staging_table_drop_query = f"""IF OBJECT_ID('{tgt_schema_name}.{tgt_table_name_staging}', 'U') IS NOT NULL  
#        DROP TABLE {tgt_schema_name}.{tgt_table_name_staging}"""
#          
#        # Drop Staging table if it exist
#        ExecuteCustomSQLQuery(staging_table_drop_query, dbServer=dbServer, dbDatabase=dbDatabase)
#          
#        print('Exception raised')
#        raise dbutils.notebook.exit(e)


def UpsertDataToSQLDB(pipeline_run_id
                      , tgt_schema_name
                      , tgt_table_name
                      , dataframe
                      , merge_columns=''
                      , write_mode='overwrite'
                      , db_url=Stratos_sqldb_URL
                      , scd_type='scd_1'
                      , dbServer=dbServer
                      , dbDatabase=dbDatabase
                      , fullRefresh=False
                      , source_dataset=None
                     ):
    
    try:
        
        # Staging table name
        tgt_table_name_staging = '';  
        tgt_table_name_backup = '';
        if tgt_table_name is not None and len(tgt_table_name) > 0:
            tgt_table_name_staging = tgt_table_name + staging_table_suffix
            tgt_table_name_backup = tgt_table_name + backup_table_suffix
            
        # Main table name
        main_table_name = tgt_schema_name + '.' + tgt_table_name + ''
        # Staging table name
        staging_table_name = tgt_schema_name + '.' + tgt_table_name_staging + ''
        backup_table_name = tgt_schema_name + '.' + tgt_table_name_backup
        
        # Get column names
        source_columns_list = dataframe.columns        
        source_columns = ', '.join(source_columns_list)
        
        if fullRefresh == False:
        
            # Create CREATE staging table query
            # staging_table_create_query = f"""IF OBJECT_ID('{tgt_schema_name}.{tgt_table_name_staging}', 'U') IS NULL  
            # SELECT TOP 0 {source_columns} INTO {tgt_schema_name}.{tgt_table_name_staging} FROM {tgt_schema_name}.{tgt_table_name}"""
            staging_table_create_query = f"""IF OBJECT_ID('{staging_table_name}', 'U') IS NULL  
            SELECT TOP 0 {source_columns} INTO {staging_table_name} FROM {main_table_name}"""            
            # Create Staging table if it doesn't exist
            ExecuteCustomSQLQuery(staging_table_create_query, dbServer=dbServer, dbDatabase=dbDatabase)
            
            # Create clustered index
            clustered_index_create_query = f"""IF OBJECT_ID('{staging_table_name}', 'U') IS NOT NULL
            CREATE CLUSTERED INDEX IX_{tgt_schema_name}_{tgt_table_name_staging} ON {staging_table_name}({merge_columns})""";
            #ExecuteCustomSQLQuery(clustered_index_create_query, dbServer=dbServer, dbDatabase=dbDatabase)
              
            # Load data into Staging table
            dataframe.write.jdbc(db_url, f"{tgt_schema_name}.{tgt_table_name_staging}", write_mode)
            
            # Generate UPSERT query
            merge_query = GenerateSCDMergeQuery(source_columns, merge_columns, staging_table_name, main_table_name, scd_type)
            
            # Execute UPSERT query
            ExecuteCustomSQLQuery(merge_query, dbServer=dbServer, dbDatabase=dbDatabase)
                
            # Generate DROP staging query
            staging_table_drop_query = f"""IF OBJECT_ID('{tgt_schema_name}.{tgt_table_name_staging}', 'U') IS NOT NULL  
            DROP TABLE {tgt_schema_name}.{tgt_table_name_staging}"""          
            # Drop Staging table if it exist
            ExecuteCustomSQLQuery(staging_table_drop_query, dbServer=dbServer, dbDatabase=dbDatabase)
            
            print(merge_query)            
            print(staging_table_create_query)
        
        else:
          
            ## If backup exist, delete it
            #backup_remove_query = f"""IF OBJECT_ID('{backup_table_name}', 'U') IS NOT NULL
            #DROP TABLE {backup_table_name}""";
            #ExecuteCustomSQLQuery(backup_remove_query, dbServer=dbServer, dbDatabase=dbDatabase)
            #
            #print(backup_remove_query)
            #
            ## Backup original table
            #backup_query = f"""IF OBJECT_ID('{main_table_name}', 'U') IS NOT NULL
            #SELECT * INTO {backup_table_name} FROM {main_table_name}""";
            #ExecuteCustomSQLQuery(backup_query, dbServer=dbServer, dbDatabase=dbDatabase)
            
            # Backup original table
            truncate_query = f"""IF OBJECT_ID('{main_table_name}', 'U') IS NOT NULL
            TRUNCATE TABLE {main_table_name}""";
            ExecuteCustomSQLQuery(truncate_query, dbServer=dbServer, dbDatabase=dbDatabase)
            
            # Overwrite original table
            dataframe.write.jdbc(db_url, f"{tgt_schema_name}.{tgt_table_name}", write_mode)
            
            source_count = dataframe.count();
            
            column_to_count = dataframe.columns[0]
            target_record_count_query= "(select " + column_to_count + " from [" + tgt_schema_name + "].[" + tgt_table_name + "])t"
            target_count_df= spark.read.jdbc(Stratos_sqldb_URL_curated, table= target_record_count_query)
            target_count = target_count_df.count();
            
            # Log process succeeded in the process log table
            UpdateProcessLog(usecase_code
                     ,pipeline_run_id
                     ,source_dataset
                     ,source_layer_code=source_layer_code
                     ,load_status=load_status_success
                     ,created_by=created_by
                     ,dbServer=dbServer
                     ,dbDatabase=dbDatabase
                     ,target_layer_code=target_layer_code
                     ,target_dataset=tgt_schema_name+'.'+tgt_table_name
                     ,status_description=default_status_description
                     ,source_count=source_count
                     ,target_count=target_count
                    );
                        
            #row_count_query = f"""SELECT COUNT(1) FROM {main_table_name}""";
            #number_of_rows_written = ExecuteCustomSQLQuery(row_count_query, dbServer=dbServer, dbDatabase=dbDatabase, return_result=True)            
            ## If original table is empty, copy backup to original table
            #if number_of_rows_written[0] is None or number_of_rows_written[0][0] is None or number_of_rows_written[0][0] == 0:
            #    revert_query = f"""INSERT INTO {main_table_name} SELECT * FROM {backup_table_name}""";
            #    ExecuteCustomSQLQuery(revert_query, dbServer=dbServer, dbDatabase=dbDatabase)
            #    
            ## Generate DROP staging query
            #backup_table_drop_query = f"""IF OBJECT_ID('{tgt_schema_name}.{tgt_table_name_backup}', 'U') IS NOT NULL  
            #DROP TABLE {tgt_schema_name}.{tgt_table_name_backup}"""          
            ## Drop Staging table if it exist
            #ExecuteCustomSQLQuery(backup_table_drop_query, dbServer=dbServer, dbDatabase=dbDatabase)
          
    except Exception as e:
        
        if fullRefresh == True:
                        
            row_count_query = f"""SELECT COUNT(1) FROM {main_table_name}""";
            number_of_rows_written = ExecuteCustomSQLQuery(row_count_query, dbServer=dbServer, dbDatabase=dbDatabase, return_result=True)          
            # If original table is empty, copy backup to original table
            if number_of_rows_written[0] is None or number_of_rows_written[0][0] is None or number_of_rows_written[0][0] == 0:
                revert_query = f"""INSERT INTO {main_table_name} SELECT * FROM {backup_table_name}""";
                
            # Generate DROP staging query
            backup_table_drop_query = f"""IF OBJECT_ID('{tgt_schema_name}.{tgt_table_name_backup}', 'U') IS NOT NULL  
            DROP TABLE {tgt_schema_name}.{tgt_table_name_staging}"""          
            # Drop Staging table if it exist
            ExecuteCustomSQLQuery(backup_table_drop_query, dbServer=dbServer, dbDatabase=dbDatabase)
        
        # Generate DROP staging query
        staging_table_drop_query = f"""IF OBJECT_ID('{tgt_schema_name}.{tgt_table_name_staging}', 'U') IS NOT NULL  
        DROP TABLE {tgt_schema_name}.{tgt_table_name_staging}"""
          
        # Drop Staging table if it exist
        ExecuteCustomSQLQuery(staging_table_drop_query, dbServer=dbServer, dbDatabase=dbDatabase)
          
        # Log process failed in the process log table
        UpdateProcessLog(usecase_code=usecase_code
                 , pipeline_run_id=pipeline_run_id
                 , source_dataset=source_dataset
                 , source_layer_code=source_layer_code
                 , load_status=load_status_failed
                 , created_by=created_by
                 , dbServer=dbServer
                 , dbDatabase=dbDatabase
                 , target_layer_code=target_layer_code
                 , target_dataset=tgt_schema_name+'.'+tgt_table_name
                 , status_description=databricks_error_prefix + str(e)[0:7998]
                );
            
        print('Exception raised')
        raise dbutils.notebook.exit(e)
  

# COMMAND ----------

# DBTITLE 1,Validate Data
def ValidateSourceData(dataframe = None, columns=[], validation_type = '', source_dataset=''):
    
    validation_result = [];
    
    if len(validation_type) > 0 and len(columns) > 0 and dataframe is not None:
      
        if validation_type.lower() == 'mandatory_column':
          
            for column in columns:
              
                if len(column) > 0:
                  
                    if dataframe.filter(column + " IS NOT NULL OR " + column + " != ''").count() == 0:
                        
                        validation_result.append({
                          'source_dataset': source_dataset,
                          'validation_status': 'Failed',
                          'validation_message': validation_type.replace('_', ' ') +  ' "' + column + '" is empty.'
                        });
                      
    return validation_result;

      


# COMMAND ----------

# DBTITLE 1,Update Process Log
def UpdateProcessLog(usecase_code
                     , pipeline_run_id
                     , source_dataset
                     , source_layer_code
                     , load_status
                     , created_by
                     , dbServer
                     , dbDatabase
                     , target_layer_code=None
                     , target_dataset=None
                     , status_description=None
                     , source_count = None
                     , target_count = None
                    ):
  
    status_description = str(status_description) if len(status_description) > 0 else '';
  
    if len(pipeline_run_id) > 0 and len(target_dataset) > 0:
      
        processing_log_sp_query = f"""EXEC [CGR].[insert_processing_log] 
                       @usecase_code='{usecase_code}'
                       , @pipeline_run_id='{pipeline_run_id}'
                       , @source_dataset='{source_dataset}'
                       , @target_dataset='{target_dataset}'
                       , @source_layer_code='{source_layer_code}'
                       , @target_layer_code='{target_layer_code}'
                       , @source_record_count='{source_count}'
                       , @target_record_count='{target_count}'
                       , @load_status='{load_status}'
                       , @status_description='{status_description}'
                       , @created_by='{created_by}'
                   """;
        #print(processing_log_sp_query)
        ExecuteCustomSQLQuery(processing_log_sp_query, dbServer=dbServer, dbDatabase=dbDatabase)

# COMMAND ----------

# DBTITLE 1,Load Watermark Values
# Get watermark value from sql db - Used for incremental data load from unharmonized ADLS
last_watermark_value_mdm_party = LoadWatermarkValue(usecase_code, dataset_mdm_party, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated, return_result=True);

last_watermark_value_mdm_counterparty_scope = LoadWatermarkValue(usecase_code, dataset_mdm_counterparty_scope, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated, return_result=True);

last_watermark_value_mdm_counterparty_xref = LoadWatermarkValue(usecase_code, dataset_mdm_counterparty_xref, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated, return_result=True);

last_watermark_value_mdm_counterparty_scope_xref = LoadWatermarkValue(usecase_code, dataset_mdm_counterparty_scope_xref, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated, return_result=True);

last_watermark_value_mdm_counterparty_xref_mapping = LoadWatermarkValue(usecase_code, dataset_mdm_counterparty_xref_mapping, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated, return_result=True);

last_watermark_value_standard_values = LoadWatermarkValue(usecase_code, dataset_standard_values, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated, return_result=True);
