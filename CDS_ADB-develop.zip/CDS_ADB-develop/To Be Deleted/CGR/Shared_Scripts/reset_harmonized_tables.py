# Databricks notebook source
# MAGIC %run "/CGR/Shared_Scripts/Main"

# COMMAND ----------

#tables_reset_query = f"""
#truncate table [ENT_LEGAL_ENTITY].[PARTY_IDENTIFICATION];""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#truncate table [ENT_LEGAL_ENTITY].[PARTY_NAME];""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#truncate table [ENT_LEGAL_ENTITY_CONTACT].[PARTY_ADDRESS];""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#truncate table [ENT_LEGAL_ENTITY].[PARTY_KYC_STATUS];""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#truncate table [ENT_LEGAL_ENTITY].[PARTY_STATUS];""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY].[COUNTERPARTY_SCOPE]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY.COUNTERPARTY_SCOPE', RESEED, 0);""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY].[PARTY]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY.PARTY', RESEED, 0);""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[PARTY_XREF]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.PARTY_XREF', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[LEGAL_CLASSIFICATION]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.LEGAL_CLASSIFICATION', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[PARTY_NAME_TYPE]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.PARTY_NAME_TYPE', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[PARTY_TYPE]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.PARTY_TYPE', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[OPERATING_REGION]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.OPERATING_REGION', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[ENTITY_TYPE]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.ENTITY_TYPE', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[LEGAL_STATUS]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.LEGAL_STATUS', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[COMPANY_TYPE]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.COMPANY_TYPE', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[IDENTIFICATION_TYPE]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.IDENTIFICATION_TYPE', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[REGION_STATE]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.REGION_STATE', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[COUNTRY]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.COUNTRY', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[ADDRESS_TYPE]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.ADDRESS_TYPE', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[KYC_STATUS_VALUE]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.KYC_STATUS_VALUE', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[KYC_LEVEL_OF_DD]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.KYC_LEVEL_OF_DD', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[PARTY_STATUS_VALUE]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.PARTY_STATUS_VALUE', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[PARTY_STATUS_TYPE]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.PARTY_STATUS_TYPE', RESEED, 0 ); """;
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[BUSINESS_AREA]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.BUSINESS_AREA', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[COMMODITY]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.COMMODITY', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[SHELL_COMPANY]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.SHELL_COMPANY', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[END_SYSTEM_CLASS]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.END_SYSTEM_CLASS', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[SERVICE_TYPE]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.SERVICE_TYPE', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[COUNTERPARTY_ROLE]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.COUNTERPARTY_ROLE', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[REVIEW_STATUS]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.REVIEW_STATUS', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[TRADING_DESK]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.TRADING_DESK', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query);
#
#tables_reset_query = f"""
#delete from [ENT_LEGAL_ENTITY_REF_DATA].[SOURCE_SYSTEM]; DBCC CHECKIDENT ('ENT_LEGAL_ENTITY_REF_DATA.SOURCE_SYSTEM', RESEED, 0 );""";
#ExecuteCustomSQLQuery(tables_reset_query)
