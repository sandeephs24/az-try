# Databricks notebook source
# MAGIC %run "/CGR/Shared_Scripts/Main"

# COMMAND ----------

#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[COUNTERPARTY]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[COUNTERPARTY_ADDRESS]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[COUNTERPARTY_IDENTIFICATION]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[COUNTERPARTY_SCOPE]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[COUNTERPARTY_STATUS]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_ADDRESS_TYPE]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_BUSINESS_AREA]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_COMMODITY]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_COMPANY_TYPE]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_COUNTERPARTY_ROLE]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_CREDIT_ASSESSED_STATUS]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_ENTITY_TYPE]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_IDENTIFICATION_TYPE]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_KYC_LEVEL_OF_DD]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_LEGAL_CLASSIFICATION]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE MDM_CGR.DIM_OPERATING_REGION"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_REVIEW_STATUS]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_SERVICE_TYPE]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_SHELL_COMPANY]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[DIM_TRADING_DESK]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[KYC_LEVEL_OF_DD]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
#
#tables_reset_query = f"""TRUNCATE TABLE [MDM_CGR].[SOURCE_SYSTEM]"""
#ExecuteCustomSQLQuery(tables_reset_query, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated);
