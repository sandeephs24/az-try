# Databricks notebook source
# DBTITLE 1,Load Main File
# MAGIC %run "/CGR/Shared_Scripts/Main"

# COMMAND ----------

# DBTITLE 1,Create Widgets
try:
    dbutils.widgets.text('counter_party_xref_mapping_file', '', 'Counter Party XREF Mapping File');
    dbutils.widgets.text('pipeline_run_id', default_pipeline_run_id, 'Pipeline Run Id');
  
except Exception as e:
  print(str(e))
  
  dbutils.notebook.exit(json.dumps({'status': 'Failed', 'ReadCount': 0, 'WriteCount': 0, 'Message': str(e)[0:7998]}))
  raise Exception(e)

# COMMAND ----------

# DBTITLE 1,Load values from Widgets
try:
    counter_party_xref_mapping_file = dbutils.widgets.get('counter_party_xref_mapping_file');
    pipeline_run_id = dbutils.widgets.get('pipeline_run_id');
    
except Exception as e:
  print(str(e))
  
  dbutils.notebook.exit(json.dumps({'status': 'Failed', 'ReadCount': 0, 'WriteCount': 0, 'Message': databricksErrorPrefix + str(e)[0:7998]}))
  raise Exception(e)

# COMMAND ----------

# DBTITLE 1,Dataframe for Xref Mapping
if counter_party_xref_mapping_file is not None and len(counter_party_xref_mapping_file) > 0:
    MDM_COUNTERPARTY_XREF_MAPPING = spark.read.format("parquet").load(counter_party_xref_mapping_file)
    meta_created_date_counterparty_xref_mapping = " AND META_CREATED_DTTM > '" + last_watermark_value_mdm_counterparty_xref_mapping + "'" if last_watermark_value_mdm_counterparty_xref_mapping is not None else "";
    MDM_COUNTERPARTY_XREF_MAPPING = MDM_COUNTERPARTY_XREF_MAPPING.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_counterparty_xref_mapping );
    new_watermark_value_counterparty_xref_mapping = MDM_COUNTERPARTY_XREF_MAPPING.select("META_CREATED_DTTM").agg({"META_CREATED_DTTM": "max"}).collect()[0][0]
    
    #MDM_COUNTERPARTY_XREF_MAPPING = MDM_COUNTERPARTY_XREF_MAPPING.filter(col("SOURCE_SYSTEM_CODE") == "MDM")
    display(MDM_COUNTERPARTY_XREF_MAPPING)

# COMMAND ----------

# DBTITLE 1,Load Party_Xref
party_xref_df = MDM_COUNTERPARTY_XREF_MAPPING.select(col("MDM_ID"),
                                                     when(col("SOURCE_SYSTEM_CODE") == 'ENERGY_CREDIT', 'ENCR').
                                                     when(col("SOURCE_SYSTEM_CODE") == 'GOLDTIER', 'GLDT').
                                                     when(col("SOURCE_SYSTEM_CODE") == 'ENDUR_GPNA', 'ENGP').
                                                     when(col("SOURCE_SYSTEM_CODE") == 'NUCLEUS', 'NCLS').
                                                     when(col("SOURCE_SYSTEM_CODE") == 'STNSAP', 'STSP').
                                                     when(col("SOURCE_SYSTEM_CODE") == 'ALIGNE', 'ALGN').
                                                     otherwise("Not in Scope").alias("SOURCE_SYSTEM_CODE")
                                                       , col("SOURCE_PARTY_PRIMARY_KEY"))

#SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'PARTY_XREF', party_xref_df)

merge_columns = 'SOURCE_SYSTEM_CODE,SOURCE_PARTY_PRIMARY_KEY'
UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'PARTY_XREF', party_xref_df, merge_columns)

display(party_xref_df)

# COMMAND ----------

if new_watermark_value_counterparty_xref_mapping is not None and len(str(new_watermark_value_counterparty_xref_mapping)) > 0:  
    UpsertWatermarkValue(usecase_code, dataset_mdm_counterparty_xref_mapping, new_watermark_value_counterparty_xref_mapping, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)
