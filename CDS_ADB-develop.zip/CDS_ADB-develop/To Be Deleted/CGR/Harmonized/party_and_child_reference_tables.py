# Databricks notebook source
# DBTITLE 1,Load Main File
# MAGIC %run "/CGR/Shared_Scripts/Main"

# COMMAND ----------

# DBTITLE 1,Create Widgets
try:
  
    dbutils.widgets.text('mdm_party_file', '', 'MDM Party File');
    dbutils.widgets.text('counter_party_xref_file', '', 'Counter Party XREF File');
    dbutils.widgets.text('counter_party_scope_xref_file', '', 'Counter Party Scope XREF File');
    dbutils.widgets.text('counter_party_scope_file', '', 'Counter Party Scope File');
    dbutils.widgets.text('pipeline_run_id', default_pipeline_run_id, 'Pipeline Run Id');
  
except Exception as e:
  print(str(e))
  
  dbutils.notebook.exit(json.dumps({'status': 'Failed', 'ReadCount': 0, 'WriteCount': 0, 'Message': str(e)[0:7998]}))
  raise Exception(e)

# COMMAND ----------

# DBTITLE 1,Load Values from Widget
try:
  
    mdm_party_file = dbutils.widgets.get('mdm_party_file');
    counter_party_xref_file = dbutils.widgets.get('counter_party_xref_file');
    counter_party_scope_xref_file = dbutils.widgets.get('counter_party_scope_xref_file');
    counter_party_scope_file = dbutils.widgets.get('counter_party_scope_file');
    pipeline_run_id = dbutils.widgets.get('pipeline_run_id');
    
except Exception as e:
  print(str(e))
  
  dbutils.notebook.exit(json.dumps({'status': 'Failed', 'ReadCount': 0, 'WriteCount': 0, 'Message': databricksErrorPrefix + str(e)[0:7998]}))
  raise Exception(e)

# COMMAND ----------

# DBTITLE 1,Load Dataframes except Scope Ref Tables
mdm_party_df = None;
if mdm_party_file is not None and len(mdm_party_file) > 0:
    mdm_party_df = spark.read.format("parquet").load(mdm_party_file)
    meta_created_date_mdm_party = " AND META_CREATED_DTTM > '" + last_watermark_value_mdm_party + "' " if last_watermark_value_mdm_party is not None else "";
    mdm_party_df = mdm_party_df.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_mdm_party);
    new_watermark_value_mdm_party = mdm_party_df.select("META_CREATED_DTTM").agg({"META_CREATED_DTTM": "max"}).collect()[0][0]

mdm_counterparty_xref_df = None;
if counter_party_xref_file is not None and len(counter_party_xref_file) > 0:
    mdm_counterparty_xref_df = spark.read.format("parquet").load(counter_party_xref_file)
    meta_created_date_counterparty_xref = " AND META_CREATED_DTTM > '" + last_watermark_value_mdm_counterparty_xref + "'" if last_watermark_value_mdm_counterparty_xref is not None else '';
    mdm_counterparty_xref_df = mdm_counterparty_xref_df.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_counterparty_xref);
    new_watermark_value_mdm_counterparty_xref = mdm_counterparty_xref_df.select("META_CREATED_DTTM").agg({"META_CREATED_DTTM": "max"}).collect()[0][0]
    
mdm_counterparty_scope_xref_df = None;
if counter_party_scope_xref_file is not None and len(counter_party_scope_xref_file) > 0:
    mdm_counterparty_scope_xref_df = spark.read.format("parquet").load(counter_party_scope_xref_file)
    meta_created_date_counterparty_scope_xref = " AND META_CREATED_DTTM > '" + last_watermark_value_mdm_counterparty_scope_xref + "'" if last_watermark_value_mdm_counterparty_scope_xref is not None else "";
    mdm_counterparty_scope_xref_df = mdm_counterparty_scope_xref_df.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_counterparty_scope_xref);
    new_watermark_value_mdm_counterparty_scope_xref = mdm_counterparty_scope_xref_df.select("META_CREATED_DTTM").agg({"META_CREATED_DTTM": "max"}).collect()[0][0]
    
mdm_counterparty_scope_df = None;
if counter_party_scope_file is not None and len(counter_party_scope_file) > 0:
    mdm_counterparty_scope_df = spark.read.format("parquet").load(counter_party_scope_file)
    meta_created_date_counterparty_scope = " AND META_CREATED_DTTM > '" + last_watermark_value_mdm_counterparty_scope + "'" if last_watermark_value_mdm_counterparty_scope is not None else "";
    mdm_counterparty_scope_df = mdm_counterparty_scope_df.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_counterparty_scope);
    new_watermark_value_counterparty_scope = mdm_counterparty_scope_df.select("META_CREATED_DTTM").agg({"META_CREATED_DTTM": "max"}).collect()[0][0]

################################################
####### Load Reference Data from SQL DB ########
################################################
    
# Load source system data from SQL DB
source_system_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'SOURCE_SYSTEM');
source_system_id_code_df = source_system_df.select(col('SOURCE_SYSTEM_ID'), col('SOURCE_SYSTEM_CODE'));
    
# Load company type data from SQL DB
company_type_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'COMPANY_TYPE');
company_type_id_code_df = company_type_df.select(col('COMPANY_TYPE_ID'), col('COMPANY_TYPE_CODE'), col('SOURCE_SYSTEM_ID'));
    
# Load legal classification data from SQL DB
legal_classification_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'LEGAL_CLASSIFICATION');
legal_classification_id_code_df = legal_classification_df.select(col('LEGAL_CLASSIFICATION_ID'), col('LEGAL_CLASSIFICATION_CODE'), col('SOURCE_SYSTEM_ID'));
    
# Load legal status data from SQL DB
legal_status_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'LEGAL_STATUS');
legal_status_id_code_df = legal_status_df.select(col('LEGAL_STATUS_ID'), col('LEGAL_STATUS_CODE'), col('SOURCE_SYSTEM_ID'));
    
# Load operating region data from SQL DB
operating_region_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'OPERATING_REGION');
operating_region_id_code_df = operating_region_df.select(col('OPERATING_REGION_ID'), col('OPERATING_REGION_CD'), col('SOURCE_SYSTEM_ID'));
    
# Load party type data from SQL DB
party_type_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'PARTY_TYPE');
party_type_id_code_df = party_type_df.select(col('PARTY_TYPE_ID'), col('PARTY_TYPE_CODE'), col('SOURCE_SYSTEM_ID'));

# Load entity type data from SQL DB
entity_type_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'ENTITY_TYPE');
entity_type_id_code_df = entity_type_df.select(col('ENTITY_TYPE_ID'), col('ENTITY_TYPE_CODE'), col('SOURCE_SYSTEM_ID'));

# Load party status value data from SQL DB
party_status_value_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'PARTY_STATUS_VALUE');
party_status_value_id_code_df = party_status_value_df.select(col('PARTY_STATUS_VALUE_ID'), col('PARTY_STATUS_VALUE_CODE'), col('SOURCE_SYSTEM_ID'));

# Load country data from SQL DB
country_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'COUNTRY');
country_id_code_df = country_df.select(col('COUNTRY_ID'), col('COUNTRY_ISO2_CODE'), col('COUNTRY_ISO3_CODE'), col('COUNTRY_NAME'), col('SOURCE_SYSTEM_ID'))

# Load region state data from SQL DB
region_state_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'REGION_STATE');
region_state_id_code_df = region_state_df.select(col('REGION_STATE_ID') , col('REGION_STATE_CODE'), col('SOURCE_SYSTEM_ID'))

# Load identification type data from SQL DB
identification_type_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'IDENTIFICATION_TYPE');
identification_type_id_code_df = identification_type_df.select(col('IDENTIFICATION_TYPE_ID') , col('IDENTIFICATION_TYPE_CODE'), col('SOURCE_SYSTEM_ID'))

# Load address type data from SQL DB
address_type_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'ADDRESS_TYPE');
address_type_id_code_df = address_type_df.select(col('ADDRESS_TYPE_ID') , col('ADDRESS_TYPE_CODE'), col('SOURCE_SYSTEM_ID'))

# Load kyc status value data from SQL DB
kyc_status_value_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'KYC_STATUS_VALUE');
kyc_status_value_id_code_df = kyc_status_value_df.select(col('KYC_STATUS_VALUE_ID') , col('KYC_STATUS_VALUE_CODE'), col('SOURCE_SYSTEM_ID'))

# Load kyc level of dd data from SQL DB
kyc_level_of_dd_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'KYC_LEVEL_OF_DD');
kyc_level_of_dd_id_code_df = kyc_level_of_dd_df.select(col('KYC_LEVEL_OF_DD_ID') , col('KYC_LEVEL_OF_DD_CD'), col('SOURCE_SYSTEM_ID'))

# COMMAND ----------

# DBTITLE 1,Load Dataframes for Scope Ref Tables
# Load business area data from SQL DB
business_area_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'BUSINESS_AREA');
business_area_id_code_df = business_area_df.select(col('BUSINESS_AREA_ID'), col('BUSINESS_AREA_CODE'), col('SOURCE_SYSTEM_ID'));

# Load commodity data from SQL DB
commodity_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'COMMODITY');
commodity_id_code_df = commodity_df.select(col('COMMODITY_ID'), col('COMMODITY_CODE'), col('SOURCE_SYSTEM_ID'));

# Load counterparty role data from SQL DB
counterparty_role_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'COUNTERPARTY_ROLE');
counterparty_role_id_code_df = counterparty_role_df.select(col('COUNTERPARTY_ROLE_ID'), col('COUNTERPARTY_ROLE_CODE'), col('SOURCE_SYSTEM_ID'));

# Load end system class data from SQL DB
end_system_class_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'END_SYSTEM_CLASS');
end_system_class_id_code_df = end_system_class_df.select(col('END_SYSTEM_CLASS_ID'), col('END_SYSTEM_CLASS_CODE'), col('SOURCE_SYSTEM_ID'));

# Load service type data from SQL DB
service_type_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'SERVICE_TYPE');
service_type_id_code_df = service_type_df.select(col('SERVICE_TYPE_ID'), col('SERVICE_TYPE_CODE'), col('SOURCE_SYSTEM_ID'));

# Load shell company data from SQL DB
shell_company_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'SHELL_COMPANY');
shell_company_id_code_df = shell_company_df.select(col('SHELL_COMPANY_ID'), col('SHELL_COMPANY_CODE'), col('SOURCE_SYSTEM_ID'));

# Load trading desk data from SQL DB
trading_desk_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'TRADING_DESK');
trading_desk_id_code_df = trading_desk_df.select(col('TRADING_DESK_ID'), col('TRADING_DESK_CODE'), col('SOURCE_SYSTEM_ID'));

# Load review status data from SQL DB
review_status_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'REVIEW_STATUS');

bank_verify_status_id_code_df = review_status_df.select(col('REVIEW_STATUS_ID').alias('BANK_VERIFY_STATUS_ID')
                                                       , col('REVIEW_STATUS_CODE').alias('BANK_VERIFY_STATUS_CODE')
                                                       , col('SOURCE_SYSTEM_ID'));

credit_assess_status_id_code_df = review_status_df.select(col('REVIEW_STATUS_ID').alias('CREDIT_ASSESS_STATUS_ID')
                                                       , col('REVIEW_STATUS_CODE').alias('CREDIT_STATUS_CODE')
                                                       , col('SOURCE_SYSTEM_ID'));

display(bank_verify_status_id_code_df)

# COMMAND ----------

# DBTITLE 1,Select required columns from PARTY_XREF
if mdm_counterparty_xref_df is not None:
  
    mdm_counterparty_xref_subset_df = mdm_counterparty_xref_df.filter("IS_RECORD_ACTIVE=1").select(col('NATURE_OF_BUSINESS').alias('BUSINESS_NATURE')
                               , col('GOVT_INTERMEDIARY_IND').alias('GOVERNMENT_INTERMEDIARY_IND')
                               , col('IS_REGISTERED').alias('IS_REGISTERED_IND')
                               , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYS_PARTY_KEY')
                               , col('SPECIAL_OWNERSHIP_IND').alias('SPECIAL_OWNERSHIP_IND')
                               , col('SUBCONTRACTOR_ID').alias('SUBCONTRACTOR_IND')
                               , col('TAX_WAIVER_SIGNOFF_INDICATOR').alias('TAX_WAIVER_IND')
                               , col('US_GOVT_IND').alias('US_GOVERNMENT_IND')
                               , col('COMPANY_TYPE_CODE')
                               , col('ENTITY_TYPE_CODE')
                               , col('LEGAL_CLASSIFICATION').alias('LEGAL_CLASSIFICATION_CODE')
                               , lit('').alias('LEGAL_STATUS_CODE')
                               #, col('LEGAL_STATUS_CODE')
                               , col('OPERATING_REGION_CD')
                               , col('PARTY_TYPE_CODE')
                               , col('SOURCE_SYSTEM_CODE')
                          )
    
    display(mdm_counterparty_xref_subset_df)
    #display(mdm_counterparty_xref_df)

# COMMAND ----------

# DBTITLE 1,Select required columns from PARTY
if mdm_party_df is not None:
  
  mdm_party_subset_df = mdm_party_df.filter("IS_RECORD_ACTIVE=1").select(col('NATURE_OF_BUSINESS').alias('BUSINESS_NATURE')
                               , col('GOVERNMENT_INTERMEDIARY_INDICATOR').alias('GOVERNMENT_INTERMEDIARY_IND')
                               , col('IS_REGISTERED_INDICATOR').alias('IS_REGISTERED_IND')
                               , col('MDM_ID').alias('SOURCE_SYS_PARTY_KEY')
                               , col('SPECIAL_OWNERSHIP_INDICATOR').alias('SPECIAL_OWNERSHIP_IND')
                               , col('SUBCONTRACTOR_INDICATOR').alias('SUBCONTRACTOR_IND')
                               , col('TAX_WAIVER_INDICATOR').alias('TAX_WAIVER_IND')
                               , col('US_GOVERNMENT_INDICATOR').alias('US_GOVERNMENT_IND')
                               , col('COMPANY_TYPE_CODE')
                               , col('ENTITY_TYPE_CODE')
                               , col('LEGAL_CLASSIFICATION_CODE')
                               , col('LEGAL_STATUS_CODE')
                               , col('OPERATING_REGION_CODE').alias('OPERATING_REGION_CD')
                               , col('PARTY_TYPE_CODE')
                               , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                           )
  
  display(mdm_party_subset_df)

# COMMAND ----------

# DBTITLE 1,Union PARTY and PARTY_XREF
mdm_party_subset_df = mdm_party_subset_df[mdm_counterparty_xref_subset_df.columns]

party_union_df = mdm_party_subset_df.union(mdm_counterparty_xref_subset_df).dropDuplicates(['SOURCE_SYS_PARTY_KEY'])


# COMMAND ----------

print(mdm_counterparty_xref_subset_df.count())
print(mdm_party_subset_df.count())
print(party_union_df.count())
print(party_union_df.filter("SOURCE_SYSTEM_CODE='MDM'").count())
print(party_union_df.filter("SOURCE_SYSTEM_CODE='ENCR'").count())

# COMMAND ----------

# DBTITLE 1,Party
party_union_df = party_union_df.join(source_system_id_code_df, ['SOURCE_SYSTEM_CODE'], 'left')

party_union_df = party_union_df.join(company_type_id_code_df, ['COMPANY_TYPE_CODE', 'SOURCE_SYSTEM_ID'], 'left') \
                                .join(legal_classification_id_code_df, ['LEGAL_CLASSIFICATION_CODE', 'SOURCE_SYSTEM_ID'], 'left') \
                                .join(legal_status_id_code_df, ['LEGAL_STATUS_CODE', 'SOURCE_SYSTEM_ID'], 'left') \
                                .join(operating_region_id_code_df, ['OPERATING_REGION_CD', 'SOURCE_SYSTEM_ID'], 'left') \
                                .join(party_type_id_code_df, ['PARTY_TYPE_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                .join(entity_type_id_code_df, ['ENTITY_TYPE_CODE', 'SOURCE_SYSTEM_ID'], 'left')

# drop unnecessary columns
columns_to_drop = ['SOURCE_SYSTEM_CODE', 'COMPANY_TYPE_CODE', 'LEGAL_CLASSIFICATION_CODE', 'LEGAL_STATUS_CODE', 'OPERATING_REGION_CD', 'PARTY_TYPE_CODE', 'ENTITY_TYPE_CODE']
party_union_df = party_union_df.drop(*columns_to_drop) #.na.drop(subset=['SOURCE_SYS_PARTY_KEY'])

if party_union_df is not None and party_union_df.count() > 0:
  
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY', 'PARTY', party_union_df)
    merge_columns = 'SOURCE_SYS_PARTY_KEY'
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY', 'PARTY', party_union_df, merge_columns)

    display(party_union_df)

# COMMAND ----------

golden_record_id_update_query = """UPDATE p3
SET P3.MDM_GOLDEN_RECORD_ID = COMPUTED_PARENT_ID.PARENT_PARTY_ID
FROM ENT_LEGAL_ENTITY.PARTY P3
INNER JOIN (
	SELECT 
		party_id_mdmid.SOURCE_PARTY_PRIMARY_KEY
		, party_id_mdmid.MDM_ID
		, party_id_mdmid.PARTY_ID
		, P2.PARTY_ID AS PARENT_PARTY_ID
	FROM (
		SELECT 
			P.SOURCE_SYS_PARTY_KEY
			, P.PARTY_ID
			, PX.SOURCE_PARTY_PRIMARY_KEY
			, PX.MDM_ID 
		FROM ENT_LEGAL_ENTITY.PARTY P
		INNER JOIN [ENT_LEGAL_ENTITY_REF_DATA].[PARTY_XREF] PX ON P.SOURCE_SYS_PARTY_KEY = PX.SOURCE_PARTY_PRIMARY_KEY
	) party_id_mdmid
	INNER JOIN ENT_LEGAL_ENTITY.PARTY P2 ON P2.SOURCE_SYS_PARTY_KEY = party_id_mdmid.MDM_ID
) COMPUTED_PARENT_ID ON P3.PARTY_ID = computed_parent_id.PARTY_ID"""

conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                           'SERVER='+dbServer+';'
                           'DATABASE='+dbDatabase+';UID='+dbUser+';'
                           'PWD='+dbPass
                       )
cursor = conn.cursor()
 
conn.autocommit = True
cursor.execute(golden_record_id_update_query)
print("Golden record ID has been updated")

# COMMAND ----------

# DBTITLE 1,Load data from relevant SQL DB tables
party_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY', 'PARTY');
party_name_type_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'PARTY_NAME_TYPE');
country_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'COUNTRY');
region_state_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'REGION_STATE');
identification_type_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'IDENTIFICATION_TYPE');
address_type_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'ADDRESS_TYPE');
kyc_status_value_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'KYC_STATUS_VALUE');
kyc_level_of_dd_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'KYC_LEVEL_OF_DD');

party_subset_df = None;
if party_df is not None:
    party_subset_df = party_df.select(col('PARTY_ID') , col('SOURCE_SYS_PARTY_KEY'))

party_name_type_subset_df = None;                                                                                                  
if party_name_type_df is not None:
    party_name_type_subset_df = party_name_type_df.select(col('PARTY_NAME_TYPE_ID'), col('PARTY_NAME_TYPE_CODE'))

country_subset_df = None;
if country_df is not None:
    country_subset_df = country_df.select(col('COUNTRY_ID'), col('COUNTRY_ISO2_CODE'), col('COUNTRY_ISO3_CODE'), col('COUNTRY_NAME'))
    
region_state_subset_df = None;
if region_state_df is not None:
    region_state_subset_df = region_state_df.select(col('REGION_STATE_ID') , col('REGION_STATE_NAME'))
    
identification_type_subset_df = None;
if identification_type_df is not None:
    identification_type_subset_df = identification_type_df.select(col('IDENTIFICATION_TYPE_ID') , col('IDENTIFICATION_TYPE_CODE'))
    
address_type_subset_df = None;
if address_type_df is not None:
    address_type_subset_df = address_type_df.select(col('ADDRESS_TYPE_ID') , col('ADDRESS_TYPE_CODE'))
    
kyc_status_value_subset_df = None;
if kyc_status_value_df is not None:
    kyc_status_value_subset_df = kyc_status_value_df.select(col('KYC_STATUS_VALUE_ID') , col('KYC_STATUS_VALUE_CODE'))
    
kyc_level_of_dd_subset_df = None;
if kyc_level_of_dd_df is not None:
    kyc_level_of_dd_subset_df = kyc_level_of_dd_df.select(col('KYC_LEVEL_OF_DD_ID') , col('KYC_LEVEL_OF_DD_CD'))

# COMMAND ----------

# DBTITLE 1,Party_Name
mdm_counterparty_xref_party_name_df = None;
if mdm_counterparty_xref_df is not None:  
    # Extract legal name from party_xref file
    mdm_counterparty_xref_party_name_df = mdm_counterparty_xref_df.select(col('LEGAL_NAME').alias('PARTY_NAME')
                                                                          , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYS_PARTY_KEY')
                                                                          , lit('Legal').alias('PARTY_NAME_TYPE_CODE') 
                                                                         );
    
mdm_party_party_name_df = None;
if mdm_party_df is not None:
    # Extract legal name from party file
    mdm_party_party_name_df = mdm_party_df.select(col('LEGAL_NAME').alias('PARTY_NAME')
                                                  , col('MDM_ID').alias('SOURCE_SYS_PARTY_KEY')
                                                  , lit('Legal').alias('PARTY_NAME_TYPE_CODE')
                                                 )
    # Extract party name from party file
    mdm_party_party_name2_df = mdm_party_df.select(col('PARTY_NAME')
                                                  , col('MDM_ID').alias('SOURCE_SYS_PARTY_KEY')
                                                  , col('PARTY_NAME_TYPE_CODE')
                                                 )

# Union all 3 dataframes
party_name_df = mdm_counterparty_xref_party_name_df.union(mdm_party_party_name_df) \
                                                   .union(mdm_party_party_name2_df).distinct()

# Join PARTY to get PARTY_ID and PARTY_NAME_TYPE table to get PARTY_NAME_TYPE_ID
party_name_df = party_name_df.join(party_subset_df, ['SOURCE_SYS_PARTY_KEY'], 'left')\
                              .join(party_name_type_subset_df, ['PARTY_NAME_TYPE_CODE'], 'left').distinct()

# drop unnecessary columns
columns_to_drop = ['PARTY_NAME_TYPE_CODE', 'SOURCE_SYS_PARTY_KEY']
party_name_df = party_name_df.drop(*columns_to_drop).na.drop(subset=['PARTY_NAME_TYPE_ID'])
#party_name_df2 = party_name_df.na.drop(subset=["PARTY_NAME_TYPE_ID", "PARTY_ID"])

if party_name_df is not None and party_name_df.count() > 0:
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY', 'PARTY_NAME', party_name_df)
    merge_columns = 'PARTY_ID,PARTY_NAME_TYPE_ID'
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY', 'PARTY_NAME', party_name_df, merge_columns)
    
    #display(party_name_df2.filter("PARTY_NAME_TYPE_ID IS NOT NULL"))
    display(party_name_df)
#display(party_name_df)

# COMMAND ----------

# DBTITLE 1,Party_Identification
mdm_counterparty_xref_party_name_df = None;
if mdm_counterparty_xref_df is not None:  
    # Extract legal name from party_xref file
    mdm_counterparty_xref_party_name_df = mdm_counterparty_xref_df.select(lit(None).alias('EXPIRY_DATE')
                                                                          , col('IDENTIFICATION_VALUE').alias('IDENTIFICATION_NO')
                                                                          , lit(None).alias('ISSUE_DATE')
                                                                          , col('COUNTRY').alias('COUNTRY_NAME')
                                                                          , col('IDENTIFICATION_TYPE_CODE')
                                                                          , col('REGION_STATE').alias('REGION_STATE_CODE')
                                                                          , col('CP_IDENTIFIER_PRIMARY_KEY').substr(1,100).alias('SOURCE_SYS_PARTY_ID_KEY')
                                                                          , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYS_PARTY_KEY')
                                                                          , col('SOURCE_SYSTEM_CODE')
                                                                         ).distinct();

mdm_party_party_identification_df = None;
if mdm_party_df is not None:
    # Extract legal name from party file
    mdm_party_party_identification_df = mdm_party_df.select(col('IDENTIFICATION_EXPIRY_DATE').alias('EXPIRY_DATE')
                                                  , col('IDENTIFICATION_NUMBER').alias('IDENTIFICATION_NO')
                                                  , col('IDENTIFICATION_ISSUE_DATE').alias('ISSUE_DATE')
                                                  , col('COUNTRY_NAME')
                                                  , col('IDENTIFICATION_TYPE_CODE')
                                                  , col('REGION_STATE').alias('REGION_STATE_CODE')
                                                  , lit(None).alias('SOURCE_SYS_PARTY_ID_KEY')
                                                  , col('MDM_ID').alias('SOURCE_SYS_PARTY_KEY')
                                                  , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                                 ).distinct()
    
    mdm_party_party_identification2_df = mdm_party_df.select(lit(None).alias('EXPIRY_DATE')
                                                     , col('GLOBAL_PARTY_ID').alias('IDENTIFICATION_NO')
                                                     , lit(None).alias('ISSUE_DATE')
                                                     , lit(None).alias('COUNTRY_NAME')
                                                     , lit('MDM_GLOBAL_PARTY').alias('IDENTIFICATION_TYPE_CODE')
                                                     , lit(None).alias('REGION_STATE_CODE')
                                                     , lit(None).alias('SOURCE_SYS_PARTY_ID_KEY')
                                                     , col('MDM_ID').alias('SOURCE_SYS_PARTY_KEY')
                                                     , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                                    ).distinct()

      # .filter("IDENTIFICATION_TYPE_CODE = 'MDM_GLOBAL_PARTY'") \

mdm_counterparty_xref_party_name_df = mdm_counterparty_xref_party_name_df[mdm_party_party_identification_df.columns]
mdm_party_party_identification2_df = mdm_party_party_identification2_df[mdm_party_party_identification_df.columns]

party_identification_df1 = mdm_counterparty_xref_party_name_df.union(mdm_party_party_identification_df)
party_identification_df = party_identification_df1.union(mdm_party_party_identification2_df)

# ??? Country_code is in party table

## Join PARTY to get PARTY_ID and PARTY_NAME_TYPE table to get PARTY_NAME_TYPE_ID
#party_identification_df = party_identification_df.join(country_subset_df, ['COUNTRY_NAME'], 'left')\
#                              .join(identification_type_subset_df, ['IDENTIFICATION_TYPE_CODE'], 'left')\
#                              .join(region_state_subset_df, ['REGION_STATE_NAME'], 'left')\
#                              .join(party_subset_df, ['SOURCE_SYS_PARTY_KEY'], 'left')
#
## drop unnecessary columns
#columns_to_drop = ['COUNTRY_NAME', 'IDENTIFICATION_TYPE_CODE', 'REGION_STATE_NAME', 'SOURCE_SYS_PARTY_KEY', 'COUNTRY_ISO2_CODE', 'COUNTRY_ISO3_CODE']

# Join SOURCE_SYSTEM to get SOURCE_SYSTEM_ID
party_identification_df = party_identification_df.join(source_system_id_code_df, ['SOURCE_SYSTEM_CODE'], 'left')

# Join Ref tables to get their corresponding Ids
party_identification_df = party_identification_df.join(country_id_code_df, ['COUNTRY_NAME', 'SOURCE_SYSTEM_ID'], 'left')\
                                                 .join(identification_type_id_code_df, ['IDENTIFICATION_TYPE_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                                 .join(region_state_id_code_df, ['REGION_STATE_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                                 .join(party_subset_df, ['SOURCE_SYS_PARTY_KEY'], 'left')

# drop unnecessary columns
columns_to_drop = ['COUNTRY_NAME', 'IDENTIFICATION_TYPE_CODE', 'REGION_STATE_CODE', 'SOURCE_SYS_PARTY_KEY', 'COUNTRY_ISO2_CODE', 'COUNTRY_ISO3_CODE', 'SOURCE_SYSTEM_ID', 'SOURCE_SYSTEM_CODE']

party_identification_cleaned_df = party_identification_df.dropDuplicates(['IDENTIFICATION_TYPE_ID', 'PARTY_ID'])\
                                                  .drop(*columns_to_drop) #.na.drop(subset=['IDENTIFICATION_TYPE_ID', 'PARTY_ID'])

if party_identification_cleaned_df is not None and party_identification_cleaned_df.count() > 0:
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY', 'PARTY_IDENTIFICATION', party_identification_df)
    merge_columns = 'PARTY_ID,IDENTIFICATION_TYPE_ID'
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY', 'PARTY_IDENTIFICATION', party_identification_cleaned_df, merge_columns)
    
    display(party_identification_cleaned_df)
    #display(mdm_party_party_identification2_df)

#display(mdm_identification_df)

# COMMAND ----------

print(party_identification_df.filter("IDENTIFICATION_TYPE_ID IS NULL").count())

# COMMAND ----------

display(party_identification_df.filter("IDENTIFICATION_TYPE_ID IS NULL"))

# COMMAND ----------

# DBTITLE 1,Party_Address
country_iso3_xref_df = country_id_code_df.withColumnRenamed("COUNTRY_ISO3_CODE", "COUNTRY")
country_iso3_party_df = country_id_code_df.withColumnRenamed("COUNTRY_ISO3_CODE", "COUNTRY_CODE")

mdm_counterparty_xref_party_address_df = None;
if mdm_counterparty_xref_df is not None:  
    # Extract party address from counterparty_xref file
    mdm_counterparty_xref_party_address_df = mdm_counterparty_xref_df.select(col('CP_ADDR_PRIMARY_KEY').alias('SOURCE_SYS_PARTY_ADDRESS_KEY')
                                                                           , col('ADDRESS_LINE_1')
                                                                           , col('ADDRESS_LINE_2')
                                                                           , col('ADDRESS_LINE_3')
                                                                           , col('ADDRESS_LINE_4')
                                                                           , col('CITY')
                                                                           , col('REGION_STATE')
                                                                           , col('POSTAL_CD').alias('POSTAL_CODE')
                                                                           , col('ADDRESS_VERIFIED_IND')
                                                                           , col('RAW_ADDRESS_LINE_1')
                                                                           , col('RAW_ADDRESS_LINE_2')
                                                                           , col('RAW_ADDRESS_LINE_3')
                                                                           , col('RAW_ADDRESS_LINE_4')
                                                                           , col('RAW_CITY')
                                                                           , col('RAW_REGION_STATE')
                                                                           , col('RAW_POSTAL_CD').alias('RAW_POSTAL_CODE')
                                                                           , col('RAW_COUNTRY')
                                                                           , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYS_PARTY_KEY')
                                                                           , col('ADDRESS_TYPE_CD').alias('ADDRESS_TYPE_CODE')
                                                                           , col('COUNTRY')
                                                                           , col('SOURCE_SYSTEM_CODE')
                                                                            ).distinct()
    
    # Join SOURCE_SYSTEM to get SOURCE_SYSTEM_ID
    mdm_counterparty_xref_party_address_df = mdm_counterparty_xref_party_address_df.join(source_system_id_code_df, ['SOURCE_SYSTEM_CODE'], 'left')
    
    # Join Ref tables to get their corresponding Ids
    mdm_counterparty_xref_party_address_df = mdm_counterparty_xref_party_address_df.join(country_iso3_xref_df, ['COUNTRY', 'SOURCE_SYSTEM_ID'], 'left')\
                                                                                   .join(address_type_id_code_df, ['ADDRESS_TYPE_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                                                                   .join(party_subset_df, ['SOURCE_SYS_PARTY_KEY'], 'left')
    
    # drop unnecessary columns from counterparty xref
    columns_to_drop_mdm_counterparty_xref = ['SOURCE_SYS_PARTY_KEY', 'ADDRESS_TYPE_CODE', 'COUNTRY_ISO2_CODE', 'COUNTRY_NAME', 'COUNTRY', 'SOURCE_SYSTEM_ID', 'SOURCE_SYSTEM_CODE']
    mdm_counterparty_xref_party_address_df = mdm_counterparty_xref_party_address_df.drop(*columns_to_drop_mdm_counterparty_xref)
    
    #display(mdm_counterparty_xref_party_address_df)
    
mdm_party_party_address_df = None;
if mdm_party_df is not None:
    # Extract party address from party file
    mdm_party_party_address_df = mdm_party_df.select(lit(None).alias('SOURCE_SYS_PARTY_ADDRESS_KEY')
                                                   , col('ADDRESS_LINE_1')
                                                   , col('ADDRESS_LINE_2')
                                                   , col('ADDRESS_LINE_3')
                                                   , col('ADDRESS_LINE_4')
                                                   , col('CITY')
                                                   , col('REGION_STATE')
                                                   , col('POSTAL_CODE')
                                                   , col('ADDRESS_VERIFIED_INDICATOR').alias('ADDRESS_VERIFIED_IND')
                                                   , lit(None).alias('RAW_ADDRESS_LINE_1')
                                                   , lit(None).alias('RAW_ADDRESS_LINE_2')
                                                   , lit(None).alias('RAW_ADDRESS_LINE_3')
                                                   , lit(None).alias('RAW_ADDRESS_LINE_4')
                                                   , lit(None).alias('RAW_CITY')
                                                   , lit(None).alias('RAW_REGION_STATE')
                                                   , lit(None).alias('RAW_POSTAL_CODE')
                                                   , lit(None).alias('RAW_COUNTRY')
                                                   , col('MDM_ID').alias('SOURCE_SYS_PARTY_KEY')
                                                   , col('ADDRESS_TYPE_CODE')
                                                   , col('COUNTRY_CODE')
                                                   , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                                    ).distinct();
    
    # Join SOURCE_SYSTEM to get SOURCE_SYSTEM_ID
    mdm_party_party_address_df = mdm_party_party_address_df.join(source_system_id_code_df, ['SOURCE_SYSTEM_CODE'], 'left')
    
    # Join Ref tables to get their corresponding Ids
    mdm_party_party_address_df = mdm_party_party_address_df.join(country_iso3_party_df, ['COUNTRY_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                                           .join(address_type_id_code_df, ['ADDRESS_TYPE_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                                           .join(party_subset_df, ['SOURCE_SYS_PARTY_KEY'], 'left')
    
    # drop unnecessary columns from mdm party
    columns_to_drop_mdm_party = ['SOURCE_SYS_PARTY_KEY', 'ADDRESS_TYPE_CODE', 'COUNTRY_ISO2_CODE', 'COUNTRY_NAME', 'COUNTRY_CODE', 'SOURCE_SYSTEM_ID', 'SOURCE_SYSTEM_CODE']    
    mdm_party_party_address_df = mdm_party_party_address_df.drop(*columns_to_drop_mdm_party)
    
    #display(mdm_party_party_address_df)
    
# Union all dataframes
mdm_counterparty_xref_party_address_df = mdm_counterparty_xref_party_address_df[mdm_party_party_address_df.columns]
party_address_df = mdm_party_party_address_df.union(mdm_counterparty_xref_party_address_df).distinct()

party_address_df = party_address_df.dropDuplicates(['ADDRESS_TYPE_ID', 'PARTY_ID']) #.na.drop(subset=['ADDRESS_TYPE_ID', 'PARTY_ID'])

if party_address_df is not None and party_address_df.count() > 0:
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_CONTACT', 'PARTY_ADDRESS', party_address_df)
    merge_columns = 'PARTY_ID,ADDRESS_TYPE_ID'
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_CONTACT', 'PARTY_ADDRESS', party_address_df, merge_columns)
    
    display(party_address_df)

# COMMAND ----------

# DBTITLE 1,Party_KYC_Status
mdm_counterparty_xref_party_kyc_status_df = None;
if mdm_counterparty_xref_df is not None:  
    # Extract party kyc status from counterparty_xref file
    mdm_counterparty_xref_party_kyc_status_df = mdm_counterparty_xref_df.select(col('KYC_STATUS_REVIEW_DATE').alias('KYC_REVIEW_DATE')
                                                                               , col('KYC_STATUS_REVIEW_CONDITION_DESCRIPTION').alias('KYC_REVIEW_CONDITION')
                                                                               , col('KYC_STATUS_NEXT_REVIEW_DATE').alias('KYC_NEXT_REVIEW_DATE')
                                                                               , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYS_PARTY_KEY')
                                                                               , col('KYC_STATUS_VALUE').alias('KYC_STATUS_VALUE_CODE')
                                                                               , col('KYC_STATUS_LEVEL_OF_DD').alias('KYC_LEVEL_OF_DD_CD')
                                                                               , col('SOURCE_SYSTEM_CODE')
                                                                               ).distinct();
  
mdm_party_party_kyc_status_df = None;
if mdm_party_df is not None:
    # Extract party address from party file
    mdm_party_party_kyc_status_df = mdm_party_df.select(col('KYC_REVIEW_DATE')
                                                       , col('KYC_REVIEW_CONDITION')
                                                       , col('KYC_NEXT_REVIEW_DATE')
                                                       , col('MDM_ID').alias('SOURCE_SYS_PARTY_KEY')
                                                       , col('KYC_STATUS_VALUE_CODE')
                                                       , col('KYC_LEVEL_OF_DD_CODE').alias('KYC_LEVEL_OF_DD_CD')
                                                       , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                                       ).distinct();
    
#Union all datasets
mdm_party_party_kyc_status_df = mdm_party_party_kyc_status_df[mdm_counterparty_xref_party_kyc_status_df.columns]
party_kyc_status_df = mdm_party_party_kyc_status_df.union(mdm_counterparty_xref_party_kyc_status_df)

## Join PARTY to get PARTY_ID, KYC_STATUS_VALUE to get KYC_STATUS_VALUE_ID, KYC_LEVEL_OF_DD to get KYC_LEVEL_OF_DD_ID
#party_kyc_status_df = party_kyc_status_df.join(kyc_level_of_dd_subset_df, ['KYC_LEVEL_OF_DD_CD'], 'left')\
#                                         .join(kyc_status_value_subset_df, ['KYC_STATUS_VALUE_CODE'], 'left')\
#                                         .join(party_subset_df, ['SOURCE_SYS_PARTY_KEY'], 'left')
#
## drop unnecessary columns
#columns_to_drop = ['KYC_LEVEL_OF_DD_CD', 'KYC_STATUS_VALUE_CODE', 'SOURCE_SYS_PARTY_KEY']

# Join SOURCE_SYSTEM to get SOURCE_SYSTEM_ID
party_kyc_status_df = party_kyc_status_df.join(source_system_id_code_df, ['SOURCE_SYSTEM_CODE'], 'left')

# Join PARTY to get PARTY_ID, KYC_STATUS_VALUE to get KYC_STATUS_VALUE_ID, KYC_LEVEL_OF_DD to get KYC_LEVEL_OF_DD_ID
party_kyc_status_df = party_kyc_status_df.join(kyc_level_of_dd_id_code_df, ['KYC_LEVEL_OF_DD_CD', 'SOURCE_SYSTEM_ID'], 'left')\
                                         .join(kyc_status_value_id_code_df, ['KYC_STATUS_VALUE_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                         .join(party_subset_df, ['SOURCE_SYS_PARTY_KEY'], 'left')

# drop unnecessary columns
columns_to_drop = ['KYC_LEVEL_OF_DD_CD', 'KYC_STATUS_VALUE_CODE', 'SOURCE_SYS_PARTY_KEY', 'SOURCE_SYSTEM_ID', 'SOURCE_SYSTEM_CODE']
party_kyc_status_df = party_kyc_status_df.drop(*columns_to_drop).dropDuplicates(['PARTY_ID', 'KYC_STATUS_VALUE_ID'])\
                                                                .na.drop(subset=['PARTY_ID', 'KYC_STATUS_VALUE_ID'])

if party_kyc_status_df is not None and party_kyc_status_df.count() > 0:
  
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY', 'PARTY_KYC_STATUS', party_kyc_status_df)
    merge_columns = 'PARTY_ID,KYC_STATUS_VALUE_ID'
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY', 'PARTY_KYC_STATUS', party_kyc_status_df, merge_columns)
    
    #display(mdm_counterparty_xref_df.filter("KYC_STATUS_VALUE IS NOT NULL OR KYC_STATUS_LEVEL_OF_DD IS NOT NULL"))
    display(party_kyc_status_df)

# COMMAND ----------

# DBTITLE 1,Party_Status
mdm_party_party_status_df = None;
if mdm_party_df is not None:
    # Extract party address from party file
    mdm_party_party_status_df = mdm_party_df.select(col("PARTY_STATUS_EFFECTIVE_DATE").alias("EFFECTIVE_DATE")
                                                    , lit("2999-12-31").alias("END_DATE")
                                                    , col("PARTY_STATUS_VALUE_CODE")
                                                    , col('MDM_ID').alias('SOURCE_SYS_PARTY_KEY')
                                                    , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                                 ).distinct();
    
    mdm_party_party_status_active_df = mdm_party_df.select(col("PARTY_STATUS_EFFECTIVE_DATE").alias("EFFECTIVE_DATE")
                                                    , lit("2999-12-31").alias("END_DATE")
                                                    , col("ACTIVE_STATUS_CODE").alias('PARTY_STATUS_VALUE_CODE')
                                                    , col('MDM_ID').alias('SOURCE_SYS_PARTY_KEY')
                                                    , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                                 ).distinct();
    
mdm_counterparty_xref_party_status_df = None;
if mdm_counterparty_xref_df is not None:  
    # Extract party kyc status from counterparty_xref file
    #mdm_counterparty_xref_party_status_df = mdm_counterparty_xref_df.select(lit(None).alias("EFFECTIVE_DATE")
    #                                                                        , lit(None).alias("END_DATE")
    #                                                                        , col("PARTY_STATUS_VALUE_CD").alias("PARTY_STATUS_VALUE_CODE")
    #                                                                        , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYS_PARTY_KEY')
    #                                                                     ).distinct();
    #
    mdm_counterparty_xref_party_status_df = mdm_counterparty_xref_df.withColumn("PARTY_STATUS_VALUE_CODE", f.split('PARTY_STATUS_VALUE_CD', '[|]')[1]) \
                                                                    .select(lit(None).alias("EFFECTIVE_DATE")
                                                                            , lit(None).alias("END_DATE")
                                                                            , col("PARTY_STATUS_VALUE_CODE")
                                                                            , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYS_PARTY_KEY')
                                                                            , col('SOURCE_SYSTEM_CODE')
                                                                         ).distinct();
    
    mdm_counterparty_xref_party_status_active_df = mdm_counterparty_xref_df.withColumn("PARTY_STATUS_VALUE_CODE", f.split('PARTY_STATUS_VALUE_CD', '[|]')[1]) \
                                                                    .select(lit(None).alias("EFFECTIVE_DATE")
                                                                            , lit(None).alias("END_DATE")
                                                                            , col("ACTIVE_STATUS_CODE").alias('PARTY_STATUS_VALUE_CODE')
                                                                            , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYS_PARTY_KEY')
                                                                            , col('SOURCE_SYSTEM_CODE')
                                                                         ).distinct();
    
# Re-order columns
mdm_party_party_status_df = mdm_party_party_status_df[mdm_counterparty_xref_party_status_df.columns]
mdm_party_party_status_active_df = mdm_party_party_status_active_df[mdm_counterparty_xref_party_status_df.columns]
mdm_counterparty_xref_party_status_active_df = mdm_counterparty_xref_party_status_active_df[mdm_counterparty_xref_party_status_df.columns]

# Union all datasets
party_status_df = mdm_party_party_status_df.union(mdm_party_party_status_active_df).union(mdm_counterparty_xref_party_status_df).union(mdm_counterparty_xref_party_status_active_df).distinct()

#party_status_df = party_status_union_df.join(party_status_value_id_code_df, ["PARTY_STATUS_VALUE_CODE"], 'left') \
#                                             .join(party_subset_df, ['SOURCE_SYS_PARTY_KEY'], 'left')
#
#columns_to_drop = ['PARTY_STATUS_VALUE_CODE', 'SOURCE_SYS_PARTY_KEY', 'SOURCE_SYSTEM_ID']

# Join SOURCE_SYSTEM to get SOURCE_SYSTEM_ID
party_status_df = party_status_df.join(source_system_id_code_df, ['SOURCE_SYSTEM_CODE'], 'left')

# Join PARTY to get PARTY_ID, PARTY_STATUS_VALUE to get PARTY_STATUS_VALUE_ID
party_status_df = party_status_df.join(party_status_value_id_code_df, ['PARTY_STATUS_VALUE_CODE', 'SOURCE_SYSTEM_ID'], 'left') \
                                 .join(party_subset_df, ['SOURCE_SYS_PARTY_KEY'], 'left')

# drop unnecessary columns
columns_to_drop = ['PARTY_STATUS_VALUE_CODE', 'SOURCE_SYS_PARTY_KEY', 'SOURCE_SYSTEM_ID', 'SOURCE_SYSTEM_CODE']
party_status_df = party_status_df.dropDuplicates(['PARTY_STATUS_VALUE_ID', 'PARTY_ID'])\
                                                  .drop(*columns_to_drop).na.drop(subset=['PARTY_STATUS_VALUE_ID', 'PARTY_ID'])

if party_status_df is not None and party_status_df.count() > 0:
  
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY', 'PARTY_STATUS', party_status_df)
    merge_columns = 'PARTY_ID,PARTY_STATUS_VALUE_ID'
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY', 'PARTY_STATUS', party_status_df, merge_columns, scd_type='scd_2')
    
    #print(party_status_df.count())
    #print(party_status_union_df.count())
    
    display(party_status_df)

    #display(mdm_counterparty_xref_df.withColumn("PARTY_STATUS_VALUE_CODE", f.split('PARTY_STATUS_VALUE_CD', '[|]')[1]))

# COMMAND ----------

# DBTITLE 1,Counterparty_Scope
mdm_counterparty_scope_counterparty_scope_df = None;
if mdm_counterparty_scope_df is not None:  
    # Extract counterparty scope from counterparty_scope file
    mdm_counterparty_scope_counterparty_scope_df = mdm_counterparty_scope_df.select(col('COUNTERPARTY_SCOPE_ID').alias('SOURCE_SYS_CP_SCOPE_KEY')
                                                                                   , col('MDM_ID').alias('SOURCE_SYS_PARTY_KEY')
                                                                                   , col('CREDIT_STATUS_CODE')
                                                                                   , col('BANK_VERIFY_STATUS_CODE')
                                                                                   , col('BUSINESS_AREA_CODE')
                                                                                   , col('SERVICE_TYPE_CODE')
                                                                                   , col('COMMODITY_CODE')
                                                                                   , col('SHELL_COMPANY_CODE')
                                                                                   , col('COUNTERPARTY_ROLE_CODE')
                                                                                   , col('END_SYSTEM_CLASSIFICATION').alias('END_SYSTEM_CLASS_CODE')
                                                                                   , col('TRADING_DESK_CODE')
                                                                                   , col('OTC_INDICATOR').substr(1, 1).alias('OTC_IND')
                                                                                   , col('COUNTERPARTY_SHORT_NAME')
                                                                                   , col('COUNTERPARTY_LONG_NAME')
                                                                                   , col('SCOPE_ACTIVE_INDICATOR').substr(1, 1).alias('SCOPE_ACTIVE_IND')
                                                                                   , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                                                                   ).distinct();
    
    # Join SOURCE_SYSTEM to get SOURCE_SYSTEM_ID
    golden_scope_df = mdm_counterparty_scope_counterparty_scope_df.join(source_system_id_code_df, ['SOURCE_SYSTEM_CODE'], 'left')
    
    # Join Scope Ref tables to get their corresponding Ids
    golden_scope_df = golden_scope_df.join(business_area_id_code_df, ['BUSINESS_AREA_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                     .join(commodity_id_code_df, ['COMMODITY_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                     .join(counterparty_role_id_code_df, ['COUNTERPARTY_ROLE_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                     .join(end_system_class_id_code_df, ['END_SYSTEM_CLASS_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                     .join(service_type_id_code_df, ['SERVICE_TYPE_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                     .join(shell_company_id_code_df, ['SHELL_COMPANY_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                     .join(trading_desk_id_code_df, ['TRADING_DESK_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                     .join(credit_assess_status_id_code_df, ['CREDIT_STATUS_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
									 .join(bank_verify_status_id_code_df, ['BANK_VERIFY_STATUS_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                     .join(party_subset_df, ['SOURCE_SYS_PARTY_KEY'], 'left')
    
    # drop unnecessary columns
    columns_to_drop_golden_scope_df = ['SOURCE_SYS_PARTY_KEY', 'CREDIT_STATUS_CODE', 'SOURCE_SYSTEM_ID', 'BANK_VERIFY_STATUS_CODE', 'TRADING_DESK_CODE', 'SHELL_COMPANY_CODE', 'SERVICE_TYPE_CODE', 'END_SYSTEM_CLASS_CODE', 'COUNTERPARTY_ROLE_CODE', 'COMMODITY_CODE', 'BUSINESS_AREA_CODE', 'SOURCE_SYSTEM_CODE']
    golden_scope_df = golden_scope_df.drop(*columns_to_drop_golden_scope_df)
    
    #display(golden_scope_df)
    
mdm_counterparty_scope_xref_counterparty_scope_df = None;
if mdm_counterparty_scope_xref_df is not None:  
    # Extract counterparty scope from counterparty_scope_xref file
    mdm_counterparty_scope_xref_counterparty_scope_df = mdm_counterparty_scope_xref_df.select(col('CPS_PRIMARY_KEY').alias('SOURCE_SYS_CP_SCOPE_KEY')
                                                                                             , col('SOURCE_PARTY_PRIMARY_KEY').alias('SOURCE_SYS_PARTY_KEY')
                                                                                             , lit(None).alias('CREDIT_ASSESS_STATUS_ID')
                                                                                             , lit(None).alias('BANK_VERIFY_STATUS_ID')
                                                                                             , col('BUSINESS_AREA_CD').alias('BUSINESS_AREA_CODE')
                                                                                             , col('SERVICE_TYPE_CD').alias('SERVICE_TYPE_CODE')
                                                                                             , col('COMMODITY_CD').alias('COMMODITY_CODE')
                                                                                             , col('SHELL_COMPANY_CD').alias('SHELL_COMPANY_CODE')
                                                                                             , col('COUNTERPARTY_ROLE_CD').alias('COUNTERPARTY_ROLE_CODE')
                                                                                             , lit(None).alias('END_SYSTEM_CLASS_ID')
                                                                                             , col('TRADING_DESK_CD').alias('TRADING_DESK_CODE')
                                                                                             , lit(None).alias('OTC_IND')
                                                                                             , col('COUNTERPARTY_SHORT_NAME')
                                                                                             , col('COUNTERPARTY_LONG_NAME')
                                                                                             , col('SCOPE_ACTIVE_INDICATOR').substr(1, 1).alias('SCOPE_ACTIVE_IND')
                                                                                             , col('SOURCE_SYSTEM_CODE')
                                                                                             ).distinct();
    
    # Join SOURCE_SYSTEM to get SOURCE_SYSTEM_ID
    contributor_scope_df = mdm_counterparty_scope_xref_counterparty_scope_df.join(source_system_id_code_df, ['SOURCE_SYSTEM_CODE'], 'left')
    
    # Join Scope Ref tables to get their corresponding Ids
    contributor_scope_df = contributor_scope_df.join(business_area_id_code_df, ['BUSINESS_AREA_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                               .join(commodity_id_code_df, ['COMMODITY_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                               .join(counterparty_role_id_code_df, ['COUNTERPARTY_ROLE_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                               .join(service_type_id_code_df, ['SERVICE_TYPE_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                               .join(shell_company_id_code_df, ['SHELL_COMPANY_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                               .join(trading_desk_id_code_df, ['TRADING_DESK_CODE', 'SOURCE_SYSTEM_ID'], 'left')\
                                               .join(party_subset_df, ['SOURCE_SYS_PARTY_KEY'], 'left')
    
    # drop unnecessary columns
    columns_to_drop_contributor_scope_df = ['SOURCE_SYS_PARTY_KEY', 'SOURCE_SYSTEM_ID', 'TRADING_DESK_CODE', 'SHELL_COMPANY_CODE', 'SERVICE_TYPE_CODE', 'COUNTERPARTY_ROLE_CODE', 'COMMODITY_CODE', 'BUSINESS_AREA_CODE', 'SOURCE_SYSTEM_CODE']
    contributor_scope_df = contributor_scope_df.drop(*columns_to_drop_contributor_scope_df)
    
    #display(contributor_scope_df)
    
# Union all dataframes
contributor_scope_df = contributor_scope_df[golden_scope_df.columns]
counterparty_scope_df = golden_scope_df.union(contributor_scope_df).distinct()

counterparty_scope_df = counterparty_scope_df.dropDuplicates(['SOURCE_SYS_CP_SCOPE_KEY'])\
                                             #.dropDuplicates(['PARTY_ID', 'BUSINESS_AREA_ID', 'COMMODITY_ID', 'COUNTERPARTY_ROLE_ID', 'SERVICE_TYPE_ID'])
                                             #.na.drop(subset=['PARTY_ID'])

if counterparty_scope_df is not None and counterparty_scope_df.count() > 0:
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY', 'COUNTERPARTY_SCOPE', counterparty_scope_df)
    merge_columns = 'PARTY_ID,SOURCE_SYS_CP_SCOPE_KEY,BUSINESS_AREA_ID,COMMODITY_ID,COUNTERPARTY_ROLE_ID,SERVICE_TYPE_ID'
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY', 'COUNTERPARTY_SCOPE', counterparty_scope_df, merge_columns)
    
    display(counterparty_scope_df)

# COMMAND ----------

display(counterparty_scope_df.filter("COUNTERPARTY_SHORT_NAME = 'HONEYWELL_UTAH_PT'"))

# COMMAND ----------

print(counterparty_scope_df.count())

# COMMAND ----------

display(mdm_counterparty_scope_df)#.filter("COUNTERPARTY_SHORT_NAME in ('HONEYWELL_UTAH_PT', 'HONEYWELL', 'HONEYWELL_FREEPORT1_PT', 'HONEYWELL_FREEPORT4_PT', 'HONEYWELL_GLENDALE_PT', 'HONEYWELL_HW INTL_PT', 'HONEYWELL_STCHARLES_PT') and meta_created_dttm like '2021-03-08 11:30:08.629%'").select('mdm_id', 'counterparty_short_name', 'commodity_code', 'service_type_code', 'counterparty_role_code', 'business_area_code', 'meta_created_dttm').distinct())

# COMMAND ----------

display(mdm_counterparty_scope_xref_df.filter("COUNTERPARTY_SHORT_NAME = 'HONEYWELL_UTAH_PT'"))

# COMMAND ----------

if new_watermark_value_mdm_party is not None and len(str(new_watermark_value_mdm_party)) > 0:  
    UpsertWatermarkValue(usecase_code, dataset_mdm_party, new_watermark_value_mdm_party, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)
    
if new_watermark_value_mdm_counterparty_xref is not None and len(str(new_watermark_value_mdm_counterparty_xref)) > 0:  
    UpsertWatermarkValue(usecase_code, dataset_mdm_counterparty_xref, new_watermark_value_mdm_counterparty_xref, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)
        
if new_watermark_value_mdm_counterparty_scope_xref is not None and len(str(new_watermark_value_mdm_counterparty_scope_xref)) > 0:  
    UpsertWatermarkValue(usecase_code, dataset_mdm_counterparty_scope_xref, new_watermark_value_mdm_counterparty_scope_xref, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)
    
if new_watermark_value_counterparty_scope is not None and len(str(new_watermark_value_counterparty_scope)) > 0:  
    UpsertWatermarkValue(usecase_code, dataset_mdm_counterparty_scope, new_watermark_value_counterparty_scope, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)
