# Databricks notebook source
# DBTITLE 1,Load Main File
# MAGIC %run "/CGR/Shared_Scripts/Main"

# COMMAND ----------

# DBTITLE 1,Create Widgets
try:
    dbutils.widgets.text('counter_party_xref_file', '', 'Counter Party XREF File');
    dbutils.widgets.text('counter_party_xref_mapping_file', '', 'Counter Party XREF Mapping File');
    dbutils.widgets.text('counter_party_scope_xref_file', '', 'Counter Party Scope XREF File');
    dbutils.widgets.text('counter_party_scope_file', '', 'Counter Party Scope File');
    dbutils.widgets.text('mdm_party_file', '', 'MDM Party File');
    dbutils.widgets.text('reference_data_file', '', 'Reference Data File');
    dbutils.widgets.text('contributor_reference_data_file', '', 'Contributor Reference Data File');
    dbutils.widgets.text('pipeline_run_id', default_pipeline_run_id, 'Pipeline Run Id');
  
except Exception as e:
  print(str(e))
  
  dbutils.notebook.exit(json.dumps({'status': 'Failed', 'ReadCount': 0, 'WriteCount': 0, 'Message': str(e)[0:7998]}))
  raise Exception(e)


# COMMAND ----------

# DBTITLE 1,Load values from Widgets
try:
    counter_party_xref_file = dbutils.widgets.get('counter_party_xref_file');
    counter_party_xref_mapping_file = dbutils.widgets.get('counter_party_xref_mapping_file');
    counter_party_scope_xref_file = dbutils.widgets.get('counter_party_scope_xref_file');
    counter_party_scope_file = dbutils.widgets.get('counter_party_scope_file');
    mdm_party_file = dbutils.widgets.get('mdm_party_file');
    reference_data_file = dbutils.widgets.get('reference_data_file');
    contributor_reference_data_file = dbutils.widgets.get('contributor_reference_data_file');
    pipeline_run_id = dbutils.widgets.get('pipeline_run_id');
    
except Exception as e:
  print(str(e))
  
  dbutils.notebook.exit(json.dumps({'status': 'Failed', 'ReadCount': 0, 'WriteCount': 0, 'Message': databricksErrorPrefix + str(e)[0:7998]}))
  raise Exception(e)

# COMMAND ----------

# DBTITLE 1,Dataframes for MDM Outbound and Ref Data
print(last_watermark_value_mdm_party)
print(last_watermark_value_mdm_counterparty_scope)
print(last_watermark_value_mdm_counterparty_xref)
print(last_watermark_value_mdm_counterparty_scope_xref)
print(last_watermark_value_mdm_counterparty_xref_mapping)
print(last_watermark_value_standard_values)

if counter_party_xref_file is not None and len(counter_party_xref_file) > 0:
    MDM_COUNTERPARTY_XREF = spark.read.format("parquet").load(counter_party_xref_file);
    meta_created_date_counterparty_xref = " AND META_CREATED_DTTM > '" + last_watermark_value_mdm_counterparty_xref + "'" if last_watermark_value_mdm_counterparty_xref is not None else '';
    MDM_COUNTERPARTY_XREF = MDM_COUNTERPARTY_XREF.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_counterparty_xref);
    #new_watermark_value_mdm_counterparty_xref = MDM_COUNTERPARTY_XREF.select("META_CREATED_DTTM").agg({"META_CREATED_DTTM": "max"}).collect()[0][0] 

if counter_party_xref_mapping_file is not None and len(counter_party_xref_mapping_file) > 0:
    MDM_COUNTERPARTY_XREF_MAPPING = spark.read.format("parquet").load(counter_party_xref_mapping_file)
    meta_created_date_counterparty_xref_mapping = " AND META_CREATED_DTTM > '" + last_watermark_value_mdm_counterparty_xref_mapping + "'" if last_watermark_value_mdm_counterparty_xref_mapping is not None else "";
    MDM_COUNTERPARTY_XREF_MAPPING = MDM_COUNTERPARTY_XREF_MAPPING.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_counterparty_xref_mapping);
    #new_watermark_value_counterparty_xref_mapping = MDM_COUNTERPARTY_XREF_MAPPING.select("META_CREATED_DTTM").agg({"META_CREATED_DTTM": "max"}).collect()[0][0]
    
if counter_party_scope_xref_file is not None and len(counter_party_scope_xref_file) > 0:
    MDM_COUNTERPARTY_SCOPE_XREF = spark.read.format("parquet").load(counter_party_scope_xref_file)
    meta_created_date_counterparty_scope_xref = " AND META_CREATED_DTTM > '" + last_watermark_value_mdm_counterparty_scope_xref + "'" if last_watermark_value_mdm_counterparty_scope_xref is not None else "";
    MDM_COUNTERPARTY_SCOPE_XREF = MDM_COUNTERPARTY_SCOPE_XREF.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_counterparty_scope_xref);
    #new_watermark_value_mdm_counterparty_scope_xref = MDM_COUNTERPARTY_SCOPE_XREF.select("META_CREATED_DTTM").agg({"META_CREATED_DTTM": "max"}).collect()[0][0]
    
if counter_party_scope_file is not None and len(counter_party_scope_file) > 0:
    MDM_COUNTERPARTY_SCOPE = spark.read.format("parquet").load(counter_party_scope_file)
    meta_created_date_counterparty_scope = " AND META_CREATED_DTTM > '" + last_watermark_value_mdm_counterparty_scope + "'" if last_watermark_value_mdm_counterparty_scope is not None else "";
    MDM_COUNTERPARTY_SCOPE = MDM_COUNTERPARTY_SCOPE.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_counterparty_scope);
    #new_watermark_value_counterparty_scope = MDM_COUNTERPARTY_SCOPE.select("META_CREATED_DTTM").agg({"META_CREATED_DTTM": "max"}).collect()[0][0]
    
if mdm_party_file is not None and len(mdm_party_file) > 0:
    MDM_PARTY = spark.read.format("parquet").load(mdm_party_file)
    meta_created_date_mdm_party = " AND META_CREATED_DTTM > '" + last_watermark_value_mdm_party + "' " if last_watermark_value_mdm_party is not None else "";
    MDM_PARTY = MDM_PARTY.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_mdm_party);
    #new_watermark_value_mdm_party = MDM_PARTY.select("META_CREATED_DTTM").agg({"META_CREATED_DTTM": "max"}).collect()[0][0]

if reference_data_file is not None and len(reference_data_file) > 0:
    REF_DATA = spark.read.format("parquet").load(reference_data_file)
    meta_created_date_standard_values = " AND META_CREATED_DTTM > '" + last_watermark_value_standard_values + "'" if last_watermark_value_standard_values is not None else "";
    REF_DATA = REF_DATA.filter("IS_RECORD_ACTIVE=1 " + meta_created_date_standard_values);
    new_watermark_value_standard_values = REF_DATA.select("META_CREATED_DTTM").agg({"META_CREATED_DTTM": "max"}).collect()[0][0]

if contributor_reference_data_file is not None and len(contributor_reference_data_file) > 0:
    REF_DATA_CONTRIBUTOR = spark.read.format("parquet").load(contributor_reference_data_file)
    REF_DATA_CONTRIBUTOR = REF_DATA_CONTRIBUTOR.filter("IS_RECORD_ACTIVE=1")
    #new_watermark_value_reference_sheet = REF_DATA_CONTRIBUTOR.select("META_CREATED_DTTM").agg({"META_CREATED_DTTM": "max"}).collect()[0][0]
    REF_DATA_CONTRIBUTOR = REF_DATA_CONTRIBUTOR.withColumn("Source_System", upper(col('Source_System')))

# COMMAND ----------

# DBTITLE 1,Source_System
# Create default source system dataframe with hard coded value for MDM
source_system_default_df = sc.parallelize([
    ['MDM', 'MDM', 'Y']
  ]).toDF(("SOURCE_SYSTEM_CODE", "SOURCE_SYSTEM_NAME", "ACTIVE_IND"))

# Remove duplicate records
source_system_ref_df = MDM_COUNTERPARTY_XREF_MAPPING.select('SOURCE_SYSTEM_CODE').distinct();

source_system_ref_df = source_system_ref_df.select(when(col("SOURCE_SYSTEM_CODE") == 'ENERGY_CREDIT', 'ENCR').
                                                   when(col("SOURCE_SYSTEM_CODE") == 'GOLDTIER', 'GLDT').
                                                   when(col("SOURCE_SYSTEM_CODE") == 'ENDUR_GPNA', 'ENGP').
                                                   when(col("SOURCE_SYSTEM_CODE") == 'NUCLEUS', 'NCLS').
                                                   when(col("SOURCE_SYSTEM_CODE") == 'STNSAP', 'STSP').
                                                   when(col("SOURCE_SYSTEM_CODE") == 'ALIGNE', 'ALGN').
                                                   otherwise("Not in Scope").alias("SOURCE_SYSTEM_CODE")
                                                        , col("SOURCE_SYSTEM_CODE").alias("SOURCE_SYSTEM_NAME"), lit("Y").alias("ACTIVE_IND"))

#source_system_ref_df = source_system_ref_df.select(col("SOURCE_SYSTEM_CODE"), col("SOURCE_SYSTEM_CODE").alias("SOURCE_SYSTEM_NAME"), lit("Y").alias("ACTIVE_IND"))

if source_system_ref_df is not None and source_system_default_df is not None:
    
    merge_columns = 'SOURCE_SYSTEM_CODE';
    
    #source_system_merged_df = source_system_default_df.union(source_system_ref_df).dropna(subset=('SOURCE_SYSTEM_CODE'))
    #UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'SOURCE_SYSTEM', source_system_merged_df, merge_columns)
    
    source_system_default_df = source_system_default_df.na.drop(subset=['SOURCE_SYSTEM_CODE'])
    source_system_ref_df = source_system_ref_df.na.drop(subset=['SOURCE_SYSTEM_CODE'])
    
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'SOURCE_SYSTEM', source_system_default_df, merge_columns)
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'SOURCE_SYSTEM', source_system_ref_df, merge_columns)
    
    #display(source_system_merged_df)

# COMMAND ----------

# Load source system data from SQL DB
source_system_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'SOURCE_SYSTEM')
if source_system_df is not None:
    source_system_id_code_df = source_system_df.select(col('SOURCE_SYSTEM_ID'), col('SOURCE_SYSTEM_CODE'))
    source_system_id_name_df = source_system_df.select(col('SOURCE_SYSTEM_ID'), col('SOURCE_SYSTEM_NAME'))
    
display(source_system_id_name_df)

# COMMAND ----------

# DBTITLE 1,Operating_Region
#Load Operating Region Data from Standard Values
operating_region_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='OperatingRegion'")\
                                         .select(col('Target_Standard_Code').alias('OPERATING_REGION_CD')
                                               , col('Target_Standard_Value_Name').alias('OPERATING_REGION_NAME')
                                               , col('Target_Standard_Value_Description').alias('OPERATING_REGION_DESC')
                                               , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                               , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                                ).distinct()

#Load Operating Region Data from Counterparty Xref
operating_region_xref_df = MDM_COUNTERPARTY_XREF.select(col('OPERATING_REGION_CD')
                                                      , col('OPERATING_REGION_CD').alias('OPERATING_REGION_NAME')
                                                      , col('OPERATING_REGION_CD').alias('OPERATING_REGION_DESC')
                                                      , lit("Y").alias('ACTIVE_IND')
                                                      , col('SOURCE_SYSTEM_CODE')
                                                       ).distinct()

#Union all datasets
operating_region_xref_df = operating_region_xref_df[operating_region_ref_df.columns]
operating_region_df = operating_region_ref_df.union(operating_region_xref_df)

if operating_region_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    operating_region_df = operating_region_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    operating_region_df = operating_region_df.drop(*columns_to_drop).dropDuplicates(['OPERATING_REGION_CD', 'SOURCE_SYSTEM_ID'])\
                                                                    .na.drop(subset=['OPERATING_REGION_CD', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'OPERATING_REGION', operating_region_df)
    merge_columns = 'SOURCE_SYSTEM_ID,OPERATING_REGION_CD';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'OPERATING_REGION', operating_region_df, merge_columns)
    
    display(operating_region_df)

# COMMAND ----------

# DBTITLE 1,Legal_Classification
#Load Legal Classification Data from Standard Values
legal_classification_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Legal Classification'")\
                                         .select(col('Target_Standard_Code').alias('LEGAL_CLASSIFICATION_CODE')
                                               , col('Target_Standard_Value_Name').alias('LEGAL_CLASSIFICATION_NAME')
                                               , col('Target_Standard_Value_Description').alias('LEGAL_CLASSIFICATION_DESC')
                                               , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                               , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                                ).distinct()

#Load Legal Classification Data from Counterparty Xref
legal_classification_xref_df = MDM_COUNTERPARTY_XREF.select(col('LEGAL_CLASSIFICATION').alias('LEGAL_CLASSIFICATION_CODE')
                                                          , col('LEGAL_CLASSIFICATION').alias('LEGAL_CLASSIFICATION_NAME')
                                                          , col('LEGAL_CLASSIFICATION').alias('LEGAL_CLASSIFICATION_DESC')
                                                          , lit("Y").alias('ACTIVE_IND')
                                                          , col('SOURCE_SYSTEM_CODE')
                                                           ).distinct()

#Union all datasets
legal_classification_xref_df = legal_classification_xref_df[legal_classification_ref_df.columns]
legal_classification_df = legal_classification_ref_df.union(legal_classification_xref_df)

if legal_classification_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    legal_classification_df = legal_classification_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    legal_classification_df = legal_classification_df.drop(*columns_to_drop).dropDuplicates(['LEGAL_CLASSIFICATION_CODE', 'SOURCE_SYSTEM_ID'])\
                                                                            .na.drop(subset=['LEGAL_CLASSIFICATION_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'LEGAL_CLASSIFICATION', legal_classification_df)
    merge_columns = 'SOURCE_SYSTEM_ID,LEGAL_CLASSIFICATION_CODE';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'LEGAL_CLASSIFICATION', legal_classification_df, merge_columns)
    
    display(legal_classification_df)

# COMMAND ----------

# DBTITLE 1,Entity_Type
#Load Entity Type Data from Standard Values
entity_type_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Entity Type'")\
                                  .select(col('Target_Standard_Code').alias('ENTITY_TYPE_CODE')
                                        , col('Target_Standard_Value_Name').alias('ENTITY_TYPE_NAME')
                                        , col('Target_Standard_Value_Description').alias('ENTITY_TYPE_DESC')
                                        , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                        , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                         ).distinct()

#Load Entity Type Data from Counterparty Xref
entity_type_xref_df = MDM_COUNTERPARTY_XREF.select(col('ENTITY_TYPE_CODE')
                                                 , col('ENTITY_TYPE_CODE').alias('ENTITY_TYPE_NAME')
                                                 , col('ENTITY_TYPE_CODE').alias('ENTITY_TYPE_DESC')
                                                 , lit("Y").alias('ACTIVE_IND')
                                                 , col('SOURCE_SYSTEM_CODE')
                                                  ).distinct()

#Union all datasets
entity_type_xref_df = entity_type_xref_df[entity_type_ref_df.columns]
entity_type_df = entity_type_ref_df.union(entity_type_xref_df)

if entity_type_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    entity_type_df = entity_type_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    entity_type_df = entity_type_df.drop(*columns_to_drop).dropDuplicates(['ENTITY_TYPE_CODE', 'SOURCE_SYSTEM_ID']).na.drop(subset=['ENTITY_TYPE_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'ENTITY_TYPE', entity_type_df)
    merge_columns = 'SOURCE_SYSTEM_ID,ENTITY_TYPE_CODE';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'ENTITY_TYPE', entity_type_df, merge_columns)
    
    display(entity_type_df)

# COMMAND ----------

# DBTITLE 1,Party_Type
#Load Party Type Data from Standard Values
party_type_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Party Type'")\
                                   .select(col('Target_Standard_Code').alias('PARTY_TYPE_CODE')
                                         , col('Target_Standard_Value_Name').alias('PARTY_TYPE_NAME')
                                         , col('Target_Standard_Value_Description').alias('PARTY_TYPE_DESC')
                                         , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                         , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                          ).distinct()

#Load Entity Type Data from Counterparty Xref
party_type_xref_df = MDM_COUNTERPARTY_XREF.select(col('PARTY_TYPE_CODE')
                                                , col('PARTY_TYPE_CODE').alias('PARTY_TYPE_NAME')
                                                , col('PARTY_TYPE_CODE').alias('PARTY_TYPE_DESC')
                                                , lit("Y").alias('ACTIVE_IND')
                                                , col('SOURCE_SYSTEM_CODE')
                                                 ).distinct()

#Union all datasets
party_type_xref_df = party_type_xref_df[party_type_ref_df.columns]
party_type_df = party_type_ref_df.union(party_type_xref_df)

if party_type_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    party_type_df = party_type_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    party_type_df = party_type_df.drop(*columns_to_drop).dropDuplicates(['PARTY_TYPE_CODE', 'SOURCE_SYSTEM_ID']).na.drop(subset=['PARTY_TYPE_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'PARTY_TYPE', party_type_df)
    merge_columns = 'PARTY_TYPE_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'PARTY_TYPE', party_type_df, merge_columns)
    
    display(party_type_df)

# COMMAND ----------

# DBTITLE 1,Party_Name_Type
# Create default party name type dataframe with hard coded value
source_system_default_nametype_df = sc.parallelize([
    ['Legal', 'Legal', 'Legal', 'MDM', 'Y']
  ]).toDF(("PARTY_NAME_TYPE_CODE", "PARTY_NAME_TYPE_NAME", "PARTY_NAME_TYPE_DESC", "SOURCE_SYSTEM_CODE", "ACTIVE_IND"))

# Load party type data from Standard Values
party_name_type_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Name Type'")\
                                    .select(col('Target_Standard_Code').alias('PARTY_NAME_TYPE_CODE')
                                          , col('Target_Standard_Value_Name').alias('PARTY_NAME_TYPE_NAME')
                                          , col('Target_Standard_Value_Description').alias('PARTY_NAME_TYPE_DESC')
                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                           ).distinct()

# Union all datasets
party_name_type_ref_df = party_name_type_ref_df[source_system_default_nametype_df.columns]
party_name_type_df = source_system_default_nametype_df.union(party_name_type_ref_df)

if party_name_type_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    party_name_type_df = party_name_type_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')

    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    party_name_type_df = party_name_type_df.drop(*columns_to_drop).dropDuplicates(['PARTY_NAME_TYPE_CODE', 'SOURCE_SYSTEM_ID'])\
                                                                  .na.drop(subset=['PARTY_NAME_TYPE_CODE', 'SOURCE_SYSTEM_ID'])

    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'PARTY_NAME_TYPE', party_name_type_df)
    merge_columns = 'PARTY_NAME_TYPE_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'PARTY_NAME_TYPE', party_name_type_df, merge_columns)

    display(party_name_type_df)

# COMMAND ----------

# DBTITLE 1,Legal_Status
#Load Legal Status Data
#legal_status_df = MDM_PARTY.select(col('LEGAL_STATUS_CODE'), col('LEGAL_STATUS_NAME')).distinct()

legal_status_df = MDM_PARTY.select(col('LEGAL_STATUS_CODE')
                                   , col('LEGAL_STATUS_NAME')
                                   , col('LEGAL_STATUS_NAME').alias('LEGAL_STATUS_DESC')
                                   , lit("Y").alias('ACTIVE_IND')
                                   , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                  ).distinct()

if legal_status_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    legal_status_df = legal_status_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    legal_status_df = legal_status_df.drop(*columns_to_drop).dropDuplicates(['LEGAL_STATUS_CODE', 'SOURCE_SYSTEM_ID']).na.drop(subset=['LEGAL_STATUS_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'LEGAL_STATUS', legal_status_df)
    merge_columns = 'LEGAL_STATUS_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'LEGAL_STATUS', legal_status_df, merge_columns)

    display(legal_status_df)

# COMMAND ----------

# DBTITLE 1,Company_Type
#Load Company Type Data from Standard Values
company_type_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Shell Internal or Third Party'")\
                                     .select(col('Target_Standard_Code').alias('COMPANY_TYPE_CODE')
                                           , col('Target_Standard_Value_Name').alias('COMPANY_TYPE_NAME')
                                           , col('Target_Standard_Value_Description').alias('COMPANY_TYPE_DESC')
                                           , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                           , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                            ).distinct()

#Load Company Type Data from Counterparty Xref
company_type_xref_df = MDM_COUNTERPARTY_XREF.select(col('COMPANY_TYPE_CODE')
                                                  , col('COMPANY_TYPE_CODE').alias('COMPANY_TYPE_NAME')
                                                  , col('COMPANY_TYPE_CODE').alias('COMPANY_TYPE_DESC')
                                                  , lit("Y").alias('ACTIVE_IND')
                                                  , col('SOURCE_SYSTEM_CODE')
                                                   ).distinct()

#Union all datasets
company_type_xref_df = company_type_xref_df[company_type_ref_df.columns]
company_type_df = company_type_ref_df.union(company_type_xref_df)

if company_type_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    company_type_df = company_type_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    company_type_df = company_type_df.drop(*columns_to_drop).dropDuplicates(['COMPANY_TYPE_CODE', 'SOURCE_SYSTEM_ID']).na.drop(subset=['COMPANY_TYPE_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'COMPANY_TYPE', company_type_df)
    merge_columns = 'SOURCE_SYSTEM_ID,COMPANY_TYPE_CODE';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'COMPANY_TYPE', company_type_df, merge_columns)
    
    display(company_type_df)

# COMMAND ----------

# DBTITLE 1,Country
#Load Country Data from Standard Values
country_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='ISO Country Plus'")\
                                .select(col('Target_Standard_Code')
                                      , col('Target_Standard_Value_Name').alias('COUNTRY_NAME')
                                      , col('Target_Standard_Value_Description').alias('COUNTRY_DESC')
                                      , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                      , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')                                          
                                       ).distinct()

country_ref_df = country_ref_df.withColumn("COUNTRY_ISO2_CODE", when((length(col('Target_Standard_Code'))) == 2, col('Target_Standard_Code')).otherwise(lit('')))\
                               .withColumn("COUNTRY_ISO3_CODE", when((length(col('Target_Standard_Code'))) == 3, col('Target_Standard_Code')).otherwise(lit('')))

#Load Country Data from Counterparty Xref
country_xref_df = MDM_COUNTERPARTY_XREF.select(lit(None).alias('Target_Standard_Code')
                                             , lit('').alias('COUNTRY_ISO2_CODE')
                                             , col('COUNTRY').alias('COUNTRY_ISO3_CODE')
                                             , col('COUNTRY').alias('COUNTRY_NAME')
                                             , col('COUNTRY').alias('COUNTRY_DESC')
                                             , lit("Y").alias('ACTIVE_IND')
                                             , col('SOURCE_SYSTEM_CODE')
                                              ).distinct()

#Union all datasets
country_xref_df = country_xref_df[country_ref_df.columns]
country_df = country_ref_df.union(country_xref_df)
                                      
if country_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    country_df = country_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE', 'Target_Standard_Code']
    country_df = country_df.drop(*columns_to_drop).dropDuplicates(['COUNTRY_ISO3_CODE', 'SOURCE_SYSTEM_ID']).na.drop(subset=['COUNTRY_ISO3_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'COUNTRY', country_df)
    merge_columns = 'COUNTRY_ISO3_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'COUNTRY', country_df, merge_columns)
    
    display(country_df)

# COMMAND ----------

# DBTITLE 1,Identification_Type
# Create default identification type dataframe with hard coded value
source_system_default_nametype_df = sc.parallelize([
    ['MDM_GLOBAL_PARTY', 'MDM_GLOBAL_PARTY', '', 'MDM', 'Y']
  ]).toDF(("IDENTIFICATION_TYPE_CODE", "IDENTIFICATION_TYPE_NAME", "IDENTIFICATION_TYPE_DESC", "SOURCE_SYSTEM_CODE", "ACTIVE_IND"))

#Load Identification Type Data from Standard Values
identification_type_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Registration ID Type'")\
                                            .select(col('Target_Standard_Code').alias('IDENTIFICATION_TYPE_CODE')
                                                  , col('Target_Standard_Value_Name').alias('IDENTIFICATION_TYPE_NAME')
                                                  , col('Target_Standard_Value_Description').alias('IDENTIFICATION_TYPE_DESC')
                                                  , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                                  , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                                   ).distinct()

#Load Company Type Data from Counterparty Xref
identification_type_xref_df = MDM_COUNTERPARTY_XREF.select(col('IDENTIFICATION_TYPE_CODE')
                                                         , col('IDENTIFICATION_TYPE_CODE').alias('IDENTIFICATION_TYPE_NAME')
                                                         , col('IDENTIFICATION_TYPE_CODE').alias('IDENTIFICATION_TYPE_DESC')
                                                         , lit("Y").alias('ACTIVE_IND')
                                                         , col('SOURCE_SYSTEM_CODE')
                                                          ).distinct()

# Re-order columns
identification_type_xref_df = identification_type_xref_df[source_system_default_nametype_df.columns]
identification_type_ref_df = identification_type_ref_df[source_system_default_nametype_df.columns]

# Union all datasets
identification_type_df = source_system_default_nametype_df.union(identification_type_ref_df).union(identification_type_xref_df)

if identification_type_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    identification_type_df = identification_type_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    identification_type_df = identification_type_df.drop(*columns_to_drop).dropDuplicates(['IDENTIFICATION_TYPE_CODE', 'SOURCE_SYSTEM_ID'])\
                                                                          .na.drop(subset=['IDENTIFICATION_TYPE_CODE', 'SOURCE_SYSTEM_ID'])
    
    #identification_type_df = identification_type_df.withColumn('IDENTIFICATION_TYPE_DESC', when(length(trim(identification_type_df.IDENTIFICATION_TYPE_DESC)) == 0, lit(None)).otherwise(identification_type_df.IDENTIFICATION_TYPE_DESC).alias("IDENTIFICATION_TYPE_DESC"))
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'IDENTIFICATION_TYPE', identification_type_df)
    merge_columns = 'SOURCE_SYSTEM_ID,IDENTIFICATION_TYPE_CODE';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'IDENTIFICATION_TYPE', identification_type_df, merge_columns)
    
    display(identification_type_df)

# COMMAND ----------

# DBTITLE 1,Region_State
#Load Region State data
#region_state_df = REF_DATA.filter("reference_entity_name_pick_list_name='ISO State/Province/Region'")\
#                                  .select(col('Target_Standard_Code').alias('REGION_STATE_CODE')
#                                          , col('Target_Standard_Value_Name').alias('REGION_STATE_NAME')
#                                          , col('Target_Standard_Value_Description').alias('REGION_STATE_DESC')
#                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
#                                          , col('Parent_Reference_Entity_Name_Nullable')
#                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
#                                         ).distinct()

# Load Country data from SQL DB
country_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'COUNTRY');
country_df = country_df.select(col('COUNTRY_ID'), col('COUNTRY_ISO2_CODE'), col('COUNTRY_ISO3_CODE'), col('SOURCE_SYSTEM_ID'));

#country_df = country_df.withColumn('COUNTRY_ISO3_CODE', when(length(trim(country_df.COUNTRY_ISO3_CODE)) == 0, lit(None)).otherwise(country_df.COUNTRY_ISO3_CODE).alias("COUNTRY_ISO3_CODE"))

#Load Region State data from MDM Party
region_state_party_df = MDM_PARTY.select(col('REGION_STATE').alias('REGION_STATE_CODE')
                                       , col('REGION_STATE').alias('REGION_STATE_NAME')
                                       , col('REGION_STATE').alias('REGION_STATE_DESC')
                                       , lit("Y").alias('ACTIVE_IND')
                                       , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                       , col('COUNTRY_CODE').alias('COUNTRY_ISO3_CODE')
                                        ).distinct()

#Load Region State data from Counterparty Xref
region_state_xref_df = MDM_COUNTERPARTY_XREF.select(col('REGION_STATE').alias('REGION_STATE_CODE')
                                                  , col('REGION_STATE').alias('REGION_STATE_NAME')
                                                  , col('REGION_STATE').alias('REGION_STATE_DESC')
                                                  , lit("Y").alias('ACTIVE_IND')
                                                  , col('SOURCE_SYSTEM_CODE')
                                                  , col('COUNTRY').alias('COUNTRY_ISO3_CODE')
                                                   ).distinct()

# Union all datasets
region_state_xref_df = region_state_xref_df[region_state_party_df.columns]
region_state_df = region_state_party_df.union(region_state_xref_df).distinct()

#if region_state_df is not None and country_df is not None:
#    
#    # Join with Country to get country_id
#    #region_state_df = region_state_df.join(country_df, 'COUNTRY_ISO2_CODE', 'left')
#    region_state_df = region_state_df.join(country_df, region_state_df.Parent_Reference_Entity_Name_Nullable == coalesce(country_df.COUNTRY_ISO3_CODE, country_df.COUNTRY_ISO2_CODE), 'left')
#    #region_state_df = region_state_df.join(country_df, region_state_df.Parent_Reference_Entity_Name_Nullable == country_df.COUNTRY_ISO3_CODE, 'left')
    
if region_state_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    region_state_df = region_state_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # Join with country to get country id
    region_state_df = region_state_df.join(country_df, ['COUNTRY_ISO3_CODE', 'SOURCE_SYSTEM_ID'], 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE', 'COUNTRY_ISO2_CODE', 'COUNTRY_ISO3_CODE']
    region_state_df = region_state_df.drop(*columns_to_drop).dropDuplicates(['REGION_STATE_CODE', 'SOURCE_SYSTEM_ID']).na.drop(subset=['REGION_STATE_CODE', 'SOURCE_SYSTEM_ID'])
    #region_state_df = region_state_df.withColumn('COUNTRY_CD', lit(''))
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'REGION_STATE', region_state_df)
    merge_columns = 'COUNTRY_ID,REGION_STATE_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'REGION_STATE', region_state_df, merge_columns)

    #display(region_state_df)

# COMMAND ----------

# DBTITLE 1,Address_Type
#Load Address Type Data from Standard Values
address_type_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Address Type'")\
                                 .select(col('Target_Standard_Code').alias('ADDRESS_TYPE_CODE')
                                       , col('Target_Standard_Value_Name').alias('ADDRESS_TYPE_NAME')
                                       , col('Target_Standard_Value_Description').alias('ADDRESS_TYPE_DESC')
                                       , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                       , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                        ).distinct()

#Load Address Type Data from Counterparty Xref
address_type_xref_df = MDM_COUNTERPARTY_XREF.select(col('ADDRESS_TYPE_CD').alias('ADDRESS_TYPE_CODE')
                                                  , col('ADDRESS_TYPE_CD').alias('ADDRESS_TYPE_NAME')
                                                  , col('ADDRESS_TYPE_CD').alias('ADDRESS_TYPE_DESC')
                                                  , lit("Y").alias('ACTIVE_IND')
                                                  , col('SOURCE_SYSTEM_CODE')
                                                   ).distinct()

#Union all datasets
address_type_xref_df = address_type_xref_df[address_type_ref_df.columns]
address_type_df = address_type_ref_df.union(address_type_xref_df)

if address_type_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    address_type_df = address_type_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    address_type_df = address_type_df.drop(*columns_to_drop).dropDuplicates(['ADDRESS_TYPE_CODE', 'SOURCE_SYSTEM_ID']).na.drop(subset=['ADDRESS_TYPE_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'ADDRESS_TYPE', address_type_df)
    merge_columns = 'ADDRESS_TYPE_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'ADDRESS_TYPE', address_type_df, merge_columns)
    
    display(address_type_df)

# COMMAND ----------

# DBTITLE 1,KYC_Status_Value
#Load KYC Status Value Data from Standard Values
kyc_status_value_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Status – KYC Review'")\
                              .select(col('Target_Standard_Code').alias('KYC_STATUS_VALUE_CODE')
                                    , col('Target_Standard_Value_Name').alias('KYC_STATUS_VALUE_NAME')
                                    , col('Target_Standard_Value_Description').alias('KYC_STATUS_VALUE_DESC')
                                    , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                    , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                     ).distinct()

#Load Address Type Data from Counterparty Xref
kyc_status_value_xref_df = MDM_COUNTERPARTY_XREF.select(col('KYC_STATUS_VALUE').alias('KYC_STATUS_VALUE_CODE')
                                                      , col('KYC_STATUS_VALUE').alias('KYC_STATUS_VALUE_NAME')
                                                      , col('KYC_STATUS_VALUE').alias('KYC_STATUS_VALUE_DESC')
                                                      , lit("Y").alias('ACTIVE_IND')
                                                      , col('SOURCE_SYSTEM_CODE')
                                                       ).distinct()

#Union all datasets
kyc_status_value_xref_df = kyc_status_value_xref_df[kyc_status_value_ref_df.columns]
kyc_status_value_df = kyc_status_value_ref_df.union(kyc_status_value_xref_df)

if kyc_status_value_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    kyc_status_value_df = kyc_status_value_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    kyc_status_value_df = kyc_status_value_df.drop(*columns_to_drop).dropDuplicates(['KYC_STATUS_VALUE_CODE', 'SOURCE_SYSTEM_ID'])\
                                                                    .na.drop(subset=['KYC_STATUS_VALUE_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'KYC_STATUS_VALUE', kyc_status_value_df)
    merge_columns = 'KYC_STATUS_VALUE_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'KYC_STATUS_VALUE', kyc_status_value_df, merge_columns)
    
    display(kyc_status_value_df)

# COMMAND ----------

# DBTITLE 1,KYC_Level_of_DD
#Load KYC Level of DD Data from Standard Values
kyc_level_of_dd_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Level of Due Diligence'")\
                                        .select(col('Target_Standard_Code').alias('KYC_LEVEL_OF_DD_CD')
                                              , col('Target_Standard_Value_Name').alias('KYC_LEVEL_OF_DD_NAME')
                                              , col('Target_Standard_Value_Description').alias('KYC_LEVEL_OF_DD_DESC')
                                              , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                              , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                               ).distinct()

#Load KYC Level of DD Data from Counterparty Xref
kyc_level_of_dd_xref_df = MDM_COUNTERPARTY_XREF.select(col('KYC_STATUS_LEVEL_OF_DD').alias('KYC_LEVEL_OF_DD_CD')
                                                     , col('KYC_STATUS_LEVEL_OF_DD').alias('KYC_LEVEL_OF_DD_NAME')
                                                     , col('KYC_STATUS_LEVEL_OF_DD').alias('KYC_LEVEL_OF_DD_DESC')
                                                     , lit("Y").alias('ACTIVE_IND')
                                                     , col('SOURCE_SYSTEM_CODE')
                                                      ).distinct()

#Union all datasets
kyc_level_of_dd_xref_df = kyc_level_of_dd_xref_df[kyc_level_of_dd_ref_df.columns]
kyc_level_of_dd_df = kyc_level_of_dd_ref_df.union(kyc_level_of_dd_xref_df)

if kyc_level_of_dd_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    kyc_level_of_dd_df = kyc_level_of_dd_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    kyc_level_of_dd_df = kyc_level_of_dd_df.drop(*columns_to_drop).dropDuplicates(['KYC_LEVEL_OF_DD_CD', 'SOURCE_SYSTEM_ID'])\
                                                                  .na.drop(subset=['KYC_LEVEL_OF_DD_CD', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'KYC_LEVEL_OF_DD', kyc_level_of_dd_df)
    merge_columns = 'KYC_LEVEL_OF_DD_CD,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'KYC_LEVEL_OF_DD', kyc_level_of_dd_df, merge_columns)
    
    display(kyc_level_of_dd_df)

# COMMAND ----------

# DBTITLE 1,Party_Status_Type
# Create default party status type dataframe with hard coded value
source_system_default_nametype_df = sc.parallelize([
    ['Active_Status', 'Active_Status', 'Active_Status', 'MDM', 'Y']
  ]).toDF(("PARTY_STATUS_TYPE_CODE", "PARTY_STATUS_TYPE_NAME", "PARTY_STATUS_TYPE_DESC", "SOURCE_SYSTEM_CODE", "ACTIVE_IND"))

#Load Party Status Type Data from Standard Values
party_status_type_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Party Status Type'")\
                                         .select(col('Target_Standard_Code').alias('PARTY_STATUS_TYPE_CODE')
                                               , col('Target_Standard_Value_Name').alias('PARTY_STATUS_TYPE_NAME')
                                               , col('Target_Standard_Value_Description').alias('PARTY_STATUS_TYPE_DESC')
                                               , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                               , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                                ).distinct()

#Load Party Status Type Data from Counterparty Xref
party_status_type_xref_df = MDM_COUNTERPARTY_XREF.select(col('PARTY_STATUS_CD').alias('PARTY_STATUS_TYPE_CODE')
                                                       , col('PARTY_STATUS_CD').alias('PARTY_STATUS_TYPE_NAME')
                                                       , col('PARTY_STATUS_CD').alias('PARTY_STATUS_TYPE_DESC')
                                                       , lit("Y").alias('ACTIVE_IND')
                                                       , col('SOURCE_SYSTEM_CODE')
                                                        ).distinct()

party_status_type_xref_active_df = MDM_COUNTERPARTY_XREF.select(col('ACTIVE_STATUS_CODE').alias('PARTY_STATUS_TYPE_CODE')
                                                       , col('ACTIVE_STATUS_CODE').alias('PARTY_STATUS_TYPE_NAME')
                                                       , col('ACTIVE_STATUS_CODE').alias('PARTY_STATUS_TYPE_DESC')
                                                       , lit("Y").alias('ACTIVE_IND')
                                                       , col('SOURCE_SYSTEM_CODE')
                                                        ).distinct()

# Re-order columns
party_status_type_xref_df = party_status_type_xref_df[source_system_default_nametype_df.columns]
party_status_type_ref_df = party_status_type_ref_df[source_system_default_nametype_df.columns]
party_status_type_xref_active_df = party_status_type_xref_active_df[source_system_default_nametype_df.columns]

# Union all datasets
party_status_type_df = source_system_default_nametype_df.union(party_status_type_ref_df)\
                                                         .union(party_status_type_xref_df)\
                                                         .union(party_status_type_xref_active_df)

if party_status_type_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    party_status_type_df = party_status_type_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    party_status_type_df = party_status_type_df.drop(*columns_to_drop).dropDuplicates(['PARTY_STATUS_TYPE_CODE', 'SOURCE_SYSTEM_ID'])\
                                                                      .na.drop(subset=['PARTY_STATUS_TYPE_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'PARTY_STATUS_TYPE', party_status_type_df)
    merge_columns = 'PARTY_STATUS_TYPE_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'PARTY_STATUS_TYPE', party_status_type_df, merge_columns)
    
    display(party_status_type_df)

# COMMAND ----------

# DBTITLE 1,Party_Status_Value
#Load Party Status Value Data from Standard Values
party_status_value_ref_df1 = REF_DATA.filter("reference_entity_name_pick_list_name='DNDB Status'")\
                                  .select(col('Target_Standard_Code').alias('PARTY_STATUS_VALUE_CODE')
                                          , col('Target_Standard_Value_Name').alias('PARTY_STATUS_VALUE_NAME')
                                          , col('Target_Standard_Value_Description').alias('PARTY_STATUS_VALUE_DESC')
                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                          , col('Parent_Reference_Entity_Name_Nullable').alias('PARTY_STATUS_TYPE_CODE')
                                         ).distinct()

party_status_value_ref_df2 = REF_DATA.filter("reference_entity_name_pick_list_name='Sanction Type'")\
                                  .select(col('Target_Standard_Code').alias('PARTY_STATUS_VALUE_CODE')
                                          , col('Target_Standard_Value_Name').alias('PARTY_STATUS_VALUE_NAME')
                                          , col('Target_Standard_Value_Description').alias('PARTY_STATUS_VALUE_DESC')
                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                          , col('Parent_Reference_Entity_Name_Nullable').alias('PARTY_STATUS_TYPE_CODE')
                                         ).distinct()

party_status_value_ref_df3 = REF_DATA.filter("reference_entity_name_pick_list_name='Status – KYC Cleared for Deals'")\
                                  .select(col('Target_Standard_Code').alias('PARTY_STATUS_VALUE_CODE')
                                          , col('Target_Standard_Value_Name').alias('PARTY_STATUS_VALUE_NAME')
                                          , col('Target_Standard_Value_Description').alias('PARTY_STATUS_VALUE_DESC')
                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                          , col('Parent_Reference_Entity_Name_Nullable').alias('PARTY_STATUS_TYPE_CODE')
                                         ).distinct()

party_status_value_ref_df4 = REF_DATA.filter("reference_entity_name_pick_list_name='Status – System Active Indicator'")\
                                  .select(col('Target_Standard_Code').alias('PARTY_STATUS_VALUE_CODE')
                                          , col('Target_Standard_Value_Name').alias('PARTY_STATUS_VALUE_NAME')
                                          , col('Target_Standard_Value_Description').alias('PARTY_STATUS_VALUE_DESC')
                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                          , col('Parent_Reference_Entity_Name_Nullable').alias('PARTY_STATUS_TYPE_CODE')
                                         ).distinct()

party_status_value_ref_df4 = party_status_value_ref_df4.withColumn('PARTY_STATUS_TYPE_CODE', lit('Active_Status'))

#party_status_value_df4 = party_status_value_df4.withColumn('PARTY_STATUS_TYPE_CODE', when(length(trim(party_status_value_df4.PARTY_STATUS_TYPE_CODE)) == 0, lit('Active_Status')).otherwise(party_status_value_df4.PARTY_STATUS_TYPE_CODE).alias("PARTY_STATUS_TYPE_CODE"))
#party_status_value_df4 = party_status_value_df4.withColumn('PARTY_STATUS_TYPE_CODE', when((party_status_value_df4.PARTY_STATUS_TYPE_CODE) == lit(None), lit('Active_Status')).otherwise(party_status_value_df4.PARTY_STATUS_TYPE_CODE).alias("PARTY_STATUS_TYPE_CODE"))

#Load Party Status Value Data from Counterparty Xref
party_status_value_xref_df = MDM_COUNTERPARTY_XREF.select(col('PARTY_STATUS_VALUE_CD')
                                                        , col('PARTY_STATUS_CD')
                                                        , col('SOURCE_SYSTEM_CODE')
                                                         ).distinct()

party_status_value_xref_active_df = MDM_COUNTERPARTY_XREF.select(col('ACTIVE_STATUS_CODE')
                                                        , col('SOURCE_SYSTEM_CODE')
                                                         ).distinct()

party_status_value_xref_df = party_status_value_xref_df.withColumn("PARTY_STATUS_VALUE_CD", f.split('PARTY_STATUS_VALUE_CD', '[|]')[1])

party_status_value_xref_df = party_status_value_xref_df.select(col('PARTY_STATUS_VALUE_CD').alias('PARTY_STATUS_VALUE_CODE')
                                                             , col('PARTY_STATUS_VALUE_CD').alias('PARTY_STATUS_VALUE_NAME')
                                                             , col('PARTY_STATUS_VALUE_CD').alias('PARTY_STATUS_VALUE_DESC')
                                                             , lit('Y').alias('ACTIVE_IND')
                                                             , col('SOURCE_SYSTEM_CODE')
                                                             , col('PARTY_STATUS_CD').alias('PARTY_STATUS_TYPE_CODE')
                                                              ).distinct()

party_status_value_xref_active_df = party_status_value_xref_active_df.select(col('ACTIVE_STATUS_CODE').alias('PARTY_STATUS_VALUE_CODE')
                                                             , col('ACTIVE_STATUS_CODE').alias('PARTY_STATUS_VALUE_NAME')
                                                             , col('ACTIVE_STATUS_CODE').alias('PARTY_STATUS_VALUE_DESC')
                                                             , lit('Y').alias('ACTIVE_IND')
                                                             , col('SOURCE_SYSTEM_CODE')
                                                             , col('ACTIVE_STATUS_CODE').alias('PARTY_STATUS_TYPE_CODE')
                                                              ).distinct()

# Re-order columns
party_status_value_xref_df = party_status_value_xref_df[party_status_value_ref_df2.columns]
party_status_value_ref_df1 = party_status_value_ref_df1[party_status_value_ref_df2.columns]
party_status_value_ref_df3 = party_status_value_ref_df3[party_status_value_ref_df2.columns]
party_status_value_ref_df4 = party_status_value_ref_df4[party_status_value_ref_df2.columns]
party_status_value_xref_active_df = party_status_value_xref_active_df[party_status_value_ref_df2.columns]
                                                               
# Union all datasets
party_status_value_df = party_status_value_ref_df1.union(party_status_value_ref_df2)\
                                                  .union(party_status_value_ref_df3)\
                                                  .union(party_status_value_ref_df4)\
                                                  .union(party_status_value_xref_df)\
                                                  .union(party_status_value_xref_active_df)

#Load Party Status Type Data from SQL DB
party_status_type_df = LoadSourceSystemFromDB('ENT_LEGAL_ENTITY_REF_DATA', 'PARTY_STATUS_TYPE');
party_status_type_subset_df = party_status_type_df.select(col('PARTY_STATUS_TYPE_ID'), col('PARTY_STATUS_TYPE_CODE'), col('SOURCE_SYSTEM_ID'));

if party_status_value_df is not None and party_status_type_subset_df is not None and source_system_id_code_df is not None:
  
    # Join SOURCE_SYSTEM to get SOURCE_SYSTEM_ID
    party_status_value_df = party_status_value_df.join(source_system_id_code_df, ['SOURCE_SYSTEM_CODE'], 'left')

    # Join PARTY_STATUS_TYPE to get PARTY_STATUS_TYPE_ID and SOURCE_SYSTEM to get SOURCE_SYSTEM_ID
    party_status_value_df = party_status_value_df.join(party_status_type_subset_df, ['PARTY_STATUS_TYPE_CODE', 'SOURCE_SYSTEM_ID'], 'left')

    # drop unnecessary columns
    columns_to_drop = ['PARTY_STATUS_TYPE_CODE', 'SOURCE_SYSTEM_CODE']
    party_status_value_df = party_status_value_df.dropDuplicates(['PARTY_STATUS_TYPE_ID', 'PARTY_STATUS_VALUE_CODE', 'SOURCE_SYSTEM_ID'])\
                                                 .drop(*columns_to_drop).na.drop(subset=['PARTY_STATUS_TYPE_ID', 'PARTY_STATUS_VALUE_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY', 'PARTY_STATUS_VALUE', party_status_value_df)
    merge_columns = 'PARTY_STATUS_VALUE_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'PARTY_STATUS_VALUE', party_status_value_df, merge_columns)

    display(party_status_value_df)

# COMMAND ----------

# DBTITLE 1,Business_Area
#Load Business Area Data from Standard Values
business_area_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Region'")\
                              .select(col('Target_Standard_Code').alias('BUSINESS_AREA_CODE')
                                          , col('Target_Standard_Value_Name').alias('BUSINESS_AREA_NAME')
                                          , col('Target_Standard_Value_Description').alias('BUSINESS_AREA_DESC')
                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                         ).distinct()

#Load Business Area Data from Scope Xref
business_area_scope_xref_df = MDM_COUNTERPARTY_SCOPE_XREF.select(col('BUSINESS_AREA_CD').alias('BUSINESS_AREA_CODE')
                                                               , col('BUSINESS_AREA_CD').alias('BUSINESS_AREA_NAME')
                                                               , col('BUSINESS_AREA_CD').alias('BUSINESS_AREA_DESC')
                                                               , col('SOURCE_SYSTEM_CODE')
                                                               , lit("Y").alias('ACTIVE_IND')
                                                                ).distinct()

#Union all datasets
business_area_scope_xref_df = business_area_scope_xref_df[business_area_ref_df.columns]
business_area_df = business_area_ref_df.union(business_area_scope_xref_df)

if business_area_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    business_area_df = business_area_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    business_area_df = business_area_df.drop(*columns_to_drop).dropDuplicates(['BUSINESS_AREA_CODE', 'SOURCE_SYSTEM_ID']).na.drop(subset=['BUSINESS_AREA_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'BUSINESS_AREA', business_area_df)
    merge_columns = 'BUSINESS_AREA_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'BUSINESS_AREA', business_area_df, merge_columns)

    display(business_area_df)

# COMMAND ----------

# DBTITLE 1,Commodity
#Load Commodity Data from Standard Values
commodity_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Commodity (Business Line)'")\
                              .select(col('Target_Standard_Code').alias('COMMODITY_CODE')
                                          , col('Target_Standard_Value_Name').alias('COMMODITY_NAME')
                                          , col('Target_Standard_Value_Description').alias('COMMODITY_DESC')
                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                         ).distinct()

#Load Commodity Data from Scope Xref
commodity_scope_xref_df = MDM_COUNTERPARTY_SCOPE_XREF.select(col('COMMODITY_CD').alias('COMMODITY_CODE')
                                                           , col('COMMODITY_CD').alias('COMMODITY_NAME')
                                                           , col('COMMODITY_CD').alias('COMMODITY_DESC')
                                                           , col('SOURCE_SYSTEM_CODE')
                                                           , lit("Y").alias('ACTIVE_IND')
                                                            ).distinct()

#Union all datasets
commodity_scope_xref_df = commodity_scope_xref_df[commodity_ref_df.columns]
commodity_df = commodity_ref_df.union(commodity_scope_xref_df)

if commodity_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    commodity_df = commodity_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    commodity_df = commodity_df.drop(*columns_to_drop).dropDuplicates(['COMMODITY_CODE', 'SOURCE_SYSTEM_ID']).na.drop(subset=['COMMODITY_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'COMMODITY', commodity_df)
    merge_columns = 'COMMODITY_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'COMMODITY', commodity_df, merge_columns)

    display(commodity_df)

# COMMAND ----------

# DBTITLE 1,Shell_Company
#Load Shell Company Data from Standard Values
shell_company_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Shell Company (Code and Name)'")\
                              .select(col('Target_Standard_Code').alias('SHELL_COMPANY_CODE')
                                          , col('Target_Standard_Value_Name').alias('SHELL_COMPANY_NAME')
                                          , col('Target_Standard_Value_Description').alias('SHELL_COMPANY_DESC')
                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                         ).distinct()

##Load Shell Company Data from Scope Xref
shell_company_scope_xref_df = MDM_COUNTERPARTY_SCOPE_XREF.select(col('SHELL_COMPANY_CD').alias('SHELL_COMPANY_CODE')
                                                               , col('SHELL_COMPANY_CD').alias('SHELL_COMPANY_NAME')
                                                               , col('SHELL_COMPANY_CD').alias('SHELL_COMPANY_DESC')
                                                               , col('SOURCE_SYSTEM_CODE')
                                                               , lit("Y").alias('ACTIVE_IND')
                                                                ).distinct();

# Copy Name and Description from MDM to Xref records
join_column = 'SHELL_COMPANY_CODE';
columns_to_copy_mdm = 'SHELL_COMPANY_NAME,SHELL_COMPANY_DESC';
columns_to_drop_mdm = 'SOURCE_SYSTEM_CODE,ACTIVE_IND'
shell_company_scope_xref_df = shell_company_scope_xref_df.drop(*columns_to_copy_mdm.split(','))
shell_company_ref_subset_df = shell_company_ref_df.drop(*columns_to_drop_mdm.split(','))
shell_company_scope_xref_df = shell_company_scope_xref_df.join(shell_company_ref_subset_df, join_column.split(','), 'left')

#Union all datasets
shell_company_scope_xref_df = shell_company_scope_xref_df[shell_company_ref_df.columns]
shell_company_df = shell_company_ref_df.union(shell_company_scope_xref_df)

if shell_company_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    shell_company_df = shell_company_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    shell_company_df = shell_company_df.drop(*columns_to_drop).dropDuplicates(['SHELL_COMPANY_CODE', 'SOURCE_SYSTEM_ID']).na.drop(subset=['SHELL_COMPANY_CODE', 'SOURCE_SYSTEM_ID'])
    
    merge_columns = 'SHELL_COMPANY_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'SHELL_COMPANY', shell_company_df, merge_columns)

    display(shell_company_df)

# COMMAND ----------

# DBTITLE 1,End_System_Class
#Load End System Class Data from Standard Values
end_system_class_df = REF_DATA.filter("reference_entity_name_pick_list_name='End System Classification'")\
                              .select(col('Target_Standard_Code').alias('END_SYSTEM_CLASS_CODE')
                                          , col('Target_Standard_Value_Name').alias('END_SYSTEM_CLASS_NAME')
                                          , col('Target_Standard_Value_Description').alias('END_SYSTEM_CLASS_DESC')
                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                         ).distinct()

if end_system_class_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    end_system_class_df = end_system_class_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    end_system_class_df = end_system_class_df.drop(*columns_to_drop).dropDuplicates(['END_SYSTEM_CLASS_CODE', 'SOURCE_SYSTEM_ID'])\
                                                                    .na.drop(subset=['END_SYSTEM_CLASS_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'END_SYSTEM_CLASS', end_system_class_df)
    merge_columns = 'END_SYSTEM_CLASS_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'END_SYSTEM_CLASS', end_system_class_df, merge_columns)
    
    display(end_system_class_df)

# COMMAND ----------

# DBTITLE 1,Service_Type
#Load Service Type Data from Standard Values
service_type_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Service Type (Business Line)'")\
                              .select(col('Target_Standard_Code').alias('SERVICE_TYPE_CODE')
                                          , col('Target_Standard_Value_Name').alias('SERVICE_TYPE_NAME')
                                          , col('Target_Standard_Value_Description').alias('SERVICE_TYPE_DESC')
                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                         ).distinct()

#Load Service Type Data from Scope Xref
service_type_scope_xref_df = MDM_COUNTERPARTY_SCOPE_XREF.select(col('SERVICE_TYPE_CD').alias('SERVICE_TYPE_CODE')
                                                              , col('SERVICE_TYPE_CD').alias('SERVICE_TYPE_NAME')
                                                              , col('SERVICE_TYPE_CD').alias('SERVICE_TYPE_DESC')
                                                              , col('SOURCE_SYSTEM_CODE')
                                                              , lit("Y").alias('ACTIVE_IND')
                                                               ).distinct()

#Union all datasets
service_type_scope_xref_df = service_type_scope_xref_df[service_type_ref_df.columns]
service_type_df = service_type_ref_df.union(service_type_scope_xref_df)

if service_type_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    service_type_df = service_type_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    service_type_df = service_type_df.drop(*columns_to_drop).dropDuplicates(['SERVICE_TYPE_CODE', 'SOURCE_SYSTEM_ID']).na.drop(subset=['SERVICE_TYPE_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'SERVICE_TYPE', service_type_df)
    merge_columns = 'SERVICE_TYPE_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'SERVICE_TYPE', service_type_df, merge_columns)

    display(service_type_df)

# COMMAND ----------

# DBTITLE 1,Counterparty_Role
#Load Counterparty Role Data from Standard Values
counterparty_role_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Business Relationship'")\
                              .select(col('Target_Standard_Code').alias('COUNTERPARTY_ROLE_CODE')
                                          , col('Target_Standard_Value_Name').alias('COUNTERPARTY_ROLE_NAME')
                                          , col('Target_Standard_Value_Description').alias('COUNTERPARTY_ROLE_DESC')
                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                         ).distinct()

#Load Counterparty Role Data from Scope Xref
counterparty_role_scope_xref_df = MDM_COUNTERPARTY_SCOPE_XREF.select(col('COUNTERPARTY_ROLE_CD').alias('COUNTERPARTY_ROLE_CODE')
                                                                   , col('COUNTERPARTY_ROLE_CD').alias('COUNTERPARTY_ROLE_NAME')
                                                                   , col('COUNTERPARTY_ROLE_CD').alias('COUNTERPARTY_ROLE_DESC')
                                                                   , col('SOURCE_SYSTEM_CODE')
                                                                   , lit("Y").alias('ACTIVE_IND')
                                                                    ).distinct()

#Union all datasets
counterparty_role_scope_xref_df = counterparty_role_scope_xref_df[counterparty_role_ref_df.columns]
counterparty_role_df = counterparty_role_ref_df.union(counterparty_role_scope_xref_df)

if counterparty_role_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    counterparty_role_df = counterparty_role_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    counterparty_role_df = counterparty_role_df.drop(*columns_to_drop).dropDuplicates(['COUNTERPARTY_ROLE_CODE', 'SOURCE_SYSTEM_ID'])\
                                                                      .na.drop(subset=['COUNTERPARTY_ROLE_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'COUNTERPARTY_ROLE', counterparty_role_df)
    merge_columns = 'COUNTERPARTY_ROLE_CODE,SOURCE_SYSTEM_ID,COUNTERPARTY_ROLE_NAME';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'COUNTERPARTY_ROLE', counterparty_role_df, merge_columns)

    display(counterparty_role_df)

# COMMAND ----------

# DBTITLE 1,Review_Status
#Load Review Status Data from Standard Values
review_status_df = REF_DATA.filter("reference_entity_name_pick_list_name='Status – Review (General)'")\
                              .select(col('Target_Standard_Code').alias('REVIEW_STATUS_CODE')
                                          , col('Target_Standard_Value_Name').alias('REVIEW_STATUS_NAME')
                                          , col('Target_Standard_Value_Description').alias('REVIEW_STATUS_DESC')
                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                         ).distinct()

if review_status_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    review_status_df = review_status_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    review_status_df = review_status_df.drop(*columns_to_drop).dropDuplicates(['REVIEW_STATUS_CODE', 'SOURCE_SYSTEM_ID']).na.drop(subset=['REVIEW_STATUS_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'REVIEW_STATUS', review_status_df)
    merge_columns = 'REVIEW_STATUS_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'REVIEW_STATUS', review_status_df, merge_columns)
    
    display(review_status_df)

# COMMAND ----------

# DBTITLE 1,Trading_Desk
#Load Trading Desk Data from Standard Values
trading_desk_ref_df = REF_DATA.filter("reference_entity_name_pick_list_name='Trading Desk'")\
                              .select(col('Target_Standard_Code').alias('TRADING_DESK_CODE')
                                          , col('Target_Standard_Value_Name').alias('TRADING_DESK_NAME')
                                          , col('Target_Standard_Value_Description').alias('TRADING_DESK_DESC')
                                          , lit('MDM').alias('SOURCE_SYSTEM_CODE')
                                          , col('Active_Indicator').substr(1, 1).alias('ACTIVE_IND')
                                         ).distinct()

#Load Trading Desk Data from Scope Xref
trading_desk_scope_xref_df = MDM_COUNTERPARTY_SCOPE_XREF.select(col('TRADING_DESK_CD').alias('TRADING_DESK_CODE')
                                                              , col('TRADING_DESK_CD').alias('TRADING_DESK_NAME')
                                                              , col('TRADING_DESK_CD').alias('TRADING_DESK_DESC')
                                                              , col('SOURCE_SYSTEM_CODE')
                                                              , lit("Y").alias('ACTIVE_IND')
                                                               ).distinct()

#Union all datasets
trading_desk_scope_xref_df = trading_desk_scope_xref_df[trading_desk_ref_df.columns]
trading_desk_df = trading_desk_ref_df.union(trading_desk_scope_xref_df)

if trading_desk_df is not None and source_system_id_code_df is not None:
  
    # Join with source system to get source system id
    trading_desk_df = trading_desk_df.join(source_system_id_code_df, 'SOURCE_SYSTEM_CODE', 'left')
    
    # drop unnecessary columns
    columns_to_drop = ['SOURCE_SYSTEM_CODE']
    trading_desk_df = trading_desk_df.drop(*columns_to_drop).dropDuplicates(['TRADING_DESK_CODE', 'SOURCE_SYSTEM_ID']).na.drop(subset=['TRADING_DESK_CODE', 'SOURCE_SYSTEM_ID'])
    
    #SaveDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'TRADING_DESK', trading_desk_df)
    merge_columns = 'TRADING_DESK_CODE,SOURCE_SYSTEM_ID';
    UpsertDataToSQLDB('ENT_LEGAL_ENTITY_REF_DATA', 'TRADING_DESK', trading_desk_df, merge_columns)

    display(trading_desk_df)

# COMMAND ----------

if new_watermark_value_standard_values is not None and len(str(new_watermark_value_standard_values)) > 0:  
    UpsertWatermarkValue(usecase_code, dataset_standard_values, new_watermark_value_standard_values, dbServer=dbServer_curated, dbDatabase=dbDatabase_curated)
