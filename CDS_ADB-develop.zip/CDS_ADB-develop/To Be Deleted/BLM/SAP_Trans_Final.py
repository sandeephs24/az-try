# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# DBTITLE 1,Import connections
# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

# MAGIC %run "/BLM/cp_master"

# COMMAND ----------

# DBTITLE 1,Read Tables used in the Joins
#read in cp_master file
#vw_bexcel_cpdata_cp_master_stg
#vw_bexcel_cpdata_sap_trans_stg
#vw_bexcel_cpdata_sap_master_stg

# COMMAND ----------

# DBTITLE 1,create temp views for curated sql tables
curated_schema_name= 'pty_counterparty' #added on 9/23/2021 to integrate SAP P2 changes
curated_tables_list  = ['cp_sap_master']   #to add sap master from SAP System 
for table_name in curated_tables_list:
        df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
        df.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")

# COMMAND ----------

# DBTITLE 1,SAP CP MASTER + SAP FINANCIALS MASTER
# MAGIC %sql
# MAGIC -- Join SAP CP table and SAP FINANCIALS MASTER (updated to point to cp_sap_master with respective columns as part of SAP P2 integration on 9/23/2021)
# MAGIC create or replace temporary view sap_master_trans as 
# MAGIC (
# MAGIC  select
# MAGIC     sap_master.SAP_SYSTEM	    sap_linked_sap_system
# MAGIC   ,sap_master.SAP_UNIQUE_ID	    sap_unique_id
# MAGIC   ,sap_master.SAP_NAME	        sap_name
# MAGIC   ,sap_master.SAP_COMPANY_CODE  sap_company_code
# MAGIC   ,sap_master.SAP_COUNTRY	    sap_country
# MAGIC   ,sap_master.SAP_REGION	    sap_region
# MAGIC   ,sap_master.SAP_CITY	        sap_city
# MAGIC   ,sap_master.SAP_ADDRESS	    sap_address
# MAGIC   ,sap_master.SAP_POSTCODE	    sap_postcode
# MAGIC   ,sap_master.SAP_CREATE_DATE	sap_create_date
# MAGIC   ,sap_master.SAP_DEACTIVATED	sap_deactivated
# MAGIC   ,SAP_BLOCK_POSTING	        sap_block_posting
# MAGIC   ,SAP_PAYMENT_BLOCK	        sap_block_payment
# MAGIC   ,SAP_BLOCK_PURCHASE	        sap_block_purchase
# MAGIC   ,sap_master.SAP_ACCOUNT_NO    sap_account_no,
# MAGIC   --,coalesce(sap_master.SAP_ACCOUNT_NO, strans.`Account Number`)	sap_account_no,
# MAGIC   strans.Cpty_Type as sap_linked_sap_cpty_type,
# MAGIC   strans.Transacted_Company_Code as sap_transacted_company_code,
# MAGIC   strans.`Settlement Currency` as sap_settlement_currency,
# MAGIC   strans.Posting_Month as sap_posting_month,
# MAGIC   strans.`Settlement Value (AP/AR LC)` as sap_settlement_value_ap_or_ar_lc,
# MAGIC   strans.Latest_Settlement_Date as sap_latest_settlement_date
# MAGIC   ,strans.UNIQUE_ID right_uniq
# MAGIC   
# MAGIC   from 
# MAGIC   vw_pty_counterparty_cp_sap_master sap_master left join vw_bexcel_cpdata_sap_trans_stg strans on sap_master.SAP_UNIQUE_ID=strans.UNIQUE_ID
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Join CP Master table and above table
# MAGIC create or replace temporary view cp_sap_master_trans as 
# MAGIC (
# MAGIC   select *  from 
# MAGIC   vw_cp_master left join sap_master_trans  on cp_sap_unique_id=sap_unique_id
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_escpl_ertrm_cp_sap_final_Stg as 
# MAGIC (
# MAGIC   select distinct
# MAGIC   csmt.cp_system, --
# MAGIC   csmt.cp_unique_id, --
# MAGIC   csmt.cp_name, --
# MAGIC   csmt.cp_entity_type, --
# MAGIC   csmt.cp_deactivated, --
# MAGIC --   csmt.sap_linked_sap_cpty_type,-- changing this to below column using case statement
# MAGIC   case when csmt.sap_linked_sap_cpty_type is not null then csmt.sap_linked_sap_cpty_type
# MAGIC        else csmt.cp_sap_account_type
# MAGIC   end sap_linked_sap_cpty_type,
# MAGIC --   csmt.sap_linked_sap_system,
# MAGIC   sap_system as sap_linked_sap_system,
# MAGIC   /*below code contains the both STNSAP, TSAP as sap_linked_system for one cp_unique_id instead want for SAP_UNIQUE_ID - -commenting the code based on bug (969780) raised on 8/25/2021 */
# MAGIC --   case when csmt.sap_linked_sap_system is not null  then csmt.sap_linked_sap_system 
# MAGIC --        else csmt.cp_linked_sap_system
# MAGIC --   end sap_linked_sap_system,
# MAGIC   csmt.cp_sap_unique_id as sap_linked_sap_unique_id, 
# MAGIC   csmt.sap_name,
# MAGIC   csmt.sap_country,
# MAGIC   csmt.sap_region,
# MAGIC   csmt.sap_city,
# MAGIC   csmt.sap_address,
# MAGIC   csmt.sap_postcode,
# MAGIC   ldf.latest_sap_create_date as sap_create_date,
# MAGIC   csmt.sap_deactivated,
# MAGIC   csmt.sap_block_posting,
# MAGIC   csmt.sap_block_payment,
# MAGIC   ldf.sap_company_code,
# MAGIC   csmt.sap_block_purchase,
# MAGIC   ldf.Latest_Settlement_Date as sap_latest_settlement_date,
# MAGIC   csmt.sap_posting_month,
# MAGIC   csmt.sap_transacted_company_code,
# MAGIC   csmt.sap_settlement_currency,
# MAGIC   csmt.sap_settlement_value_ap_or_ar_lc,
# MAGIC   csmt.cp_sap_link as sap_link,
# MAGIC   csmt.sap_account_no,
# MAGIC   csmt.cp_system as source_system,
# MAGIC   1 as load_status
# MAGIC   --cp_account_number, removed as part of cp_master implementation
# MAGIC   --cp_cpty_type, removed as part of cp_master implementation
# MAGIC   --sap_settlement_activity, removed as part of cp_master implementation
# MAGIC   --sap_settlement_recency removed as part of cp_master implementation
# MAGIC   
# MAGIC   from
# MAGIC   cp_sap_master_trans csmt 
# MAGIC   left join vw_cp_mstr_latest_dates_with_flag ldf on csmt.cp_unique_id=ldf.cp_unique_id
# MAGIC   );

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'escpl_ertrm_cp_sap_final_Stg')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'escpl_ertrm_cp_sap_final_Stg', 'pty_counterparty', 'escpl_ertrm_cp_sap_final')
