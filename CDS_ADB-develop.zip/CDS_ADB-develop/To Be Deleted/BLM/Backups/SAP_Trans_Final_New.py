# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# DBTITLE 1,Import connections
# MAGIC %run "/BLM/config"

# COMMAND ----------

# MAGIC %run "/BLM/cp_master"

# COMMAND ----------

# DBTITLE 1,Read Tables used in the Joins
#read in cp_master file
#vw_bexcel_cpdata_cp_master_stg
#vw_bexcel_cpdata_sap_trans_stg
#vw_bexcel_cpdata_sap_master_stg

# COMMAND ----------

# DBTITLE 1,SAP CP MASTER + SAP FINANCIALS MASTER
# MAGIC %sql
# MAGIC -- Join SAP CP table and SAP FINANCIALS MASTER
# MAGIC create or replace temporary view sap_master_trans as 
# MAGIC (
# MAGIC   select
# MAGIC   sap_master.`SAP SYSTEM`	sap_linked_sap_system
# MAGIC   ,sap_master.UNIQUE_ID	sap_unique_id
# MAGIC   ,sap_master.`SAP NAME`	sap_name
# MAGIC   ,sap_master.`SAP COMPANY CODE` sap_company_code
# MAGIC   ,sap_master.`SAP COUNTRY`	sap_country
# MAGIC   ,sap_master.`SAP REGION`	sap_region
# MAGIC   ,sap_master.`SAP CITY`	sap_city
# MAGIC   ,sap_master.`SAP ADDRESS`	sap_address
# MAGIC   ,sap_master.`SAP POSTCODE`	sap_postcode
# MAGIC   ,sap_master.`SAP CREATE DATE`	sap_create_date
# MAGIC   ,sap_master.`SAP DEACTIVATED`	sap_deactivated
# MAGIC   ,BLOCK_POSTING	sap_block_posting
# MAGIC   ,BLOCK_PAYMENT	sap_block_payment
# MAGIC   ,BLOCK_PURCHASE	sap_block_purchase
# MAGIC   ,sap_master.SAP_ACCOUNT_NO	sap_account_no,
# MAGIC   --,coalesce(sap_master.SAP_ACCOUNT_NO, strans.`Account Number`)	sap_account_no,
# MAGIC   strans.Cpty_Type as sap_linked_sap_cpty_type,
# MAGIC   strans.Transacted_Company_Code as sap_transacted_company_code,
# MAGIC   strans.`Settlement Currency` as sap_settlement_currency,
# MAGIC   strans.Posting_Month as sap_posting_month,
# MAGIC   strans.`Settlement Value (AP/AR LC)` as sap_settlement_value_ap_or_ar_lc,
# MAGIC   strans.Latest_Settlement_Date as sap_latest_settlement_date
# MAGIC   --strans.UNIQUE_ID right_uniq
# MAGIC   
# MAGIC   from 
# MAGIC   vw_bexcel_cpdata_sap_master_stg sap_master left join vw_bexcel_cpdata_sap_trans_stg strans on sap_master.UNIQUE_ID=strans.UNIQUE_ID
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Join CP Master table and above table
# MAGIC create or replace temporary view cp_sap_master_trans as 
# MAGIC (
# MAGIC   select *  from 
# MAGIC   vw_cp_master left join sap_master_trans  on cp_sap_unique_id=sap_unique_id
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_escpl_ertrm_cp_sap_final_new as 
# MAGIC (
# MAGIC   select distinct
# MAGIC   csmt.cp_system, --
# MAGIC   csmt.cp_unique_id, --
# MAGIC   csmt.cp_name, --
# MAGIC   csmt.cp_entity_type, --
# MAGIC   csmt.cp_deactivated, --
# MAGIC   csmt.sap_linked_sap_cpty_type,
# MAGIC   csmt.sap_linked_sap_system,
# MAGIC   csmt.cp_sap_unique_id as sap_linked_sap_unique_id, 
# MAGIC   csmt.sap_name,
# MAGIC   csmt.sap_country,
# MAGIC   csmt.sap_region,
# MAGIC   csmt.sap_city,
# MAGIC   csmt.sap_address,
# MAGIC   csmt.sap_postcode,
# MAGIC   ltsd.latest_sap_create_date as sap_create_date,
# MAGIC   csmt.sap_deactivated,
# MAGIC   csmt.sap_block_posting,
# MAGIC   csmt.sap_block_payment,
# MAGIC   ld.sap_company_code,
# MAGIC   csmt.sap_block_purchase,
# MAGIC   ltsd.Latest_Settlement_Date as sap_latest_settlement_date,
# MAGIC   csmt.sap_posting_month,
# MAGIC   csmt.sap_transacted_company_code,
# MAGIC   csmt.sap_settlement_currency,
# MAGIC   csmt.sap_settlement_value_ap_or_ar_lc,
# MAGIC   csmt.cp_sap_link as sap_link,
# MAGIC   csmt.sap_account_no
# MAGIC   --cp_account_number, removed as part of cp_master implementation
# MAGIC   --cp_cpty_type, removed as part of cp_master implementation
# MAGIC   --sap_settlement_activity, removed as part of cp_master implementation
# MAGIC   --sap_settlement_recency removed as part of cp_master implementation
# MAGIC   
# MAGIC   from
# MAGIC   cp_sap_master_trans csmt 
# MAGIC   left join vw_cp_mstr_latest_trade_settlements_dates ltsd on csmt.cp_unique_id=ltsd.cp_unique_id
# MAGIC   left join vw_cp_mstr_latest_dates ld on csmt.cp_unique_id=ld.cp_unique_id
# MAGIC   );

# COMMAND ----------

#per unique id, have one sap link value. one unique id cant have sap link and no sap link values.
#all unique id from financials should be there in sap master. there should be a match.
#if a unique id has sap linked id then sap link is yes, else no, even if it has one link, doesn't need to have sap unique id

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_escpl_ertrm_cp_sap_final_new

# COMMAND ----------

# MAGIC %sql
# MAGIC describe vw_escpl_ertrm_cp_sap_final_new

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'escpl_ertrm_cp_sap_final_new')
