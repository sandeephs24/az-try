# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# DBTITLE 1,Import connections
# MAGIC %run "/BLM/config"

# COMMAND ----------

# DBTITLE 1,Read Tables used in the Joins
#create stg tables into curated db for all tables read
cp_trans_stg_df = spark.read.jdbc(SS_sqldb_URL, table='bexcel.escpl_etrm_cp_trans_stg');
cp_trans_stg_df.createOrReplaceTempView('cp_trans')
cp_trans_stg_df.createOrReplaceTempView('vw_vw_escpl_etrm_cp_trans_stg')
#display(cp_trans_stg_df)

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'vw_escpl_etrm_cp_trans_stg')

# COMMAND ----------

erate_df = spark.read.jdbc(SS_sqldb_URL, table='bexcel.erate_combining_fo_source_eratedate_vw');
erate_df.createOrReplaceTempView('erate')
erate_df.createOrReplaceTempView('vw_vw_erate_combining_fo_source_eratedate')
#display(erate_df)

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'vw_erate_combining_fo_source_eratedate')

# COMMAND ----------

gtmi_crd_df = spark.read.jdbc(Stratos_sqldb_URL, table='pty_counterparty_vw.gt_crd_gtmi_singlecplist');
gtmi_crd_df.createOrReplaceTempView('gtmi_crd')
gtmi_crd_df.createOrReplaceTempView('vw_vw_gt_crd_gtmi_singlecplist')
#display(gtmi_crd_df)

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'vw_gt_crd_gtmi_singlecplist')

# COMMAND ----------

sanctions_df = spark.read.jdbc(SS_sqldb_URL, table='bexcel.erate_sanction_list');
sanctions_df.createOrReplaceTempView('sanctions')
sanctions_df.createOrReplaceTempView('vw_vw_erate_sanction_list')
#display(sanctions_df)

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'vw_erate_sanction_list')

# COMMAND ----------

dndb_df = spark.read.jdbc(SS_sqldb_URL, table='bexcel.erate_dndb_counterparty');
dndb_df.createOrReplaceTempView('dndb')
dndb_df.createOrReplaceTempView('vw_vw_erate_dndb_counterparty')
#display(cp_trans_stg_df)

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'vw_erate_dndb_counterparty')

# COMMAND ----------

# DBTITLE 1,Output One
# MAGIC %sql
# MAGIC --Step 1. Join TRANS OUTPUT BEFORE JOINS and ERATE and filter
# MAGIC create or replace temporary view output_one as 
# MAGIC (
# MAGIC     select 
# MAGIC       `ADDRESS`
# MAGIC       ,`Buy/Sell`
# MAGIC       ,`Contract_Type`
# MAGIC       ,`COUNTRY`
# MAGIC       ,`CP_SHORT_NAME`
# MAGIC       ,`CREATED/UPDATED`
# MAGIC       ,`CREDIT RATING`
# MAGIC       ,`DEACTIVATED`
# MAGIC       ,`Deal Class`
# MAGIC       ,`Discharge Country Code`
# MAGIC --      ,`Discharge Region Code`
# MAGIC       ,`ENTITY_TYPE`
# MAGIC       ,`ETRM_ACCOUNT_NO`
# MAGIC       ,`L2_ID`
# MAGIC       ,`L2_NAME`
# MAGIC       ,`L2_TYPE`
# MAGIC       ,`Latest_Activity_Date_ETRM`
# MAGIC       ,`Latest_Delivery_Date`
# MAGIC       ,`Latest_Trade_Date`
# MAGIC       ,`Latest_Trader_Name`
# MAGIC       ,`Loading Country Code`
# MAGIC --      ,`Loading Region Code`
# MAGIC       ,`NAME`
# MAGIC       ,`Notional Value`
# MAGIC       ,`Notional Volume`
# MAGIC       ,`PARENT`
# MAGIC       ,`Product Grade`
# MAGIC       ,`Product Type`
# MAGIC       ,`Linked SAP Customer ID`
# MAGIC       ,`Linked SAP System`
# MAGIC       ,`Linked SAP Vendor ID`
# MAGIC       ,`SYSTEM`
# MAGIC       ,`Trade_Month`
# MAGIC       ,`Trade_Year`
# MAGIC       ,`Trader Name`
# MAGIC       ,`Trading Desk`
# MAGIC       ,`Trading Entity`
# MAGIC       ,`Trading Entity Long Name`
# MAGIC       ,cp_trans.UNIQUE_ID
# MAGIC       ,`Value_UoM`
# MAGIC       ,`Volume_UoM`
# MAGIC       ,`Min_DELIVERY START DATE`
# MAGIC       ,`SAP_LINK`
# MAGIC       ,`LATEST SETTLEMENT DATE`
# MAGIC       ,`LATEST_SAP CREATE DATE`
# MAGIC       ,`Company Code`
# MAGIC       ,`Latest_Activity_Date`
# MAGIC       ,`Latest_Activity_Flag`
# MAGIC       ,if(system_erate is Null, erate_flag_source, system_erate) as system_erate
# MAGIC       ,erate_date_source
# MAGIC       ,erate_date as eratedate
# MAGIC       ,erating as erate_flag
# MAGIC     from
# MAGIC     cp_trans left join erate on cp_trans.unique_id = erate.unique_id
# MAGIC  );

# COMMAND ----------

# MAGIC %sql
# MAGIC --Step 3. Filter GTMI view
# MAGIC create or replace temporary view gtmi_crd_derived as 
# MAGIC (
# MAGIC   select 
# MAGIC   if(IsNull(gtmi_crd.CLCM_GoldTierID), GoldTier_ID , CLCM_GoldTierID) as GoldTier_ID, --combining columns to create goldtier_id column
# MAGIC        gtmi_crd.CptyID
# MAGIC       ,gtmi_crd.cptygroupid as `Cust Group ID`
# MAGIC       ,gtmi_crd.GoldTier_ID as `Cust GoldTier ID`--
# MAGIC       ,gtmi_crd.Cust_Legal_Name as `Cust Legal Name`--
# MAGIC       ,gtmi_crd.GT_KYC_Policy_Status_Date as `Cust Policy Status Date`--
# MAGIC       ,gtmi_crd.GT_Country_of_Operations as `Cust Country of Operations`--
# MAGIC       ,gtmi_crd.GT_Legal_Country as `Cust Legal Country`--
# MAGIC       ,gtmi_crd.GT_Policy_Last_Review_Date as `Cust Policy Last Review Date`--
# MAGIC       ,gtmi_crd.GT_Policy_Next_Rereview_Date as `Cust Policy Next Review Date`--
# MAGIC       ,gtmi_crd.GT_KYC_Policy_Status as `Cust Policy Status`--or this
# MAGIC       ,gtmi_crd.DD_Level_Approved --
# MAGIC       ,gtmi_crd.KYC_Approved_with_Conditions as `Approved With Conditions (Y/N)`--
# MAGIC       ,gtmi_crd.KYC_Approved_with_Conditions_Remarks as `Approved with condition remarks`--
# MAGIC       ,gtmi_crd.DNDB_Flag as `DNDB List` --
# MAGIC       ,gtmi_crd.GT_KYC_Policy_Approved_Date as `Cust Policy Approved Date`--
# MAGIC       ,gtmi_crd.Cust_Policy_Risk_Level as `Cust Policy Risk Level`--
# MAGIC       ,gtmi_crd.Cust_Create_Date --
# MAGIC       ,gtmi_crd.Due_Diligence_Level as `Cust DD Level`--  
# MAGIC       ,gtmi_crd.KYC_Entity_Type as `GT_Entity_Type`
# MAGIC       ,gtmi_crd.Cust_Create_Date
# MAGIC     from gtmi_crd
# MAGIC     );

# COMMAND ----------

# MAGIC %sql
# MAGIC --Step 3. Filter GTMI view
# MAGIC create or replace temporary view gtmi_crd_filtered as 
# MAGIC (
# MAGIC   select distinct
# MAGIC     gt_crd.*
# MAGIC     ,if(gt_crd.CptyID is null and gt_crd.GoldTier_ID is not Null, concat('GOLDTIER_',cast(gt_crd.GoldTier_ID as string)), CptyID) as uniq_id 
# MAGIC     -- deriving unique id after goldtier_id is derived
# MAGIC     from gtmi_crd_derived gt_crd
# MAGIC     where COALESCE(GoldTier_ID, `Cust Group ID`) is not Null
# MAGIC     );

# COMMAND ----------

# MAGIC %sql
# MAGIC --To derive dndb flag
# MAGIC create or replace temporary view gtmi_dndb as 
# MAGIC (
# MAGIC   select distinct legal_name, GoldTier_ID as gt_id
# MAGIC   from
# MAGIC   dndb left join gtmi_crd_derived on lower(trim(dndb.legal_name)) = lower(trim(gtmi_crd_derived.`Cust Legal Name`))
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC   select *
# MAGIC   from gtmi_dndb where gt_id is null

# COMMAND ----------

# DBTITLE 1,Output Two
# MAGIC %sql
# MAGIC --Step 4. Join Output One and GTMI view
# MAGIC create or replace temporary view output_two as 
# MAGIC (
# MAGIC   select 
# MAGIC         if(one.unique_id is Null, gt_crd.uniq_id, one.unique_id) as unique_id
# MAGIC       ,`ADDRESS`
# MAGIC       ,`Buy/Sell`
# MAGIC       ,`Contract_Type`
# MAGIC       ,`COUNTRY`
# MAGIC       ,`CP_SHORT_NAME`
# MAGIC       ,`CREATED/UPDATED`
# MAGIC       ,`CREDIT RATING`
# MAGIC       ,`DEACTIVATED`
# MAGIC       ,`Deal Class`
# MAGIC       ,`Discharge Country Code`
# MAGIC --      ,`Discharge Region Code`
# MAGIC       ,`ENTITY_TYPE`
# MAGIC       ,`ETRM_ACCOUNT_NO`
# MAGIC       ,`L2_ID`
# MAGIC       ,`L2_NAME`
# MAGIC       ,`L2_TYPE`
# MAGIC       ,`Latest_Activity_Date_ETRM`
# MAGIC       ,`Latest_Delivery_Date`
# MAGIC       ,`Latest_Trade_Date`
# MAGIC       ,`Latest_Trader_Name`
# MAGIC       ,`Loading Country Code`
# MAGIC --      ,`Loading Region Code`
# MAGIC       ,`NAME`
# MAGIC       ,`Notional Value`
# MAGIC       ,`Notional Volume`
# MAGIC       ,`PARENT`
# MAGIC       ,`Product Grade`
# MAGIC       ,`Product Type`
# MAGIC       ,`Linked SAP Customer ID`
# MAGIC       ,`Linked SAP System`
# MAGIC       ,`Linked SAP Vendor ID`
# MAGIC       , if(upper(gt_crd.uniq_id) like '%GOLDTIER%', 'GOLDTIER', one.SYSTEM) as cp_system
# MAGIC       ,`Trade_Month`
# MAGIC       ,`Trade_Year`
# MAGIC       ,`Trader Name`
# MAGIC       ,`Trading Desk`
# MAGIC       ,`Trading Entity`
# MAGIC       ,`Trading Entity Long Name`
# MAGIC       ,`Value_UoM`
# MAGIC       ,`Volume_UoM`
# MAGIC       ,`Min_DELIVERY START DATE`
# MAGIC       ,`SAP_LINK`
# MAGIC       ,`LATEST SETTLEMENT DATE`
# MAGIC       ,`LATEST_SAP CREATE DATE`
# MAGIC       ,`Company Code`
# MAGIC       ,`Latest_Activity_Date`
# MAGIC       ,`Latest_Activity_Flag`
# MAGIC       ,system_erate
# MAGIC       ,erate_date_source
# MAGIC       ,eratedate
# MAGIC       ,erate_flag
# MAGIC       ,gt_crd.GoldTier_ID
# MAGIC       ,gt_crd.`Cust Group ID`
# MAGIC       ,gt_crd.`Cust GoldTier ID`--
# MAGIC       ,gt_crd.`Cust Legal Name`--
# MAGIC       ,gt_crd.`Cust Policy Status Date`--
# MAGIC       ,gt_crd.`Cust Country of Operations`--
# MAGIC       ,gt_crd.`Cust Legal Country`--
# MAGIC       ,gt_crd.`Cust Policy Last Review Date`--
# MAGIC       ,gt_crd.`Cust Policy Next Review Date`--
# MAGIC       ,gt_crd.`Cust Policy Status`--
# MAGIC       ,gt_crd.DD_Level_Approved `DD Level Approved`--
# MAGIC       ,gt_crd.`Approved With Conditions (Y/N)`--
# MAGIC       ,gt_crd.`Approved with condition remarks`--
# MAGIC       ,gt_crd.`DNDB List` --
# MAGIC       ,gt_crd.`Cust Policy Approved Date`--
# MAGIC       ,gt_crd.`Cust Policy Risk Level`--
# MAGIC       ,gt_crd.Cust_Create_Date --
# MAGIC       ,gt_crd.`Cust DD Level` -- 
# MAGIC       ,gt_crd.`GT_Entity_Type`
# MAGIC       ,gt_crd.Cust_Create_Date
# MAGIC       from
# MAGIC       output_one one Full Outer Join gtmi_crd_filtered gt_crd on one.unique_id = gt_crd.uniq_id
# MAGIC )

# COMMAND ----------

# DBTITLE 1,Output Three
# MAGIC %sql
# MAGIC --Step 5. Join Output Two and Sanctions
# MAGIC create or replace temporary view output_three as 
# MAGIC (
# MAGIC   select two.*, 
# MAGIC   sanctions.sanctions_type,
# MAGIC   sanctions.entity_type as `sanctions_entity_type`,
# MAGIC   sanctions.policy_status as `sanctions_policy_status` 
# MAGIC   from
# MAGIC   output_two two left Join sanctions on two.GoldTier_ID = sanctions.goldTier_id
# MAGIC )

# COMMAND ----------

# DBTITLE 1,CP_Trans_Final
# MAGIC %sql
# MAGIC --Step 6. Filters after join and rename columns 
# MAGIC create or replace temporary view vw_escpl_ertrm_cp_final as 
# MAGIC (
# MAGIC   select 
# MAGIC         cp_system
# MAGIC       ,`ADDRESS` cp_address
# MAGIC       ,`Buy/Sell` deal_buy_sell
# MAGIC       ,`Contract_Type` deal_contract_type
# MAGIC       ,`COUNTRY` cp_country
# MAGIC       ,`CP_SHORT_NAME` cp_short_name
# MAGIC       ,`CREATED/UPDATED` cp_created_or_updated_date
# MAGIC       ,`CREDIT RATING` cp_credit_rating
# MAGIC       ,`DEACTIVATED` cp_deactivated
# MAGIC       ,`Deal Class` deal_class
# MAGIC       ,`Discharge Country Code` deal_discharge_location_code
# MAGIC --      ,`Discharge Region Code` deal_discharge_region_code
# MAGIC       ,`ENTITY_TYPE` cp_entity_type
# MAGIC       ,`ETRM_ACCOUNT_NO` cp_etrm_account_no
# MAGIC       ,`L2_ID` cp_l2_id
# MAGIC       ,`L2_NAME` cp_l2_name
# MAGIC       ,`L2_TYPE` cp_l2_type
# MAGIC       ,`Latest_Activity_Date_ETRM` deal_latest_activity_date_etrm
# MAGIC       ,`Latest_Delivery_Date` deal_latest_delivery_date
# MAGIC       ,`Latest_Trade_Date` deal_latest_trade_date
# MAGIC       ,`Latest_Trader_Name` deal_latest_trader_name
# MAGIC       ,`Loading Country Code` deal_loading_location_code
# MAGIC --      ,`Loading Region Code` deal_loading_region_code
# MAGIC       ,`NAME` cp_name
# MAGIC       ,`Notional Value` deal_notional_value
# MAGIC       ,`Notional Volume` deal_notional_volume
# MAGIC       ,`PARENT` cp_parent
# MAGIC       ,`Product Grade` deal_product_grade
# MAGIC       ,`Product Type` deal_product_type
# MAGIC       ,`Linked SAP Customer ID` cp_linked_sap_customer_id
# MAGIC       ,`Linked SAP System` cp_linked_sap_system
# MAGIC       ,`Linked SAP Vendor ID` cp_linked_sap_vendor_id
# MAGIC       ,`Trade_Month` deal_trade_month
# MAGIC       ,`Trade_Year` deal_trade_year
# MAGIC       ,`Trader Name` deal_trader_name
# MAGIC       ,`Trading Desk` deal_trading_desk
# MAGIC       ,`Trading Entity` deal_trading_entity
# MAGIC       ,`Trading Entity Long Name` deal_trading_entity_long_name
# MAGIC       ,`UNIQUE_ID` cp_unique_id
# MAGIC       ,`Value_UoM` cp_value_unit_of_measure
# MAGIC       ,`Volume_UoM` cp_volume_unit_of_measure
# MAGIC       ,`SAP_LINK` cp_sap_link
# MAGIC       ,`LATEST SETTLEMENT DATE` sap_latest_settlement_date
# MAGIC       ,`LATEST_SAP CREATE DATE` sap_cp_create_date
# MAGIC       ,`Latest_Activity_Date` deal_latest_activity_date
# MAGIC       ,`Latest_Activity_Flag` deal_latest_activity_flag
# MAGIC       ,`System_Erate` cp_erate_flag_in_source
# MAGIC       ,erate_date_source cp_erate_date_in_source
# MAGIC       ,`eratedate` cp_erate_date
# MAGIC       ,`ERate_Flag` cp_erate_flag
# MAGIC       ,`GoldTier_ID` gt_goldtier_id
# MAGIC       ,`Cust Group ID` clcm_cust_group_id
# MAGIC       ,`Cust Legal Name` gt_cust_legal_name
# MAGIC       ,`Cust Policy Status Date` gt_cust_policy_status_date
# MAGIC       ,`Cust Country of Operations` gt_cust_country_of_operations
# MAGIC       ,`Cust Legal Country` gt_cust_legal_country
# MAGIC       ,`Cust Policy Last Review Date` gt_cust_policy_last_review_date
# MAGIC       ,`Cust Policy Next Review Date` gt_cust_policy_next_review_date
# MAGIC       ,`Cust Policy Status` gt_cust_policy_status
# MAGIC       ,`DD Level Approved` gt_dd_level_approved
# MAGIC       ,`Cust DD Level` gt_cust_dd_level
# MAGIC       ,`GT_Entity_Type` gt_entity_type --and this can be combined
# MAGIC       ,`Approved With Conditions (Y/N)` gt_approved_with_conditions_flag
# MAGIC       ,`Approved with condition remarks` gt_approved_with_conditions_remarks
# MAGIC       ,`DNDB List` gt_dndb_list
# MAGIC       , if() as cp_dndb_flag
# MAGIC --      , dndb.legal_name dndb_legal_name
# MAGIC       ,`Cust Policy Approved Date` gt_cust_policy_approved_date
# MAGIC       ,`Cust Policy Risk Level` gt_cust_policy_risk_level
# MAGIC       ,`Cust_Create_Date` gt_cust_create_date
# MAGIC       ,`sanctions_entity_type` cp_sanctions_entity_type --this
# MAGIC       ,`sanctions_policy_status` cp_sanctions_policy_status
# MAGIC       ,if (output_three.sanctions_type is Null, 'None', sanctions_type) as cp_sanctions_type
# MAGIC   from
# MAGIC   output_three left join gtmi_dndb on 
# MAGIC   where output_three.cp_system is not Null
# MAGIC )

# COMMAND ----------

df = spark.sql("select * from vw_escpl_ertrm_cp_final")

# COMMAND ----------

df.count()

# COMMAND ----------

display(df)

# COMMAND ----------

#connectionProperties = {
#  "user" : jdbcUsername,
#  "password" : jdbcPassword,
#  "driver" : "com.mysql.jdbc.Driver"
#}
#df.write.jdbc(Stratos_sqldb_URL_curated, "pty_counterparty.escpl_ertrm_cp_final_triall")

# COMMAND ----------

# DBTITLE 1,Write to Curated Table
#RefreshCuratedSqlTbl('pty_counterparty', 'escpl_ertrm_cp_final')
