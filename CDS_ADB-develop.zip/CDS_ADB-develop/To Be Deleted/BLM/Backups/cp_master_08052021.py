# Databricks notebook source
# MAGIC %run "/CP_Data/Shared/config/config"

# COMMAND ----------

# DBTITLE 1,create temp views self Service Tables
schema_name= 'bexcel'
selfservice_tables_list  = ['cpdata_cp_master_stg', 'cpdata_cp_trans_stg', 'cpdata_sap_master_stg', 'cpdata_sap_trans_stg', 'erate_fo_data', 'erate_activity_cpty_dex']

for table_name in selfservice_tables_list:
        df = spark.read.jdbc(SS_sqldb_URL, table=f'bexcel.{table_name}')
        df.createOrReplaceTempView(f"vw_{schema_name}_{table_name}")
        df.createOrReplaceTempView(f'vw_{table_name}')
#         print(f"--- {table_name} load started -----")
#         RefreshCuratedSqlTbl('pty_counterparty', f'{table_name}')
#         print(f"--- {table_name} load completed -----")
#         print(f"-------------------------------------")

# COMMAND ----------

# DBTITLE 1,create temp views for curated sql tables
curated_schema_name= 'pty_counterparty' # read from curated tables
curated_tables_list  = ['cp_master']
for table_name in curated_tables_list:
        df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
        df.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")
#         RefreshCuratedSqlTbl('pty_counterparty', f'{table_name}')

# COMMAND ----------

# DBTITLE 1,cp_master ( union cp_master_stg and cpdata_master_stg)
# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master as 
# MAGIC select  
# MAGIC      cpm.cp_unique_id
# MAGIC     ,cpm.cp_l1_id
# MAGIC     ,cpm.cp_name
# MAGIC     ,cpm.cp_etrm_account_no
# MAGIC     ,cpm.cp_l2_id
# MAGIC     ,cpm.cp_l2_name
# MAGIC     ,cpm.cp_short_name   -- 06/29/2021  added cp_short_name to cp_master
# MAGIC     ,cpm.cp_entity_type
# MAGIC     ,cpm.cp_created_or_updated_date
# MAGIC     ,cpm.cp_deactivated
# MAGIC     ,cpm.cp_country
# MAGIC     ,cpm.cp_parent
# MAGIC     ,cpm.cp_system
# MAGIC     ,cpm.cp_linked_sap_id
# MAGIC     ,upper(cpm.cp_sap_account_type) as cp_sap_account_type
# MAGIC     ,cpm.cp_sap_unique_id
# MAGIC     ,qry.cp_linked_sap_system
# MAGIC     ,qry.cp_sap_link
# MAGIC     ,cpm.cp_erate_flag_in_source
# MAGIC     ,cpm.cp_erate_date_in_source
# MAGIC     --,cpm.cp_erate_lifted_date_in_source not needed any more 
# MAGIC     ,cpm.cp_broker_indicator
# MAGIC     ,cpm.cp_mapping_id
# MAGIC     ,cpm.source_system
# MAGIC     ,cpm.meta_created_dttm
# MAGIC  from vw_pty_counterparty_cp_master cpm
# MAGIC  left join ( select cp_unique_id 
# MAGIC                     ,concat_ws(',',collect_set(cp_linked_sap_system)) as cp_linked_sap_system
# MAGIC                     ,case when size(collect_list(cp_sap_unique_id)) > 0 then 'SAP LINK' else 'NO SAP LINK' end cp_sap_link
# MAGIC             from vw_pty_counterparty_cp_master
# MAGIC             group by cp_unique_id
# MAGIC             ) qry on cpm.cp_unique_id = qry.cp_unique_id
# MAGIC  where cpm.cp_system in ('ENDNA_GP', 'SLMT' ,'NUCLEUS', 'DEX', 'ALIGNE', 'ENDNA_CRUDE', 'ENDNA_PROD', 'IMOS','GMAS','RADAR' )
# MAGIC union all 
# MAGIC select 
# MAGIC    cpms.unique_id            as cp_unique_id
# MAGIC   ,cpms.l1_id                as cp_l1_id
# MAGIC   ,cpms.name                 as cp_name
# MAGIC   ,cpms.etrm_account_no      as cp_etrm_account_no
# MAGIC   ,cpms.l2_id                as cp_l2_id
# MAGIC   ,cpms.l2_name              as cp_l2_name
# MAGIC   ,cast(null as string)      as cp_short_name    -- 06/29/2021  added cp_short_name to cp_master
# MAGIC   ,cpms.entity_type          as cp_entity_type
# MAGIC   ,cpms.`CREATED/UPDATED`    as cp_created_or_updated_date
# MAGIC   ,cpms.DEACTIVATED          as cp_deactivated
# MAGIC   ,cpms.country              as cp_country
# MAGIC   ,cpms.parent               as cp_parent
# MAGIC   ,cpms.system               as cp_system
# MAGIC   ,cast(null as string)      as cp_linked_sap_id
# MAGIC   ,upper(cpms.sap_cpty_type)  as cp_sap_account_type
# MAGIC   ,case when cpms.sap_account_no is not null then concat(cpms.sap_system, '_',initcap(cpms.sap_cpty_type),'_',cpms.sap_account_no)
# MAGIC         else cast(null as string) 
# MAGIC    end  cp_sap_unique_id
# MAGIC   ,cpms.SAP_SYSTEM           as cp_linked_sap_system
# MAGIC   ,qry.cp_sap_link           as cp_sap_link
# MAGIC   ,cpms.System_Erate         as cp_erate_flag_in_source
# MAGIC   ,cast(null as string)      as cp_erate_date_in_source  -- as the self-service column is been removed in May 2021
# MAGIC   ,cast(null as string)      as cp_broker_indicator
# MAGIC   ,cpms.Mapping_ID           as cp_mapping_id
# MAGIC   ,cpms.system               as source_system
# MAGIC   ,current_date              as meta_created_dttm
# MAGIC from vw_bexcel_cpdata_cp_master_stg  cpms
# MAGIC  left join ( select unique_id 
# MAGIC                     ,concat_ws(',',collect_set(SAP_SYSTEM)) as cp_linked_sap_system
# MAGIC                     ,case when size(collect_list(SAP_SYSTEM)) > 0 then 'SAP LINK' else 'NO SAP LINK' end cp_sap_link
# MAGIC             from vw_bexcel_cpdata_cp_master_stg
# MAGIC             group by unique_id
# MAGIC             ) qry on cpms.unique_id = qry.unique_id
# MAGIC 
# MAGIC where SYSTEM  not in ('ENDNA_GP', 'SLMT' ,'NUCLEUS', 'DEX', 'ALIGNE', 'ENDNA_CRUDE', 'ENDNA_PROD', 'IMOS','GMAS','RADAR')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_mstr_latest_trade_settlements_dates as
# MAGIC -- calculate latest_settlement_date, latest_create_date from sap 
# MAGIC --latest_delivery_date , latest_trade_date from cp trans
# MAGIC   
# MAGIC SELECT 
# MAGIC       cpm.cp_UNIQUE_ID
# MAGIC      ,max(to_date(sm.`sap create date`))       as   latest_sap_create_date
# MAGIC      ,max(to_date(st.Latest_Settlement_Date))  as   Latest_Settlement_Date
# MAGIC      ,max(to_date(cpt.Latest_Trade_Date))      as   Latest_Trade_Date
# MAGIC      ,max(to_date(cpt.Latest_Delivery_Date))   as   Latest_Delivery_Date
# MAGIC      ,collect_set(sm.`SAP COMPANY CODE`)       as   sap_company_code_arry
# MAGIC FROM   vw_cp_master cpm 
# MAGIC left join vw_bexcel_cpdata_sap_master_stg sm on cpm.cp_sap_unique_id = sm.unique_id
# MAGIC left join vw_bexcel_cpdata_sap_trans_stg  st on cpm.cp_sap_unique_id = st.unique_id
# MAGIC left join vw_bexcel_cpdata_cp_trans_stg   cpt on upper(trim(cpm.cp_system)) = upper(trim(cpt.system)) and upper(trim(cpm.cp_mapping_id)) = upper(cpt.Mapping_ID)
# MAGIC group by cpm.cp_UNIQUE_ID

# COMMAND ----------

# MAGIC %sql 
# MAGIC create or replace temporary view vw_cp_mstr_latest_dates as
# MAGIC select * 
# MAGIC        ,greatest(Latest_Settlement_Date,Latest_Trade_Date,Latest_Delivery_Date) as Latest_Activity_Date
# MAGIC        ,concat_ws(',', sap_company_code_arry) as sap_company_code
# MAGIC        
# MAGIC  from vw_cp_mstr_latest_trade_settlements_dates

# COMMAND ----------

# df_sap_comp_code = spark.sql("select  cp_unique_id, explode(split(sap_company_code, ',')) as sap_company_code from vw_cp_mstr_latest_dates ")
# df_sap_comp_code = df_sap_comp_code.groupby("cp_unique_id").agg(sort_array(collect_set(col("sap_company_code"))).alias("sap_company_code"))
# df_sap_comp_code.createOrReplaceTempView("vw_cp_mstr_sap_company_code_arry")

# COMMAND ----------

# MAGIC %sql 
# MAGIC create or replace temporary view vw_cp_mstr_sap_company_code as
# MAGIC   select cp_unique_id, concat_ws(',',collect_set(sap_company_code))   as sap_company_code 
# MAGIC    from (
# MAGIC          select  cp_unique_id, explode(split(sap_company_code, ',')) as sap_company_code from vw_cp_mstr_latest_dates
# MAGIC         ) qry
# MAGIC group by cp_unique_id
# MAGIC  --group by cp_unique_id

# COMMAND ----------

# MAGIC %sql 
# MAGIC create or replace temporary view vw_cp_mstr_latest_dates_with_flag as
# MAGIC select cpm.cp_unique_id
# MAGIC     , cpm.latest_sap_create_date
# MAGIC     , cpm.Latest_Settlement_Date
# MAGIC     , cpm.Latest_Trade_Date
# MAGIC     , cpm.Latest_Delivery_Date
# MAGIC     , cpm.Latest_Activity_Date
# MAGIC     , trunc( cpm.Latest_Activity_Date,'month') 
# MAGIC     , add_months(trunc( cpm.Latest_Activity_Date,'month'), -12) as latestActivity_Prior12Months 
# MAGIC     , add_months(trunc( cpm.Latest_Activity_Date,'month'), -24) as latestActivity_Prior24Months 
# MAGIC     , case when trunc( cpm.Latest_Activity_Date,'month') >= add_months(trunc(current_date,'month'), -12) then 'Active 12Months'
# MAGIC            when trunc( cpm.Latest_Activity_Date,'month') >= add_months(trunc(current_date,'month'), -24) then 'Active 24Months'
# MAGIC            else 'No Activity'
# MAGIC       end Latest_Activity_Flag
# MAGIC     ,sap_code.sap_company_code as sap_company_code
# MAGIC   from vw_cp_mstr_latest_dates cpm
# MAGIC   left join vw_cp_mstr_sap_company_code sap_code on cpm.cp_unique_id = sap_code.cp_unique_id
# MAGIC -- where cp_unique_id like '%ENDNA_GP%'
# MAGIC --and trunc(Latest_Activity_Date,'month') >= add_months(trunc(current_date,'month'), -24)

# COMMAND ----------

from pyspark.sql.functions import col, concat_ws
# get the list agg for customer and vendor of cp_sap_unique_id
# list_agg using collect-set , and split to get the 3rd element of the customer
CpUniqueID_SapUniqueID_df = spark.sql("""select distinct cp_unique_id, cp_sap_account_type, collect_set(cp_linked_sap_system) as cp_linked_sap_system, 
                                       collect_set(split(cp_sap_unique_id, '_')[2]) as cp_sap_unique_id from vw_cp_master group by cp_unique_id, cp_sap_account_type
                                       order by cp_unique_id, cp_sap_account_type, cp_linked_sap_system
                                     """)
CpUniqueID_SapUniqueID_df = CpUniqueID_SapUniqueID_df["cp_unique_id","cp_sap_account_type", "cp_sap_unique_id", "cp_linked_sap_system"].drop_duplicates()

#convert from string array to string 
CpUniqueID_SapUniqueID_df = CpUniqueID_SapUniqueID_df.withColumn("cp_sap_unique_id_new", concat_ws(",", col("cp_sap_unique_id")))   # change it to string using concat_ws
CpUniqueID_SapUniqueID_df = CpUniqueID_SapUniqueID_df.withColumn("cp_linked_sap_system_new", concat_ws(",", col("cp_linked_sap_system")))   # change it to string using concat_ws
CpUniqueID_SapUniqueID_df = CpUniqueID_SapUniqueID_df["cp_unique_id", "cp_sap_account_type", "cp_sap_unique_id_new", "cp_linked_sap_system_new"]
CpUniqueID_SapUniqueID_df = CpUniqueID_SapUniqueID_df["cp_unique_id", "cp_sap_account_type", "cp_sap_unique_id_new", "cp_linked_sap_system_new"].withColumnRenamed("cp_linked_sap_system_new", "cp_linked_sap_system")

# display(CpUniqueID_SapUniqueID_df)

#create customer df and rename the cp_sap_unique_id_new to cp_sap_customer_id
cpUniqueID_Customer_df = CpUniqueID_SapUniqueID_df["cp_unique_id","cp_sap_unique_id_new","cp_sap_account_type", "cp_linked_sap_system"].filter('cp_sap_account_type=="CUSTOMER"')
cpUniqueID_Customer_df = cpUniqueID_Customer_df["cp_unique_id","cp_sap_unique_id_new", "cp_linked_sap_system"].withColumnRenamed("cp_sap_unique_id_new","cp_sap_customer_id")\
                                               .createOrReplaceTempView("vw_cp_master_customer")

# #create vendor df and rename the cp_sap_unique_id_new to cp_sap_vendor_id
cpUniqueID_Vendor_df =  CpUniqueID_SapUniqueID_df["cp_unique_id","cp_sap_unique_id_new","cp_sap_account_type", "cp_linked_sap_system"].filter('cp_sap_account_type=="VENDOR"')
cpUniqueID_Vendor_df = cpUniqueID_Vendor_df["cp_unique_id","cp_sap_unique_id_new","cp_linked_sap_system"].withColumnRenamed("cp_sap_unique_id_new","cp_sap_vendor_id")\
                                               .createOrReplaceTempView("vw_cp_master_vendor")



cpUniqueID_SapSystem_df = spark.sql("select  distinct cp_unique_id , collect_set(cp_linked_sap_system)  as cp_linked_sap_system from vw_cp_master group by cp_unique_id")
#convert from string array to string 
cpUniqueID_SapSystem_df = cpUniqueID_SapSystem_df.withColumn("cp_linked_sap_system_new", concat_ws(",", col("cp_linked_sap_system")))   # change it to string using concat_ws
cpUniqueID_SapSystem_df = cpUniqueID_SapSystem_df.drop_duplicates()
cpUniqueID_SapSystem_df = cpUniqueID_SapSystem_df["cp_unique_id" , "cp_linked_sap_system_new"].withColumnRenamed("cp_linked_sap_system_new", "cp_linked_sap_system")\
                                                 .createOrReplaceTempView("vw_cp_master_sap_system")



# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_unique
# MAGIC as 
# MAGIC select distinct 
# MAGIC    cpm.cp_system
# MAGIC   ,cpm.cp_unique_id
# MAGIC   ,cpm.cp_country
# MAGIC   ,cpm.cp_created_or_updated_date
# MAGIC   ,cpm.cp_deactivated
# MAGIC   ,cpm.cp_entity_type
# MAGIC   ,cpm.cp_etrm_account_no
# MAGIC   ,cpm.cp_l2_id
# MAGIC   ,cpm.cp_l2_name
# MAGIC   ,cpm.cp_short_name       -- 06/29/2021  added cp_short_name to cp_master
# MAGIC   ,cpm.cp_name
# MAGIC   ,cpm.cp_parent
# MAGIC   ,cpss.cp_linked_sap_system
# MAGIC   ,cpm.cp_system
# MAGIC   ,cpm.cp_sap_link
# MAGIC   ,cpm.cp_erate_flag_in_source
# MAGIC   ,cpm.cp_mapping_id
# MAGIC   ,cpm.SOURCE_SYSTEM
# MAGIC   ,cpm.meta_created_dttm
# MAGIC   ,cpm.cp_l1_id   -- added this column in cp_master will be populated in the escpl_ertrm_cp_final ( PBI # 815943)
# MAGIC from       vw_cp_master                      cpm
# MAGIC left join  vw_cp_master_sap_system           cpss   on upper(trim(cpm.cp_unique_id)) = upper(trim(cpss.cp_unique_id))
# MAGIC --where cpm.cp_unique_id = 'RADAR_46917_1'

# COMMAND ----------

# DBTITLE 1,erate fo salesforce data  format dates
# MAGIC %sql
# MAGIC create or replace temporary view vw_bexcel_erate_fo_data_new as 
# MAGIC select *, TO_DATE(CAST(UNIX_TIMESTAMP(fo.e_rate_completion_date, 'yyyy/MM/dd') AS TIMESTAMP)) as e_rate_completion_date_cal from vw_bexcel_erate_fo_data fo
# MAGIC where system not in ('SLMT', 'IMOS')

# COMMAND ----------

# DBTITLE 1,DEX data from erate activity file
# MAGIC %sql
# MAGIC create or replace temporary view vw_bexcel_erate_dex as 
# MAGIC select distinct 'DEX' as source_system
# MAGIC    , case when length(trim(company_name))> 0 and length(trim(unique_id))> 0 then 
# MAGIC           concat('DEX_',upper(trim(company_name)),'_',upper(trim(cast(cast(unique_id as decimal) as varchar(200)))))
# MAGIC           --concat('DEX_',upper(trim(party_id))) - include this while comparing
# MAGIC       end unique_id
# MAGIC    , case when length(trim(party_name)) > 0  then concat('DEX_',trim(party_name),'_') end unique_id2
# MAGIC    ,cast(appr_date as date ) as erate_date_source
# MAGIC     from vw_bexcel_erate_activity_cpty_dex
# MAGIC     where approved_status in ('E', 'P')

# COMMAND ----------

# DBTITLE 1,erate Logic -- New 06012021
# MAGIC %sql 
# MAGIC create or replace temporary view erate  as  
# MAGIC select distinct 
# MAGIC        cpm.cp_system
# MAGIC       ,cpm.cp_unique_id as unique_id
# MAGIC       ,case when cpm.cp_system = 'GMAS' then cast(null as string)
# MAGIC             when cpm.cp_system = 'DEX'  and  (dex_qry.erate_date_source is not null or fo.e_rated = 'Y') then 'Y' 
# MAGIC             when cpm.cp_system in ('IMOS','SLMT')  and cpm.cp_erate_flag_in_source  = 'Y'                then 'Y' -- changed on 6/9/2021
# MAGIC             when cpm.cp_system not in ('GMAS','DEX' ,'IMOS','SLMT') and  fo.e_rated = 'Y'                then 'Y' -- changed on 6/9/2021
# MAGIC             else 'N'
# MAGIC         END erating
# MAGIC         
# MAGIC       ,case  when cpm.cp_system = 'GMAS' then null
# MAGIC              when cpm.cp_system =  'DEX' and  dex_qry.erate_date_source     is not null                                         then dex_qry.erate_date_source
# MAGIC              when cpm.cp_system =  'DEX' and  fo.e_rate_completion_date_cal is not null and  dex_qry.erate_date_source is null  then fo.e_rate_completion_date_cal
# MAGIC              when cpm.cp_system in ('IMOS','SLMT') and cpm.cp_erate_flag_in_source is not null                                  then cpm.cp_erate_date_in_source
# MAGIC              when cpm.cp_system in ('RADAR')       and  cpm.cp_erate_flag_in_source  = 'Y'                                      then fo.e_rate_completion_date_cal-- 6/9/2021 change eratedate to src
# MAGIC              when cpm.cp_system not in ('GMAS','DEX' ,'IMOS', 'SLMT') and  fo.e_rated = 'Y'                                     then fo.e_rate_completion_date_cal
# MAGIC              else null 
# MAGIC         end erate_date
# MAGIC         
# MAGIC       ,case when cpm.cp_system = 'DEX' then to_date(dex_qry.erate_date_source) 
# MAGIC             else to_date(cpm.cp_erate_date_in_source) 
# MAGIC             end  erate_date_source
# MAGIC       ,case when dex_qry.erate_date_source is not null then 'Y'
# MAGIC             when dex_qry.erate_date_source is null then 'N'
# MAGIC        end erate_flag_source
# MAGIC       ,to_date(fo.e_rate_completion_date_cal) as erate_date_salesforce
# MAGIC from      vw_cp_master cpm
# MAGIC left join vw_bexcel_erate_dex as dex_qry on upper(trim(cpm.cp_unique_id)) = dex_qry.unique_id or upper(trim(cpm.cp_unique_id)) = dex_qry.unique_id2
# MAGIC left join vw_bexcel_erate_fo_data_new fo on upper(trim(cpm.cp_unique_id)) = upper(trim(fo.unique_id))   
