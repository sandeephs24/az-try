# Databricks notebook source
from pyspark.sql.functions import *
import pyodbc
import pandas as pd

# COMMAND ----------

# MAGIC %run "/CP_Data/Shared/config/config"

# COMMAND ----------

# MAGIC %run "/CP_Data_DataSets/Common/dataset_library"

# COMMAND ----------

sqlString = '''
select a.*,
case when a.value = 'adls' and c.old_new_adls_path_indicator = 'OLD' 
then concat(old_adls_full_path,',',adls_file_format)
when a.value = 'adls' and c.old_new_adls_path_indicator = 'NEW' 
then concat(new_adls_full_path,',',adls_file_format)
else a.value end as expression
 from [cp_data].[cp_data_refresh_audit_log_logic] a 
join [cp_data].[cp_data_refresh_audit_log_master] b 
on a.system_refresh_id = b.system_refresh_id
join (select *, Row_number() over (partition by source_system order by src_table_name) rn
from [cp_data].[config_adls_paths] where active_flag = 1 and (old_adls_full_path is not null or new_adls_full_path is not null)) c 
on b.system_code = c.source_system where rn = 1
and a.is_active = 1
'''

df_logic = spark.read.format("jdbc").option("url",Stratos_sqldb_URL_curated).option("query",sqlString).load()
display(df_logic)

# COMMAND ----------

def getValue_sql(x):
  if not x:
    return pd.Timestamp(None)
  else:
    df = spark.read.format("jdbc").option("url",Stratos_sqldb_URL_curated).option("query",x).load()
    return df.agg({"mDate": "max"}).collect()[0][0]

# COMMAND ----------

def getValue_adls(x):
  if not x:
    return pd.Timestamp(None)
  else:
    k= x.split(',')
    print(k[0],k[1])
    df = spark.read.format(k[1]).load(k[0]).filter(col("IS_RECORD_ACTIVE") == 1)
    return df.agg({"meta_created_dttm": "max"}).collect()[0][0]
  

# COMMAND ----------

df_logic_pd = df_logic.toPandas()
df_logic_pd['SQL_Output'] = df_logic_pd.apply(lambda row : getValue_adls(row['expression']) if row['value'] == 'adls' else getValue_sql(row['expression']), axis=1)
output_df = spark.createDataFrame(df_logic_pd)
df =output_df.select(col('system_refresh_id'),col('id').alias('column_id'),col('SQL_Output').alias('value'),lit(current_timestamp().alias('meta_created_dttm')))

# COMMAND ----------

display(df)

# COMMAND ----------

try:
  conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                                    'SERVER='+dbServer_curated+';'
                                    'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
                                    'PWD='+dbPass
                                    )
  cursor = conn.cursor()
  #execSQL = f"truncate table cp_data.cp_data_refresh_audit_log_stg"
  conn.autocommit = True
  #cursor.execute(execSQL)
  
  df.write.jdbc(Stratos_sqldb_URL_curated, f"cp_data.cp_data_refresh_audit_log_stg", "overwrite")
  execSQL = f"exec cp_data.update_audit_refresh_log"
  cursor.execute(execSQL)
     
except Exception as e:
  print('Exception raised')
  raise dbutils.notebook.exit(e)
            
