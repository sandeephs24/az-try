# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# DBTITLE 1,Import connections
# MAGIC %run "/BLM/config"

# COMMAND ----------

# DBTITLE 1,Read Tables used in the Joins
sap_trans_stg_df = spark.read.jdbc(SS_sqldb_URL, table='bexcel.escpl_sap_cp_trans_stg');
sap_trans_stg_df.createOrReplaceTempView('sap_trans')
#display(sap_trans_stg_df)

# COMMAND ----------

sap_trans_stg_df.printSchema()

# COMMAND ----------

# DBTITLE 1,SAP_Trans_Final
# MAGIC %sql
# MAGIC create or replace temporary view vw_escpl_ertrm_cp_sap_final as 
# MAGIC (
# MAGIC   select 
# MAGIC       SYSTEM cp_system
# MAGIC ,`UNIQUE_ID` cp_unique_id
# MAGIC ,`NAME` cp_name
# MAGIC ,`ENTITY_TYPE` cp_entity_type
# MAGIC ,`DEACTIVATED` cp_deactivated
# MAGIC ,`LINKED SAP CPTY TYPE` sap_linked_sap_cpty_type
# MAGIC ,`LINKED SAP SYSTEM` sap_linked_sap_system
# MAGIC ,`LINKED SAP UNIQUE ID` sap_linked_sap_unique_id
# MAGIC ,`SAP NAME` sap_name
# MAGIC ,`SAP COUNTRY` sap_country
# MAGIC ,`SAP REGION` sap_region
# MAGIC ,`SAP CITY` sap_city
# MAGIC ,`SAP ADDRESS` sap_address
# MAGIC ,`SAP POSTCODE` sap_postcode
# MAGIC ,`SAP CREATE DATE` sap_create_date
# MAGIC ,`SAP DEACTIVATED` sap_deactivated
# MAGIC ,`BLOCK_POSTING` sap_block_posting
# MAGIC ,`BLOCK_PAYMENT` sap_block_payment
# MAGIC ,`SAP COMPANY CODE` sap_company_code
# MAGIC ,`BLOCK_PURCHASE` sap_block_purchase
# MAGIC ,`LATEST SETTLEMENT DATE` sap_latest_settlement_date
# MAGIC ,`POSTING MONTH` sap_posting_month
# MAGIC ,`TRANSACTED COMPANY CODE` sap_transacted_company_code
# MAGIC ,`SETTLEMENT CURRENCY` sap_settlement_currency
# MAGIC ,`SETTLEMENT VALUE(AP/AR LC)` sap_settlement_value_ap_or_ar_lc
# MAGIC ,`SAP_LINK` sap_link
# MAGIC ,`SAP_ACCOUNT_NO` sap_account_no
# MAGIC ,`Right_Account Number` cp_account_number
# MAGIC ,`Right_Cpty_Type` cp_cpty_type
# MAGIC --,`Right_Right_Account Number`
# MAGIC --,`Right_Right_Cpty_Type`
# MAGIC ,`SETTLEMENT_ACTIVITY` sap_settlement_activity
# MAGIC ,`SETTLEMENT_RECENCY` sap_settlement_recency
# MAGIC   from
# MAGIC   sap_trans
# MAGIC )

# COMMAND ----------

df = spark.sql("select * from vw_escpl_ertrm_cp_sap_final")

# COMMAND ----------

# display(df.select("sap_posting_month").drop_duplicates())

# COMMAND ----------

display(df)

# COMMAND ----------

#display(df)
df.printSchema()

# COMMAND ----------

df = spark.sql("select * from vw_escpl_ertrm_cp_sap_final")

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'escpl_ertrm_cp_sap_final')

# COMMAND ----------


