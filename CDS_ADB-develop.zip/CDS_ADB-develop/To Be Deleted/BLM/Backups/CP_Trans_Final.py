# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# DBTITLE 1,Import connections
# MAGIC %run "/CP_Data/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 1,cp_master consolidation and getting latest logics
# MAGIC %run "/BLM/cp_master"

# COMMAND ----------

from pyspark.sql.functions import col, concat_ws

# COMMAND ----------

# DBTITLE 1,Self-Service Tables to be loaded into Curated DB -- erate
# erate_df = spark.read.jdbc(SS_sqldb_URL, table='bexcel.erate_combining_fo_source_eratedate_vw');
# erate_df.createOrReplaceTempView('erate')
# erate_df.createOrReplaceTempView('vw_vw_erate_combining_fo_source_eratedate')
# #display(erate_df)

# COMMAND ----------

# RefreshCuratedSqlTbl('pty_counterparty', 'vw_erate_combining_fo_source_eratedate')

# COMMAND ----------

# DBTITLE 1,Read vw_gt_crd_gtmi_singlecpList is needed in joins for cp_trans_final output table
gtmi_crd_df = spark.read.jdbc(Stratos_sqldb_URL_curated, table='pty_counterparty_vw.gt_crd_gtmi_singlecplist');
gtmi_crd_df.createOrReplaceTempView('gtmi_crd')
gtmi_crd_df.createOrReplaceTempView('vw_vw_gt_crd_gtmi_singlecplist')
#display(gtmi_crd_df)

# COMMAND ----------

RefreshCuratedSqlTbl('pty_counterparty', 'vw_gt_crd_gtmi_singlecplist')

# COMMAND ----------

# DBTITLE 1,Sanctions from Self-Service ( will be removed in future enhancements)
#sanctions_df = spark.read.jdbc(SS_sqldb_URL, table='bexcel.erate_sanction_list');
#sanctions_df.createOrReplaceTempView('sanctions')
#sanctions_df.createOrReplaceTempView('vw_vw_erate_sanction_list')
#display(sanctions_df)

# COMMAND ----------

#RefreshCuratedSqlTbl('pty_counterparty', 'vw_erate_sanction_list')

# COMMAND ----------

# DBTITLE 1,Self- Service from DNDB Flag (not using anywhere)
#dndb_df = spark.read.jdbc(SS_sqldb_URL, table='bexcel.erate_dndb_counterparty');
#dndb_df.createOrReplaceTempView('dndb')
#dndb_df.createOrReplaceTempView('vw_vw_erate_dndb_counterparty')
#display(cp_trans_stg_df)

# COMMAND ----------

#RefreshCuratedSqlTbl('pty_counterparty', 'vw_erate_dndb_counterparty')

# COMMAND ----------

# DBTITLE 1,Load the curated tables
schema_name= 'bexcel'
selfservice_tables_list  = ['cpdata_cp_master_stg', 'cpdata_cp_trans_stg', 'cpdata_sap_master_stg', 'cpdata_sap_trans_stg']

for table_name in selfservice_tables_list:
        df = spark.read.jdbc(SS_sqldb_URL, table=f'bexcel.{table_name}')
#         df.createOrReplaceTempView(f"vw_{schema_name}_{table_name}")
        df.createOrReplaceTempView(f'vw_{table_name}')
        print(f"--- {table_name} load started -----")
        RefreshCuratedSqlTbl('pty_counterparty', f'{table_name}')
        print(f"--- {table_name} load completed -----")
        print(f"-------------------------------------")

# COMMAND ----------

# DBTITLE 1,cp_trans --> based on cp_master, cp_etrm_trans , latest dates
# MAGIC %sql
# MAGIC create or replace temporary view cp_trans as 
# MAGIC select 
# MAGIC    cpm.cp_system                   as cp_system
# MAGIC  , cpm.cp_unique_id                as cp_unique_id 
# MAGIC  , cast(null as string)            as cp_address -- old column not needed as per new requirement doc, if needed get from cp_trans
# MAGIC  , cpt.`Buy/Sell`                  as `Buy/Sell`  
# MAGIC  
# MAGIC  --, cpt.`Contract_Type`             as `Contract_Type` not needed as per discussion with Brindha on 3/17
# MAGIC  , cpm.cp_country                  as `COUNTRY`
# MAGIC  , cpm.cp_created_or_updated_date  as `CREATED/UPDATED`
# MAGIC  , cast(null as string)            as `CREDIT RATING`
# MAGIC  , cpm.cp_deactivated              as `DEACTIVATED`
# MAGIC  , cpt.`deal class`                as `Deal Class`
# MAGIC  , cpt.`Discharge Location Code`   as `Discharge Location Code`
# MAGIC  , cpm.cp_entity_type              as `ENTITY_TYPE`
# MAGIC  , cpm.cp_etrm_account_no          as `ETRM_ACCOUNT_NO`
# MAGIC  , cpm.cp_l2_id                    as `L2_ID`
# MAGIC  , cpm.cp_l2_name                  as `L2_NAME` 
# MAGIC  --, cpt.`Latest_Activity_Date_ETRM` as deal_latest_activity_date_etrm not needed as per discussion with Brindha on 3/17
# MAGIC  , cpmldt.`Latest_Delivery_Date`   as `Latest_Delivery_Date`
# MAGIC  , cpmldt.`Latest_Trade_Date`      as `Latest_Trade_Date`
# MAGIC  , cpt.`Latest_Trader_Name`        as `Latest_Trader_Name`
# MAGIC  , cpt.`Loading Location Code`     as `Loading Location Code`
# MAGIC  , cpm.cp_name                     as `NAME`
# MAGIC  , cpt.`Notional Value`            as `Notional Value`
# MAGIC  , cpt.`Notional Volume`           as `Notional Volume`  
# MAGIC  , cpm.cp_parent                   as `PARENT`
# MAGIC  , cpt.`Product Grade`             as `Product Grade` 
# MAGIC  , cpt.`Product Type`              as `Product Type`
# MAGIC  , cpc.`cp_sap_customer_id`        as `Linked SAP Customer ID`
# MAGIC  , cpm.cp_linked_sap_system        as `Linked SAP System`
# MAGIC  , cpv.cp_sap_vendor_id            as `Linked SAP Vendor ID`
# MAGIC  , cpm.cp_system                   as `SYSTEM`
# MAGIC  , cpt.Trade_Month                 as `Trade_Month`
# MAGIC  , cpt.Trade_Year                  as `Trade_Year`
# MAGIC  , cpt.`Trader Name`               as `Trader Name`
# MAGIC  , cpt.`Trading Desk`              as `Trading Desk`
# MAGIC  , cpt.`Trading Entity`            as `Trading Entity`
# MAGIC  , cpt.`Trading Entity Long Name`  as `Trading Entity Long Name`
# MAGIC  , cpm.cp_unique_id                as  UNIQUE_ID
# MAGIC  , cpt.`Value_UoM`                 as `Value_UoM`
# MAGIC  , cpt.`Volume_UoM`                as `Volume_UoM`
# MAGIC  --, cpt.`Min_DELIVERY START DATE`   as `Min_DELIVERY START DATE` not needed in the final out so dropped
# MAGIC  , cpm.cp_sap_link                  as `SAP_LINK`
# MAGIC  , cpmldt.Latest_Settlement_Date    as `LATEST SETTLEMENT DATE`
# MAGIC  , cpmldt.latest_sap_create_date    as `LATEST_SAP CREATE DATE`
# MAGIC  , cpmldt.sap_company_code          as `Company Code`
# MAGIC  , cpmldt.Latest_Activity_Date      as `Latest_Activity_Date`
# MAGIC  , cpmldt.Latest_Activity_Flag      as `Latest_Activity_Flag`
# MAGIC  -- remove the columns once everything in the final table
# MAGIC  , cast(null as string)             as `ADDRESS`
# MAGIC  , cast(null as string)             as `Contract_Type`
# MAGIC  , cast(cpm.cp_short_name as string)    as `cp_short_name`    -- 06/29/2021  added cp_short_name to cp_master
# MAGIC  , cast(null as string)             as  L2_TYPE
# MAGIC  , to_date(null)                    as  Latest_Activity_Date_ETRM
# MAGIC  , to_date(null)                    as `Min_DELIVERY START DATE`
# MAGIC  , cpm.cp_erate_flag_in_source      as  system_erate
# MAGIC  --, cpm.cp_erate_date_in_source      as erate_date_source
# MAGIC from       vw_cp_master_unique               cpm
# MAGIC inner join vw_cp_mstr_latest_dates_with_flag cpmldt on upper(trim(cpm.cp_unique_id)) = upper(trim(cpmldt.cp_unique_id))
# MAGIC left join  vw_bexcel_cpdata_cp_trans_stg     cpt    on upper(trim(cpm.cp_system))    = upper(trim(cpt.system)) and upper(trim(cpm.cp_mapping_id)) = upper(cpt.Mapping_ID)
# MAGIC left join  vw_cp_master_customer             cpc    on upper(trim(cpm.cp_unique_id)) = upper(trim(cpc.cp_unique_id))
# MAGIC left join  vw_cp_master_vendor               cpv    on upper(trim(cpm.cp_unique_id)) = upper(trim(cpv.cp_unique_id))
# MAGIC -- left join  vw_cp_master_sap_system           cpss   on upper(trim(cpm.cp_unique_id)) = upper(trim(cpv.cp_unique_id))
# MAGIC --WHERE  cpm.cp_system = 'ENDNA_GP'

# COMMAND ----------

# DBTITLE 1,Output One
# MAGIC %sql
# MAGIC --Step 1. Join TRANS OUTPUT BEFORE JOINS and ERATE and filter
# MAGIC create or replace temporary view output_one as 
# MAGIC (
# MAGIC     select 
# MAGIC       `ADDRESS`
# MAGIC       ,`Buy/Sell` 
# MAGIC       ,`Contract_Type`
# MAGIC       ,`COUNTRY`
# MAGIC       ,`CP_SHORT_NAME`
# MAGIC       ,`CREATED/UPDATED`
# MAGIC       ,`CREDIT RATING`
# MAGIC       ,`DEACTIVATED`
# MAGIC       ,`Deal Class`
# MAGIC       ,`Discharge Location Code`
# MAGIC --      ,`Discharge Region Code`
# MAGIC       ,`ENTITY_TYPE`
# MAGIC       ,`ETRM_ACCOUNT_NO`
# MAGIC       ,`L2_ID`
# MAGIC       ,`L2_NAME`
# MAGIC       ,`L2_TYPE`
# MAGIC       ,`Latest_Activity_Date_ETRM`
# MAGIC       ,`Latest_Delivery_Date`
# MAGIC       ,`Latest_Trade_Date`
# MAGIC       ,`Latest_Trader_Name`
# MAGIC       ,`Loading Location Code`
# MAGIC --    ,`Loading Region Code`
# MAGIC       ,`NAME`
# MAGIC       ,`Notional Value`
# MAGIC       ,`Notional Volume`
# MAGIC       ,`PARENT`
# MAGIC       ,`Product Grade`
# MAGIC       ,`Product Type`
# MAGIC       ,`Linked SAP Customer ID`
# MAGIC       ,`Linked SAP System`
# MAGIC       ,`Linked SAP Vendor ID`
# MAGIC       ,`SYSTEM`
# MAGIC       ,`Trade_Month`
# MAGIC       ,`Trade_Year`
# MAGIC       ,`Trader Name`
# MAGIC       ,`Trading Desk`
# MAGIC       ,`Trading Entity`
# MAGIC       ,`Trading Entity Long Name`
# MAGIC       ,cp_trans.UNIQUE_ID
# MAGIC       ,`Value_UoM`
# MAGIC       ,`Volume_UoM`
# MAGIC       ,`Min_DELIVERY START DATE`
# MAGIC       ,`SAP_LINK`
# MAGIC       ,`LATEST SETTLEMENT DATE`
# MAGIC       ,`LATEST_SAP CREATE DATE`
# MAGIC       ,`Company Code`
# MAGIC       ,`Latest_Activity_Date`
# MAGIC       ,`Latest_Activity_Flag`
# MAGIC       ,if(system_erate is Null, erate_flag_source, system_erate) as system_erate
# MAGIC       ,erate_date_source
# MAGIC       ,erate_date as eratedate
# MAGIC       ,erating as erate_flag
# MAGIC     from
# MAGIC     cp_trans left join erate on cp_trans.unique_id = erate.unique_id
# MAGIC  );

# COMMAND ----------

# DBTITLE 1,CRD_GTMI_Derived (deriving goldtier id)
# MAGIC %sql
# MAGIC --Step 3. Filter GTMI view
# MAGIC create or replace temporary view gtmi_crd_derived as 
# MAGIC (
# MAGIC   select 
# MAGIC   if(IsNull(gtmi_crd.CLCM_GoldTierID), GoldTier_ID , CLCM_GoldTierID) as GoldTier_ID, --combining columns to create goldtier_id column
# MAGIC        gtmi_crd.CptyID
# MAGIC       ,gtmi_crd.cptygroupid as `Cust Group ID`
# MAGIC       ,gtmi_crd.GoldTier_ID as `Cust GoldTier ID`--
# MAGIC       ,gtmi_crd.Cust_Legal_Name as `Cust Legal Name`--
# MAGIC       ,gtmi_crd.GT_KYC_Policy_Status_Date as `Cust Policy Status Date`--
# MAGIC       ,gtmi_crd.GT_Country_of_Operations as `Cust Country of Operations`--
# MAGIC       ,gtmi_crd.GT_Legal_Country as `Cust Legal Country`--
# MAGIC       ,gtmi_crd.GT_Policy_Last_Review_Date as `Cust Policy Last Review Date`--
# MAGIC       ,gtmi_crd.GT_Policy_Next_Rereview_Date as `Cust Policy Next Review Date`--
# MAGIC       ,gtmi_crd.GT_KYC_Policy_Status as `Cust Policy Status`--or this
# MAGIC       ,gtmi_crd.DD_Level_Approved --
# MAGIC       ,gtmi_crd.KYC_Approved_with_Conditions as `Approved With Conditions (Y/N)`--
# MAGIC       ,gtmi_crd.KYC_Approved_with_Conditions_Remarks as `Approved with condition remarks`--
# MAGIC       ,gtmi_crd.DNDB_Flag as `DNDB List` --
# MAGIC       ,gtmi_crd.GT_KYC_Policy_Approved_Date as `Cust Policy Approved Date`--
# MAGIC       ,gtmi_crd.Cust_Policy_Risk_Level as `Cust Policy Risk Level`--
# MAGIC       ,gtmi_crd.Cust_Create_Date --
# MAGIC       ,gtmi_crd.Due_Diligence_Level as `Cust DD Level`--  
# MAGIC       ,gtmi_crd.KYC_Entity_Type as `GT_Entity_Type`
# MAGIC       ,gtmi_crd.Cust_Create_Date
# MAGIC       ,gtmi_crd.sanctions
# MAGIC       ,gtmi_crd.policy_status
# MAGIC       ,gtmi_crd.ProjectName
# MAGIC       ,gtmi_crd.DispositionDetail
# MAGIC       ,gtmi_crd.ReReviewsLiveKeepsProcess
# MAGIC       ,gtmi_crd.ReReviewsLiveBatch
# MAGIC     from gtmi_crd
# MAGIC     );

# COMMAND ----------

# MAGIC %sql
# MAGIC --To derive dndb flag
# MAGIC --create or replace temporary view gtmi_dndb as 
# MAGIC --(
# MAGIC --  select distinct legal_name, GoldTier_ID as gt_id
# MAGIC --  from
# MAGIC --  dndb left join gtmi_crd_derived on lower(trim(dndb.legal_name)) = lower(trim(gtmi_crd_derived.`Cust Legal Name`))
# MAGIC --)

# COMMAND ----------

# DBTITLE 1,Deriving unique id after goldtier_id is derived
# MAGIC %sql
# MAGIC --Step 3. Filter GTMI view
# MAGIC create or replace temporary view gtmi_crd_filtered as 
# MAGIC (
# MAGIC   select distinct
# MAGIC     gt_crd.*
# MAGIC     ,if(gt_crd.CptyID is null and gt_crd.GoldTier_ID is not Null, concat('GOLDTIER_',cast(gt_crd.GoldTier_ID as string)), CptyID) as uniq_id 
# MAGIC     -- deriving unique id after goldtier_id is derived
# MAGIC     from gtmi_crd_derived gt_crd
# MAGIC     where COALESCE(GoldTier_ID, `Cust Group ID`) is not Null
# MAGIC     );

# COMMAND ----------

# MAGIC %sql
# MAGIC --select * from gtmi_crd_filtered where uniq_id like '%ECS%'
# MAGIC --select * from gtmi_crd_filtered where uniq_id='ECS_24854_25448'
# MAGIC select * from gtmi_crd_filtered where uniq_id='ECS_1348'

# COMMAND ----------

# DBTITLE 1,Output Two
# MAGIC %sql
# MAGIC --Step 4. Join Output One and GTMI view
# MAGIC create or replace temporary view output_two as 
# MAGIC (
# MAGIC   select 
# MAGIC         if(one.unique_id is Null, gt_crd.uniq_id, one.unique_id) as unique_id
# MAGIC       ,`ADDRESS`
# MAGIC       ,`Buy/Sell`
# MAGIC       ,`Contract_Type`
# MAGIC       ,`COUNTRY`
# MAGIC       ,`CP_SHORT_NAME`
# MAGIC       ,`CREATED/UPDATED`
# MAGIC       ,`CREDIT RATING`
# MAGIC       ,`DEACTIVATED`
# MAGIC       ,`Deal Class`
# MAGIC       ,`Discharge Location Code`
# MAGIC --      ,`Discharge Region Code`
# MAGIC       ,`ENTITY_TYPE`
# MAGIC       ,`ETRM_ACCOUNT_NO`
# MAGIC       ,`L2_ID`
# MAGIC       ,`L2_NAME`
# MAGIC       ,`L2_TYPE`
# MAGIC       ,`Latest_Activity_Date_ETRM`
# MAGIC       ,`Latest_Delivery_Date`
# MAGIC       ,`Latest_Trade_Date`
# MAGIC       ,`Latest_Trader_Name`
# MAGIC       ,`Loading Location Code`
# MAGIC --      ,`Loading Region Code`
# MAGIC       ,`NAME`
# MAGIC       ,`Notional Value`
# MAGIC       ,`Notional Volume`
# MAGIC       ,`PARENT`
# MAGIC       ,`Product Grade`
# MAGIC       ,`Product Type`
# MAGIC       ,`Linked SAP Customer ID`
# MAGIC       ,`Linked SAP System`
# MAGIC       ,`Linked SAP Vendor ID`
# MAGIC       , if(upper(gt_crd.uniq_id) like '%GOLDTIER%', 'GOLDTIER', one.SYSTEM) as cp_system
# MAGIC       ,`Trade_Month`
# MAGIC       ,`Trade_Year`
# MAGIC       ,`Trader Name`
# MAGIC       ,`Trading Desk`
# MAGIC       ,`Trading Entity`
# MAGIC       ,`Trading Entity Long Name`
# MAGIC       ,`Value_UoM`
# MAGIC       ,`Volume_UoM`
# MAGIC       ,`Min_DELIVERY START DATE`
# MAGIC       ,`SAP_LINK`
# MAGIC       ,`LATEST SETTLEMENT DATE`
# MAGIC       ,`LATEST_SAP CREATE DATE`
# MAGIC       ,`Company Code`
# MAGIC       ,`Latest_Activity_Date`
# MAGIC       ,`Latest_Activity_Flag`
# MAGIC       ,system_erate
# MAGIC       ,erate_date_source
# MAGIC       ,eratedate
# MAGIC       ,erate_flag
# MAGIC       ,gt_crd.GoldTier_ID
# MAGIC       ,gt_crd.`Cust Group ID`
# MAGIC       ,gt_crd.`Cust GoldTier ID`--
# MAGIC       ,gt_crd.`Cust Legal Name`--
# MAGIC       ,gt_crd.`Cust Policy Status Date`--
# MAGIC       ,gt_crd.`Cust Country of Operations`--
# MAGIC       ,gt_crd.`Cust Legal Country`--
# MAGIC       ,gt_crd.`Cust Policy Last Review Date`--
# MAGIC       ,gt_crd.`Cust Policy Next Review Date`--
# MAGIC       ,gt_crd.`Cust Policy Status`--
# MAGIC       ,gt_crd.DD_Level_Approved `DD Level Approved`--
# MAGIC       ,gt_crd.`Approved With Conditions (Y/N)`--
# MAGIC       ,gt_crd.`Approved with condition remarks`--
# MAGIC       ,gt_crd.`DNDB List` --
# MAGIC       ,gt_crd.`Cust Policy Approved Date`--
# MAGIC       ,gt_crd.`Cust Policy Risk Level`--
# MAGIC       ,gt_crd.Cust_Create_Date --
# MAGIC       ,gt_crd.`Cust DD Level` -- 
# MAGIC       ,gt_crd.`GT_Entity_Type`
# MAGIC       ,gt_crd.Cust_Create_Date
# MAGIC       ,gt_crd.sanctions
# MAGIC       ,gt_crd.policy_status
# MAGIC       ,gt_crd.ProjectName
# MAGIC       ,gt_crd.DispositionDetail
# MAGIC       ,gt_crd.ReReviewsLiveKeepsProcess
# MAGIC       ,gt_crd.ReReviewsLiveBatch
# MAGIC       from
# MAGIC       output_one one Full Outer Join gtmi_crd_filtered gt_crd on one.unique_id = gt_crd.uniq_id
# MAGIC )

# COMMAND ----------

# DBTITLE 1,Output Three - not required as part of sanctions enhancement
# MAGIC %sql
# MAGIC --Step 5. Join Output Two and Sanctions
# MAGIC --create or replace temporary view output_three as 
# MAGIC --(
# MAGIC --  select two.*, 
# MAGIC --  sanctions.sanctions_type,
# MAGIC --  sanctions.entity_type as `sanctions_entity_type`,
# MAGIC --  sanctions.policy_status as `sanctions_policy_status` 
# MAGIC --  from
# MAGIC --  output_two two left Join sanctions on two.GoldTier_ID = sanctions.goldTier_id
# MAGIC --)

# COMMAND ----------

# DBTITLE 1,CP_Trans_Final
# MAGIC %sql
# MAGIC --Step 6. Filters after join and rename columns 
# MAGIC create or replace temporary view vw_escpl_ertrm_cp_final as 
# MAGIC (
# MAGIC   select 
# MAGIC         cp_system
# MAGIC       ,`ADDRESS` cp_address
# MAGIC       ,`Buy/Sell` deal_buy_sell
# MAGIC       ,`Contract_Type` deal_contract_type
# MAGIC       ,`COUNTRY` cp_country
# MAGIC       ,`CP_SHORT_NAME` cp_short_name
# MAGIC       ,`CREATED/UPDATED` cp_created_or_updated_date
# MAGIC       ,`CREDIT RATING` cp_credit_rating
# MAGIC       ,`DEACTIVATED` cp_deactivated
# MAGIC       ,`Deal Class` deal_class
# MAGIC       ,`Discharge Location Code` deal_discharge_location_code
# MAGIC --      ,`Discharge Region Code` deal_discharge_region_code
# MAGIC       ,`ENTITY_TYPE` cp_entity_type
# MAGIC       ,`ETRM_ACCOUNT_NO` cp_etrm_account_no
# MAGIC       ,`L2_ID` cp_l2_id
# MAGIC       ,`L2_NAME` cp_l2_name
# MAGIC       --,`CP_SHORT_NAME` cp_short_name
# MAGIC       ,`L2_TYPE` cp_l2_type
# MAGIC       ,`Latest_Activity_Date_ETRM` deal_latest_activity_date_etrm
# MAGIC       ,`Latest_Delivery_Date` deal_latest_delivery_date
# MAGIC       ,`Latest_Trade_Date` deal_latest_trade_date
# MAGIC       ,`Latest_Trader_Name` deal_latest_trader_name
# MAGIC       ,`Loading Location Code` deal_loading_location_code
# MAGIC --      ,`Loading Region Code` deal_loading_region_code
# MAGIC       ,`NAME` cp_name
# MAGIC       ,`Notional Value` deal_notional_value
# MAGIC       ,`Notional Volume` deal_notional_volume
# MAGIC       ,`PARENT` cp_parent
# MAGIC       ,`Product Grade` deal_product_grade
# MAGIC       ,`Product Type` deal_product_type
# MAGIC       ,`Linked SAP Customer ID` cp_linked_sap_customer_id
# MAGIC       ,`Linked SAP System` cp_linked_sap_system
# MAGIC       ,`Linked SAP Vendor ID` cp_linked_sap_vendor_id
# MAGIC       ,`Trade_Month` deal_trade_month
# MAGIC       ,`Trade_Year` deal_trade_year
# MAGIC       ,`Trader Name` deal_trader_name
# MAGIC       ,`Trading Desk` deal_trading_desk
# MAGIC       ,`Trading Entity` deal_trading_entity
# MAGIC       ,`Trading Entity Long Name` deal_trading_entity_long_name
# MAGIC       ,`UNIQUE_ID` cp_unique_id
# MAGIC       ,`Value_UoM` cp_value_unit_of_measure
# MAGIC       ,`Volume_UoM` cp_volume_unit_of_measure
# MAGIC       ,`SAP_LINK` cp_sap_link
# MAGIC       ,`LATEST SETTLEMENT DATE` sap_latest_settlement_date
# MAGIC       ,`LATEST_SAP CREATE DATE` sap_cp_create_date
# MAGIC       ,`Latest_Activity_Date` deal_latest_activity_date
# MAGIC       ,`Latest_Activity_Flag` deal_latest_activity_flag
# MAGIC       ,`System_Erate` cp_erate_flag_in_source
# MAGIC       ,erate_date_source cp_erate_date_in_source
# MAGIC       ,`eratedate` cp_erate_date
# MAGIC       ,`ERate_Flag` cp_erate_flag
# MAGIC       ,`GoldTier_ID` gt_goldtier_id
# MAGIC       ,`Cust Group ID` clcm_cust_group_id
# MAGIC       ,`Cust Legal Name` gt_cust_legal_name
# MAGIC       ,`Cust Policy Status Date` gt_cust_policy_status_date
# MAGIC       ,`Cust Country of Operations` gt_cust_country_of_operations
# MAGIC       ,`Cust Legal Country` gt_cust_legal_country
# MAGIC       ,`Cust Policy Last Review Date` gt_cust_policy_last_review_date
# MAGIC       ,`Cust Policy Next Review Date` gt_cust_policy_next_review_date
# MAGIC       --,`Cust Policy Status` gt_cust_policy_status --derived
# MAGIC       ,policy_status gt_cust_policy_status --raw from gtmi, changed as part of enhancement
# MAGIC       ,`DD Level Approved` gt_dd_level_approved
# MAGIC       ,`Cust DD Level` gt_cust_dd_level
# MAGIC       ,`GT_Entity_Type` gt_entity_type --cc.Entity_Type 
# MAGIC       ,`Approved With Conditions (Y/N)` gt_approved_with_conditions_flag
# MAGIC       ,`Approved with condition remarks` gt_approved_with_conditions_remarks
# MAGIC       ,`DNDB List` gt_dndb_list
# MAGIC       , cast(NULL as string) as cp_dndb_flag
# MAGIC --      , dndb.legal_name dndb_legal_name
# MAGIC       ,`Cust Policy Approved Date` gt_cust_policy_approved_date
# MAGIC       ,`Cust Policy Risk Level` gt_cust_policy_risk_level
# MAGIC       ,`Cust_Create_Date` gt_cust_create_date
# MAGIC       --,`sanctions_entity_type` cp_sanctions_entity_type --sanctions file
# MAGIC       ,cast(NULL as string) cp_sanctions_entity_type --same as gt_entity_type, not required
# MAGIC       --,`sanctions_policy_status` cp_sanctions_policy_status --sanctions file
# MAGIC       ,cast(NULL as string) cp_sanctions_policy_status
# MAGIC       --,if (output_three.sanctions_type is Null, 'None', sanctions_type) as cp_sanctions_type --sanctions file
# MAGIC       ,cast(NULL as string) cp_sanctions_type
# MAGIC       ,sanctions as gt_sanctions_type -- added as part of enhancement
# MAGIC       --sanctions from gtmi
# MAGIC       ,ProjectName as clcm_project_name
# MAGIC       --,cast(NULL as string) clcm_project_name
# MAGIC       --,cast(NULL as string) clcm_disposition_detail
# MAGIC       ,DispositionDetail as clcm_disposition_detail
# MAGIC       ,ReReviewsLiveKeepsProcess as clcm_rereviews_live_keeps_process
# MAGIC       ,ReReviewsLiveBatch as clcm_rereviews_live_batch
# MAGIC       ,cp_system as source_system
# MAGIC   from
# MAGIC   output_two
# MAGIC   where output_two.cp_system is not Null
# MAGIC )

# COMMAND ----------

df = spark.sql("select * from vw_escpl_ertrm_cp_final")
# df.count() 

# COMMAND ----------

# DBTITLE 1,Write to Curated Table -- uncomment this after DTU's are been updated
RefreshCuratedSqlTbl('pty_counterparty', 'escpl_ertrm_cp_final')
