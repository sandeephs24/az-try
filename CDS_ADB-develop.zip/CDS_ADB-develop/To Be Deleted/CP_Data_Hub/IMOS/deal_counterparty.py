# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 1,Parameters
dbutils.widgets.text("pm_adls_proj_folder", "P00014-Cross_Comm-CPData-DEV")
v_adls_folder = dbutils.widgets.get("pm_adls_proj_folder")

# COMMAND ----------

# DBTITLE 1,ADLS Staging and Target Paths of CP Data Hub Project ( Parameterized the Project folder P00014-)
adls_file_path_full_src = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/staging/IMOS/source_file/" 
adls_file_path_full_src2 = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/staging/IMOS/Timecard/source_file/"
adls_file_path_tgt      = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/cp_data_hub/IMOS/"
partition_by_cols_stg= ['source_system_code','report_date_key']
partition_by_cols_tgt = ["source_system_code"]

# COMMAND ----------

# DBTITLE 1,Reading the Source Data from Curated DB
#to read data ingested in table in curated db instead on ADLS
curated_schema_name= 'IMOS' 
curated_tables_list = ['IMOS_FINANCIAL_INVOICE_DETAILS_VES']
for table_name in curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")
  
curated_schema_name= 'IMOS' 
curated_tables_list = ['IMOS_TIME_CHARTER_DETAILS_VES']
for table_name in curated_tables_list:
  df1 = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
  df1.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")

# COMMAND ----------

df = df.withColumn("source_system_code",lit('IMOS')) #adding source_system_code
df = df.withColumn("meta_created_dttm",current_timestamp()) #adding source_system_code
df = df.withColumn("report_date_key", date_format(current_timestamp(),'yyyyMMdd').cast(IntegerType()))  # report date key

df = df.withColumnRenamed("Vessel_Code","Vessel_Code_Fin")
df = df.withColumnRenamed("Voyage_No","Voyage_No_Fin")
df = df.withColumnRenamed("Vessel_Name","Vessel_Name_Fin")

# COMMAND ----------

df1 = df1.withColumn("source_system_code",lit('IMOS')) #adding source_system_code
df1 = df1.withColumn("meta_created_dttm",current_timestamp()) #adding source_system_code
df1 = df1.withColumn("report_date_key", date_format(current_timestamp(),'yyyyMMdd').cast(IntegerType()))  # report date key

# COMMAND ----------

df.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_stg).save(adls_file_path_full_src)

# COMMAND ----------

df1.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_stg).save(adls_file_path_full_src2)

# COMMAND ----------

imos_df  = spark.read.format('delta').load(adls_file_path_full_src)

# COMMAND ----------

imos_df_timecard  = spark.read.format('delta').load(adls_file_path_full_src2)

# COMMAND ----------

max_created_dttm = imos_df.select(max("meta_created_dttm")).collect()[0][0] # 2021-10-26 02:39:..
print(max_created_dttm)

# COMMAND ----------

imos_df_latest = imos_df.filter(imos_df.meta_created_dttm == max_created_dttm)

# COMMAND ----------

# DBTITLE 1,Filter Conditions for Financial dataset
imos_df_timecard_filter = imos_df_timecard.filter((imos_df_timecard["Voyage_Complete_Date_Gmt"] >= "2018-01-01") & (imos_df_timecard["Time_Charter_counterparty_Short_Name"].isNotNull()))

# COMMAND ----------

# DBTITLE 1,Filter Conditions for Timecard dataset
imos_df_filter = imos_df.filter((imos_df["Bill_Due_Date"] >= "2018-01-01" ) &  (ltrim(imos_df["invoice_no"]) != '0'))


imos_df_filter = imos_df_filter.withColumn("Amount_Curr",col("Amount_Curr").cast('double'))
imos_df_filter = imos_df_filter.withColumn("invoice_no",ltrim(col("invoice_no")))

imos_df_filter=imos_df_filter.groupBy("invoice_date","Short_Name","Invoice_No","Full_Name","Vessel_Name_Fin","Vessel_Code_Fin","Voyage_No_Fin",\
                                      "company_code","Bill_due_date","curr").agg(sum("Amount_Curr").alias("Sum_Amount_Curr"))

# COMMAND ----------

# DBTITLE 1,Join Financial and Timecard dataset
df_FInal=imos_df_timecard_filter.join(imos_df_filter, (imos_df_timecard_filter["Time_Charter_counterparty_Short_Name"] == imos_df_filter["Short_Name"]) & (imos_df_timecard_filter["Voyage_No"] == imos_df_filter["Voyage_No_Fin"])
                    & (imos_df_timecard_filter["Vessel_Code"] == imos_df_filter["Vessel_Code_Fin"])
               ,'full_outer')

# COMMAND ----------

df_FInal=df_FInal.withColumn("Counterparty_short_name", when (col("Time_Charter_counterparty_Short_Name").isNull(),col("Short_name")).otherwise(col("Time_Charter_counterparty_Short_Name")))
 
df_FInal=df_FInal.withColumn("Vessel_Code_New", when (col("Vessel_Code").isNull(),col("Vessel_Code_Fin")).otherwise(col("Vessel_Code")))
 
df_FInal=df_FInal.withColumn("Voyage_No_New", when (col("Voyage_No").isNull(),col("Voyage_No_Fin")).otherwise(col("Voyage_No")))
 
df_FInal=df_FInal.withColumn("Vessel_Name_New", when (col("Vessel_Name").isNull(),col("Vessel_Name_Fin")).otherwise(col("Vessel_Name")))
 

# COMMAND ----------

deal_cp_col_list = ["Voyage_Commence_Date_Gmt", "Voyage_Complete_Date_Gmt", "Invoice_Date", "Counterparty_short_name","Trader", 
                    "Time_Charter_Delivery_Date", "Time_Charter_Redelivery_Date", "TimeCharter_Est_Delivery_Date_Gmt", "TimeCharter_Est_Redelivery_Date_Gmt","Company_Code","Freight_Desk","Full_Name","Invoice_Date","Company_Code","Bill_Due_Date","Invoice_No","Curr","Freight_Desk_Full_Name","sum_Amount_Curr","Vessel_Code_New","Voyage_No_New","Vessel_Name_New"]

deal_counterparty_df = df_FInal[deal_cp_col_list]

deal_counterparty_df.createOrReplaceTempView("vw_deal_counterparty")


# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view  vw_deal_counterparty_new as 
# MAGIC select distinct
# MAGIC Voyage_Commence_Date_Gmt
# MAGIC ,Voyage_Complete_Date_Gmt 
# MAGIC ,Invoice_Date
# MAGIC ,Counterparty_short_name
# MAGIC ,Trader 
# MAGIC ,Time_Charter_Delivery_Date 
# MAGIC ,Time_Charter_Redelivery_Date
# MAGIC ,TimeCharter_Est_Delivery_Date_Gmt
# MAGIC ,TimeCharter_Est_Redelivery_Date_Gmt
# MAGIC ,Company_Code
# MAGIC ,Freight_Desk
# MAGIC ,Full_Name
# MAGIC ,Voyage_No_New
# MAGIC ,Vessel_Code_new
# MAGIC ,Vessel_Name_new
# MAGIC ,Invoice_Date
# MAGIC ,Company_Code
# MAGIC ,Bill_Due_Date
# MAGIC ,Invoice_No
# MAGIC ,Curr
# MAGIC ,Freight_Desk_Full_Name
# MAGIC ,Sum_Amount_Curr
# MAGIC ,GREATEST(Voyage_Commence_Date_Gmt,Voyage_Complete_Date_Gmt,Invoice_Date,Bill_Due_Date) AS Trade_date
# MAGIC ,date_format(to_date(date_add(last_day(add_months(Bill_Due_Date,-1)),1)),"yyyyMMdd") as Trade_month
# MAGIC from vw_deal_counterparty 

# COMMAND ----------

# deal_latest_trade_date = max of max_trade_Date
# deal_latest_delivery_date = greatest of the max_activity_date and max_prod_date
deal_counterpary_summary_df=deal_counterparty_df.groupBy("Counterparty_short_name").agg(                                                                     greatest(max("Time_Charter_Delivery_Date"),max("Time_Charter_Redelivery_Date"),max("TimeCharter_Est_Delivery_Date_Gmt"),max("TimeCharter_Est_Redelivery_Date_Gmt")).alias("deal_latest_delivery_date"),\
                                                                            greatest(max("Voyage_Commence_Date_Gmt"),max("Voyage_Complete_Date_Gmt"),max("Invoice_Date"),max("Bill_due_date")).alias("deal_latest_trade_date")
                                                           
                                                                         )
#create the temp view
deal_counterpary_summary_df.createOrReplaceTempView("vw_deal_counterparty_summary")

# COMMAND ----------

deal_counterparty_summary = spark.sql(""" select distinct
                                         'IMOS' as source_system_code
                                         ,cds.Counterparty_short_name as cp_deal_mapping_id
                                         ,cds.deal_latest_trade_date
                                         ,cds.deal_latest_delivery_date
                                         ,concat_ws(",", array_sort((collect_set(cd.Trader)))) as deal_latest_trader_name
                                         ,current_timestamp as meta_created_dttm
                                         ,current_timestamp as meta_start_dttm
                                         ,cast('2999-12-31' as timestamp) as meta_end_dttm 
                                         ,'Y'  as active_indicator
                                         , date_format(current_date, 'yyyyMMdd') as report_date_key
                                    from    vw_deal_counterparty_new         cd
                                    inner join  vw_deal_counterparty_summary cds on cd.Counterparty_short_name =   
                                    cds.Counterparty_short_name and (cds.deal_latest_trade_date = cd.TRADE_DATE )
                                     group by cds.Counterparty_short_name
                                           , cds.deal_latest_trade_date
                                           , cds.deal_latest_delivery_date 
                                           """)
deal_counterparty_summary.createOrReplaceTempView("vw_deal_counterparty_summary")
deal_counterparty_summary.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty_summary/")

# COMMAND ----------

cnt_before_writing = deal_counterparty_summary.count()
deal_counterparty_summary= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty_summary/")
cnt_after_writing = deal_counterparty_summary.count()
try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty_summary', 'IMOS')
except Exception as r:
  print("For IMOS source system deal_counteparty_summary counts didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'deal_counterparty_summary', 'cp_data_hub', 'deal_counterparty_summary', 'IMOS')

# COMMAND ----------

  deal_counterparty = spark.sql(""" select distinct
                                         'IMOS' as source_system_code
                                         ,Counterparty_short_name as cp_deal_mapping_id
                                         ,if (Company_Code is null ,Freight_Desk,Company_Code) as deal_trading_desk
										 ,cast(null as string) as deal_trading_entity
										 ,cast(null as string) as deal_trading_entity_long_name
										 ,cast(null as string)   as deal_buy_sell
										 ,cast(null as string)   as deal_class
										 ,cast(null as string)   as deal_product_type
										 ,cast(Trade_month as int)   as deal_date_month_key
										 ,Trader as deal_trader_name
										 ,Curr   as deal_value_unit_of_measure
										 ,cast(null as string)       as deal_volume_unit_of_measure
                                         ,sum(sum_Amount_curr) as deal_notional_value
                                         ,cast(null as string)   as deal_notional_volume
										 ,current_timestamp as meta_created_dttm
                                         ,current_timestamp as meta_start_dttm
                                         ,cast('2999-12-31' as timestamp) as meta_end_dttm 
                                         ,'Y'  as active_indicator
                                         , date_format(current_date, 'yyyyMMdd') as report_date_key
                                    from    vw_deal_counterparty_new         cd
                                 where Counterparty_short_name is not null
                                 group by  Counterparty_short_name,if (Company_Code is null ,Freight_Desk,Company_Code)
									,Trader,Curr,Trade_month
                              
                              """)
deal_counterparty.createOrReplaceTempView("vw_deal_counterparty")
deal_counterparty.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty/")

# COMMAND ----------

cnt_before_writing = deal_counterparty.count()
deal_counterparty= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty/")
cnt_after_writing = deal_counterparty.count()

try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty', 'IMOS')
except Exception as r:
  print("For IMOS source system deal_counteparty counts didn't match")
  raise dbutils.notebook.exit(e)


# COMMAND ----------

LoadCuratedTargetTbl('staging', 'deal_counterparty', 'cp_data_hub', 'deal_counterparty', 'IMOS')

# COMMAND ----------

# DBTITLE 1,Function to update refresh date
#RefreshDateP3(col_name,schema_name,table_name,source_system)
RefreshDateP3('Last_Update_Gmt','IMOS','IMOS_TRANSACTION_DETAILS','IMOS') 

# COMMAND ----------

Source_System_Code = 'IMOS'
System ='P3'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
