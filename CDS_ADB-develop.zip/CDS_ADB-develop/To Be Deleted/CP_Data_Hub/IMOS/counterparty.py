# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

curated_schema_name= 'IMOS' 
curated_tables_list = ['IMOS_COUNTERPARTY','IMOS_TRANSACTION_DETAILS']
for table_name in curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_IMOS_IMOS_COUNTERPARTY_CPTY as 
# MAGIC select
# MAGIC 'IMOS' as SYSTEM,
# MAGIC 'IMOS_' || Short_Name as UNIQUE_ID,
# MAGIC Full_Name as NAME,
# MAGIC case 
# MAGIC when Type = 'A' then 'Agents'
# MAGIC when Type = 'B' then 'Brokers'
# MAGIC when Type = 'C' then 'Charterers'
# MAGIC when Type = 'F' then 'Bunker Vendors'
# MAGIC when Type = 'M' then 'Misc'
# MAGIC when Type = 'N' then 'Banks'
# MAGIC when Type = 'O' then 'Owners'
# MAGIC when Type = 'P' then 'Port services supplier'
# MAGIC when Type = 'Q' then 'Port/Terminal operator'
# MAGIC when Type = 'R' then 'Receiver'
# MAGIC when Type = 'S' then 'Shipper'
# MAGIC when Type = 'W' then 'Company Info'
# MAGIC when Type = 'X' then 'System used'
# MAGIC end as ENTITY_TYPE,
# MAGIC case when Inactive = 'True' then 'Y' else 'N' end as DEACTIVATED,
# MAGIC Short_Name as L1_ID,
# MAGIC Country as COUNTRY,
# MAGIC 'STNSAP' as SAP_SYSTEM,
# MAGIC Credit_Rating as CREDIT_RATING,
# MAGIC Last_Transaction_Date as Last_Transaction_Date,
# MAGIC Type as Type,
# MAGIC AP_Account,
# MAGIC AR_Account,
# MAGIC Type_Descr,
# MAGIC Last_Update_Gmt,
# MAGIC Last_User_ID,
# MAGIC Rating_Date
# MAGIC from vw_IMOS_IMOS_COUNTERPARTY

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_IMOS_IMOS_COUNTERPARTY_ACCOUNTS as 
# MAGIC select
# MAGIC cpty1.*, 'Customer' as SAP_CPTY_TYPE
# MAGIC from vw_IMOS_IMOS_COUNTERPARTY_CPTY cpty1
# MAGIC UNION
# MAGIC select
# MAGIC cpty2.*, 'Vendor' as SAP_CPTY_TYPE
# MAGIC from vw_IMOS_IMOS_COUNTERPARTY_CPTY cpty2

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_IMOS_IMOS_COUNTERPARTY_UNIQUE as 
# MAGIC select
# MAGIC SYSTEM,
# MAGIC UNIQUE_ID,
# MAGIC NAME,
# MAGIC ENTITY_TYPE,
# MAGIC DEACTIVATED,
# MAGIC L1_ID,
# MAGIC COUNTRY,
# MAGIC SAP_SYSTEM,
# MAGIC case
# MAGIC when SAP_CPTY_TYPE = 'Vendor'   then AP_Account
# MAGIC when SAP_CPTY_TYPE = 'Customer' then AR_Account end as SAP_ACCOUNT_NO,
# MAGIC CREDIT_RATING,
# MAGIC Last_Transaction_Date,
# MAGIC Type,
# MAGIC SAP_CPTY_TYPE,
# MAGIC Type_Descr,
# MAGIC Last_Update_Gmt,
# MAGIC Last_User_ID,
# MAGIC  Rating_Date
# MAGIC from vw_IMOS_IMOS_COUNTERPARTY_ACCOUNTS

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_imos as 
# MAGIC select
# MAGIC distinct
# MAGIC UNIQUE_ID,
# MAGIC NAME,
# MAGIC Type,
# MAGIC ENTITY_TYPE,
# MAGIC DEACTIVATED,
# MAGIC L1_ID,
# MAGIC COUNTRY,
# MAGIC SAP_SYSTEM,
# MAGIC SAP_ACCOUNT_NO,
# MAGIC CREDIT_RATING,
# MAGIC --cast(Last_Transaction_Date as timestamp) as Last_Transaction_Date,
# MAGIC date_format(cast(Last_Transaction_Date as timestamp), "yyyy-MM-dd") as Last_Transaction_Date,
# MAGIC SAP_CPTY_TYPE,
# MAGIC case when trim(SAP_ACCOUNT_NO) = '' or SAP_ACCOUNT_NO is null then null 
# MAGIC      else SAP_SYSTEM || '_' || SAP_CPTY_TYPE || '_' || SAP_ACCOUNT_NO  end as SAP_UNIQUE_ID,
# MAGIC Type_Descr,
# MAGIC --cast(Last_Update_Gmt as timestamp) as Last_Update_Gmt,
# MAGIC date_format(cast(Last_Update_Gmt as timestamp), "yyyy-MM-dd") as Last_Update_Gmt,
# MAGIC Last_User_ID,
# MAGIC case when CREDIT_RATING ='E' then 'Y' else 'N' end  cp_erate_flag_in_source
# MAGIC --,cast(null as timestamp) as cp_erate_date_in_source
# MAGIC ,case when CREDIT_RATING ='E' then  cast(Rating_Date as timestamp) 
# MAGIC   else cast(null as timestamp) 
# MAGIC   end cp_erate_date_in_source 
# MAGIC ,L1_ID                          as cp_mapping_id
# MAGIC ,SYSTEM
# MAGIC ,'IMOS' as SOURCE_SYSTEM
# MAGIC ,current_timestamp as META_CREATED_DTTM
# MAGIC from vw_IMOS_IMOS_COUNTERPARTY_UNIQUE

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty as 
# MAGIC select distinct 
# MAGIC     imos.UNIQUE_ID                      as cp_unique_id               
# MAGIC   , imos.L1_ID                          as cp_legal_entity_id          
# MAGIC   , imos.name                           as cp_name
# MAGIC   , cast(null as string)                as cp_business_unit_id         
# MAGIC   , cast(null as string)                as cp_business_unit_name
# MAGIC   , cast(null as string)                as cp_short_name
# MAGIC   , cast(null as timestamp)             as cp_created_date
# MAGIC   , cast(null as timestamp)             as cp_updated_date
# MAGIC   , imos.DEACTIVATED                    as cp_deactivated
# MAGIC   , imos.cp_erate_flag_in_source        as cp_erate_flag_source
# MAGIC   , imos.cp_erate_date_in_source        as cp_erate_date_source
# MAGIC   , case when imos.cp_erate_flag_in_source = 'Y' then 'Y' Else 'N' END as cp_erate_flag
# MAGIC  ,  case when imos.cp_erate_flag_in_source is not null then imos.cp_erate_date_in_source else null end as cp_erate_date
# MAGIC   , imos.L1_ID                         as cp_account_number
# MAGIC   , imos.L1_ID                         as cp_deal_mapping_id
# MAGIC   , current_timestamp as meta_created_ddtm
# MAGIC   , current_timestamp as meta_start_ddtm
# MAGIC   ,  to_date('2999-12-31', 'yyyy-MM-dd') as meta_end_ddtm
# MAGIC   , 'Y' as active_indicator
# MAGIC   , 'IMOS' as source_system_code
# MAGIC   ,date_format(current_date, 'yyyyMMdd') as  report_date_key
# MAGIC from vw_cp_master_imos imos                      
# MAGIC --left join vw_cp_data_hub_erate_salesforce   er   on (gpna.cp_unique_id = er.cp_unique_id and er.source_system ='ENDNA_GP')

# COMMAND ----------

# DBTITLE 1,Counterparty
df = spark.sql("select * from vw_counterparty")
df = df.drop_duplicates()
total_row_cnt = df.count()
print (total_row_cnt)
cp_unique_id_df = df.select(["cp_unique_id"])
cp_unique_id_df = cp_unique_id_df.drop_duplicates()
cp_unique_id_cnt= cp_unique_id_df.count()
print(cp_unique_id_cnt)
try:
  if total_row_cnt == cp_unique_id_cnt:
    RefreshCuratedSqlTbl('staging', 'counterparty', 'IMOS')
except Exception as r:
  print("For IMOS source system counterparty count vs unique_id cnt didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty', 'cp_data_hub', 'counterparty','IMOS')

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['counterparty']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

# DBTITLE 1,Counterparty Details
cp_details_df = spark.sql("""
                          select distinct
                             imos.unique_id                as cp_unique_id
                            ,cast(NULL as string)          as cp_company_code
                            ,cast(NULL as string)          as cp_company_name
                            ,cast(NULL as string)          as cp_country_code
                            ,imos.country                  as cp_country_name
                            ,cast(NULL as string)            as counterparty_type
                            ,current_timestamp               as meta_created_ddtm
                            ,current_timestamp               as meta_start_ddtm
                            ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                            ,'Y'                                   as active_indicator
                            ,'IMOS'                         as source_system_code
                            ,date_format(current_date, 'yyyyMMdd') as  report_date_key
                           from vw_cp_master_imos  imos
                           where imos.country is not null
                           and length(imos.country)>0
                          """)
#creating temp view
cp_details_df.createOrReplaceTempView("vw_counterparty_details")

# need to get the distinct unique_id counts
cp_details_cp_unique_id_cnt = cp_details_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_counterparty_details cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)                               
#load process
try:
  if cp_unique_id_cnt >= cp_details_cp_unique_id_cnt and cp_unique_id_not_in_cp_df.count()==0:
    print(f"""Count Match: {cp_unique_id_cnt} and {cp_details_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of counterparty_details is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'counterparty_details', 'IMOS')
except Exception as e:
  print("For IMOS source system counterparty count and counterparty Details unique_id didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'counterparty_details', 'cp_data_hub', 'counterparty_details', 'IMOS')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details_summary as
# MAGIC   
# MAGIC   
# MAGIC 			select cpd.source_system_code
# MAGIC 			      ,cpd.cp_unique_id
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(counterparty_type))) as counterparty_type
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_code))) as cp_company_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_name))) as cp_company_name
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_code))) as cp_country_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_name))) as cp_country_name
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 				  from vw_counterparty_details cpd
# MAGIC 				  where cpd.source_system_code  in ('IMOS')
# MAGIC 			group by cpd.source_system_code, cpd.cp_unique_id
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details_summary', 'IMOS')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details_summary', 'cp_data_hub', 'counterparty_details_summary', 'IMOS')

# COMMAND ----------

# DBTITLE 1,Bridge_counterparty_sap_account
bdg_cp_sap_account_df = spark.sql("""
                                 select distinct 
                                    imos.unique_id                  as cp_unique_id
                                   ,imos.sap_unique_id              as sap_unique_id
                                   ,imos.sap_account_no             as sap_account_number
                                   ,imos.sap_cpty_type              as sap_account_type
                                   ,imos.sap_system                 as sap_source_system_code
                                   ,current_timestamp               as meta_created_ddtm
                                   ,current_timestamp               as meta_start_ddtm
                                   ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                                   ,'Y'                                   as active_indicator
                                   ,'IMOS'                                as source_system_code
                                   ,date_format(current_date, 'yyyyMMdd') as  report_date_key 
                                from vw_cp_master_imos  imos
                                where imos.sap_unique_id is not null and length(imos.sap_unique_id) > 0
                                """)
#creating temp view
bdg_cp_sap_account_df.createOrReplaceTempView("vw_bridge_counterparty_sap_account")

# need to get the distinct unique_id counts
bdg_cp_sap_account_cp_unique_id_cnt = bdg_cp_sap_account_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
bdg_cp_sap_account_cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_bridge_counterparty_sap_account cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)
                                       
#load process
if cp_unique_id_cnt >= bdg_cp_sap_account_cp_unique_id_cnt and bdg_cp_sap_account_cp_unique_id_not_in_cp_df.count()==0:
  try:
  
    print(f"""Count Match: {cp_unique_id_cnt} and {bdg_cp_sap_account_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of bridge_counterparty_sap_account is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'bridge_counterparty_sap_account', 'IMOS')
  
  except Exception as e:
    print("For IMOS source system counterparty count and bridge_counterparty_sap_accnt cp_unique_id didn't match")
    raise dbutils.notebook.exit(e)
elif {cp_unique_id_cnt} < {bdg_cp_sap_account_cp_unique_id_cnt}: 
  print(f"""counterparty: {cp_unique_id_cnt}""")
  print(f"""bridge_counterparty_sap_account: {bdg_cp_sap_account_cp_unique_id_cnt}""")
  print("Count match is not working ")
else:
  print(f"""cp_unique_id exists in bridge counterparty sap account table but in counterparty table""")

# COMMAND ----------


#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'bridge_counterparty_sap_account', 'cp_data_hub', 'bridge_counterparty_sap_account', 'IMOS')

# COMMAND ----------

Source_System_Code = 'IMOS'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
