# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 1,Parameters
dbutils.widgets.text("pm_adls_proj_folder", "P00014-Cross_Comm-CPData-DEV")
v_adls_folder = dbutils.widgets.get("pm_adls_proj_folder")

# COMMAND ----------

# DBTITLE 1,ADLS Staging and Target Paths of CP Data Hub Project
adls_file_path_full_src = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/staging/dex/source_file/"
adls_file_path_tgt      = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/cp_data_hub/dex/"
partition_by_cols_stg= ['source_system_code','report_date_key']
partition_by_cols_tgt = ["source_system_code"]

# COMMAND ----------

create_temp_views_per_source_system('WONA_DWH', 'dex')

# COMMAND ----------

# MAGIC %sql
# MAGIC --Filtering source data to get last 4 years data only.
# MAGIC create or replace temporary view dex_STO_PRCLEVDE as
# MAGIC select * from
# MAGIC dex_STO_PRCLEVDE prclevde where 
# MAGIC prclevde.PARCEL_EVENT_DATE >= cast('2018-01-01' as date)

# COMMAND ----------

# DBTITLE 1,Trans Data from Source tables
dex_trans_df = spark.sql("""
select 
    parcel.TRDG_COMP_MNEM,
    contract.CONTRACT_NUM,
    parcel.PRCL_SEQ_NUM,
    contract.CONTRACT_CREATE_D,
    cdtyctmt.CTMT_SEQ_NUM,
    corpent.CORPORATE_ENTITY_C,
    corpent.NAME_TEXT,
    contract.CONTRACT_DATE as CONTRACT_DATE_old,
    cdtyctmt.COMMITMENT_DATE as COMMITMENT_DATE_old,
    parcel.PARCEL_DATE as PARCEL_DATE_old,
    cast(date_format(substring(contract.CONTRACT_DATE,1,10), 'yyyy-MM-dd') as Date) as CONTRACT_DATE,
    cast(date_format(substring(cdtyctmt.COMMITMENT_DATE,1,10), 'yyyy-MM-dd') as Date) as COMMITMENT_DATE,
    cast(date_format(substring(parcel.PARCEL_DATE,1,10), 'yyyy-MM-dd') as Date) as PARCEL_DATE,
    owng_chrgacct.CHARGE_ACCT_NAME,
    owng_chrgacct.CHARGE_ACCT_MNEM,
    parcel.DEAL_CLASS_CODE,
    parcel.DEAL_TYPE_CODE,
    parcel.GRADE_CODE,
    grade.OIL_TYPE_CODE,
    clnt_chrgacct.CHARGE_ACCT_MNEM as CHARGE_ACCT_MNEM2,
    clnt_chrgacct.COMPANY_MNEM,
    clnt_chrgacct.CHRG_ACCT_TYP_CODE,
    clnt_chrgacct.ACTIVE_REC_IND,
    company.CMF_LONG_NAME,
    parcel.OWNER_BUY_SELL_IND,
    contract.SPOT_TERM_CODE,
    contract.TRADER_USERID,
    cdtyctmt.CTMT_USERID,
    pricing.FIXED_PRICE,
    pricing.FINAL_PRCL_PRICE,
    parcel.BBL_VOL,
    prclcst.LATEST_COST_VALUE,
    parcel.TITLE_TRANSFER_D,
    cast(date_format(substring(parcel.BOL_DATE,1,10), 'yyyy-MM-dd') as Date) as BOL_DATE,
    cast(date_format(substring(parcel.TITLE_TRANSFER_D,1,10), 'yyyy-MM-dd') as Date) as parcel_tt,
    cast(date_format(substring(prclevde.PARCEL_EVENT_DATE,1,10), 'yyyy-MM-dd') as Date) as prcl_event_tt,
    cast(date_format(substring(parcel.MAX_PRCG_END_DATE,1,10), 'yyyy-MM-dd') as Date) as MAX_PRCG_END_DATE,
    lcload.LOCATION_NAME,
    dchg.LOCATION_NAME,
    cast(date_format(substring(parcel.ATL_SETL_DUE_DATE,1,10), 'yyyy-MM-dd') as Date) as ATL_SETL_DUE_DATE,
    --latest_cred.CREDIT_RATING_CODE,
    --cast(date_format(substring(latest_cred.CREDIT_RATING_DATE,1,10), 'yyyy-MM-dd') as Date) as CREDIT_RATING_DATE,
    --cast(date_format(substring(latest_cred.CR_RG_EXPRY_DATE,1,10), 'yyyy-MM-dd') as Date) as CR_RG_EXPRY_DATE,
    prclcst.COST_TYPE_CODE,
    prclcst.COST_CODE,
    prclcst.CURRENCY_CODE,
    prclcst.DEAL_EVENT_CODE,
    costacct.CHARGE_ACCT_MNEM as cost_charge_acct_mnem,
    costacct.COMPANY_MNEM as cost_company_mnem,
    costacct.CHRG_ACCT_TYP_CODE as cost_chrg_acct_typ_code,
    costacct.ACTIVE_REC_IND as cost_active_rec_ind,
    costcompany.CMF_LONG_NAME as cost_cmf_long_name
from dex_sto_contract contract 
left outer join 
dex_sto_cdtyctmt cdtyctmt on contract.TRDG_COMP_MNEM = cdtyctmt.TRDG_COMP_MNEM and contract.CONTRACT_NUM = cdtyctmt.CONTRACT_NUM 
left outer join 
dex_sto_parcel parcel on parcel.CONTRACT_NUM = contract.CONTRACT_NUM and parcel.CONTRACT_CREATE_D = contract.CONTRACT_CREATE_D and contract.DELETED_IND is NULL 
and parcel.CDTY_CTMT_SEQ_NUM = cdtyctmt.CTMT_SEQ_NUM and parcel.CONTRACT_CREATE_D = cdtyctmt.CONTRACT_CREATE_D and parcel.VLDT_LEVEL = 'F' and parcel.REAL_ASSUMED_IND = 'R' and parcel.DELETED_IND is NULL and cdtyctmt.DELETED_IND is NULL
inner join 
dex_sto_trdgacct owng_trdgacct on contract.OWNG_CHRG_ACCT_NUM = owng_trdgacct.SEQUENCE_NUM and owng_trdgacct.DELETED_IND is NULL
inner join 
dex_sto_chrgacct owng_chrgacct on contract.OWNG_CHRG_ACCT_NUM = owng_chrgacct.SEQUENCE_NUM and owng_chrgacct.DELETED_IND is NULL
inner join 
dex_sto_corpent corpent on owng_trdgacct.CORPORATE_ENTITY_C = corpent.CORPORATE_ENTITY_C and corpent.DELETED_IND is NULL
left outer join 
dex_sto_grade grade on parcel.GRADE_CODE = grade.GRADE_CODE and grade.DELETED_IND is NULL
inner join 
dex_sto_chrgacct clnt_chrgacct on contract.CLT_CHRG_ACCT_NUM = clnt_chrgacct.SEQUENCE_NUM and clnt_chrgacct.DELETED_IND is NULL
left outer join 
dex_sto_company company on clnt_chrgacct.COMPANY_MNEM = company.COMPANY_MNEM and company.DELETED_IND is NULL
left outer join 
dex_sto_pricing pricing on pricing.SEQUENCE_NUM = parcel.PRCG_SEQ_NUM and pricing.DELETED_IND is NULL
left outer join 
dex_sto_prclevde prclevde on prclevde.TRDG_COMP_MNEM = parcel.TRDG_COMP_MNEM and prclevde.CONTRACT_NUM = parcel.CONTRACT_NUM and prclevde.PRCL_SEQ_NUM = parcel.PRCL_SEQ_NUM and prclevde.CONTRACT_CREATE_D = parcel.CONTRACT_CREATE_D and prclevde.DELETED_IND is NULL and prclevde.DEAL_EVENT_CODE = 'TT'
left outer join 
dex_sto_prclcst prclcst on prclcst.TRDG_COMP_MNEM = parcel.TRDG_COMP_MNEM and prclcst.CONTRACT_NUM = parcel.CONTRACT_NUM and prclcst.PRCL_SEQ_NUM = parcel.PRCL_SEQ_NUM and prclcst.CONTRACT_CREATE_D = parcel.CONTRACT_CREATE_D and prclcst.DELETED_IND is NULL
left outer join 
dex_sto_chrgacct costacct on prclcst.CHRG_ACCT_NUM = costacct.SEQUENCE_NUM and costacct.DELETED_IND is NULL
left outer join 
dex_sto_company costcompany on costacct.COMPANY_MNEM = costcompany.COMPANY_MNEM and costcompany.DELETED_IND is NULL
left outer join 
dex_sto_prclldg prclldg on prclldg.TRDG_COMP_MNEM = parcel.TRDG_COMP_MNEM and prclldg.CONTRACT_NUM = parcel.CONTRACT_NUM and prclldg.PRCL_SEQ_NUM = parcel.PRCL_SEQ_NUM and prclldg.DELETED_IND is NULL
left outer join 
dex_sto_prcldch prcldch on prcldch.TRDG_COMP_MNEM = parcel.TRDG_COMP_MNEM and prcldch.CONTRACT_NUM = parcel.CONTRACT_NUM and prcldch.PRCL_SEQ_NUM = parcel.PRCL_SEQ_NUM and prcldch.DELETED_IND is NULL
left outer join 
dex_sto_location lcload on prclldg.LOC_SEQ_NUM = lcload.SEQUENCE_NUM and lcload.DELETED_IND is NULL
left outer join 
dex_sto_location dchg on prcldch.LOC_SEQ_NUM = dchg.SEQUENCE_NUM and dchg.DELETED_IND is NULL
--left outer join
--(
--    select dex_sto_compcrrg.COMPANY_MNEM,
--    dex_sto_compcrrg.CREDIT_RATING_DATE,
--    dex_sto_compcrrg.CREDIT_RATING_CODE,
--    dex_sto_compcrrg.CR_RG_EXPRY_DATE,
--    RANK()
--    over
--    (
--        partition by dex_sto_compcrrg.COMPANY_MNEM
--        order by dex_sto_compcrrg.CREDIT_RATING_DATE Desc
--    ) as latest
--    from dex_sto_compcrrg
--    where dex_sto_compcrrg.DELETED_IND is Null
--) latest_cred on latest_cred.COMPANY_MNEM = clnt_chrgacct.COMPANY_MNEM and latest_cred.LATEST = 1
""")

dex_trans_df = dex_trans_df.drop_duplicates()
dex_trans_df.createOrReplaceTempView("dex_trans")

# COMMAND ----------

deal_counterparty_df = spark.sql("""
select 
CHARGE_ACCT_MNEM2,
COMPANY_MNEM,
case when CHARGE_ACCT_MNEM2 is null then COMPANY_MNEM else CHARGE_ACCT_MNEM2 end as mapping_id,
CORPORATE_ENTITY_C,
NAME_TEXT,
CHARGE_ACCT_NAME,
OWNER_BUY_SELL_IND,
case when OWNER_BUY_SELL_IND = 'B' then 'BUY' 
     when OWNER_BUY_SELL_IND = 'S' then 'SELL' 
     else OWNER_BUY_SELL_IND 
end as deal_buy_sell,
DEAL_CLASS_CODE,
OIL_TYPE_CODE,
COST_TYPE_CODE,
CTMT_USERID,
--Commitment_Date,
--Contract_Date,
--TITLE_TRANSFER_D,
--parcel_tt,
--prcl_event_tt,
--BOL_DATE,
--PARCEL_DATE,
cast(max(CONTRACT_DATE) as Date) as trade_date, --latest based on mapping sheet
cast(date_format(if(parcel_tt is null,prcl_event_tt,parcel_tt), 'yyyy-MM-01') as Date) as trade_month, --title transfer date
cast(greatest(if(parcel_tt is null,prcl_event_tt,parcel_tt),BOL_DATE,ATL_SETL_DUE_DATE) as Date) as delivery_date, --latest based on mapping sheet
Sum(BBL_VOL) as BBL_VOL,
Sum(LATEST_COST_VALUE) as LATEST_COST_VALUE
from dex_trans
group by 
CHARGE_ACCT_MNEM2,
COMPANY_MNEM,
CORPORATE_ENTITY_C,
NAME_TEXT,
CHARGE_ACCT_NAME,
OWNER_BUY_SELL_IND,
DEAL_CLASS_CODE,
OIL_TYPE_CODE,
COST_TYPE_CODE,
CTMT_USERID,
--trade_date,
trade_month,
delivery_date
--Commitment_Date,
--Contract_Date,
--TITLE_TRANSFER_D
--parcel_tt,
--prcl_event_tt,
--BOL_DATE,
--PARCEL_DATE
""")

# COMMAND ----------

deal_counterparty_df=deal_counterparty_df\
.withColumn("source_system_code",lit("DEX"))\
.withColumn("meta_created_dttm",current_timestamp())\
.withColumn("report_date_key",date_format(current_timestamp(),'yyyyMMdd').cast(IntegerType()))

date_columns = ['trade_month']
for col_name in date_columns:
    deal_counterparty_df= deal_counterparty_df.withColumn(f"{col_name}_key",date_format(to_date(col(f"{col_name}"),"yyyy-MM-01"),"yyyyMMdd").cast(IntegerType()))

# COMMAND ----------

#dbutils.fs.rm(adls_file_path_full_src, True)

# COMMAND ----------

# DBTITLE 1,Staging the data in CP DATA HUB ADLS 
deal_counterparty_df.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_stg).save(adls_file_path_full_src)

# COMMAND ----------

# DBTITLE 1,Read from Staged Folder
deal_counterparty_df = spark.read.format('delta').load(adls_file_path_full_src)
deal_counterparty_df.createOrReplaceTempView("vw_deal_counterparty")

# COMMAND ----------

# %sql
# select * from vw_deal_counterparty
# limit 10

# COMMAND ----------

# DBTITLE 1,Getting max dates for deal_counterparty_summary
deal_counterpary_summary_df = deal_counterparty_df.groupBy(col('mapping_id')).agg(max("trade_date").alias("deal_latest_trade_date")\
                                                                                       ,max("delivery_date").alias("deal_latest_delivery_date"))
deal_counterpary_summary_df.createOrReplaceTempView("vw_deal_counterparty_summary")

# COMMAND ----------

# DBTITLE 1,deal_counterparty_summary
deal_counterparty_summary = spark.sql(""" select source_system_code
                                         ,cds.mapping_id as cp_deal_mapping_id
                                         ,cds.deal_latest_trade_date
                                         ,cds.deal_latest_delivery_date
                                         ,concat_ws(",", array_sort((collect_set(cd.CTMT_USERID)))) as deal_latest_trader_name
                                         ,current_timestamp as meta_created_dttm
                                         ,current_timestamp as meta_start_dttm
                                         ,cast('2999-12-31' as timestamp) as meta_end_dttm 
                                         ,'Y'  as active_indicator
                                         , date_format(current_date, 'yyyyMMdd') as report_date_key
                                    from        vw_deal_counterparty         cd
                                    inner join  vw_deal_counterparty_summary cds on cd.mapping_id = cds.mapping_id 
                                    and (cds.deal_latest_trade_date = cd.trade_date)
                                    where year(cds.deal_latest_delivery_date) >= 2018
                                    group by source_system_code
                                           , cds.mapping_id
                                           , cds.deal_latest_trade_date
                                           , cds.deal_latest_delivery_date
                                     """)
deal_counterparty_summary.createOrReplaceTempView("vw_deal_counterparty_summary")
deal_counterparty_summary.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty_summary/")

# COMMAND ----------

# DBTITLE 1,deal_counterparty
deal_counterparty_final = spark.sql("""select source_system_code,
                                              mapping_id as cp_deal_mapping_id,
                                              CHARGE_ACCT_NAME as deal_trading_desk,
                                              CORPORATE_ENTITY_C as deal_trading_entity,
                                              NAME_TEXT as deal_trading_entity_long_name,
                                              deal_buy_sell,
                                              DEAL_CLASS_CODE as deal_class,
                                              OIL_TYPE_CODE as deal_product_type,
                                              cast(trade_month_key as int) as deal_date_month_key,
                                              CTMT_USERID as deal_trader_name,
                                              'USD' as deal_value_unit_of_measure,
                                              'BBL' as deal_volume_unit_of_measure,
                                              Sum(cast(LATEST_COST_VALUE as decimal(30,5))) as deal_notional_value,
                                              sum(cast(BBL_VOL as DECIMAL(30,5))) as deal_notional_volume,
                                              current_timestamp as meta_created_dttm,
                                              current_timestamp as meta_start_dttm,
                                              cast('2999-12-31' as timestamp) as meta_end_dttm,
                                              'Y'  as active_indicator,
                                              date_format(current_date, 'yyyyMMdd') as report_date_key 
                                        from vw_deal_counterparty
                                        where COST_TYPE_CODE = 'OIL' 
                                        --and trade_date >= add_months(trunc(current_date, 'year') , -36) --last 4 years filter
                                        and year(trade_month) >= '2019' 
                                        and year(delivery_date) >= '2018'
                                        group by source_system_code,
                                              mapping_id,
                                              CHARGE_ACCT_NAME,
                                              CORPORATE_ENTITY_C,
                                              NAME_TEXT,
                                              deal_buy_sell,
                                              DEAL_CLASS_CODE,
                                              OIL_TYPE_CODE,
                                              trade_month_key,
                                              CTMT_USERID
                                  """)
deal_counterparty_final.createOrReplaceTempView("vw_deal_counterparty")
deal_counterparty_final.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty/")

# COMMAND ----------

# DBTITLE 1, Write deal_counterparty to staging table
cnt_before_writing = deal_counterparty_final.count()
deal_counterparty= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty/")
cnt_after_writing = deal_counterparty.count()

try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty', 'DEX')
except Exception as r:
  print("For DEX source system deal_counteparty counts didn't match")
  raise dbutils.notebook.exit(e)        

# COMMAND ----------

# DBTITLE 1,Switch the partitions from staging table target table
LoadCuratedTargetTbl('staging', 'deal_counterparty', 'cp_data_hub', 'deal_counterparty', 'DEX')

# COMMAND ----------

# DBTITLE 1,Write deal_counterparty_summary to staging table
cnt_before_writing = deal_counterparty_summary.count()
deal_counterparty_summary= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty_summary/")
cnt_after_writing = deal_counterparty_summary.count()
try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty_summary', 'DEX')
except Exception as r:
  print("For DEX source system deal_counteparty_summary counts didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Switch Partition from staging table target table
LoadCuratedTargetTbl('staging', 'deal_counterparty_summary', 'cp_data_hub', 'deal_counterparty_summary', 'DEX')

# COMMAND ----------

# DBTITLE 1,Function to update refresh date
RefreshDateP3('last_run_tstmp','NULL','dex_STO_PARCEL','DEX') 

# COMMAND ----------

Source_System_Code = 'DEX'
System ='P3'


# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
