# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

create_temp_views_per_source_system('WONA_DWH', 'dex')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view  vw_dex_sto_chrgacct as 
# MAGIC select 
# MAGIC TRDG_COMP_MNEM
# MAGIC ,cast(cast(SEQUENCE_NUM as bigint) as string) as SEQUENCE_NUM
# MAGIC ,CHARGE_ACCT_MNEM
# MAGIC ,CHRG_ACCT_TYP_RT_C
# MAGIC ,CHRG_ACCT_TYP_CODE
# MAGIC ,CHARGE_ACCT_NAME
# MAGIC ,OWNING_USERID
# MAGIC ,COMPANY_MNEM
# MAGIC ,CMF_ACCOUNT_NUM
# MAGIC ,SAP_ACCOUNT_NUM
# MAGIC ,CR_CNTLR_NUM
# MAGIC ,LEVEL_NUM
# MAGIC ,LAST_UPDATE_TSTMP
# MAGIC ,DELETED_IND
# MAGIC ,LAST_RUN_TSTMP
# MAGIC ,SDW_VERSION_NUM
# MAGIC ,REACH_IMPORT_IND
# MAGIC ,US_PERS_STAT
# MAGIC ,EU_FNCL_STAT
# MAGIC ,TRDG_ACCT_SPEC_IND
# MAGIC ,CLT_MIFID_CODE
# MAGIC ,ACTIVE_REC_IND
# MAGIC ,CLEARED_CPTY_IND
# MAGIC ,SUPPLY_TRADE_IND
# MAGIC ,MANUFACTURING_IND
# MAGIC ,CLASS_OF_BUS_CODE
# MAGIC ,META_CREATED_DTTM
# MAGIC ,EFFECTIVE_START_DATE
# MAGIC ,EFFECTIVE_END_DATE
# MAGIC ,IS_RECORD_ACTIVE
# MAGIC from dex_sto_chrgacct

# COMMAND ----------

# MAGIC  %sql
# MAGIC  create or replace temporary view vw_cp_master_dex_addr as    --to get the address details
# MAGIC   select distinct compaddr.company_mnem,compaddr.seq_num,
# MAGIC           compaddr.preferred_ind,
# MAGIC           address.active_rec_ind,
# MAGIC           compaddr.address_type_code,
# MAGIC           addrline.last_update_tstmp as addrline_last_update_tstmp,
# MAGIC           compaddr.last_update_tstmp as compaddr_last_update_tstmp,
# MAGIC           address.last_update_tstmp as address_last_update_tstmp,
# MAGIC           concat_ws(' ',collect_list(cast(addrline.description_text as string)) 
# MAGIC           over (partition by compaddr.company_mnem order by addrline.line_num ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)) as full_address
# MAGIC         from dex_sto_compaddr compaddr
# MAGIC         left outer join dex_sto_address address   on compaddr.address_num = address.address_num
# MAGIC         left outer join dex_sto_addrline addrline on address.address_num = addrline.address_num

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_dex_base as    --to get the base data as per logic 
# MAGIC select distinct
# MAGIC     company.appv_bkr_ind as APPV_BKR_IND,
# MAGIC     company.company_mnem as L1_ID,
# MAGIC     --concat('DEX_',trim(company.company_mnem),'_',trim(string(chrgacct.sequence_num))) as UNIQUE_ID,
# MAGIC     case when trim(company.company_mnem)     is null       then concat('DEX_',trim(string(chrgacct.sequence_num)))
# MAGIC     when trim(string(chrgacct.sequence_num)) is null       then concat('DEX_',trim(company.company_mnem),'_')
# MAGIC     when trim(company.company_mnem)=trim(chrgacct.CHARGE_ACCT_MNEM) then concat('DEX_',trim(company.company_mnem),'_') --added for CPs who are dummy/parents,not include seq no.
# MAGIC     else concat('DEX_',trim(company.company_mnem),'_',trim(string(chrgacct.sequence_num))) 
# MAGIC     end as UNIQUE_ID,
# MAGIC     chrgacct.sequence_num as L2_ID,
# MAGIC     /*case when company.line2_name is null then trim(company.line1_name)
# MAGIC          when company.line1_name is null then trim(company.line2_name)
# MAGIC          else trim(concat(trim(company.line1_name),' ',trim(company.line2_name))) 
# MAGIC     end as NAME,*/
# MAGIC     case when company.line1_name is null and company.line2_name is null then trim(chrgacct.charge_acct_name)
# MAGIC          when company.line2_name is null and company.line1_name is not null then trim(company.line1_name)
# MAGIC          when company.line1_name is null and company.line2_name is not null then trim(company.line2_name)
# MAGIC          else trim(concat(trim(company.line1_name),' ',trim(company.line2_name))) 
# MAGIC     end as NAME,
# MAGIC     company.line1_name as L1_NAME1,
# MAGIC     company.line2_name as L1_NAME2,
# MAGIC     chrgacct.charge_acct_name as L2_NAME1,
# MAGIC     chrgacct.charge_acct_mnem as L1_ID_NEW,
# MAGIC     company.cmf_short_name as CP_SHORT_NAME,
# MAGIC     company.company_type_code as L1_TYPE,
# MAGIC     case when company.company_type_code = 'A' then 'A_Affiliate'
# MAGIC          when company.company_type_code = 'G' then 'G_Government'
# MAGIC          when company.company_type_code = 'A' then 'A_Affiliate'
# MAGIC          when company.company_type_code = 'T' then 'T_3rd_Party'
# MAGIC          else company.company_type_code 
# MAGIC     end as ENTITY_TYPE,
# MAGIC     company.owning_mnem as PARENT,
# MAGIC     chrgacct.chrg_acct_typ_rt_c as L2_TYPE,
# MAGIC     chrgacct.sap_account_num as  SAP_ACCOUNT_NUM,
# MAGIC     case when ltrim('0',trim(chrgacct.sap_account_num)) = '' or chrgacct.sap_account_num is null then null 
# MAGIC          else 'STNSAP'
# MAGIC     end as SAP_SYSTEM,
# MAGIC     case when ltrim('0',trim(chrgacct.sap_account_num)) = '' or chrgacct.sap_account_num is null then null 
# MAGIC          else 'L2'
# MAGIC     end as SAP_LINK_LEVEL,
# MAGIC     ltrim('0',trim(chrgacct.sap_account_num)) as SAP_ACCOUNT_NO,
# MAGIC     case when ltrim('0',trim(chrgacct.sap_account_num)) = '' or chrgacct.sap_account_num is null then null 
# MAGIC          when cast(Substring(trim(chrgacct.sap_account_num),0,1) as double) is not null then lpad(trim(chrgacct.sap_account_num), 10,'0')  
# MAGIC          else trim(chrgacct.sap_account_num)
# MAGIC     end as SAP_ACCOUNT,
# MAGIC     --company.META_CREATED_DTTM,
# MAGIC     case when company.META_CREATED_DTTM is null 
# MAGIC       then chrgacct.META_CREATED_DTTM else company.META_CREATED_DTTM end as META_CREATED_DTTM,
# MAGIC     chrgacct.last_update_tstmp as LAST_UPDATE_TSTMP,
# MAGIC     --case when chrgacct.active_rec_ind = 'N' then 'X' else null end as DEACTIVATED,
# MAGIC     case when company.last_update_tstmp >= chrgacct.last_update_tstmp then cast(company.last_update_tstmp as date)
# MAGIC      when chrgacct.last_update_tstmp >= company.last_update_tstmp then cast(chrgacct.last_update_tstmp as date)
# MAGIC      when company.last_update_tstmp is null and chrgacct.last_update_tstmp is null then NULL
# MAGIC      when company.last_update_tstmp is null and chrgacct.last_update_tstmp is not null then cast(chrgacct.last_update_tstmp as date)
# MAGIC      when company.last_update_tstmp is not null and chrgacct.last_update_tstmp is null then cast(company.last_update_tstmp as date)
# MAGIC     end as CREATED_UPDATED,
# MAGIC     --end as LAST_UPDATE_DATE,
# MAGIC     addr.full_address as FULL_ADDRESS,
# MAGIC     addr.seq_num as SEQ_NUM,
# MAGIC     addr.preferred_ind as PREFERRED_IND,
# MAGIC     --addr.active_rec_ind as ACTIVE_REC_IND,
# MAGIC     chrgacct.active_rec_ind as ACTIVE_REC_IND,
# MAGIC     addr.address_type_code as ADDRESS_TYPE_CODE,
# MAGIC     compcrrg.credit_rating_date as CREDIT_RATING_DATE,
# MAGIC     compcrrg.credit_rating_time as CREDIT_RATING_TIME,
# MAGIC     chrgacct.chrg_acct_typ_code as CHRG_ACCT_TYP_CODE,
# MAGIC     addr.addrline_last_update_tstmp as ADDRLINE_LAST_UPDATE_TSTMP,
# MAGIC     company.last_update_tstmp as COMPANY_LAST_UPDATE_TSTMP,
# MAGIC     addr.compaddr_last_update_tstmp as COMPADDR_LAST_UPDATE_TSTMP,
# MAGIC     addr.address_last_update_tstmp as ADDRESS_LAST_UPDATE_TSTMP,
# MAGIC     compcrrg.credit_rating_code as CREDIT_RATING_CODE,
# MAGIC     case when compcrrg.credit_rating_code = 'P' or compcrrg.credit_rating_code = 'E' then 'Y' else 'N' end as ERATE_FLAG,
# MAGIC     case when trim(company.line1_name) is null then '' else concat(company.line1_name,' ') end as LE_NAME_P1,
# MAGIC     case when trim(company.line2_name) is null then '' else concat(company.line2_name,' ') end as LE_NAME_P2,
# MAGIC     case when trim(chrgacct.charge_acct_name) is null then '' else chrgacct.charge_acct_name end as LE_NAME_P3
# MAGIC     from dex_sto_company company
# MAGIC     full outer join vw_dex_sto_chrgacct chrgacct on company.company_mnem = chrgacct.company_mnem or company.company_mnem = chrgacct.CHARGE_ACCT_MNEM
# MAGIC     left outer join vw_cp_master_dex_addr addr on company.company_mnem = addr.company_mnem
# MAGIC     left outer join dex_sto_compcrrg compcrrg on compcrrg.company_mnem = company.company_mnem   

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_dex_union as  --to get all records with null SAP Account no. once and other records twice - one for vendor and one for customer
# MAGIC (select *, 1 as rowcount from vw_cp_master_dex_base) 
# MAGIC union all
# MAGIC (select *, 2 as rowcount from vw_cp_master_dex_base where ltrim('0',trim(SAP_ACCOUNT_NUM)) != '' and SAP_ACCOUNT_NUM is not null)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_dex as  --to get the output data in required columns sequence
# MAGIC select 
# MAGIC     APPV_BKR_IND,
# MAGIC     'DEX' as SYSTEM,
# MAGIC     L1_ID,
# MAGIC     UNIQUE_ID,
# MAGIC     L2_ID,
# MAGIC     NAME,
# MAGIC     L1_NAME1,
# MAGIC     L1_NAME2,
# MAGIC     L2_NAME1,
# MAGIC     L1_ID_NEW,
# MAGIC     CP_SHORT_NAME,
# MAGIC     L1_TYPE,
# MAGIC     ENTITY_TYPE,
# MAGIC     PARENT,
# MAGIC     L2_TYPE,
# MAGIC     SAP_ACCOUNT_NUM,
# MAGIC     SAP_SYSTEM,
# MAGIC     case when ltrim('0',trim(SAP_ACCOUNT_NUM)) = '' or SAP_ACCOUNT_NUM is null then null
# MAGIC       else concat('STNSAP_',(case when rowcount = 1 then 'Customer' else 'Vendor' end),'_',ltrim('0',trim(replace(SAP_ACCOUNT_NUM,'_',''))))
# MAGIC     end as SAP_UNIQUE_ID,
# MAGIC     case when ltrim('0',trim(SAP_ACCOUNT_NUM)) = '' or SAP_ACCOUNT_NUM is null then null 
# MAGIC       when rowcount = 1 then 'Customer' else 'Vendor'
# MAGIC     end as SAP_CPTY_TYPE,
# MAGIC     SAP_LINK_LEVEL,
# MAGIC     SAP_ACCOUNT_NO,
# MAGIC     SAP_ACCOUNT,
# MAGIC     CAST(META_CREATED_DTTM AS TIMESTAMP),
# MAGIC     CAST(LAST_UPDATE_TSTMP AS TIMESTAMP),
# MAGIC     --ACTIVE_REC_IND as DEACTIVATED,
# MAGIC     case when  ACTIVE_REC_IND = 'N' then 'Y'  else 'N' end as DEACTIVATED, -- cp_deactivated
# MAGIC     CREATED_UPDATED,
# MAGIC     FULL_ADDRESS,
# MAGIC     SEQ_NUM,
# MAGIC     PREFERRED_IND,
# MAGIC     --ACTIVE_REC_IND,
# MAGIC     --ACTIVE_REC_IND_1,
# MAGIC     ADDRESS_TYPE_CODE,
# MAGIC     cast(CREDIT_RATING_DATE as Date) AS CREDIT_RATING_DATE,
# MAGIC     CREDIT_RATING_TIME,
# MAGIC     CHRG_ACCT_TYP_CODE,
# MAGIC     CAST(ADDRLINE_LAST_UPDATE_TSTMP AS timestamp) AS ADDRLINE_LAST_UPDATE_TSTMP,
# MAGIC     CAST(COMPANY_LAST_UPDATE_TSTMP  AS timestamp) AS COMPANY_LAST_UPDATE_TSTMP,
# MAGIC     CAST(COMPADDR_LAST_UPDATE_TSTMP AS timestamp) AS COMPADDR_LAST_UPDATE_TSTMP,
# MAGIC     CAST(ADDRESS_LAST_UPDATE_TSTMP  AS timestamp) AS ADDRESS_LAST_UPDATE_TSTMP,
# MAGIC     CREDIT_RATING_CODE,
# MAGIC     --concat(LE_NAME_P1,'_',LE_NAME_P2,'_',LE_NAME_P3) as CP_LEGAL_ENTITY_NAME,
# MAGIC     concat(LE_NAME_P1,LE_NAME_P2,LE_NAME_P3) as CP_LEGAL_ENTITY_NAME,
# MAGIC     ERATE_FLAG,
# MAGIC     'WONA_DWH' as SOURCE_SYSTEM    
# MAGIC from vw_cp_master_dex_union

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_erate_flag as 
# MAGIC select * from
# MAGIC (
# MAGIC   select distinct company_mnem, credit_rating_date, credit_rating_time, credit_rating_code,
# MAGIC   dense_rank() over (partition by company_mnem order by credit_rating_date desc, credit_rating_time desc) as seq_num
# MAGIC   from dex_sto_compcrrg
# MAGIC )
# MAGIC where seq_num = 1

# COMMAND ----------

# MAGIC %sql
# MAGIC --added to provide consistency between all company_mnem under the same chrgacct. 
# MAGIC create or replace temporary view vw_cp_master_erate_flag1 as 
# MAGIC ( with a as (
# MAGIC   select * ,1 as n from vw_cp_master_erate_flag
# MAGIC   union
# MAGIC   select CHARGE_ACCT_MNEM as company_mnem, 
# MAGIC   credit_rating_date, credit_rating_time, credit_rating_code, seq_num , 2 as n
# MAGIC   from vw_cp_master_erate_flag eflag inner join vw_dex_sto_chrgacct chrgacct
# MAGIC   on eflag.company_mnem = chrgacct.company_mnem )
# MAGIC   
# MAGIC   select t.company_mnem,
# MAGIC t.credit_rating_date,
# MAGIC t.credit_rating_time,
# MAGIC t.credit_rating_code,
# MAGIC t.seq_num from (
# MAGIC   select a.*, row_number() over(partition by company_mnem order by n ) rn from a)t where  t.rn = 1
# MAGIC )

# COMMAND ----------

#schema_name= 'bexcel'
#selfservice_tables_list  = ['erate_activity_cpty_dex']
#
#for table_name in selfservice_tables_list:
#        df = spark.read.jdbc(SS_sqldb_URL, table=f'bexcel.{table_name}')
#        df.createOrReplaceTempView(f"vw_{schema_name}_{table_name}")
#        df.createOrReplaceTempView(f'vw_{table_name}')

# COMMAND ----------

#%sql
#create or replace temporary view vw_bexcel_erate_dex as 
#select distinct 
#    'DEX' as source_system
#   , case when length(trim(company_name))> 0 and length(trim(unique_id))> 0 then 
#          concat('DEX_',upper(trim(company_name)),'_',upper(trim(cast(cast(unique_id as decimal) as varchar(200)))))
#      end unique_id
#   , case when length(trim(party_name)) > 0  then concat('DEX_',trim(party_name),'_') end unique_id2
#   ,cast(appr_date as date) as erate_date_source
#   ,approved_status
#    from vw_bexcel_erate_activity_cpty_dex
#    where approved_status in ('E', 'P')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master as 
# MAGIC select distinct 
# MAGIC     A.UNIQUE_ID             as cp_unique_id,                      --REQ-26
# MAGIC     L1_ID                 as cp_l1_id,                          --REQ-28
# MAGIC     NAME                  as cp_name,                           --REQ-27
# MAGIC     case when L1_ID_NEW is null                                 --L1_ID = company.company_mnem, L1_ID_NEW = chrgacct.charge_acct_mnem
# MAGIC       then L1_ID else L1_ID_NEW 
# MAGIC     end                   as cp_etrm_account_no,                
# MAGIC     L2_ID                 as cp_l2_id,                          --REQ-29
# MAGIC     L2_NAME1              as cp_l2_name,                        --REQ-30                          
# MAGIC     L1_TYPE               as cp_entity_type,                    --REQ-31
# MAGIC     CREATED_UPDATED       as cp_created_or_updated_date,        --REQ-34
# MAGIC     --case when DEACTIVATED is null then '' else DEACTIVATED  end                   as cp_deactivated,                    --REQ-32
# MAGIC     DEACTIVATED           as cp_deactivated,                     -- REQ-32 changed on 4/20/2021 by rama
# MAGIC     FULL_ADDRESS          as cp_country,                        --REQ-91
# MAGIC     PARENT                as cp_parent,                         --REQ-87
# MAGIC     SYSTEM                as cp_system,                         --REQ-36
# MAGIC     SAP_ACCOUNT_NO        as cp_linked_sap_id,                  --REQ-93
# MAGIC     SAP_CPTY_TYPE         as cp_sap_account_type,               --REQ-38
# MAGIC     SAP_UNIQUE_ID         as cp_sap_unique_id,                  --REQ-97
# MAGIC     SAP_SYSTEM            as cp_linked_sap_system,              --REQ-93
# MAGIC     case when (SAP_UNIQUE_ID is null or length(trim(SAP_UNIQUE_ID)) = 0 ) 
# MAGIC       then 'NO SAP LINK' ELSE 'SAP LINK' 
# MAGIC     END                   as cp_sap_link,
# MAGIC     
# MAGIC     --removed as a part of dex erate change
# MAGIC     --case when dex_qry.erate_date_source is not null    then 'Y' else 'N'
# MAGIC     --end                   as cp_erate_flag,           --REQ-9
# MAGIC     --
# MAGIC     --case  when   dex_qry.erate_date_source    is not null  then to_date(dex_qry.erate_date_source) 
# MAGIC     -- else null end
# MAGIC     -- as cp_erate_date,           --REQ-10
# MAGIC     
# MAGIC     
# MAGIC     case when B.credit_rating_code = 'P' or B.credit_rating_code = 'E' 
# MAGIC       then 'Y' else 'N' 
# MAGIC     end                   as cp_erate_flag, --erating
# MAGIC     
# MAGIC     case when B.credit_rating_code = 'P' or B.credit_rating_code = 'E' 
# MAGIC       then CAST(B.credit_rating_date  AS DATE)
# MAGIC       else CAST(Null  AS DATE) 
# MAGIC     end as cp_erate_date, --eratedate
# MAGIC     
# MAGIC     
# MAGIC     case when B.credit_rating_code = 'P' or B.credit_rating_code = 'E' 
# MAGIC       then 'Y' else 'N' 
# MAGIC     end                   as cp_erate_flag_in_source,           --REQ-9
# MAGIC     case when B.credit_rating_code = 'P' or B.credit_rating_code = 'E' 
# MAGIC       then CAST(B.credit_rating_date  AS DATE)
# MAGIC       else CAST(Null  AS DATE) 
# MAGIC     end as cp_erate_date_in_source,           --REQ-10
# MAGIC     cast(null as DATE)  as cp_erate_lifted_date_in_source,    --REQ-11
# MAGIC     APPV_BKR_IND          as cp_broker_indicator,               --REQ-86
# MAGIC     case when L1_ID_NEW is null 
# MAGIC       then L1_ID else L1_ID_NEW 
# MAGIC     end                   as cp_mapping_id,                     
# MAGIC     A.SOURCE_SYSTEM         as source_system,                     --Metadata Column       
# MAGIC     META_CREATED_DTTM     as meta_created_dttm                  --Metadata Column       
# MAGIC from vw_cp_master_dex A
# MAGIC --left join vw_bexcel_erate_dex as dex_qry on upper(trim(A.unique_id)) = dex_qry.unique_id or upper(trim(A.unique_id)) = dex_qry.unique_id2
# MAGIC left outer join vw_cp_master_erate_flag1 B on A.L1_ID = B.company_mnem

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty as
# MAGIC Select distinct
# MAGIC   
# MAGIC   gm.cp_unique_id as cp_unique_id,
# MAGIC   cp_l1_id as cp_legal_entity_id,
# MAGIC   cp_name as cp_name,
# MAGIC   cp_l2_id as cp_business_unit_id,
# MAGIC   cp_l2_name as cp_business_unit_name,
# MAGIC   cast(null as string) as cp_short_name,
# MAGIC   cp_created_or_updated_date as cp_created_date,
# MAGIC   cp_created_or_updated_date as cp_updated_date,
# MAGIC   cp_deactivated  as cp_deactivated,
# MAGIC   cp_erate_flag_in_source   as cp_erate_flag_source,
# MAGIC   cp_erate_date_in_source   as cp_erate_date_source,
# MAGIC   cp_erate_flag   as cp_erate_flag,
# MAGIC   cp_erate_date  as cp_erate_date,
# MAGIC   cp_etrm_account_no as cp_account_number,
# MAGIC   cp_mapping_id as cp_deal_mapping_id,
# MAGIC   current_timestamp as meta_created_ddtm,
# MAGIC   current_timestamp as meta_start_ddtm,
# MAGIC   to_date('2999-12-31', 'yyyy-MM-dd') as meta_end_ddtm,
# MAGIC   'Y' as active_indicator,
# MAGIC   'DEX' as source_system_code,
# MAGIC   date_format(current_date, 'yyyyMMdd') as  report_date_key
# MAGIC  
# MAGIC FROM
# MAGIC   vw_cp_master gm 

# COMMAND ----------

cp_df = spark.sql("select * from vw_counterparty")
cp_df = cp_df.drop_duplicates()
total_row_cnt = cp_df.count()
print (total_row_cnt)
cp_unique_id_df = cp_df.select(["cp_unique_id"])
cp_unique_id_df = cp_unique_id_df.drop_duplicates()
cp_unique_id_cnt= cp_unique_id_df.count()
print(cp_unique_id_cnt)
try:
  if total_row_cnt == cp_unique_id_cnt:
    RefreshCuratedSqlTbl('staging', 'counterparty', 'DEX')
except Exception as e:
  print("For DEX source system counterparty count vs unique_id cnt didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty', 'cp_data_hub', 'counterparty', 'DEX')

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['counterparty']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

cp_details_df = spark.sql("""
                          select distinct
                             gm.cp_unique_id               as cp_unique_id
                            ,cast(NULL as string)          as cp_company_code
                            ,cast(NULL as string)          as cp_company_name
                            ,cast(NULL as string)          as cp_country_code
                            ,gm.cp_country                 as cp_country_name
                            ,gm.cp_entity_type             as counterparty_type
                            ,current_timestamp               as meta_created_ddtm
                            ,current_timestamp               as meta_start_ddtm
                            ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                            ,'Y'                                   as active_indicator
                            ,'DEX'                         as source_system_code
                            ,date_format(current_date, 'yyyyMMdd') as  report_date_key
                           from vw_cp_master  gm
                           where gm.cp_country is not null
                           and length(gm.cp_country)>0
                          """)
#creating temp view
cp_details_df.createOrReplaceTempView("vw_counterparty_details")

# need to get the distinct unique_id counts
cp_details_cp_unique_id_cnt = cp_details_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_counterparty_details cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)                               
#load process
try:
  if cp_unique_id_cnt >= cp_details_cp_unique_id_cnt and cp_unique_id_not_in_cp_df.count()==0:
    print(f"""Count Match: {cp_unique_id_cnt} and {cp_details_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of counterparty_details is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'counterparty_details', 'DEX')
except Exception as e:
  print("For DEX source system counterparty count and counterparty Details unique_id didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details', 'cp_data_hub', 'counterparty_details', 'DEX')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details_summary as
# MAGIC   
# MAGIC 			select cpd.source_system_code
# MAGIC 			      ,cpd.cp_unique_id
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(counterparty_type))) as counterparty_type
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_code))) as cp_company_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_name))) as cp_company_name
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_code))) as cp_country_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_name))) as cp_country_name
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 				  from vw_counterparty_details cpd
# MAGIC 				  where cpd.source_system_code in ('DEX')
# MAGIC 			group by cpd.source_system_code, cpd.cp_unique_id
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details_summary', 'DEX')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details_summary', 'cp_data_hub', 'counterparty_details_summary', 'DEX')

# COMMAND ----------

bdg_cp_sap_account_df = spark.sql("""
                                 select distinct 
                                    gm.cp_unique_id               as cp_unique_id
                                   ,gm.cp_sap_unique_id              as sap_unique_id
                                   ,gm.cp_linked_sap_id             as sap_account_number
                                   ,gm.cp_sap_account_type           as sap_account_type
                                   ,gm.cp_linked_sap_system          as sap_source_system_code
                                   ,current_timestamp               as meta_created_ddtm
                                   ,current_timestamp               as meta_start_ddtm
                                   ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                                   ,'Y'                                   as active_indicator
                                   ,'DEX'                          as source_system_code
                                   ,date_format(current_date, 'yyyyMMdd') as  report_date_key 
                                from vw_cp_master gm
                                where gm.cp_sap_unique_id is not null and length(gm.cp_sap_unique_id) > 0
                                """)
#creating temp view
bdg_cp_sap_account_df.createOrReplaceTempView("vw_bridge_counterparty_sap_account")

# need to get the distinct unique_id counts
bdg_cp_sap_account_cp_unique_id_cnt = bdg_cp_sap_account_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
bdg_cp_sap_account_cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_bridge_counterparty_sap_account cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)
                                       
#load process
if cp_unique_id_cnt >= bdg_cp_sap_account_cp_unique_id_cnt and bdg_cp_sap_account_cp_unique_id_not_in_cp_df.count()==0:
  try:
  
    print(f"""Count Match: {cp_unique_id_cnt} and {bdg_cp_sap_account_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of bridge_counterparty_sap_account is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'bridge_counterparty_sap_account', 'DEX')
  
  except Exception as e:
    print("For ENERGY_CREDIT source system counterparty count and bridge_counterparty_sap_accnt cp_unique_id didn't match")
    raise dbutils.notebook.exit(e)
elif {cp_unique_id_cnt} < {bdg_cp_sap_account_cp_unique_id_cnt}: 
  print(f"""counterparty: {cp_unique_id_cnt}""")
  print(f"""bridge_counterparty_sap_account: {bdg_cp_sap_account_cp_unique_id_cnt}""")
  print("Count match is not working ")
else:
  print(f"""cp_unique_id exists in bridge counterparty sap account table but in counterparty table""")

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'bridge_counterparty_sap_account', 'cp_data_hub', 'bridge_counterparty_sap_account', 'DEX')

# COMMAND ----------

Source_System_Code = 'DEX'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
