# Databricks notebook source
# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# source_system , view_prefix_name  parameters to pass to the function
create_temp_views_per_source_system('GOLD_TIER_MI', 'gtmi')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_gt_compliance as 
# MAGIC 
# MAGIC select distinct 
# MAGIC    cc.GoldTier_ID                                   as gt_goldtier_id
# MAGIC   ,cc.Legal_Name                                    as gt_cust_legal_name
# MAGIC   ,cc.Legal_Country                                 as gt_cust_legal_country
# MAGIC   ,cc.Country_Of_Operations                         as gt_cust_country_of_operations
# MAGIC   ,cc.Policy_Status                                 as gt_cust_policy_status
# MAGIC --   ,cc.DD_Level_Approved                             as gt_cust_dd_level
# MAGIC   ,case when cc.DD_Level_Approved   is not null or length(trim(cc.DD_Level_Approved)) > 0 then cc.DD_Level_Approved
# MAGIC         when cc.Due_Diligence_Level is not null or length(trim(Due_Diligence_Level)) > 0  then cc.Due_Diligence_Level
# MAGIC         else cc.DD_Level_Override
# MAGIC    end                                              as gt_cust_dd_level
# MAGIC   ,cc.Entity_Type                                   as gt_entity_type
# MAGIC   ,cc.Approved_With_Conditions_Flag                 as gt_approved_with_conditions_flag
# MAGIC   ,cc.Approved_With_Condition_Remarks               as gt_approved_with_conditions_remarks
# MAGIC   ,cast(cc.Policy_Status_Date as timestamp)         as gt_cust_policy_status_date
# MAGIC   ,cast(cc.Policy_Approved_date as timestamp)       as gt_cust_policy_approved_date
# MAGIC   ,cast(cc.Policy_Last_Review_Date as timestamp)    as gt_cust_policy_last_review_date
# MAGIC   ,cast(cc.Policy_Next_Review_Date as timestamp)    as gt_cust_policy_next_review_date
# MAGIC   ,cc.Policy_Risk_Level                             as gt_cust_policy_risk_level
# MAGIC   ,cc.Sanctions_type                                as gt_sanctions_type
# MAGIC   ,cc.DNDB_List                                     as gt_dndb_list
# MAGIC   ,current_timestamp()                              as meta_created_ddtm
# MAGIC   ,current_timestamp()                              as meta_start_ddtm
# MAGIC   ,'9999-12-31'                                     as meta_end_ddtm
# MAGIC   ,'Y'                                              as active_indicator
# MAGIC   ,'GT'                                             as source_system_code
# MAGIC   ,date_format(current_timestamp(), 'yyyyMMdd')     as report_date_key
# MAGIC   
# MAGIC from gtmi_vw_mi_customer_core cc
# MAGIC   left join (select distinct cce.GoldTier_ID from gtmi_vw_mi_customer_core_extended cce 
# MAGIC              where cce.Record_Active_Flag = 'Y') cce 
# MAGIC     on cce.GoldTier_ID = cc.GoldTier_ID
# MAGIC   where cc.Record_Active_Flag = 'Y' 
# MAGIC     and cc.GoldTier_ID not in (select distinct GOLDTIER_ID from gtmi_R_CUST_ARCH_GT)

# COMMAND ----------

# DBTITLE 1,Refresh staging table
RefreshCuratedSqlTbl('staging', 'gt_compliance')

# COMMAND ----------

# DBTITLE 1,Switch partition from staging table to main table
#parameter seq: staging_schema, staging_table, target_schema, target_table, source_system_code
LoadCuratedTargetTbl('staging', 'gt_compliance', 'cp_data_hub', 'gt_compliance', 'GT')

# COMMAND ----------

Source_System_Code = 'GOLD_TIER_MI'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
