# Databricks notebook source
# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'[scpl].[CPTY_SCPL]')
df.createOrReplaceTempView(f"scpl")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_bridge_cp_goldtier_clcmapp as 
# MAGIC select 
# MAGIC   CptyGroupID as clcm_cust_group_id
# MAGIC   , ProjectName as clcm_project_name
# MAGIC   , DispositionDetail as clcm_disposition_detail
# MAGIC   , ReReviewsLiveKeepsProcess as clcm_rereviews_live_keeps_process
# MAGIC   , ReReviewsLiveBatch as clcm_rereviews_live_batch
# MAGIC   , GoldTierID as clcm_goldtier_id
# MAGIC   , CptyID as clcm_unique_id
# MAGIC   , current_timestamp() as meta_created_ddtm
# MAGIC   , current_timestamp() as meta_start_ddtm
# MAGIC   , '2999-12-31' as meta_end_ddtm
# MAGIC   , 1 as active_indicator
# MAGIC   , 'CLCM_APP' as source_system_code
# MAGIC   , date_format(current_timestamp(), 'yyyyMMdd') as report_date_key
# MAGIC   
# MAGIC   --Not needed in new table.
# MAGIC   --  , CptyName
# MAGIC   --, SystemUniquePrefix
# MAGIC   --, GT_LegalEntity
# MAGIC   --, GT_DDLevel
# MAGIC   --, GT_DDLevelApproved
# MAGIC   --, GT_PolicyStatus
# MAGIC   --, CptyUpdatedOn
# MAGIC   --, ErateDate
# MAGIC   --, EratedFlag
# MAGIC   --, DeactivatedFlag
# MAGIC   --, RecordStatusID
# MAGIC 
# MAGIC from scpl;

# COMMAND ----------

#df = spark.sql("select *  from vw_bridge_cp_goldtier_clcmapp")
#display(df)

# COMMAND ----------

# DBTITLE 1,Loading to SQL DB Curated
RefreshCuratedSqlTbl('staging', 'bridge_cp_goldtier_clcmapp')

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'bridge_cp_goldtier_clcmapp', 'cp_data_hub', 'bridge_cp_goldtier_clcmapp', 'CLCM_APP')

# COMMAND ----------

Source_System_Code = 'SCPL'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
