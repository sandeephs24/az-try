# Databricks notebook source
# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'[scpl].[cpty_vwscpl_lob]')
df.createOrReplaceTempView(f"cpty_vwscpl_lob")

# COMMAND ----------

# DBTITLE 1,Data preparation for bridge_cp_clcm_lob
# MAGIC %sql
# MAGIC create or replace temporary view vw_bridge_cp_clcm_lob as
# MAGIC select 
# MAGIC cptyid as clcm_cp_unique_id,
# MAGIC systemuniqueprefix as clcm_cp_source_system_code,
# MAGIC lineofbusiness as clcm_cp_line_of_business,
# MAGIC current_timestamp() as meta_created_ddtm,
# MAGIC current_timestamp() as meta_start_ddtm,
# MAGIC '2999-12-31' as meta_end_ddtm,
# MAGIC 1 as active_indicator,
# MAGIC 'CLCM_APP' as source_system_code,
# MAGIC date_format(current_timestamp(), 'yyyyMMdd') as report_date_key
# MAGIC from cpty_vwscpl_lob

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'bridge_cp_clcm_lob','CLCM_APP')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'bridge_cp_clcm_lob', 'cp_data_hub', 'bridge_cp_clcm_lob', 'CLCM_APP')
