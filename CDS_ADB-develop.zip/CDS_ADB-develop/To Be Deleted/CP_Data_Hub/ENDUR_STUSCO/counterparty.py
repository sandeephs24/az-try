# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 0,Get Parameters Values
create_temp_views_per_source_system('ENDUR_STUSCO', 'VW')

# COMMAND ----------

# DBTITLE 1,Read erate_salesforce data from curated tb
tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['erate_salesforce']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view erate_info as 
# MAGIC select distinct PARTY_ID, 'N' as flag from VW_PARTY_FUNCTION where Function_TYPE = 1 --erate flag logic

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_endur_canada_products as
# MAGIC select concat(coalesce(ple.party_id,''), 
# MAGIC        case when ple.party_id is null then '' else '_' end , coalesce(pbu.party_id,''))  AS CP_UNIQUE_ID,
# MAGIC --        cast (ple.party_id as string)    AS CP_LEGAL_ENTITY_ID the logic is not populating the legal entities in the legal_entities id
# MAGIC        case when pbu.party_class = 0 then cast(pbu.party_id as string) 
# MAGIC              else cast(ple.party_id as string) 
# MAGIC        end as CP_LEGAL_ENTITY_ID,
# MAGIC        ple.short_name  as CP_LEGAL_ENTITY_SHORT_NAME,
# MAGIC        case when ple.long_name is not null and trim(ple.long_name) != ''  then ple.long_name
# MAGIC             when ple.short_name is not null and trim(ple.short_name) != ''  then ple.short_name
# MAGIC             when pbu.long_name is not null and trim(pbu.long_name) != ''  then pbu.long_name
# MAGIC             else pbu.short_name
# MAGIC        end AS CP_LEGAL_ENTITY_NAME,
# MAGIC        cast(pbu.party_id as string)   AS CP_BUSINESS_UNIT_ID,
# MAGIC        pbu.short_name  as CP_BUSINESS_UNIT_SHORT_NAME,
# MAGIC        case when pbu.long_name is not null then pbu.long_name
# MAGIC             else pbu.short_name 
# MAGIC        end AS CP_BUSINESS_UNIT_NAME,
# MAGIC         concat(CASE WHEN pbu.int_ext = 0 THEN 'INT'
# MAGIC                     WHEN pbu.int_ext = 1 THEN 'EXT' 
# MAGIC                     ELSE 'UNKNOWN' 
# MAGIC                     END  ,
# MAGIC                 '_' ,
# MAGIC                 (CASE WHEN pbu.party_class = 0 THEN 'LE'
# MAGIC                       WHEN pbu.party_class = 1 THEN 'BU' 
# MAGIC                       ELSE 'UNKNOWN' 
# MAGIC                       END),
# MAGIC                  CASE when trim(right(replace(replace(trim(pbu.short_name),"-"," "),"_"," "),4)) in 
# MAGIC                 ("CRD","EXCH","LSE","MAR","NOC","OPR","PRD","RSK","TRSP") THEN
# MAGIC                 concat('_',trim(right(replace(replace(trim(pbu.short_name),"-"," "),"_"," "),4)))
# MAGIC                 ELSE ''
# MAGIC                 END )  AS cp_entity_type ,
# MAGIC        case when pbu.party_status in ( 1,0 ) then 'N'
# MAGIC             else 'Y' end as DEACTIVATED,
# MAGIC        cast(Null as timestamp)       AS CP_CREATE_DATE,
# MAGIC        cast(unix_timestamp(pbu.last_update, 'MM/dd/yyyy HH:mm:ss.SSS') as timestamp) as CP_LAST_UPDATE_DATE,
# MAGIC        pri.value                     AS SAP_ACCOUNT_NO,
# MAGIC        pbu.party_status              AS CP_SYSTEM_STATUS,
# MAGIC        'ENDUR_STUSCO'                AS SYSTEM,
# MAGIC        pri.Type                      AS SAP_ACCOUNT_TYPE,
# MAGIC        cle.name                      AS CP_REGISTERED_COUNTRY,
# MAGIC        'MSAP'                        AS LINKED_SAP_SYSTEM,
# MAGIC        current_timestamp as META_CREATED_DTTM,
# MAGIC        case
# MAGIC        when trim(pri.value) = ''
# MAGIC        or pri.value is null then null
# MAGIC        else 'MSAP' || '_' || regexp_replace(pri.Type,'SAP_','') || '_' || pri.value
# MAGIC        end as SAP_UNIQUE_ID,
# MAGIC        coalesce(ef.flag,'Y')                AS erate_flag, --PBI STUSCO
# MAGIC        to_date(NULL)                        AS erate_completion_date, --PBI STUSCO
# MAGIC        to_Date(NULL)                        AS erate_lift_date --PBI STUSCO
# MAGIC       FROM VW_PARTY pbu
# MAGIC       LEFT OUTER JOIN VW_BUSINESS_UNIT bu ON pbu.party_id = bu.party_id
# MAGIC       LEFT OUTER JOIN VW_PARTY_RELATIONSHIP pr ON pbu.party_id = pr.business_unit_id
# MAGIC       LEFT OUTER JOIN VW_LEGAL_ENTITY le ON pr.legal_entity_id = le.party_id
# MAGIC       LEFT OUTER JOIN VW_PARTY ple ON pr.legal_entity_id = ple.party_id
# MAGIC       LEFT OUTER JOIN VW_PARTY_FUNCTION pf ON ple.party_id = pf.party_id
# MAGIC       LEFT OUTER JOIN VW_COUNTRY cle ON le.country = cle.id_number
# MAGIC       LEFT OUTER JOIN VW_COUNTRY cbu ON bu.country = cbu.id_number
# MAGIC       LEFT OUTER JOIN VW_STATES sle ON le.state_id = sle.state_id
# MAGIC       LEFT OUTER JOIN VW_STATES sbu ON bu.state_id = sbu.state_id
# MAGIC       LEFT OUTER JOIN erate_info ef ON ef.PARTY_ID = pbu.PARTY_ID  ---PBI STUSCO
# MAGIC       LEFT OUTER JOIN (SELECT 'SAP_CUSTOMER' AS Type,  value, party_id
# MAGIC                        FROM VW_PARTY_INFO
# MAGIC                        WHERE type_id in (20001) 
# MAGIC                        UNION ALL
# MAGIC                        SELECT 'SAP_VENDOR' AS Type, value, party_id     
# MAGIC                        FROM VW_PARTY_INFO
# MAGIC                        WHERE type_id in (20002)) pri ON pri.party_id = bu.party_id

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_endur_canada_products_new as
# MAGIC select
# MAGIC   cprd.cp_unique_id,
# MAGIC   cprd.cp_legal_entity_id,
# MAGIC   cprd.cp_legal_entity_short_name,
# MAGIC   cprd.cp_legal_entity_name,
# MAGIC   cprd.cp_business_unit_id,
# MAGIC   cprd.cp_business_unit_short_name,
# MAGIC   cprd.cp_business_unit_name,
# MAGIC   cprd.cp_entity_type,
# MAGIC   cprd.deactivated,
# MAGIC   cprd.cp_create_date,
# MAGIC   cprd.cp_last_update_date,
# MAGIC   cprd.sap_account_no,
# MAGIC   cprd.cp_system_status,
# MAGIC   cprd.system,
# MAGIC   cprd.sap_account_type,
# MAGIC   cprd.CP_REGISTERED_COUNTRY,
# MAGIC   cprd.linked_sap_system,
# MAGIC   cprd.meta_created_dttm,
# MAGIC   cprd.sap_unique_id,
# MAGIC   case when cprd.cp_legal_entity_id =  cprd.cp_business_unit_id THEN NULL /*erate flag should be blank or null if cp_unique_id is legal_entity_id */ 
# MAGIC        else cprd.erate_flag  
# MAGIC   end as cp_erate_flag_source,
# MAGIC   case when cprd.cp_legal_entity_id =  cprd.cp_business_unit_id THEN NULL
# MAGIC        else to_date(cprd.erate_completion_date,'yyyy-MM-dd') 
# MAGIC   end as cp_erate_date_source,
# MAGIC   cprd.erate_lift_date,
# MAGIC   case when cprd.cp_legal_entity_id =  cprd.cp_business_unit_id THEN NULL 
# MAGIC        when cprd.erate_flag = 'Y' then 'Y'
# MAGIC        Else 'N'
# MAGIC   END as cp_erate_flag,
# MAGIC   case when cprd.cp_legal_entity_id =  cprd.cp_business_unit_id then to_date(null)
# MAGIC        when cprd.erate_flag = 'Y' then to_date(er.erate_completion_date, 'yyyy-MM-dd')
# MAGIC        else null
# MAGIC   end as cp_erate_date
# MAGIC from
# MAGIC   vw_cp_master_endur_canada_products cprd
# MAGIC   left join vw_cp_data_hub_erate_salesforce er
# MAGIC   on (
# MAGIC     cprd.cp_unique_id = er.cp_unique_id
# MAGIC     and er.source_system = 'ENDNA_CAN'
# MAGIC   )

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_endur_canada_products_new")
df.count()

# COMMAND ----------

from pyspark.sql.types import StringType, TimestampType
#from pyspark.sql.functions import regexp_replace as r
#sap_unique_id = concat(col('LINKED_SAP_SYSTEM'),lit('_'),r(col('SAP_ACCOUNT_TYPE'),'SAP_',''),lit('_'),col('SAP_ACCOUNT_NO'))
df_counterparty = df.select(concat(lit('ENDNA_CAN_'),col('CP_UNIQUE_ID')).alias('cp_unique_id'),
                         col('CP_LEGAL_ENTITY_ID').alias('cp_legal_entity_id'),
                         col('CP_LEGAL_ENTITY_NAME').alias('cp_name'),
                         col('CP_BUSINESS_UNIT_ID').alias('cp_business_unit_id'),
                         col('CP_BUSINESS_UNIT_NAME').alias('cp_business_unit_name'),
                         expr("case when length(trim(CP_BUSINESS_UNIT_SHORT_NAME)) >0 then  CP_BUSINESS_UNIT_SHORT_NAME when length(trim(CP_BUSINESS_UNIT_SHORT_NAME)) = 0 then CP_BUSINESS_UNIT_NAME when length(trim(CP_BUSINESS_UNIT_NAME)) = 0 then CP_LEGAL_ENTITY_SHORT_NAME  end").alias('cp_short_name'),
                         col('CP_CREATE_DATE').alias('cp_created_date'),
                         col('CP_LAST_UPDATE_DATE').alias('cp_updated_date'),
                         col('DEACTIVATED').alias('cp_deactivated'),
                         #lit(None).cast(StringType()).alias('cp_erate_flag_source'),
                         #lit(None).cast(TimestampType()).alias('cp_erate_date_source'),
                         #lit(None).cast(StringType()).alias('cp_erate_flag'),
                         #lit(None).cast(TimestampType()).alias('cp_erate_date'),
                         col('CP_ERATE_FLAG_SOURCE').alias('cp_erate_flag_source'),
                         col('CP_ERATE_DATE_SOURCE').alias('cp_erate_date_source'),
                         col('CP_ERATE_FLAG').alias('cp_erate_flag'),
                         col('CP_ERATE_DATE').alias('cp_erate_date'),   
                         col('CP_BUSINESS_UNIT_ID').alias('cp_account_number'),
                         col('CP_BUSINESS_UNIT_ID').alias('cp_deal_mapping_id'),
                         lit(current_timestamp()).cast(TimestampType()).alias('meta_created_ddtm'),
                         lit(current_timestamp()).cast(TimestampType()).alias('meta_start_ddtm'),
                         to_date(lit('2999-12-31'),'yyyy-MM-dd').alias("meta_end_ddtm"),
                         lit('Y').cast(StringType()).alias("active_indicator"),
                         lit('ENDUR_STUSCO').cast(StringType()).alias("source_system_code"),
                         date_format(current_timestamp(),'yyyyMMdd').alias('report_date_key'),
                        ).distinct()
                        

# COMMAND ----------

df_counterparty.createOrReplaceTempView(f"vw_counterparty")

# COMMAND ----------

cp_df = spark.sql("select * from vw_counterparty")
cp_df = cp_df.drop_duplicates()
total_row_cnt = cp_df.count()
print (total_row_cnt)
cp_unique_id_df = cp_df.select(["cp_unique_id"])
cp_unique_id_df = cp_unique_id_df.drop_duplicates()
cp_unique_id_cnt= cp_unique_id_df.count()
print(cp_unique_id_cnt)
try:
  if total_row_cnt == cp_unique_id_cnt:
    RefreshCuratedSqlTbl('staging', 'counterparty', 'ENDUR_STUSCO')
except Exception as e:
  print("For ENDUR_STUSCO source system counterparty count vs unique_id cnt didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty', 'cp_data_hub', 'counterparty', 'ENDUR_STUSCO')

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['counterparty']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

# DBTITLE 1,Counterparty Details
cp_details_df = spark.sql("""
                          select distinct
                             concat('ENDNA_CAN_',ecp.CP_UNIQUE_ID) as cp_unique_id
                            ,cast(NULL as string)            as cp_company_code
                            ,cast(NULL as string)            as cp_company_name
                            ,cast(NULL as string)            as cp_country_code
                            ,ecp.CP_REGISTERED_COUNTRY       as cp_country_name
                            ,ecp.cp_entity_type              as counterparty_type
                            ,current_timestamp               as meta_created_ddtm
                            ,current_timestamp               as meta_start_ddtm
                            ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                            ,'Y'                                   as active_indicator
                            ,'ENDUR_STUSCO'                        as source_system_code
                            ,date_format(current_date, 'yyyyMMdd') as  report_date_key
                           from vw_cp_master_endur_canada_products  ecp
                           where ecp.CP_REGISTERED_COUNTRY is not null
                           and length(ecp.CP_REGISTERED_COUNTRY)>0
                          """)
#creating temp view
cp_details_df.createOrReplaceTempView("vw_counterparty_details")

# need to get the distinct unique_id counts
cp_details_cp_unique_id_cnt = cp_details_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_counterparty_details cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)                               
#load process
if cp_unique_id_cnt >= cp_details_cp_unique_id_cnt and cp_unique_id_not_in_cp_df.count()==0:
  try:
    print(f"""Count Match: {cp_unique_id_cnt} and {cp_details_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of counterparty_details is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'counterparty_details', 'ENDUR_STUSCO')
  except Exception as e:
    print("For ENDUR_STUSCO source system counterparty count and counterparty Details unique_id didn't match")
    raise dbutils.notebook.exit(e)
else:
  print(f"""cp_unique_id not exists in counterparty details table but in counterparty table""")

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'counterparty_details', 'cp_data_hub', 'counterparty_details', 'ENDUR_STUSCO')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details_summary as
# MAGIC   
# MAGIC 	select cpd.source_system_code
# MAGIC 			      ,cpd.cp_unique_id
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(counterparty_type))) as counterparty_type
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_code))) as cp_company_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_name))) as cp_company_name
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_code))) as cp_country_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_name))) as cp_country_name
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 				  from vw_counterparty_details cpd
# MAGIC 				  where cpd.source_system_code in ('ENDUR_STUSCO')
# MAGIC 			group by cpd.source_system_code, cpd.cp_unique_id
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details_summary', 'ENDUR_STUSCO')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details_summary', 'cp_data_hub', 'counterparty_details_summary', 'ENDUR_STUSCO')

# COMMAND ----------

# DBTITLE 1,bridge_counterparty_sap_account
bdg_cp_sap_account_df = spark.sql("""
                                 select distinct 
                                    concat('ENDNA_CAN_',ecp.CP_UNIQUE_ID) as cp_unique_id
                                   ,ecp.SAP_UNIQUE_ID               as sap_unique_id
                                   ,ecp.SAP_ACCOUNT_NO              as sap_account_number
                                   ,replace(ecp.SAP_ACCOUNT_TYPE, 'SAP_' ,'') as sap_account_type
                                   ,ecp.LINKED_SAP_SYSTEM           as sap_source_system_code
                                   ,current_timestamp               as meta_created_ddtm
                                   ,current_timestamp               as meta_start_ddtm
                                   ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                                   ,'Y'                                   as active_indicator
                                   ,'ENDUR_STUSCO'                        as source_system_code
                                   ,date_format(current_date, 'yyyyMMdd') as  report_date_key 
                                from vw_cp_master_endur_canada_products  ecp
                                where ecp.SAP_UNIQUE_ID is not null and length(ecp.SAP_UNIQUE_ID) > 0
                                """)
#creating temp view
bdg_cp_sap_account_df.createOrReplaceTempView("vw_bridge_counterparty_sap_account")

# need to get the distinct unique_id counts
bdg_cp_sap_account_cp_unique_id_cnt = bdg_cp_sap_account_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
bdg_cp_sap_account_cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_bridge_counterparty_sap_account cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)
                                       
#load process
if cp_unique_id_cnt >= bdg_cp_sap_account_cp_unique_id_cnt and bdg_cp_sap_account_cp_unique_id_not_in_cp_df.count()==0:
  try:
  
    print(f"""Count Match: {cp_unique_id_cnt} and {bdg_cp_sap_account_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of bridge_counterparty_sap_account is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'bridge_counterparty_sap_account', 'ENDUR_STUSCO')
  
  except Exception as e:
    print("For ENDUR_STUSCO source system counterparty count and bridge_counterparty_sap_accnt cp_unique_id didn't match")
    raise dbutils.notebook.exit(e)
elif {cp_unique_id_cnt} < {bdg_cp_sap_account_cp_unique_id_cnt}: 
  print(f"""counterparty: {cp_unique_id_cnt}""")
  print(f"""bridge_counterparty_sap_account: {bdg_cp_sap_account_cp_unique_id_cnt}""")
  print("Count match is not working ")
else:
  print(f"""cp_unique_id exists in bridge counterparty sap account table but in counterparty table""")

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'bridge_counterparty_sap_account', 'cp_data_hub', 'bridge_counterparty_sap_account', 'ENDUR_STUSCO')

# COMMAND ----------

Source_System_Code = 'ENDUR_STUSCO'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
