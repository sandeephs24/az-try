# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 1,ADLS Staging and Target Paths of CP Data Hub Project
#parameterize base folder
dbutils.widgets.text("pm_adls_proj_folder", "P00004-TS-DEV")
v_adls_folder = dbutils.widgets.get("pm_adls_proj_folder")

#derive final paths
adls_file_path_full_src = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/staging/aligne/source_file/"
adls_file_path_tgt      = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/cp_data_hub/aligne/"
partition_by_cols_stg= ['source_system_code','report_date_key']
partition_by_cols_tgt = ["source_system_code"]

# COMMAND ----------

# DBTITLE 1,create views from the data source
#two views VW_V_DEAL_SUMMARY,VW_V_PHYS_DELIVERY will be created from the source file path
create_temp_views_per_source_system('ENDUR_STUSCO','VW')

# COMMAND ----------

#create_temp_views_per_source_system('ENDUR_CANADA_PRODUCTS', 'DBO')

# COMMAND ----------

# DBTITLE 1,View for refresh date
# MAGIC %sql
# MAGIC create or replace temporary view vw_refresh_date as
# MAGIC select max(to_timestamp(trade_date,'MM/dd/yyyy HH:mm:ss.SSS')) as refresh_date from vw_v_deal_summary

# COMMAND ----------

# DBTITLE 1,joining two views from the data scource
# MAGIC %sql
# MAGIC create or replace temporary view vw_phys_deal_summary as 
# MAGIC select distinct
# MAGIC   ds.i_le_name,
# MAGIC   ds.i_bu_name,
# MAGIC   ds.e_le_name,
# MAGIC   ds.e_bu_name,
# MAGIC   pd.e_bu_name as phy_bu_name,
# MAGIC   pd.e_le_name as phy_le_name,
# MAGIC --   case when ds.e_le_name is not null then ds.e_le_name else pd.e_le_name end le_name,
# MAGIC --   case when ds.e_bu_name is not null then ds.e_bu_name else pd.e_bu_name end bu_name,
# MAGIC --   case when pd.e_le_name is not null then pd.e_le_name else ds.e_le_name end p_le_name,
# MAGIC --   case when pd.e_bu_name is not null then pd.e_bu_name else ds.e_bu_name end p_bu_name,
# MAGIC    case when ds.e_le_name =  pd.e_le_name then ds.e_le_name 
# MAGIC         when  ds.e_le_name <> pd.e_le_name and ds.e_le_name like '%- LE%'  or ds.e_le_name like '%-LE%' then ds.e_le_name
# MAGIC         when  ds.e_le_name <> pd.e_le_name and pd.e_le_name like '%- LE%'  or pd.e_le_name like '%-LE%' then pd.e_le_name
# MAGIC         when ds.e_le_name <> pd.e_le_name and ds.e_le_name is not null then ds.e_le_name
# MAGIC         when ds.e_le_name <> pd.e_le_name and ds.e_le_name is null and pd.e_le_name is not null then pd.e_le_name
# MAGIC    end le_name_cal,
# MAGIC    case when ds.e_bu_name =  pd.e_bu_name then ds.e_bu_name 
# MAGIC         when  ds.e_bu_name <> pd.e_bu_name and  ds.e_bu_name not like '%- LE%'  or ds.e_bu_name not like '%-LE%' then ds.e_bu_name
# MAGIC         when  ds.e_bu_name <> pd.e_bu_name and  pd.e_bu_name not like '%- LE%'  or pd.e_bu_name not like '%-LE%' then pd.e_bu_name
# MAGIC         when ds.e_bu_name <> pd.e_bu_name and  ds.e_bu_name is not null then ds.e_bu_name
# MAGIC         when ds.e_bu_name <> pd.e_bu_name and  ds.e_bu_name is null and pd.e_bu_name is not null then pd.e_bu_name
# MAGIC    end bu_name_cal
# MAGIC   ,ds.i_pfolio_name as trading_desk
# MAGIC   ,to_timestamp(ds.trade_date,'MM/dd/yyyy HH:mm:ss.SSS') as trade_date --converitng to timestamp
# MAGIC   ,ds.trader
# MAGIC   --ds.contract_number
# MAGIC   ,ds.settle_date as activity_date
# MAGIC   ,ds.settle_date as prod_date
# MAGIC   ,ds.evergreen_flag
# MAGIC   ,ds.end_date
# MAGIC   ,pd.deliv_end_date as contract_end_date
# MAGIC   ,pd.deliv_end_date  
# MAGIC from vw_v_deal_summary as ds
# MAGIC inner join VW_V_PHYS_DELIVERY as pd on ds.deal_tracking_num = pd.deal_tracking_num
# MAGIC --  and ds.trade_date > '08/25/2020' --condtion should be based on trade date and delivery date
# MAGIC  --where (ds.settle_date > '12/31/2017' or ds.trade_date > '12/31/2017' or pd.deliv_end_date > '12/31/2017')

# COMMAND ----------

# MAGIC %sql create
# MAGIC or replace temporary view vw_phys_deal_summary_new as
# MAGIC select
# MAGIC   distinct ple.party_id as legal_entity_id,
# MAGIC   ple.long_name as legal_name,
# MAGIC   dlb.e_le_name,
# MAGIC   dlb.phy_le_name,
# MAGIC   pbu.party_id as business_unit_id,
# MAGIC   pbu.party_id as cp_deal_mapping_id,
# MAGIC   pbu.long_name as business_unit_name,
# MAGIC   dlb.e_bu_name,
# MAGIC   dlb.phy_bu_name,
# MAGIC   dlb.trading_desk,
# MAGIC   trade_date,
# MAGIC   trader,
# MAGIC   activity_date,
# MAGIC   prod_date,
# MAGIC   evergreen_flag,
# MAGIC   contract_end_date, --    pbu.long_name as business_name
# MAGIC   deliv_end_date,
# MAGIC   end_Date
# MAGIC from
# MAGIC   vw_phys_deal_summary dlb
# MAGIC   left join VW_PARTY ple on (
# MAGIC     upper(dlb.le_name_cal) = upper(ple.short_name)
# MAGIC     or upper(dlb.le_name_cal) = upper(ple.long_name)
# MAGIC     or upper(dlb.le_name_cal) = upper(concat(ple.short_name, ',', ple.long_name))
# MAGIC   )
# MAGIC   left join VW_PARTY pbu on (
# MAGIC     upper(dlb.bu_name_cal) = upper(pbu.short_name)
# MAGIC     or upper(dlb.bu_name_cal) = upper(pbu.long_name)
# MAGIC     or upper(dlb.bu_name_cal) = upper(concat(pbu.short_name, ',', pbu.long_name))
# MAGIC   ) --where
# MAGIC   -- e_le_name = 'AUTHENTIX, INC. - LE'
# MAGIC   --e_le_name <> phy_le_name

# COMMAND ----------

# DBTITLE 1,data preparation for deal counterparty summary
# MAGIC %sql create
# MAGIC or replace temporary view vw_deal_counterparty_new as
# MAGIC select
# MAGIC   distinct cp_deal_mapping_id,
# MAGIC   null as deal_trading_entity,
# MAGIC   e_le_name as deal_trading_entity_long_name,
# MAGIC   --check on this.
# MAGIC   trading_desk as deal_trading_desk,
# MAGIC   null as deal_buy_sell,
# MAGIC   null as deal_class,
# MAGIC   null as deal_product_type,
# MAGIC   null as deal_date_month_key,
# MAGIC   trader as deal_trader_name,
# MAGIC   null as deal_value_unit_of_measure,
# MAGIC   null as deal_volume_unit_of_measure,
# MAGIC   null as deal_notional_value,
# MAGIC   null as deal_notional_volume,
# MAGIC   /*case
# MAGIC       when activity_date is not null then activity_date
# MAGIC       when activity_date is null and contract_end_date is not null then contract_end_date
# MAGIC       else trade_date
# MAGIC     end latest_activity_date,*/
# MAGIC   --commented as latest activity date is not needed
# MAGIC   -- greatest(activity_date, trade_date) as latest_activity_date,
# MAGIC   -- check the condition here
# MAGIC   trade_date,
# MAGIC   deliv_end_date,
# MAGIC   end_date,
# MAGIC   contract_end_date as latest_delivery_date,
# MAGIC   current_timestamp as meta_created_dttm,
# MAGIC   current_timestamp as meta_start_dttm,
# MAGIC   cast('2999-12-31' as timestamp) as meta_end_dttm,
# MAGIC   'Y' as active_indicator,
# MAGIC   date_format(current_date, 'yyyyMMdd') as report_date_key
# MAGIC from
# MAGIC   vw_phys_deal_summary_new -- check the date filter condition

# COMMAND ----------

# DBTITLE 1,data for deal counterparty
# MAGIC %sql create
# MAGIC or replace temporary view vw_deal_counterparty as
# MAGIC select
# MAGIC   distinct 'ENDUR_STUSCO' as source_system_code,
# MAGIC   cp_deal_mapping_id,
# MAGIC   cast(null as string) as deal_trading_entity,
# MAGIC   e_le_name as deal_trading_entity_long_name,
# MAGIC   --check on this.
# MAGIC   trading_desk as deal_trading_desk,
# MAGIC   cast(null as string) as deal_buy_sell,
# MAGIC   cast(null as string) as deal_class,
# MAGIC   cast(null as string) as deal_product_type,
# MAGIC   cast(null as int) as deal_date_month_key,
# MAGIC   trader as deal_trader_name,
# MAGIC   cast(null as string) as deal_value_unit_of_measure,
# MAGIC   cast(null as string) as deal_volume_unit_of_measure,
# MAGIC   cast(null as float) as deal_notional_value,
# MAGIC   cast(null as float) as deal_notional_volume,
# MAGIC   --greatest(activity_date, trade_date) as latest_activity_date,
# MAGIC   -- check the condition here
# MAGIC   --contract_end_date as latest_delivery_date,
# MAGIC   current_timestamp as meta_created_dttm,
# MAGIC   current_timestamp as meta_start_dttm,
# MAGIC   cast('2999-12-31' as timestamp) as meta_end_dttm,
# MAGIC   'Y' as active_indicator,
# MAGIC   date_format(current_date, 'yyyyMMdd') as report_date_key
# MAGIC from
# MAGIC   vw_phys_deal_summary_new
# MAGIC   where cp_deal_mapping_id is not null  -- check the date filter condition

# COMMAND ----------

# DBTITLE 1,deriving date value for counterparty summary
# MAGIC %sql create
# MAGIC or replace temporary view vw_cp_latest_trade_dates as
# MAGIC select
# MAGIC   cp_deal_mapping_id,
# MAGIC   max(trade_date) as deal_lastest_trade_date, --new logic
# MAGIC   greatest (max(deliv_end_date), max(end_date)) as deal_latest_delivery_date ---new logic
# MAGIC   --max(latest_activity_date) as deal_lastest_trade_date,
# MAGIC   --max(latest_delivery_date) as deal_latest_delivery_date
# MAGIC from
# MAGIC   vw_deal_counterparty_new
# MAGIC group by
# MAGIC   cp_deal_mapping_id

# COMMAND ----------

# DBTITLE 1,deriving trader name for deal counterparty summary
# MAGIC %sql create
# MAGIC or replace temporary view vw_cp_concat_list_of_traders as
# MAGIC select
# MAGIC   dcp.cp_deal_mapping_id,
# MAGIC   ltd.deal_lastest_trade_date,
# MAGIC   concat_ws(
# MAGIC     ",",
# MAGIC     array_sort(collect_set(dcp.deal_trader_name))
# MAGIC   ) as deal_latest_trader_name
# MAGIC from
# MAGIC   vw_deal_counterparty_new dcp
# MAGIC   inner join vw_cp_latest_trade_dates ltd on dcp.cp_deal_mapping_id = ltd.cp_deal_mapping_id
# MAGIC   and dcp.trade_date = ltd.deal_lastest_trade_date
# MAGIC group by
# MAGIC   dcp.cp_deal_mapping_id,
# MAGIC   ltd.deal_lastest_trade_date

# COMMAND ----------

# DBTITLE 1,deal counterparty summary
# MAGIC %sql -- deal_summary
# MAGIC   create or replace temporary view vw_deal_counterparty_summary as
# MAGIC   select
# MAGIC   distinct 'ENDUR_STUSCO' as source_system_code,
# MAGIC   dc.cp_deal_mapping_id,
# MAGIC   clt.deal_lastest_trade_date as deal_latest_trade_date,
# MAGIC   ltd.deal_latest_delivery_date,
# MAGIC   clt.deal_latest_trader_name,
# MAGIC   current_timestamp as meta_created_dttm,
# MAGIC   current_timestamp as meta_start_dttm,
# MAGIC   cast('2999-12-31' as timestamp) as meta_end_dttm,
# MAGIC   'Y' as active_indicator,
# MAGIC   date_format(current_date, 'yyyyMMdd') as report_date_key
# MAGIC from
# MAGIC   vw_deal_counterparty dc
# MAGIC   left join vw_cp_concat_list_of_traders clt on dc.cp_deal_mapping_id = clt.cp_deal_mapping_id
# MAGIC   left join vw_cp_latest_trade_dates ltd on dc.cp_deal_mapping_id = ltd.cp_deal_mapping_id

# COMMAND ----------

# DBTITLE 0,Load data into staging.deal_counterparty table
RefreshCuratedSqlTbl('staging', 'deal_counterparty', 'ENDUR_STUSCO')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'deal_counterparty', 'cp_data_hub', 'deal_counterparty', 'ENDUR_STUSCO')

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'deal_counterparty_summary', 'ENDUR_STUSCO')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'deal_counterparty_summary', 'cp_data_hub', 'deal_counterparty_summary', 'ENDUR_STUSCO')

# COMMAND ----------

# DBTITLE 1,Function to update refresh date
RefreshDateP3('refresh_date','NULL','vw_refresh_date','ENDUR_STUSCO') 

# COMMAND ----------

Source_System_Code = 'ENDUR_STUSCO'
System ='P3'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
