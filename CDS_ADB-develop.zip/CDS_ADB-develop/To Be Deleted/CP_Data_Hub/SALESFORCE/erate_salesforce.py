# Databricks notebook source
# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 1,reading from Staging in case the output in the ingested table is blank
curated_schema_name= 'SFDC' 
curated_tables_list = ['E_Rate_All_Request__c']
for table_name in curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")   

# COMMAND ----------

# DBTITLE 1,erate_salesforce table in the curated table 
# MAGIC %sql
# MAGIC --logic for erate_salesforce table in the curated table 
# MAGIC create or replace temporary view vw_erate_salesforce as 
# MAGIC Select distinct 
# MAGIC        System_ID__c as cp_unique_id
# MAGIC       ,COUNTERPARTY_NAME as counterparty_name
# MAGIC       ,SYSTEM            as source_system
# MAGIC       ,case when upper(Request_Type__c) = 'E-RATE' Then 'Y' Else 'N' End erate_flag
# MAGIC       ,ERATE_COMPLETION_DATE as erate_completion_date
# MAGIC       ,current_timestamp as meta_created_ddtm
# MAGIC       ,current_timestamp as meta_start_ddtm
# MAGIC       ,to_date('2999-12-31', 'yyyy-MM-dd') as meta_end_ddtm
# MAGIC       ,'Y' as active_indicator
# MAGIC       ,'SALESFORCE' as source_system_code
# MAGIC       ,date_format(current_date, 'yyyyMMdd') as  report_date_key
# MAGIC  
# MAGIC from ( 
# MAGIC select System_ID__c, Counterparty_Name__c as COUNTERPARTY_NAME,
# MAGIC                            Latest_Actioned_Date__C,
# MAGIC                            Date_Actioned_DD_MM_YYYY__c,
# MAGIC                            cast(UNIX_TIMESTAMP(er.e_rate_completion_date__c , "yyyy/MM/dd") as timestamp) as ERATE_COMPLETION_DATE,
# MAGIC                            Latest_Actioned_Request_Type__c,
# MAGIC                            Request_Type__c,
# MAGIC                            System_Group__c,
# MAGIC                            Comments__c,
# MAGIC                            Request_Info__c,
# MAGIC                            Request_Status__c,
# MAGIC                            Request_Reason__c,
# MAGIC                            er.system__c as SYSTEM,
# MAGIC                            --case when Request_Type__c = 'E-Rate' or Request_Type__c not in('Lift E-Rate', 'Deactivate') then 'Y' ELSE 'N' END erate_flag,
# MAGIC                            ROW_NUMBER() OVER (PARTITION BY System_ID__c  ORDER BY Latest_Actioned_Date__c DESC, Date_Actioned_DD_MM_YYYY__c  DESC  ) as ROW_NUM
# MAGIC                            FROM vw_SFDC_E_Rate_All_Request__c er 
# MAGIC                            -- er.System_ID__c = 'IMOS_SONAGAS'
# MAGIC                            where Request_Type__c  not in ('Deactivate', 'Reactivate')
# MAGIC                            ANd Request_Status__c in ('Completed','Previously Actioned')
# MAGIC )qry where ROW_NUM =1 and upper(Request_Type__c) = 'E-RATE'

# COMMAND ----------

# DBTITLE 1,Refreshing the Staging Table "erate_salesforce"
RefreshCuratedSqlTbl('staging', 'erate_salesforce')

# COMMAND ----------

# DBTITLE 1,switch partition from staging table to target table in curated DB.
#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'erate_salesforce', 'cp_data_hub', 'erate_salesforce', 'SALESFORCE')

# COMMAND ----------

Source_System_Code = 'SALESFORCE'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
