# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

curated_schema_name= 'ENDUR' 
curated_tables_list = ['ENDNA_CRUDE_ACTIVITY']
for table_name in curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")

# COMMAND ----------

# DBTITLE 1,Read erate_salesforce data from curated tb
tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['erate_salesforce']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

# MAGIC %sql
# MAGIC --To get separate records where SAP Account No. is for Customer
# MAGIC create or replace temporary view vw_cp_master_crude_customer as 
# MAGIC select distinct system,
# MAGIC cpty_id as cp_unique_id,
# MAGIC cpty_bunit_id as cp_business_unit_id,
# MAGIC cpty_legal_entity_id  as cp_legal_entity_id,
# MAGIC cpty_legal_entity_long_name as cp_legal_entity_name,
# MAGIC cpty_legal_name as cpty_legal_name,  ---change back to the cpty_legal_name mapping to cp_name, according Brindha on 4/29 , Changed by RK
# MAGIC case when length(trim(cpty_bunit_short_name)) >0 then cpty_bunit_short_name
# MAGIC when length(trim(cpty_bunit_short_name)) = 0 then cpty_bunit_long_name
# MAGIC when length(trim(cpty_bunit_long_name)) = 0 then cpty_legal_entity_short_name
# MAGIC end as cp_short_name,
# MAGIC case when cpty_deactivated_flag = 'Y' 
# MAGIC   then 'Y' else 'N' 
# MAGIC end as cp_deactivation_flag,
# MAGIC cpty_sap_customer_no as sap_account_no,
# MAGIC 'Customer' as sap_account_type,
# MAGIC concat('TSAP_Customer_',cpty_sap_customer_no) as sap_unique_id,
# MAGIC 'TSAP' as linked_sap_system,
# MAGIC concat(
# MAGIC (
# MAGIC   case when cpty_entity_type='Internal' 
# MAGIC     then 'INT'
# MAGIC   when cpty_entity_type='External' 
# MAGIC    then 'EXT' else 'UNKNOWN' end
# MAGIC ), '_BU',
# MAGIC (
# MAGIC   case when trim(right(replace(replace(trim(cpty_bunit_short_name),'-',' '),'_',' '),4)) in ('CRD','EXCH','LSE','MAR','NOC','OPR','PRD','RSK','TRSP') 
# MAGIC     then concat('_',trim(right(replace(replace(trim(cpty_bunit_short_name),'-',' '),'_',' '),4)))
# MAGIC   else '' end
# MAGIC )
# MAGIC ) as cp_entity_type,
# MAGIC --cpty_bunit_long_name  as cp_business_unit_name,
# MAGIC cpty_legal_name as cp_business_unit_name,
# MAGIC cpty_erated_flag as erate_flag,
# MAGIC --cast(cpty_create_date as Timestamp) as cp_create_date,
# MAGIC case when length(cpty_create_date) = 8 then cast(to_date(cpty_create_date,"M/d/yyyy") as timestamp)   --added logic on 13/4/22 to populate cp_create_date
# MAGIC      when length(cpty_create_date) = 10 then cast(to_date(cpty_create_date,"MM/dd/yyyy") as timestamp)--create date
# MAGIC      when length(cpty_create_date) = 9 then 
# MAGIC          (
# MAGIC              case when substring(cpty_create_date,1,2) like '%/' then cast(to_date(cpty_create_date,"M/dd/yyyy") as timestamp)
# MAGIC              else cast(to_date(cpty_create_date,"MM/d/yyyy") as timestamp) end
# MAGIC          )
# MAGIC end as cp_create_date,
# MAGIC cast(cpty_update_date as Timestamp) as cp_last_update_date,
# MAGIC 'ENDUR_OIL' as source_system,
# MAGIC current_timestamp as meta_created_dttm
# MAGIC from vw_ENDUR_ENDNA_CRUDE_ACTIVITY
# MAGIC where cpty_sap_customer_no is not null;

# COMMAND ----------

# MAGIC %sql
# MAGIC --To get separate records where SAP Account No. is for Vendor
# MAGIC create or replace temporary view vw_cp_master_crude_vendor as 
# MAGIC select distinct system,
# MAGIC cpty_id as cp_unique_id,
# MAGIC cpty_bunit_id as cp_business_unit_id,
# MAGIC cpty_legal_entity_id  as cp_legal_entity_id,
# MAGIC cpty_legal_entity_long_name as cp_legal_entity_name,
# MAGIC cpty_legal_name as cpty_legal_name, ---change back to the cpty_legal_name mapping to cp_name, according Brindha on 4/29 , Changed by RK
# MAGIC case when length(trim(cpty_bunit_short_name)) >0 then cpty_bunit_short_name
# MAGIC when length(trim(cpty_bunit_short_name)) = 0 then cpty_bunit_long_name
# MAGIC when length(trim(cpty_bunit_long_name)) = 0 then cpty_legal_entity_short_name
# MAGIC end as cp_short_name,
# MAGIC case when cpty_deactivated_flag = 'Y' 
# MAGIC   then 'Y' else 'N' 
# MAGIC end as cp_deactivation_flag,
# MAGIC cpty_sap_vendor_no as sap_account_no,
# MAGIC 'Vendor' as sap_account_type,
# MAGIC concat('TSAP_Vendor_',cpty_sap_vendor_no) as sap_unique_id,
# MAGIC 'TSAP' as linked_sap_system,
# MAGIC concat(
# MAGIC (
# MAGIC   case when cpty_entity_type='Internal' 
# MAGIC     then 'INT'
# MAGIC   when cpty_entity_type='External' 
# MAGIC    then 'EXT' else 'UNKNOWN' end
# MAGIC ), '_BU',
# MAGIC (
# MAGIC   case when trim(right(replace(replace(trim(cpty_bunit_short_name),'-',' '),'_',' '),4)) in ('CRD','EXCH','LSE','MAR','NOC','OPR','PRD','RSK','TRSP') 
# MAGIC     then concat('_',trim(right(replace(replace(trim(cpty_bunit_short_name),'-',' '),'_',' '),4)))
# MAGIC   else '' end
# MAGIC )
# MAGIC ) as cp_entity_type,
# MAGIC --cpty_bunit_long_name  as cp_business_unit_name,
# MAGIC cpty_legal_name as cp_business_unit_name,
# MAGIC cpty_erated_flag as erate_flag,
# MAGIC --cast(cpty_create_date as Timestamp) as cp_create_date,
# MAGIC case when length(cpty_create_date) = 8 then cast(to_date(cpty_create_date,"M/d/yyyy") as timestamp)   --added logic on 13/4/22 to populate cp_create_date
# MAGIC      when length(cpty_create_date) = 10 then cast(to_date(cpty_create_date,"MM/dd/yyyy") as timestamp)
# MAGIC      when length(cpty_create_date) = 9 then 
# MAGIC          (
# MAGIC              case when substring(cpty_create_date,1,2) like '%/' then cast(to_date(cpty_create_date,"M/dd/yyyy") as timestamp)
# MAGIC              else cast(to_date(cpty_create_date,"MM/d/yyyy") as timestamp) end
# MAGIC          )
# MAGIC end as cp_create_date,
# MAGIC cast(cpty_update_date as Timestamp) as cp_last_update_date,
# MAGIC 'ENDUR_OIL' as source_system,
# MAGIC current_timestamp as meta_created_dttm
# MAGIC from vw_ENDUR_ENDNA_CRUDE_ACTIVITY
# MAGIC where cpty_sap_vendor_no is not null;

# COMMAND ----------

# MAGIC %sql
# MAGIC --To get separate records where SAP Account No. is for blank
# MAGIC create or replace temporary view vw_cp_master_crude as 
# MAGIC select distinct system,
# MAGIC cpty_id as cp_unique_id,
# MAGIC cpty_bunit_id as cp_business_unit_id,
# MAGIC cpty_legal_entity_id  as cp_legal_entity_id,
# MAGIC cpty_legal_entity_long_name as cp_legal_entity_name,
# MAGIC cpty_legal_name as cpty_legal_name,  ---change back to the cpty_legal_name mapping to cp_name, according Brindha on 4/29 , Changed by RK
# MAGIC case when length(trim(cpty_bunit_short_name)) >0 then cpty_bunit_short_name
# MAGIC when length(trim(cpty_bunit_short_name)) = 0 then cpty_bunit_long_name
# MAGIC when length(trim(cpty_bunit_long_name)) = 0 then cpty_legal_entity_short_name
# MAGIC end as cp_short_name,
# MAGIC case when cpty_deactivated_flag = 'Y' 
# MAGIC   then 'Y' else 'N' 
# MAGIC end as cp_deactivation_flag,
# MAGIC '' as sap_account_no,
# MAGIC '' as sap_account_type,
# MAGIC '' as sap_unique_id,
# MAGIC '' as linked_sap_system,
# MAGIC concat(
# MAGIC (
# MAGIC   case when cpty_entity_type='Internal' 
# MAGIC     then 'INT'
# MAGIC   when cpty_entity_type='External' 
# MAGIC    then 'EXT' else 'UNKNOWN' end
# MAGIC ), '_BU',
# MAGIC (
# MAGIC   case when trim(right(replace(replace(trim(cpty_bunit_short_name),'-',' '),'_',' '),4)) in ('CRD','EXCH','LSE','MAR','NOC','OPR','PRD','RSK','TRSP') 
# MAGIC     then concat('_',trim(right(replace(replace(trim(cpty_bunit_short_name),'-',' '),'_',' '),4)))
# MAGIC   else '' end
# MAGIC )
# MAGIC ) as cp_entity_type,
# MAGIC --cpty_bunit_long_name  as cp_business_unit_name,
# MAGIC cpty_legal_name as cp_business_unit_name,
# MAGIC cpty_erated_flag as erate_flag,
# MAGIC --cast(cpty_create_date as Timestamp) as cp_create_date,
# MAGIC case when length(cpty_create_date) = 8 then cast(to_date(cpty_create_date,"M/d/yyyy") as timestamp)   --added logic on 13/4/22 to populate cp_create_date
# MAGIC      when length(cpty_create_date) = 10 then cast(to_date(cpty_create_date,"MM/dd/yyyy") as timestamp)
# MAGIC      when length(cpty_create_date) = 9 then 
# MAGIC          (
# MAGIC              case when substring(cpty_create_date,1,2) like '%/' then cast(to_date(cpty_create_date,"M/dd/yyyy") as timestamp)
# MAGIC              else cast(to_date(cpty_create_date,"MM/d/yyyy") as timestamp) end
# MAGIC          )
# MAGIC end as cp_create_date,
# MAGIC cast(cpty_update_date as Timestamp) as cp_last_update_date,
# MAGIC 'ENDUR_OIL' as source_system,
# MAGIC current_timestamp as meta_created_dttm
# MAGIC from vw_ENDUR_ENDNA_CRUDE_ACTIVITY
# MAGIC where cpty_sap_customer_no is null and cpty_sap_vendor_no is null;

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_endur_crude as 
# MAGIC select * from vw_cp_master_crude_customer
# MAGIC union all
# MAGIC select * from vw_cp_master_crude_vendor
# MAGIC union all
# MAGIC select * from vw_cp_master_crude

# COMMAND ----------

# MAGIC %sql create
# MAGIC or replace temporary view vw_counterparty as
# MAGIC select
# MAGIC   distinct cpc.cp_unique_id as cp_unique_id,
# MAGIC   cpc.cp_legal_entity_id as cp_legal_entity_id,
# MAGIC   cpc.cpty_legal_name as cp_name,
# MAGIC   cpc.cp_business_unit_id as cp_business_unit_id,
# MAGIC   case
# MAGIC     when length(trim(crd.cpty_bunit_short_name)) > 0 then crd.cpty_bunit_short_name
# MAGIC     when length(trim(crd.cpty_bunit_short_name)) = 0 then cpc.cp_business_unit_name
# MAGIC     when length(trim(cpc.cp_business_unit_name)) = 0 then crd.cpty_legal_entity_short_name
# MAGIC   end as cp_business_unit_name,
# MAGIC   case
# MAGIC     when length(trim(crd.cpty_bunit_short_name)) > 0 then crd.cpty_bunit_short_name
# MAGIC     when length(trim(crd.cpty_bunit_short_name)) = 0 then cpc.cp_business_unit_name
# MAGIC     when length(trim(cpc.cp_business_unit_name)) = 0 then crd.cpty_legal_entity_short_name
# MAGIC   end as cp_short_name,
# MAGIC   cpc.cp_create_date as cp_created_date,
# MAGIC   cpc.cp_last_update_date as cp_updated_date,
# MAGIC   cpc.cp_deactivation_flag as cp_deactivated,
# MAGIC   cpc.erate_flag as cp_erate_flag_source,
# MAGIC   cast(null as timestamp) as cp_erate_date_source,
# MAGIC   case
# MAGIC     when cpc.erate_flag = 'Y' then 'Y'
# MAGIC     else 'N'
# MAGIC   end as cp_erate_flag,
# MAGIC   case
# MAGIC     when cpc.erate_flag = 'Y' then to_date(er.erate_completion_date, 'yyyy-MM-dd')
# MAGIC     else null
# MAGIC   end as cp_erate_date,
# MAGIC   cpc.cp_legal_entity_id as cp_account_number,
# MAGIC   cpc.cp_unique_id as cp_deal_mapping_id,
# MAGIC   current_timestamp as meta_created_ddtm,
# MAGIC   current_timestamp as meta_start_ddtm,
# MAGIC   to_date('2999-12-31', 'yyyy-MM-dd') as meta_end_ddtm,
# MAGIC   'Y' as active_indicator,
# MAGIC   'ENDUR_OIL' as source_system_code,
# MAGIC   date_format(current_date, 'yyyyMMdd') as report_date_key
# MAGIC from
# MAGIC   vw_cp_master_endur_crude cpc
# MAGIC   join vw_ENDUR_ENDNA_CRUDE_ACTIVITY crd on cpc.cp_unique_id = crd.cpty_id
# MAGIC   left join vw_cp_data_hub_erate_salesforce er on (
# MAGIC     cpc.cp_unique_id = er.cp_unique_id
# MAGIC     and er.source_system = 'ENDNA_CRUDE'
# MAGIC   )

# COMMAND ----------

# DBTITLE 1,Counterparty
df = spark.sql("select * from vw_counterparty")
df = df.drop_duplicates()
total_row_cnt = df.count()
print (total_row_cnt)
cp_unique_id_df = df.select(["cp_unique_id"])
cp_unique_id_df = cp_unique_id_df.drop_duplicates()
cp_unique_id_cnt= cp_unique_id_df.count()
print(cp_unique_id_cnt)
try:
  if total_row_cnt == cp_unique_id_cnt:
    RefreshCuratedSqlTbl('staging', 'counterparty', 'ENDUR_OIL')
except Exception as r:
  print("For ENDUR_OIL source system counterparty count vs unique_id cnt didn't match")
  raise dbutils.notebook.exit(e)
  

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty', 'cp_data_hub', 'counterparty', 'ENDUR_OIL')

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['counterparty']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

# DBTITLE 1,Counterparty_details
cp_details_df = spark.sql("""
                          select distinct
                            cpc.cp_unique_id               as cp_unique_id 
                            ,cast(NULL as string)          as cp_company_code
                            ,cast(NULL as string)          as cp_company_name
                            ,cast(NULL as string)          as cp_country_code
                            ,cast(NULL as string)          as cp_country_name
                            ,cpc.cp_entity_type            as counterparty_type
                            ,current_timestamp             as meta_created_ddtm
                            ,current_timestamp             as meta_start_ddtm
                            ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                            ,'Y'                                   as active_indicator
                            ,'ENDUR_OIL'                      as source_system_code
                            ,date_format(current_date, 'yyyyMMdd') as  report_date_key
                           from vw_cp_master_endur_crude cpc
                          """)
#creating temp view
cp_details_df.createOrReplaceTempView("vw_counterparty_details")

# need to get the distinct unique_id counts
cp_details_cp_unique_id_cnt = cp_details_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_counterparty_details cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)                               
#load process
try:
  if cp_unique_id_cnt >= cp_details_cp_unique_id_cnt and cp_unique_id_not_in_cp_df.count()==0:
    print(f"""Count Match: {cp_unique_id_cnt} and {cp_details_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of counterparty_details is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'counterparty_details', 'ENDUR_OIL')
except Exception as e:
  print("For ENDUR_OIL source system counterparty count and counterparty Details unique_id didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'counterparty_details', 'cp_data_hub', 'counterparty_details', 'ENDUR_OIL')

# COMMAND ----------

# DBTITLE 1,Counterparty_details_summary
# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details_summary as
# MAGIC   
# MAGIC 			select cpd.source_system_code
# MAGIC 			      ,cpd.cp_unique_id
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(counterparty_type))) as counterparty_type
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_code))) as cp_company_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_name))) as cp_company_name
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_code))) as cp_country_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_name))) as cp_country_name
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 				  from vw_counterparty_details cpd
# MAGIC 				  where cpd.source_system_code in ('ENDUR_OIL')
# MAGIC 			group by cpd.source_system_code, cpd.cp_unique_id
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details_summary', 'ENDUR_OIL')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details_summary', 'cp_data_hub', 'counterparty_details_summary', 'ENDUR_OIL')

# COMMAND ----------

# DBTITLE 1,bridge_counterparty_sap_account
bdg_cp_sap_account_df = spark.sql("""
                                 select distinct 
                                    cpc.cp_unique_id               as cp_unique_id
                                   ,cpc.sap_unique_id              as sap_unique_id
                                   ,cpc.sap_account_no             as sap_account_number
                                   ,cpc.sap_account_type           as sap_account_type
                                   ,cpc.linked_sap_system          as sap_source_system_code
                                   ,current_timestamp               as meta_created_ddtm
                                   ,current_timestamp               as meta_start_ddtm
                                   ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                                   ,'Y'                                   as active_indicator
                                   ,'ENDUR_OIL'                          as source_system_code
                                   ,date_format(current_date, 'yyyyMMdd') as  report_date_key 
                                from vw_cp_master_endur_crude cpc
                                where cpc.sap_unique_id is not null and length(cpc.sap_unique_id) > 0
                                """)
#creating temp view
bdg_cp_sap_account_df.createOrReplaceTempView("vw_bridge_counterparty_sap_account")

# need to get the distinct unique_id counts
bdg_cp_sap_account_cp_unique_id_cnt = bdg_cp_sap_account_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
bdg_cp_sap_account_cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_bridge_counterparty_sap_account cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)
                                       
#load process
if cp_unique_id_cnt >= bdg_cp_sap_account_cp_unique_id_cnt and bdg_cp_sap_account_cp_unique_id_not_in_cp_df.count()==0:
  try:
  
    print(f"""Count Match: {cp_unique_id_cnt} and {bdg_cp_sap_account_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of bridge_counterparty_sap_account is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'bridge_counterparty_sap_account', 'ENDUR_OIL')
  
  except Exception as e:
    print("For ENDUR_OIL source system counterparty count and bridge_counterparty_sap_accnt cp_unique_id didn't match")
    raise dbutils.notebook.exit(e)
elif {cp_unique_id_cnt} < {bdg_cp_sap_account_cp_unique_id_cnt}: 
  print(f"""counterparty: {cp_unique_id_cnt}""")
  print(f"""bridge_counterparty_sap_account: {bdg_cp_sap_account_cp_unique_id_cnt}""")
  print("Count match is not working ")
else:
  print(f"""cp_unique_id exists in bridge counterparty sap account table but in counterparty table""")

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'bridge_counterparty_sap_account', 'cp_data_hub', 'bridge_counterparty_sap_account', 'ENDUR_OIL')

# COMMAND ----------

Source_System_Code = 'ENDUR_OIL'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
