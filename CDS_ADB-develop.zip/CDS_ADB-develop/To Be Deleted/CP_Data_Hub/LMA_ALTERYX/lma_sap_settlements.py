# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %sql SET spark.sql.adaptive.coalescePartitions.enabled=true

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

schema_name= 'bexcel'
if dbDatabase_curated != 'shell-01-eun-sqdb-lnqlphzqpfhtavofltjy':  # sql curated uat server for test environment need to use cp_data_cp_trans_stg_uat and rest of env cp_data_cp_trans_stg
    selfservice_tables_list  = ['cpdata_cp_master_stg', 'cpdata_cp_trans_stg', 'cpdata_sap_master_stg', 'cpdata_sap_trans_stg']
else:
    selfservice_tables_list  = ['cpdata_cp_master_stg', 'cpdata_cp_trans_stg_uat', 'cpdata_sap_master_stg', 'cpdata_sap_trans_stg']

for table_name in selfservice_tables_list:
    if table_name == 'cpdata_cp_trans_stg_uat':
      df = spark.read.jdbc(SS_sqldb_URL, table=f'bexcel.{table_name}')
      df.createOrReplaceTempView(f'vw_cpdata_cp_trans_stg')
      print(f'vw_cpdata_cp_trans_stg')
    else:
      df = spark.read.jdbc(SS_sqldb_URL, table=f'bexcel.{table_name}')
      df.createOrReplaceTempView(f'vw_{table_name}')
      print(f'vw_{table_name}')

# COMMAND ----------

df = spark.sql("select SYSTEM from vw_cpdata_sap_trans_stg")
df = df.drop_duplicates()
df.sort('system').show(20)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace TEMPORARY view vw_lma_sap_settlements
# MAGIC as 
# MAGIC select str.`System`  as source_system_code
# MAGIC       ,str.UNIQUE_ID as cp_unique_id
# MAGIC       ,date_format(str.posting_month,'yyyyMMdd') as sap_posting_month_key
# MAGIC       ,str.Transacted_Company_Code               as sap_transacted_company_code
# MAGIC       --,str.Latest_Settlement_Date                as sap_latest_settlement_date
# MAGIC       ,cast(str.Latest_Settlement_Date as date)    as sap_latest_settlement_date
# MAGIC       ,str.`Settlement Currency`                 as sap_settlement_loc_currency
# MAGIC       ,sum(cast(str.`Settlement Value (AP/AR LC)` as DECIMAL(30,5)))         as sap_settlement_value_ap_or_ar_lc
# MAGIC       ,current_timestamp                       as meta_created_ddtm
# MAGIC       ,current_timestamp                       as meta_start_ddtm
# MAGIC       ,to_date('2999-12-31', 'yyyy-MM-dd')     as meta_end_ddtm
# MAGIC       ,'Y'                                     as active_indicator
# MAGIC       ,date_format(current_date, 'yyyyMMdd')   as report_date_key
# MAGIC from vw_cpdata_sap_trans_stg str
# MAGIC group by str.`System` ,str.UNIQUE_ID , date_format(str.posting_month,'yyyyMMdd'),str.Transacted_Company_Code, str.Latest_Settlement_Date, str.`Settlement Currency` ,str.`Settlement Value (AP/AR LC)`

# COMMAND ----------

df = spark.sql("select source_system_code from vw_lma_sap_settlements")
df = df.drop_duplicates()
df.sort('source_system_code').show(20)

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'lma_sap_settlements')

# COMMAND ----------

source_system_code_list = [row[0] for row in df[["source_system_code"]].drop_duplicates().collect()] #list comprehension for getting source_system_codes

#loop through each source code and then alter the partition from staging
for source_system_code in source_system_code_list:
    print(source_system_code)
    LoadCuratedTargetTbl('staging', 'lma_sap_settlements', 'cp_data_hub', 'lma_sap_settlements', source_system_code)

# COMMAND ----------


