# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %sql SET spark.sql.adaptive.coalescePartitions.enabled=true

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

print(dbDatabase_curated)

# COMMAND ----------

# DBTITLE 1,Alteryx O/P files reading from Self-Service
schema_name= 'bexcel'
if dbDatabase_curated != 'shell-01-eun-sqdb-lnqlphzqpfhtavofltjy':  # sql curated uat server for test environment need to use cp_data_cp_trans_stg_uat and rest of env cp_data_cp_trans_stg
    selfservice_tables_list  = ['cpdata_cp_master_stg', 'cpdata_cp_trans_stg', 'cpdata_sap_master_stg', 'cpdata_sap_trans_stg']
else:
    selfservice_tables_list  = ['cpdata_cp_master_stg', 'cpdata_cp_trans_stg_uat', 'cpdata_sap_master_stg', 'cpdata_sap_trans_stg']

for table_name in selfservice_tables_list:
    if table_name == 'cpdata_cp_trans_stg_uat':
      df = spark.read.jdbc(SS_sqldb_URL, table=f'bexcel.{table_name}') 
      df.createOrReplaceTempView(f'vw_cpdata_cp_trans_stg')
      print(f'vw_cpdata_cp_trans_stg')
    else:
      df = spark.read.jdbc(SS_sqldb_URL, table=f'bexcel.{table_name}')
      df.createOrReplaceTempView(f'vw_{table_name}')
      print(f'vw_{table_name}')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- select * from vw_cpdata_cp_trans_stg

# COMMAND ----------

df = spark.sql("select SYSTEM from vw_cpdata_cp_trans_stg")
df = df.drop_duplicates()
df.sort('system').show(20)

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['counterparty']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

# DBTITLE 1,lma_deal_counterparty
deal_tran_df = spark.sql("""select
                               case when tr.system = 'ALIGNE' THEN 'ALIGNE'
                                    when tr.system = 'DEX'    THEN 'DEX'
                                    when tr.system = 'ENDNA_CRUDE'    THEN 'ENDUR_OIL'
                                    when tr.system = 'ENDNA_GP'       THEN 'ENDUR_GP_NA'
                                    when tr.system = 'ENDNA_PROD'     THEN 'ENDUR_PRODUCTS'
                                    when tr.system = 'IMOS'           THEN 'IMOS'
                                    when tr.system = 'NUCLEUS'        THEN 'NUCLEUS'
                                    when tr.system = 'RADAR'          THEN 'RADAR'
                                    when tr.system = 'SLMT'           THEN 'SLMT'
                               else tr.system 
                               end source_system_code
                              ,tr.mapping_id                 as cp_deal_mapping_id
                              ,tr.`trading entity`           as deal_trading_entity
                              ,case when length(trim(tr.`trading entity long name`)) >0 then trim(tr.`trading entity long name`)
                                    else tr.`trading entity`
                               END deal_trading_entity_long_name
                              ,tr.`trading desk`             as deal_trading_desk
                              ,tr.`buy/sell`                 as deal_buy_sell
                              ,tr.`deal class`               as deal_class
                              ,tr.`Product Type`             as deal_product_type
                              --,tr.Trade_Month                as deal_date_month
                              ,date_format(tr.Trade_Month,'yyyMMdd') as deal_date_month_key
                              ,tr.`Trader Name`              as deal_trader_name
                              ,tr.`Value_UoM`                as deal_value_unit_of_measure
                              ,tr.`Volume_UoM`               as deal_volume_unit_of_measure
                              ,sum(cast(tr.`Notional Value` as DECIMAL(30,5)))  as deal_notional_value
                              ,sum(cast(tr.`Notional Volume` as DECIMAL(30,5))) as deal_notional_volume
                              ,current_timestamp                       as meta_created_ddtm
                              ,current_timestamp                       as meta_start_ddtm
                              ,to_date('2999-12-31', 'yyyy-MM-dd')     as meta_end_ddtm
                              ,'Y'                                     as active_indicator
                              ,date_format(current_date, 'yyyyMMdd')   as report_date_key
                              
                          from 
                               vw_cpdata_cp_trans_stg tr
                          group by  case when tr.system = 'ALIGNE' THEN 'ALIGNE'
                                    when tr.system = 'DEX'    THEN 'DEX'
                                    when tr.system = 'ENDNA_CRUDE'    THEN 'ENDUR_OIL'
                                    when tr.system = 'ENDNA_GP'       THEN 'ENDUR_GP_NA'
                                    when tr.system = 'ENDNA_PROD'     THEN 'ENDUR_PRODUCTS'
                                    when tr.system = 'IMOS'           THEN 'IMOS'
                                    when tr.system = 'NUCLEUS'        THEN 'NUCLEUS'
                                    when tr.system = 'RADAR'          THEN 'RADAR'
                                    when tr.system = 'SLMT'           THEN 'SLMT'
                               else tr.system
                               end, 
                                    tr.mapping_id , tr.`trading entity`, 
                                    case when length(trim(tr.`trading entity long name`)) >0 then trim(tr.`trading entity long name`) else tr.`trading entity` END, 
                                    tr.`trading desk`, tr.`buy/sell`,tr.`deal class`
                                   ,tr.`Product Type`,date_format(tr.Trade_Month,'yyyMMdd'),  tr.`Trader Name`,tr.`Value_UoM` ,tr.`Volume_UoM`
                                   
                          """)
deal_tran_df.createOrReplaceTempView("vw_lma_deal_counterparty")
RefreshCuratedSqlTbl('staging', 'lma_deal_counterparty')

# COMMAND ----------

source_system_code_list = [row[0] for row in deal_tran_df[["source_system_code"]].drop_duplicates().collect()]  #list comprehension for getting source_system_codes

#loop through each source code and then alter the partition from staging
for source_system_code in source_system_code_list:
    print(source_system_code)
    LoadCuratedTargetTbl('staging', 'lma_deal_counterparty', 'cp_data_hub', 'lma_deal_counterparty', source_system_code)

# COMMAND ----------

# DBTITLE 1,lma_deal_cp_summary 
# MAGIC %sql
# MAGIC create or replace TEMPORARY view vw_lma_deal_cp_summary as 
# MAGIC select 
# MAGIC                                   case when tr.system = 'ALIGNE' THEN 'ALIGNE'
# MAGIC                                         when tr.system = 'DEX'    THEN 'DEX'
# MAGIC                                         when tr.system = 'ENDNA_CRUDE'    THEN 'ENDUR_OIL'
# MAGIC                                         when tr.system = 'ENDNA_GP'       THEN 'ENDUR_GP_NA'
# MAGIC                                         when tr.system = 'ENDNA_PROD'     THEN 'ENDUR_PRODUCTS'
# MAGIC                                         when tr.system = 'IMOS'           THEN 'IMOS'
# MAGIC                                         when tr.system = 'NUCLEUS'        THEN 'NUCLEUS'
# MAGIC                                         when tr.system = 'RADAR'          THEN 'RADAR'
# MAGIC                                         when tr.system = 'SLMT'           THEN 'SLMT'
# MAGIC                                    else tr.system 
# MAGIC                                    end source_system_code
# MAGIC                                   ,tr.mapping_id                         as cp_deal_mapping_id
# MAGIC                                   ,max(to_date(tr.latest_trade_date))    as deal_latest_trade_date
# MAGIC                                   ,max(tr.latest_trader_name)            as deal_latest_trader_name
# MAGIC                                   ,max(to_date(tr.latest_delivery_date)) as deal_latest_delivery_date
# MAGIC                                   ,current_timestamp                       as meta_created_ddtm
# MAGIC                                   ,current_timestamp                       as meta_start_ddtm
# MAGIC                                   ,to_date('2999-12-31', 'yyyy-MM-dd')     as meta_end_ddtm
# MAGIC                                   ,'Y'                                     as active_indicator
# MAGIC                                   ,date_format(current_date, 'yyyyMMdd')   as report_date_key
# MAGIC                                  from vw_cpdata_cp_trans_stg tr
# MAGIC                                  group by 
# MAGIC                                     case when tr.system = 'ALIGNE' THEN 'ALIGNE'
# MAGIC                                             when tr.system = 'DEX'    THEN 'DEX'
# MAGIC                                             when tr.system = 'ENDNA_CRUDE'    THEN 'ENDUR_OIL'
# MAGIC                                             when tr.system = 'ENDNA_GP'       THEN 'ENDUR_GP_NA'
# MAGIC                                             when tr.system = 'ENDNA_PROD'     THEN 'ENDUR_PRODUCTS'
# MAGIC                                             when tr.system = 'IMOS'           THEN 'IMOS'
# MAGIC                                             when tr.system = 'NUCLEUS'        THEN 'NUCLEUS'
# MAGIC                                             when tr.system = 'RADAR'          THEN 'RADAR'
# MAGIC                                             when tr.system = 'SLMT'           THEN 'SLMT'
# MAGIC                                        else tr.system
# MAGIC                                        end,
# MAGIC                                      tr.mapping_id

# COMMAND ----------

# DBTITLE 1,Checking the latest dates or trader names are not null in lma_deal_counterparty_summary
lma_deal_counterparty_summary_df = spark.sql("""select * from vw_lma_deal_cp_summary
                                                where deal_latest_trade_date is not null or deal_latest_delivery_date is not null or length(deal_latest_trader_name)>0 
                                             """
                                             )
lma_deal_counterparty_summary_df.createOrReplaceTempView("vw_lma_deal_counterparty_summary")

# cp_deal_mapping_id_df = spark.sql("""select cp_deal_mapping_id from vw_cp_data_hub_counterparty""")
# cp_deal_mapping_id_df = cp_deal_mapping_id_df.drop_duplicates()
# cp_deal_mapping_id_distinct_cnt = cp_deal_mapping_id_df.count()

# # need to get the distinct deal_mapping_id counts
# deal_cp_summary_mapping_id_cnt = lma_deal_counterparty_summary_df[['cp_deal_mapping_id']].drop_duplicates().count()

# # check if every deal_mapping_id of deal_counterparty_summary is in counterparty table or not.
# deal_mapping_id_not_in_cp_df = spark.sql("""select distinct cp_deal_mapping_id from vw_lma_deal_counterparty_summary dcs
#                                             where not exists (select 1 from vw_cp_data_hub_counterparty cp where  cp.cp_deal_mapping_id = dcs.cp_deal_mapping_id)
#                                          """)
# print(deal_mapping_id_not_in_cp_df.count())                           
#load process
    

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'lma_deal_counterparty_summary')

# COMMAND ----------

source_system_code_list = [row[0] for row in lma_deal_counterparty_summary_df[["source_system_code"]].drop_duplicates().collect()]  #list comprehension for getting source_system_codes

#loop through each source code and then alter the partition from staging
for source_system_code in source_system_code_list:
    print(source_system_code)
    LoadCuratedTargetTbl('staging', 'lma_deal_counterparty_summary', 'cp_data_hub', 'lma_deal_counterparty_summary', source_system_code)
