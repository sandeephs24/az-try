# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# DBTITLE 1,Run dataset dependencies
# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# source_system , view_prefix_name  parameters to pass to the function
#create_temp_views_per_source_system('ENDUR_GP_NA', 'gpna')
create_temp_views_per_source_system('ENDUR_SLMT', 'endur_lng')

# COMMAND ----------

# DBTITLE 1,Fetching create date value
# MAGIC %sql
# MAGIC create or replace temporary view party_history as
# MAGIC select to_timestamp(min(last_update),'yyyy-MM-dd HH:mm:ss.SSSSSSS')as lst_updt,party_id from endur_lng_PARTY_HISTORY
# MAGIC group by party_id

# COMMAND ----------

# MAGIC   %sql
# MAGIC 
# MAGIC create or replace temporary view vw_cp_slmt_mrd_business_unit_master as  -- removed ENDUR_LNG in the name at end 
# MAGIC (
# MAGIC   --Step 1.
# MAGIC   with query_one as
# MAGIC   (
# MAGIC   SELECT DISTINCT party.party_id, 
# MAGIC    int_ext.name type, 
# MAGIC    pc.name party_class, 
# MAGIC    party.party_class party_class_id, 
# MAGIC    ps.name status, 
# MAGIC    party.Short_Name, 
# MAGIC    party.Long_Name, 
# MAGIC    per_created.name created_by, 
# MAGIC    CONCAT(per_created.first_name,(' '||per_created.last_name)) created_by_name,
# MAGIC    per_updated.name updated_by, 
# MAGIC    CONCAT(per_updated.first_name,(' '||per_updated.last_name)) le_updated_by_name,
# MAGIC    to_date(party.Last_Update) as Last_Update, 
# MAGIC    party.party_version version, 
# MAGIC    no_yes.name Agency_Activities, 
# MAGIC    party.Linked_Party_Id, 
# MAGIC    le.addr1 address_1, 
# MAGIC    le.addr2 address_2, 
# MAGIC    le.city, 
# MAGIC    states.short_name state, 
# MAGIC    country.name country, 
# MAGIC    le.mail_code, 
# MAGIC    le.phone, 
# MAGIC    le.fax, 
# MAGIC    le.description, 
# MAGIC    le.int_ref1 internal_reference_1, 
# MAGIC    le.int_ref2 internal_reference_2, 
# MAGIC    le.int_ref3 internal_reference_3, 
# MAGIC    pg.short_name party_group, 
# MAGIC    pi_sap_cust.value lng_sap_customer, 
# MAGIC    pi_sap_ven.value lng_sap_vendor, 
# MAGIC    pi_int_sap_cust.value lng_int_sap_customer, 
# MAGIC    pi_int_sap_ven.value lng_int_sap_vendor, 
# MAGIC    pi_comp_code.value lng_company_code, 
# MAGIC    CASE party.int_ext 
# MAGIC      WHEN 0 
# MAGIC      THEN pi_int_remit_rep.value 
# MAGIC      ELSE pi_remit_rep.value 
# MAGIC    END remit_reprotable, 
# MAGIC    pi_qgc_sap_cust.value qgc_sap_cust, 
# MAGIC    pi_qgc_sap_vend.value qgc_sap_vend, 
# MAGIC    pi_sgm_sap_cust.value sgm_sap_cust, 
# MAGIC    pi_sgm_sap_vend.value sgm_sap_vend, 
# MAGIC    pi_sgm_sap_ic_cust.value sgm_sap_ic_cust, 
# MAGIC    pi_sgm_sap_ic_vend.value sgm_sap_ic_vend, 
# MAGIC    pr.name party_rating, 
# MAGIC    pgm.group_id, 
# MAGIC    cr.rating_name,
# MAGIC    to_date(party.meta_created_dttm) as meta_created_dttm,
# MAGIC    ph.lst_updt as cp_create_date  --added create date
# MAGIC    --+ Date of maximum end date of any load / discharge for any associated deal for any associated party agreement, 
# MAGIC  FROM endur_lng_party party
# MAGIC  left outer join party_history ph on ph.party_id = party.party_id --- join to get create date
# MAGIC  left outer join endur_lng_legal_entity le on party.party_id = le.party_id
# MAGIC  left outer join endur_lng_states states on le.state_id = states.state_id
# MAGIC  left outer join endur_lng_country country on le.country = country.id_number
# MAGIC  left outer join endur_lng_party_group_memb pgm on party.party_id           = pgm.party_id
# MAGIC  left outer join endur_lng_party_group pg on pgm.group_id                   = pg.group_id
# MAGIC  left outer join endur_lng_party_info pi_sap_cust on party.party_id         = pi_sap_cust.party_id and  pi_sap_cust.type_id  = 20176
# MAGIC  left outer join endur_lng_party_info pi_sap_ven on party.party_id          = pi_sap_ven.party_id and pi_sap_ven.type_id   = 20174 -- LNG Ext SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_int_sap_cust on party.party_id     = pi_int_sap_cust.party_id and pi_int_sap_cust.type_id  = 20177 -- LNG Int SAP Customer  
# MAGIC  left outer join endur_lng_party_info pi_int_sap_ven on party.party_id      = pi_int_sap_ven.party_id and pi_int_sap_ven.type_id   = 20175 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_comp_code on party.party_id        = pi_comp_code.party_id and pi_comp_code.type_id     = 20173 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_int_remit_rep on party.party_id    = pi_int_remit_rep.party_id and pi_int_remit_rep.type_id = 20183 -- Remit Reportable Internal 
# MAGIC  left outer join endur_lng_party_info pi_remit_rep on party.party_id        = pi_remit_rep.party_id and pi_remit_rep.type_id = 20184 -- Remit Reportable External 
# MAGIC  left outer join endur_lng_party_info pi_qgc_sap_cust on party.party_id     = pi_qgc_sap_cust.party_id and pi_qgc_sap_cust.type_id  = 20166 -- QGC SAP Customer 
# MAGIC  left outer join endur_lng_party_info pi_qgc_sap_vend on party.party_id     = pi_qgc_sap_vend.party_id and pi_qgc_sap_vend.type_id  = 20167 -- QGC SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_cust on party.party_id     = pi_sgm_sap_cust.party_id and pi_sgm_sap_cust.type_id  = 20149 -- SGM SAP Customer 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_vend on party.party_id     = pi_sgm_sap_vend.party_id and pi_sgm_sap_vend.type_id  = 20150 -- SGM SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_ic_cust on party.party_id  = pi_sgm_sap_ic_cust.party_id and pi_sgm_sap_ic_cust.type_id  = 20188 -- SGM SAP IC Customer 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_ic_vend on party.party_id  = pi_sgm_sap_ic_vend.party_id and pi_sgm_sap_ic_vend.type_id  = 20189 -- SGM SAP IC Vendor 
# MAGIC  left outer join endur_lng_party_rating pr on le.party_rating               = pr.id_number
# MAGIC  left outer join endur_lng_party_credit_rating pcr on party.party_id        = pcr.party_id
# MAGIC  left outer join endur_lng_credit_rating cr        on pcr.rating_id         = cr.rating_id,
# MAGIC   endur_lng_party_status ps,
# MAGIC   endur_lng_internal_external int_ext,
# MAGIC   endur_lng_personnel per_created,
# MAGIC   endur_lng_personnel per_updated,
# MAGIC   endur_lng_party_class pc,
# MAGIC   endur_lng_no_yes no_yes
# MAGIC  WHERE party.int_ext               =int_ext.id_number 
# MAGIC  AND party.party_class           = pc.id_number 
# MAGIC  AND party.party_status          = ps.id_number 
# MAGIC  AND party.inputter_id           = per_created.id_number 
# MAGIC  AND party.authoriser_id         = per_updated.id_number 
# MAGIC  AND party.Agency_Activities     = no_yes.id_number
# MAGIC  ),
# MAGIC  
# MAGIC  --Step 3.
# MAGIC  query_two as
# MAGIC  (
# MAGIC  SELECT DISTINCT pf.party_id,  
# MAGIC    p.short_name,  
# MAGIC    p.int_ext,  
# MAGIC    concat_ws(";", collect_list(ft.name)) as functions--,  --Step 4.
# MAGIC    --concat_ws(";", ft.name) as functions--,
# MAGIC    --pr.business_unit_id  
# MAGIC    FROM endur_lng_party_function pf, 
# MAGIC    --left outer join endur_lng_party_relationship pr on pf.party_id = pr.business_unit_id,  
# MAGIC    endur_lng_party p,  
# MAGIC    endur_lng_function_type ft  
# MAGIC  WHERE pf.party_id = p.party_id  
# MAGIC  AND pf.function_type =ft.id_number
# MAGIC  group by pf.party_id, p.short_name, p.int_ext--, pr.business_unit_id, ft.name
# MAGIC  ),
# MAGIC  
# MAGIC  --Step 5.
# MAGIC  query_three as
# MAGIC  ( 
# MAGIC   SELECT DISTINCT pr.legal_entity_id,  
# MAGIC    pr.business_unit_id  
# MAGIC  FROM endur_lng_party_relationship pr 
# MAGIC  )
# MAGIC  
# MAGIC  -- Step 4 - Output 1.
# MAGIC  select query_one.party_id as Party_Id,
# MAGIC 		query_one.type as Type,
# MAGIC 		query_one.status as Status,
# MAGIC 		query_one.short_name as CP_BU_SHORT_NAME,
# MAGIC 		query_one.long_name as CP_BU_LONG_NAME,
# MAGIC 		query_one.created_by as Created_By,
# MAGIC 		query_one.updated_by as LE_Updated_By,
# MAGIC 		query_one.last_update as LE_Last_Updated,
# MAGIC 		query_one.version as Version,
# MAGIC 		--query_one.linked_party_id as Linked_Party_Id,
# MAGIC         --query_three.business_unit_id as linked_party_id,
# MAGIC         nvl(query_three.legal_entity_id,query_one.party_id) as linked_party_id,
# MAGIC 		query_one.party_group as Party_Group,
# MAGIC         query_one.lng_sap_customer as LNG_SAP_Customer,
# MAGIC 		query_one.lng_sap_vendor as LNG_SAP_Vendor,
# MAGIC 		query_one.lng_int_sap_customer as LNG_Int_SAP_Customer,
# MAGIC 		query_one.lng_int_sap_vendor as LNG_Int_SAP_Vendor,
# MAGIC 		query_one.lng_company_code as LNG_Company_Code,
# MAGIC 		query_one.remit_reprotable as Remit_Reportable,
# MAGIC 		query_one.qgc_sap_cust as QGC_SAP_Customer,
# MAGIC 		query_one.qgc_sap_vend as QGC_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_cust as SGM_SAP_Customer,
# MAGIC 		query_one.sgm_sap_vend as SGM_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_ic_cust as SGM_SAP_IC_Customer,
# MAGIC 		query_one.sgm_sap_ic_vend as SGM_SAP_IC_Vendor,
# MAGIC         query_one.party_rating    as Credit_Internal_Rating,
# MAGIC 		query_one.rating_name     as SHELL_CREDIT_RATING,
# MAGIC 		query_two.functions       as BU_Functions,
# MAGIC         'ENDUR_LNG' as source_system,
# MAGIC         query_one.meta_created_dttm,
# MAGIC         query_one.cp_create_date --create date
# MAGIC         --query_three.business_unit_id as linked_party_id
# MAGIC   from query_one
# MAGIC   -- Step 4
# MAGIC   left outer join  query_two on query_one.party_id=query_two.party_id
# MAGIC   -- Step 6
# MAGIC   left outer join query_three on query_one.party_id=query_three.business_unit_id
# MAGIC   -- Step 2.
# MAGIC   where query_one.party_class_id !=0 --/*This will exclude all Legal Entities */
# MAGIC   )
# MAGIC  ;
# MAGIC           

# COMMAND ----------

# DBTITLE 1,Testing
#df = spark.sql("select * from vw_cp_slmt_mrd_business_unit_master_ENDUR_LNG") 
df = spark.sql("select * from vw_cp_slmt_mrd_business_unit_master")


# COMMAND ----------

df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC   --Step 1.
# MAGIC   create or replace temporary view vw_cp_slmt_mrd_legal_entity_master_tmp1 as  -- removed _ENDUR_LNG in the name at the end. 
# MAGIC   (
# MAGIC   with query_one as
# MAGIC   (
# MAGIC   SELECT DISTINCT party.party_id, 
# MAGIC    int_ext.name type, 
# MAGIC    pc.name party_class, 
# MAGIC    party.party_class party_class_id, 
# MAGIC    ps.name status, 
# MAGIC    party.Short_Name, 
# MAGIC    party.Long_Name, 
# MAGIC    per_created.name created_by, 
# MAGIC    CONCAT(per_created.first_name,(' '||per_created.last_name)) created_by_name,
# MAGIC    per_updated.name updated_by, 
# MAGIC    CONCAT(per_updated.first_name,(' '||per_updated.last_name)) le_updated_by_name,
# MAGIC    to_date(party.Last_Update) as Last_Update, 
# MAGIC    party.party_version version, 
# MAGIC    no_yes.name Agency_Activities, 
# MAGIC    party.Linked_Party_Id, 
# MAGIC    le.addr1 address_1, 
# MAGIC    le.addr2 address_2, 
# MAGIC    le.city, 
# MAGIC    states.short_name state, 
# MAGIC    country.name country, 
# MAGIC    le.mail_code, 
# MAGIC    le.phone, 
# MAGIC    le.fax, 
# MAGIC    le.description, 
# MAGIC    le.int_ref1 internal_reference_1, 
# MAGIC    le.int_ref2 internal_reference_2, 
# MAGIC    le.int_ref3 internal_reference_3, 
# MAGIC    pg.short_name party_group, 
# MAGIC    pi_sap_cust.value lng_sap_customer, 
# MAGIC    pi_sap_ven.value lng_sap_vendor, 
# MAGIC    pi_int_sap_cust.value lng_int_sap_customer, 
# MAGIC    pi_int_sap_ven.value lng_int_sap_vendor, 
# MAGIC    pi_comp_code.value lng_company_code, 
# MAGIC    CASE party.int_ext 
# MAGIC      WHEN 0 
# MAGIC      THEN pi_int_remit_rep.value 
# MAGIC      ELSE pi_remit_rep.value 
# MAGIC    END remit_reprotable, 
# MAGIC    pi_qgc_sap_cust.value qgc_sap_cust, 
# MAGIC    pi_qgc_sap_vend.value qgc_sap_vend, 
# MAGIC    pi_sgm_sap_cust.value sgm_sap_cust, 
# MAGIC    pi_sgm_sap_vend.value sgm_sap_vend, 
# MAGIC    pi_sgm_sap_ic_cust.value sgm_sap_ic_cust, 
# MAGIC    pi_sgm_sap_ic_vend.value sgm_sap_ic_vend, 
# MAGIC    pr.name party_rating, 
# MAGIC    pgm.group_id, 
# MAGIC    cr.rating_name,
# MAGIC    ph.lst_updt as cp_create_date --create date
# MAGIC    --case when pi_ext_sap_ven.type_id   = 20174 or pi_int_sap_ven.type_id   = 20175 then "Vendor"
# MAGIC    --     when pi_ext_sap_cust.type_id   = 20176 or pi_int_sap_cust.type_id   = 20177 then "Customer" end as sap_cpty_type
# MAGIC    --+ Date of maximum end date of any load / discharge for any associated deal for any associated party agreement, 
# MAGIC  FROM endur_lng_party party
# MAGIC  inner join endur_lng_party_status ps on party.party_status          = ps.id_number
# MAGIC  inner join  endur_lng_internal_external int_ext on party.int_ext               =int_ext.id_number 
# MAGIC  inner join endur_lng_personnel per_created on party.inputter_id           = per_created.id_number 
# MAGIC  inner join  endur_lng_personnel per_updated on party.authoriser_id         = per_updated.id_number 
# MAGIC  inner join endur_lng_party_class pc on party.party_class           = pc.id_number 
# MAGIC  inner join endur_lng_no_yes no_yes on party.Agency_Activities     = no_yes.id_number
# MAGIC  left outer join party_history ph on ph.party_id = party.party_id --create date
# MAGIC  left outer join endur_lng_legal_entity le on party.party_id = le.party_id
# MAGIC  left outer join endur_lng_states states on le.state_id = states.state_id
# MAGIC  left outer join endur_lng_country country on le.country = country.id_number
# MAGIC  left outer join endur_lng_party_group_memb pgm on party.party_id = pgm.party_id
# MAGIC  left outer join endur_lng_party_group pg on pgm.group_id = pg.group_id
# MAGIC  left outer join endur_lng_party_info pi_sap_cust on party.party_id = pi_sap_cust.party_id and  pi_sap_cust.type_id  = 20176
# MAGIC  left outer join endur_lng_party_info pi_sap_ven on party.party_id          = pi_sap_ven.party_id and pi_sap_ven.type_id   = 20174 -- LNG Ext SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_int_sap_cust on party.party_id         = pi_int_sap_cust.party_id and pi_int_sap_cust.type_id  = 20177 -- LNG Int SAP Customer  
# MAGIC  left outer join endur_lng_party_info pi_int_sap_ven on party.party_id              = pi_int_sap_ven.party_id and pi_int_sap_ven.type_id   = 20175 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_comp_code on party.party_id              = pi_comp_code.party_id and pi_comp_code.type_id     = 20173 -- LNG Int SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_int_remit_rep on party.party_id      = pi_int_remit_rep.party_id and pi_int_remit_rep.type_id = 20183 -- Remit Reportable Internal 
# MAGIC  left outer join endur_lng_party_info pi_remit_rep on party.party_id     = pi_remit_rep.party_id and pi_remit_rep.type_id = 20184 -- Remit Reportable External 
# MAGIC  left outer join endur_lng_party_info pi_qgc_sap_cust on party.party_id              = pi_qgc_sap_cust.party_id and pi_qgc_sap_cust.type_id  = 20166 -- QGC SAP Customer 
# MAGIC  left outer join endur_lng_party_info pi_qgc_sap_vend on party.party_id              = pi_qgc_sap_vend.party_id and pi_qgc_sap_vend.type_id  = 20167 -- QGC SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_cust on party.party_id              = pi_sgm_sap_cust.party_id and pi_sgm_sap_cust.type_id  = 20149 -- SGM SAP Customer 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_vend on party.party_id              = pi_sgm_sap_vend.party_id and pi_sgm_sap_vend.type_id  = 20150 -- SGM SAP Vendor 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_ic_cust on party.party_id      = pi_sgm_sap_ic_cust.party_id and pi_sgm_sap_ic_cust.type_id  = 20188 -- SGM SAP IC Customer 
# MAGIC  left outer join endur_lng_party_info pi_sgm_sap_ic_vend on party.party_id       = pi_sgm_sap_ic_vend.party_id and pi_sgm_sap_ic_vend.type_id  = 20189 -- SGM SAP IC Vendor 
# MAGIC  left outer join endur_lng_party_rating pr on le.party_rating             = pr.id_number
# MAGIC  left outer join endur_lng_party_credit_rating pcr on party.party_id  = pcr.party_id
# MAGIC  left outer join endur_lng_credit_rating cr on pcr.rating_id = cr.rating_id
# MAGIC  WHERE  party.party_class != 1
# MAGIC  ),
# MAGIC   
# MAGIC     query_three as
# MAGIC     (
# MAGIC     SELECT DISTINCT 
# MAGIC     pr.legal_entity_id,  
# MAGIC     pr.business_unit_id  
# MAGIC     FROM endur_lng_party_relationship pr
# MAGIC     )
# MAGIC     
# MAGIC  SELECT DISTINCT
# MAGIC         query_one.party_id as Party_Id,
# MAGIC 		query_one.type as Type,
# MAGIC 		query_one.party_class as Class,
# MAGIC 		query_one.status as Status,
# MAGIC 		query_one.short_name as CP_LE_SHORT_NAME,
# MAGIC 		query_one.long_name as CP_LE_LONG_NAME,
# MAGIC 		query_one.created_by as Created_By,
# MAGIC 		query_one.created_by_name as Created_By_Name,
# MAGIC 		query_one.updated_by as LE_Updated_By,
# MAGIC 		query_one.le_updated_by_name as LE_Updated_By_Name,
# MAGIC 		to_date(query_one.last_update) as LE_Last_Updated,
# MAGIC 		query_one.version as Version,
# MAGIC 		query_one.agency_activities as Agency_Activities,
# MAGIC 		query_one.address_1 as Address_1,
# MAGIC 		query_one.address_2 as Address_2,
# MAGIC 		query_one.city as City,
# MAGIC 		query_one.state as State,
# MAGIC 		query_one.country as Country,
# MAGIC 		query_one.mail_code as Mail_Code,
# MAGIC 		query_one.phone as Phone,
# MAGIC 		query_one.fax as Fax,
# MAGIC 		query_one.description as Description,
# MAGIC 		query_one.internal_reference_1 as Internal_Reference_1,
# MAGIC 		query_one.internal_reference_2 as Internal_Reference_2,
# MAGIC 		query_one.internal_reference_3 as Internal_Reference_3,
# MAGIC 		query_one.party_group as Party_Group,
# MAGIC 		query_one.lng_sap_customer as LNG_Ext_SAP_Customer,
# MAGIC 		query_one.lng_sap_vendor as LNG_Ext_SAP_Vendor,
# MAGIC 		query_one.lng_int_sap_customer as LNG_Int_SAP_Customer,
# MAGIC 		query_one.lng_int_sap_vendor as LNG_Int_SAP_Vendor,
# MAGIC 		query_one.lng_company_code as LNG_Company_Code,
# MAGIC 		query_one.remit_reprotable as Remit_Reportable,
# MAGIC 		query_one.qgc_sap_cust as QGC_SAP_Customer,
# MAGIC 		query_one.qgc_sap_vend as QGC_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_cust as SGM_SAP_Customer,
# MAGIC 		query_one.sgm_sap_vend as SGM_SAP_Vendor,
# MAGIC 		query_one.sgm_sap_ic_cust as SGM_SAP_IC_Customer,
# MAGIC 		query_one.sgm_sap_ic_vend as SGM_SAP_IC_Vendor,
# MAGIC 		query_one.party_rating as Credit_Internal_Rating,
# MAGIC 		query_one.rating_name as SHELL_CREDIT_RATING,
# MAGIC         null as Agreement_ID,
# MAGIC         null as Maximum_Deal_Number,
# MAGIC         null as max_end_date,
# MAGIC         null as trader_id,
# MAGIC         null as Trader_Id_Name,
# MAGIC         null as TRADE_DATE,
# MAGIC         null as LAST_UPDATE_DEAL,
# MAGIC         null as LAST_USER_UPDATE_DEAL,
# MAGIC         null as last_user_update_deal_name,
# MAGIC         query_three.business_unit_id as linked_party_id,
# MAGIC         'ENDUR_LNG' as source_system,
# MAGIC         query_one.cp_create_date
# MAGIC     from query_one
# MAGIC     left outer join query_three               on query_one.party_id = query_three.legal_entity_id
# MAGIC     order by CP_LE_SHORT_NAME
# MAGIC )
# MAGIC   ;   

# COMMAND ----------

# MAGIC %sql
# MAGIC -- removed _ENDUR_LNG in the name 
# MAGIC create or replace temporary view vw_cp_slmt_mrd_legal_entity_master_tmp2 as
# MAGIC SELECT *
# MAGIC FROM
# MAGIC (
# MAGIC     SELECT t.*, ROW_NUMBER() OVER (PARTITION BY party_id, linked_party_id ORDER BY version DESC) rn
# MAGIC     FROM vw_cp_slmt_mrd_legal_entity_master_tmp1 t
# MAGIC ) t
# MAGIC WHERE rn = 1;

# COMMAND ----------

spark.sql("SET spark.sql.parser.quotedRegexColumnNames=true")

# COMMAND ----------

sql("create or replace temporary view vw_cp_slmt_mrd_legal_entity_master as select `(rn)?+.+` from vw_cp_slmt_mrd_legal_entity_master_tmp2").show()

# COMMAND ----------

# MAGIC %sql
# MAGIC --_ENDUR_LNG rmoved in the names
# MAGIC  create or replace temporary view vw_cp_slmt_bu_le_cons as
# MAGIC select distinct
# MAGIC BU.PARTY_ID as BU_PARTY_ID,
# MAGIC BU.TYPE as BU_TYPE,
# MAGIC BU.STATUS as BU_STATUS,
# MAGIC BU.CP_BU_SHORT_NAME as BU_SHORT_NAME,
# MAGIC BU.CP_BU_LONG_NAME as BU_LONG_NAME,
# MAGIC BU.CREATED_BY as BU_CREATED_BY,
# MAGIC BU.LE_UPDATED_BY as BU_UPDATED_BY,
# MAGIC BU.LE_LAST_UPDATED as BU_LAST_UPDATED,
# MAGIC BU.VERSION as BU_VERSION,
# MAGIC BU.LINKED_PARTY_ID as BU_LINKED_PARTY_ID,
# MAGIC BU.PARTY_GROUP as BU_PARTY_GROUP,
# MAGIC --BU.LNG_SAP_CUSTOMER as BU_LNG_SAP_CUSTOMER,
# MAGIC --BU.LNG_SAP_VENDOR as BU_LNG_SAP_VENDOR,
# MAGIC --BU.LNG_INT_SAP_CUSTOMER as BU_LNG_INT_SAP_CUSTOMER,
# MAGIC --BU.LNG_INT_SAP_VENDOR as BU_LNG_INT_SAP_VENDOR,
# MAGIC --BU.LNG_COMPANY_CODE as BU_LNG_COMPANY_CODE,
# MAGIC --BU.REMIT_REPORTABLE as BU_REMIT_REPORTABLE,
# MAGIC --BU.QGC_SAP_CUSTOMER as BU_QGC_SAP_CUSTOMER,
# MAGIC --BU.QGC_SAP_VENDOR as BU_QGC_SAP_VENDOR,
# MAGIC --BU.SGM_SAP_CUSTOMER as BU_SGM_SAP_CUSTOMER,
# MAGIC --BU.SGM_SAP_VENDOR as BU_SGM_SAP_VENDOR,
# MAGIC --BU.SGM_SAP_IC_CUSTOMER as BU_SGM_SAP_IC_CUSTOMER,
# MAGIC --BU.SGM_SAP_IC_VENDOR as BU_SGM_SAP_IC_VENDOR,
# MAGIC --BU.CREDIT_INTERNAL_RATING as BU_CREDIT_INTERNAL_RATING,
# MAGIC --BU.SHELL_CREDIT_RATING as BU_SHELL_CREDIT_RATING,
# MAGIC BU.BU_FUNCTIONS as BU_FUNCTIONS,
# MAGIC LE.PARTY_ID as LE_PARTY_ID,
# MAGIC LE.TYPE as LE_TYPE,
# MAGIC LE.CLASS as LE_CLASS,
# MAGIC LE.STATUS as LE_STATUS,
# MAGIC LE.CP_LE_SHORT_NAME as LE_SHORT_NAME,
# MAGIC LE.CP_LE_LONG_NAME as LE_LONG_NAME,
# MAGIC LE.CREATED_BY as LE_CREATED_BY,
# MAGIC LE.CREATED_BY_NAME as LE_CREATED_BY_NAME,
# MAGIC LE.LE_UPDATED_BY as LE_UPDATED_BY,
# MAGIC LE.LE_UPDATED_BY_NAME as LE_UPDATED_BY_NAME,
# MAGIC LE.LE_LAST_UPDATED as LE_LAST_UPDATED,
# MAGIC LE.VERSION as LE_VERSION,
# MAGIC LE.AGENCY_ACTIVITIES as LE_AGENCY_ACTIVITIES,
# MAGIC LE.ADDRESS_1 as LE_ADDRESS_1,
# MAGIC LE.ADDRESS_2 as LE_ADDRESS_2,
# MAGIC LE.CITY as LE_CITY,
# MAGIC LE.STATE as LE_STATE,
# MAGIC LE.COUNTRY as LE_COUNTRY,
# MAGIC LE.MAIL_CODE as LE_MAIL_CODE,
# MAGIC LE.PHONE as LE_PHONE,
# MAGIC LE.FAX as LE_FAX,
# MAGIC LE.DESCRIPTION as LE_DESCRIPTION,
# MAGIC LE.INTERNAL_REFERENCE_1 as LE_INTERNAL_REFERENCE_1,
# MAGIC LE.INTERNAL_REFERENCE_2 as LE_INTERNAL_REFERENCE_2,
# MAGIC LE.INTERNAL_REFERENCE_3 as LE_INTERNAL_REFERENCE_3,
# MAGIC LE.PARTY_GROUP as LE_PARTY_GROUP,
# MAGIC LE.LNG_EXT_SAP_CUSTOMER as LE_LNG_EXT_SAP_CUSTOMER,
# MAGIC LE.LNG_EXT_SAP_VENDOR as LE_LNG_EXT_SAP_VENDOR,
# MAGIC LE.LNG_INT_SAP_CUSTOMER as LE_LNG_INT_SAP_CUSTOMER,
# MAGIC LE.LNG_INT_SAP_VENDOR as LE_LNG_INT_SAP_VENDOR,
# MAGIC LE.LNG_COMPANY_CODE as LE_LNG_COMPANY_CODE,
# MAGIC LE.REMIT_REPORTABLE as LE_REMIT_REPORTABLE,
# MAGIC LE.QGC_SAP_CUSTOMER as LE_QGC_SAP_CUSTOMER,
# MAGIC LE.QGC_SAP_VENDOR as LE_QGC_SAP_VENDOR,
# MAGIC LE.SGM_SAP_CUSTOMER as LE_SGM_SAP_CUSTOMER,
# MAGIC LE.SGM_SAP_VENDOR as LE_SGM_SAP_VENDOR,
# MAGIC LE.SGM_SAP_IC_CUSTOMER as LE_SGM_SAP_IC_CUSTOMER,
# MAGIC LE.SGM_SAP_IC_VENDOR as LE_SGM_SAP_IC_VENDOR,
# MAGIC LE.CREDIT_INTERNAL_RATING as LE_CREDIT_INTERNAL_RATING,
# MAGIC LE.SHELL_CREDIT_RATING as LE_SHELL_CREDIT_RATING,
# MAGIC LE.AGREEMENT_ID as LE_AGREEMENT_ID,
# MAGIC LE.MAXIMUM_DEAL_NUMBER as LE_MAXIMUM_DEAL_NUMBER,
# MAGIC LE.MAX_END_DATE as LE_MAX_END_DATE,
# MAGIC LE.TRADER_ID as LE_TRADER_ID,
# MAGIC LE.TRADER_ID_NAME as LE_TRADER_ID_NAME,
# MAGIC LE.TRADE_DATE as LE_TRADE_DATE,
# MAGIC LE.LAST_UPDATE_DEAL as LE_LAST_UPDATE_DEAL,
# MAGIC LE.LAST_USER_UPDATE_DEAL as LE_LAST_USER_UPDATE_DEAL,
# MAGIC LE.LAST_USER_UPDATE_DEAL_NAME as LE_LAST_USER_UPDATE_DEAL_NAME,
# MAGIC LE.LINKED_PARTY_ID as LE_LINKED_PARTY_ID,
# MAGIC 'ENDUR_LNG' as source_system,
# MAGIC BU.meta_created_dttm,
# MAGIC bu.cp_create_date as bu_cp_create_date,le.cp_create_date as le_cp_create_date
# MAGIC from vw_cp_slmt_mrd_business_unit_master BU, vw_cp_slmt_mrd_legal_entity_master LE
# MAGIC where LE.LINKED_PARTY_ID = BU.PARTY_ID;

# COMMAND ----------

df = spark.sql("select * from vw_cp_slmt_bu_le_cons")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_slmt_sap_accounts as
# MAGIC select distinct PARTY_ID, name, value, COL_NAME, 'ENDUR_LNG' as source_system from (
# MAGIC select
# MAGIC       PARTY_ID,
# MAGIC       case  
# MAGIC       when 1 = 1 then "LNG Ext SAP Customer"
# MAGIC       end
# MAGIC       as Name,
# MAGIC       case  
# MAGIC       when 1 = 1 then LNG_EXT_SAP_CUSTOMER
# MAGIC       end
# MAGIC       as Value,
# MAGIC       case  
# MAGIC       when 1 = 1 then "Customer"
# MAGIC       end
# MAGIC       as COL_NAME
# MAGIC from vw_cp_slmt_mrd_legal_entity_master
# MAGIC union
# MAGIC select  
# MAGIC       PARTY_ID,
# MAGIC       case  
# MAGIC       when 1 = 1 then "LNG Ext SAP Vendor"
# MAGIC       end
# MAGIC       as Name,
# MAGIC       case  
# MAGIC       when 1 = 1 then LNG_EXT_SAP_VENDOR
# MAGIC       end
# MAGIC       as Value,
# MAGIC       case  
# MAGIC       when 1 = 1 then "Vendor"
# MAGIC       end
# MAGIC       as COL_NAME
# MAGIC from vw_cp_slmt_mrd_legal_entity_master
# MAGIC union
# MAGIC select  
# MAGIC       PARTY_ID,
# MAGIC       case  
# MAGIC       when 1 = 1 then "LNG Int SAP Customer"
# MAGIC       end
# MAGIC       as Name,
# MAGIC       case  
# MAGIC       when 1 = 1 then LNG_INT_SAP_CUSTOMER
# MAGIC       end
# MAGIC       as Value,
# MAGIC       case  
# MAGIC       when 1 = 1 then "Customer"
# MAGIC       end
# MAGIC       as COL_NAME
# MAGIC from vw_cp_slmt_mrd_legal_entity_master
# MAGIC union
# MAGIC select  
# MAGIC     PARTY_ID,
# MAGIC     case  
# MAGIC     when 1 = 1 then "LNG Int SAP Vendor"
# MAGIC     end
# MAGIC     as Name,
# MAGIC     case  
# MAGIC     when 1 = 1 then LNG_INT_SAP_VENDOR
# MAGIC     end
# MAGIC     as Value,
# MAGIC     case  
# MAGIC     when 1 = 1 then "Vendor"
# MAGIC     end
# MAGIC     as COL_NAME
# MAGIC from vw_cp_slmt_mrd_legal_entity_master
# MAGIC ) t order by PARTY_ID

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_slmt_sap_accounts_sap as
# MAGIC select distinct PARTY_ID, name, value, COL_NAME, 'ENDUR_LNG' as source_system from (
# MAGIC select
# MAGIC       PARTY_ID, "LNG SAP Customer" as name, nvl(sl_mast_sap.lng_ext_sap_customer,sl_mast_sap.lng_int_sap_customer) as value,
# MAGIC case when sl_mast_sap.lng_ext_sap_customer is not null or trim(sl_mast_sap.lng_ext_sap_customer) <> '' or sl_mast_sap.lng_int_sap_customer is not null or trim(sl_mast_sap.lng_int_sap_customer) <> '' then "Customer" end col_name 
# MAGIC from vw_cp_slmt_mrd_legal_entity_master sl_mast_sap
# MAGIC union
# MAGIC select
# MAGIC       PARTY_ID, "LNG SAP Vendor" as name, nvl(sl_mast_sap.lng_ext_sap_vendor,sl_mast_sap.lng_int_sap_vendor) as value,
# MAGIC case when sl_mast_sap.lng_ext_sap_vendor is not null or trim(sl_mast_sap.lng_ext_sap_vendor) <> '' or sl_mast_sap.lng_int_sap_vendor is not null or trim(sl_mast_sap.lng_int_sap_vendor) <> '' then "Vendor" end col_name 
# MAGIC from vw_cp_slmt_mrd_legal_entity_master sl_mast_sap
# MAGIC ) t order by PARTY_ID

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_slmt_mrd_legal_entity_master_sap as
# MAGIC select sl_mast_sap.*, 
# MAGIC case when sl_mast_sap.lng_ext_sap_customer is not null or trim(sl_mast_sap.lng_ext_sap_customer) <> '' or sl_mast_sap.lng_int_sap_customer is not null or trim(sl_mast_sap.lng_int_sap_customer) <> '' then "Customer" 
# MAGIC      when sl_mast_sap.lng_ext_sap_vendor is not null or trim(sl_mast_sap.lng_ext_sap_vendor) <> '' or sl_mast_sap.lng_int_sap_vendor is not null       or trim(sl_mast_sap.lng_int_sap_vendor) <> '' then "Vendor" end sap_cpty_type 
# MAGIC from vw_cp_slmt_mrd_legal_entity_master sl_mast_sap

# COMMAND ----------

# df = spark.sql("select * from vw_cp_slmt_sap_accounts_ENDUR_LNG")
df = spark.sql("select * from vw_cp_slmt_sap_accounts")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_bu_functios_split as
# MAGIC select distinct BU_FUNCTIONS from vw_cp_slmt_bu_le_cons

# COMMAND ----------

# MAGIC %sql 
# MAGIC create or replace temporary view vw_cp_slmt_entity as
# MAGIC select 
# MAGIC   BU_FUNCTIONS as Input_6_BU_BU_Functions,
# MAGIC   case when locate('Trading', BU_FUNCTIONS)      >  0 then "Trading" else '' end ||
# MAGIC   case when locate('Scheduling', BU_FUNCTIONS)   >  0 then "/Scheduling" else '' end ||
# MAGIC   case when locate('Broking', BU_FUNCTIONS)      >  0 then "/Broking" else '' end ||
# MAGIC   case when locate('Agency', BU_FUNCTIONS)       >  0 then "/Agency" else '' end ||
# MAGIC   case when locate('Holding Bank', BU_FUNCTIONS) >  0 then "/Holding Bank" else '' end as Entity,
# MAGIC   'ENDUR_LNG' as source_system
# MAGIC from vw_cp_bu_functios_split

# COMMAND ----------

df = spark.sql("select * from vw_cp_slmt_entity")

# COMMAND ----------

df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_le_bu_cons_sap_acc as
# MAGIC select
# MAGIC CO.LE_ADDRESS_1,
# MAGIC CO.LE_ADDRESS_2,
# MAGIC CO.LE_AGENCY_ACTIVITIES,
# MAGIC CO.LE_AGREEMENT_ID,
# MAGIC CO.LE_CITY,
# MAGIC CO.LE_CLASS,
# MAGIC CO.LE_COUNTRY,
# MAGIC CO.LE_CREATED_BY,
# MAGIC CO.LE_CREATED_BY_NAME as CREATED_BY_NAME,
# MAGIC CO.LE_CREDIT_INTERNAL_RATING,
# MAGIC CO.LE_DESCRIPTION,
# MAGIC CO.LE_FAX,
# MAGIC CO.LE_INTERNAL_REFERENCE_1,
# MAGIC CO.LE_INTERNAL_REFERENCE_2,
# MAGIC CO.LE_INTERNAL_REFERENCE_3,
# MAGIC CO.LE_LAST_UPDATED,
# MAGIC CO.LE_UPDATED_BY,
# MAGIC CO.LE_UPDATED_BY_NAME,
# MAGIC CO.LE_LINKED_PARTY_ID,
# MAGIC CO.LE_LNG_COMPANY_CODE,
# MAGIC CO.LE_LNG_EXT_SAP_CUSTOMER,
# MAGIC CO.LE_LNG_EXT_SAP_VENDOR,
# MAGIC CO.LE_LNG_INT_SAP_CUSTOMER,
# MAGIC CO.LE_LNG_INT_SAP_VENDOR,
# MAGIC CO.LE_LONG_NAME,
# MAGIC CO.LE_MAIL_CODE,
# MAGIC CO.LE_MAX_END_DATE,
# MAGIC CO.LE_MAXIMUM_DEAL_NUMBER,
# MAGIC CO.LE_PARTY_GROUP,
# MAGIC CO.LE_PARTY_ID,
# MAGIC CO.LE_PHONE,
# MAGIC CO.LE_QGC_SAP_CUSTOMER,
# MAGIC CO.LE_QGC_SAP_VENDOR,
# MAGIC CO.LE_REMIT_REPORTABLE,
# MAGIC CO.LE_SGM_SAP_CUSTOMER,
# MAGIC CO.LE_SGM_SAP_IC_CUSTOMER,
# MAGIC CO.LE_SGM_SAP_IC_VENDOR,
# MAGIC CO.LE_SGM_SAP_VENDOR,
# MAGIC CO.LE_SHELL_CREDIT_RATING as SHELL_CREDIT_RATING,
# MAGIC CO.LE_SHORT_NAME,
# MAGIC CO.LE_STATE,
# MAGIC CO.LE_STATUS,
# MAGIC CO.LE_TRADE_DATE as TRADE_DATE,
# MAGIC CO.LE_TRADER_ID as TRADER_ID,
# MAGIC CO.LE_TRADER_ID_NAME as TRADER_ID_NAME,
# MAGIC CO.LE_TYPE,
# MAGIC CO.LE_VERSION,
# MAGIC CO.LE_LAST_UPDATE_DEAL as LAST_UPDATE_DEAL,
# MAGIC CO.LE_LAST_USER_UPDATE_DEAL as LAST_USER_UPDATE_DEAL,
# MAGIC CO.LE_LAST_USER_UPDATE_DEAL_NAME as LAST_USER_UPDATE_DEAL_NAME,
# MAGIC CO.BU_FUNCTIONS as BU_BU_FUNCTIONS,
# MAGIC CO.BU_CREATED_BY,
# MAGIC CO.BU_LAST_UPDATED as RIGHT_LE_LAST_UPDATED,
# MAGIC CO.BU_UPDATED_BY as RIGHT_LE_UPDATED_BY,
# MAGIC CO.BU_LINKED_PARTY_ID,
# MAGIC CO.BU_LONG_NAME,
# MAGIC CO.BU_PARTY_GROUP,
# MAGIC CO.BU_PARTY_ID,
# MAGIC CO.BU_SHORT_NAME,
# MAGIC CO.BU_STATUS,
# MAGIC CO.BU_TYPE,
# MAGIC CO.BU_VERSION,
# MAGIC SA.PARTY_ID as RIGHT_PARTY_ID,
# MAGIC SA.NAME,
# MAGIC SA.VALUE,
# MAGIC SA.COL_NAME,
# MAGIC 'ENDUR_LNG' as source_system,
# MAGIC CO.meta_created_dttm,
# MAGIC co.bu_cp_create_date --create date
# MAGIC from vw_cp_slmt_bu_le_cons CO 
# MAGIC --LEFT OUTER JOIN  vw_cp_slmt_sap_accounts SA ON
# MAGIC LEFT OUTER JOIN  vw_cp_slmt_sap_accounts_sap SA ON
# MAGIC CO.LE_PARTY_ID =  SA.PARTY_ID

# COMMAND ----------

df = spark.sql("select * from vw_cp_le_bu_cons_sap_acc")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_le_bu_cons_sap_credit_rating as
# MAGIC select
# MAGIC SA.LE_PARTY_ID,
# MAGIC SA.LE_TYPE,
# MAGIC SA.LE_CLASS,
# MAGIC SA.LE_STATUS,
# MAGIC SA.LE_SHORT_NAME,
# MAGIC SA.LE_LONG_NAME,
# MAGIC SA.LE_CREATED_BY,
# MAGIC SA.CREATED_BY_NAME,
# MAGIC SA.LE_UPDATED_BY,
# MAGIC SA.LE_UPDATED_BY_NAME,
# MAGIC SA.LE_LAST_UPDATED,
# MAGIC SA.LE_VERSION,
# MAGIC SA.LE_AGENCY_ACTIVITIES,
# MAGIC SA.LE_LINKED_PARTY_ID,
# MAGIC SA.LE_ADDRESS_1,
# MAGIC SA.LE_ADDRESS_2,
# MAGIC SA.LE_CITY,
# MAGIC SA.LE_STATE,
# MAGIC SA.LE_COUNTRY,
# MAGIC SA.LE_MAIL_CODE,
# MAGIC SA.LE_PHONE,
# MAGIC SA.LE_FAX,
# MAGIC SA.LE_DESCRIPTION,
# MAGIC SA.LE_INTERNAL_REFERENCE_1,
# MAGIC SA.LE_INTERNAL_REFERENCE_2,
# MAGIC SA.LE_INTERNAL_REFERENCE_3,
# MAGIC SA.LE_PARTY_GROUP,
# MAGIC SA.LE_LNG_EXT_SAP_CUSTOMER,
# MAGIC SA.LE_LNG_EXT_SAP_VENDOR,
# MAGIC SA.LE_LNG_INT_SAP_CUSTOMER,
# MAGIC SA.LE_LNG_INT_SAP_VENDOR,
# MAGIC SA.LE_LNG_COMPANY_CODE,
# MAGIC SA.LE_REMIT_REPORTABLE,
# MAGIC SA.LE_QGC_SAP_CUSTOMER,
# MAGIC SA.LE_QGC_SAP_VENDOR,
# MAGIC SA.LE_SGM_SAP_CUSTOMER,
# MAGIC SA.LE_SGM_SAP_VENDOR,
# MAGIC SA.LE_SGM_SAP_IC_CUSTOMER,
# MAGIC SA.LE_SGM_SAP_IC_VENDOR,
# MAGIC SA.LE_CREDIT_INTERNAL_RATING,
# MAGIC SA.SHELL_CREDIT_RATING,
# MAGIC SA.LE_AGREEMENT_ID,
# MAGIC SA.LE_MAXIMUM_DEAL_NUMBER,
# MAGIC SA.LE_MAX_END_DATE,
# MAGIC SA.TRADER_ID,
# MAGIC SA.TRADER_ID_NAME,
# MAGIC SA.TRADE_DATE,
# MAGIC SA.LAST_UPDATE_DEAL,
# MAGIC SA.LAST_USER_UPDATE_DEAL,
# MAGIC SA.LAST_USER_UPDATE_DEAL_NAME,
# MAGIC SA.BU_PARTY_ID,
# MAGIC SA.BU_TYPE,
# MAGIC SA.BU_STATUS,
# MAGIC SA.BU_SHORT_NAME,
# MAGIC SA.BU_LONG_NAME,
# MAGIC SA.BU_CREATED_BY,
# MAGIC SA.RIGHT_LE_UPDATED_BY as LEFT_RIGHT_LE_UPDATED_BY,
# MAGIC SA.RIGHT_LE_LAST_UPDATED as LEFT_RIGHT_LE_LAST_UPDATED,
# MAGIC SA.BU_VERSION,
# MAGIC SA.BU_LINKED_PARTY_ID,
# MAGIC SA.BU_PARTY_GROUP,
# MAGIC SA.BU_BU_FUNCTIONS,
# MAGIC SA.RIGHT_PARTY_ID,
# MAGIC SA.NAME,
# MAGIC SA.VALUE,
# MAGIC SA.COL_NAME,
# MAGIC LE.PARTY_ID,
# MAGIC LE.CP_LE_SHORT_NAME as SHORT_NAME,
# MAGIC LE.CP_LE_LONG_NAME as LONG_NAME,
# MAGIC LE.CREATED_BY_NAME as RIGHT_CREATED_BY_NAME,
# MAGIC LE.LE_UPDATED_BY as RIGHT_LE_UPDATED_BY,
# MAGIC LE.LE_UPDATED_BY_NAME as RIGHT_LE_UPDATED_BY_NAME,
# MAGIC LE.LE_LAST_UPDATED as RIGHT_LE_LAST_UPDATED,
# MAGIC LE.TRADER_ID as RIGHT_TRADER_ID,
# MAGIC LE.TRADER_ID_NAME as RIGHT_TRADER_ID_NAME,
# MAGIC LE.TRADE_DATE as RIGHT_TRADE_DATE,
# MAGIC LE.LAST_UPDATE_DEAL as RIGHT_LAST_UPDATE_DEAL,
# MAGIC LE.LAST_USER_UPDATE_DEAL as RIGHT_LAST_USER_UPDATE_DEAL,
# MAGIC LE.LAST_USER_UPDATE_DEAL_NAME AS RIGHT_LAST_USER_UPDATE_DEAL_NAME,
# MAGIC 'ENDUR_LNG' as source_system,
# MAGIC SA.meta_created_dttm,
# MAGIC sa.bu_cp_create_date --create date
# MAGIC from
# MAGIC vw_cp_le_bu_cons_sap_acc SA Left Outer Join vw_cp_slmt_mrd_legal_entity_master LE
# MAGIC ON SA.LE_PARTY_ID = LE.PARTY_ID

# COMMAND ----------

# df = spark.sql("select * from vw_cp_le_bu_cons_sap_credit_rating_ENDUR_LNG")
df = spark.sql("select * from vw_cp_le_bu_cons_sap_credit_rating")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_slmt_master_entity as
# MAGIC select
# MAGIC SA.LE_PARTY_ID,
# MAGIC SA.LE_TYPE,
# MAGIC SA.LE_CLASS,
# MAGIC SA.LE_STATUS,
# MAGIC SA.LE_SHORT_NAME,
# MAGIC SA.LE_LONG_NAME,
# MAGIC SA.LE_CREATED_BY,
# MAGIC SA.CREATED_BY_NAME,
# MAGIC SA.LE_UPDATED_BY,
# MAGIC SA.LE_UPDATED_BY_NAME,
# MAGIC SA.LE_LAST_UPDATED,
# MAGIC SA.LE_VERSION,
# MAGIC SA.LE_AGENCY_ACTIVITIES,
# MAGIC SA.LE_LINKED_PARTY_ID,
# MAGIC SA.LE_ADDRESS_1,
# MAGIC SA.LE_ADDRESS_2,
# MAGIC SA.LE_CITY,
# MAGIC SA.LE_STATE,
# MAGIC SA.LE_COUNTRY,
# MAGIC SA.LE_MAIL_CODE,
# MAGIC SA.LE_PHONE,
# MAGIC SA.LE_FAX,
# MAGIC SA.LE_DESCRIPTION,
# MAGIC SA.LE_INTERNAL_REFERENCE_1,
# MAGIC SA.LE_INTERNAL_REFERENCE_2,
# MAGIC SA.LE_INTERNAL_REFERENCE_3,
# MAGIC SA.LE_PARTY_GROUP,
# MAGIC SA.LE_LNG_EXT_SAP_CUSTOMER,
# MAGIC SA.LE_LNG_EXT_SAP_VENDOR,
# MAGIC SA.LE_LNG_INT_SAP_CUSTOMER,
# MAGIC SA.LE_LNG_INT_SAP_VENDOR,
# MAGIC SA.LE_LNG_COMPANY_CODE,
# MAGIC SA.LE_REMIT_REPORTABLE,
# MAGIC SA.LE_QGC_SAP_CUSTOMER,
# MAGIC SA.LE_QGC_SAP_VENDOR,
# MAGIC SA.LE_SGM_SAP_CUSTOMER,
# MAGIC SA.LE_SGM_SAP_VENDOR,
# MAGIC SA.LE_SGM_SAP_IC_CUSTOMER,
# MAGIC SA.LE_SGM_SAP_IC_VENDOR,
# MAGIC SA.LE_CREDIT_INTERNAL_RATING,
# MAGIC SA.SHELL_CREDIT_RATING,
# MAGIC SA.LE_AGREEMENT_ID,
# MAGIC SA.LE_MAXIMUM_DEAL_NUMBER,
# MAGIC SA.LE_MAX_END_DATE,
# MAGIC SA.TRADER_ID,
# MAGIC SA.TRADER_ID_NAME,
# MAGIC SA.TRADE_DATE,
# MAGIC SA.LAST_UPDATE_DEAL,
# MAGIC SA.LAST_USER_UPDATE_DEAL,
# MAGIC SA.LAST_USER_UPDATE_DEAL_NAME,
# MAGIC SA.BU_PARTY_ID,
# MAGIC SA.BU_TYPE,
# MAGIC SA.BU_STATUS,
# MAGIC SA.BU_SHORT_NAME,
# MAGIC SA.BU_LONG_NAME,
# MAGIC SA.BU_CREATED_BY,
# MAGIC SA.LEFT_RIGHT_LE_UPDATED_BY,
# MAGIC SA.LEFT_RIGHT_LE_LAST_UPDATED,
# MAGIC SA.BU_VERSION,
# MAGIC SA.BU_LINKED_PARTY_ID,
# MAGIC SA.BU_PARTY_GROUP,
# MAGIC SA.BU_BU_FUNCTIONS,
# MAGIC SA.RIGHT_PARTY_ID,
# MAGIC SA.NAME,
# MAGIC SA.VALUE,
# MAGIC SA.COL_NAME,
# MAGIC SA.PARTY_ID,
# MAGIC SA.SHORT_NAME,
# MAGIC SA.LONG_NAME,
# MAGIC SA.RIGHT_CREATED_BY_NAME,
# MAGIC SA.RIGHT_LE_UPDATED_BY,
# MAGIC SA.RIGHT_LE_UPDATED_BY_NAME,
# MAGIC SA.RIGHT_LE_LAST_UPDATED,
# MAGIC SA.RIGHT_TRADER_ID,
# MAGIC SA.RIGHT_TRADER_ID_NAME,
# MAGIC SA.RIGHT_TRADE_DATE,
# MAGIC SA.RIGHT_LAST_UPDATE_DEAL,
# MAGIC SA.RIGHT_LAST_USER_UPDATE_DEAL,
# MAGIC SA.RIGHT_LAST_USER_UPDATE_DEAL_NAME,
# MAGIC --SE.Entity,
# MAGIC TRIM(LEADING '/' FROM SE.Entity) as Entity,
# MAGIC 'ENDUR_LNG' as source_system,
# MAGIC SA.meta_created_dttm,
# MAGIC sa.bu_cp_create_date --create date
# MAGIC from    vw_cp_le_bu_cons_sap_credit_rating SA 
# MAGIC Left Outer Join vw_cp_slmt_entity          SE ON SA.BU_BU_FUNCTIONS = SE.Input_6_BU_BU_Functions

# COMMAND ----------

df = spark.sql("select * from vw_cp_slmt_master_entity")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_slmt_master as
# MAGIC select distinct
# MAGIC SA.LE_PARTY_ID as ACCOUNT_NO,
# MAGIC "SLMT_" || SA.LE_PARTY_ID as ACTIVITY_ID,
# MAGIC SA.LE_ADDRESS_1 || SA.LE_ADDRESS_2 as ADDRESS,
# MAGIC SA.BU_BU_FUNCTIONS,
# MAGIC SA.BU_CREATED_BY,
# MAGIC SA.BU_LINKED_PARTY_ID,
# MAGIC SA.BU_LONG_NAME,
# MAGIC SA.BU_PARTY_GROUP,
# MAGIC SA.BU_PARTY_ID,
# MAGIC SA.BU_SHORT_NAME,
# MAGIC SA.BU_STATUS,
# MAGIC SA.BU_TYPE,
# MAGIC SA.BU_VERSION,
# MAGIC SA.COL_NAME,
# MAGIC SA.CREATED_BY_NAME,
# MAGIC --CREDIT_RATING --Check with Neeraj about whic is rating_name column for this logic
# MAGIC case when SA.LE_STATUS = 'Suspended' or SA.BU_STATUS = 'Suspended' then 'Y'
# MAGIC      else 'N'
# MAGIC end as DELETED,
# MAGIC SA.Entity,
# MAGIC case when SA.Entity is null or length(trim(SA.Entity)) = 0  then SA.LE_TYPE else SA.LE_TYPE || "_" || SA.Entity end as ENTITY_TYPE,
# MAGIC case when SA.LE_STATUS is null then null when SA.LE_STATUS =  "Suspended" then "N" else "Y" end as L1_ACTIVE_IND,
# MAGIC case when SA.LE_TYPE =  "External" then "EXT" else "INT" end || "_" || 
# MAGIC case when SA.LE_CLASS = "Legal Entity" then "LE" else "BU" end as L1_TYPE,
# MAGIC SA.LE_PARTY_ID as L1_UNIQUE_ID,
# MAGIC case when SA.BU_STATUS is null then null when SA.BU_STATUS = "Suspended" then "N" else "Y" end as L2_ACTIVE_IND,
# MAGIC case when SA.BU_TYPE = "External" then "EXT" else "INT" end as L2_TYPE,
# MAGIC SA.LAST_UPDATE_DEAL,
# MAGIC SA.LAST_USER_UPDATE_DEAL,
# MAGIC SA.LAST_USER_UPDATE_DEAL_NAME,
# MAGIC SA.LE_LAST_UPDATED,
# MAGIC SA.LE_UPDATED_BY,
# MAGIC SA.LE_UPDATED_BY_NAME,
# MAGIC SA.LE_ADDRESS_1,
# MAGIC SA.LE_ADDRESS_2,
# MAGIC SA.LE_AGENCY_ACTIVITIES,
# MAGIC SA.LE_AGREEMENT_ID,
# MAGIC SA.LE_CITY,
# MAGIC SA.LE_CLASS,
# MAGIC SA.LE_COUNTRY,
# MAGIC SA.LE_CREATED_BY,
# MAGIC SA.LE_CREDIT_INTERNAL_RATING,
# MAGIC SA.LE_DESCRIPTION,
# MAGIC SA.LE_FAX,
# MAGIC SA.LE_INTERNAL_REFERENCE_1,
# MAGIC SA.LE_INTERNAL_REFERENCE_2,
# MAGIC SA.LE_INTERNAL_REFERENCE_3,
# MAGIC SA.LE_LINKED_PARTY_ID,
# MAGIC SA.LE_LNG_COMPANY_CODE,
# MAGIC SA.LE_LNG_EXT_SAP_CUSTOMER,
# MAGIC SA.LE_LNG_EXT_SAP_VENDOR,
# MAGIC SA.LE_LNG_INT_SAP_CUSTOMER,
# MAGIC SA.LE_LNG_INT_SAP_VENDOR,
# MAGIC SA.LE_LONG_NAME,
# MAGIC SA.LE_MAIL_CODE,
# MAGIC SA.LE_MAX_END_DATE,
# MAGIC SA.LE_MAXIMUM_DEAL_NUMBER,
# MAGIC SA.LE_PARTY_GROUP,
# MAGIC SA.PARTY_ID,
# MAGIC SA.LE_PHONE,
# MAGIC SA.LE_QGC_SAP_CUSTOMER,
# MAGIC SA.LE_QGC_SAP_VENDOR,
# MAGIC SA.LE_REMIT_REPORTABLE,
# MAGIC SA.LE_SGM_SAP_CUSTOMER,
# MAGIC SA.LE_SGM_SAP_IC_CUSTOMER,
# MAGIC SA.LE_SGM_SAP_IC_VENDOR,
# MAGIC SA.LE_SGM_SAP_VENDOR,
# MAGIC SA.LE_SHORT_NAME,
# MAGIC SA.LE_STATE,
# MAGIC SA.LE_STATUS,
# MAGIC SA.LE_TYPE,
# MAGIC SA.LE_VERSION,
# MAGIC SA.LEFT_RIGHT_LE_LAST_UPDATED,
# MAGIC SA.LEFT_RIGHT_LE_UPDATED_BY,
# MAGIC SA.LONG_NAME,
# MAGIC case when SA.LE_LONG_NAME is null then SA.LE_SHORT_NAME else SA.LE_LONG_NAME end as NAME,
# MAGIC SA.RIGHT_PARTY_ID as PARTY_ID2,
# MAGIC SA.RIGHT_CREATED_BY_NAME,
# MAGIC SA.RIGHT_LAST_UPDATE_DEAL,
# MAGIC SA.RIGHT_LAST_USER_UPDATE_DEAL,
# MAGIC SA.RIGHT_LAST_USER_UPDATE_DEAL_NAME,
# MAGIC SA.RIGHT_LE_LAST_UPDATED,
# MAGIC SA.RIGHT_LE_UPDATED_BY,
# MAGIC SA.RIGHT_LE_UPDATED_BY_NAME,
# MAGIC SA.RIGHT_PARTY_ID,
# MAGIC SA.RIGHT_TRADE_DATE,
# MAGIC SA.RIGHT_TRADER_ID,
# MAGIC SA.RIGHT_TRADER_ID_NAME,
# MAGIC case when trim(SA.VALUE) = '' or trim(SA.VALUE) is null then null 
# MAGIC      when cast(substr(SA.VALUE,1,1) as int) is null then lpad(SA.VALUE,10,"0") else SA.VALUE end as  SAP_ACCOUNT,
# MAGIC --cast(trim(SA.VALUE) as int) as SAP_ACCOUNT_NO,
# MAGIC REPLACE(LTRIM(REPLACE(TRIM(SA.VALUE), '0', ' ')),' ','0') as SAP_ACCOUNT_NO,
# MAGIC case when trim(SA.VALUE) = '' or trim(SA.VALUE) is null then null
# MAGIC      when SA.COL_NAME = "Customer" then "CUSTOMER"
# MAGIC      when SA.COL_NAME = "Vendor"   then "VENDOR" end as SAP_CPTY_TYPE,
# MAGIC case when trim(SA.VALUE) = '' or trim(SA.VALUE) is null then null else "L1" end as SAP_LINK_LEVEL,
# MAGIC case when trim(SA.VALUE) = '' or trim(SA.VALUE) is null then null else "STNSAP" end as SAP_SYSTEM,
# MAGIC --case when trim(SA.VALUE) = '' or trim(SA.VALUE) is null then null
# MAGIC --     when SA.COL_NAME = "Customer" then "STNSAP_Customer_" || trim(SA.VALUE)
# MAGIC --     when SA.COL_NAME = "Vendor" then "STNSAP_Vendor_" || trim(SA.VALUE) end as SAP_UNIQUE_ID,
# MAGIC case when trim(SA.VALUE) = '' or trim(SA.VALUE) is null then null
# MAGIC      when SA.COL_NAME = "Customer" then "STNSAP_Customer_" || REPLACE(LTRIM(REPLACE(trim(SA.VALUE), '0', ' ')),' ','0')
# MAGIC      when SA.COL_NAME = "Vendor" then "STNSAP_Vendor_" || REPLACE(LTRIM(REPLACE(trim(SA.VALUE), '0', ' ')),' ','0') end as SAP_UNIQUE_ID,
# MAGIC SA.SHELL_CREDIT_RATING,
# MAGIC SA.SHORT_NAME,
# MAGIC "SLMT" as SYSTEM,
# MAGIC SA.TRADE_DATE,
# MAGIC SA.TRADER_ID,
# MAGIC SA.TRADER_ID_NAME,
# MAGIC "SLMT_" || SA.LE_PARTY_ID || "_" || SA.BU_PARTY_ID as UNIQUE_ID,
# MAGIC SA.VALUE,
# MAGIC --SA.NAME, This is not used
# MAGIC 'ENDUR_LNG' as source_system,
# MAGIC SA.meta_created_dttm,
# MAGIC sa.bu_cp_create_date --create date
# MAGIC from
# MAGIC vw_cp_slmt_master_entity SA
# MAGIC --vw_cp_le_bu_cons_sap_credit_rating_ENDUR_LNG SA Left Outer Join vw_cp_slmt_entity_ENDUR_LNG SE
# MAGIC --ON SA.BU_BU_FUNCTIONS = SE.Input_6_BU_BU_Functions

# COMMAND ----------

df = spark.sql("select * from vw_cp_slmt_master")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_erated as
# MAGIC WITH ARCHIVED_DETAILS AS
# MAGIC (
# MAGIC SELECT EXTERNAL_BUNIT, MAX(ARCHIVED_CREATED_DATE) AS DELETION_DATE FROM endur_lng_USER_E_RATED_COUNTERPARTY_H GROUP BY EXTERNAL_BUNIT
# MAGIC )
# MAGIC 
# MAGIC SELECT distinct 
# MAGIC PARTY.PARTY_ID, 
# MAGIC --PARTY.SHORT_NAME AS PARTY_SHORT_NAME,
# MAGIC --PARTY.LONG_NAME AS PARTY_LONG_NAME, 
# MAGIC --INTERNAL_EXTERNAL.NAME AS INTERNAL_EXTERNAL,
# MAGIC --PARTY_STATUS.NAME AS STATUS,
# MAGIC CASE WHEN USER_E_RATED_COUNTERPARTY.EXTERNAL_BUNIT IS NOT NULL THEN 'Y' ELSE 'N' END AS E_RATED_FLAG,
# MAGIC USER_E_RATED_COUNTERPARTY.LAST_UPDATED AS E_RATED_COMPLETION_DATE,
# MAGIC CASE WHEN USER_E_RATED_COUNTERPARTY.EXTERNAL_BUNIT IS NULL THEN ARCHIVED_DETAILS.DELETION_DATE END AS E_RATED_LIFTED_DATE
# MAGIC FROM endur_lng_party PARTY
# MAGIC JOIN endur_lng_INTERNAL_EXTERNAL INTERNAL_EXTERNAL ON INTERNAL_EXTERNAL.ID_NUMBER = PARTY.INT_EXT
# MAGIC JOIN endur_lng_PARTY_STATUS PARTY_STATUS ON PARTY_STATUS.ID_NUMBER = PARTY.PARTY_STATUS
# MAGIC LEFT OUTER JOIN endur_lng_USER_E_RATED_COUNTERPARTY USER_E_RATED_COUNTERPARTY ON  USER_E_RATED_COUNTERPARTY.EXTERNAL_BUNIT = PARTY.PARTY_ID
# MAGIC LEFT OUTER JOIN ARCHIVED_DETAILS ON ARCHIVED_DETAILS.EXTERNAL_BUNIT = PARTY.PARTY_ID
# MAGIC WHERE PARTY.PARTY_CLASS= 1

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_slmt_master_consum as
# MAGIC select distinct
# MAGIC   SA.UNIQUE_ID,
# MAGIC   --SA.LE_MAX_END_DATE  as LATEST_END_DATE,
# MAGIC   --SA.TRADE_DATE       as LATEST_TRADE_DATE,
# MAGIC   --SA.LAST_UPDATE_DEAL as LATEST_DEAL_UPDATE_DATE,
# MAGIC   SA.L1_UNIQUE_ID      as L1_ID,
# MAGIC   SA.BU_PARTY_ID       as L2_ID,
# MAGIC   SA.NAME              as L1_NAME,
# MAGIC   SA.SHORT_NAME        as L1_NAME1,
# MAGIC   SA.BU_SHORT_NAME     as L2_NAME1,
# MAGIC   SA.BU_LONG_NAME      as L2_NAME,
# MAGIC   SA.SAP_CPTY_TYPE,
# MAGIC   SA.SAP_ACCOUNT_NO,
# MAGIC   SA.SYSTEM, 
# MAGIC   SA.SAP_UNIQUE_ID,
# MAGIC   SA.SAP_SYSTEM,
# MAGIC   --SA.L1_TYPE,
# MAGIC   SA.ENTITY_TYPE,
# MAGIC   --SA.Entity,  -- not needed
# MAGIC   --SA.ADDRESS,
# MAGIC   SA.BU_PARTY_GROUP             as PARENT,
# MAGIC   --SA.LE_COUNTRY as COUNTRY,
# MAGIC   --SA.LEFT_RIGHT_LE_UPDATED_BY,
# MAGIC   --SA.RIGHT_LE_LAST_UPDATED      as LE_LAST_UPDATED,  --SA.RIGHT_LE_LAST_UPDATED changed from the LE_Last_updated to le_last_update
# MAGIC   SA.LEFT_RIGHT_LE_LAST_UPDATED   as LE_LAST_UPDATED,
# MAGIC   SA.SHELL_CREDIT_RATING        as SHELL_CREDIT_RATING,
# MAGIC   SA.LE_STATUS                  as LE_STATUS,
# MAGIC   SA.DELETED                    as DEACTIVATED, -- new column add in the table after adding in the table remove this comment
# MAGIC   SA.LE_COUNTRY                 as LE_COUNTRY,                            -- new column add in the table 
# MAGIC   --CASE WHEN SA.SHELL_CREDIT_RATING ='E' then 'Y' Else 'N' END ERATE_FLAG,
# MAGIC   er.E_RATED_FLAG as ERATE_FLAG,
# MAGIC   'ENDUR_LNG'                   as source_system,
# MAGIC   SA.meta_created_dttm,
# MAGIC   sa.bu_cp_create_date
# MAGIC from vw_cp_slmt_master SA
# MAGIC left join vw_erated er on trim(SA.BU_PARTY_ID) = trim(er.PARTY_ID)

# COMMAND ----------

df = spark.sql("select * from vw_cp_slmt_master_consum")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master as 
# MAGIC select distinct
# MAGIC      UNIQUE_ID  as cp_unique_id                -- req-26
# MAGIC     ,L1_ID    as cp_l1_id                    -- l1_id (req-28)
# MAGIC     ,L1_NAME  as cp_name                     --  l1_name (req-27)
# MAGIC     ,L1_ID   as cp_etrm_account_no          --  same as l1_id for slmt
# MAGIC     ,L2_ID   as cp_l2_id                    -- l2_id (req-29)
# MAGIC     ,L2_NAME as cp_l2_name                  -- l2_name (req-30)
# MAGIC     ,ENTITY_TYPE        as cp_entity_type              -- REQ-31
# MAGIC     ,LE_LAST_UPDATED as cp_created_or_updated_date  -- req-33/req-34
# MAGIC     ,DEACTIVATED  as cp_deactivated              -- req-32
# MAGIC     ,LE_COUNTRY as cp_country                  -- req-91
# MAGIC     ,PARENT                as cp_parent                   -- req-87
# MAGIC     ,SYSTEM                as cp_system                   -- req-36 --same as "SLMT?"
# MAGIC     ,SAP_ACCOUNT_NO        as cp_linked_sap_id            -- REQ-35
# MAGIC     ,SAP_CPTY_TYPE      as cp_sap_account_type         -- REQ-38
# MAGIC     ,SAP_UNIQUE_ID         as cp_sap_unique_id            -- REQ-97
# MAGIC     ,SAP_SYSTEM     as cp_linked_sap_system        -- REQ-93
# MAGIC     ,case when (SAP_UNIQUE_ID is null or length(trim(SAP_UNIQUE_ID)) = 0 ) then  'NO SAP LINK' 
# MAGIC            ELSE 'SAP LINK' 
# MAGIC      END cp_sap_link
# MAGIC     --,ERATE_FLAG as cp_erate_flag_in_source     -- REQ-9
# MAGIC     --,cast(null as string) as cp_erate_date_in_source     -- REQ-10
# MAGIC     --,cast(null as string)       as cp_erate_lifted_date_in_source  -- req-11
# MAGIC     ,er.E_RATED_FLAG as cp_erate_flag_in_source
# MAGIC     ,er.E_RATED_COMPLETION_DATE            as cp_erate_date_in_source
# MAGIC     ,er.E_RATED_LIFTED_DATE                as cp_erate_lifted_date_in_source
# MAGIC     ,cast(null as string)                  as cp_broker_indicator 
# MAGIC     ,concat(L1_ID,'_',L2_id)               as cp_mapping_id   
# MAGIC     ,source_system         as source_system
# MAGIC     ,meta_created_dttm     as meta_created_dttm,
# MAGIC     bu_cp_create_date as cp_create_date --create date
# MAGIC 
# MAGIC from vw_cp_slmt_master_consum con
# MAGIC left join vw_erated er on trim(con.L2_ID) = trim(er.PARTY_ID)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty as 
# MAGIC select distinct 
# MAGIC     slmt.UNIQUE_ID                      as cp_unique_id               
# MAGIC   , slmt.L1_ID                          as cp_legal_entity_id          
# MAGIC   , slmt.L1_NAME                        as cp_name
# MAGIC   , L2_ID                               as cp_business_unit_id         
# MAGIC   , L2_NAME                             as cp_business_unit_name
# MAGIC   , cast(null as string)                as cp_short_name
# MAGIC  -- , cast(null as timestamp)             as cp_created_date
# MAGIC  ,bu_cp_create_date                     as cp_created_date ---create date
# MAGIC   , slmt.LE_LAST_UPDATED                as cp_updated_date
# MAGIC   , slmt.DEACTIVATED                    as cp_deactivated
# MAGIC   , er.E_RATED_FLAG                     as cp_erate_flag_source
# MAGIC  -- , --, er.E_RATED_COMPLETION_DATE          as cp_erate_date_source
# MAGIC   ,cast(er.E_RATED_COMPLETION_DATE as timestamp) as cp_erate_date_source
# MAGIC   , case when er.E_RATED_FLAG = 'Y' then 'Y' Else 'N' END as cp_erate_flag
# MAGIC   --, case when er.E_RATED_COMPLETION_DATE is not null then er.E_RATED_COMPLETION_DATE else null end as cp_erate_date
# MAGIC   ,case when cast(er.E_RATED_COMPLETION_DATE as timestamp) is not null then cast(er.E_RATED_COMPLETION_DATE as timestamp) else null end as cp_erate_date
# MAGIC   , slmt.L1_ID                          as cp_account_number
# MAGIC   , concat(slmt.L1_ID,'_',slmt.L2_id)   as cp_deal_mapping_id
# MAGIC   , current_timestamp as meta_created_ddtm
# MAGIC   , current_timestamp as meta_start_ddtm
# MAGIC   ,  to_date('2999-12-31', 'yyyy-MM-dd') as meta_end_ddtm
# MAGIC   , 'Y' as active_indicator
# MAGIC   , 'SLMT' as source_system_code
# MAGIC   ,date_format(current_date, 'yyyyMMdd') as  report_date_key
# MAGIC from vw_cp_slmt_master_consum slmt    
# MAGIC left join vw_erated er on trim(slmt.L2_ID) = trim(er.PARTY_ID)

# COMMAND ----------

df = spark.sql("select * from vw_counterparty")
df = df.drop_duplicates()
total_row_cnt = df.count()
print (total_row_cnt)
cp_unique_id_df = df.select(["cp_unique_id"])
cp_unique_id_df = cp_unique_id_df.drop_duplicates()
cp_unique_id_cnt= cp_unique_id_df.count()
print(cp_unique_id_cnt)
try:
  if total_row_cnt == cp_unique_id_cnt:
    RefreshCuratedSqlTbl('staging', 'counterparty', 'SLMT')
except Exception as r:
  print("For SLMT source system counterparty count vs unique_id cnt didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty', 'cp_data_hub', 'counterparty','SLMT')

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['counterparty']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

cp_details_df = spark.sql("""
                          select distinct
                             slmt.UNIQUE_ID                as cp_unique_id
                            ,cast(NULL as string)          as cp_company_code
                            ,cast(NULL as string)          as cp_company_name
                            ,cast(NULL as string)          as cp_country_code
                            ,slmt.LE_COUNTRY               as cp_country_name
                            ,cast(NULL as string)          as counterparty_type
                            ,current_timestamp             as meta_created_ddtm
                            ,current_timestamp             as meta_start_ddtm
                            ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                            ,'Y'                                   as active_indicator
                            ,'SLMT'                                as source_system_code
                            ,date_format(current_date, 'yyyyMMdd') as  report_date_key
                            from vw_cp_slmt_master_consum slmt  
                            where slmt.LE_COUNTRY is not null
                            and length(slmt.LE_COUNTRY)>0
                            """)
#creating temp view
cp_details_df.createOrReplaceTempView("vw_counterparty_details")

# need to get the distinct unique_id counts
cp_details_cp_unique_id_cnt = cp_details_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_counterparty_details cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)                               
#load process
try:
  if cp_unique_id_cnt >= cp_details_cp_unique_id_cnt and cp_unique_id_not_in_cp_df.count()==0:
    print(f"""Count Match: {cp_unique_id_cnt} and {cp_details_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of counterparty_details is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'counterparty_details', 'SLMT')
except Exception as e:
  print("For SLMT source system counterparty count and counterparty Details unique_id didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'counterparty_details', 'cp_data_hub', 'counterparty_details', 'SLMT')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details_summary as
# MAGIC   
# MAGIC   
# MAGIC 			select cpd.source_system_code
# MAGIC 			      ,cpd.cp_unique_id
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(counterparty_type))) as counterparty_type
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_code))) as cp_company_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_name))) as cp_company_name
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_code))) as cp_country_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_name))) as cp_country_name
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 				  from vw_counterparty_details cpd
# MAGIC 				  where cpd.source_system_code  in ('SLMT')
# MAGIC 			      group by  cpd.source_system_code, cpd.cp_unique_id
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details_summary', 'SLMT')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details_summary', 'cp_data_hub', 'counterparty_details_summary', 'SLMT')

# COMMAND ----------

bdg_cp_sap_account_df = spark.sql("""
                                 select distinct 
                                    slmt.unique_id                  as cp_unique_id
                                   ,slmt.SAP_UNIQUE_ID              as sap_unique_id
                                   ,slmt.SAP_ACCOUNT_NO             as sap_account_number
                                   ,slmt.SAP_CPTY_TYPE              as sap_account_type
                                   ,slmt.SAP_SYSTEM                 as sap_source_system_code
                                   ,current_timestamp               as meta_created_ddtm
                                   ,current_timestamp               as meta_start_ddtm
                                   ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                                   ,'Y'                                   as active_indicator
                                   ,'SLMT'                           as source_system_code
                                   ,date_format(current_date, 'yyyyMMdd') as  report_date_key 
                                from vw_cp_slmt_master_consum slmt
                                where slmt.SAP_UNIQUE_ID is not null and length(slmt.SAP_UNIQUE_ID) > 0
                                """)
#creating temp view
bdg_cp_sap_account_df.createOrReplaceTempView("vw_bridge_counterparty_sap_account")

# need to get the distinct unique_id counts
bdg_cp_sap_account_cp_unique_id_cnt = bdg_cp_sap_account_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
bdg_cp_sap_account_cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_bridge_counterparty_sap_account cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)
                                       
#load process
if cp_unique_id_cnt >= bdg_cp_sap_account_cp_unique_id_cnt and bdg_cp_sap_account_cp_unique_id_not_in_cp_df.count()==0:
  try:
  
    print(f"""Count Match: {cp_unique_id_cnt} and {bdg_cp_sap_account_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of bridge_counterparty_sap_account is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'bridge_counterparty_sap_account', 'SLMT')
  
  except Exception as e:
    print("For SLMT source system counterparty count and bridge_counterparty_sap_accnt cp_unique_id didn't match")
    raise dbutils.notebook.exit(e)
elif {cp_unique_id_cnt} < {bdg_cp_sap_account_cp_unique_id_cnt}: 
  print(f"""counterparty: {cp_unique_id_cnt}""")
  print(f"""bridge_counterparty_sap_account: {bdg_cp_sap_account_cp_unique_id_cnt}""")
  print("Count match is not working ")
else:
  print(f"""cp_unique_id exists in bridge counterparty sap account table but in counterparty table""")

# COMMAND ----------


#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'bridge_counterparty_sap_account', 'cp_data_hub', 'bridge_counterparty_sap_account', 'SLMT')

# COMMAND ----------

Source_System_Code = 'SLMT'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
