# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

create_temp_views_per_source_system('EDW','ENDUR_SLMT')

# COMMAND ----------

dbutils.widgets.text("pm_adls_proj_folder", "P00014-Cross_Comm-CPData-DEV")
v_adls_folder = dbutils.widgets.get("pm_adls_proj_folder")

# COMMAND ----------

# DBTITLE 1,ADLS Staging and Target Paths of CP Data Hub Project
adls_file_path_full_src = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/staging/ENDUR_SLMT/source_file/"
adls_file_path_tgt      = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/cp_data_hub/ENDUR_SLMT/"
partition_by_cols_stg= ['source_system_code','report_date_key']
partition_by_cols_tgt = ["source_system_code"]

# COMMAND ----------

# DBTITLE 1,Physical
physical_Query_df=spark.sql("""


with deal_details as (	
  select distinct p.deal_num , p.tran_num, p.report_date from ENDUR_SLMT_fact_deal_pnl_lng p 	
  join ( select deal_num, max(report_date) report_date from ENDUR_SLMT_fact_deal_pnl_lng 	
   group by deal_num ) f	
  on f.deal_num = p.deal_num and f.report_date = p.report_date 	
),	
dim_cargo_info_temp	
AS	
  (SELECT MAX(report_date) report_date,	
    cargo_key	
  FROM ENDUR_SLMT_dim_cargo_info	
  GROUP BY cargo_key	
  ), 

final_data as(	
	
select 	
    ddd.deal_num, 
    ddd.tran_num, 
    date_format(pnl.report_date,'dd-MMM-yy') as report_date,
    dt.trader,	
    'LNG'                                       AS product,	
   -- DECODE (ddd.buy_sell_id, 0, 'BUY', 1, 'SELL') AS buy_sell,	   
    case when ddd.buy_sell_id=0 then 'BUY'
    when ddd.buy_sell_id=1 then 'SELL'
    end as buy_sell,
    ddd.param_num, 
    ddd.profile_num, 
    ABS(NVL(fdq.quantity,0))          AS quantity, 
    VU.VOLUME_UNIT                    AS deal_quantity_unit,	
    SUM(pnl.RST_TOTAL_NOTIONAL_VALUE) AS pnl, 
    dcy.currency                      AS payment_currency,
    cf.cash_flow, --- type of transaction	
    pnl.deal_category_cd, --- custom codes for deal categarization (computed at EDW level)	
    port.portfolio, --- Portfolio Name	
    ins.ins_type, -- Instrument Type	
    ddd.counterparty_id, --- Counterparty (external legal entity id)	
    cpty.counterparty_longname AS External_LE,	
    ddd.legal_entity_id, --- internal legal entity if	
    le.legal_entity_longname   AS Internal_LE, -- internal legal entity long name	
	cast(xbu.ext_business_unit_id as bigint)  AS External_bu_id,
    xbu.business_unit          AS External_bu,	
	cast(bu.business_unit_id as bigint)  AS internal_bu_id, -- internal BU ID -- changing the data type  2021-01-02
    bu.business_unit           AS internal_bu, -- Internal BU ID	
    --date_format(ddd.trade_date,'dd-MM-yyyy') as trade_date, --- the date of transaction	
    ddd.trade_date as trade_date,
    c.load_port,  ---- loading port for the buy deal in the location	
    c.discharge_port,  --- discharge port for the sell deal in the location	
    c.actual_discharge_date as actual_discharge_date,
   --date_format(c.actual_discharge_date, 'dd-MM-yyyy') as actual_discharge_date ,	
   c.actual_loading_date as actual_loading_date,
    --date_format(c.actual_loading_date, 'dd-MM-yyyy') as actual_loading_date,	
    c.scheduled_loading_date as scheduled_loading_date,
   
   ddd.payment_date as payment_date,
 --  date_format(c.scheduled_loading_date, 'dd-MM-yyyy') as scheduled_loading_date,	
   ddd.profile_from_date as profile_from_date,
   ddd.profile_to_date as profile_to_date,
   ddd.settled_date as settled_date
  -- date_format(ddd.payment_date, 'dd-MM-yyyy') as payment_date, --- payment date of invoice	
   -- date_format(ddd.profile_from_date, 'dd-MM-yyyy') as profile_from_date, --- Profile start date, deal are divided into monthly profiles, this signifies the start date of the profile	
  --  date_format(ddd.profile_to_date, 'dd-MM-yyyy') as profile_to_date, --- Profile end date, deal are divided into monthly profiles, this signifies the start date of the profile	
   -- date_format(ddd.settled_date, 'dd-MM-yyyy') as settled_date --- when the transactions/events are settled.	
	
FROM deal_details dd 	
JOIN ENDUR_SLMT_dim_deal_detail ddd on ddd.deal_num = dd.deal_num and ddd.tran_num = dd.tran_num	
JOIN ENDUR_SLMT_fact_deal_pnl_lng pnl on pnl.deal_num = dd.deal_num and pnl.tran_num = dd.tran_num and pnl.report_date = dd.report_date	
and pnl.param_num = ddd.param_num and pnl.profile_num = ddd.profile_num 	
and pnl.settlement_type_id = 1 --- cash settlements only, 2 is for physcial settlements only	
LEFT OUTER JOIN ENDUR_SLMT_fact_deal_quantity fdq on 	
dd.report_date = fdq.report_date and dd.deal_num = fdq.deal_num and dd.tran_num = fdq.tran_num	
and (	
(fdq.param_num+1 = pnl.param_num and fdq.price_adj_level_id IN (3,4) ) --- Price Adjustment Level ID = 3 (Delivery Tickets (delivery tickets deals were converetd to parcels in 2019), 4 (Parcels only)	
OR (fdq.param_num = pnl.param_num and (fdq.price_adj_level_id NOT IN (3,4) OR fdq.price_adj_level_id is NULL )) --- (like Comm fee deals)	
) and fdq.profile_num = pnl.profile_num	
and fdq.quantity_type_id = 4 --- BAV Volume type	
left join dim_cargo_info_temp dcit	
ON pnl.cargo_key = dcit.cargo_key	
LEFT JOIN ENDUR_SLMT_dim_cargo_info c	
ON pnl.cargo_key = c.cargo_key	
and dcit.cargo_key= c.cargo_key	
and dcit.report_date = c.report_date	
AND ( 	
(c.actual_discharge_date >='01-Jan-2018'	
AND c.actual_discharge_date IS NOT NULL) 	
OR (c.actual_loading_date >='01-Jan-2018'	
AND c.actual_loading_date IS NOT NULL)	
)	
LEFT JOIN ENDUR_SLMT_dim_portfolio port	
ON ddd.portfolio_id = port.portfolio_id	
LEFT JOIN ENDUR_SLMT_DIM_INS_TYPE ins	
ON ddd.ins_type_id = ins.ins_type_id	
LEFT JOIN ENDUR_SLMT_dim_counterparty cpty	
ON ddd.counterparty_id = cpty.counterparty_id 	
LEFT JOIN ENDUR_SLMT_dim_legal_entity le	
ON ddd.legal_entity_id = le.legal_entity_id  	
LEFT JOIN ENDUR_SLMT_dim_ext_business_unit xbu	
ON ddd.ext_business_unit_id = xbu.ext_business_unit_id	
LEFT JOIN ENDUR_SLMT_dim_business_unit bu	
ON ddd.business_unit_id = bu.business_unit_id	
LEFT JOIN ENDUR_SLMT_dim_trader dt	
ON ddd.trader_id = dt.trader_id	
LEFT JOIN ENDUR_SLMT_dim_volume_unit vu	
ON ddd.quantity_unit_id = vu.volume_unit_id	
LEFT JOIN ENDUR_SLMT_dim_currency dcy	
ON ddd.payment_currency_id = dcy.currency_id	
LEFT JOIN ENDUR_SLMT_dim_cash_flow cf	
ON pnl.rst_cash_flow_type_id = cf.cash_flow_id	
	
WHERE (ddd.trade_date >= '01-Jan-2018'	
OR ddd.maturity_date  >= '01-Jan-2018') 	
	GROUP BY 	
	
ddd.deal_num,	
ddd.tran_num,	
pnl.report_date,	
ddd.buy_sell_id,	
dt.trader , 	
ddd.param_num, 	
ddd.profile_num,	
VU.VOLUME_UNIT,  	
dcy.currency,	
cf.CASH_FLOW,	
c.LOAD_PORT,	
c.DISCHARGE_PORT,	
port.portfolio,	
ins.INS_TYPE,	
ddd.counterparty_id,	
cpty.counterparty_longname,	
ddd.legal_entity_id,	
le.legal_entity_longname,	
xbu.ext_business_unit_id,	
xbu.business_unit,	
bu.business_unit_id,	
bu.business_unit,	
ddd.trade_date,	
c.actual_discharge_date,	
c.actual_loading_date,	
c.scheduled_loading_date,	
pnl.deal_category_cd,	
fdq.quantity,	
ddd.settled_date,	
ddd.profile_from_date,	
ddd.profile_to_date,	
ddd.payment_date
)
select * from final_data;
""")

# COMMAND ----------

deal_counterparty_df=physical_Query_df
deal_counterparty_df=deal_counterparty_df\
.withColumn("source_system_code",lit("ENDUR_SLMT"))\
.withColumn("meta_created_dttm",current_timestamp())\
.withColumn("report_date_key",date_format(current_timestamp(),'yyyyMMdd').cast(IntegerType()))

# COMMAND ----------

# DBTITLE 1,Staging the data in CP DATA HUB ADLS 
deal_counterparty_df.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_stg).save(adls_file_path_full_src)

# COMMAND ----------

# DBTITLE 1,Read from Staged Folder
deal_counterparty_df = spark.read.format('delta').load(adls_file_path_full_src)

# COMMAND ----------

# DBTITLE 1,Get the max meta created datetime from the DF
max_created_dttm = deal_counterparty_df.select(max("meta_created_dttm")).collect()[0][0] # 2021-10-26 02:39:..
print(max_created_dttm)

# COMMAND ----------

# DBTITLE 1,Filter the data to the latest data staged
deal_counterparty_df = deal_counterparty_df.filter(deal_counterparty_df.meta_created_dttm == max_created_dttm)
deal_counterparty_df.createOrReplaceTempView("vw_deal_counterparty_load")

# COMMAND ----------

# DBTITLE 1,For taking max of row count based on latest date
date_filter_df=spark.sql("""
with date_fine
as (
select 
max(to_date(report_date,'dd-MMM-yy')) as max_date
from vw_deal_counterparty_load
),
find_date
(
select  count(*),a.report_date 
from vw_deal_counterparty_load a 
inner join date_fine  b 
on month(b.max_date)=month(to_date(a.report_date,'dd-MMM-yy'))
and year(b.max_date)=year(to_date(a.report_date,'dd-MMM-yy'))
group by a.report_date order by  count(*) desc

)

select * from find_date
""")

# COMMAND ----------

date_filter_df=date_filter_df.collect()[0][1]

# COMMAND ----------

# DBTITLE 1,Final Logic based on Alteryx 
Final_Query_df=spark.sql("""

with main as (
select 
Trader as Trader_name,
buy_sell,
quantity as Notional_volume ,
deal_quantity_unit as UOM,
PNL as Notional_value, 
cash_flow as Deal_class, 
ins_type as ins_type, 
counterparty_id as l1_id ,
External_LE as name, 
External_bu_id as l2_id ,
internal_BU as Trading_Account_Adj,
ACTUAL_LOADING_DATE as ACTUAL_LOADING_DATE1,
TRADE_DATE as TRADE_DATE1,
PAYMENT_DATE as PAYMENT_DATE1
from
vw_deal_counterparty_load where REPORT_DATE='{}'
),

filter_notional as
(
select
       name, 
        l1_id ,
       l2_id ,
       Deal_class, 
        ins_type, 
        Trading_Account_Adj,
       Trader_name,
       UOM,
       buy_sell,
       sum(Notional_volume)  as  sum_Notional_volume,
       ACTUAL_LOADING_DATE1 as Tdate
 from Main
where  date_format(ACTUAL_LOADING_DATE1, 'yyyy-MM-dd')>'2017-12-31'
group by 
name, 
l1_id ,
l2_id ,
Deal_class, 
 ins_type, 
 Trading_Account_Adj,
Trader_name,
UOM,
buy_sell,
ACTUAL_LOADING_DATE1 
union
select 
       name, 
        l1_id ,
       l2_id ,
       Deal_class, 
        ins_type, 
        Trading_Account_Adj,
       Trader_name,
       UOM,
       buy_sell,
       sum(Notional_volume)  as  sum_Notional_volume,
       PAYMENT_DATE1 as Tdate
from Main
where date_format(PAYMENT_DATE1, 'yyyy-MM-dd')>'2017-12-31' and ACTUAL_LOADING_DATE1 is null
group by 
name, 
 l1_id ,
l2_id ,
Deal_class, 
 ins_type, 
 Trading_Account_Adj,
Trader_name,
UOM,
buy_sell,
PAYMENT_DATE1

),--select count(*) from filter_notional
distinct_record as 
(
select distinct Tdate,buy_sell,Deal_class,ins_type,l1_id,l2_id,name,sum_Notional_volume,Trading_Account_Adj,Trader_name,UOM
 from filter_notional
),

filter_deal_class as (
select
        name,
        l1_id,
        l2_id,
        case when Deal_class!='Comm-DelTkt' and 
        (ins_type  IN ('ENGY-SWAP','ENGY-B-SWAP') AND Deal_class='None') 
        then Deal_class 
        when Deal_class='Comm-DelTkt' then Deal_class
        else '' 
        end as Deal_class,
        case when Deal_class!='Comm-DelTkt' and 
        (ins_type  IN ('ENGY-SWAP','ENGY-B-SWAP') AND Deal_class='None') 
        then sum_Notional_volume
        when Deal_class='Comm-DelTkt' then sum_Notional_volume
        else  null
        end as sum_Notional_volume,
        case when Deal_class!='Comm-DelTkt' and
        (ins_type  IN ('ENGY-SWAP','ENGY-B-SWAP') AND Deal_class='None') 
        then ins_type
        when Deal_class='Comm-DelTkt' then ins_type
        else  ''
        end as ins_type,
        Trading_Account_Adj,
        Tdate,
        Trader_name,
        case when Deal_class!='Comm-DelTkt' and
        (ins_type  IN ('ENGY-SWAP','ENGY-B-SWAP') AND Deal_class='None') 
        then Buy_Sell
        when Deal_class='Comm-DelTkt' then Buy_Sell
        else '' end as Buy_Sell,
        case when Deal_class!='Comm-DelTkt'  and
        (ins_type  IN ('ENGY-SWAP','ENGY-B-SWAP') AND Deal_class='None') 
        then UOM
        when Deal_class='Comm-DelTkt' then UOM
        else '' end as UOM 
 from distinct_record
),
max_del_trade as (

select max(ACTUAL_LOADING_DATE1) as delivery_date,
max(TRADE_DATE1) as TRADE_DATE ,l1_id,name
 from main
group by l1_id,name

),
take_del_trade as 
(

select   
Tdate
,BUY_SELL
,Deal_Class
,ins_type
,a.L1_ID
,a.L2_ID
,a.name
,sum_Notional_volume
,Trader_Name
,Trading_Account_Adj as trading_desk
,UoM
,b.L1_ID as right_l1_id
,b.NAME as right_name
,TRADE_DATE
,delivery_date
from filter_deal_class a
left join max_del_trade b
on a.l1_id=b.l1_id
group by 
Tdate
,BUY_SELL
,Deal_Class
,ins_type
,a.L1_ID
,a.L2_ID
,a.name
,sum_Notional_volume
,Trader_Name
,Trading_Account_Adj 
,UoM
,b.L1_ID 
,b.NAME 
,TRADE_DATE
,delivery_date
),
final_output as 
(
select distinct 
Tdate
,BUY_SELL
,Deal_Class
,ins_type
,L1_ID
,L2_ID
,name
,sum_Notional_volume
,Trader_Name
,trading_desk
,UoM
,right_l1_id
,right_name
,TRADE_DATE
,delivery_date
,case when trading_desk='SITME LNG ST - BU' then 'SITME'
 when trading_desk='SNALNG DLNG - BU' then 'SNALNG'
  when trading_desk='SELNG ST - BU' then 'SELNG'
    when trading_desk='BG S&O - BU' then 'BG'

	    when trading_desk='SSLNG ST - BU' then 'SSLNG'
		when trading_desk='BGEM NG - BU' then 'BGEM'
		when trading_desk='SG DLNG MARINE - BU' then 'SG'
		when trading_desk='SNALNG ST - BU' then 'SNALNG'
    when trading_desk='SG DLNG INDUSTRIAL - BU' then 'SG'

when trading_desk='SELNG MT - BU' then 'SELNG'
when trading_desk='SITME LNG MT - BU' then 'SITME'
when trading_desk='SNALNG - BU' then 'SNALNG'
when trading_desk='SELNG BUCKET - BU' then 'SELNG'
end as Trading_entity 
from take_del_trade

)
 
select * from final_output 

""".format(date_filter_df))

# COMMAND ----------

Final_Query_df.createOrReplaceTempView("vw_deal_counterparty_load_final")

# COMMAND ----------

# DBTITLE 1,Get the max trade date per counterparty
# MAGIC %sql
# MAGIC create or replace TEMPORARY View vw_deal_cp_max_trade_date AS 
# MAGIC select cast(l1_id as bigint)  as l1_id
# MAGIC       ,cast(l2_id as bigint) as l2_id
# MAGIC       ,max(cds.TRADE_DATE) as deal_latest_trade_date
# MAGIC 
# MAGIC from vw_deal_counterparty_load_final cds
# MAGIC group by cast(l1_id as bigint)
# MAGIC       ,cast(l2_id as bigint) 

# COMMAND ----------

deal_counterparty_summary = spark.sql("""
select  'SLMT' as source_system_code
       , concat(cpm.l1_id,'_',cpm.l2_id) as cp_deal_mapping_id
       , cpm.deal_latest_trade_date      as deal_latest_trade_date
       , max(cds.delivery_date) as deal_latest_delivery_date
       , concat_ws(",", array_sort((collect_set(cds.TRADER_NAME)))) as deal_latest_trader_name
       ,current_timestamp as meta_created_dttm
       ,current_timestamp as meta_start_dttm
       ,cast('2999-12-31' as timestamp) as meta_end_dttm 
       ,'Y'  as active_indicator
       ,date_format(current_date, 'yyyyMMdd') as report_date_key
from vw_deal_cp_max_trade_date  cpm
left join vw_deal_counterparty_load_final cds on  cpm.l1_id = cds.l1_id 
                                              and cpm.l2_id = cds.l2_id
                                              and cpm.deal_latest_trade_date  = cds.TRADE_DATE
group by concat(cpm.l1_id,'_',cpm.l2_id) 
       , cpm.deal_latest_trade_date
        """)

deal_counterparty_summary.createOrReplaceTempView("vw_deal_counterparty_summary")
deal_counterparty_summary.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty_summary/")

# COMMAND ----------

# DBTITLE 1,deal_counterparty_summary
# deal_counterparty_summary = spark.sql(""" select distinct 'SLMT' as source_system_code
#                                          ,concat(cast(l1_id as bigint),'_',cast(l2_id as bigint)) as cp_deal_mapping_id
#                                          ,max(cds.TRADE_DATE) as deal_latest_trade_date
#                                          ,max(cds.delivery_date) as deal_latest_delivery_date
#                                          ,concat_ws(",", array_sort((collect_set(TRADER_NAME)))) as deal_latest_trader_name
#                                          ,current_timestamp as meta_created_dttm
#                                          ,current_timestamp as meta_start_dttm
#                                          ,cast('2999-12-31' as timestamp) as meta_end_dttm 
#                                          ,'Y'  as active_indicator
#                                          ,date_format(current_date, 'yyyyMMdd') as report_date_key
#                                     from vw_deal_counterparty_load_final cds
#                                     group by concat(cast(l1_id as bigint),'_',cast(l2_id as bigint))
                                            
                                           
#                                    """)
# deal_counterparty_summary.createOrReplaceTempView("vw_deal_counterparty_summary")
# deal_counterparty_summary.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty_summary/")

# COMMAND ----------

# DBTITLE 1,deal_counterparty
deal_counterparty_final = spark.sql("""
                                             select 'SLMT' as source_system_code,
                                              concat(cast(l1_id as bigint),'_',cast(l2_id as bigint)) as cp_deal_mapping_id,
                                              trading_desk as deal_trading_desk,
                                              Trading_entity as deal_trading_entity,
                                              cast(null as string) as deal_trading_entity_long_name,
                                              buy_sell as deal_buy_sell,
                                              deal_class as deal_class,
                                              cast(null as string) as deal_product_type,
                                              date_format(Tdate, 'yyyyMMdd') as deal_date_month_key,
                                              Trader_Name as deal_trader_name,
                                              cast(null as string) as deal_value_unit_of_measure,
                                              Uom as deal_volume_unit_of_measure,
                                              cast('null' as double) as deal_notional_value,
                                              sum(sum_Notional_volume) as deal_notional_volume,
                                              current_timestamp as meta_created_dttm,
                                              current_timestamp as meta_start_dttm,
                                              cast('2999-12-31' as timestamp) as meta_end_dttm,
                                              'Y'  as active_indicator,
                                              date_format(current_date, 'yyyyMMdd') as report_date_key 
                                        from vw_deal_counterparty_load_final
                                        group by  
                                              concat(cast(l1_id as bigint),'_',cast(l2_id as bigint)) ,
                                              trading_desk,
                                              Trading_entity ,
                                              cast(null as string),
                                              buy_sell,
                                              deal_class,
                                              cast(null as string),
                                              date_format(Tdate, 'yyyyMMdd'),
                                              Trader_Name,
                                              cast(null as string),
                                              Uom,
                                              cast('null' as double)
                                  """)
deal_counterparty_final.createOrReplaceTempView("vw_deal_counterparty")
deal_counterparty_final.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty/")

# COMMAND ----------

# DBTITLE 1,writing to the deal_counterparty ADLS folder and storing to the staging the table
cnt_before_writing = deal_counterparty_final.count()
deal_counterparty= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty/")
cnt_after_writing = deal_counterparty.count()

try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty', 'SLMT')
except Exception as r:
  print("For ENDUR_SLMT source system deal_counteparty counts didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Switch partition from deal_counterparty staging table to target table
LoadCuratedTargetTbl('staging', 'deal_counterparty', 'cp_data_hub', 'deal_counterparty', 'SLMT')

# COMMAND ----------

# DBTITLE 1,deal_counterparty_summary to staging table
cnt_before_writing = deal_counterparty_summary.count()
deal_counterparty_summary= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty_summary/")
cnt_after_writing = deal_counterparty_summary.count()
try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty_summary', 'SLMT')
except Exception as r:
  print("For ENDUR_SLMT source system deal_counteparty_summary counts didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Switch partition from deal_counterparty_summary staging table to target table
LoadCuratedTargetTbl('staging', 'deal_counterparty_summary', 'cp_data_hub', 'deal_counterparty_summary', 'SLMT')

# COMMAND ----------

# DBTITLE 1,Function to update refresh date
RefreshDateP3('report_date','NULL','ENDUR_SLMT_FACT_DEAL_PNL_LNG','SLMT') 

# COMMAND ----------

Source_System_Code = 'SLMT'
System ='P3'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
