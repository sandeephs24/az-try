# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

create_temp_views_per_source_system('GMAS', 'GMAS')

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC create or replace temporary view GMAS_Asset as
# MAGIC 
# MAGIC select * from GMAS_ASSET_CARGO
# MAGIC union 
# MAGIC select * from GMAS_ASSET_LOCATION
# MAGIC union 
# MAGIC select * from GMAS_ASSET_ORGANISATION
# MAGIC union 
# MAGIC select * from GMAS_ASSET_PERSON
# MAGIC union 
# MAGIC select * from GMAS_ASSET_VESSEL
# MAGIC union 
# MAGIC select * from GMAS_ASSET_PORT
# MAGIC   

# COMMAND ----------

def remov(x) :
  if x is None or x == '':
    return None
  else:
    return x.lstrip('0')

# COMMAND ----------

spark.udf.register('st',remov)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_SAP_Code_unq_vendon_customer as
# MAGIC 
# MAGIC ( with SAP_Code_unq as 
# MAGIC   (
# MAGIC   select distinct st(SAP_CODE) as SAP_CODE from GMAS_Party_Role
# MAGIC   ),
# MAGIC   Cust_Vendor as 
# MAGIC   (
# MAGIC   select 'Vendor' as SAP_ACCOUNT_TYPE
# MAGIC   union 
# MAGIC   select 'Customer' as SAP_ACCOUNT_TYPE
# MAGIC   )
# MAGIC   
# MAGIC   select * from SAP_Code_unq join Cust_Vendor on 1 = 1
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_gmas_temp as -- view without Req 38 and Req 97
# MAGIC SELECT 
# MAGIC       
# MAGIC       org.ORGANISATION_FULL_NAME                                                         as NAME
# MAGIC     , 'GMAS_' || cast(org.ORGANISATION_ID as int)                                        as UNIQUE_ID
# MAGIC     , cast(cast(org.ORGANISATION_ID as int)  as string)                                  as L2_ID
# MAGIC     , CASE when org.ACTIVE_STATUS = 'Active' Then 'N' else 'Y' end                       as DEACTIVATED
# MAGIC     , cast(org.CREATED_DT  as timestamp)                                                 as CREATED_DATE
# MAGIC     , cast(org.LAST_UPDATED_DT  as timestamp)                                            as UPDATED_DATE
# MAGIC     , st(trim(pr.SAP_CODE))                                                              as SAP_ACCOUNT_NO
# MAGIC     , 'GMAS'                                                                             as SOURCE_SYSTEM
# MAGIC     , trim(a.asset_name)                                                                       as COUNTRY
# MAGIC     , 'STNSAP'                                                                           as SAP_SYSTEM
# MAGIC    -- , a.asset_active_status
# MAGIC     , prt.PARTY_ROLE_TYPE_DESC                                                           as COUNTERPARTY_TYPE
# MAGIC     , org.ORGANISATION_SHORT_NAME                                                        as CP_SHORT_NAME
# MAGIC     
# MAGIC FROM 
# MAGIC     GMAS_Organisation org 
# MAGIC     LEFT JOIN GMAS_Party_Role pr ON org.organisation_id = pr.party_id
# MAGIC     LEFT JOIN GMAS_Address_usage au ON pr.party_role_id = au.party_role_id
# MAGIC     LEFT JOIN GMAS_Address ad ON au.address_id = ad.address_id  
# MAGIC     LEFT JOIN GMAS_Asset a ON ad.country_id = a.asset_id
# MAGIC     LEFT JOIN GMAS_party_role_type prt ON pr.party_role_type_id = prt.party_role_type_id
# MAGIC WHERE 
# MAGIC     prt.party_role_type_code NOT IN ('ORGANISATION_MAIN', 'PERSON_MAIN')
# MAGIC ORDER BY org.organisation_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty as
# MAGIC Select distinct
# MAGIC   
# MAGIC   gm.UNIQUE_ID as cp_unique_id,
# MAGIC   cast(null as string) as cp_legal_entity_id,
# MAGIC   gm.NAME as cp_name,
# MAGIC   gm.L2_ID as cp_business_unit_id,
# MAGIC   gm.NAME as cp_business_unit_name,
# MAGIC   gm.CP_SHORT_NAME as cp_short_name,
# MAGIC   gm.CREATED_DATE as cp_created_date,
# MAGIC   gm.UPDATED_DATE as cp_updated_date,
# MAGIC   gm.DEACTIVATED  as cp_deactivated,
# MAGIC   cast(null as string)   as cp_erate_flag_source,
# MAGIC   cast(null as timestamp)   as cp_erate_date_source,
# MAGIC   cast(null as string)   as cp_erate_flag,
# MAGIC   cast(null as timestamp)   as cp_erate_date,
# MAGIC   gm.L2_ID as cp_account_number,
# MAGIC   gm.L2_ID as cp_deal_mapping_id,
# MAGIC   current_timestamp as meta_created_ddtm,
# MAGIC   current_timestamp as meta_start_ddtm,
# MAGIC   to_date('2999-12-31', 'yyyy-MM-dd') as meta_end_ddtm,
# MAGIC   'Y' as active_indicator,
# MAGIC   'GMAS' as source_system_code,
# MAGIC   date_format(current_date, 'yyyyMMdd') as  report_date_key
# MAGIC  
# MAGIC FROM
# MAGIC   vw_gmas_temp gm

# COMMAND ----------

df = spark.sql("select * from vw_counterparty")
df = df.drop_duplicates()
total_row_cnt = df.count()
print (total_row_cnt)
cp_unique_id_df = df.select(["cp_unique_id"])
cp_unique_id_df = cp_unique_id_df.drop_duplicates()
cp_unique_id_cnt= cp_unique_id_df.count()
print(cp_unique_id_cnt)
try:
  if total_row_cnt == cp_unique_id_cnt:
    RefreshCuratedSqlTbl('staging', 'counterparty', 'GMAS')
except Exception as r:
  print("For GMAS source system counterparty count vs unique_id cnt didn't match")
  raise dbutils.notebook.exit(e)
  
  


# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty', 'cp_data_hub', 'counterparty', 'GMAS')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details as
# MAGIC Select distinct
# MAGIC   
# MAGIC   gm.UNIQUE_ID as cp_unique_id,
# MAGIC   cast(null as string)        as cp_company_code,
# MAGIC   cast(null as string)        as cp_company_name,
# MAGIC   cast(null as string)         as cp_country_code,
# MAGIC   gm.COUNTRY   as cp_country_name,
# MAGIC   gm.COUNTERPARTY_TYPE as counterparty_type,
# MAGIC   current_timestamp as meta_created_ddtm,
# MAGIC   current_timestamp as meta_start_ddtm,
# MAGIC   to_date('2999-12-31', 'yyyy-MM-dd') as meta_end_ddtm,
# MAGIC   'Y' as active_indicator,
# MAGIC   'GMAS' as source_system_code,
# MAGIC   date_format(current_date, 'yyyyMMdd') as  report_date_key
# MAGIC  
# MAGIC FROM
# MAGIC vw_counterparty cp inner join  vw_gmas_temp gm on cp.cp_unique_id = gm.UNIQUE_ID

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details', 'GMAS')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details', 'cp_data_hub', 'counterparty_details', 'GMAS')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details_summary as
# MAGIC   
# MAGIC   
# MAGIC 			select cpd.source_system_code
# MAGIC 			      ,cpd.cp_unique_id
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(counterparty_type))) as counterparty_type
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_code))) as cp_company_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_name))) as cp_company_name
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_code))) as cp_country_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_name))) as cp_country_name
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 				  from vw_counterparty_details cpd
# MAGIC 				  where cpd.source_system_code  in ('GMAS')
# MAGIC 			group by cpd.source_system_code, cpd.cp_unique_id
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details_summary', 'GMAS')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details_summary', 'cp_data_hub', 'counterparty_details_summary', 'GMAS')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_bridge_counterparty_sap_account as
# MAGIC Select distinct
# MAGIC   'GMAS' as source_system_code,
# MAGIC   gm.UNIQUE_ID as cp_unique_id,
# MAGIC   case
# MAGIC     when trim(SAP_ACCOUNT_NO) = ''
# MAGIC     or SAP_ACCOUNT_NO is null then null
# MAGIC     else gm.SAP_SYSTEM || '_' || vc.SAP_ACCOUNT_TYPE || '_' || gm.SAP_ACCOUNT_NO
# MAGIC   end as sap_unique_id,
# MAGIC   gm.SAP_ACCOUNT_NO    as sap_account_number,
# MAGIC   vc.SAP_ACCOUNT_TYPE   as sap_account_type,
# MAGIC  'STNSAP' as sap_source_system_code,
# MAGIC   current_timestamp as meta_created_ddtm,
# MAGIC   current_timestamp as meta_start_ddtm,
# MAGIC   to_date('2999-12-31', 'yyyy-MM-dd') as meta_end_ddtm,
# MAGIC   'Y' as active_indicator,
# MAGIC   date_format(current_date, 'yyyyMMdd') as  report_date_key
# MAGIC  
# MAGIC FROM
# MAGIC vw_counterparty cp inner join  vw_gmas_temp gm on cp.cp_unique_id = gm.UNIQUE_ID
# MAGIC inner join vw_SAP_Code_unq_vendon_customer vc on gm.SAP_ACCOUNT_NO = vc.SAP_CODE  

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'bridge_counterparty_sap_account', 'GMAS')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'bridge_counterparty_sap_account', 'cp_data_hub', 'bridge_counterparty_sap_account', 'GMAS')

# COMMAND ----------

Source_System_Code = 'GMAS'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
