# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 1,Create temp views from ADLS
# source_system , view_prefix_name  parameters to pass to the function
create_temp_views_per_source_system('SAPHANA', 'stnsap')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_stnsap as 
# MAGIC select distinct
# MAGIC   concat(CA_SAP_SYSTEM, '_', CA_CPTY_TYPE, '_', ltrim('0',trim(LIFNR))) as SAP_UNIQUE_ID,
# MAGIC   /*case when NAME1 is null then NAME2
# MAGIC        when NAME2 is null then NAME1
# MAGIC        else concat(NAME1,' ',NAME2)
# MAGIC   end as SAP_NAME,*/
# MAGIC   concat(
# MAGIC        (case when NAME1 = '' then '' else concat(NAME1,' ') end),
# MAGIC        (case when NAME2 = '' then '' else concat(NAME2,' ') end),
# MAGIC        (case when NAME3 = '' then '' else concat(NAME3,' ') end),
# MAGIC        (case when NAME4 = '' then '' else concat(NAME4,' ') end)
# MAGIC   ) as SAP_NAME,                                                   --Added Name3 and Name4 as part of SAP Name 
# MAGIC   --NAME3 AS SAP_NAME3,
# MAGIC   --NAME4 AS SAP_NAME4,
# MAGIC   ltrim('0',trim(LIFNR)) as SAP_ACCOUNT_NO,
# MAGIC   /*concat_ws(',',collect_set(cast(BUKRS as string)) 
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_COMPANY_CODE,
# MAGIC   concat_ws(',',collect_set(cast(BUTXT as string))
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_COMPANY_NAME, */
# MAGIC   BUKRS as SAP_COMPANY_CODE,
# MAGIC   BUTXT as SAP_COMPANY_NAME,
# MAGIC   LAND1 as SAP_COUNTRY,
# MAGIC   LANDX as SAP_COUNTRY_NAME,
# MAGIC   CA_CPTY_TYPE as SAP_CPTY_TYPE,
# MAGIC   --REGIO as SAP_REGION,
# MAGIC   --ORT01 as SAP_CITY,
# MAGIC   --STRAS as SAP_ADDRESS,
# MAGIC   --PSTLZ as SAP_POSTCODE,
# MAGIC   to_date(CA_ERDAT) as SAP_CREATE_DATE,
# MAGIC   --LOEVM as SAP_DEACTIVATED,
# MAGIC   case when LOEVM = 'X' then 'Y' else 'N' end as SAP_DEACTIVATED, --Updated on 21/10
# MAGIC   /*SPERR as SAP_BLOCK_POSTING,
# MAGIC   SPERZ as SAP_BLOCK_PAYMENT,
# MAGIC   SPERM as SAP_BLOCK_PURCHASE,
# MAGIC   concat_ws(',',collect_set(cast(KTOKK as string)) 
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_ACCOUNT_GROUP,
# MAGIC   '' as SAP_SALES_ORG,
# MAGIC   '' as SAP_SALES_ORG_NAME,
# MAGIC   '' as SAP_DISTRIBUTION_CHANNEL,
# MAGIC   '' as SAP_DISTRIBUTION_CHANNEL_NAME,
# MAGIC   '' as SAP_DIVISION,
# MAGIC   '' as SAP_DIVISION_NAME,
# MAGIC   BRSCH as SAP_INDUSTRY_KEY,
# MAGIC   BRTXT as SAP_INDUSTRY_KEY_NAME,
# MAGIC   concat_ws(',',collect_set(cast(EKORG as string)) 
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_PURCHASE_ORG,  
# MAGIC   concat_ws(',',collect_set(cast(EKOTX as string)) 
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_PURCHASE_ORG_NAME,
# MAGIC   concat_ws(',',collect_set(cast(ZAHLS as string)) 
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_PAYMENT_BLOCK,
# MAGIC   concat_ws(',',collect_set(cast(TEXTL as string)) 
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_PAYMENT_BLOCK_REASON,*/
# MAGIC   to_date(CA_UPDAT) as SAP_CHANGE_DATE,
# MAGIC   META_CREATED_DTTM
# MAGIC from
# MAGIC stnsap_CA_CPDATA_STN_VEND_GRA_001 where KTOKK in ('Z001', 'Z002', 'Z004', 'Z005', 'Z006', 'Z007', 'Z008', 'Z009', 'Z010', 'Z011', 'ZACS', 'ZASC', 'ZEMP', 'ZFR', 'ZGCS', 'ZGRP', 'ZIBT', 'ZINT', 'ZLOC', 'ZMCO', 'ZMFP', 'ZMTP', 'ZONE', 'ZOTM', 'ZSML', 'ZSPP', 'ZTPY')
# MAGIC 
# MAGIC union
# MAGIC 
# MAGIC select distinct
# MAGIC   concat(CA_SAP_SYSTEM, '_', CA_CPTY_TYPE, '_', ltrim('0',trim(KUNNR))) as SAP_UNIQUE_ID,
# MAGIC   /*case when NAME1 is null then NAME2
# MAGIC        when NAME2 is null then NAME1
# MAGIC        else concat(NAME1,' ',NAME2)
# MAGIC   end as SAP_NAME,*/
# MAGIC   concat(
# MAGIC        (case when NAME1 = '' then '' else concat(NAME1,' ') end),
# MAGIC        (case when NAME2 = '' then '' else concat(NAME2,' ') end),
# MAGIC        (case when NAME3 = '' then '' else concat(NAME3,' ') end),
# MAGIC        (case when NAME4 = '' then '' else concat(NAME4,' ') end)
# MAGIC   ) as SAP_NAME,                                                   --Added Name3 and Name4 as part of SAP Name 
# MAGIC   --NAME3 AS SAP_NAME3,
# MAGIC   --NAME4 AS SAP_NAME4,
# MAGIC   ltrim('0',trim(KUNNR)) as SAP_ACCOUNT_NO, 
# MAGIC   /*concat_ws(',',collect_set(cast(BUKRS as string)) 
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_COMPANY_CODE,
# MAGIC   concat_ws(',',collect_set(cast(BUTXT as string))
# MAGIC           over (partition by LIFNR,CA_SAP_SYSTEM)) as SAP_COMPANY_NAME, */
# MAGIC   BUKRS as SAP_COMPANY_CODE,
# MAGIC   BUTXT as SAP_COMPANY_NAME,
# MAGIC   LAND1 as SAP_COUNTRY,
# MAGIC   LANDX as SAP_COUNTRY_NAME,
# MAGIC   CA_CPTY_TYPE as SAP_CPTY_TYPE,
# MAGIC   --REGIO as SAP_REGION,
# MAGIC   --ORT01 as SAP_CITY,
# MAGIC   --STRAS as SAP_ADDRESS,
# MAGIC   --PSTLZ as SAP_POSTCODE,
# MAGIC   to_date(CA_ERDAT) as SAP_CREATE_DATE,
# MAGIC   --LOEVM as SAP_DEACTIVATED,
# MAGIC   case when LOEVM = 'X' then 'Y' else 'N' end as SAP_DEACTIVATED, --Updated on 21/10
# MAGIC   /*SPERR as SAP_BLOCK_POSTING,
# MAGIC   SPERZ as SAP_BLOCK_PAYMENT,
# MAGIC   '' as SAP_BLOCK_PURCHASE,
# MAGIC   concat_ws(',',collect_set(cast(KTOKD as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_ACCOUNT_GROUP,
# MAGIC   concat_ws(',',collect_set(cast(VKORG as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_SALES_ORG,
# MAGIC   concat_ws(',',collect_set(cast(VKORG_VTEXT as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_SALES_ORG_NAME,
# MAGIC   concat_ws(',',collect_set(cast(VTWEG as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_DISTRIBUTION_CHANNEL,
# MAGIC   concat_ws(',',collect_set(cast(VTWEG_VTEXT as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_DISTRIBUTION_CHANNEL_NAME,
# MAGIC   concat_ws(',',collect_set(cast(SPART as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_DIVISION,
# MAGIC   concat_ws(',',collect_set(cast(SPART_VTEXT as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_DIVISION_NAME,
# MAGIC   BRSCH as SAP_INDUSTRY_KEY,
# MAGIC   BRTXT as SAP_INDUSTRY_KEY_NAME,
# MAGIC   '' as SAP_PURCHASE_ORG,  
# MAGIC   '' as SAP_PURCHASE_ORG_NAME,
# MAGIC   concat_ws(',',collect_set(cast(ZAHLS as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_PAYMENT_BLOCK,
# MAGIC   concat_ws(',',collect_set(cast(TEXTL as string)) 
# MAGIC           over (partition by KUNNR,CA_SAP_SYSTEM)) as SAP_PAYMENT_BLOCK_REASON,*/
# MAGIC   to_date(CA_UPDAT) as SAP_CHANGE_DATE,
# MAGIC   META_CREATED_DTTM
# MAGIC from
# MAGIC stnsap_CA_CPDATA_STN_CUST_GRA_001 where KTOKD in ('ZTPY', 'ZGRP', 'ZASC', '0004', 'Z001', 'Z002', 'Z004', 'DEBI', 'ZACS', 'ZFR', 'ZGCS', 'ZIBT', 'ZINT', 'ZLOC', 'ZMCO', 'ZONE', 'ZOTM')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty as
# MAGIC select distinct 
# MAGIC     SAP_UNIQUE_ID                         as cp_unique_id,               
# MAGIC     cast(null as string)                  as cp_legal_entity_id,          
# MAGIC     SAP_NAME                              as cp_name,
# MAGIC     cast(null as string)                  as cp_business_unit_id,         
# MAGIC     cast(null as string)                  as cp_business_unit_name,
# MAGIC     cast(null as string)                  as cp_short_name,
# MAGIC     SAP_CREATE_DATE                       as cp_created_date,
# MAGIC     SAP_CHANGE_DATE                       as cp_updated_date,
# MAGIC     SAP_DEACTIVATED                       as cp_deactivated,
# MAGIC     cast(null as string)                  as cp_erate_flag_source,
# MAGIC     cast(null as string)                  as cp_erate_date_source,
# MAGIC     cast(null as string)                  as cp_erate_date,
# MAGIC     SAP_ACCOUNT_NO                        as cp_account_number,
# MAGIC     SAP_UNIQUE_ID                         as cp_deal_mapping_id,
# MAGIC     current_timestamp                     as meta_created_ddtm,
# MAGIC     current_timestamp                     as meta_start_ddtm,
# MAGIC     to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm,
# MAGIC     'Y'                                   as active_indicator,
# MAGIC     'STNSAP'                              as source_system_code,
# MAGIC     date_format(current_date, 'yyyyMMdd') as report_date_key
# MAGIC from vw_cp_master_stnsap 

# COMMAND ----------

#parameters sequence: tgt_schema_name, tgt_table_name, source_system_code -> loading data into counterparty staging table
RefreshCuratedSqlTbl('staging', 'counterparty', 'STNSAP')

# COMMAND ----------

#parameters sequence: staging schema, staging table_name, target_schema_name, target table_name, source_system_code -> loading data into counterparty table
LoadCuratedTargetTbl('staging', 'counterparty', 'cp_data_hub', 'counterparty','STNSAP')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details as 
# MAGIC select distinct 
# MAGIC     SAP_UNIQUE_ID                         as cp_unique_id,               
# MAGIC     SAP_COMPANY_CODE                      as cp_company_code,
# MAGIC     SAP_COMPANY_NAME                      as cp_company_name,
# MAGIC     SAP_COUNTRY                           as cp_country_code,
# MAGIC     SAP_COUNTRY_NAME                      as cp_country_name,         
# MAGIC     SAP_CPTY_TYPE                         as counterparty_type,
# MAGIC     current_timestamp                     as meta_created_ddtm,
# MAGIC     current_timestamp                     as meta_start_ddtm,
# MAGIC     to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm,
# MAGIC     'Y'                                   as active_indicator,
# MAGIC     'STNSAP'                              as source_system_code,
# MAGIC     date_format(current_date, 'yyyyMMdd') as report_date_key
# MAGIC from vw_cp_master_stnsap 

# COMMAND ----------

#Foreign key constraint check in cp_unique_id -> load data into counterparty_details staging table if all cp_unique_id in counterpart_details are present in counterparty table
df = spark.sql("""select distinct cp_unique_id from vw_counterparty_details b
                  where not exists (select * from vw_counterparty a where a.cp_unique_id = b.cp_unique_id)""")
print(df.count())
try:
  if df.count() == 0:
    RefreshCuratedSqlTbl('staging', 'counterparty_details', 'STNSAP')
except Exception as r:
  print("Foreign key constraint failure - cp_unique_id for STNSAP not present in counterparty data")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

#parameters sequence: staging schema, staging table_name, target_schema_name, target table_name, source_system_code -> loading data into counterparty_details table
LoadCuratedTargetTbl('staging', 'counterparty_details', 'cp_data_hub', 'counterparty_details','STNSAP')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details_summary as
# MAGIC   
# MAGIC   select cpd.source_system_code
# MAGIC 				  ,cpd.cp_unique_id
# MAGIC 				  ,cpd.counterparty_type
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_code))) as cp_company_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_name))) as cp_company_name
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_code))) as cp_country_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_name))) as cp_country_name
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 				  from vw_counterparty_details cpd
# MAGIC 				  where cpd.source_system_code in ('STNSAP')
# MAGIC 			group by cpd.source_system_code, cpd.cp_unique_id, cpd.counterparty_type,meta_created_ddtm
# MAGIC                   ,meta_start_ddtm
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 			

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details_summary', 'STNSAP')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details_summary', 'cp_data_hub', 'counterparty_details_summary', 'STNSAP')

# COMMAND ----------

Source_System_Code = 'STNSAP'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
