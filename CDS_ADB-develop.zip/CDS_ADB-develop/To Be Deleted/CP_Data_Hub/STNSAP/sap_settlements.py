# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 1,Create temp views from ADLS
# source_system , view_prefix_name  parameters to pass to the function
create_temp_views_per_source_system('SAPHANA', 'stnsap')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_settlements as
# MAGIC select 
# MAGIC     account_no,
# MAGIC     cpty_type,
# MAGIC     sap_posting_month_key,
# MAGIC     company_cd,
# MAGIC     loc_curr,
# MAGIC     sap_open_cleared_indicator,
# MAGIC     document_type,
# MAGIC     sum(cast(sap_settlement_value_ap_or_ar_lc as decimal(30,5))) as sap_settlement_value_ap_or_ar_lc,
# MAGIC     sum(cast(sap_settlement_value_ap_or_ap_usd as decimal(30,5))) as sap_settlement_value_ap_or_ap_usd,
# MAGIC     sum(cast(sap_sales_purchase_value_lc as decimal(30,5))) as sap_sales_purchase_value_lc,
# MAGIC     sum(cast(sap_sales_purchase_value_usd as decimal(30,5))) as sap_sales_purchase_value_usd
# MAGIC     --sum(sap_settlement_value_ap_or_ar_lc) as sap_settlement_value_ap_or_ar_lc,
# MAGIC     --sum(sap_settlement_value_ap_or_ap_usd) as sap_settlement_value_ap_or_ap_usd, 
# MAGIC     --sum(sap_sales_purchase_value_lc) as sap_sales_purchase_value_lc,
# MAGIC     --sum(sap_sales_purchase_value_usd) as sap_sales_purchase_value_usd 
# MAGIC from
# MAGIC (
# MAGIC   select  
# MAGIC     vendor as account_no,
# MAGIC     'Vendor' as cpty_type,
# MAGIC     date_format(ca_posting_dt, 'yyyyMM01') as sap_posting_month_key,
# MAGIC     company_cd,
# MAGIC     loc_curr,
# MAGIC     'Cleared' as sap_open_cleared_indicator,
# MAGIC     document_type,
# MAGIC     sum(cm_amount_loc_curr) as sap_settlement_value_ap_or_ar_lc,
# MAGIC     sum(cm_amount_in_usd) as sap_settlement_value_ap_or_ap_usd,
# MAGIC     case when document_type in ('X1','KR','Y1','Y5','KA','YN','YL') 
# MAGIC       then sum(cm_amount_loc_curr) 
# MAGIC       else 0 
# MAGIC     end as sap_sales_purchase_value_lc,
# MAGIC     case when document_type in ('X1','KR','Y1','Y5','KA','YN','YL') 
# MAGIC       then sum(cm_amount_in_usd) 
# MAGIC       else 0 
# MAGIC     end as sap_sales_purchase_value_usd
# MAGIC   from stnsap_CA_ERATED_STN_AP_CLEAR_GRA_001
# MAGIC   where ((year(ca_document_dt) >= '2019') or (year(ca_clearing_dt) >= '2019'))
# MAGIC   group by vendor, sap_posting_month_key, company_cd, loc_curr, document_type
# MAGIC   
# MAGIC   union all
# MAGIC   
# MAGIC   select  
# MAGIC     vendor as account_no,
# MAGIC     'Vendor' as cpty_type,
# MAGIC     date_format(ca_posting_dt, 'yyyyMM01') as sap_posting_month_key,
# MAGIC     company_cd,
# MAGIC     loc_curr,
# MAGIC     'Open' as sap_open_cleared_indicator,
# MAGIC     document_type,
# MAGIC     sum(cm_amount_loc_curr) as sap_settlement_value_ap_or_ar_lc,
# MAGIC     sum(cm_amount_in_usd) as sap_settlement_value_ap_or_ap_usd,
# MAGIC     case when document_type in ('X1','KR','Y1','Y5','KA','YN','YL') 
# MAGIC       then sum(cm_amount_loc_curr) 
# MAGIC       else 0 
# MAGIC     end as sap_sales_purchase_value_lc,
# MAGIC     case when document_type in ('X1','KR','Y1','Y5','KA','YN','YL') 
# MAGIC       then sum(cm_amount_in_usd) 
# MAGIC       else 0 
# MAGIC     end as sap_sales_purchase_value_usd
# MAGIC   from stnsap_CA_ERATED_STN_AP_OPEN_GRA_001
# MAGIC   group by vendor, sap_posting_month_key, company_cd, loc_curr, document_type
# MAGIC   
# MAGIC   union all
# MAGIC   
# MAGIC   select  
# MAGIC     customer as account_no,
# MAGIC     'Customer' as cpty_type,
# MAGIC     date_format(ca_posting_dt, 'yyyyMM01') as sap_posting_month_key,
# MAGIC     company_cd,
# MAGIC     loc_curr,
# MAGIC     'Cleared' as sap_open_cleared_indicator,
# MAGIC     document_type,
# MAGIC     sum(cm_amount_loc_curr) as sap_settlement_value_ap_or_ar_lc,
# MAGIC     sum(cm_amount_in_usd) as sap_settlement_value_ap_or_ap_usd,
# MAGIC     case when document_type in ('X2','AB','DR','RV','GL','ZR','Y3','Y6','DG','YM','YK','S3') 
# MAGIC       then sum(cm_amount_loc_curr) 
# MAGIC       else 0 
# MAGIC     end as sap_sales_purchase_value_lc,
# MAGIC     case when document_type in ('X2','AB','DR','RV','GL','ZR','Y3','Y6','DG','YM','YK','S3') 
# MAGIC       then sum(cm_amount_in_usd) 
# MAGIC       else 0 
# MAGIC     end as sap_sales_purchase_value_usd
# MAGIC   from stnsap_CA_ERATED_STN_AR_CLEAR_GRA_001
# MAGIC   where ((year(ca_document_dt) >= '2019') or (year(ca_clearing_dt) >= '2019'))
# MAGIC   group by customer, sap_posting_month_key, company_cd, loc_curr, document_type
# MAGIC   
# MAGIC   union all
# MAGIC   
# MAGIC   select  
# MAGIC     customer as account_no,
# MAGIC     'Customer' as cpty_type,
# MAGIC     date_format(ca_posting_dt, 'yyyyMM01') as sap_posting_month_key,
# MAGIC     company_cd,
# MAGIC     loc_curr,
# MAGIC     'Open' as sap_open_cleared_indicator,
# MAGIC     document_type,
# MAGIC     sum(cm_amount_loc_curr) as sap_settlement_value_ap_or_ar_lc,
# MAGIC     sum(cm_amount_in_usd) as sap_settlement_value_ap_or_ap_usd,
# MAGIC     case when document_type in ('X2','AB','DR','RV','GL','ZR','Y3','Y6','DG','YM','YK','S3') 
# MAGIC       then sum(cm_amount_loc_curr) 
# MAGIC       else 0 
# MAGIC     end as sap_sales_purchase_value_lc,
# MAGIC     case when document_type in ('X2','AB','DR','RV','GL','ZR','Y3','Y6','DG','YM','YK','S3') 
# MAGIC       then sum(cm_amount_in_usd) 
# MAGIC       else 0 
# MAGIC     end as sap_sales_purchase_value_usd
# MAGIC   from stnsap_CA_ERATED_STN_AR_OPEN_GRA_001
# MAGIC   group by customer, sap_posting_month_key, company_cd, loc_curr, document_type
# MAGIC )
# MAGIC group by account_no, cpty_type, sap_posting_month_key, company_cd, loc_curr, sap_open_cleared_indicator, document_type

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_sap_settlements as
# MAGIC select distinct
# MAGIC     concat('STNSAP_',cpty_type,'_',ltrim('0',trim(account_no))) as cp_unique_id,
# MAGIC     sap_posting_month_key,
# MAGIC     company_cd as sap_transacted_company_code,
# MAGIC     loc_curr as sap_settlement_loc_currency,
# MAGIC     sap_open_cleared_indicator,
# MAGIC     document_type as sap_document_type,
# MAGIC     sap_settlement_value_ap_or_ar_lc,
# MAGIC     sap_settlement_value_ap_or_ap_usd,
# MAGIC     sap_sales_purchase_value_lc,
# MAGIC     sap_sales_purchase_value_usd,
# MAGIC     current_timestamp as meta_created_ddtm,
# MAGIC     current_timestamp as meta_start_ddtm,
# MAGIC     to_date('2999-12-31', 'yyyy-MM-dd') as meta_end_ddtm,
# MAGIC     'Y' as active_indicator,
# MAGIC     'STNSAP' as source_system_code,
# MAGIC     date_format(current_date, 'yyyyMMdd') as report_date_key
# MAGIC from 
# MAGIC vw_settlements 

# COMMAND ----------

#parameters sequence: tgt_schema_name, tgt_table_name, source_system_code -> loading data into counterparty staging table
RefreshCuratedSqlTbl('staging', 'sap_settlements', 'STNSAP')

# COMMAND ----------

#parameters sequence: staging schema, staging table_name, target_schema_name, target table_name, source_system_code -> loading data into counterparty table
LoadCuratedTargetTbl('staging', 'sap_settlements', 'cp_data_hub', 'sap_settlements', 'STNSAP')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_settlements_summary_date as
# MAGIC select
# MAGIC     account_no, cpty_type, 
# MAGIC     max(clearing_date) as latest_clearing_date, 
# MAGIC     max(posting_date) as latest_posting_date
# MAGIC     from
# MAGIC (
# MAGIC   select distinct
# MAGIC     vendor as account_no,
# MAGIC     'Vendor' as cpty_type,
# MAGIC     ifnull(ca_clearing_dt,'') as clearing_date,
# MAGIC     ifnull(ca_posting_dt,'') as posting_date
# MAGIC   from stnsap_CA_ERATED_STN_AP_CLEAR_GRA_001
# MAGIC   where ((year(ca_document_dt) >= '2019') or (year(ca_clearing_dt) >= '2019'))
# MAGIC   
# MAGIC   union all
# MAGIC   
# MAGIC   select distinct
# MAGIC     vendor as account_no,
# MAGIC     'Vendor' as cpty_type,
# MAGIC     ifnull(ca_clearing_dt,'') as clearing_date,
# MAGIC     ifnull(ca_posting_dt,'') as posting_date
# MAGIC   from stnsap_CA_ERATED_STN_AP_OPEN_GRA_001
# MAGIC   
# MAGIC   union all
# MAGIC   
# MAGIC   select distinct
# MAGIC     customer as account_no,
# MAGIC     'Customer' as cpty_type,
# MAGIC     ifnull(ca_clearing_dt,'') as clearing_date,
# MAGIC     ifnull(ca_posting_dt,'') as posting_date
# MAGIC   from stnsap_CA_ERATED_STN_AR_CLEAR_GRA_001
# MAGIC   where ((year(ca_document_dt) >= '2019') or (year(ca_clearing_dt) >= '2019'))
# MAGIC   
# MAGIC   union all
# MAGIC   
# MAGIC   select distinct
# MAGIC     customer as account_no,
# MAGIC     'Customer' as cpty_type,
# MAGIC     ifnull(ca_clearing_dt,'') as clearing_date,
# MAGIC     ifnull(ca_posting_dt,'') as posting_date
# MAGIC   from stnsap_CA_ERATED_STN_AR_OPEN_GRA_001
# MAGIC )
# MAGIC group by account_no, cpty_type

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_settlements_summary as
# MAGIC select
# MAGIC   account_no, 
# MAGIC   cpty_type,
# MAGIC   case when latest_posting_date > latest_clearing_date then date_format(latest_posting_date, 'yyyyMMdd')
# MAGIC     else date_format(latest_clearing_date, 'yyyyMMdd') end as sap_latest_settlement_date_key
# MAGIC from 
# MAGIC vw_settlements_summary_date

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_sap_settlements_summary as
# MAGIC select distinct
# MAGIC     concat('STNSAP_',cpty_type,'_',ltrim('0',trim(account_no))) as cp_unique_id,
# MAGIC     sap_latest_settlement_date_key,
# MAGIC     current_timestamp as meta_created_ddtm,
# MAGIC     current_timestamp as meta_start_ddtm,
# MAGIC     to_date('2999-12-31', 'yyyy-MM-dd') as meta_end_ddtm,
# MAGIC     'Y' as active_indicator,
# MAGIC     'STNSAP' as source_system_code,
# MAGIC     date_format(current_date, 'yyyyMMdd') as report_date_key
# MAGIC from 
# MAGIC vw_settlements_summary 

# COMMAND ----------

#parameters sequence: tgt_schema_name, tgt_table_name, source_system_code -> loading data into sap_settlements_summary staging table
RefreshCuratedSqlTbl('staging', 'sap_settlements_summary', 'STNSAP')

# COMMAND ----------

#parameters sequence: staging schema, staging table_name, target_schema_name, target table_name, source_system_code -> loading data into sap_settlements_summary table
LoadCuratedTargetTbl('staging', 'sap_settlements_summary', 'cp_data_hub', 'sap_settlements_summary', 'STNSAP')

# COMMAND ----------

# DBTITLE 1,Function for refresh date
RefreshDateP4('last_dtm','stnsap_CA_ERATED_STN_AP_CLEAR_GRA_001','stnsap_CA_ERATED_STN_AP_OPEN_GRA_001','stnsap_CA_ERATED_STN_AR_CLEAR_GRA_001','stnsap_CA_ERATED_STN_AR_OPEN_GRA_001','STNSAP')

# COMMAND ----------

Source_System_Code = 'STNSAP'
System ='P4'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
