# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 1,Read erate_salesforce data from curated tb
tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['erate_salesforce']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

curated_schema_name= 'ENDUR' 
curated_tables_list = ['ENDNA_PROD_ACTIVITY','ENDNA_PROD_SAP_IDS_MAPPING']
for table_name in curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_endur_products as 
# MAGIC select distinct cpty_erated_flag as CP_ERATED_FLAG,
# MAGIC cpty_id as UNIQUE_ID,
# MAGIC --cpty_legal_entity_long_name as L1_LONG_NAME,
# MAGIC activity.cpty_legal_name as L1_LONG_NAME,
# MAGIC cpty_legal_entity_id as L1_ID,
# MAGIC cpty_bunit_id as L2_ID,
# MAGIC /* new cp_l2_name definition as per Paul confirmed with Josephine  changed on 6/3/2021*/
# MAGIC case when length(trim(cpty_bunit_short_name)) >0 then cpty_bunit_short_name
# MAGIC   when length(trim(cpty_bunit_short_name)) = 0 then cpty_bunit_long_name
# MAGIC   when length(trim(cpty_bunit_long_name)) = 0 then cpty_legal_entity_short_name
# MAGIC  end as L2_LONG_NAME,
# MAGIC   /* new cp_short_name definition changed on 6/30/2021*/
# MAGIC  case when length(trim(cpty_bunit_short_name)) >0 then cpty_bunit_short_name
# MAGIC   when length(trim(cpty_bunit_short_name)) = 0 then cpty_bunit_long_name
# MAGIC   when length(trim(cpty_bunit_long_name)) = 0 then cpty_legal_entity_short_name
# MAGIC  end as CP_SHORT_NAME,
# MAGIC cpty_entity_type as ENTITY_TYPE,
# MAGIC cpty_deactivated_flag as DEACTIVATED,
# MAGIC cast(cpty_create_date as timestamp) as CP_CREATE_DATE,
# MAGIC cast(cpty_update_date as timestamp) as CP_UPDATE_DATE,
# MAGIC ltrim('0',trim(mapping.SAP_ID)) as SAP_ID,
# MAGIC 'ENDNA_PROD' as SYSTEM,
# MAGIC --case when mapping.SAP_ID is null then '' else mapping.CUST_VEND_IND_NM end as SAP_CPTY_TYPE,
# MAGIC mapping.CUST_VEND_IND_NM as SAP_CPTY_TYPE,
# MAGIC --case when mapping.SAP_ID is null then '' when mapping.INT_LENTITY_ID = '20034' then 'GSAP' else 'TSAP' end as SAP_SYSTEM,
# MAGIC case when mapping.SAP_ID is null then null when mapping.INT_LENTITY_ID = '20034' then 'GSAP' else 'TSAP' end as SAP_SYSTEM,
# MAGIC concat((case when mapping.INT_LENTITY_ID = '20034' then 'GSAP' else 'TSAP' end), '_', (mapping.CUST_VEND_IND_NM), '_', (mapping.SAP_ID)) as SAP_UNIQUE_ID,
# MAGIC 'ENDUR_PRODUCTS' as SOURCE_SYSTEM,
# MAGIC current_timestamp as META_CREATED_DTTM
# MAGIC from
# MAGIC vw_ENDUR_ENDNA_PROD_ACTIVITY activity
# MAGIC left outer join 
# MAGIC vw_ENDUR_ENDNA_PROD_SAP_IDS_MAPPING mapping
# MAGIC on activity.cpty_bunit_id = mapping.EXT_BUNIT_ID 
# MAGIC where cpty_id not like '%UNKNOWN%'
# MAGIC --and cpty_erated_flag != '?'

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty as 
# MAGIC select distinct 
# MAGIC     endurprod.UNIQUE_ID                      as cp_unique_id                -- req-26
# MAGIC   , endurprod.L1_ID                          as cp_legal_entity_id          -- l1_id (req-28)
# MAGIC   , endurprod.L1_LONG_NAME                   as cp_name
# MAGIC   , endurprod.L2_ID                                    as cp_business_unit_id          
# MAGIC   , endurprod.L2_LONG_NAME                             as cp_business_unit_name
# MAGIC   , endurprod.cp_short_name                         as cp_short_name
# MAGIC   , cast(endurprod.CP_CREATE_DATE as timestamp)   as cp_created_date
# MAGIC   , cast(endurprod.CP_UPDATE_DATE as timestamp)             as cp_updated_date
# MAGIC   , endurprod.DEACTIVATED                                     as cp_deactivated
# MAGIC   , endurprod.CP_ERATED_FLAG                                  as cp_erate_flag_source
# MAGIC   , CAST (NULL AS TIMESTAMP)                                  as cp_erate_date_source
# MAGIC   , case when endurprod.CP_ERATED_FLAG = 'Y' then 'Y' Else 'N' END as cp_erate_flag
# MAGIC  ,  case when endurprod.CP_ERATED_FLAG is not null then to_date(er.erate_completion_date, 'yyyy-MM-dd') else null end as cp_erate_date
# MAGIC   , endurprod.L2_ID                             as cp_account_number
# MAGIC   , endurprod.UNIQUE_ID                         as cp_deal_mapping_id
# MAGIC   , current_timestamp as meta_created_ddtm
# MAGIC   , current_timestamp as meta_start_ddtm
# MAGIC   ,  to_date('2999-12-31', 'yyyy-MM-dd') as meta_end_ddtm
# MAGIC   , 'Y' as active_indicator
# MAGIC   , 'ENDUR_PRODUCTS' as source_system_code
# MAGIC   ,date_format(current_date, 'yyyyMMdd') as  report_date_key
# MAGIC from vw_cp_master_endur_products endurprod                      
# MAGIC left join vw_cp_data_hub_erate_salesforce   er   on (endurprod.UNIQUE_ID = er.cp_unique_id and er.source_system ='ENDNA_PROD')

# COMMAND ----------

# DBTITLE 1,Counterparty
cp_df = spark.sql("select * from vw_counterparty")
cp_df = cp_df.drop_duplicates()
total_row_cnt = cp_df.count()
print (total_row_cnt)
cp_unique_id_df = cp_df.select(["cp_unique_id"])
cp_unique_id_df = cp_unique_id_df.drop_duplicates()
cp_unique_id_cnt= cp_unique_id_df.count()
print(cp_unique_id_cnt)
try:
  if total_row_cnt == cp_unique_id_cnt:
    RefreshCuratedSqlTbl('staging', 'counterparty', 'ENDUR_PRODUCTS')
except Exception as e:
  print("For ENDUR_PRODUCTS source system counterparty count vs unique_id cnt didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'counterparty', 'cp_data_hub', 'counterparty', 'ENDUR_PRODUCTS')

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['counterparty']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

cp_details_df = spark.sql("""
                          select distinct
                            endurprod.UNIQUE_ID            as cp_unique_id 
                            ,cast(NULL as string)          as cp_company_code
                            ,cast(NULL as string)          as cp_company_name
                            ,cast(NULL as string)          as cp_country_code
                            ,cast(NULL as string)          as cp_country_name
                            ,cast(NULL as string)          as counterparty_type
                            ,current_timestamp             as meta_created_ddtm
                            ,current_timestamp             as meta_start_ddtm
                            ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                            ,'Y'                                   as active_indicator
                            ,'ENDUR_PRODUCTS'                      as source_system_code
                            ,date_format(current_date, 'yyyyMMdd') as  report_date_key
                           from vw_cp_master_endur_products  endurprod
                          """)
#creating temp view
cp_details_df.createOrReplaceTempView("vw_counterparty_details")

# need to get the distinct unique_id counts
cp_details_cp_unique_id_cnt = cp_details_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_counterparty_details cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)                               
#load process
try:
  if cp_unique_id_cnt >= cp_details_cp_unique_id_cnt and cp_unique_id_not_in_cp_df.count()==0:
    print(f"""Count Match: {cp_unique_id_cnt} and {cp_details_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of counterparty_details is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'counterparty_details', 'ENDUR_PRODUCTS')
except Exception as e:
  print("For ENDUR_PRODUCTS source system counterparty count and counterparty Details unique_id didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'counterparty_details', 'cp_data_hub', 'counterparty_details', 'ENDUR_PRODUCTS')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details_summary as
# MAGIC   
# MAGIC 			select cpd.source_system_code
# MAGIC 			      ,cpd.cp_unique_id
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(counterparty_type))) as counterparty_type
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_code))) as cp_company_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_name))) as cp_company_name
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_code))) as cp_country_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_name))) as cp_country_name
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 				  from vw_counterparty_details cpd
# MAGIC 				  where cpd.source_system_code in ('ENDUR_PRODUCTS')
# MAGIC 			group by cpd.source_system_code, cpd.cp_unique_id
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details_summary', 'ENDUR_PRODUCTS')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details_summary', 'cp_data_hub', 'counterparty_details_summary', 'ENDUR_PRODUCTS')

# COMMAND ----------

bdg_cp_sap_account_df = spark.sql("""
                                 select distinct 
                                    endurprod.UNIQUE_ID             as cp_unique_id 
                                   ,endurprod.SAP_UNIQUE_ID         as sap_unique_id
                                   ,endurprod.SAP_ID                as sap_account_number
                                   ,endurprod.SAP_CPTY_TYPE         as sap_account_type
                                   ,endurprod.SAP_SYSTEM            as sap_source_system_code
                                   ,current_timestamp               as meta_created_ddtm
                                   ,current_timestamp               as meta_start_ddtm
                                   ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                                   ,'Y'                                   as active_indicator
                                   ,'ENDUR_PRODUCTS'                          as source_system_code
                                   ,date_format(current_date, 'yyyyMMdd') as  report_date_key 
                                from  vw_cp_master_endur_products  endurprod
                                where endurprod.SAP_UNIQUE_ID is not null and length(endurprod.SAP_UNIQUE_ID) > 0
                                """)
#creating temp view
bdg_cp_sap_account_df.createOrReplaceTempView("vw_bridge_counterparty_sap_account")

# need to get the distinct unique_id counts
bdg_cp_sap_account_cp_unique_id_cnt = bdg_cp_sap_account_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
bdg_cp_sap_account_cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_bridge_counterparty_sap_account cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)
                                       
#load process
if cp_unique_id_cnt >= bdg_cp_sap_account_cp_unique_id_cnt and bdg_cp_sap_account_cp_unique_id_not_in_cp_df.count()==0:
  try:
  
    print(f"""Count Match: {cp_unique_id_cnt} and {bdg_cp_sap_account_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of bridge_counterparty_sap_account is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'bridge_counterparty_sap_account', 'ENDUR_PRODUCTS')
  
  except Exception as e:
    print("For ENDUR_PRODUCTS source system counterparty count and bridge_counterparty_sap_accnt cp_unique_id didn't match")
    raise dbutils.notebook.exit(e)
elif {cp_unique_id_cnt} < {bdg_cp_sap_account_cp_unique_id_cnt}: 
  print(f"""counterparty: {cp_unique_id_cnt}""")
  print(f"""bridge_counterparty_sap_account: {bdg_cp_sap_account_cp_unique_id_cnt}""")
  print("Count match is not working ")
else:
  print(f"""cp_unique_id exists in bridge counterparty sap account table but in counterparty table""")

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'bridge_counterparty_sap_account', 'cp_data_hub', 'bridge_counterparty_sap_account', 'ENDUR_PRODUCTS')

# COMMAND ----------

Source_System_Code = 'ENDUR_PRODUCTS'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
