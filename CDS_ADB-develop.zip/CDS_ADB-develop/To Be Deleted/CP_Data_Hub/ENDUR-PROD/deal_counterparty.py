# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 1,Parameters
dbutils.widgets.text("pm_adls_proj_folder", "P00014-Cross_Comm-CPData-DEV")
v_adls_folder = dbutils.widgets.get("pm_adls_proj_folder")

# COMMAND ----------

# DBTITLE 1,ADLS Staging and Target Paths of CP Data Hub Project
adls_file_path_full_src = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/staging/endur_products/source_file/"
adls_file_path_tgt      = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/cp_data_hub/endur_products/"
partition_by_cols_stg= ['source_system_code','report_date_key']
partition_by_cols_tgt = ["source_system_code"]

# COMMAND ----------

# DBTITLE 1,Reading the Source Data from Curated DB
#to read data ingested in table in curated db instead on ADLS
curated_schema_name= 'ENDUR' 
curated_tables_list = ['ENDNA_PROD_ACTIVITY']
for table_name in curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{curated_schema_name}_{table_name}")

# COMMAND ----------

# DBTITLE 1,Creating Date Key Columns for the date columns
#creating a date_key column of integer type and converting all date columns from string to date datatype
date_columns = ["max_trade_date", "max_activity_date", "max_prod_date","max_contract_end_date"]
for col_name in date_columns:
    df= df.withColumn(f"{col_name}_key",date_format(to_date(col(f"{col_name}"),"yyyy-MM-dd"),"yyyyMMdd").cast(IntegerType()))
    df= df.withColumn(f"{col_name}",date_format(to_date(col(f"{col_name}"),"yyyy-MM-dd"),"yyyy-MM-dd").cast("date"))
    
df = df.withColumn("source_system_code",lit('ENDUR_PRODUCTS')) #adding source_system_code
df = df.withColumn("meta_created_dttm",current_timestamp()) #adding source_system_code
df = df.withColumn("report_date_key", date_format(current_timestamp(),'yyyyMMdd').cast(IntegerType()))  # report date key 
df.printSchema()

# COMMAND ----------

#dbutils.fs.rm(adls_file_path_full_src, True)

# COMMAND ----------

# DBTITLE 1,Staging the data in CP DATA HUB ADLS 
df.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_stg).save(adls_file_path_full_src)

# COMMAND ----------

# DBTITLE 1,Read from Staged Folder
endur_prod_df  = spark.read.format('delta').load(adls_file_path_full_src)
# endur_prod_df.count()

# COMMAND ----------

# DBTITLE 1,Get the max meta created datetime from the DF
max_created_dttm = endur_prod_df.select(max("meta_created_dttm")).collect()[0][0] # 2021-10-26 02:39:..
print(max_created_dttm)

# COMMAND ----------

# DBTITLE 1,Filter the data to the latest data staged
endur_prod_df_latest = endur_prod_df.filter(endur_prod_df.meta_created_dttm == max_created_dttm)

# COMMAND ----------

# DBTITLE 1,Column's list need for the deal_counterparty and deal_counterparty_summary
deal_cp_col_list = ["cpty_bunit_short_name", "cpty_bunit_long_name", "cpty_create_date", "cpty_entity_type", "cpty_update_date",  "cpty_id", "cpty_legal_entity_short_name", 
                    "internal_legal_entity_name", "max_activity_date", "max_contract_end_date", "max_prod_date", "max_trade_contract", "max_trade_date","max_trade_trader","system","trade_desk"]
deal_counterparty_df = endur_prod_df_latest[deal_cp_col_list]
#converting empty string to Null for max_trade_trader for seamless concat in deal_summary
deal_counterparty_df = deal_counterparty_df.withColumn("max_trade_trader", when(trim(col('max_trade_trader')) != "", col('max_trade_trader')).otherwise(None)) 
deal_counterparty_df.createOrReplaceTempView("vw_deal_counterparty")

# COMMAND ----------

# DBTITLE 1,Getting the  max and greatest of the date columns as per logic defined.
# deal_latest_trade_date = max of max_trade_Date
# deal_latest_delivery_date = greatest of the max_activity_date and max_prod_date
deal_counterpary_summary_df  =  deal_counterparty_df.groupBy("cpty_id").agg(max("max_trade_date"), max("max_contract_end_date"),\
                                                                           max("max_trade_date").alias("deal_latest_trade_date"),\
                                                                           max("max_activity_date"),max("max_prod_date"),\
                                                                           greatest(max("max_activity_date"),max("max_prod_date")).alias("deal_latest_delivery_date")
                                                                          )

#create the temp view
deal_counterpary_summary_df.createOrReplaceTempView("vw_deal_counterparty_summary")

# COMMAND ----------

#deal_counterpary_summary_df.filter("cpty_id = 'ENDNA_PROD_28036_28035'").show(truncate=False)

# COMMAND ----------

# DBTITLE 1,deal_counterparty_summary
deal_counterparty_summary = spark.sql(""" select  'ENDUR_PRODUCTS' as source_system_code
                                         ,cds.cpty_id as cp_deal_mapping_id
                                         ,cds.deal_latest_trade_date
                                         ,cds.deal_latest_delivery_date
                                         ,concat_ws(",", array_sort(collect_set(cd.max_trade_trader))) as deal_latest_trader_name
                                         ,current_timestamp as meta_created_dttm
                                         ,current_timestamp as meta_start_dttm
                                         ,cast('2999-12-31' as timestamp) as meta_end_dttm 
                                         ,'Y'  as active_indicator
                                         , date_format(current_date, 'yyyyMMdd') as report_date_key
                                    from        vw_deal_counterparty         cd
                                    inner join  vw_deal_counterparty_summary cds on cd.cpty_id = cds.cpty_id 
                                    and (cds.deal_latest_trade_date = cd.max_trade_date or cds.deal_latest_trade_date = cd.max_contract_end_date)
                                    group by cds.cpty_id
                                           , cds.deal_latest_trade_date
                                           , cds.deal_latest_delivery_date
                                     """).dropna()
deal_counterparty_summary.createOrReplaceTempView("vw_deal_counterparty_summary")
deal_counterparty_summary.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty_summary/")

# COMMAND ----------

#display(deal_counterparty_summary.filter("cp_deal_mapping_id = 'ENDNA_PROD_28036_28035'"))#.show(truncate=False)

# COMMAND ----------

# DBTITLE 1,deal_counterparty
deal_counterparty_final = deal_counterparty_df.select(lit('ENDUR_PRODUCTS').alias('source_system_code')
                                                ,col('cpty_id').alias('cp_deal_mapping_id')
                                                ,col('trade_desk').alias('deal_trading_desk')
                                                ,lit('').alias('deal_trading_entity')
                                                ,col('internal_legal_entity_name').alias('deal_trading_entity_long_name')
                                                ,lit('').alias('deal_buy_sell')
                                                ,lit('').alias('deal_class')
                                                ,lit('').alias('deal_product_type')
                                                ,lit('null').cast('Integer').alias('deal_date_month_key')
                                                ,lit('').alias('deal_trader_name')
                                                ,lit('').alias('deal_value_unit_of_measure')
                                                ,lit('').alias('deal_volume_unit_of_measure')
                                                ,lit('null').cast('Decimal').alias('deal_notional_value')
                                                ,lit('null').cast('Decimal').alias('deal_notional_volume')
                                                ,col("current_timestamp").alias('meta_created_dttm')
                                                ,col("current_timestamp").alias('meta_start_dttm')
                                                ,to_date(lit('2999-12-31')).alias('meta_end_dttm')
                                                ,lit('Y').alias('active_indicator')
                                                ,date_format(col("current_date"),'yyyyMMdd').alias('report_date_key')
                                               ).drop_duplicates()
deal_counterparty_final.createOrReplaceTempView("vw_deal_counterparty")
deal_counterparty_final.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty/")
# df.withColumn("foobar", lit(null).cast(StringType))

# COMMAND ----------

# DBTITLE 1,writing to the deal_counterparty ADLS folder and storing to the staging the table
cnt_before_writing = deal_counterparty_final.count()
deal_counterparty= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty/")
cnt_after_writing = deal_counterparty.count()

try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty', 'ENDUR_PRODUCTS')
except Exception as r:
  print("For ENDUR_PRODUCTS source system deal_counteparty counts didn't match")
  raise dbutils.notebook.exit(e)
        

# COMMAND ----------

# DBTITLE 1,Switch the partitions
LoadCuratedTargetTbl('staging', 'deal_counterparty', 'cp_data_hub', 'deal_counterparty', 'ENDUR_PRODUCTS')

# COMMAND ----------

# DBTITLE 1,deal_counterparty_summary ==> staging table
cnt_before_writing = deal_counterparty_summary.count()
deal_counterparty_summary= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty_summary/")
cnt_after_writing = deal_counterparty_summary.count()
try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty_summary', 'ENDUR_PRODUCTS')
except Exception as r:
  print("For ENDUR_PRODUCTS source system deal_counteparty_summary counts didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Switch Partition from staging table target table
LoadCuratedTargetTbl('staging', 'deal_counterparty_summary', 'cp_data_hub', 'deal_counterparty_summary', 'ENDUR_PRODUCTS')

# COMMAND ----------

# DBTITLE 1,Function to update refresh date
RefreshDateP3('last_modified_date','ENDUR','ENDNA_PROD_ACTIVITY','ENDUR_PRODUCTS') 

# COMMAND ----------

Source_System_Code = 'ENDUR_PRODUCTS'
System ='P3'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
