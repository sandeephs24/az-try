# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 1,ADLS Staging and Target Paths of CP Data Hub Project
#parameterize base folder
dbutils.widgets.text("pm_adls_proj_folder", "P00014-Cross_Comm-CPData-DEV")
v_adls_folder = dbutils.widgets.get("pm_adls_proj_folder")

#derive final paths
adls_file_path_full_src = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/staging/endur_gp_na/source_file/"
adls_file_path_tgt      = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/cp_data_hub/endur_gp_na/"
partition_by_cols_stg= ['source_system_code','report_date_key']
partition_by_cols_tgt = ["source_system_code"]

# COMMAND ----------

create_temp_views_per_source_system('ENDUR_GP_NA', 'gpna')

# COMMAND ----------

# DBTITLE 1,Reading the Source Data from ADLS (Lepton data special)
# source_system , view_prefix_name  parameters to pass to the function
def create_temp_views_per_source_system(source_system,vw_prefix_name):
    """
     create tempviews for adls paths
    """
    src_tables_List= [] # empty to store the table name and filepath
    temp_views_List= [] # temporary views to print the in notebook when called.
    df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'cp_data.config_adls_paths') # read config table to retrieve the adls file paths
    df = df.filter(f"source_system == '{source_system}'")
    df = df.filter("active_flag == 0")
    df.createOrReplaceTempView(f"vw_cp_data_config_adls_paths")
    df_new = df.toPandas()

    dataframedict = {}
    for row in df_new.itertuples():
        src_tables_List.append((row.src_table_name,  row.old_adls_full_path, row.new_adls_full_path))
        if row.adls_file_format =='parquet' and row.old_new_adls_path_indicator =='OLD':
          dataframedict[row.src_table_name] = spark.read.format("parquet").load(row.old_adls_full_path).filter("ACTIVE_INDICATOR ='Y'")
        elif row.adls_file_format =='delta' and row.old_new_adls_path_indicator =='OLD':
          dataframedict[row.src_table_name] = spark.read.format("delta").load(row.old_adls_full_path).filter("ACTIVE_INDICATOR ='Y'")
#        elif row.adls_file_format =='parquet' and row.old_new_adls_path_indicator =='NEW':
#          dataframedict[row.src_table_name] = spark.read.format("parquet").load(row.new_adls_full_path) #.filter(col("IS_RECORD_ACTIVE") == 1)
#        elif row.adls_file_format =='delta' and row.old_new_adls_path_indicator =='NEW':
#          dataframedict[row.src_table_name] = spark.read.format("delta").load(row.new_adls_full_path) #.filter(col("IS_RECORD_ACTIVE") == 1)
#          
    #create the temporary views
    for key,value in dataframedict.items():
        temp_views_List.append(f"{vw_prefix_name}_{key}")
        dataframedict[key] = value.createOrReplaceTempView(f"{vw_prefix_name}_{key}")
    print("Temp View Names")
    print(temp_views_List)
#    temp_views_List_new = []
#    exception_list =['gpna_CURRENCY', 'gpna_GAS_PHYS_LOCATION']
#    for vw in temp_views_List:
#        vw = vw.replace('vw_','')
#        if vw not in exception_list:
#            
#            df = spark.sql(f"""select * from {vw} where ACTIVE_INDICATOR ='Y'""")
#            df.createOrReplaceTempView(f"{vw}")
#            temp_views_List_new.append(vw)
#        else:
#           
#            df = spark.sql(f"""select * from {vw} where LatestSCDRecordFlag ='Y'""")
#            df.createOrReplaceTempView(f"{vw}")
#            temp_views_List_new.append(vw)
#            
#    print("Use below names: ")
#    print(temp_views_List_new)
    
create_temp_views_per_source_system('ENDUR_GP_NA', 'gpna')

# COMMAND ----------

# DBTITLE 1,Volumes Query combined
df_volumes = spark.sql("""
select 
  ab.external_bunit as l2_id
, ile.long_name     as corporate_entity
, po.name           as trading_desk
, i.name            as deal_class
, PER.NAME          as trader_name
, 'Gas'             as product_traded
, bs.name           as buy_sell
, cur.name          as currency_uom
, iu.unit_label     as UOM
, cast(ab.trade_date as date)  as trade_date
, cast(pro.end_date as date)   as delivery_date
,cast(date_format(pro.end_date, 'yyyy-MM-01') as Date) as trade_month
, sum(cast(abs(PRO.NOTNL) as DECIMAL(30,5)))  as notional_volume 
, sum(cast(abs(PRO.PYMT) as DECIMAL(30,5)))   as notional_value
/*not needed for deal_counterparty or deal_counterparty_summary 
--, EBU.LONG_NAME as bu_long_name --not needed
, ab.external_lentity
, ele.long_name as le_long_name
, ab.internal_lentity
, gpl.location_name 
, 'NA' as product_grade
, ab.start_date as contract_start_date
, ab.maturity_date as contract_end_date
, pro.start_date as leg_start_date
, ab.deal_tracking_num
,P.PARAM_SEQ_NUM as fin_param
,phys_p.param_seq_num as phys_param
*/

from       gpna_ab_tran           ab
inner join gpna_parameter         p     on  p.ins_num = ab.ins_num
--inner join gpna_party             ele   on  ab.external_lentity = ele.party_id
inner join gpna_party             ebu   on  ab.external_bunit = ebu.party_id
inner join gpna_instruments       i     on ab.ins_type = i.id_number
inner join gpna_buy_sell          bs    on ab.buy_sell = BS.ID_NUMBER
inner join gpna_party             ile   on ab.internal_lentity = ile.party_id
inner join gpna_currency          cur   on p.currency = cur.id_number 
inner join gpna_idx_unit          iu    on iu.unit_id = p.unit
inner join gpna_parameter         phys_p on phys_p.ins_num = p.ins_num
inner join gpna_gas_phys_param    gpp 	on phys_p.ins_num = gpp.ins_num and phys_p.param_seq_num = gpp.param_seq_num
--inner join gpna_gas_phys_location gpl 	on gpp.location_id = gpl.location_id
inner join gpna_portfolio         po 	on ab.internal_portfolio = po.id_number
inner join gpna_personnel         per on ab.internal_contact = PER.ID_NUMBER
inner join gpna_profile            pro on  phys_p.param_seq_num = pro.param_seq_num and phys_p.ins_num = pro.ins_num
left join  gpna_phys_header       	ph  on  ab.ins_num  = ph.ins_num
where
    ab.current_flag = 1
and ab.tran_status <> 5 --Not cancelled
and ab.tran_status <> 1 --Not Pending
and ab.tran_status <> 14 --Not Deleted
and ab.ins_type not in (48000, 48020, 48030, 1000023)
-- and ab.offset_tran_type = 0 --3P deals only
and ab.offset_tran_type in (0,1, 2) --Include external, internal, offsetting deals
and phys_p.settlement_type = 2
and ((ph.pricing_level = 0 and p.param_seq_num = phys_p.param_seq_num + 1) 
or(ph.pricing_level = 1 and p.param_seq_num = 0))
-- and ab.start_date <= '31-Dec-2030'  --Removing this restriction
and ab.maturity_date >= cast('2018-01-01' as date) --Limit to only deals past 01-jan-2018
and pro.end_date >=  cast('2018-01-01' as date)  --Limit to only deals past 01-jan-2018
group by 
  ab.external_bunit 
, ile.long_name     
, po.name           
, i.name            
, PER.NAME          
, 'Gas'             
, bs.name           
, cur.name          
, iu.unit_label     
, cast(ab.trade_date as date)  
, cast(pro.end_date as date)   
,cast(date_format(pro.end_date, 'yyyy-MM-01') as Date)

UNION ALL 
select 
  ab.external_bunit as l2_id
, ile.long_name     as corporate_entity
, po.name           as trading_desk
, i.name            as deal_class
, PER.NAME          as trader_name
, 'Gas'             as product_traded
, bs.name           as buy_sell
, cur.name          as currency_uom
, iu.unit_label     as UOM
,cast(ab.trade_date as date) as  trade_date
,cast(pro.end_date as date)  as  delivery_date
,cast(date_format(pro.end_date, 'yyyy-MM-01') as Date) as trade_month
, sum(cast(abs(PRO.NOTNL) as DECIMAL(30,5))) as notional_volume 
, sum(cast(abs(PRO.PYMT) as DECIMAL(30,5)))  as notional_value
/*not needed for deal_counterparty or deal_counterparty_summary 
--, EBU.LONG_NAME as bu_long_name --not needed
, ab.external_lentity
, ele.long_name as le_long_name
, ab.internal_lentity
, 'None' as location_name
, 'NA' as product_grade
, ab.start_date as contract_start_date
, ab.maturity_date as contract_end_date
, pro.start_date as leg_start_date
, ab.deal_tracking_num
,0 as fin_param -- Adding these so the union works
,0 as phys_param -- Adding these so the union works
*/
from        gpna_ab_tran		ab
inner join  gpna_parameter     p    on  p.ins_num = ab.ins_num
inner join  gpna_profile       pro  on  p.param_seq_num = pro.param_seq_num and p.ins_num = pro.ins_num
inner join  gpna_party         ele  on  ab.external_lentity = ele.party_id
inner join  gpna_party         ebu  on ab.external_bunit = ebu.party_id
inner join 	gpna_instruments   i    on  ab.ins_type = i.id_number
inner join 	gpna_buy_sell      bs   on   ab.buy_sell = BS.ID_NUMBER
inner join 	gpna_party         ile  on ab.internal_lentity = ile.party_id
inner join 	gpna_currency      cur  on  p.currency = cur.id_number 
inner join 	gpna_idx_unit      iu   on  iu.unit_id = p.unit
inner join 	gpna_portfolio     po   on   ab.internal_portfolio = po.id_number
inner join  gpna_personnel 	per  on  ab.internal_contact = PER.ID_NUMBER
left join 	gpna_phys_header   ph   on   ab.ins_num = ph.ins_num

where ab.current_flag = 1
and ab.tran_status <> 5 --Not cancelled
and ab.tran_status <> 1 --Not Pending
and ab.tran_status <> 14 --Not Deleted
and ab.ins_type not in (48000, 48020, 48030, 1000023)
-- and ab.offset_tran_type = 0 --3P deals only
and ab.offset_tran_type in (0,1, 2)
and ab.maturity_date >=  cast('2018-01-01' as date)  --Performance join
and pro.end_date >=  cast('2018-01-01' as date) 
and ((p.param_seq_num > 1 and nvl(ph.pricing_level, -1) = 0 and p.settlement_type = 1)
OR (p.param_seq_num = 0 and nvl(ph.pricing_level, -1) in (-1, 1)))
and not exists (select 1 from gpna_gas_phys_param gpp where ab.ins_num = gpp.ins_num)
group by 
ab.external_bunit   
, ile.long_name     
, po.name           
, i.name            
, PER.NAME          
, 'Gas'             
, bs.name           
, cur.name          
, iu.unit_label     
,cast(ab.trade_date as date) 
,cast(pro.end_date as date)  
,cast(date_format(pro.end_date, 'yyyy-MM-01') as Date) 

""")




# COMMAND ----------

# DBTITLE 1,Costs
df_cost = spark.sql("""

select  
  ab.external_bunit as l2_id
, ile.long_name     as corporate_entity
, po.name           as trading_desk
, i.name            as deal_class
, PER.NAME          as trader_name
, 'Gas'             as product_traded
, bs.name           as buy_sell
, cur.name          as currency_uom
,cast(Null as String)     as uom
,cast(ab.trade_date as date)  as trade_date
,cast(pc.cflow_date  as date) as delivery_date
,cast(date_format(pc.cflow_date, 'yyyy-MM-01') as Date) as trade_month
,cast(null as int)   as notional_volume
,sum(cast(abs(pc.cflow) as DECIMAL(30,5))) as notional_value

/* not needed list for deal_counterparty or deal_counterparty_summary
, EBU.LONG_NAME as ext_bu_long_name
, ele.long_name as ext_le_long_name
, ab.internal_lentity
, ab.external_lentity

, ab.deal_tracking_num
, CT.NAME as cflow_type
, 'NA' as product_grade
, ab.start_date as contract_start_date
, ab.maturity_date as contract_end_date

*/

from		gpna_ab_tran 		ab
inner join	gpna_parameter 	p		on		p.ins_num = ab.ins_num
inner join  gpna_instruments 	i		on 		ab.ins_type = i.id_number
inner join 	gpna_buy_sell 		bs		on 		ab.buy_sell = BS.ID_NUMBER
inner join  gpna_physcash 		pc		on 		p.ins_num = pc.ins_num and p.param_seq_num = pc.param_seq_num
inner join 	gpna_cflow_type 	ct		on 		pc.cflow_type = CT.ID_NUMBER
--inner join 	gpna_party 		ele		on 		ab.external_lentity = ele.party_id
inner join 	gpna_party 		ebu		on 		ab.external_bunit = ebu.party_id
inner join  gpna_party 		ile		on 		ab.internal_lentity = ile.party_id
inner join 	gpna_currency 		cur		on  	pc.currency = cur.id_number 
inner join 	gpna_portfolio 	po		on 		ab.internal_portfolio = po.id_number
inner join 	gpna_personnel 	per		on 		ab.internal_contact = PER.ID_NUMBER

where ab.current_flag = 1
and ab.tran_status <> 5 --Not cancelled
and ab.tran_status <> 1 --Not Pending
and ab.tran_status <> 14 --Not Deleted
--and ab.ins_type in (48020, 48030, 1000023)
-- and ab.offset_tran_type = 0 --3P deals only
and ab.offset_tran_type in (0,1,2) -- Include external, internal, offsetting deals
and ab.maturity_date >= cast('2018-01-01' as date)
and ab.last_update >= cast('2018-01-01' as date)
and PC.CFLOW_DATE >= cast('2018-01-01' as date)
group by 
  ab.external_bunit 
, ile.long_name     
, po.name           
, i.name            
, PER.NAME          
       
, bs.name           
, cur.name          

,cast(ab.trade_date as date)  
,cast(pc.cflow_date  as date) 
,cast(date_format(pc.cflow_date, 'yyyy-MM-01') as Date) 

""")

# COMMAND ----------

# DBTITLE 1,Broker Fee
df_broker_fee = spark.sql("""
select 
  abt.broker_id  as l2_id
, ile.long_name  as corporate_entity
, po.name        as trading_desk
, i.name         as deal_class
, PER.NAME       as trader_name
,cast(Null as String) as product_traded
, 'Pay'    as buy_sell
, cur.name as currency_uom
,cast(Null as String) as uom
,cast(ab.trade_date  as date) as trade_date
,cast(ab.settle_date as date) as delivery_date
,cast(date_format(ab.settle_date, 'yyyy-MM-01') as Date) as trade_month
,cast(Null as int) as notional_volume
, sum(cast(abs(abt.reserved_amt) as DECIMAL(30,5))) as notional_value

/* not needed for deal_counterparty or deal_counterparty_summary
, BBU.LONG_NAME as broker_long_name
, ab.internal_lentity
, ab.start_date as contract_start_date
, ab.maturity_date as contract_end_date
, ab.deal_tracking_num
, PT.NAME as prov_type
*/
from 		gpna_ab_tran 					ab
inner join 	gpna_ab_tran_provisional 		abt		on 		ab.tran_num = abt.tran_num
inner join 	gpna_instruments 				i		on		ab.ins_type = i.id_number
inner join 	gpna_party 					bbu		on 		ab.external_bunit = bbu.party_id
inner join 	gpna_party 					ile		on 		ab.internal_lentity = ile.party_id
inner join 	gpna_prov_type 				pt		on 		abt.prov_type = PT.ID_NUMBER
inner join 	gpna_currency 					cur		on		ab.currency = cur.id_number
inner join 	gpna_portfolio 				po		on		ab.internal_portfolio = po.id_number
inner join 	gpna_personnel 				per		on		ab.internal_contact = PER.ID_NUMBER
where ab.current_flag = 1
and ab.tran_status <> 5 --Not cancelled
and ab.tran_status <> 1 --Not Pending
and ab.tran_status <> 14 --Not Deleted
-- and ab.offset_tran_type = 0 --3P deals only
and ab.offset_tran_type in (0,1,2) -- Include external, internal, offsetting deals
and ab.maturity_date >= cast('2018-01-01' as date) 
and ab.last_update >= cast('2018-01-01' as date) 
group by abt.broker_id  
, ile.long_name  
, po.name        
, i.name         
, PER.NAME       
, cur.name 
,cast(ab.trade_date  as date) 
,cast(ab.settle_date as date) 
,cast(date_format(ab.settle_date, 'yyyy-MM-01') as Date) 
""")

# COMMAND ----------

# DBTITLE 1,Union all + date key columns
deal_counterparty_df = df_volumes.unionAll(df_cost).unionAll(df_broker_fee)
deal_counterparty_df  =  deal_counterparty_df.groupBy("l2_id", "corporate_entity", "trading_desk", \
                                                      "deal_class", "trader_name","product_traded",\
                                                      "buy_sell","currency_uom","UOM", "trade_date",\
                                                      "delivery_date","trade_month").agg(sum("notional_volume").alias("notional_volume"),\
                                                                           sum("notional_value").alias("notional_value") )
deal_counterparty_df= deal_counterparty_df.withColumn("source_system_code",lit('ENDUR_GP_NA'))
deal_counterparty_df = deal_counterparty_df.withColumn("meta_created_dttm",current_timestamp()) #adding source_system_code
deal_counterparty_df = deal_counterparty_df.withColumn("report_date_key", date_format(current_timestamp(),'yyyyMMdd').cast(IntegerType()))  # report date key
#creating a date_key column of integer type
date_columns = ['trade_month']
for col_name in date_columns:
    deal_counterparty_df= deal_counterparty_df.withColumn(f"{col_name}_key",date_format(to_date(col(f"{col_name}"),"M/d/yyyy"),"yyyyMMdd").cast(IntegerType()))

# COMMAND ----------

# DBTITLE 1,Staging deal_counterparty in ADLS 
adls_file_path_full_src_deal_cp=adls_file_path_full_src+'deal_counterparty/'
print(adls_file_path_full_src_deal_cp)
deal_counterparty_df.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_stg).save(adls_file_path_full_src_deal_cp)
#deal_counterparty_df.count()

# COMMAND ----------

# DBTITLE 1,Read deal_counterparty  from Staged Folder
deal_counterparty_df  = spark.read.format('delta').load(adls_file_path_full_src_deal_cp)
max_created_dttm = deal_counterparty_df.select(max("meta_created_dttm")).collect()[0][0]
print(max_created_dttm)
deal_counterparty_df= deal_counterparty_df.filter(deal_counterparty_df['meta_created_dttm']==max_created_dttm)
deal_counterparty_df.createOrReplaceTempView("vw_deal_counterparty")
#deal_counterparty_df.count()

# COMMAND ----------

# DBTITLE 1,Getting max dates for deal_counterparty_summary
deal_counterpary_summary_df  =  deal_counterparty_df.groupBy("l2_id").agg(max("trade_date").alias("deal_latest_trade_date"),\
                                                                           max("delivery_date").alias("deal_latest_delivery_date") )
deal_counterpary_summary_df.createOrReplaceTempView("vw_deal_counterparty_summary")

# COMMAND ----------

# DBTITLE 1,deal_counterparty_summary
deal_counterparty_summary = spark.sql(""" select 
                                          source_system_code
                                         ,cds.l2_id as cp_deal_mapping_id
                                         ,cds.deal_latest_trade_date
                                         ,cds.deal_latest_delivery_date
                                         ,concat_ws(",", array_sort((collect_set(cd.trader_name)))) as deal_latest_trader_name
                                         ,current_timestamp as meta_created_dttm
                                         ,current_timestamp as meta_start_dttm
                                         ,cast('2999-12-31' as timestamp) as meta_end_dttm 
                                         ,'Y'  as active_indicator
                                         , date_format(current_date, 'yyyyMMdd') as report_date_key
                                    from        vw_deal_counterparty         cd
                                    inner join  vw_deal_counterparty_summary cds on cd.l2_id = cds.l2_id and (cds.deal_latest_trade_date = cd.trade_date)
                                    group by source_system_code
                                           , cds.l2_id
                                           , cds.deal_latest_trade_date
                                           , cds.deal_latest_delivery_date
                                     """)#.dropna()
#deal_counterparty_summary.count()
deal_counterparty_summary.createOrReplaceTempView("vw_deal_counterparty_summary")
deal_counterparty_summary.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty_summary/")

# COMMAND ----------

deal_counterparty_df_new =  deal_counterparty_df.groupBy("source_system_code", "l2_id", "trading_desk", "corporate_entity", \
                                                          "buy_sell", "deal_class","product_traded", "trade_month_key",
                                                          "trader_name","currency_uom","UOM", "meta_created_dttm"
                                                         ).agg(sum("notional_volume").alias("notional_volume"),\
                                                               sum("notional_value").alias("notional_value") )

# COMMAND ----------

# DBTITLE 1,deal_counterparty
deal_counterparty_final = deal_counterparty_df_new.select(col('source_system_code').alias('source_system_code')
                                                ,col('l2_id').alias('cp_deal_mapping_id') 
                                                ,col('trading_desk').alias('deal_trading_desk') 
                                                ,col('corporate_entity').alias('deal_trading_entity')
                                                ,col('corporate_entity').alias('deal_trading_entity_long_name')
                                                ,col('buy_sell').alias('deal_buy_sell')
                                                ,col('deal_class').alias('deal_class')
                                                ,col('product_traded').alias('deal_product_type') 
                                                ,col('trade_month_key').alias('deal_date_month_key') 
                                                ,col('trader_name').alias('deal_trader_name') 
                                                ,col('currency_uom').alias('deal_value_unit_of_measure') 
                                                ,col('uom').alias('deal_volume_unit_of_measure') 
                                                ,col('notional_value').cast('DECIMAL(30,5)').alias('deal_notional_value')
                                                ,col('notional_volume').cast('DECIMAL(30,5)').alias('deal_notional_volume')
                                                ,col("meta_created_dttm").alias('meta_created_dttm')
                                                ,col("current_timestamp").alias('meta_start_dttm')
                                                ,to_date(lit('2999-12-31')).alias('meta_end_dttm')
                                                ,lit('Y').alias('active_indicator')
                                                ,date_format(col("current_date"),'yyyyMMdd').alias('report_date_key')
                                               )
#deal_counterparty_final.count()
deal_counterparty_final.createOrReplaceTempView("vw_deal_counterparty")
deal_counterparty_final.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty/")

# COMMAND ----------

# DBTITLE 1, Write deal_counterparty to staging table
cnt_before_writing = deal_counterparty_final.count()
deal_counterparty= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty/")
cnt_after_writing = deal_counterparty.count()

try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty', 'ENDUR_GP_NA')
except Exception as r:
  print("For ENDUR_GP_NA source system deal_counteparty counts didn't match")
  raise dbutils.notebook.exit(e)
        

# COMMAND ----------

# DBTITLE 1,Switch the partitions from staging table target table
LoadCuratedTargetTbl('staging', 'deal_counterparty', 'cp_data_hub', 'deal_counterparty', 'ENDUR_GP_NA')

# COMMAND ----------

# DBTITLE 1,Write deal_counterparty_summary to staging table
cnt_before_writing = deal_counterparty_summary.count()
deal_counterparty_summary= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty_summary/")
cnt_after_writing = deal_counterparty_summary.count()
try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty_summary', 'ENDUR_GP_NA')
except Exception as r:
  print("For ENDUR_GP_NA source system deal_counteparty_summary counts didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Switch Partition from staging table target table
LoadCuratedTargetTbl('staging', 'deal_counterparty_summary', 'cp_data_hub', 'deal_counterparty_summary', 'ENDUR_GP_NA')

# COMMAND ----------

# DBTITLE 1,Function to update refresh date
RefreshDateP3('last_update','NULL','gpna_AB_TRAN','ENDUR_GP_NA') 

# COMMAND ----------

Source_System_Code = 'ENDUR_GP_NA'
System ='P3'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
