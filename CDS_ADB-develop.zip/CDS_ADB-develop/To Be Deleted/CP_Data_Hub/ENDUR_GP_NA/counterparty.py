# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 1,Create temp views from ADLS
# source_system , view_prefix_name  parameters to pass to the function
create_temp_views_per_source_system('ENDUR_GP_NA', 'gpna')

# COMMAND ----------

# DBTITLE 1,Read erate_salesforce data from curated tb
tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['erate_salesforce']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

# DBTITLE 1,Fetching create date 
# MAGIC %sql
# MAGIC create or replace temporary view party_history as
# MAGIC select to_timestamp(min(last_update),'yyyy-MM-dd HH:mm:ss.SSSSSSS')as lst_updt,party_id from gpna_PARTY_HISTORY
# MAGIC group by party_id --create date

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view erate_info as 
# MAGIC select distinct PARTY_ID, 'N' as flag from gpna_PARTY_FUNCTION where Function_TYPE = 1  -- PBI 958878

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_gpna as 
# MAGIC 
# MAGIC SELECT CASE WHEN ple.PARTY_ID IS NULL THEN  CONCAT('ENDNA_GP', '__', pbu.PARTY_ID) 
# MAGIC             ELSE CONCAT('ENDNA_GP', '_', ple.PARTY_ID, '_',pbu.PARTY_ID) END AS cp_unique_id,
# MAGIC         ple.PARTY_ID    AS cp_legal_entity_id,
# MAGIC         ple.short_name  as cp_legal_entity_short_name,
# MAGIC         case when ple.long_NAME is not null and length(trim(ple.long_name)) >0 then ple.long_NAME
# MAGIC             else ple.short_name 
# MAGIC         end AS cp_legal_entity_name,
# MAGIC        pbu.PARTY_ID    AS cp_business_unit_id,
# MAGIC        pbu.short_name  as cp_business_unit_short_name,
# MAGIC        case when pbu.long_name is not null and length(trim(pbu.long_name)) > 0  then pbu.long_NAME
# MAGIC             else pbu.short_name 
# MAGIC         end AS cp_business_unit_name,
# MAGIC        IFNULL(CONCAT(CASE WHEN pbu.INT_EXT = 0 THEN 'INT'
# MAGIC                           WHEN pbu.INT_EXT = 1 THEN 'EXT' 
# MAGIC                           ELSE 'UNKNOWN' 
# MAGIC                        END , 
# MAGIC                        '_' ,
# MAGIC                      CASE WHEN pbu.PARTY_CLASS = 0 THEN 'LE'
# MAGIC                           WHEN pbu.PARTY_CLASS = 1 THEN 'BU' 
# MAGIC                           ELSE 'UNKNOWN' 
# MAGIC                           END,
# MAGIC                     -- check the last 3 characters of last underscore and if it satisfies 'CD' or 'PT' or BKR then concat with those characters in the end
# MAGIC                     CASE WHEN slice(split(trim(pbu.SHORT_NAME), "_"),-1,1)[0] in ('CD', 'PT', 'BKR') then concat('_',slice(split(trim(pbu.SHORT_NAME), "_"),-1,1)[0])
# MAGIC                          else ''
# MAGIC                          end 
# MAGIC                           ), 'UNKNOWN') AS cp_entity_type,              
# MAGIC        CASE WHEN (pbu.PARTY_STATUS <> 1 OR ple.PARTY_STATUS <> 1) THEN 'Y' 
# MAGIC             ELSE 'N' END AS cp_deactivation_flag, -- check the logic   ,, its different between the catalog and alteryx logic
# MAGIC         ph.lst_updt                        as cp_create_date,----create date    
# MAGIC        --CAST (NULL AS TIMESTAMP)             AS cp_create_date,
# MAGIC        CAST (pbu.LAST_UPDATE AS TIMESTAMP)  AS cp_last_update_date,
# MAGIC        LTRIM(pri.VALUE)                     AS sap_account_no,
# MAGIC        'ENDNA_GP'                           AS system,
# MAGIC        pbu.party_status                     AS cp_system_status,
# MAGIC        pri.TYPE                             AS sap_account_type,
# MAGIC        PRI.SAP_UNIQUE_ID                    as sap_unique_id,
# MAGIC        ''                                   AS broker_indicator,
# MAGIC        ''                                   AS parent,
# MAGIC        cle.NAME                             AS cp_registered_country,
# MAGIC        'STNSAP'                             AS linked_sap_system,
# MAGIC        coalesce(ef.flag,'Y')                AS erate_flag, --PBI 958878
# MAGIC        to_date(NULL)                        AS erate_completion_date,
# MAGIC        to_Date(NULL)                        AS erate_lift_date,
# MAGIC        
# MAGIC        --ple.SHORT_NAME                       AS cp_legal_entity_short_name,
# MAGIC        'ENDUR_GP_NA'                        AS source_system,
# MAGIC        case when ple.SHORT_NAME is null then  to_Date(pbu.META_CREATED_DTTM) 
# MAGIC             else to_Date(ple.META_CREATED_DTTM)
# MAGIC          END meta_created_dttm
# MAGIC        
# MAGIC        FROM gpna_PARTY pbu
# MAGIC             INNER JOIN gpna_BUSINESS_UNIT bu ON pbu.PARTY_ID = bu.PARTY_ID
# MAGIC             left outer join PARTY_HISTORY ph on pbu.party_id = ph.party_id --create date
# MAGIC             LEFT OUTER JOIN gpna_PARTY_RELATIONSHIP pr ON pbu.PARTY_ID = pr.BUSINESS_UNIT_ID
# MAGIC             LEFT OUTER JOIN gpna_LEGAL_ENTITY le ON pr.LEGAL_ENTITY_ID = le.PARTY_ID
# MAGIC             LEFT OUTER JOIN gpna_PARTY ple ON pr.LEGAL_ENTITY_ID = ple.PARTY_ID
# MAGIC             LEFT OUTER JOIN gpna_PARTY_FUNCTION pf ON ple.PARTY_ID = pf.PARTY_ID
# MAGIC             LEFT OUTER JOIN erate_info ef ON ef.PARTY_ID = pbu.PARTY_ID                -- PBI 958878
# MAGIC             LEFT OUTER JOIN gpna_COUNTRY cle ON le.COUNTRY = cle.ID_NUMBER
# MAGIC             LEFT OUTER JOIN gpna_COUNTRY cbu ON bu.COUNTRY = cbu.ID_NUMBER
# MAGIC             LEFT OUTER JOIN gpna_STATES sle ON le.STATE_ID = sle.STATE_ID
# MAGIC             LEFT OUTER JOIN gpna_STATES sbu ON bu.STATE_ID = sbu.STATE_ID
# MAGIC             LEFT OUTER JOIN (SELECT 'CUSTOMER' AS Type, REPLACE(LTRIM(REPLACE(value, '0', ' ')),' ','0') as value, PARTY_ID, 
# MAGIC                                      CASE WHEN trim(VALUE) IS NOT NULL and length(trim(VALUE)) >0  THEN  CONCAT('STNSAP_Customer_',REPLACE(LTRIM(REPLACE(trim(value), '0', ' ')),' ','0')) ELSE NULL END  SAP_UNIQUE_ID
# MAGIC                                     FROM gpna_PARTY_INFO
# MAGIC                              WHERE TYPE_ID in (40019,40020)
# MAGIC                              UNION ALL
# MAGIC                              SELECT 'VENDOR' AS Type, REPLACE(LTRIM(REPLACE(value, '0', ' ')),' ','0') as value, PARTY_ID,
# MAGIC                                      CASE WHEN trim(VALUE) IS NOT NULL   and length(trim(VALUE)) >0  THEN  CONCAT('STNSAP_Vendor_',REPLACE(LTRIM(REPLACE(trim(value), '0', ' ')),' ','0'))  ELSE NULL END AS SAP_UNIQUE_ID
# MAGIC                                     FROM gpna_PARTY_INFO
# MAGIC                              WHERE TYPE_ID in (40019,40020)) pri ON pri.PARTY_ID = ple.PARTY_ID

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty as 
# MAGIC select distinct 
# MAGIC     gpna.cp_unique_id               as cp_unique_id                -- req-26
# MAGIC   , gpna.cp_legal_entity_id         as cp_legal_entity_id          -- l1_id (req-28)
# MAGIC   , case when gpna.cp_business_unit_name is not null and length(trim(gpna.cp_business_unit_name)) >0 then cp_business_unit_name 
# MAGIC           else gpna.cp_legal_entity_name 
# MAGIC      end  cp_name
# MAGIC   , gpna.cp_business_unit_id             as cp_business_unit_id          -- same as l2_id for gpna
# MAGIC   , gpna.cp_business_unit_name           as cp_business_unit_name
# MAGIC   , gpna.cp_business_unit_short_name     as cp_short_name
# MAGIC   , gpna.cp_create_date                  as cp_created_date
# MAGIC   , gpna.cp_last_update_date             as cp_updated_date
# MAGIC   , gpna.cp_deactivation_flag            as cp_deactivated
# MAGIC   , gpna.erate_flag                      as cp_erate_flag_source
# MAGIC   , gpna.erate_completion_date           as cp_erate_date_source
# MAGIC   , case when gpna.erate_flag = 'Y' then 'Y' Else 'N' END as cp_erate_flag
# MAGIC  ,  case when gpna.erate_flag = 'Y' then to_date(er.erate_completion_date, 'yyyy-MM-dd') else null end as cp_erate_date
# MAGIC   , gpna.cp_business_unit_id             as cp_account_number
# MAGIC   , gpna.cp_business_unit_id             as cp_deal_mapping_id
# MAGIC   , current_timestamp as meta_created_ddtm
# MAGIC   , current_timestamp as meta_start_ddtm
# MAGIC   ,  to_date('2999-12-31', 'yyyy-MM-dd') as meta_end_ddtm
# MAGIC   , 'Y' as active_indicator
# MAGIC   , 'ENDUR_GP_NA' as source_system_code
# MAGIC   ,date_format(current_date, 'yyyyMMdd') as  report_date_key
# MAGIC from vw_cp_master_gpna                      gpna
# MAGIC left join vw_cp_data_hub_erate_salesforce   er   on (gpna.cp_unique_id = er.cp_unique_id and er.source_system ='ENDNA_GP')

# COMMAND ----------

# @dispatch(str,str,str)
# def RefreshCuratedSqlTbl(tgt_schema_name, tgt_table_name, source_system_code):
#         """
#         Loads the data into sql server for curated layer
#         tgt_schema_name = 'cp_data'
#         tgt_tablename   = 'gtmi_singlecplist'
#         source_system   = 'GOLD_TIER_MI'
#         """
#         try:
#             df = spark.sql(f"select * from  vw_{tgt_table_name}").cache()
#             print(tgt_schema_name , tgt_table_name, source_system_code)
#             if df.count() > 0:
#                 print(df.count())
#                 conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
#                                     'SERVER='+dbServer_curated+';'
#                                     'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
#                                     'PWD='+dbPass
#                                     )
#                 cursor = conn.cursor()
#                 execSQL = f"delete from {tgt_schema_name}.{tgt_table_name} where source_system_code = upper('{source_system_code}')"
#                 conn.autocommit = True
#                 cursor.execute(execSQL)
#                 print("Data been Deleted")
#                 df.write.jdbc(Stratos_sqldb_URL_curated, f"{tgt_schema_name}.{tgt_table_name}", "append")
#                 print(f"load of {tgt_table_name}  of {source_system_code} is completed")
#             else:
#                 print("Returned Zero Records")

#         except Exception as e:
#             print('Exception raised')
#             raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Counterparty
cp_df = spark.sql("select * from vw_counterparty")
cp_df = cp_df.drop_duplicates()
total_row_cnt = cp_df.count()
print (total_row_cnt)
cp_unique_id_df = cp_df.select(["cp_unique_id"])
cp_unique_id_df = cp_unique_id_df.drop_duplicates()
cp_unique_id_cnt= cp_unique_id_df.count()
print(cp_unique_id_cnt)
try:
  if total_row_cnt == cp_unique_id_cnt:
    RefreshCuratedSqlTbl('staging', 'counterparty', 'ENDUR_GP_NA')
except Exception as e:
  print("For GPNA source system counterparty count vs unique_id cnt didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'counterparty', 'cp_data_hub', 'counterparty', 'ENDUR_GP_NA')

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['counterparty']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

# DBTITLE 1,Counterparty Details
cp_details_df = spark.sql("""
                          select distinct
                             gpna.cp_unique_id               as cp_unique_id
                            ,cast(NULL as string)          as cp_company_code
                            ,cast(NULL as string)          as cp_company_name
                            ,cast(NULL as string)          as cp_country_code
                            ,gpna.cp_registered_country      as cp_country_name
                            ,cast(NULL as string)          as counterparty_type
                            ,current_timestamp               as meta_created_ddtm
                            ,current_timestamp               as meta_start_ddtm
                            ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                            ,'Y'                                   as active_indicator
                            ,'ENDUR_GP_NA'                         as source_system_code
                            ,date_format(current_date, 'yyyyMMdd') as  report_date_key
                           from vw_cp_master_gpna  gpna
                           where gpna.cp_registered_country is not null
                           and length(gpna.cp_registered_country)>0
                          """)
#creating temp view
cp_details_df.createOrReplaceTempView("vw_counterparty_details")

# need to get the distinct unique_id counts
cp_details_cp_unique_id_cnt = cp_details_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_counterparty_details cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)                               
#load process
try:
  if cp_unique_id_cnt >= cp_details_cp_unique_id_cnt and cp_unique_id_not_in_cp_df.count()==0:
    print(f"""Count Match: {cp_unique_id_cnt} and {cp_details_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of counterparty_details is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'counterparty_details', 'ENDUR_GP_NA')
except Exception as e:
  print("For GPNA source system counterparty count and counterparty Details unique_id didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'counterparty_details', 'cp_data_hub', 'counterparty_details', 'ENDUR_GP_NA')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details_summary as
# MAGIC   
# MAGIC   select 
# MAGIC 			 cpd.source_system_code
# MAGIC 			      ,cpd.cp_unique_id
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(counterparty_type))) as counterparty_type
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_code))) as cp_company_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_name))) as cp_company_name
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_code))) as cp_country_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_name))) as cp_country_name
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 				  from vw_counterparty_details cpd
# MAGIC 				  where cpd.source_system_code in ('ENDUR_GP_NA')
# MAGIC 			group by cpd.source_system_code, cpd.cp_unique_id
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details_summary', 'ENDUR_GP_NA')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details_summary', 'cp_data_hub', 'counterparty_details_summary', 'ENDUR_GP_NA')

# COMMAND ----------

# DBTITLE 1,bridge_counterparty_sap_account
bdg_cp_sap_account_df = spark.sql("""
                                 select distinct 
                                    gpna.cp_unique_id               as cp_unique_id
                                   ,gpna.sap_unique_id              as sap_unique_id
                                   ,gpna.sap_account_no             as sap_account_number
                                   ,gpna.sap_account_type           as sap_account_type
                                   ,gpna.linked_sap_system          as sap_source_system_code
                                   ,current_timestamp               as meta_created_ddtm
                                   ,current_timestamp               as meta_start_ddtm
                                   ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                                   ,'Y'                                   as active_indicator
                                   ,'ENDUR_GP_NA'                          as source_system_code
                                   ,date_format(current_date, 'yyyyMMdd') as  report_date_key 
                                from vw_cp_master_gpna gpna
                                where gpna.sap_unique_id is not null and length(gpna.sap_unique_id) > 0
                                """)
#creating temp view
bdg_cp_sap_account_df.createOrReplaceTempView("vw_bridge_counterparty_sap_account")

# need to get the distinct unique_id counts
bdg_cp_sap_account_cp_unique_id_cnt = bdg_cp_sap_account_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
bdg_cp_sap_account_cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_bridge_counterparty_sap_account cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)
                                       
#load process
if cp_unique_id_cnt >= bdg_cp_sap_account_cp_unique_id_cnt and bdg_cp_sap_account_cp_unique_id_not_in_cp_df.count()==0:
  try:
  
    print(f"""Count Match: {cp_unique_id_cnt} and {bdg_cp_sap_account_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of bridge_counterparty_sap_account is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'bridge_counterparty_sap_account', 'ENDUR_GP_NA')
  
  except Exception as e:
    print("For GPNA source system counterparty count and bridge_counterparty_sap_accnt cp_unique_id didn't match")
    raise dbutils.notebook.exit(e)
elif {cp_unique_id_cnt} < {bdg_cp_sap_account_cp_unique_id_cnt}: 
  print(f"""counterparty: {cp_unique_id_cnt}""")
  print(f"""bridge_counterparty_sap_account: {bdg_cp_sap_account_cp_unique_id_cnt}""")
  print("Count match is not working ")
else:
  print(f"""cp_unique_id exists in bridge counterparty sap account table but in counterparty table""")

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'bridge_counterparty_sap_account', 'cp_data_hub', 'bridge_counterparty_sap_account', 'ENDUR_GP_NA')

# COMMAND ----------

Source_System_Code = 'ENDUR_GP_NA'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
