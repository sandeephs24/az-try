# Databricks notebook source
from pyspark.sql.functions import *
import pyodbc
import pandas as pd

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/config/config"

# COMMAND ----------

if 'System' not in locals():
  print('Initiating System variable to blank')
  System = ''
else :
  print ('System : ',System) 
  
sqlString = '''
select a.*,b.system_code
from [cp_data].[cp_data_refresh_audit_log_logic_refactor] a 
join [cp_data].[cp_data_refresh_audit_log_master_refactor] b 
on a.system_refresh_id = b.system_refresh_id
and a.is_active = 1
and a.system='{}'
'''.format(System)
if 'Source_System_Code' not in locals():
  print('Initiating Source_System_Code variable to blank')
  Source_System_Code = ''
else :
  print ('Source_System_Code : ',Source_System_Code)

if Source_System_Code != '':
  sql2 = " where system_code = '{}'".format(Source_System_Code)
else:
  sql2 = ""
  
finalsql = sqlString + ' ' + sql2




# COMMAND ----------

df_logic = spark.read.format("jdbc").option("url",Stratos_sqldb_URL_curated).option("query",finalsql).load()
display(df_logic) #display df 


# COMMAND ----------

print(df_logic.count())

# COMMAND ----------

if df_logic.count()==0:
  dbutils.notebook.exit('no records returned')

# COMMAND ----------

def getValue_sql(x):
  if not x:
    return pd.Timestamp(None)
  else:
    df = spark.read.format("jdbc").option("url",Stratos_sqldb_URL_curated).option("query",x).load()
    return df.agg({"mDate": "max"}).collect()[0][0]

# COMMAND ----------

def getValue_adls(x):
  if (x == 'adls'):
    return pd.Timestamp(None)
  else:
    k= x.split(',')
    print(k[0],k[1])
    df = spark.read.format(k[1]).load(k[0]).filter(col("IS_RECORD_ACTIVE") == 1)
    return df.agg({"meta_created_dttm": "max"}).collect()[0][0]
  

# COMMAND ----------

df_logic_pd = df_logic.toPandas()
df_logic_pd['SQL_Output'] = df_logic_pd.apply(lambda row : getValue_adls(row['value']) if row['value'] == 'adls' else getValue_sql(row['value']), axis=1)
output_df = spark.createDataFrame(df_logic_pd)
df =output_df.select(col('system_refresh_id'),col('id').alias('column_id'),col('SQL_Output').alias('value'),lit(current_timestamp().alias('meta_created_dttm')))

# COMMAND ----------

display(df)

# COMMAND ----------

try:
  conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                                    'SERVER='+dbServer_curated+';'
                                    'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
                                    'PWD='+dbPass
                                    )
  cursor = conn.cursor()
  #execSQL = f"truncate table cp_data.cp_data_refresh_audit_log_stg"
  conn.autocommit = True
  #cursor.execute(execSQL)
  
  df.write.jdbc(Stratos_sqldb_URL_curated, f"cp_data.cp_data_refresh_audit_log_stg_refactor", "overwrite")
  execSQL = "exec cp_data.update_audit_refresh_log_refactor @system = '{}' ".format(System)
  cursor.execute(execSQL)
     
except Exception as e:
  print('Exception raised')
  raise dbutils.notebook.exit(e)
            
