# Databricks notebook source
# DBTITLE 1,Common Variables
dbJdbcPort = "1433"
dbUser = "CPData_Dev_ADB"
dbPass = dbutils.secrets.get(scope = "CPDataDatabricksScopeDev", key = "cpdata-sqldb-adb")

# COMMAND ----------

# DBTITLE 1,Curated SQL DB
# Curated SQLDB Connection - Uses same login account as above 
dbDatabase_curated = "shell-01-eun-sqdb-moyuhlwsgetxylxlydxo"
dbServer_curated = "shell-01-eun-sq-hsnipummfftxdrbrdmsm.database.windows.net"
Stratos_sqldb_URL_curated = "jdbc:sqlserver://" + dbServer_curated + ":" + dbJdbcPort + ";database=" + dbDatabase_curated + ";user=" + dbUser+";password=" + dbPass

# COMMAND ----------

# DBTITLE 1,Harmonized SQL DB
#SQLDB Connection
dbDatabase = "shell-01-eun-sqdb-zjktctrunctxtrbovevz"
dbServer = "shell-01-eun-sq-vwvxqmqfsltvwsftjbzt.database.windows.net"
dbUser = "CPData_Dev_ADB"
dbPass = dbutils.secrets.get(scope = "CPDataDatabricksScopeDev", key = "cpdata-sqldb-adb")
dbJdbcPort = "1433"
dbJdbcExtraOptions = "encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
Stratos_sqldb_URL = "jdbc:sqlserver://" + dbServer + ":" + dbJdbcPort + ";database=" + dbDatabase + ";user=" + dbUser+";password=" + dbPass

# COMMAND ----------

# DBTITLE 1,Self-Service SQL DB
#SQLDB Connection - bexcel
SSdbDatabase = "shell-01-eun-sqdb-knaredzgurlgokeoysaq"
SSdbServer = "shell-01-eun-sq-dyogurnmurnlyhuuodlt.database.windows.net"
SSdbUser = "sqldb_bexcel_de_d_s"
SSdbPass = dbutils.secrets.get(scope = "CPDataDatabricksScopeDev", key = "bexcel-de-d-s")
SSdbJdbcPort = "1433"
SSdbJdbcExtraOptions = "encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
SS_sqldb_URL = "jdbc:sqlserver://" + SSdbServer + ":" + SSdbJdbcPort + ";database=" + SSdbDatabase + ";user=" + SSdbUser+";password=" + SSdbPass
