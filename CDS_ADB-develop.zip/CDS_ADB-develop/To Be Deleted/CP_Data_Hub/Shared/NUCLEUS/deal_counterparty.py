# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

def create_temp_views_per_source_system(source_system,vw_prefix_name):
    """
     create tempviews for adls paths
    """
    src_tables_List= [] # empty to store the table name and filepath
    temp_views_List= [] # temporary views to print the in notebook when called.
    df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'cp_data.config_adls_paths') # read config table to retrieve the adls file paths
    df = df.filter(f"source_system == '{source_system}'")
    IsSAPHANA = True if source_system == 'SAPHANA' else False   #specific to SAPHANA
#     df = df.filter("active_flag == 1")
    df.createOrReplaceTempView(f"vw_cp_data_config_adls_paths")
    df_new = df.toPandas()

                   
    dataframedict = {}
    for row in df_new.itertuples():
        src_tables_List.append((row.src_table_name,  row.old_adls_full_path, row.new_adls_full_path))
        if row.adls_file_format =='parquet' and row.old_new_adls_path_indicator =='OLD':
          dataframedict[row.src_table_name] = spark.read.format("parquet").load(row.old_adls_full_path)#.filter(col("IS_RECORD_ACTIVE") == 1)
        elif row.adls_file_format =='delta' and row.old_new_adls_path_indicator =='OLD':
          dataframedict[row.src_table_name] = spark.read.format("delta").load(row.old_adls_full_path)#.filter(col("IS_RECORD_ACTIVE") == 1)
        elif row.adls_file_format =='parquet' and row.old_new_adls_path_indicator =='NEW':
          dataframedict[row.src_table_name] = spark.read.format("parquet").load(row.new_adls_full_path)#.filter(col("IS_RECORD_ACTIVE") == 1)
        elif row.adls_file_format =='delta' and row.old_new_adls_path_indicator =='NEW':
          dataframedict[row.src_table_name] = spark.read.format("delta").load(row.new_adls_full_path)#.filter(col("IS_RECORD_ACTIVE") == 1)
          
    #create the temporary views
    for key,value in dataframedict.items():
        temp_views_List.append(f"{vw_prefix_name}_{key}")
        dataframedict[key] = value.createOrReplaceTempView(f"{vw_prefix_name}_{key}")
#     print("Temp View Names")
#     print(temp_views_List)
    temp_views_List_new = []
    tables_with_active_record_list = ['nucleus_BROKER_COMMISSION_MONTHS', 'nucleus_CUSTODY_TRANSFER_POINTS', 'nucleus_DEAL_MONTH_DETAILS',\
                             'nucleus_DEAL_CONFIRMS', 'nucleus_MISC_CHARGE_MONTHS','nucleus_MISC_CHARGE_VOLUMES', 'nucleus_MISC_CHARGES' ,'nucleus_PORTFOLIOS', 'nucleus_POWER_FEE_MONTHS',\
							 'nucleus_SPREAD_OPTIONS', 'nucleus_USERS']
    for vw in temp_views_List:
        vw = vw.replace('vw_','')
       
        if vw not in tables_with_active_record_list:
            
            df = spark.sql(f"""select * from {vw} where IS_RECORD_ACTIVE =1 """)
            df.createOrReplaceTempView(f"{vw}")
            temp_views_List_new.append(vw)
        else:
           
            df = spark.sql(f"""select * from {vw} where ACTIVE_INDICATOR = 'Y'""")
            df.createOrReplaceTempView(f"{vw}")
            temp_views_List_new.append(vw)
            
    print("Use below names: ")
    print(temp_views_List_new)
create_temp_views_per_source_system('NUCLEUS','nucleus')

# COMMAND ----------

dbutils.widgets.text("pm_adls_proj_folder", "P00014-Cross_Comm-CPData-DEV")
v_adls_folder = dbutils.widgets.get("pm_adls_proj_folder")

# COMMAND ----------

# DBTITLE 1,ADLS Staging and Target Paths of CP Data Hub Project
adls_file_path_full_src = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/staging/nucleus/source_file/"
adls_file_path_tgt      = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/cp_data_hub/nucleus/"
partition_by_cols_stg= ['source_system_code','report_date_key']
partition_by_cols_tgt = ["source_system_code"]

# COMMAND ----------

# DBTITLE 1,Physical
physical_df=spark.sql("""
SELECT 
      DMD.DEAL_KEY,
      TRUE_DEAL_TYPE     DEAL_TYPE, 
      LE.CY_ENTITY_KEY   TRADING_ENTITY_KEY,
      LE.DESCRIPTION     TRADING_ENTITY_LONG_NAME,
      P.DESCRIPTION      TRADING_DESK,
      DC.PHY_FIN_FLAG    INSTRUMENT_TYPE,       
      'Power'            PRODUCT_TRADED,
      MIN(DMD.DY_BEG_DAY)  DEAL_START_DATE,
      MAX(DMD.DY_END_DAY)  DEAL_END_DATE,
      C.COMPANY_KEY       COUNTERPARTY_ID,             -- LegalEntityID or CpDealMappingId   
      DMD.DN_DIRECTION         BUY_SELL_INDICATOR,
      U.USER_NAME              TRADER_NAME,
      DMD.TRADE_DATE           TRADE_DATE,
      DMD.CM_CONTRACT_MONTH    DELIVERY_DATE,
      DMD.UT_UNIT              VOLUME_TRADED_UOM,
      DMD.CU_CURRENCY          PRICE_CURRENCY,
      SUM(DMD.CONTRACT_VOLUME) VOLUME_TRADED
FROM (SELECT  DMD.DEAL_KEY,
              CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END TRUE_DEAL_TYPE,
              MAX(LGL_CY_ENTITY_KEY) LGL_CY_ENTITY_KEY,
              MAX(DMD.PRT_PORTFOLIO) PRT_PORTFOLIO,
              MIN(DMD.DY_BEG_DAY) DY_BEG_DAY,
              MAX(DMD.DY_END_DAY) DY_END_DAY,
              MAX(DMD.CY_COMPANY_KEY) CY_COMPANY_KEY,
              MAX(CASE WHEN DMD.DLT_DEAL_TYPE = 'TRANS' THEN CASE WHEN DMD.DN_DIRECTION = 'PURCHASE' THEN 'SALE' ELSE 'PURCHASE' END ELSE DMD.DN_DIRECTION END) DN_DIRECTION,
              MAX(DMD.UR_TRADER) UR_TRADER,
              MAX(DMD.CU_CURRENCY) CU_CURRENCY,
              SUM(CASE WHEN DMD.DLT_DEAL_TYPE = 'TRANS' THEN -DMD.CONTRACT_VOLUME ELSE DMD.CONTRACT_VOLUME END) CONTRACT_VOLUME,
              MAX(DMD.UT_UNIT) UT_UNIT,
              MAX(DMD.TRADE_DATE) TRADE_DATE,
              MAX(DMD.CTP_POINT_CODE) CTP_POINT_CODE,
              DMD.VOLUME_SEQ,
              DMD.CM_CONTRACT_MONTH
        FROM nucleus_DEAL_MONTH_DETAILS DMD
        WHERE CM_CONTRACT_MONTH >= '201801'
        AND TRUE_DEAL_TYPE NOT IN('BSWPS', 'FSWPS', 'OTCOPT', 'SWPS', 'SSWPS', 'GAS')
        AND NOT(DMD.TRUE_DEAL_TYPE = 'TRANS' AND DMD.DETAIL_SEQ = 2)
        AND NOT(DMD.TRUE_DEAL_TYPE = 'SPDOPT' AND DMD.VOLUME_SEQ = 2 AND EXISTS(
                                                                                SELECT 1
                                                                                FROM nucleus_SPREAD_OPTIONS SO
                                                                                WHERE SO.SPREAD_OPTION_KEY = DMD.DEAL_KEY
                                                                                AND SO.UT_UNIT1 = SO.UT_UNIT2
                                                                               )
               )GROUP BY CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END, DMD.DEAL_KEY, DMD.VOLUME_SEQ , DMD.CM_CONTRACT_MONTH
               ) DMD
LEFT JOIN nucleus_DEAL_CONFIRMS   DC  ON DMD.TRUE_DEAL_TYPE = DC.DLT_DEAL_TYPE AND DMD.DEAL_KEY = DC.DEAL_KEY
     JOIN nucleus_COMPANIES       C   ON DMD.CY_COMPANY_KEY = C.COMPANY_KEY
     JOIN nucleus_LEGAL_ENTITIES  LE  ON DMD.LGL_CY_ENTITY_KEY = LE.CY_ENTITY_KEY 
     JOIN nucleus_PORTFOLIOS      P   ON DMD.PRT_PORTFOLIO = P.PORTFOLIO
     JOIN nucleus_USERS           U   ON DMD.UR_TRADER = U.USER_CODE
--where C.COMPANY_KEY=17454 and DMD.DEAL_KEY=451
GROUP BY DMD.DEAL_KEY
        ,TRUE_DEAL_TYPE
        ,LE.CY_ENTITY_KEY
        ,LE.DESCRIPTION
        ,P.DESCRIPTION
        ,DC.PHY_FIN_FLAG
        ,C.COMPANY_KEY
        ,DMD.DN_DIRECTION
        ,U.USER_NAME
        ,DMD.TRADE_DATE
        ,DMD.CM_CONTRACT_MONTH
        ,DMD.UT_UNIT
        ,DMD.DY_BEG_DAY
        ,DMD.DY_END_DAY
        ,DMD.CU_CURRENCY
""")

# COMMAND ----------

# DBTITLE 1,Financial
financial_df=spark.sql("""
SELECT 
        MCM.MCV_MC_MISC_CHARGE_KEY DEAL_KEY,
        'MISC' DEAL_TYPE,
        LE.CY_ENTITY_KEY TRADING_ENTITY_KEY,
        LE.DESCRIPTION TRADING_ENTITY_LONG_NAME,
        P.DESCRIPTION TRADING_DESK,
        'FIN' INSTRUMENT_TYPE,
        'Power' PRODUCT_TRADED,
        MIN(MCV.DY_BEG_DAY) DEAL_START_DATE,
        MAX(MCV.DY_END_DAY) DEAL_END_DATE,
        C.COMPANY_KEY COUNTERPARTY_ID,
        CASE MCM.REC_PAY_FLAG WHEN 'P' THEN 'PURCHASE' ELSE 'SALE' END BUY_SELL_INDICATOR,
        U.USER_NAME TRADER_NAME,
        CASE WHEN MCM.TRADE_DATE < '1950-01-01' THEN MC.CREATE_DATE ELSE MCM.TRADE_DATE END TRADE_DATE,
        MCM.CM_CONTRACT_MONTH DELIVERY_DATE,
        MCM.UT_UNIT VOLUME_TRADED_UOM,
        MCM.CU_CURRENCY PRICE_CURRENCY,
        SUM(MCM.INT_VOLUME + MCM.R_INT_VOLUME) VOLUME_TRADED
FROM nucleus_MISC_CHARGE_MONTHS  MCM
    JOIN nucleus_MISC_CHARGE_VOLUMES MCV ON MCM.MCV_MC_MISC_CHARGE_KEY = MCV.MC_MISC_CHARGE_KEY AND MCM.MCV_MISC_VOL_SEQ = MCV.MISC_VOL_SEQ
    JOIN nucleus_MISC_CHARGES        MC  ON MCM.MCV_MC_MISC_CHARGE_KEY = MC.MISC_CHARGE_KEY 
    JOIN nucleus_COMPANIES           C   ON MCM.CY_COMPANY_KEY = C.COMPANY_KEY
    JOIN nucleus_LEGAL_ENTITIES LE
ON MCM.LGL_CY_ENTITY_KEY = LE.CY_ENTITY_KEY 
    JOIN nucleus_PORTFOLIOS P
ON P.PORTFOLIO = MCM.PRT_PORTFOLIO
    JOIN nucleus_USERS U
ON MCM.UR_TRADER = U.USER_CODE
WHERE CM_CONTRACT_MONTH >= '201801'
GROUP BY MCM.MCV_MC_MISC_CHARGE_KEY
        ,LE.CY_ENTITY_KEY
        ,LE.DESCRIPTION
        ,P.DESCRIPTION
        ,C.COMPANY_KEY
        ,U.USER_NAME
        ,MCM.CM_CONTRACT_MONTH
        ,MCM.UT_UNIT
        ,MCV.DY_BEG_DAY
        ,MCV.DY_END_DAY
        ,MCM.REC_PAY_FLAG
        ,MCM.TRADE_DATE
        ,MC.CREATE_DATE
        ,MCM.CU_CURRENCY
""")

# COMMAND ----------

# DBTITLE 1,Deal Costs
deal_costs_df=spark.sql("""
SELECT 
        BCM.DEAL_KEY,
        'BROKER FEE' DEAL_TYPE, 
        LE.CY_ENTITY_KEY TRADING_ENTITY_KEY,
        LE.DESCRIPTION TRADING_ENTITY_LONG_NAME,
        P.DESCRIPTION TRADING_DESK,
        'FIN' INSTRUMENT_TYPE,
        'Power' PRODUCT_TRADED,
        MIN(BCM.DY_BEG_DAY) OVER (PARTITION BY BCM.DEAL_KEY ) as DEAL_START_DATE,
        MAX(BCM.DY_END_DAY) OVER (PARTITION BY BCM.DEAL_KEY ) as DEAL_END_DATE,
        C.COMPANY_KEY COUNTERPARTY_ID,
        BCM.DN_DIRECTION BUY_SELL_INDICATOR,
        U.USER_NAME TRADER_NAME,
        BCM.TRADE_DATE,
        BCM.CM_CONTRACT_MONTH DELIVERY_DATE,
        BCM.UT_UNIT VOLUME_TRADED_UOM,
        BCM.CU_CURRENCY PRICE_CURRENCY,
        SUM(BCM.VOLUME) VOLUME_TRADED
FROM nucleus_BROKER_COMMISSION_MONTHS BCM
    JOIN nucleus_COMPANIES C
ON BCM.CY_BROKER_KEY = C.COMPANY_KEY 
    JOIN nucleus_LEGAL_ENTITIES LE
ON BCM.LGL_CY_ENTITY_KEY = LE.CY_ENTITY_KEY
    JOIN nucleus_PORTFOLIOS P
ON P.PORTFOLIO = BCM.PRT_PORTFOLIO
    JOIN nucleus_USERS U
ON BCM.UR_TRADER = U.USER_CODE
WHERE CM_CONTRACT_MONTH >= '201801'
GROUP BY BCM.DEAL_KEY
        ,LE.CY_ENTITY_KEY
        ,LE.DESCRIPTION
        ,P.DESCRIPTION
        ,BCM.DY_BEG_DAY
        ,BCm.DY_END_DAY
        ,C.COMPANY_KEY
        ,U.USER_NAME
		,BCM.DN_DIRECTION
        ,BCM.CM_CONTRACT_MONTH
        ,BCM.UT_UNIT
        ,BCM.TRADE_DATE
        ,BCM.CU_CURRENCY
""")

# COMMAND ----------

# DBTITLE 1,Broker Fee
broker_fee_df=spark.sql("""
SELECT 
        PFM.DEAL_KEY,
        'PROGRAM FEE' DEAL_TYPE, 
        LE.CY_ENTITY_KEY TRADING_ENTITY_KEY,
        LE.DESCRIPTION TRADING_ENTITY_LONG_NAME,
        P.DESCRIPTION TRADING_DESK,
        'FIN' INSTRUMENT_TYPE,
        'Power' PRODUCT_TRADED,
        --PFM.CM_CONTRACT_MONTH,
        MIN((to_date(concat(cm_contract_month,'01'),'yyyyMMdd'))) over (partition by PFM.DEAL_KEY) DEAL_START_DATE,
        max(last_day(to_date(concat(cm_contract_month,'01'),'yyyyMMdd'))) over (partition by PFM.DEAL_KEY)  DEAL_END_DATE,
        C.COMPANY_KEY COUNTERPARTY_ID,
        PFM.DN_DIRECTION BUY_SELL_INDICATOR,
        U.USER_NAME TRADER_NAME,
        PFM.TRADE_DATE,
        PFM.CM_CONTRACT_MONTH DELIVERY_DATE,
        PFM.UT_UNIT VOLUME_TRADED_UOM,
        PFM.CU_CURRENCY PRICE_CURRENCY,
        SUM(PFM.VOLUME) VOLUME_TRADED
FROM nucleus_POWER_FEE_MONTHS PFM
JOIN nucleus_COMPANIES        C
ON PFM.CY_COMPANY_KEY = C.COMPANY_KEY 
    JOIN nucleus_LEGAL_ENTITIES LE
ON PFM.LGL_CY_ENTITY_KEY = LE.CY_ENTITY_KEY
    JOIN nucleus_USERS U
ON PFM.UR_TRADER = U.USER_CODE
    JOIN nucleus_PORTFOLIOS P
ON P.PORTFOLIO = PFM.PRT_PORTFOLIO
WHERE CM_CONTRACT_MONTH >= '201801'
GROUP BY PFM.DEAL_KEY
        ,LE.CY_ENTITY_KEY
        ,LE.DESCRIPTION
        ,P.DESCRIPTION
        ,C.COMPANY_KEY
        ,U.USER_NAME
		,PFM.DN_DIRECTION
        ,PFM.CM_CONTRACT_MONTH
        ,PFM.UT_UNIT
        ,PFM.TRADE_DATE
        ,PFM.CU_CURRENCY
""")

# COMMAND ----------

deal_counterparty_df=physical_df.union(financial_df).union(deal_costs_df).union(broker_fee_df)
deal_counterparty_df=deal_counterparty_df\
.withColumn("DELIVERY_DATE1",to_timestamp(concat(col("DELIVERY_DATE"),lit("01")),"yyyyMMdd"))\
.withColumn("source_system_code",lit("NUCLEUS"))\
.withColumn("meta_created_dttm",current_timestamp())\
.withColumn("report_date_key",date_format(current_timestamp(),'yyyyMMdd').cast(IntegerType()))

# COMMAND ----------

# DBTITLE 1,Staging the data in CP DATA HUB ADLS 
deal_counterparty_df.write.format('delta').mode("append").option("overwriteSchema","true").partitionBy(partition_by_cols_stg).save(adls_file_path_full_src)

# COMMAND ----------

# DBTITLE 1,Read from Staged Folder
deal_counterparty_df = spark.read.format('delta').load(adls_file_path_full_src)

# COMMAND ----------

# DBTITLE 1,Get the max meta created datetime from the DF
max_created_dttm = deal_counterparty_df.select(max("meta_created_dttm")).collect()[0][0] # 2021-10-26 02:39:..
print(max_created_dttm)

# COMMAND ----------

# DBTITLE 1,Filter the data to the latest data staged
deal_counterparty_df = deal_counterparty_df.filter(deal_counterparty_df.meta_created_dttm == max_created_dttm)
deal_counterparty_df.createOrReplaceTempView("vw_deal_counterparty")

# COMMAND ----------

# DBTITLE 1,Getting the  max and greatest of the date columns as per logic defined
deal_counterpary_summary_df = deal_counterparty_df.groupBy(col('COUNTERPARTY_ID')).agg(max("TRADE_DATE").alias("deal_latest_trade_date")\
                                                                                       ,max(col("DELIVERY_DATE1")).alias("max_delivery_date")\
                                                                                      ,max(col("DEAL_START_DATE")),max(col("DEAL_END_DATE"))\
                                                                                      ,greatest(max(col("DELIVERY_DATE1")),max(col("DEAL_START_DATE")),max(col("DEAL_END_DATE"))).alias("deal_latest_delivery_date"))
deal_counterpary_summary_df.createOrReplaceTempView("vw_deal_counterparty_summary")

# COMMAND ----------

# DBTITLE 1,deal_counterparty_summary
deal_counterparty_summary = spark.sql(""" select 'NUCLEUS' as source_system_code
                                         ,cds.COUNTERPARTY_ID as cp_deal_mapping_id  -- Company_Key is nothing but Counterparty_ID
                                         ,cds.deal_latest_trade_date
                                         ,cds.deal_latest_delivery_date
                                         ,concat_ws(",", array_sort((collect_set(cd.TRADER_NAME)))) as deal_latest_trader_name
                                         ,current_timestamp as meta_created_dttm
                                         ,current_timestamp as meta_start_dttm
                                         ,cast('2999-12-31' as timestamp) as meta_end_dttm 
                                         ,'Y'  as active_indicator
                                         , date_format(current_date, 'yyyyMMdd') as report_date_key
                                    from vw_deal_counterparty cd
                                    inner join  vw_deal_counterparty_summary cds on cd.COUNTERPARTY_ID = cds.COUNTERPARTY_ID 
                                    and (cds.deal_latest_trade_date = cd.TRADE_DATE )
                                    group by cds.COUNTERPARTY_ID
                                           , cds.deal_latest_trade_date
                                           , cds.deal_latest_delivery_date
                                     """)
deal_counterparty_summary.createOrReplaceTempView("vw_deal_counterparty_summary")
deal_counterparty_summary.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty_summary/")

# COMMAND ----------

# DBTITLE 1,deal_counterparty
deal_counterparty_final = spark.sql("""select 'NUCLEUS' as source_system_code,
                                              COUNTERPARTY_ID as cp_deal_mapping_id,
                                              TRADING_DESK as deal_trading_desk,
                                              TRADING_ENTITY_KEY as deal_trading_entity,
                                              TRADING_ENTITY_LONG_NAME as deal_trading_entity_long_name,
                                              BUY_SELL_INDICATOR as deal_buy_sell,
                                              INSTRUMENT_TYPE as deal_class,
                                              DEAL_TYPE as deal_product_type,
                                              cast(DELIVERY_DATE as int) as deal_date_month_key,
                                              TRADER_NAME as deal_trader_name,
                                              PRICE_CURRENCY as deal_value_unit_of_measure,
                                              VOLUME_TRADED_UOM as deal_volume_unit_of_measure,
                                              cast('null' as double) as deal_notional_value,
                                              cast(sum(VOLUME_TRADED) as double) as deal_notional_volume,
                                              current_timestamp as meta_created_dttm,
                                              current_timestamp as meta_start_dttm,
                                              cast('2999-12-31' as timestamp) as meta_end_dttm,
                                              'Y'  as active_indicator,
                                              date_format(current_date, 'yyyyMMdd') as report_date_key 
                                        from vw_deal_counterparty
                                        group by COUNTERPARTY_ID,
                                              TRADING_DESK,
                                              TRADING_ENTITY_KEY,
                                              TRADING_ENTITY_LONG_NAME,
                                              BUY_SELL_INDICATOR,
                                              INSTRUMENT_TYPE,
                                              DEAL_TYPE,
                                              DELIVERY_DATE,
                                              TRADER_NAME,
                                              PRICE_CURRENCY,
                                              VOLUME_TRADED_UOM
                                  """)
deal_counterparty_final.createOrReplaceTempView("vw_deal_counterparty")
deal_counterparty_final.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty/")

# COMMAND ----------

# DBTITLE 1,writing to the deal_counterparty ADLS folder and storing to the staging the table
cnt_before_writing = deal_counterparty_final.count()
deal_counterparty= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty/")
cnt_after_writing = deal_counterparty.count()

try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty', 'NUCLEUS')
except Exception as r:
  print("For NUCLEUS source system deal_counteparty counts didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Switch partition from deal_counterparty staging table to target table
LoadCuratedTargetTbl('staging', 'deal_counterparty', 'cp_data_hub', 'deal_counterparty', 'NUCLEUS')

# COMMAND ----------

# DBTITLE 1,deal_counterparty_summary to staging table
cnt_before_writing = deal_counterparty_summary.count()
deal_counterparty_summary= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty_summary/")
cnt_after_writing = deal_counterparty_summary.count()
try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty_summary', 'NUCLEUS')
except Exception as r:
  print("For NUCLEUS source system deal_counteparty_summary counts didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Switch partition from deal_counterparty_summary staging table to target table
LoadCuratedTargetTbl('staging', 'deal_counterparty_summary', 'cp_data_hub', 'deal_counterparty_summary', 'NUCLEUS')
