# Databricks notebook source
import json

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

#Get values from the Excel in JSON form
dbutils.widgets.text("Values", " ")
values_str  = dbutils.widgets.get("Values")

#Convert to DataFrame
values_df = sqlContext.read.json(sc.parallelize([values_str]))

#View DF
display(values_df)

#Create a temp view to write into DB
values_df.createOrReplaceTempView('vw_config_adls_paths')

# COMMAND ----------

RefreshCuratedSqlTbl('cp_data', 'config_adls_paths')
