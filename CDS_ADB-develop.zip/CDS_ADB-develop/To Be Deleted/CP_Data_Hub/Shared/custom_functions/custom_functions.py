# Databricks notebook source
# MAGIC %run "/CP_Data/Shared/config/config"

# COMMAND ----------

#make all the imports here
from pyspark.sql.functions import *
import pyodbc
import pandas as pd
from multipledispatch import dispatch
from pyspark.sql.functions import col, concat_ws

import datetime
import json
# import pyspark.sql.functions as sf
# import pyodbc
# from pyspark.sql.functions import lit, col, desc, expr, unix_timestamp, from_unixtime, to_timestamp, asc
from pyspark.sql.types import StringType, StructType, StructField, IntegerType, TimestampType, LongType, DoubleType
from pyspark.sql.window import Window

# COMMAND ----------

# DBTITLE 1,Creates Temporary Views for the Logic
def create_temp_views_per_source_system(source_system,vw_prefix_name):
    """
     create tempviews for adls paths
    """
    src_tables_List= [] # empty to store the table name and filepath
    temp_views_List= [] # temporary views to print the in notebook when called.
    df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'cp_data.config_adls_paths') # read config table to retrieve the adls file paths
    df = df.filter(f"source_system == '{source_system}'")
    IsSAPHANA = True if source_system == 'SAPHANA' else False   #specific to SAPHANA
    df = df.filter("active_flag == 1")
    df.createOrReplaceTempView(f"vw_cp_data_config_adls_paths")
    df_new = df.toPandas()
#     df_new = df_new.filter("active_flag=='Y'")
#     print(df_new.head())
                   
    dataframedict = {}
    for row in df_new.itertuples():
        src_tables_List.append((row.src_table_name,  row.old_adls_full_path, row.new_adls_full_path))
        if row.adls_file_format =='parquet' and row.old_new_adls_path_indicator =='OLD':
          dataframedict[row.src_table_name] = spark.read.format("parquet").load(row.old_adls_full_path).filter(col("IS_RECORD_ACTIVE") == 1)
        elif row.adls_file_format =='delta' and row.old_new_adls_path_indicator =='OLD':
          dataframedict[row.src_table_name] = spark.read.format("delta").load(row.old_adls_full_path).filter(col("IS_RECORD_ACTIVE") == 1)
        elif row.adls_file_format =='parquet' and row.old_new_adls_path_indicator =='NEW':
          dataframedict[row.src_table_name] = spark.read.format("parquet").load(row.new_adls_full_path).filter(col("IS_RECORD_ACTIVE") == 1)
        elif row.adls_file_format =='delta' and row.old_new_adls_path_indicator =='NEW':
          dataframedict[row.src_table_name] = spark.read.format("delta").load(row.new_adls_full_path).filter(col("IS_RECORD_ACTIVE") == 1)
          
    #create the temporary views
    for key,value in dataframedict.items():
    #  if IsSAPHANA == True :
    #    
    #    temp_views_List.append(f"vw_{vw_prefix_name}_{key.split('/')[1]}")
    #    dataframedict[key] = value.createOrReplaceTempView(f"{vw_prefix_name}_{key.split('/')[1]}")
    #  else : 
        temp_views_List.append(f"{vw_prefix_name}_{key}")
        dataframedict[key] = value.createOrReplaceTempView(f"{vw_prefix_name}_{key}")
    print("Temp View Names")
    print(temp_views_List)

# COMMAND ----------

# DBTITLE 1,Truncate and Reload the table in Curated DB
@dispatch(str,str)
def RefreshCuratedSqlTbl(tgt_schema_name, tgt_table_name):
  """
  Loads the data into sql server for curated layer
  tgt_schema_name = 'cp_data'
  tgt_tablename   = 'gtmi_singlecplist'
  source_system   = 'GOLD_TIER_MI'
  """
  try:
    df = spark.sql(f"select * from  vw_{tgt_table_name}")
    print(tgt_schema_name , tgt_table_name)
    if df.count() > 0:
      print(df.count())
      conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                            'SERVER='+dbServer_curated+';'
                            'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
                            'PWD='+dbPass
                            )
      cursor = conn.cursor()
      execSQL = f"truncate table {tgt_schema_name}.{tgt_table_name}"
      conn.autocommit = True
      cursor.execute(execSQL)
      print("Data been Deleted")
      df.write.jdbc(Stratos_sqldb_URL_curated, f"{tgt_schema_name}.{tgt_table_name}", "append")
      print(f"load of {tgt_table_name}  with  is completed")
    else:
      print("Returned Zero Records")
      
  except Exception as e:
    print('Exception raised')
    raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Delete by source_system and Reload the table in Curated DB
@dispatch(str,str,str)
def RefreshCuratedSqlTbl(tgt_schema_name, tgt_table_name, source_system_code):
        """
        Loads the data into sql server for curated layer
        tgt_schema_name = 'cp_data'
        tgt_tablename   = 'gtmi_singlecplist'
        source_system   = 'GOLD_TIER_MI'
        """
        try:
            df = spark.sql(f"select * from  vw_{tgt_table_name}").cache()
            print(tgt_schema_name , tgt_table_name, source_system_code)
            if df.count() > 0:
                print(df.count())
                conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                                    'SERVER='+dbServer_curated+';'
                                    'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
                                    'PWD='+dbPass
                                    )
                cursor = conn.cursor()
                #chainging the source_system to source_system_code.
                execSQL = f"delete from {tgt_schema_name}.{tgt_table_name} where source_system_code = upper('{source_system_code}')"
                conn.autocommit = True
                cursor.execute(execSQL)
                print("Data been Deleted")
                df.write.jdbc(Stratos_sqldb_URL_curated, f"{tgt_schema_name}.{tgt_table_name}", "append")
                print(f"load of {tgt_table_name}  of {source_system_code} is completed")
            else:
                print("Returned Zero Records")

        except Exception as e:
            print('Exception raised')
            raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Delete by source_system and Reload the table in Harmonized DB
@dispatch(str,str,str)
def RefreshHarmonizedSqlDbTbl(tgt_schema_name, tgt_table_name, source_system_code):
  """
  Loads the data into sql server for curated layer
  tgt_schema_name = 'cp_data'
  tgt_tablename   = 'gtmi_singlecplist'
  source_system   = 'GOLD_TIER_MI'
  """
  try:
    df = spark.sql(f"select * from  vw_{tgt_table_name}_{source_system_code}")
    print(tgt_schema_name , tgt_table_name, source_system_code)
    if df.count() > 0:
      print(df.count())
      conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                            'SERVER='+dbServer+';'
                            'DATABASE='+dbDatabase+';UID='+dbUser+';'
                            'PWD='+dbPass
                            )
      cursor = conn.cursor()
      #chainging the source_system to source_system_code.
      execSQL = f"delete from {tgt_schema_name}.{tgt_table_name} where source_system_code = upper('{source_system_code}')"
      conn.autocommit = True
      cursor.execute(execSQL)
      print("Data been Deleted")
      df.write.jdbc(Stratos_sqldb_URL, f"{tgt_schema_name}.{tgt_table_name}", "append")
      print(f"load of {tgt_table_name}  with  is completed")
    else:
      print("Returned Zero Records")
      
  except Exception as e:
    print('Exception raised')
    raise dbutils.notebook.exit(e)

# COMMAND ----------

#def DeleteInsertCuratedSqlTbl(tgt_schema_name, tgt_table_name, source_system):
#        """
#        Loads the data into sql server for curated layer
#        tgt_schema_name = 'cp_data'
#        tgt_tablename   = 'gtmi_singlecplist'
#        source_system   = 'GOLD_TIER_MI'
#        """
#        try:
#            df = spark.sql(f"select * from  vw_{tgt_table_name}")
#            print(tgt_schema_name , tgt_table_name, source_system)
#            if df.count() > 0:
#                print(df.count())
#                conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
#                                    'SERVER='+dbServer_curated+';'
#                                    'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
#                                    'PWD='+dbPass
#                                    )
#                cursor = conn.cursor()
#                execSQL = f"delete from {tgt_schema_name}.{tgt_table_name} where source_system = upper('{source_system}')"
#                conn.autocommit = True
#                cursor.execute(execSQL)
#                print("Data been Deleted")
#                df.write.jdbc(Stratos_sqldb_URL_curated, f"{tgt_schema_name}.{tgt_table_name}", "append")
#                print(f"load of {tgt_table_name}  of {source_system} is completed")
#            else:
#                print("Returned Zero Records")
#
#        except Exception as e:
#            print('Exception raised')
#            raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Load data from curated staging table to curated target table -deprecate
# def LoadCuratedTargetTbl(stg_schema_name, stg_table_name, tgt_schema_name, tgt_table_name):
#   try:
#       conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
#                             'SERVER='+dbServer_curated+';'
#                             'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
#                             'PWD='+dbPass
#                             )
#       cursor = conn.cursor()
#       execSQL=f'''BEGIN TRAN
#       BEGIN TRY
      
#       TRUNCATE TABLE {tgt_schema_name}.{tgt_table_name} with (PARTITIONS (2));
#       ALTER TABLE {stg_schema_name}.{stg_table_name} SWITCH TO {tgt_schema_name}.{tgt_table_name} PARTITION 2;
#       TRUNCATE TABLE {tgt_schema_name}.{tgt_table_name} with (PARTITIONS (1));
      
#       COMMIT TRAN
#       END TRY
#       BEGIN CATCH
#       ROLLBACK;
#       END CATCH'''
#       conn.autocommit = True
#       cursor.execute(execSQL)
#       print(f"loading of {tgt_table_name} table is completed")
      
#   except Exception as e:
#     print('Exception raised')
#     raise dbutils.notebook.exit(e)

# COMMAND ----------

def get_partition_number(stg_schema_name,stg_table_name,source_system_code):
  try:
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                            'SERVER='+dbServer_curated+';'
                            'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
                            'PWD='+dbPass
                            )
    cursor = conn.cursor()
    exec_sql = f"""
                  select distinct 
                       
                         p.partition_number  as partition_number
                       -- sc.name            as schema_name
                       --,t.name             as table_name
                        --,rv.value          as partition_value
                    FROM sys.tables     AS t  
                    JOIN sys.schemas    as sc         on t.schema_id = sc.schema_id
                    JOIN sys.indexes    AS i		  ON t.object_id = i.object_id  
                    JOIN sys.partitions AS p		  ON i.object_id = p.object_id AND i.index_id = p.index_id   
                    JOIN  sys.partition_schemes AS s  ON i.data_space_id = s.data_space_id  
                    JOIN sys.partition_functions AS f ON s.function_id = f.function_id  
                    LEFT JOIN sys.partition_range_values AS r ON f.function_id = r.function_id and r.boundary_id = p.partition_number  
                    LEFT JOIN sys.partition_range_values AS rv ON f.function_id = rv.function_id AND p.partition_number = rv.boundary_id     
                    --LEFT JOIN sys.partition_range_values AS rv2 ON f.function_id = rv2.function_id AND p.partition_number - 1= rv2.boundary_id
                    WHERE i.type <= 1 
                    AND t.name = '{stg_table_name}' 
                    and sc.name = '{stg_schema_name}'
                    and rv.value = '{source_system_code}'
               """
    conn.autocommit=True
    cursor.execute(exec_sql)
    partition_number =cursor.fetchone()[0]
    
    return partition_number
  except Exception as e:
    print('Exception raised')
    raise dbutils.notebook.exit(e)
    

# COMMAND ----------

def LoadCuratedTargetTbl(stg_schema_name, stg_table_name, tgt_schema_name, tgt_table_name,source_system_code):
  try:
      var_partition_num = get_partition_number(stg_schema_name,stg_table_name,source_system_code)
      print('partition num:', var_partition_num)
      conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                            'SERVER='+dbServer_curated+';'
                            'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
                            'PWD='+dbPass
                            )
      cursor = conn.cursor()
      execSQL=f'''BEGIN TRAN
      BEGIN TRY
      
      TRUNCATE TABLE {tgt_schema_name}.{tgt_table_name} with (PARTITIONS ({var_partition_num}));
      ALTER TABLE    {stg_schema_name}.{stg_table_name} SWITCH PARTITION {var_partition_num} TO {tgt_schema_name}.{tgt_table_name} PARTITION {var_partition_num};
           
      COMMIT TRAN
      END TRY
      BEGIN CATCH
      ROLLBACK;
      THROW;
      END CATCH'''
      conn.autocommit = True
      cursor.execute(execSQL)
      print(f"loading of {tgt_table_name} table is completed")
      
  except Exception as e:
    print('Exception raised')
    raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Refresh date for P3 systems
def RefreshDateP3(col_name,schema_name,table_name,source_system):
  """
  This function will update the refresh date for P3 system in table staging.cp_data_transactional_refresh_date
  col_name  is used to take the date for refresh date
  schema_name is used for IMOS,ENDUR_OIL and ENDUR_PRODUCTS for other source its NULL
  table_name is used for table from which the refresh date will be taken
  
  """
  source_list =['IMOS','ENDUR_OIL','ENDUR_PRODUCTS']
  try:
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                            'SERVER='+dbServer_curated+';'
                            'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
                            'PWD='+dbPass
                            )
    cursor = conn.cursor()
      
    if source_system not in source_list:
      refresh_date = spark.sql(f"select cast(max({col_name}) as timestamp) as maxdt  from {table_name}").collect()[0][0]
      print(refresh_date)
      conn.autocommit = True
      execSQL = f"""update staging.cp_data_transactional_refresh_date set refresh_date= '{refresh_date}' where source_system_code ='{source_system}'"""
      print(execSQL)
      cursor.execute(execSQL)
    else:
      conn.autocommit = True
      execSQL1 = f"""update [staging].[cp_data_transactional_refresh_date] set refresh_date = (select max(dateadd(day,-1,cast({col_name} as datetime2)))
                    from {schema_name}.{table_name})where source_system_code='{source_system}' """
      print(execSQL1)
      cursor.execute(execSQL1)
  except Exception as e:
    print('Exception raised')
    raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Refresh date for P4 systems
def RefreshDateP4(col_name,table_name1,table_name2,table_name3,table_name4,source_system):
  """
  This function will update the refresh date for P4 system in table staging.cp_data_transactional_refresh_date
  col_name  is used to take the date for refresh date
  table_name1,2,3 and 4 is used for tables from which the refresh date will be taken (AP Open, AP Cleared, AR Open, AR Cleared)
  
  """
  try:
    conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                            'SERVER='+dbServer_curated+';'
                            'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
                            'PWD='+dbPass
                            )
    cursor = conn.cursor()
      
    refresh_date = spark.sql(f"""select to_timestamp(concat(
                                  cast(substring(refresh_dttm,1,1) as string),
                                  cast(substring(refresh_dttm,3,3) as string),
                                  cast(substring(refresh_dttm,6,4) as string),
                                  lpad(cast(int(refresh_dttm % 1000000) as string),6,'0')
                                  ),'yyyyMMddHHmmss') as maxdt from
                                 (
                                      select max(refresh_dttm) as refresh_dttm from 
                                      (
                                          select max({col_name}) as refresh_dttm from {table_name1}
                                          union
                                          select max({col_name}) as refresh_dttm from {table_name2}
                                          union
                                          select max({col_name}) as refresh_dttm from {table_name3}
                                          union
                                          select max({col_name}) as refresh_dttm from {table_name4}
                                      )
                                 )
                              """).collect()[0][0]
    print(refresh_date)
      
    conn.autocommit = True
    execSQL = f"""update staging.cp_data_transactional_refresh_date set refresh_date= '{refresh_date}' where source_system_code ='{source_system}'"""
    print(execSQL)
    cursor.execute(execSQL)
    
  except Exception as e:
    print('Exception raised')
    raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,ODBC-DB Connection Details
def db_connection_details():
    """Comment Sections
    """
    try:
        v_conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                                    'SERVER='+dbServer_curated+';'
                                    'DATABASE='+dbDatabase_curated+';UID='+dbUser+';'
                                    'PWD='+dbPass
                                    )
    
        return v_conn
    
    except Exception as e:
        print('Exception raised')
        raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,return config id by passing source system,  table_schema, table_name
def get_ref_refresh_tbl_config_id(source_system_code, cpdata_tgt_table_schema, cpdata_tgt_table_name):
      """
      Comments Section:
      """
      try:
          conn=   db_connection_details()
          cursor= conn.cursor()
          refresh_config_id_qry = f"select distinct ref_refresh_tbl_config_id from  cp_data.ref_refresh_tbl_config where source_system_code = '{source_system_code}' and cpdata_tgt_table_schema = '{cpdata_tgt_table_schema}' and cpdata_tgt_table_name = '{cpdata_tgt_table_name}' "
          v_ref_refresh_tbl_config_id = cursor.execute(refresh_config_id_qry).fetchone()[0]
          print('Statement print inside func. ref_refresh_tbl_config_id Job in DB:',v_ref_refresh_tbl_config_id)
      except:
          print("getting config id failed")
          dbutils.notebook.exit("getting config id failed")
    
      return v_ref_refresh_tbl_config_id

# COMMAND ----------

# DBTITLE 1,Notebook JobId~RunId~NotebookPath
def get_notebook_run_id(notebook_start_datetime):
      notebook_info = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
      try:
          current_job_id = notebook_info["tags"]["jobId"]
          print(current_job_id)
          current_run_id = notebook_info["tags"]["runId"]
          print(current_run_id)
          notebook_path = notebook_info["extraContext"]["notebook_path"]
          print(notebook_path)
          """
          run_id  = job_id~run_id~notebook_path
          """
          run_id_notebook_path = current_job_id+'~'+current_run_id+'~'+notebook_path+'~'+str(notebook_start_datetime)
          out_run_id_notebook_path = run_id_notebook_path.replace('@shell.com','')
          print(out_run_id_notebook_path)
          
      except:
          current_job_id ="manual_run" # making the job_id manual if someone runs manually
          current_run_id = notebook_info["extraContext"]["aclPathOfAclRoot"]
          notebook_path = notebook_info["extraContext"]["notebook_path"]
          run_id_notebook_path = current_job_id+'~'+current_run_id+'~'+notebook_path+'~'+str(notebook_start_datetime)
          out_run_id_notebook_path = run_id_notebook_path.replace('@shell.com','')
      return out_run_id_notebook_path

# COMMAND ----------

# DBTITLE 1,Assign New Job ID to the Logging System
def assign_new_job_id():
      """
      First insert the row for tbl_config into the table get the max value for that tbl_config and carry that job id for the rest the config used within the cell.
      ENDUR_GP_NA, cp_Data_hub , counterparty_logic

      """
      try:
          conn=   db_connection_details()
          cursor= conn.cursor()
        #   latest_job_id_qry = f"select max(pl_refresh_job_id) from  cp_data.refresh_job_status_log where ref_refresh_tbl_config_id ={ref_refresh_tbl_config_id}"
          max_job_id_qry = f"select max(pl_run_refresh_job_id) from  cp_data.pl_run_refresh_status_log"

          max_job_id = cursor.execute(max_job_id_qry).fetchone()[0]
          if max_job_id == None:
            v_max_job_id= 1
          else:
            v_max_job_id = max_job_id +1

          print('Statement print inside func. Latest Job in DB:',v_max_job_id)
          return v_max_job_id

      except Exception as e:
          print('Exception raised')
          raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Retrieve Job Id and assign for current refresh
def get_latest_job_id_current_refresh(ref_refresh_tbl_config):
      
      try:
          conn = db_connection_details()
          cursor = conn.cursor()
          get_latest_job_id_current_refresh_qry  = f"select max(pl_run_refresh_job_id) from cp_data.pl_run_refresh_status_log where pl_meta_config_id = {ref_refresh_tbl_config}"
          v_latest_job_id_current_refresh = cursor.execute(get_latest_job_id_current_refresh_qry).fetchone()[0]
          print("inside get_latest_job_id_current_refresh func. value ", v_latest_job_id_current_refresh)
          return v_latest_job_id_current_refresh
        
      except Exception as e:
        print('Exception raised')
        raise dbutils.notebook.exit(e)

# COMMAND ----------

def ins_row_refresh_log_tbl(log_table_name, insert_qry_values):
    try:
        conn=db_connection_details()
        cursor=conn.cursor()
#       log_table_col_names  = "(pl_run_refresh_id, pl_run_refresh_job_id, pl_meta_config_id, pl_run_refresh_activity_description, pl_run_refresh_row_count,pl_run_exception_comments,pl_run_refresh_create_dttm)"
        refresh_log_tbl_name = log_table_name
        log_table_col_names = "(pl_run_refresh_id, pl_run_refresh_job_id, pl_meta_config_id, pl_run_refresh_activity_description, pl_run_refresh_row_count,pl_run_exception_comments,pl_run_refresh_create_dttm)"
        insert_row_cnt_qry = f"insert into cp_data.{refresh_log_tbl_name}{log_table_col_names} values (?,?,?,?,?,?,?)"
        cursor.execute(insert_row_cnt_qry, insert_qry_values)
        cursor.commit()
    except Exception as e:
        raise(dbutils.noteboook.exit(e))

# COMMAND ----------

def log_notebook_activity(source_system_code, curated_tbl_schema, curated_tbl_name, pl_run_refresh_id, notebook_start_datetime, log_table_name='pl_run_refresh_status_log',notebook_activity='notebook_start'):
    try:
        conn=db_connection_details()
        v_notebook_run_id = get_notebook_run_id(notebook_start_datetime)
        print(v_notebook_run_id)
        v_config_id  = get_ref_refresh_tbl_config_id(source_system_code, curated_tbl_schema, curated_tbl_name)
        print(f"'config in the log_notebook_activity function:' {v_config_id}")
      
        insert_qry_values = (v_notebook_run_id,pl_run_refresh_id, v_config_id, f"{notebook_activity}", None, None,datetime.datetime.now())
#         ins_row_refresh_log_tbl('pl_run_refresh_status_log',insert_qry_values)
        ins_row_refresh_log_tbl(log_table_name, insert_qry_values)
    except Exception as e:
        print(repr(e))
        raise(dbutils.noteboook.exit(e))
  

# COMMAND ----------

def get_row_cnt(source_system_code,table_name, tbl_schema_name='cp_data_hub'):
  
      try:
          conn = db_connection_details()
          cursor = conn.cursor()
          cnt_query = f"select count(1) from {tbl_schema_name}.{table_name} where source_system_code = upper('{source_system_code}')"
          tgt_row_cnt = cursor.execute(cnt_query).fetchone()[0]

          return tgt_row_cnt
        
      except Exception as e:
        print('Exception raised')
        raise dbutils.notebook.exit(e)

# COMMAND ----------

def delete_data_with_condition(source_system_code,table_name, table_schema_name='staging'):
  
      try:
          conn = db_connection_details()
          cursor = conn.cursor()
          del_qry = f"Delete from {table_schema_name}.{table_name} where source_system_code = upper('{source_system_code}')"
          cursor.execute(del_qry)
          conn.commit()
          
      except Exception as e:
        print('Exception raised')
        raise dbutils.notebook.exit(e)

# COMMAND ----------

def refresh_curated_sqltbl_with_logging(tgt_schema_name, tgt_table_name, source_system_code):
    """
    delete the data in staging schema and then insert the data into the staging tables for that source_system_code
    tgt_schema_name = 'cp_data'
    tgt_tablename   = 'gtmi_singlecplist'
    source_system   = 'GOLD_TIER_MI'
    """
    try:
        df = spark.sql(f"select * from  vw_{tgt_table_name}").cache()
        print(tgt_schema_name , tgt_table_name, source_system_code)
        data_processed_cnt = df.count()
        if data_processed_cnt >0:
            print(f"Data Processed Cnt:{data_processed_cnt}")
            conn = db_connection_details()
            cursor = conn.cursor()
            
            #log the refresh process_start
            insert_qry_values =(cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'StageRefreshProcess_Start',None, None,datetime.datetime.now())
            print(insert_qry_values)
            ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
            
            #log the curated final target table row count
            v_tgt_cnt = get_row_cnt(source_system_code, tgt_table_name, 'cp_data_hub')
            print(f"target_row_count for {source_system_code} : {v_tgt_cnt}")
            insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id, 'TgtCount_BeforeRefresh_Start',v_tgt_cnt,None,datetime.datetime.now() )
            ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
            
            #log the curated staging table row count
            v_stg_cnt = get_row_cnt(source_system_code, tgt_table_name, 'cp_data_hub')
            print(f"target_row_count for {source_system_code} : {v_tgt_cnt}")
            insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id, 'StgCount_BeforeDelete_Start',v_stg_cnt,None,datetime.datetime.now() )
            ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
            
            #log the current df/activity process count
            v_data_processed_cnt =data_processed_cnt
            print(f"processed count: ", v_data_processed_cnt)
            insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'DataProcessed_Cnt',v_data_processed_cnt, None, datetime.datetime.now())
            ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
            
            #log delete data in stage processed
            print(f"delete process started")
            insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'DataDelete_Start',None, None, datetime.datetime.now())
            ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
            
            #actual delete process
            delete_data_with_condition(source_system_code,tgt_table_name,'staging')
            
            #log delete data in stage processed end
            print(f"delete process end")
            insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'DataDelete_End', None, None, datetime.datetime.now())
            ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
            
            v_stg_cnt_after_del = get_row_cnt(source_system_code, tgt_table_name, 'staging')
            print(f"stage count after delete for {source_system_code} : {v_stg_cnt}")
            insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'StgCount_AfterDelete_End',v_stg_cnt_after_del, None, datetime.datetime.now())
            ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
            
            
            if v_stg_cnt_after_del ==0:
                #log insert into stage start
                print("Insert into Stage Start")
                insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'Insert_Stg_Start',None, None,datetime.datetime.now())
                ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
                
                
                #insert into the stage table
                df.write.jdbc(Stratos_sqldb_URL_curated, f"staging.{tgt_table_name}", "append")
                print("Insert into Stage End")
                insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'Insert_Stg_End',None, None, datetime.datetime.now())
                ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
            else:
                print("Insert into Stage-Didn't Happened")
                insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'Insert_Stg_Failed',None, None,datetime.datetime.now())
                ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
            
            #log the stage count after insert
            
            v_stg_cnt_after_ins = get_row_cnt(source_system_code, tgt_table_name, 'staging')
            print(f"stage_row_count after insert - {source_system_code} : {v_stg_cnt_after_ins}")
            insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'StgCount_AfterInsert_End',v_stg_cnt_after_ins, None, datetime.datetime.now())
            ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
            
            insert_qry_values =(cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'StageRefreshProcess_End',None, None,datetime.datetime.now())
            print(insert_qry_values)
            ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
            
            conn.commit()
            
    except Exception as err:
        print(repr(err))
        print(len(repr(err)))
        insert_qry_values =(cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'exception_raised',None, repr(err),datetime.datetime.now())
        ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
        raise dbutils.notebook.exit(err)
        

# COMMAND ----------

def load_curated_target_tbl_with_logging(stg_schema_name, stg_table_name, tgt_schema_name, tgt_table_name,source_system_code):
  """
  Commments
  """
  #get row count of the processed and stg count
  v_stg_cnt = get_row_cnt(source_system_code,tgt_table_name,stg_schema_name)
  print(f"stage count for: {source_system_code}-{stg_schema_name}.{tgt_table_name}={v_stg_cnt}")
  
  #processed count to load into target table.
  v_data_processed_cnt = spark.sql(f"select * from  vw_{tgt_table_name}").cache().count()
  print(f"processed count for : {source_system_code}-{tgt_table_name}: {v_data_processed_cnt}")
  
  #log final curated table refresh start
  print("Final Curated Table Refresh Process-Start")
  insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'Final Curated Table Refresh Process-Start',None, None, datetime.datetime.now())
  ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
  
  try:
    if v_stg_cnt == v_data_processed_cnt:
        #log stage cnt and data processed count validation check
        print(f"Count Validation Check-Passed: StageCount={v_stg_cnt} and ProcessedCount={v_data_processed_cnt}")
        insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'ValidationCheck-Passed',v_stg_cnt, None, datetime.datetime.now())
        ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
        
        #log into final Curated Table
        insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'AlterPartitionCommand-Start',None, None, datetime.datetime.now())
        ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
        
        #actual alter partition
        LoadCuratedTargetTbl(stg_schema_name, stg_table_name, tgt_schema_name, tgt_table_name,source_system_code)
        
        #log alter command end process 
        insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'AlterParitionCommand-End',None, None, datetime.datetime.now())
        ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
        
        v_tgt_cnt_after_refresh = get_row_cnt(source_system_code, tgt_table_name, 'cp_data_hub')
        insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'TgtRowCountCheck',v_tgt_cnt_after_refresh, None, datetime.datetime.now())
        ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
        
        print(f"Refresh Completed  for the final Curated table: cp_data_hub.counterparty")
        
        #log refresh Completed 
        insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'Final Curated Table Refresh Process-End',None, None, datetime.datetime.now())
        ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
        
    else:
        #log stage cnt and data Processed count failed check
        print(f"Count Validation Check-Failed: {v_stg_cnt} and {v_data_processed_cnt}")
        insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'ValidationCheck-Failed',v_stg_cnt, None, datetime.datetime.now())
        ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
      
  except Exception as err:
      print("Entered Exception")
      insert_qry_values = (cur_pl_run_refresh_id, cur_pl_run_refresh_job_id, v_config_id,'Exception Raised',None, repr(err), datetime.datetime.now())
      ins_row_refresh_log_tbl('pl_run_refresh_status_log', insert_qry_values)
      raise dbutils.notebook.exit(err)
  
  
