# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

create_temp_views_per_source_system('ENERGYCREDIT', 'ENERGYCREDIT_PRD')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_report_party as
# MAGIC select distinct p.*,
# MAGIC RP.dAssetSize as  rp_dAssetSize,
# MAGIC RP.dDefaultProbability as  rp_dDefaultProbability,
# MAGIC RP.dOverallLimit as  rp_dOverallLimit,
# MAGIC RP.dRecoveryRate as  rp_dRecoveryRate,
# MAGIC RP.dteAmended as  rp_dteAmended,
# MAGIC RP.dteBankruptcy as  rp_dteBankruptcy,
# MAGIC RP.dteEffective as  rp_dteEffective,
# MAGIC RP.dteExpiry as  rp_dteExpiry,
# MAGIC RP.dteFutureNameEffectiveDate as  rp_dteFutureNameEffectiveDate,
# MAGIC RP.dtePrevReview as  rp_dtePrevReview,
# MAGIC RP.dteReview as  rp_dteReview,
# MAGIC RP.lPartyId as  rp_lPartyId,
# MAGIC RP.sAccountStatus as  rp_sAccountStatus,
# MAGIC RP.sActive as  rp_sActive,
# MAGIC RP.sAddress as  rp_sAddress,
# MAGIC RP.sAddressCode as  rp_sAddressCode,
# MAGIC RP.sAliases as  rp_sAliases,
# MAGIC RP.sAmendedBy as  rp_sAmendedBy,
# MAGIC RP.sAssetSizeCurrency as  rp_sAssetSizeCurrency,
# MAGIC RP.sBankruptcy as  rp_sBankruptcy,
# MAGIC RP.sBlocked as  rp_sBlocked,
# MAGIC RP.sBuyOnly as  rp_sBuyOnly,
# MAGIC RP.sCity as  rp_sCity,
# MAGIC RP.sCompositeRating as  rp_sCompositeRating,
# MAGIC RP.sContact as  rp_sContact,
# MAGIC RP.sCountryIncorporation as  rp_sCountryIncorporation,
# MAGIC RP.sCountryOfRisk as  rp_sCountryOfRisk,
# MAGIC RP.sCreditOfficer as  rp_sCreditOfficer,
# MAGIC RP.sCreditOutlook as  rp_sCreditOutlook,
# MAGIC RP.sCreditRating as  rp_sCreditRating,
# MAGIC RP.sCurrency as  rp_sCurrency,
# MAGIC RP.sDBRSOutlook as  rp_sDBRSOutlook,
# MAGIC RP.sDBRSRating as  rp_sDBRSRating,
# MAGIC RP.sDescription as  rp_sDescription,
# MAGIC RP.sDomicileCountry as  rp_sDomicileCountry,
# MAGIC RP.sEcreditAcctNum as  rp_sEcreditAcctNum,
# MAGIC RP.sEmailAddress as  rp_sEmailAddress,
# MAGIC RP.sEntityType as  rp_sEntityType,
# MAGIC RP.sFacsimile as  rp_sFacsimile,
# MAGIC RP.sFitchOutlook as  rp_sFitchOutlook,
# MAGIC RP.sFitchRating as  rp_sFitchRating,
# MAGIC RP.sFSAStatus as  rp_sFSAStatus,
# MAGIC RP.sFutureDescription as  rp_sFutureDescription,
# MAGIC RP.sFutureMnemonic as  rp_sFutureMnemonic,
# MAGIC RP.sGSTExclusive as  rp_sGSTExclusive,
# MAGIC RP.sGuaranteeParent as  rp_sGuaranteeParent,
# MAGIC RP.sICEParticipant as  rp_sICEParticipant,
# MAGIC RP.sIndustryCode as  rp_sIndustryCode,
# MAGIC RP.sIndustryCodeDescription as  rp_sIndustryCodeDescription,
# MAGIC RP.sInternalOutlook as  rp_sInternalOutlook,
# MAGIC RP.sInternalRating as  rp_sInternalRating,
# MAGIC RP.sISCommonCounterparty as  rp_sISCommonCounterparty,
# MAGIC RP.sISCreditFileExists as  rp_sISCreditFileExists,
# MAGIC RP.sISFutureNameChange as  rp_sISFutureNameChange,
# MAGIC RP.sIsUltimate as  rp_sIsUltimate,
# MAGIC RP.sLCAddress as  rp_sLCAddress,
# MAGIC RP.sLCContactName as  rp_sLCContactName,
# MAGIC RP.sLCEmail as  rp_sLCEmail,
# MAGIC RP.sLCOffice as  rp_sLCOffice,
# MAGIC RP.sLCRegNumber as  rp_sLCRegNumber,
# MAGIC RP.sLCTelephone as  rp_sLCTelephone,
# MAGIC RP.sLegalParent as  rp_sLegalParent,
# MAGIC RP.sLegalStatus as  rp_sLegalStatus,
# MAGIC RP.sLegalUltimateParent as  rp_sLegalUltimateParent,
# MAGIC RP.sLimitReviewFrequency as  rp_sLimitReviewFrequency,
# MAGIC RP.sLimitReviewFrequencyType as  rp_sLimitReviewFrequencyType,
# MAGIC RP.sMarket as  rp_sMarket,
# MAGIC RP.sMoodyOutlook as  rp_sMoodyOutlook,
# MAGIC RP.sMoodyRating as  rp_sMoodyRating,
# MAGIC RP.sName as  rp_sName,
# MAGIC RP.sNarrative as  rp_sNarrative,
# MAGIC RP.sOTCClearance as  rp_sOTCClearance,
# MAGIC RP.sPartyType as  rp_sPartyType,
# MAGIC RP.sPrimaryAnalyst as  rp_sPrimaryAnalyst,
# MAGIC RP.sPrimaryContact as  rp_sPrimaryContact,
# MAGIC RP.sRelationshipManager as  rp_sRelationshipManager,
# MAGIC RP.sReverseBlocked as  rp_sReverseBlocked,
# MAGIC RP.sSAndPOutlook as  rp_sSAndPOutlook,
# MAGIC RP.sSAndPRating as  rp_sSAndPRating,
# MAGIC RP.sSecondaryAnalyst as  rp_sSecondaryAnalyst,
# MAGIC RP.sTelephone as  rp_sTelephone,
# MAGIC RP.sTelex as  rp_sTelex,
# MAGIC RP.sTradeStatus as  rp_sTradeStatus,
# MAGIC RP.sUltimateName as  rp_sUltimateName,
# MAGIC RP.sUrl as  rp_sUrl,
# MAGIC RP.sWatchList as  rp_sWatchList,
# MAGIC RP.META_CREATED_DTTM as  rp_META_CREATED_DTTM,
# MAGIC RP.EFFECTIVE_START_DATE as  rp_EFFECTIVE_START_DATE,
# MAGIC RP.EFFECTIVE_END_DATE as  rp_EFFECTIVE_END_DATE,
# MAGIC RP.IS_RECORD_ACTIVE as  rp_IS_RECORD_ACTIVE
# MAGIC from ENERGYCREDIT_PRD_Party P --left table
# MAGIC left join ENERGYCREDIT_PRD_ReportParty RP --right table
# MAGIC --ON RP.lPartyId = P.lPartyId
# MAGIC ON P.lPartyId = RP.lPartyId

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_legal_parent as
# MAGIC select distinct 
# MAGIC P.bActive as  le_bActive,
# MAGIC P.bCreditFileExists as  le_bCreditFileExists,
# MAGIC P.bFutureNameChange as  le_bFutureNameChange,
# MAGIC P.binTimeStamp as  le_binTimeStamp,
# MAGIC P.bIsCommonCounterparty as  le_bIsCommonCounterparty,
# MAGIC P.bIsDummyParty as  le_bIsDummyParty,
# MAGIC P.bTaxexempt as  le_bTaxexempt,
# MAGIC P.bteIsBranch as  le_bteIsBranch,
# MAGIC P.bteLifeSupport as  le_bteLifeSupport,
# MAGIC P.bTenorLimitCasebyCase as  le_bTenorLimitCasebyCase,
# MAGIC P.bteReportingDealer as  le_bteReportingDealer,
# MAGIC P.bteRiskWeightingSource as  le_bteRiskWeightingSource,
# MAGIC P.bteSolvencyInternal as  le_bteSolvencyInternal,
# MAGIC P.bWeightingLocked as  le_bWeightingLocked,
# MAGIC P.dRiskWeighting as  le_dRiskWeighting,
# MAGIC P.dteAmended as  le_dteAmended,
# MAGIC P.dteDateOfIncorporation as  le_dteDateOfIncorporation,
# MAGIC P.dteFutureNameEffectiveDate as  le_dteFutureNameEffectiveDate,
# MAGIC P.lAmendedById as  le_lAmendedById,
# MAGIC P.lApplicationUserId as  le_lApplicationUserId,
# MAGIC P.lBaseYear as  le_lBaseYear,
# MAGIC P.lCityId as  le_lCityId,
# MAGIC P.lCompositeRatingRuleId as  le_lCompositeRatingRuleId,
# MAGIC P.lCountyId as  le_lCountyId,
# MAGIC P.lFSAStatusId as  le_lFSAStatusId,
# MAGIC P.lGESLACodeId as  le_lGESLACodeId,
# MAGIC P.lICEParticipantId as  le_lICEParticipantId,
# MAGIC P.lIndustryCodeId as  le_lIndustryCodeId,
# MAGIC P.lLegalStatusId as  le_lLegalStatusId,
# MAGIC P.lLimitSourceTypeId as  le_lLimitSourceTypeId,
# MAGIC P.lMarketId as  le_lMarketId,
# MAGIC P.lOSLACodeId as  le_lOSLACodeId,
# MAGIC P.lOTCClearingId as  le_lOTCClearingId,
# MAGIC P.lPartyId as  le_lPartyId,
# MAGIC P.lPartyTypeId as  le_lPartyTypeId,
# MAGIC P.lPaymentTypeId as  le_lPaymentTypeId,
# MAGIC P.lPlaceOfIncorporationId as  le_lPlaceOfIncorporationId,
# MAGIC P.lPrimaryContactId as  le_lPrimaryContactId,
# MAGIC P.lProcessId as  le_lProcessId,
# MAGIC P.lRepoCodeId as  le_lRepoCodeId,
# MAGIC P.lRTGSSLACodeId as  le_lRTGSSLACodeId,
# MAGIC P.lServiceAgreementId as  le_lServiceAgreementId,
# MAGIC P.lTradeStatusId as  le_lTradeStatusId,
# MAGIC P.lWZ08CodeId as  le_lWZ08CodeId,
# MAGIC P.nStatus as  le_nStatus,
# MAGIC P.sAddress as  le_sAddress,
# MAGIC P.sAddressCode as  le_sAddressCode,
# MAGIC P.sAtlasLongName as  le_sAtlasLongName,
# MAGIC P.sBGAddress as  le_sBGAddress,
# MAGIC P.sBGAdvisingBank as  le_sBGAdvisingBank,
# MAGIC P.sBGContactName as  le_sBGContactName,
# MAGIC P.sBGEmail as  le_sBGEmail,
# MAGIC P.sBGFaxTelex as  le_sBGFaxTelex,
# MAGIC P.sBGIssuingBank as  le_sBGIssuingBank,
# MAGIC P.sBGOffice as  le_sBGOffice,
# MAGIC P.sBGRegNumber as  le_sBGRegNumber,
# MAGIC P.sBGTelePhone as  le_sBGTelePhone,
# MAGIC P.sCategoryCode as  le_sCategoryCode,
# MAGIC P.sContact as  le_sContact,
# MAGIC P.sDCAddress as  le_sDCAddress,
# MAGIC P.sDCAdvisingBank as  le_sDCAdvisingBank,
# MAGIC P.sDCContactName as  le_sDCContactName,
# MAGIC P.sDCEmail as  le_sDCEmail,
# MAGIC P.sDCFaxTelex as  le_sDCFaxTelex,
# MAGIC P.sDCIssuingBank as  le_sDCIssuingBank,
# MAGIC P.sDCOffice as  le_sDCOffice,
# MAGIC P.sDCRegNumber as  le_sDCRegNumber,
# MAGIC P.sDCTelePhone as  le_sDCTelePhone,
# MAGIC P.sDescription as  le_sDescription,
# MAGIC P.sEmailAddress as  le_sEmailAddress,
# MAGIC P.SExcelOutputPath as  le_SExcelOutputPath,
# MAGIC P.sExcelTemplatesPath as  le_sExcelTemplatesPath,
# MAGIC P.sFacsimile as  le_sFacsimile,
# MAGIC P.sFutureDescription as  le_sFutureDescription,
# MAGIC P.sFutureMnemonic as  le_sFutureMnemonic,
# MAGIC P.sLCAddress as  le_sLCAddress,
# MAGIC P.sLCAdvisingBank as  le_sLCAdvisingBank,
# MAGIC P.sLCContactName as  le_sLCContactName,
# MAGIC P.sLCEmail as  le_sLCEmail,
# MAGIC P.sLCFaxTelex as  le_sLCFaxTelex,
# MAGIC P.sLCIssuingBank as  le_sLCIssuingBank,
# MAGIC P.sLCOffice as  le_sLCOffice,
# MAGIC P.sLCRegNumber as  le_sLCRegNumber,
# MAGIC P.sLCSwiftCode as  le_sLCSwiftCode,
# MAGIC P.sLCTelePhone as  le_sLCTelePhone,
# MAGIC P.sMachineName as  le_sMachineName,
# MAGIC P.sMnemonic as  le_sMnemonic,
# MAGIC P.sTelephone as  le_sTelephone,
# MAGIC P.sTelex as  le_sTelex,
# MAGIC P.sURL as  le_sURL,
# MAGIC P.META_CREATED_DTTM as  le_META_CREATED_DTTM,
# MAGIC P.EFFECTIVE_START_DATE as  le_EFFECTIVE_START_DATE,
# MAGIC P.EFFECTIVE_END_DATE as  le_EFFECTIVE_END_DATE,
# MAGIC P.IS_RECORD_ACTIVE as  le_IS_RECORD_ACTIVE,
# MAGIC RP.dAssetSize as  le_rp_dAssetSize,
# MAGIC RP.dDefaultProbability as  le_rp_dDefaultProbability,
# MAGIC RP.dOverallLimit as  le_rp_dOverallLimit,
# MAGIC RP.dRecoveryRate as  le_rp_dRecoveryRate,
# MAGIC RP.dteAmended as  le_rp_dteAmended,
# MAGIC RP.dteBankruptcy as  le_rp_dteBankruptcy,
# MAGIC RP.dteEffective as  le_rp_dteEffective,
# MAGIC RP.dteExpiry as  le_rp_dteExpiry,
# MAGIC RP.dteFutureNameEffectiveDate as  le_rp_dteFutureNameEffectiveDate,
# MAGIC RP.dtePrevReview as  le_rp_dtePrevReview,
# MAGIC RP.dteReview as  le_rp_dteReview,
# MAGIC RP.lPartyId as  le_rp_lPartyId,
# MAGIC RP.sAccountStatus as  le_rp_sAccountStatus,
# MAGIC RP.sActive as  le_rp_sActive,
# MAGIC RP.sAddress as  le_rp_sAddress,
# MAGIC RP.sAddressCode as  le_rp_sAddressCode,
# MAGIC RP.sAliases as  le_rp_sAliases,
# MAGIC RP.sAmendedBy as  le_rp_sAmendedBy,
# MAGIC RP.sAssetSizeCurrency as  le_rp_sAssetSizeCurrency,
# MAGIC RP.sBankruptcy as  le_rp_sBankruptcy,
# MAGIC RP.sBlocked as  le_rp_sBlocked,
# MAGIC RP.sBuyOnly as  le_rp_sBuyOnly,
# MAGIC RP.sCity as  le_rp_sCity,
# MAGIC RP.sCompositeRating as  le_rp_sCompositeRating,
# MAGIC RP.sContact as  le_rp_sContact,
# MAGIC RP.sCountryIncorporation as  le_rp_sCountryIncorporation,
# MAGIC RP.sCountryOfRisk as  le_rp_sCountryOfRisk,
# MAGIC RP.sCreditOfficer as  le_rp_sCreditOfficer,
# MAGIC RP.sCreditOutlook as  le_rp_sCreditOutlook,
# MAGIC RP.sCreditRating as  le_rp_sCreditRating,
# MAGIC RP.sCurrency as  le_rp_sCurrency,
# MAGIC RP.sDBRSOutlook as  le_rp_sDBRSOutlook,
# MAGIC RP.sDBRSRating as  le_rp_sDBRSRating,
# MAGIC RP.sDescription as  le_rp_sDescription,
# MAGIC RP.sDomicileCountry as  le_rp_sDomicileCountry,
# MAGIC RP.sEcreditAcctNum as  le_rp_sEcreditAcctNum,
# MAGIC RP.sEmailAddress as  le_rp_sEmailAddress,
# MAGIC RP.sEntityType as  le_rp_sEntityType,
# MAGIC RP.sFacsimile as  le_rp_sFacsimile,
# MAGIC RP.sFitchOutlook as  le_rp_sFitchOutlook,
# MAGIC RP.sFitchRating as  le_rp_sFitchRating,
# MAGIC RP.sFSAStatus as  le_rp_sFSAStatus,
# MAGIC RP.sFutureDescription as  le_rp_sFutureDescription,
# MAGIC RP.sFutureMnemonic as  le_rp_sFutureMnemonic,
# MAGIC RP.sGSTExclusive as  le_rp_sGSTExclusive,
# MAGIC RP.sGuaranteeParent as  le_rp_sGuaranteeParent,
# MAGIC RP.sICEParticipant as  le_rp_sICEParticipant,
# MAGIC RP.sIndustryCode as  le_rp_sIndustryCode,
# MAGIC RP.sIndustryCodeDescription as  le_rp_sIndustryCodeDescription,
# MAGIC RP.sInternalOutlook as  le_rp_sInternalOutlook,
# MAGIC RP.sInternalRating as  le_rp_sInternalRating,
# MAGIC RP.sISCommonCounterparty as  le_rp_sISCommonCounterparty,
# MAGIC RP.sISCreditFileExists as  le_rp_sISCreditFileExists,
# MAGIC RP.sISFutureNameChange as  le_rp_sISFutureNameChange,
# MAGIC RP.sIsUltimate as  le_rp_sIsUltimate,
# MAGIC RP.sLCAddress as  le_rp_sLCAddress,
# MAGIC RP.sLCContactName as  le_rp_sLCContactName,
# MAGIC RP.sLCEmail as  le_rp_sLCEmail,
# MAGIC RP.sLCOffice as  le_rp_sLCOffice,
# MAGIC RP.sLCRegNumber as  le_rp_sLCRegNumber,
# MAGIC RP.sLCTelephone as  le_rp_sLCTelephone,
# MAGIC RP.sLegalParent as  le_rp_sLegalParent,
# MAGIC RP.sLegalStatus as  le_rp_sLegalStatus,
# MAGIC RP.sLegalUltimateParent as  le_rp_sLegalUltimateParent,
# MAGIC RP.sLimitReviewFrequency as  le_rp_sLimitReviewFrequency,
# MAGIC RP.sLimitReviewFrequencyType as  le_rp_sLimitReviewFrequencyType,
# MAGIC RP.sMarket as  le_rp_sMarket,
# MAGIC RP.sMoodyOutlook as  le_rp_sMoodyOutlook,
# MAGIC RP.sMoodyRating as  le_rp_sMoodyRating,
# MAGIC RP.sName as  le_rp_sName,
# MAGIC RP.sNarrative as  le_rp_sNarrative,
# MAGIC RP.sOTCClearance as  le_rp_sOTCClearance,
# MAGIC RP.sPartyType as  le_rp_sPartyType,
# MAGIC RP.sPrimaryAnalyst as  le_rp_sPrimaryAnalyst,
# MAGIC RP.sPrimaryContact as  le_rp_sPrimaryContact,
# MAGIC RP.sRelationshipManager as  le_rp_sRelationshipManager,
# MAGIC RP.sReverseBlocked as  le_rp_sReverseBlocked,
# MAGIC RP.sSAndPOutlook as  le_rp_sSAndPOutlook,
# MAGIC RP.sSAndPRating as  le_rp_sSAndPRating,
# MAGIC RP.sSecondaryAnalyst as  le_rp_sSecondaryAnalyst,
# MAGIC RP.sTelephone as  le_rp_sTelephone,
# MAGIC RP.sTelex as  le_rp_sTelex,
# MAGIC RP.sTradeStatus as  le_rp_sTradeStatus,
# MAGIC RP.sUltimateName as  le_rp_sUltimateName,
# MAGIC RP.sUrl as  le_rp_sUrl,
# MAGIC RP.sWatchList as  le_rp_sWatchList,
# MAGIC RP.META_CREATED_DTTM as  le_rp_META_CREATED_DTTM,
# MAGIC RP.EFFECTIVE_START_DATE as  le_rp_EFFECTIVE_START_DATE,
# MAGIC RP.EFFECTIVE_END_DATE as  le_rp_EFFECTIVE_END_DATE,
# MAGIC RP.IS_RECORD_ACTIVE as  le_rp_IS_RECORD_ACTIVE
# MAGIC from ENERGYCREDIT_PRD_Party P
# MAGIC inner join ENERGYCREDIT_PRD_ReportParty RP ON RP.lPartyId = P.lPartyId

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_le_rp as
# MAGIC Select distinct * 
# MAGIC --from vw_legal_parent lp --right table
# MAGIC --left join vw_report_party  rp --left table
# MAGIC --on rp.rp_sLegalParent = lp.le_rp_sName
# MAGIC from vw_report_party  rp   
# MAGIC left join vw_legal_parent lp
# MAGIC on rp.rp_sLegalParent = lp.le_rp_sName

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_sap_Alias as
# MAGIC --SELECT 'CUSTOMER' AS Type, A.sAlias as SAP_Account, A.lInstanceId,
# MAGIC SELECT 'CUSTOMER' AS Type, TRIM(LEADING '0' FROM A.sAlias) as SAP_Account, A.lInstanceId,
# MAGIC CASE WHEN A.laliastypeid IN (124,109) THEN 'STNSAP' WHEN A.laliastypeid = 148 THEN 'SAP_HF' END SAP_System,
# MAGIC CASE WHEN A.sAlias IS NOT NULL THEN CONCAT(CASE WHEN A.laliastypeid IN (124,109) THEN 'STNSAP' WHEN A.laliastypeid = 148 THEN 'SAP_HF' END,'_Customer_',TRIM(LEADING '0' FROM A.sAlias)) ELSE NULL END SAP_UNIQUE_ID
# MAGIC --END,'_Customer_',A.sAlias) ELSE NULL END SAP_UNIQUE_ID
# MAGIC --FROM ENERGYCREDIT_PRD_Alias A WHERE A.bActive = 1 AND A.laliastypeid IN (124,109,148)
# MAGIC FROM ENERGYCREDIT_PRD_Alias A WHERE A.laliastypeid IN (124,109,148)
# MAGIC UNION ALL
# MAGIC --SELECT 'VENDOR' AS Type, A.sAlias as SAP_Account, A.lInstanceId,
# MAGIC SELECT 'VENDOR' AS Type, TRIM(LEADING '0' FROM A.sAlias) as SAP_Account, A.lInstanceId,
# MAGIC CASE WHEN A.laliastypeid IN (124,109) THEN 'STNSAP' WHEN A.laliastypeid = 148 THEN 'SAP_HF' END SAP_System,
# MAGIC --CASE WHEN A.sAlias IS NOT NULL THEN CONCAT(CASE WHEN A.laliastypeid IN (124,109) THEN 'STNSAP' WHEN A.laliastypeid = 148 THEN 'SAP_HF' END,'_Vendor_',A.sAlias)
# MAGIC CASE WHEN A.sAlias IS NOT NULL THEN CONCAT(CASE WHEN A.laliastypeid IN (124,109) THEN 'STNSAP' WHEN A.laliastypeid = 148 THEN 'SAP_HF' END,'_Vendor_',TRIM(LEADING '0' FROM A.sAlias))ELSE NULL END SAP_UNIQUE_ID
# MAGIC --FROM ENERGYCREDIT_PRD_Alias A WHERE A.bActive = 1 AND A.laliastypeid IN (124,109,148)
# MAGIC FROM ENERGYCREDIT_PRD_Alias A WHERE A.laliastypeid IN (124,109,148)
# MAGIC --TRIM(LEADING '/' FROM Entity)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_party_sap_Alias as
# MAGIC select P.sMnemonic as sCounterParty,A.*
# MAGIC from ENERGYCREDIT_PRD_Party P
# MAGIC inner join vw_sap_Alias A on P.lPartyId = A.lInstanceId

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_lerp_sap_alias as
# MAGIC select *
# MAGIC from vw_le_rp  lerp
# MAGIC left join vw_party_sap_Alias  psa
# MAGIC on lerp.rp_sName = psa.sCounterParty

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_lerp_sap_alias_derived as
# MAGIC select 
# MAGIC distinct
# MAGIC --LE_LPARTYID,
# MAGIC --LPARTYID,
# MAGIC "ECS" as SYSTEM,
# MAGIC case when LE_LPARTYID is not null and LPARTYID is not null then  "ECS_" || LE_LPARTYID || "_" || LPARTYID 
# MAGIC      when LE_LPARTYID is not null and LPARTYID is null then "ECS_" || LE_LPARTYID 
# MAGIC      when LE_LPARTYID is null and  LPARTYID is not null then "ECS_" || LPARTYID
# MAGIC      else null
# MAGIC     --when  LE_LPARTYID is not null and  LPARTYID is not null then "ECS_" || LE_LPARTYID || "_" || LPARTYID 
# MAGIC     --else case when LE_LPARTYID is not null and LPARTYID is null then "ECS_" || LE_LPARTYID  end
# MAGIC --case when LE_LPARTYID is null then "ECS_" || LPARTYID
# MAGIC --     else "ECS_" || LE_LPARTYID-- || "_" || LPARTYID
# MAGIC  end as UNIQUE_ID,
# MAGIC  
# MAGIC -- CASE WHEN LE_LPARTYID IS NULL THEN  CONCAT('ECS_', LPARTYID) 
# MAGIC --            ELSE CONCAT('ECS_', LE_LPARTYID, '_',LPARTYID) END AS UNIQUE_ID,
# MAGIC SMNEMONIC as NAME,
# MAGIC --rp_sLegalUltimateParent as PARENT,
# MAGIC rp_sLegalParent  as PARENT,
# MAGIC --rp_sName as NAME,
# MAGIC --case when LE_LPARTYID is not null and LPARTYID is not null then SMNEMONIC when  LPARTYID is null then le_SMNEMONIC end as NAME,
# MAGIC --SMNEMONIC,
# MAGIC --rp_sName,
# MAGIC --le_SMNEMONIC,
# MAGIC lerp.rp_sPartyType as ENTITY_TYPE,
# MAGIC --bActive,
# MAGIC case when bActive = 0 then "Y" else "N" end as DEACTIVATED,
# MAGIC case when LE_LPARTYID is null then LPARTYID
# MAGIC      else LE_LPARTYID
# MAGIC end as L1_ID,
# MAGIC case when LE_LPARTYID is null then RP_SPARTYTYPE
# MAGIC      else LE_RP_SPARTYTYPE
# MAGIC end as L1_TYPE,
# MAGIC cast(lerp.dTeamended as timestamp) as CREATED_UPDATED,
# MAGIC case when LE_LPARTYID is null then null
# MAGIC      else LPARTYID
# MAGIC end as L2_ID,
# MAGIC case when LE_LPARTYID is null then null
# MAGIC      else SDESCRIPTION
# MAGIC end as L2_NAME_1,
# MAGIC case when LE_LPARTYID is null then null
# MAGIC      else RP_SPARTYTYPE
# MAGIC end as L2_TYPE,
# MAGIC lerp.rp_sDomicileCountry as COUNTRY,
# MAGIC lerp.sap_system as SAP_SYSTEM,
# MAGIC trim(SAP_UNIQUE_ID) as SAP_UNIQUE_ID,
# MAGIC lerp.Type as SAP_CPTY_TYPE,
# MAGIC trim(lerp.SAP_Account) as SAP_ACCOUNT_NUMBER,
# MAGIC lerp.sAddress as ADDRESS,
# MAGIC 'ECS' as SOURCE_SYSTEM,
# MAGIC current_timestamp as META_CREATED_DTTM
# MAGIC --case when LE_LPARTYID is null then "ECS_" || LPARTYID  else "ECS_" || LE_LPARTYID end as L1_UNIQUE_ID,
# MAGIC --case when LE_LPARTYID is null and BACTIVE = 1 then "Y" when LE_LPARTYID is null and BACTIVE = 0 then "N" else "N" end as L1_ACTIVE_IND,
# MAGIC --case when LE_LPARTYID is not null and BACTIVE = 1 then "Y" when LE_LPARTYID is not null and BACTIVE = 0 then "N" else null end as L2_ACTIVE_IND,
# MAGIC --case when LE_LPARTYID is null then SDESCRIPTION else LE_SDESCRIPTION end as L1_NAME1
# MAGIC from vw_lerp_sap_alias lerp

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_ecs_erate as
# MAGIC select P1.sMnemonic as Party_Name, CR.dteAmended as Last_Amend_Date, P2.sMnemonic as Trading_Entity, LC.sMnemonic as Limit_Category, "Y" as Erate_Flag
# MAGIC from
# MAGIC (select lCptyRestrictionEntryNo,lLimitCategoryId,lTradingEntityId from ENERGYCREDIT_PRD_RestrictionDuration where (sBuyOnly='9D' and sSellOnly='9D')) T1
# MAGIC inner join ENERGYCREDIT_PRD_CptyRestriction CR on CR.lCptyRestrictionEntryNo=T1.lCptyRestrictionEntryNo
# MAGIC inner join ENERGYCREDIT_PRD_Party P1 on P1.lpartyid=CR.lCounterPartyId
# MAGIC inner join ENERGYCREDIT_PRD_Party P2 on P2.lpartyid=T1.lTradingEntityId
# MAGIC inner join ENERGYCREDIT_PRD_LimitCategory LC on LC.lLimitCategoryId=T1.lLimitCategoryId
# MAGIC where CR.nTimeFrameId=0
# MAGIC order by P1.sMnemonic

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_energycredit_final as
# MAGIC select distinct lsad.*, 
# MAGIC case when ee.Erate_Flag = "Y" then "Y" else "N" end as Erate_Flag
# MAGIC from
# MAGIC vw_lerp_sap_alias_derived lsad
# MAGIC left join vw_ecs_erate ee
# MAGIC on lsad.name = ee.Party_Name

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_energycredit as
# MAGIC select distinct fin.* from vw_cp_master_energycredit_final fin

# COMMAND ----------

# MAGIC %sql
# MAGIC desc vw_cp_master_energycredit

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master as 
# MAGIC select distinct
# MAGIC      UNIQUE_ID          as cp_unique_id                -- req-26
# MAGIC     ,L1_ID    as cp_l1_id                    -- l1_id (req-28)
# MAGIC     ,NAME  as cp_name                     --  l1_name (req-27)
# MAGIC     ,L1_ID   as cp_etrm_account_no          --  same as l1_id for slmt
# MAGIC     ,L2_ID   as cp_l2_id                    -- l2_id (req-29)
# MAGIC     ,L2_NAME_1 as cp_l2_name                  -- l2_name (req-30)
# MAGIC     ,ENTITY_TYPE        as cp_entity_type              -- REQ-31
# MAGIC     ,CREATED_UPDATED as cp_created_or_updated_date  -- req-33/req-34
# MAGIC     ,DEACTIVATED  as cp_deactivated              -- req-32
# MAGIC     ,COUNTRY as cp_country                  -- req-91
# MAGIC     ,PARENT                as cp_parent                   -- req-87
# MAGIC     ,SOURCE_SYSTEM                as cp_system                   -- req-36 --same as "SLMT?"
# MAGIC     ,SAP_ACCOUNT_NUMBER        as cp_linked_sap_id            -- REQ-35
# MAGIC     ,SAP_CPTY_TYPE      as cp_sap_account_type         -- REQ-38
# MAGIC     ,SAP_UNIQUE_ID         as cp_sap_unique_id            -- REQ-97
# MAGIC     ,SAP_SYSTEM     as cp_linked_sap_system        -- REQ-93
# MAGIC     ,case when (SAP_UNIQUE_ID is null or length(trim(SAP_UNIQUE_ID)) = 0 ) then  'NO SAP LINK' 
# MAGIC            ELSE 'SAP LINK' 
# MAGIC      END cp_sap_link
# MAGIC     ,ERATE_FLAG as cp_erate_flag_in_source     -- REQ-9
# MAGIC     ,cast(null as string) as cp_erate_date_in_source     -- REQ-10
# MAGIC     ,cast(null as string)       as cp_erate_lifted_date_in_source  -- req-11
# MAGIC     ,cast(null as string)  as cp_broker_indicator 
# MAGIC     ,L1_ID   as cp_mapping_id   
# MAGIC     ,source_system         as source_system
# MAGIC     ,meta_created_dttm     as meta_created_dttm
# MAGIC 
# MAGIC from vw_cp_master_energycredit

# COMMAND ----------

df = spark.sql("select * from vw_cp_master")
#df.count()

# COMMAND ----------

# DBTITLE 1,salesforce table for erate logic
tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['erate_salesforce']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty as
# MAGIC Select distinct
# MAGIC   
# MAGIC   gm.cp_unique_id as cp_unique_id,
# MAGIC   cp_l1_id as cp_legal_entity_id,
# MAGIC   cp_name as cp_name,
# MAGIC   cp_l2_id as cp_business_unit_id,
# MAGIC   cp_l2_name as cp_business_unit_name,
# MAGIC   cast(null as string) as cp_short_name,
# MAGIC   cp_created_or_updated_date as cp_created_date,
# MAGIC   cp_created_or_updated_date as cp_updated_date,
# MAGIC   cp_deactivated  as cp_deactivated,
# MAGIC   cp_erate_flag_in_source   as cp_erate_flag_source,
# MAGIC   cast(null as timestamp)   as cp_erate_date_source,
# MAGIC   coalesce(cp_erate_flag_in_source,'N')   as cp_erate_flag,
# MAGIC   case when cp_erate_flag_in_source = 'Y' then to_date(er.erate_completion_date, 'yyyy-MM-dd') else null end as cp_erate_date,
# MAGIC   cp_etrm_account_no as cp_account_number,
# MAGIC   cp_mapping_id as cp_deal_mapping_id,
# MAGIC   current_timestamp as meta_created_ddtm,
# MAGIC   current_timestamp as meta_start_ddtm,
# MAGIC   to_date('2999-12-31', 'yyyy-MM-dd') as meta_end_ddtm,
# MAGIC   'Y' as active_indicator,
# MAGIC   'ENERGY_CREDIT' as source_system_code,
# MAGIC   date_format(current_date, 'yyyyMMdd') as  report_date_key
# MAGIC  
# MAGIC FROM
# MAGIC   vw_cp_master gm 
# MAGIC   left join vw_cp_data_hub_erate_salesforce   er   on (gm.cp_unique_id = er.cp_unique_id and er.source_system ='ECS')

# COMMAND ----------

cp_df = spark.sql("select * from vw_counterparty")
cp_df = cp_df.drop_duplicates()
total_row_cnt = cp_df.count()
print (total_row_cnt)
cp_unique_id_df = cp_df.select(["cp_unique_id"])
cp_unique_id_df = cp_unique_id_df.drop_duplicates()
cp_unique_id_cnt= cp_unique_id_df.count()
print(cp_unique_id_cnt)
try:
  if total_row_cnt == cp_unique_id_cnt:
    RefreshCuratedSqlTbl('staging', 'counterparty', 'ENERGY_CREDIT')
except Exception as e:
  print("For ENERGY_CREDIT source system counterparty count vs unique_id cnt didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty', 'cp_data_hub', 'counterparty', 'ENERGY_CREDIT')

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['counterparty']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

cp_details_df = spark.sql("""
                          select distinct
                             gm.cp_unique_id               as cp_unique_id
                            ,cast(NULL as string)          as cp_company_code
                            ,cast(NULL as string)          as cp_company_name
                            ,cast(NULL as string)          as cp_country_code
                            ,gm.cp_country                 as cp_country_name
                            ,gm.cp_entity_type             as counterparty_type
                            ,current_timestamp               as meta_created_ddtm
                            ,current_timestamp               as meta_start_ddtm
                            ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                            ,'Y'                                   as active_indicator
                            ,'ENERGY_CREDIT'                         as source_system_code
                            ,date_format(current_date, 'yyyyMMdd') as  report_date_key
                           from vw_cp_master  gm
                           where gm.cp_country is not null
                           and length(gm.cp_country)>0
                          """)
#creating temp view
cp_details_df.createOrReplaceTempView("vw_counterparty_details")

# need to get the distinct unique_id counts
cp_details_cp_unique_id_cnt = cp_details_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_counterparty_details cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)                               
#load process
try:
  if cp_unique_id_cnt >= cp_details_cp_unique_id_cnt and cp_unique_id_not_in_cp_df.count()==0:
    print(f"""Count Match: {cp_unique_id_cnt} and {cp_details_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of counterparty_details is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'counterparty_details', 'ENERGY_CREDIT')
except Exception as e:
  print("For ENERGY_CREDIT source system counterparty count and counterparty Details unique_id didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details', 'cp_data_hub', 'counterparty_details', 'ENERGY_CREDIT')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details_summary as
# MAGIC   
# MAGIC 			select cpd.source_system_code
# MAGIC 			      ,cpd.cp_unique_id
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(counterparty_type))) as counterparty_type
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_code))) as cp_company_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_name))) as cp_company_name
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_code))) as cp_country_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_name))) as cp_country_name
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 				  from vw_counterparty_details cpd
# MAGIC 				  where cpd.source_system_code in ('ENERGY_CREDIT')
# MAGIC 			group by cpd.source_system_code, cpd.cp_unique_id
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details_summary', 'ENERGY_CREDIT')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details_summary', 'cp_data_hub', 'counterparty_details_summary', 'ENERGY_CREDIT')

# COMMAND ----------

bdg_cp_sap_account_df = spark.sql("""
                                 select distinct 
                                    gm.cp_unique_id               as cp_unique_id
                                   ,gm.cp_sap_unique_id              as sap_unique_id
                                   ,gm.cp_linked_sap_id             as sap_account_number
                                   ,gm.cp_sap_account_type           as sap_account_type
                                   ,gm.cp_linked_sap_system          as sap_source_system_code
                                   ,current_timestamp               as meta_created_ddtm
                                   ,current_timestamp               as meta_start_ddtm
                                   ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                                   ,'Y'                                   as active_indicator
                                   ,'ENERGY_CREDIT'                          as source_system_code
                                   ,date_format(current_date, 'yyyyMMdd') as  report_date_key 
                                from vw_cp_master gm
                                where gm.cp_sap_unique_id is not null and length(gm.cp_sap_unique_id) > 0
                                """)
#creating temp view
bdg_cp_sap_account_df.createOrReplaceTempView("vw_bridge_counterparty_sap_account")

# need to get the distinct unique_id counts
bdg_cp_sap_account_cp_unique_id_cnt = bdg_cp_sap_account_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
bdg_cp_sap_account_cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_bridge_counterparty_sap_account cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)
                                       
#load process
if cp_unique_id_cnt >= bdg_cp_sap_account_cp_unique_id_cnt and bdg_cp_sap_account_cp_unique_id_not_in_cp_df.count()==0:
  try:
  
    print(f"""Count Match: {cp_unique_id_cnt} and {bdg_cp_sap_account_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of bridge_counterparty_sap_account is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'bridge_counterparty_sap_account', 'ENERGY_CREDIT')
  
  except Exception as e:
    print("For ENERGY_CREDIT source system counterparty count and bridge_counterparty_sap_accnt cp_unique_id didn't match")
    raise dbutils.notebook.exit(e)
elif {cp_unique_id_cnt} < {bdg_cp_sap_account_cp_unique_id_cnt}: 
  print(f"""counterparty: {cp_unique_id_cnt}""")
  print(f"""bridge_counterparty_sap_account: {bdg_cp_sap_account_cp_unique_id_cnt}""")
  print("Count match is not working ")
else:
  print(f"""cp_unique_id exists in bridge counterparty sap account table but in counterparty table""")

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'bridge_counterparty_sap_account', 'cp_data_hub', 'bridge_counterparty_sap_account', 'ENERGY_CREDIT')

# COMMAND ----------

Source_System_Code = 'ENERGY_CREDIT'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
