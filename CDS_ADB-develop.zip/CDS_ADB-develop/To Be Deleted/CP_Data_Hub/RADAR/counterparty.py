# Databricks notebook source
from pyspark.sql.types import TimestampType, StringType

# COMMAND ----------

# MAGIC %sql 
# MAGIC CLEAR CACHE

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

create_temp_views_per_source_system('RADAR', 'RADAR')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_customer_contact as   --Logic to get customer contact details
# MAGIC select customer_code, max(address_line_1) as address_line_1, 
# MAGIC max(address_line_2) as address_line_2, max(address_line_3) as address_line_3, 
# MAGIC max(address_line_4) as address_line_4, max(postal_town) as postal_town, 
# MAGIC max(county_state) as county_state, max(post_zip_code) as post_zip_code, 
# MAGIC max(address_line_5) as address_line_5, max(cntry_mnem) as cntry_mnem
# MAGIC from radar_customer_contact
# MAGIC where contact_last_name = 'HEAD OFFICE'
# MAGIC group by customer_code

# COMMAND ----------

df = spark.sql("select * from vw_customer_contact")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_tsap_code as   --Logic to get TSAP value, TSAP logic and join to be uncommented once Magellan data is available 
# MAGIC select distinct cvc.customer_code, cvc.customer_vendor_ind, 
# MAGIC null as TSAP
# MAGIC /*
# MAGIC case when cvc.customer_vendor_ind = 'C' then
# MAGIC   case when magl.kunnr is null then magl.magellan_sap_vendor_code else magl.kunnr end
# MAGIC when cvc.customer_vendor_ind = 'V' then
# MAGIC   case when magl.lifnr is null then magl.magellan_sap_vendor_code else magl.lifnr end
# MAGIC else null
# MAGIC end as TSAP*/
# MAGIC from radar_customer_vendor_code cvc
# MAGIC /*left outer join 
# MAGIC radar_tsap_zst_fi_magl magl --Magellan dataset to be taken once available
# MAGIC on cvc.customer_code = magl.customer_code
# MAGIC and cvc.vendor_seq_num = magl.vendor_seq_num*/

# COMMAND ----------

df = spark.sql("select * from vw_tsap_code")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_sap_vendor as       --Logic for scenario where SAP Vendor ID exists
# MAGIC SELECT distinct
# MAGIC        'RADAR' as SYSTEM,
# MAGIC        concat('RADAR',
# MAGIC        (case when c.customer_code is null then '' else concat('_',cast(c.customer_code as int)) end),
# MAGIC        (case when cvc.vendor_seq_num is null then '' else concat('_',cast(cvc.vendor_seq_num as int)) end)
# MAGIC        ) as UNIQUE_ID,
# MAGIC        c.business_name as NAME,
# MAGIC        c.customer_type as ENTITY_TYPE,
# MAGIC        --c.active_ind as DEACTIVATED,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DEACTIVATED,
# MAGIC        c.customer_code as L1_ID,
# MAGIC        c.customer_type as L1_TYPE,
# MAGIC        c.created_tstmp as CREATED_UPDATED,
# MAGIC        c.owning_customer_code as PARENT,
# MAGIC        cvc.vendor_seq_num as L2_ID,
# MAGIC        cvc.magellan_company_name as L2_NAME1,
# MAGIC        cvc.customer_vendor_ind as L2_TYPE,
# MAGIC        case when cc.cntry_mnem is null 
# MAGIC          then c.cntry_of_operation_mnem 
# MAGIC          else cc.cntry_mnem 
# MAGIC        end as COUNTRY,
# MAGIC        'STNSAP' as SAP_SYSTEM,      
# MAGIC        ltrim('0',trim(c.sap_vendor_code)) as SAP_ACCOUNT_NO,
# MAGIC        concat(
# MAGIC        (case when address_line_1 is null then '' else concat(address_line_1,' ') end),
# MAGIC        (case when address_line_2 is null then '' else concat(address_line_2,' ') end),
# MAGIC        (case when address_line_3 is null then '' else concat(address_line_3,' ') end),
# MAGIC        (case when address_line_4 is null then '' else address_line_4 end)
# MAGIC        ) as ADDRESS,
# MAGIC        c.sap_vendor_code as SAP_VENDOR_CODE,
# MAGIC        cvc.stn_sap_vendor_code AS STN_SAP_VENDOR_CODE,
# MAGIC        erated_ind as ERATE_FLAG,
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as ACTIVITY_ID,
# MAGIC        --tsap_cd.TSAP as TSAP,
# MAGIC        cvc.magellan_sap_vendor_code as TSAP, --Taken as per the change in logic to get TSAP values from Radar table instead of SAP Tables
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as L1_UNIQUE_ID,
# MAGIC        c.business_name as L1_LONG_NAME,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DELETED,
# MAGIC        case when cc.postal_town is null then cvc.city_txt else cc.postal_town end as CITY,
# MAGIC        case when cc.county_state is null then cvc.region_txt else cc.county_state end as STATE,
# MAGIC        case when cc.post_zip_code is null then cvc.postal_code_txt else cc.post_zip_code end as POSTCODE,
# MAGIC        c.customer_code as ACCOUNT_NO,
# MAGIC        cc.address_line_5 as ADDRESS_LINE_5,
# MAGIC        c.LAST_UPDATE_TSTMP as CUSTOMER_LAST_UPDATE_TSTMP,
# MAGIC        c.active_ind as L1_ACTIVE_IND,
# MAGIC        c.META_CREATED_DTTM as META_CREATED_DTTM,      
# MAGIC        case when cast(Substring(trim(c.sap_vendor_code),0,1) as double) is not null 
# MAGIC          then lpad(trim(c.sap_vendor_code), 10,'0')  
# MAGIC          else trim(c.sap_vendor_code)
# MAGIC        end as SAP_ACCOUNT,
# MAGIC        'L1' as SAP_LINK_LEVEL
# MAGIC FROM
# MAGIC radar_customer c
# MAGIC left outer join radar_customer_vendor_code cvc on c.customer_code = cvc.customer_code
# MAGIC left outer join vw_customer_contact cc on c.customer_code = cc.customer_code
# MAGIC --left outer join vw_tsap_code tsap_cd on c.customer_code = tsap_cd.customer_code  --taking data from Radar table as of now instead of SAP Table
# MAGIC where c.sap_vendor_code is not null and length(ltrim('0',trim(c.sap_vendor_code))) != 0 

# COMMAND ----------

df = spark.sql("select * from vw_sap_vendor")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_sap as  --To get same records twice one for Vendor and other for Customer
# MAGIC select *, concat('STNSAP_Customer_',SAP_ACCOUNT_NO) as SAP_UNIQUE_ID,
# MAGIC        'CUSTOMER' as SAP_CPTY_TYPE,
# MAGIC        'CUSTOMER' as VENDOR_CUSTOMER
# MAGIC from vw_sap_vendor
# MAGIC union
# MAGIC select *, concat('STNSAP_Vendor_',SAP_ACCOUNT_NO) as SAP_UNIQUE_ID,
# MAGIC        'VENDOR' as SAP_CPTY_TYPE,
# MAGIC        'VENDOR' as VENDOR_CUSTOMER
# MAGIC from vw_sap_vendor

# COMMAND ----------

df = spark.sql("select * from vw_sap")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_stn_sap_vendor as   --Logic for scenario where L2_ID and STN SAP Vendor ID exists
# MAGIC SELECT distinct 
# MAGIC        'RADAR' as SYSTEM,
# MAGIC        concat('RADAR',
# MAGIC        (case when c.customer_code is null then '' else concat('_',cast(c.customer_code as int)) end),
# MAGIC        (case when cvc.vendor_seq_num is null then '' else concat('_',cast(cvc.vendor_seq_num as int)) end)
# MAGIC        ) as UNIQUE_ID,
# MAGIC        c.business_name as NAME,
# MAGIC        c.customer_type as ENTITY_TYPE,
# MAGIC        --c.active_ind as DEACTIVATED,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DEACTIVATED,
# MAGIC        c.customer_code as L1_ID,
# MAGIC        c.customer_type as L1_TYPE,
# MAGIC        c.created_tstmp as CREATED_UPDATED,
# MAGIC        c.owning_customer_code as PARENT,
# MAGIC        cvc.vendor_seq_num as L2_ID,
# MAGIC        cvc.magellan_company_name as L2_NAME1,
# MAGIC        cvc.customer_vendor_ind as L2_TYPE,
# MAGIC        case when cc.cntry_mnem is null 
# MAGIC          then c.cntry_of_operation_mnem 
# MAGIC          else cc.cntry_mnem 
# MAGIC        end as COUNTRY,
# MAGIC        'STNSAP' as SAP_SYSTEM,       
# MAGIC        ltrim('0',trim(cvc.stn_sap_vendor_code)) as SAP_ACCOUNT_NO,
# MAGIC        concat(
# MAGIC        (case when address_line_1 is null then '' else concat(address_line_1,' ') end),
# MAGIC        (case when address_line_2 is null then '' else concat(address_line_2,' ') end),
# MAGIC        (case when address_line_3 is null then '' else concat(address_line_3,' ') end),
# MAGIC        (case when address_line_4 is null then '' else address_line_4 end)
# MAGIC        ) as ADDRESS,
# MAGIC        c.sap_vendor_code as SAP_VENDOR_CODE,
# MAGIC        cvc.stn_sap_vendor_code AS STN_SAP_VENDOR_CODE,
# MAGIC        erated_ind as ERATE_FLAG,
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as ACTIVITY_ID,
# MAGIC        --tsap_cd.TSAP as TSAP,
# MAGIC        cvc.magellan_sap_vendor_code as TSAP, --Taken as per the change in logic to get TSAP values from Radar table instead of SAP Tables
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as L1_UNIQUE_ID,
# MAGIC        c.business_name as L1_LONG_NAME,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DELETED,
# MAGIC        case when cc.postal_town is null then cvc.city_txt else cc.postal_town end as CITY,
# MAGIC        case when cc.county_state is null then cvc.region_txt else cc.county_state end as STATE,
# MAGIC        case when cc.post_zip_code is null then cvc.postal_code_txt else cc.post_zip_code end as POSTCODE,
# MAGIC        c.customer_code as ACCOUNT_NO,
# MAGIC        cc.address_line_5 as ADDRESS_LINE_5,
# MAGIC        c.LAST_UPDATE_TSTMP as CUSTOMER_LAST_UPDATE_TSTMP,
# MAGIC        c.active_ind as L1_ACTIVE_IND,
# MAGIC        c.META_CREATED_DTTM as META_CREATED_DTTM,       
# MAGIC        case when cast(Substring(trim(cvc.stn_sap_vendor_code),0,1) as double) is not null 
# MAGIC          then lpad(trim(cvc.stn_sap_vendor_code), 10,'0')  
# MAGIC          else trim(cvc.stn_sap_vendor_code)
# MAGIC        end as SAP_ACCOUNT,
# MAGIC        'L2' as SAP_LINK_LEVEL
# MAGIC FROM
# MAGIC radar_customer c
# MAGIC left OUTER JOIN radar_customer_vendor_code cvc on c.customer_code = cvc.customer_code
# MAGIC left OUTER JOIN vw_customer_contact cc on c.customer_code = cc.customer_code
# MAGIC --left outer join vw_tsap_code tsap_cd on c.customer_code = tsap_cd.customer_code  --taking data from Radar table as of now instead of SAP Table
# MAGIC where cvc.vendor_seq_num is not null and cvc.stn_sap_vendor_code is not null and length(ltrim('0',trim(cvc.stn_sap_vendor_code))) != 0 

# COMMAND ----------

df = spark.sql("select * from vw_stn_sap_vendor")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_stn_sap as   --To get same records twice one for Vendor and other for Customer
# MAGIC select *, concat('STNSAP_Customer_',SAP_ACCOUNT_NO) as SAP_UNIQUE_ID,
# MAGIC        'CUSTOMER' as SAP_CPTY_TYPE,
# MAGIC        'CUSTOMER' as VENDOR_CUSTOMER
# MAGIC from vw_stn_sap_vendor
# MAGIC union
# MAGIC select *, concat('STNSAP_Vendor_',SAP_ACCOUNT_NO) as SAP_UNIQUE_ID,
# MAGIC        'VENDOR' as SAP_CPTY_TYPE,
# MAGIC        'VENDOR' as VENDOR_CUSTOMER
# MAGIC from vw_stn_sap_vendor

# COMMAND ----------

df = spark.sql("select * from vw_stn_sap")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_tsap as    --Logic for scenario where TSAP ID exists, TSAP values taken from Radar table instead of SAP table
# MAGIC SELECT distinct
# MAGIC        'RADAR' as SYSTEM,
# MAGIC        concat('RADAR',
# MAGIC        (case when c.customer_code is null then '' else concat('_',cast(c.customer_code as int)) end),
# MAGIC        (case when cvc.vendor_seq_num is null then '' else concat('_',cast(cvc.vendor_seq_num as int)) end)
# MAGIC        ) as UNIQUE_ID,
# MAGIC        c.business_name as NAME,
# MAGIC        c.customer_type as ENTITY_TYPE,
# MAGIC        --c.active_ind as DEACTIVATED,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DEACTIVATED,
# MAGIC        c.customer_code as L1_ID,
# MAGIC        c.customer_type as L1_TYPE,
# MAGIC        c.created_tstmp as CREATED_UPDATED,
# MAGIC        c.owning_customer_code as PARENT,
# MAGIC        cvc.vendor_seq_num as L2_ID,
# MAGIC        cvc.magellan_company_name as L2_NAME1,
# MAGIC        cvc.customer_vendor_ind as L2_TYPE,
# MAGIC        case when cc.cntry_mnem is null 
# MAGIC          then c.cntry_of_operation_mnem 
# MAGIC          else cc.cntry_mnem 
# MAGIC        end as COUNTRY,
# MAGIC        'TSAP' as SAP_SYSTEM,
# MAGIC        ltrim('0',trim(cvc.magellan_sap_vendor_code)) as SAP_ACCOUNT_NO,
# MAGIC        concat(
# MAGIC        (case when address_line_1 is null then '' else concat(address_line_1,' ') end),
# MAGIC        (case when address_line_2 is null then '' else concat(address_line_2,' ') end),
# MAGIC        (case when address_line_3 is null then '' else concat(address_line_3,' ') end),
# MAGIC        (case when address_line_4 is null then '' else address_line_4 end)
# MAGIC        ) as ADDRESS,
# MAGIC        c.sap_vendor_code as SAP_VENDOR_CODE,
# MAGIC        cvc.stn_sap_vendor_code AS STN_SAP_VENDOR_CODE,
# MAGIC        erated_ind as ERATE_FLAG,
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as ACTIVITY_ID,
# MAGIC        --tsap_cd.TSAP as TSAP,
# MAGIC        cvc.magellan_sap_vendor_code as TSAP,
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as L1_UNIQUE_ID,
# MAGIC        c.business_name as L1_LONG_NAME,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DELETED,
# MAGIC        case when cc.postal_town is null then cvc.city_txt else cc.postal_town end as CITY,
# MAGIC        case when cc.county_state is null then cvc.region_txt else cc.county_state end as STATE,
# MAGIC        case when cc.post_zip_code is null then cvc.postal_code_txt else cc.post_zip_code end as POSTCODE,
# MAGIC        c.customer_code as ACCOUNT_NO,
# MAGIC        cc.address_line_5 as ADDRESS_LINE_5,
# MAGIC        c.LAST_UPDATE_TSTMP as CUSTOMER_LAST_UPDATE_TSTMP,
# MAGIC        c.active_ind as L1_ACTIVE_IND,
# MAGIC        c.META_CREATED_DTTM as META_CREATED_DTTM,
# MAGIC        case when cast(Substring(trim(cvc.magellan_sap_vendor_code),0,1) as double) is not null 
# MAGIC          then lpad(trim(cvc.magellan_sap_vendor_code), 10,'0')  
# MAGIC          else trim(cvc.magellan_sap_vendor_code)
# MAGIC        end as SAP_ACCOUNT,
# MAGIC        'L2' as SAP_LINK_LEVEL,
# MAGIC        concat('TSAP_',
# MAGIC        (case when cvc.customer_vendor_ind = 'C' then 'Customer_' else 'Vendor_' end),
# MAGIC        ltrim('0',trim(cvc.magellan_sap_vendor_code))) as SAP_UNIQUE_ID,
# MAGIC        case when cvc.customer_vendor_ind = 'C' then 'CUSTOMER' else 'VENDOR' end as SAP_CPTY_TYPE,
# MAGIC        case when cvc.customer_vendor_ind = 'C' then 'CUSTOMER' else 'VENDOR' end as VENDOR_CUSTOMER
# MAGIC FROM
# MAGIC radar_customer c
# MAGIC left OUTER JOIN radar_customer_vendor_code cvc on c.customer_code = cvc.customer_code
# MAGIC left OUTER JOIN vw_customer_contact cc on c.customer_code = cc.customer_code
# MAGIC --left outer join vw_tsap_code tsap_cd on c.customer_code = tsap_cd.customer_code
# MAGIC where cvc.vendor_seq_num is not null and cvc.magellan_sap_vendor_code is not null and length(ltrim('0',trim(cvc.magellan_sap_vendor_code))) != 0 

# COMMAND ----------

df = spark.sql("select * from vw_tsap")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_no_sap_code as    --Logic for scenario where no SAP code exists
# MAGIC SELECT distinct
# MAGIC        'RADAR' as SYSTEM,
# MAGIC        concat('RADAR',
# MAGIC        (case when c.customer_code is null then '' else concat('_',cast(c.customer_code as int)) end),
# MAGIC        (case when cvc.vendor_seq_num is null then '' else concat('_',cast(cvc.vendor_seq_num as int)) end)
# MAGIC        ) as UNIQUE_ID,
# MAGIC        c.business_name as NAME,
# MAGIC        c.customer_type as ENTITY_TYPE,
# MAGIC        --c.active_ind as DEACTIVATED,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DEACTIVATED,
# MAGIC        c.customer_code as L1_ID,
# MAGIC        c.customer_type as L1_TYPE,
# MAGIC        c.created_tstmp as CREATED_UPDATED,
# MAGIC        c.owning_customer_code as PARENT,
# MAGIC        cvc.vendor_seq_num as L2_ID,
# MAGIC        cvc.magellan_company_name as L2_NAME1,
# MAGIC        cvc.customer_vendor_ind as L2_TYPE,
# MAGIC        case when cc.cntry_mnem is null 
# MAGIC          then c.cntry_of_operation_mnem 
# MAGIC          else cc.cntry_mnem 
# MAGIC        end as COUNTRY,
# MAGIC        null as SAP_SYSTEM,
# MAGIC        null as SAP_ACCOUNT_NO,
# MAGIC        concat(
# MAGIC        (case when address_line_1 is null then '' else concat(address_line_1,' ') end),
# MAGIC        (case when address_line_2 is null then '' else concat(address_line_2,' ') end),
# MAGIC        (case when address_line_3 is null then '' else concat(address_line_3,' ') end),
# MAGIC        (case when address_line_4 is null then '' else address_line_4 end)
# MAGIC        ) as ADDRESS,
# MAGIC        c.sap_vendor_code as SAP_VENDOR_CODE,
# MAGIC        cvc.stn_sap_vendor_code AS STN_SAP_VENDOR_CODE,
# MAGIC        erated_ind as ERATE_FLAG,
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as ACTIVITY_ID,
# MAGIC        --tsap_cd.TSAP as TSAP,
# MAGIC        cvc.magellan_sap_vendor_code as TSAP, --Taken as per the change in logic to get TSAP values from Radar table instead of SAP Tables
# MAGIC        concat('RADAR_',cast(c.customer_code as int)) as L1_UNIQUE_ID,
# MAGIC        c.business_name as L1_LONG_NAME,
# MAGIC        case when c.active_ind = 'Y' then 'N' else 'Y' end as DELETED,
# MAGIC        case when cc.postal_town is null then cvc.city_txt else cc.postal_town end as CITY,
# MAGIC        case when cc.county_state is null then cvc.region_txt else cc.county_state end as STATE,
# MAGIC        case when cc.post_zip_code is null then cvc.postal_code_txt else cc.post_zip_code end as POSTCODE,
# MAGIC        c.customer_code as ACCOUNT_NO,
# MAGIC        cc.address_line_5 as ADDRESS_LINE_5,
# MAGIC        c.LAST_UPDATE_TSTMP as CUSTOMER_LAST_UPDATE_TSTMP,
# MAGIC        c.active_ind as L1_ACTIVE_IND,
# MAGIC        c.META_CREATED_DTTM as META_CREATED_DTTM,
# MAGIC        null as SAP_ACCOUNT,
# MAGIC        'L2' as SAP_LINK_LEVEL,
# MAGIC        null as SAP_UNIQUE_ID,
# MAGIC        null as SAP_CPTY_TYPE,
# MAGIC        null as VENDOR_CUSTOMER
# MAGIC FROM
# MAGIC radar_customer c
# MAGIC left OUTER JOIN radar_customer_vendor_code cvc on c.customer_code = cvc.customer_code
# MAGIC left OUTER JOIN vw_customer_contact cc on c.customer_code = cc.customer_code
# MAGIC --left outer join vw_tsap_code tsap_cd on c.customer_code = tsap_cd.customer_code  --taking data from Radar table as of now instead of SAP Table
# MAGIC where (c.sap_vendor_code is null or length(ltrim('0',trim(c.sap_vendor_code))) = 0 ) and 
# MAGIC (cvc.stn_sap_vendor_code is null or length(ltrim('0',trim(cvc.stn_sap_vendor_code))) = 0) and 
# MAGIC --(tsap_cd.TSAP is  null or length(ltrim('0',trim(tsap_cd.TSAP))) = 0)
# MAGIC (cvc.magellan_sap_vendor_code is null or length(ltrim('0',trim(cvc.magellan_sap_vendor_code))) = 0)

# COMMAND ----------

df = spark.sql("select * from vw_no_sap_code")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_radar_union as
# MAGIC select * from vw_sap
# MAGIC union
# MAGIC select * from vw_stn_sap
# MAGIC union
# MAGIC select * from vw_tsap
# MAGIC union
# MAGIC select * from vw_no_sap_code

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_radar_union")
df.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_radar as
# MAGIC select
# MAGIC   SYSTEM,
# MAGIC   UNIQUE_ID,
# MAGIC   NAME,
# MAGIC   ENTITY_TYPE,
# MAGIC   DEACTIVATED,
# MAGIC   L1_ID,
# MAGIC   L1_TYPE,
# MAGIC   cast(CREATED_UPDATED as timestamp) as CREATED_UPDATED,
# MAGIC   PARENT,
# MAGIC   L2_ID,
# MAGIC   L2_NAME1,
# MAGIC   L2_TYPE,
# MAGIC   COUNTRY,
# MAGIC   SAP_SYSTEM,
# MAGIC   SAP_UNIQUE_ID,
# MAGIC   SAP_CPTY_TYPE,
# MAGIC   SAP_ACCOUNT_NO,
# MAGIC   ADDRESS,
# MAGIC   SAP_VENDOR_CODE,
# MAGIC   STN_SAP_VENDOR_CODE,
# MAGIC   ERATE_FLAG,
# MAGIC   ACTIVITY_ID,
# MAGIC   cast(TSAP as string) as TSAP,
# MAGIC   L1_UNIQUE_ID,
# MAGIC   L1_LONG_NAME,
# MAGIC   DELETED,
# MAGIC   CITY,
# MAGIC   STATE,
# MAGIC   POSTCODE,
# MAGIC   ACCOUNT_NO,
# MAGIC   ADDRESS_LINE_5,
# MAGIC   cast(CUSTOMER_LAST_UPDATE_TSTMP as timestamp) as CUSTOMER_LAST_UPDATE_TSTMP,
# MAGIC   L1_ACTIVE_IND,
# MAGIC   cast(META_CREATED_DTTM as timestamp) as META_CREATED_DTTM,
# MAGIC   VENDOR_CUSTOMER,
# MAGIC   SAP_ACCOUNT,
# MAGIC   SAP_LINK_LEVEL,
# MAGIC   'RADAR' as SOURCE_SYSTEM
# MAGIC from vw_cp_master_radar_union

# COMMAND ----------

df = spark.sql("select * from vw_cp_master_radar")
df.count()

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['erate_salesforce']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty as 
# MAGIC select distinct 
# MAGIC      UNIQUE_ID                               as cp_unique_id                      --REQ-26
# MAGIC     ,L1_ID                                  as cp_legal_entity_id                          --REQ-28
# MAGIC     ,NAME                                   as cp_name                           --REQ-27
# MAGIC     ,L2_ID                                  as cp_business_unit_id                          --REQ-29
# MAGIC     ,L2_NAME1                               as cp_business_unit_name                        --REQ-30  
# MAGIC     ,cast(null as string)                   as cp_short_name
# MAGIC     ,CREATED_UPDATED                        as cp_created_date
# MAGIC     ,CUSTOMER_LAST_UPDATE_TSTMP             as cp_updated_date    
# MAGIC     ,DEACTIVATED                            as cp_deactivated                    --REQ-32
# MAGIC     ,k.ERATE_FLAG                           as cp_erate_flag_source           --REQ-9
# MAGIC     ,cast(null as timestamp)                as cp_erate_date_source           --REQ-10
# MAGIC     ,k.ERATE_FLAG                            as cp_erate_flag
# MAGIC     ,case when k.ERATE_FLAG = 'Y' then to_date(er.erate_completion_date, 'yyyy-MM-dd') else null end as cp_erate_date  
# MAGIC     ,L1_ID                                  as cp_account_number   
# MAGIC     ,L1_ID                                  as cp_deal_mapping_id
# MAGIC     ,current_timestamp                      as meta_created_ddtm
# MAGIC     ,current_timestamp                      as meta_start_ddtm
# MAGIC     , to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
# MAGIC     ,'Y'                                    as active_indicator
# MAGIC     ,'RADAR'                               as source_system_code
# MAGIC     ,date_format(current_date, 'yyyyMMdd')  as report_date_key    
# MAGIC from vw_cp_master_radar k
# MAGIC left join vw_cp_data_hub_erate_salesforce   er   on (k.UNIQUE_ID = er.cp_unique_id and er.source_system ='RADAR')

# COMMAND ----------

cp_df = spark.sql("select * from vw_counterparty")
cp_df = cp_df.drop_duplicates()
total_row_cnt = cp_df.count()
print (total_row_cnt)
cp_unique_id_df = cp_df.select(["cp_unique_id"])
cp_unique_id_df = cp_unique_id_df.drop_duplicates()
cp_unique_id_cnt= cp_unique_id_df.count()
print(cp_unique_id_cnt)
try:
  if total_row_cnt == cp_unique_id_cnt:
    RefreshCuratedSqlTbl('staging', 'counterparty', 'RADAR')
except Exception as e:
  print("For RADAR source system counterparty count vs unique_id cnt didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty', 'cp_data_hub', 'counterparty', 'RADAR')

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['counterparty']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

cp_details_df = spark.sql("""
                          select distinct
                             rad.UNIQUE_ID               as cp_unique_id
                            ,cast(NULL as string)          as cp_company_code
                            ,cast(NULL as string)          as cp_company_name
                            ,cast(NULL as string)          as cp_country_code
                            ,rad.COUNTRY                    as cp_country_name
                            ,rad.ENTITY_TYPE             as counterparty_type
                            ,current_timestamp               as meta_created_ddtm
                            ,current_timestamp               as meta_start_ddtm
                            ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                            ,'Y'                                   as active_indicator
                            ,'RADAR'                         as source_system_code
                            ,date_format(current_date, 'yyyyMMdd') as  report_date_key
                           from vw_cp_master_radar  rad
                           where rad.COUNTRY is not null
                           and length(rad.COUNTRY)>0
                          """)
#creating temp view
cp_details_df.createOrReplaceTempView("vw_counterparty_details")

# need to get the distinct unique_id counts
cp_details_cp_unique_id_cnt = cp_details_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_counterparty_details cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)                               
#load process
try:
  if cp_unique_id_cnt >= cp_details_cp_unique_id_cnt and cp_unique_id_not_in_cp_df.count()==0:
    print(f"""Count Match: {cp_unique_id_cnt} and {cp_details_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of counterparty_details is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'counterparty_details', 'RADAR')
except Exception as e:
  print("For RADAR source system counterparty count and counterparty Details unique_id didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details', 'cp_data_hub', 'counterparty_details', 'RADAR')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details_summary as
# MAGIC   
# MAGIC 			select cpd.source_system_code
# MAGIC 			      ,cpd.cp_unique_id
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(counterparty_type))) as counterparty_type
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_code))) as cp_company_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_name))) as cp_company_name
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_code))) as cp_country_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_name))) as cp_country_name
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 				  from vw_counterparty_details cpd
# MAGIC 				  where cpd.source_system_code in ('RADAR')
# MAGIC 			group by cpd.source_system_code, cpd.cp_unique_id
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details_summary', 'RADAR')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details_summary', 'cp_data_hub', 'counterparty_details_summary', 'RADAR')

# COMMAND ----------

bdg_cp_sap_account_df = spark.sql("""
                                 select distinct 
                                    rad.UNIQUE_ID               as cp_unique_id
                                   ,rad.SAP_UNIQUE_ID              as sap_unique_id
                                   ,rad.SAP_VENDOR_CODE             as sap_account_number
                                   ,rad.VENDOR_CUSTOMER           as sap_account_type
                                   ,rad.SAP_SYSTEM          as sap_source_system_code
                                   ,current_timestamp               as meta_created_ddtm
                                   ,current_timestamp               as meta_start_ddtm
                                   ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                                   ,'Y'                                   as active_indicator
                                   ,'RADAR'                          as source_system_code
                                   ,date_format(current_date, 'yyyyMMdd') as  report_date_key 
                                from vw_cp_master_radar rad
                                where rad.SAP_UNIQUE_ID is not null and length(rad.SAP_UNIQUE_ID) > 0
                                """)
#creating temp view
bdg_cp_sap_account_df.createOrReplaceTempView("vw_bridge_counterparty_sap_account")

# need to get the distinct unique_id counts
bdg_cp_sap_account_cp_unique_id_cnt = bdg_cp_sap_account_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
bdg_cp_sap_account_cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_bridge_counterparty_sap_account cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)
                                       
#load process
if cp_unique_id_cnt >= bdg_cp_sap_account_cp_unique_id_cnt and bdg_cp_sap_account_cp_unique_id_not_in_cp_df.count()==0:
  try:
  
    print(f"""Count Match: {cp_unique_id_cnt} and {bdg_cp_sap_account_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of bridge_counterparty_sap_account is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'bridge_counterparty_sap_account', 'RADAR')
  
  except Exception as e:
    print("For RADAR source system counterparty count and bridge_counterparty_sap_accnt cp_unique_id didn't match")
    raise dbutils.notebook.exit(e)
elif {cp_unique_id_cnt} < {bdg_cp_sap_account_cp_unique_id_cnt}: 
  print(f"""counterparty: {cp_unique_id_cnt}""")
  print(f"""bridge_counterparty_sap_account: {bdg_cp_sap_account_cp_unique_id_cnt}""")
  print("Count match is not working ")
else:
  print(f"""cp_unique_id exists in bridge counterparty sap account table but in counterparty table""")

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'bridge_counterparty_sap_account', 'cp_data_hub', 'bridge_counterparty_sap_account', 'RADAR')

# COMMAND ----------

Source_System_Code = 'RADAR'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
