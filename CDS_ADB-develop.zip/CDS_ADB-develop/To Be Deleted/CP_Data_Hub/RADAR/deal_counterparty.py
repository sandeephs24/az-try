# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 1,ADLS Staging and Target Paths of CP Data Hub Project
#parameterize base folder
dbutils.widgets.text("pm_adls_proj_folder", "P00014-Cross_Comm-CPData-DEV")
v_adls_folder = dbutils.widgets.get("pm_adls_proj_folder")

#derive final paths
adls_file_path_full_src = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/staging/radar/source_file/"
adls_file_path_tgt      = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/cp_data_hub/radar/"
partition_by_cols_stg= ['source_system_code','report_date_key']
partition_by_cols_tgt = ["source_system_code"]

# COMMAND ----------

create_temp_views_per_source_system('RADAR', 'radar')

# COMMAND ----------

# DBTITLE 1, radar_VOY_INFO view for refresh date
# MAGIC %sql
# MAGIC create or replace temporary view radar_voy_info_tmstmp 
# MAGIC as select * from radar_voy_info

# COMMAND ----------

# MAGIC %sql
# MAGIC --Common filters for deal_info
# MAGIC create or replace temporary view radar_deal_info as
# MAGIC select distinct
# MAGIC   customer_code
# MAGIC   ,radar_date
# MAGIC   --,control_end_date
# MAGIC   ,deal_number
# MAGIC   ,deal_type
# MAGIC   ,trader_name
# MAGIC   ,deal_date
# MAGIC   ,book_name
# MAGIC from radar_deal_info

# COMMAND ----------

# MAGIC %sql
# MAGIC --Common filters for rad_oil_contract
# MAGIC create or replace temporary view radar_rad_oil_contract as
# MAGIC select distinct
# MAGIC counter_party_code
# MAGIC ,oil_contract_seq_num
# MAGIC from
# MAGIC radar_rad_oil_contract

# COMMAND ----------

# MAGIC %sql
# MAGIC --Common filters for rad_sap_submission
# MAGIC create or replace temporary view radar_rad_sap_submission as
# MAGIC select distinct
# MAGIC customer_code
# MAGIC ,last_update_tstmp
# MAGIC from
# MAGIC radar_rad_sap_submission

# COMMAND ----------

# MAGIC %sql
# MAGIC --Common filters for deal_comm
# MAGIC create or replace temporary view fil_radar_deal_comm as
# MAGIC select distinct
# MAGIC customer_code,
# MAGIC deal_number
# MAGIC from 
# MAGIC radar_deal_comm
# MAGIC where address_comm = 'N'

# COMMAND ----------

# MAGIC %sql
# MAGIC --Common filters for customer
# MAGIC create or replace temporary view fil_radar_customer as
# MAGIC select distinct
# MAGIC customer_code from
# MAGIC radar_customer c
# MAGIC where
# MAGIC --cast(c.last_update_tstmp as date)>='2018-01-01'
# MAGIC --and 
# MAGIC c.CUSTOMER_code <>1

# COMMAND ----------

# MAGIC %sql
# MAGIC --Common filters for port_calls
# MAGIC create or replace temporary view fil_radar_port_calls as
# MAGIC select distinct
# MAGIC third_party_agent_code
# MAGIC ,port_arrive
# MAGIC ,port_depart
# MAGIC ,last_update_tstmp
# MAGIC from
# MAGIC radar_port_calls pc
# MAGIC WHERE if(isnull(PC.port_arrive), cast(PC.port_depart as date), cast(PC.port_arrive as date)) > '2018-01-01'

# COMMAND ----------

# MAGIC %sql
# MAGIC --Common filters for RAD_BUNKER_LIFTING
# MAGIC create or replace temporary view fil_radar_RAD_BUNKER_LIFTING as
# MAGIC select distinct
# MAGIC bunker_broker_code
# MAGIC ,lifting_date
# MAGIC ,supp_code
# MAGIC from
# MAGIC radar_RAD_BUNKER_LIFTING
# MAGIC WHERE cast(lifting_date as date) > '2018-01-01'

# COMMAND ----------

# MAGIC %sql
# MAGIC --Common filters for RAD_trading_PARCEL
# MAGIC create or replace temporary view fil_radar_RAD_trading_PARCEL as
# MAGIC select distinct
# MAGIC inspector_code
# MAGIC ,bol_date
# MAGIC ,last_update_tstmp
# MAGIC ,oil_contract_seq_num
# MAGIC from
# MAGIC radar_RAD_trading_PARCEL p
# MAGIC WHERE if(isnull(p.bol_date), cast(p.last_update_tstmp as date), cast(p.bol_date as date)) > '2018-01-01'

# COMMAND ----------

# DBTITLE 1,Original
# MAGIC %sql
# MAGIC --create or replace temporary view vw_original as
# MAGIC --SELECT 
# MAGIC --  --radar customer details
# MAGIC --  c.customer_code,
# MAGIC --  CAST(REPLACE(c.business_name,'"','') AS VARCHAR(50)) business_name,
# MAGIC --  
# MAGIC --  --mark a counterparty as obsolete if no activity since specified cutoff date
# MAGIC --  CASE WHEN
# MAGIC --        if(isnull(max_freight_deal_dte), date_add(current_date(), -2000), max_freight_deal_dte)      <= '2018-01-01'
# MAGIC --    AND if(isnull(max_freight_broker_dte),date_add(current_date(), -2000), max_freight_broker_dte)    <= '2018-01-01'
# MAGIC --    AND vsl_own.is_ship_owner IS NULL
# MAGIC --    AND vsl_op.is_ship_operator IS NULL
# MAGIC --    AND if(isnull(p_bunker.max_bunker_lifting), date_add(current_date(), -2000), p_bunker.max_bunker_lifting)  <= '2018-01-01'
# MAGIC --    AND if(isnull(p_supplier.max_bunker_lifting), date_add(current_date(), -2000), p_supplier.max_bunker_lifting) <= '2018-01-01'
# MAGIC --    AND p_agent1.is_port_agent IS NULL
# MAGIC --    AND p_agent2.is_port_agent IS NULL
# MAGIC --    AND p_agent_zone.is_hub_agent IS NULL
# MAGIC --    AND if(isnull(p_3agent.max_port_arrive), date_add(current_date(), -2000), p_3agent.max_port_arrive)  <= '2018-01-01'
# MAGIC --    AND if(isnull(c_insp.max_bol_date), date_add(current_date(), -2000), c_insp.max_bol_date)       <= '2018-01-01'
# MAGIC --    AND if(isnull(c_oil.Max_bol_date), date_add(current_date(), -2000), c_oil.Max_bol_date)        <= '2018-01-01'
# MAGIC --    AND if(isnull(dem.last_demurrage_date), date_add(current_date(), -2000), dem.last_demurrage_date)        <= '2018-01-01' 
# MAGIC --    AND if(isnull(rss.last_submission_date), date_add(current_date(), -2000), rss.last_submission_date)        <= '2018-01-01' 
# MAGIC --  THEN 'Y'
# MAGIC --  ELSE 'N'
# MAGIC --  END obsolete,
# MAGIC --
# MAGIC --  p_3agent.max_port_arrive,
# MAGIC --  CASE WHEN max_tc_date > current_date() THEN 'Y' ELSE 'N' END open_tc_ind,
# MAGIC --  if(isnull(dem.customer_code),'N','Y') open_dem_ind,
# MAGIC --
# MAGIC --  max_freight_broker_dte,
# MAGIC --
# MAGIC --  --cargo usage
# MAGIC --  c_insp.max_bol_date inspector_max_bol_date,
# MAGIC --  c_oil.Max_bol_date oil_max_bol_date,
# MAGIC --
# MAGIC --  --vessel usage
# MAGIC --  if(isnull(vsl_own.is_ship_owner),'Y','N') is_ship_owner,
# MAGIC --  if(isnull(vsl_op.is_ship_operator),'Y','N') is_ship_operator,
# MAGIC --
# MAGIC --  --bunker usage
# MAGIC --  p_bunker.max_bunker_lifting bunker_broker_max_lifting,
# MAGIC --  p_supplier.max_bunker_lifting bunker_supplier_max_lifting,
# MAGIC --
# MAGIC --  --port agent usage
# MAGIC -- 
# MAGIC --  if(isnull(p_agent1.max_port_name), 
# MAGIC --        if(isnull(p_agent2.max_port_name), p_agent_zone.zone_code, p_agent2.max_port_name),
# MAGIC --                      p_agent1.max_port_name) agent_max_port,
# MAGIC --
# MAGIC --  --probably not useful
# MAGIC --  rss.last_submission_date,
# MAGIC --
# MAGIC --  current_date() extraction_date
# MAGIC --
# MAGIC --FROM radar_customer c
# MAGIC --
# MAGIC ----/*RADAR FREIGHT DEAL USAGE*/--
# MAGIC --left OUTER JOIN (
# MAGIC --  SELECT
# MAGIC --    customer_code,
# MAGIC --    Max(radar_date) max_freight_deal_dte,
# MAGIC --    Max(control_end_date) max_tc_date
# MAGIC --  FROM radar_deal_info di
# MAGIC --  left OUTER JOIN radar_ship_control sc ON sc.tc_deal_number = di.deal_number
# MAGIC --  GROUP BY customer_code
# MAGIC --) di ON di.customer_code = c.customer_code
# MAGIC --
# MAGIC ----/*RADAR FREIGHT DEAL BROKERAGE - exclude address commission*/--
# MAGIC --left OUTER JOIN (
# MAGIC --  SELECT
# MAGIC --    dc.customer_code,
# MAGIC --    Max(radar_date) max_freight_broker_dte
# MAGIC --  FROM radar_deal_comm dc
# MAGIC --  JOIN radar_deal_info di on dc.deal_number = di.deal_number
# MAGIC --  WHERE address_comm = 'N'
# MAGIC --  and cast(di.deal_date as date) > '2018-01-01' 
# MAGIC --  GROUP BY
# MAGIC --    dc.customer_code
# MAGIC --) dc ON dc.customer_code = c.customer_code
# MAGIC --
# MAGIC ----/*IS VESSEL OPERATOR*/--
# MAGIC --left OUTER JOIN (
# MAGIC --  SELECT DISTINCT
# MAGIC --    vsl.operator_code,
# MAGIC --    1 is_ship_operator
# MAGIC --  FROM radar_BVT_VESSEL vsl
# MAGIC --  JOIN radar_SHIP_DATA ship ON vsl.lrs = ship.lrs
# MAGIC --  WHERE
# MAGIC --    ship.ship_active_ind = 'Y'
# MAGIC --  UNION
# MAGIC --  SELECT DISTINCT ship.safe_manager_code,
# MAGIC --  1 is_ship_operator
# MAGIC --  FROM radar_SHIP_DATA ship
# MAGIC --  WHERE
# MAGIC --    ship.ship_active_ind = 'Y'
# MAGIC --) vsl_op ON vsl_op.operator_code = c.customer_code
# MAGIC --
# MAGIC ----/*IS VESSEL OWNER*/--
# MAGIC --left OUTER JOIN (
# MAGIC --  SELECT DISTINCT
# MAGIC --    vsl.owner_code,
# MAGIC --    1 is_ship_owner
# MAGIC --  FROM radar_BVT_VESSEL vsl
# MAGIC --  JOIN radar_SHIP_DATA ship ON vsl.lrs = ship.lrs
# MAGIC --  WHERE
# MAGIC --    ship.ship_active_ind = 'Y'
# MAGIC --  UNION
# MAGIC --  SELECT DISTINCT
# MAGIC --    ship.safe_owner_code,
# MAGIC --    1 is_ship_owner
# MAGIC --  FROM radar_SHIP_DATA ship
# MAGIC --  WHERE
# MAGIC --    ship.ship_active_ind = 'Y'
# MAGIC --) vsl_own ON vsl_own.owner_code = c.customer_code
# MAGIC --
# MAGIC ----/*3rd PARTY AGENT PORT CALL*/--
# MAGIC --left OUTER JOIN (
# MAGIC --  SELECT
# MAGIC --    pc.third_party_agent_code,
# MAGIC --    --pn.port_name,
# MAGIC --    --pn.CNTRY_MNEM,PC.PORT_ACTIVITY,
# MAGIC --    Max(if(isnull(pc.port_arrive),
# MAGIC --        if(isnull(pc.port_depart), pc.last_update_tstmp , pc.port_depart),
# MAGIC --                  pc.port_arrive)) max_port_arrive
# MAGIC --    --Max(pn.port_name) max_port_name
# MAGIC --  FROM radar_port_calls pc
# MAGIC --  --JOIN radar_port_name pn ON pn.port_code = pc.port_code
# MAGIC --  WHERE if(isnull(PC.port_arrive), cast(PC.port_depart as date), cast(PC.port_arrive as date)) > '2018-01-01'
# MAGIC --  GROUP BY
# MAGIC --    pc.third_party_agent_code
# MAGIC --    --,pn.port_name
# MAGIC --    --, pn.CNTRY_MNEM,PC.PORT_ACTIVITY
# MAGIC --) p_3agent ON p_3agent.third_party_agent_code = c.customer_code
# MAGIC --
# MAGIC ----/*PRIMARY PORT AGENT*/--
# MAGIC --left OUTER JOIN (
# MAGIC --  SELECT
# MAGIC --    pn.main_port_agent_code,
# MAGIC --    1 is_port_agent,
# MAGIC --    Max(pn.port_name) max_port_name
# MAGIC --  FROM radar_port_name pn
# MAGIC --  GROUP BY
# MAGIC --    pn.main_port_agent_code
# MAGIC --) p_agent1 ON p_agent1.main_port_agent_code = c.customer_code
# MAGIC --
# MAGIC ----/*SECONDARY PORT AGENT*/--
# MAGIC --left OUTER JOIN (
# MAGIC --  SELECT
# MAGIC --    pn.secondary_port_agent_code,
# MAGIC --    1 is_port_agent,
# MAGIC --    Max(pn.port_name) max_port_name
# MAGIC --  FROM radar_port_name pn
# MAGIC --  GROUP BY
# MAGIC --    pn.secondary_port_agent_code
# MAGIC --) p_agent2 ON p_agent2.secondary_port_agent_code = c.customer_code
# MAGIC --
# MAGIC ----/*ZONE AGENT*/--
# MAGIC --left OUTER JOIN (
# MAGIC --  SELECT
# MAGIC --    hub_agent_code,
# MAGIC --    1 is_hub_agent,
# MAGIC --    Max(zone_code) zone_code
# MAGIC --  FROM radar_rad_zone
# MAGIC --  GROUP BY
# MAGIC --    hub_agent_code
# MAGIC --) p_agent_zone ON p_agent_zone.hub_agent_code = c.customer_code
# MAGIC --
# MAGIC ----/*BUNKER BROKER USAGE*/--
# MAGIC --left OUTER JOIN (
# MAGIC --  SELECT
# MAGIC --    bunker_broker_code, Max(lifting_date) max_bunker_lifting
# MAGIC --  FROM radar_RAD_BUNKER_LIFTING
# MAGIC --  WHERE cast(lifting_date as date) > '2018-01-01'
# MAGIC --  GROUP BY bunker_broker_code
# MAGIC --) p_bunker ON p_bunker.bunker_broker_code = c.customer_code
# MAGIC --
# MAGIC ----/*BUNKER SUPPLIER*/--
# MAGIC --left OUTER JOIN (
# MAGIC --  SELECT
# MAGIC --    supp_code, Max(lifting_date) max_bunker_lifting
# MAGIC --  FROM radar_RAD_BUNKER_LIFTING
# MAGIC --  WHERE cast(lifting_date as date) > '2018-01-01'
# MAGIC --  GROUP BY supp_code
# MAGIC --) p_supplier ON p_supplier.supp_code = c.customer_code
# MAGIC --
# MAGIC ----/*INSPECTOR on CARGO*/--
# MAGIC --left OUTER JOIN (
# MAGIC --  SELECT
# MAGIC --    p.inspector_code,
# MAGIC --    Max(if(isnull(p.bol_date),p.last_update_tstmp,p.bol_date)) max_bol_date
# MAGIC --  FROM radar_RAD_trading_PARCEL p
# MAGIC --  WHERE if(isnull(p.bol_date), cast(p.last_update_tstmp as date), cast(p.bol_date as date)) > '2018-01-01'
# MAGIC --  GROUP BY
# MAGIC --    p.inspector_code
# MAGIC -- ) c_insp ON c_insp.inspector_code = c.customer_code
# MAGIC --
# MAGIC ----/*OIL COUNTERPARTY USAGE*/--
# MAGIC -- left OUTER JOIN (
# MAGIC --  SELECT
# MAGIC --    oc.counter_party_code,
# MAGIC --    Max(if(isnull(p.bol_date),p.last_update_tstmp, p.bol_date)) max_bol_date
# MAGIC --  FROM radar_RAD_trading_PARCEL p
# MAGIC --  JOIN radar_rad_oil_contract oc ON oc.oil_contract_seq_num = p.oil_contract_seq_num
# MAGIC --  AND if(isnull(p.bol_date),cast(p.last_update_tstmp as date), cast(p.bol_date as date)) > '2018-01-01'
# MAGIC --  GROUP BY
# MAGIC --    oc.counter_party_code
# MAGIC -- ) c_oil ON c_oil.counter_party_code = c.customer_code
# MAGIC -- 
# MAGIC ----/*DEMURRAGE STILL OPEN*/--
# MAGIC --left OUTER JOIN (
# MAGIC --  SELECT
# MAGIC --    if(isnull(dc.alternative_customer_code),  
# MAGIC --            if(isnull(di.customer_code), oc.counter_party_code , di.customer_code),
# MAGIC --                     dc.alternative_customer_code)
# MAGIC --     customer_code,
# MAGIC --    Max(dc.last_update_tstmp) last_demurrage_date
# MAGIC --
# MAGIC --  FROM radar_DEM_CALC dc
# MAGIC --  left OUTER JOIN radar_deal_info di ON di.deal_number = dc.deal_number
# MAGIC --  left OUTER JOIN radar_rad_oil_contract oc ON oc.oil_contract_seq_num = dc.oil_contract_seq_num
# MAGIC --  WHERE
# MAGIC --    --demurrage status that IS still OPEN/unresolved.
# MAGIC --    dc.status_code IN (0,9,10,11,12,13,14,19,20,21,22)
# MAGIC --  AND cast(dc.last_update_tstmp as date) > '2018-01-01'  
# MAGIC --GROUP BY
# MAGIC --  if(isnull(dc.alternative_customer_code),  
# MAGIC --            if(isnull(di.customer_code), oc.counter_party_code , di.customer_code),
# MAGIC --                     dc.alternative_customer_code)
# MAGIC --) dem ON dem.customer_code = c.customer_code
# MAGIC --
# MAGIC --
# MAGIC --LEFT OUTER JOIN (
# MAGIC --SELECT customer_code,
# MAGIC --max(last_update_tstmp) last_submission_date
# MAGIC --FROM radar_rad_sap_submission
# MAGIC --GROUP BY customer_code) rss ON rss.customer_code = c.customer_code
# MAGIC --
# MAGIC --where cast(c.last_update_tstmp as date)>='2018-01-01'
# MAGIC --and c.CUSTOMER_code <>1
# MAGIC --ORDER BY
# MAGIC --  c.customer_type,
# MAGIC --  c.business_name,
# MAGIC --  c.customer_code
# MAGIC --;
# MAGIC --

# COMMAND ----------

# DBTITLE 1,Non-Freight Deals
df_radar_nfd = spark.sql("""
SELECT 
  --radar customer details
  c.customer_code,
  cast(NULL as string) book_name,
  cast(NULL as string) deal_type,
  cast(NULL as string) trader_name,
  cast(NULL as string) max_deal_date,
  cast(NULL as string) buy_sell_ind,
  cast(NULL as string) voyage_end_date,
  max(p_3agent.max_port_arrive) max_port_arrive,

  max(max_freight_broker_dte) max_freight_broker_dte,

  --cargo usage
  max(c_insp.max_bol_date) inspector_max_bol_date,
  max(c_oil.Max_bol_date) oil_max_bol_date,

  --bunker usage
  max(p_bunker.max_bunker_lifting) bunker_broker_max_lifting,
  max(p_supplier.max_bunker_lifting) bunker_supplier_max_lifting,

  --probably not useful
  max(rss.last_submission_date) last_submission_date,
  cast(NULL as string) total_costs

FROM fil_radar_customer c

--/*RADAR FREIGHT DEAL BROKERAGE - exclude address commission*/--
left OUTER JOIN (
  SELECT
    dc.customer_code,
    Max(radar_date) max_freight_broker_dte
  FROM fil_radar_deal_comm dc
  JOIN radar_deal_info di on dc.deal_number = di.deal_number
  WHERE cast(di.deal_date as date) > '2018-01-01' 
  GROUP BY
    dc.customer_code
) dc ON dc.customer_code = c.customer_code

--/*3rd PARTY AGENT PORT CALL*/--
left OUTER JOIN (
  SELECT
    pc.third_party_agent_code,
    --pn.port_name,
    --pn.CNTRY_MNEM,PC.PORT_ACTIVITY,
    Max(if(isnull(pc.port_arrive),
        if(isnull(pc.port_depart), pc.last_update_tstmp , pc.port_depart),
                  pc.port_arrive)) max_port_arrive
    --Max(pn.port_name) max_port_name
  FROM fil_radar_port_calls pc
  --JOIN radar_port_name pn ON pn.port_code = pc.port_code
  --WHERE if(isnull(PC.port_arrive), cast(PC.port_depart as date), cast(PC.port_arrive as date)) > '2018-01-01'
  GROUP BY
    pc.third_party_agent_code
    --,pn.port_name
    --, pn.CNTRY_MNEM,PC.PORT_ACTIVITY
) p_3agent ON p_3agent.third_party_agent_code = c.customer_code

--/*BUNKER BROKER USAGE*/--
left OUTER JOIN (
  SELECT
    bunker_broker_code, Max(lifting_date) max_bunker_lifting
  FROM fil_radar_RAD_BUNKER_LIFTING
  --WHERE cast(lifting_date as date) > '2018-01-01'
  GROUP BY bunker_broker_code
) p_bunker ON p_bunker.bunker_broker_code = c.customer_code

--/*BUNKER SUPPLIER*/--
left OUTER JOIN (
  SELECT
    supp_code, Max(lifting_date) max_bunker_lifting
  FROM fil_radar_RAD_BUNKER_LIFTING
  --WHERE cast(lifting_date as date) > '2018-01-01'
  GROUP BY supp_code
) p_supplier ON p_supplier.supp_code = c.customer_code

--/*INSPECTOR on CARGO*/--
left OUTER JOIN (
  SELECT
    p.inspector_code,
    Max(if(isnull(p.bol_date),p.last_update_tstmp,p.bol_date)) max_bol_date
  FROM fil_radar_RAD_trading_PARCEL p
  --WHERE if(isnull(p.bol_date), cast(p.last_update_tstmp as date), cast(p.bol_date as date)) > '2018-01-01'
  GROUP BY
    p.inspector_code
 ) c_insp ON c_insp.inspector_code = c.customer_code

--/*OIL COUNTERPARTY USAGE*/--
 left OUTER JOIN (
  SELECT
    oc.counter_party_code,
    Max(if(isnull(p.bol_date),p.last_update_tstmp, p.bol_date)) max_bol_date
  FROM radar_RAD_trading_PARCEL p
  JOIN radar_rad_oil_contract oc ON oc.oil_contract_seq_num = p.oil_contract_seq_num
  --AND if(isnull(p.bol_date),cast(p.last_update_tstmp as date), cast(p.bol_date as date)) > '2018-01-01'
  GROUP BY
    oc.counter_party_code
 ) c_oil ON c_oil.counter_party_code = c.customer_code

LEFT OUTER JOIN (
SELECT customer_code,
max(last_update_tstmp) last_submission_date
FROM radar_rad_sap_submission
GROUP BY customer_code) rss ON rss.customer_code = c.customer_code

group by
c.customer_code
--rss.last_submission_date
ORDER BY
  c.customer_code
;
""")

df_radar_nfd = df_radar_nfd.withColumn("source_system_code",lit('RADAR')) #adding source_system_code
df_radar_nfd = df_radar_nfd.withColumn("meta_created_dttm",current_timestamp()) #adding source_system_code
df_radar_nfd = df_radar_nfd.withColumn("report_date_key", date_format(current_timestamp(),'yyyyMMdd').cast(IntegerType()))  # report date key 


# COMMAND ----------

#display(df_radar_nfd.filter("bunker_supplier_max_lifting is not null"))#.count()

# COMMAND ----------

# DBTITLE 1,Staging Non Freight in ADLS 
adls_file_path_full_src_nonfreight=adls_file_path_full_src+'non-freight/'
print(adls_file_path_full_src_nonfreight)
df_radar_nfd.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_stg).save(adls_file_path_full_src_nonfreight)

# COMMAND ----------

# DBTITLE 1,Read Non Freight from Staged Folder
df_radar_nfd  = spark.read.format('delta').load(adls_file_path_full_src_nonfreight)
#df_gpna_fin.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC --Common filters for radar_book_name
# MAGIC create or replace temporary view radar_book_name as
# MAGIC select distinct
# MAGIC book_name
# MAGIC from
# MAGIC radar_book_name

# COMMAND ----------

# MAGIC %sql
# MAGIC --Common filters for radar_voy_cargo
# MAGIC create or replace temporary view radar_voy_cargo as
# MAGIC select distinct
# MAGIC deal_number
# MAGIC ,voyage_number
# MAGIC ,lrs
# MAGIC ,trip_number
# MAGIC ,total_costs
# MAGIC from
# MAGIC radar_voy_cargo

# COMMAND ----------

# MAGIC %sql
# MAGIC --Common filters for radar_voy_info
# MAGIC create or replace temporary view radar_voy_info as
# MAGIC select distinct
# MAGIC voyage_number
# MAGIC ,lrs
# MAGIC ,trip_number
# MAGIC ,voyage_end_date
# MAGIC from
# MAGIC radar_voy_info

# COMMAND ----------

# DBTITLE 1,Freight Deals
# MAGIC %sql
# MAGIC create or replace temporary view freight_deals_one as
# MAGIC SELECT 
# MAGIC di.customer_code,
# MAGIC bn.book_name, 
# MAGIC di.deal_type, 
# MAGIC di.trader_name,
# MAGIC di.deal_date,
# MAGIC if(instr(di.deal_type,'I')==0,'S','B') buy_sell_ind,
# MAGIC vi.voyage_end_date,
# MAGIC cast(NULL as string) max_port_arrive,
# MAGIC cast(NULL as string) max_freight_broker_dte,
# MAGIC cast(NULL as string) inspector_max_bol_date,
# MAGIC cast(NULL as string) oil_max_bol_date,
# MAGIC cast(NULL as string) bunker_broker_max_lifting,
# MAGIC cast(NULL as string) bunker_supplier_max_lifting,
# MAGIC cast(NULL as string) last_submission_date,
# MAGIC vc.total_costs
# MAGIC FROM 
# MAGIC radar_deal_info di 
# MAGIC , radar_book_name bn
# MAGIC , radar_voy_cargo vc 
# MAGIC , radar_voy_info vi
# MAGIC 
# MAGIC WHERE di.book_name = bn.book_name
# MAGIC AND vc.deal_number = di.deal_number
# MAGIC AND (vi.lrs = vc.lrs AND vi.voyage_number = vc.voyage_number)
# MAGIC and year(vi.voyage_end_date) >=2018
# MAGIC /*AND (vc.laycan_end > '2018-01-01' OR di.deal_date > '2018-01-01')
# MAGIC AND (di.book2_name IS NULL OR vc.vci_vco_ind IS NULL)*/
# MAGIC 
# MAGIC union
# MAGIC 
# MAGIC SELECT 
# MAGIC di.customer_code,
# MAGIC bn.book_name, 
# MAGIC di.deal_type, 
# MAGIC di.trader_name,
# MAGIC di.deal_date,
# MAGIC if(instr(di.deal_type,'I')==0,'S','B') buy_sell_ind,
# MAGIC vi.voyage_end_date,
# MAGIC cast(NULL as string) max_port_arrive,
# MAGIC cast(NULL as string) max_freight_broker_dte,
# MAGIC cast(NULL as string) inspector_max_bol_date,
# MAGIC cast(NULL as string) oil_max_bol_date,
# MAGIC cast(NULL as string) bunker_broker_max_lifting,
# MAGIC cast(NULL as string) bunker_supplier_max_lifting,
# MAGIC cast(NULL as string) last_submission_date,
# MAGIC vc.total_costs
# MAGIC FROM 
# MAGIC radar_deal_info di 
# MAGIC , radar_book_name bn
# MAGIC , radar_voy_cargo vc 
# MAGIC , radar_voy_info vi
# MAGIC 
# MAGIC WHERE di.book_name = bn.book_name
# MAGIC AND vc.deal_number = di.deal_number
# MAGIC AND  (vi.lrs = 666 AND vi.trip_number = vc.trip_number)
# MAGIC and  year(vi.voyage_end_date) >=2018
# MAGIC /*AND (vc.laycan_end > '2018-01-01' OR di.deal_date > '2018-01-01')
# MAGIC AND (di.book2_name IS NULL OR vc.vci_vco_ind IS NULL)*/

# COMMAND ----------

df_radar_fd = spark.sql("""
SELECT 
customer_code,
book_name, 
deal_type, 
trader_name,
max(deal_date) max_deal_date,
buy_sell_ind,
max(voyage_end_date) voyage_end_date,
max_port_arrive,
max_freight_broker_dte,
inspector_max_bol_date,
oil_max_bol_date,
bunker_broker_max_lifting,
bunker_supplier_max_lifting,
last_submission_date,
sum(total_costs) total_costs
FROM 
freight_deals_one
group by
customer_code,
book_name, 
deal_type, 
trader_name,
buy_sell_ind,
max_port_arrive,
max_freight_broker_dte,
inspector_max_bol_date,
oil_max_bol_date,
bunker_broker_max_lifting,
bunker_supplier_max_lifting,
last_submission_date
""")

df_radar_fd = df_radar_fd.withColumn("source_system_code",lit('RADAR')) #adding source_system_code
df_radar_fd = df_radar_fd.withColumn("meta_created_dttm",current_timestamp()) #adding source_system_code
df_radar_fd = df_radar_fd.withColumn("report_date_key", date_format(current_timestamp(),'yyyyMMdd').cast(IntegerType()))  # report date key 


# COMMAND ----------

#display(df_radar_fd.filter("max_deal_date is not null"))

# COMMAND ----------

# DBTITLE 1,Staging Freight in ADLS 
adls_file_path_full_src_freight=adls_file_path_full_src+'freight/'
print(adls_file_path_full_src_freight)
df_radar_fd.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_stg).save(adls_file_path_full_src_freight)

# COMMAND ----------

# DBTITLE 1,Read Freight from Staged Folder
df_radar_fd  = spark.read.format('delta').load(adls_file_path_full_src_freight)
df_radar_fd.count()

# COMMAND ----------



# COMMAND ----------

#dbutils.fs.rm('/mnt/ADLS/PROJECT/P00014-Cross_Comm-CPData-DEV/cp-data-hub/staging/endur_gp_na/source_file/', True )

# COMMAND ----------

# DBTITLE 1,Union all + date key columns
#union all
deal_counterparty_df = df_radar_nfd.union(df_radar_fd)
deal_counterparty_df = deal_counterparty_df.withColumn("source_system_code",lit('RADAR'))
deal_counterparty_df = deal_counterparty_df.withColumn("meta_created_dttm",current_timestamp()) #adding source_system_code
deal_counterparty_df = deal_counterparty_df.withColumn("report_date_key", date_format(current_timestamp(),'yyyyMMdd').cast(IntegerType()))  # report date key 

# COMMAND ----------

#creating a date_key column of integer type
date_columns = ['voyage_end_date']
for col_name in date_columns:
    deal_counterparty_df= deal_counterparty_df.withColumn(f"{col_name}_key",date_format((f"{col_name}"),"yyyyMMdd").cast(IntegerType()))
#deal_counterparty_df.count()

# COMMAND ----------

#display(deal_counterparty_df.filter('max_deal_date_key is not null'))

# COMMAND ----------

# DBTITLE 1,Staging deal_counterparty in ADLS 
adls_file_path_full_src_deal_cp=adls_file_path_full_src+'deal_counterparty/'
print(adls_file_path_full_src_deal_cp)
deal_counterparty_df.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_stg).save(adls_file_path_full_src_deal_cp)
#deal_counterparty_df.count()

# COMMAND ----------

# DBTITLE 1,Read deal_counterparty  from Staged Folder
deal_counterparty_df  = spark.read.format('delta').load(adls_file_path_full_src_deal_cp)
deal_counterparty_df.createOrReplaceTempView("vw_deal_counterparty")
#deal_counterparty_df.count()

# COMMAND ----------

# DBTITLE 1,Getting max dates for deal_counterparty_summary
deal_counterpary_summary_df  =  deal_counterparty_df.groupBy("customer_code").agg(max("max_deal_date").alias("deal_latest_trade_date"),\
                                                                           greatest(max("voyage_end_date"), max("max_port_arrive"), max("max_freight_broker_dte"), max("inspector_max_bol_date"), max("oil_max_bol_date"), max("bunker_broker_max_lifting"), max("bunker_supplier_max_lifting"), max("last_submission_date")).alias("deal_latest_delivery_date") )
deal_counterpary_summary_df.createOrReplaceTempView("vw_deal_counterparty_summary")

# COMMAND ----------

# DBTITLE 1,deal_counterparty_summary
deal_counterparty_summary = spark.sql(""" select source_system_code
                                         ,cds.customer_code as cp_deal_mapping_id
                                         ,cds.deal_latest_trade_date
                                         ,cds.deal_latest_delivery_date
                                         ,concat_ws(",", array_sort((collect_set(cd.trader_name)))) as deal_latest_trader_name
                                         ,current_timestamp as meta_created_dttm
                                         ,current_timestamp as meta_start_dttm
                                         ,cast('2999-12-31' as timestamp) as meta_end_dttm 
                                         ,'Y'  as active_indicator
                                         , date_format(current_date, 'yyyyMMdd') as report_date_key
                                    from        vw_deal_counterparty         cd
                                    inner join  vw_deal_counterparty_summary cds on cd.customer_code = cds.customer_code 
                                    and (cds.deal_latest_trade_date = cd.max_deal_date)
                                    where year(cds.deal_latest_delivery_date) >= 2018
                                    or year(cds.deal_latest_trade_date) >= 2018
                                    group by source_system_code
                                           , cds.customer_code
                                           , cds.deal_latest_trade_date
                                           , cds.deal_latest_delivery_date
                                     """)#.dropna()
#deal_counterparty_summary.count()
deal_counterparty_summary.createOrReplaceTempView("vw_deal_counterparty_summary")
deal_counterparty_summary.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty_summary/")

# COMMAND ----------

# DBTITLE 1,deal_counterparty
deal_counterparty_final = deal_counterparty_df.select(col('source_system_code').alias('source_system_code')  
                                                ,col('customer_code').alias('cp_deal_mapping_id')  
                                                ,col('book_name').alias('deal_trading_desk')  
                                                ,lit('').alias('deal_trading_entity')  
                                                ,lit('').alias('deal_trading_entity_long_name')  
                                                ,col('buy_sell_ind').alias('deal_buy_sell')  
                                                ,col('deal_type').alias('deal_class')  
                                                ,lit('').alias('deal_product_type')  
                                                ,col('voyage_end_date_key').alias('deal_date_month_key')  
                                                ,col('trader_name').alias('deal_trader_name')  
                                                ,lit('USD').alias('deal_value_unit_of_measure')  
                                                ,lit('').alias('deal_volume_unit_of_measure')  
                                                ,col('total_costs').cast("decimal(30,5)").alias('deal_notional_value')  
                                                ,lit('NULL').cast("decimal(30,5)").alias('deal_notional_volume')  
                                                ,col("meta_created_dttm").alias('meta_created_dttm')
                                                ,col("current_timestamp").alias('meta_start_dttm')
                                                ,to_date(lit('2999-12-31')).alias('meta_end_dttm')
                                                ,lit('Y').alias('active_indicator')
                                                ,date_format(col("current_date"),'yyyyMMdd').alias('report_date_key')
                                               ).drop_duplicates()
#deal_counterparty_final.count()
deal_counterparty_final.createOrReplaceTempView("vw_deal_counterparty")
deal_counterparty_final.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_tgt).save(adls_file_path_tgt+"deal_counterparty/")

# COMMAND ----------

# DBTITLE 1, Write deal_counterparty to staging table
cnt_before_writing = deal_counterparty_final.count()
deal_counterparty= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty/")
cnt_after_writing = deal_counterparty.count()

try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty', 'RADAR')
except Exception as r:
  print("For RADAR source system deal_counteparty counts didn't match")
  raise dbutils.notebook.exit(e)
        

# COMMAND ----------

# DBTITLE 1,Switch the partitions from staging table target table
LoadCuratedTargetTbl('staging', 'deal_counterparty', 'cp_data_hub', 'deal_counterparty', 'RADAR')

# COMMAND ----------

# DBTITLE 1,Write deal_counterparty_summary to staging table
cnt_before_writing = deal_counterparty_summary.count()
deal_counterparty_summary= spark.read.format('delta').load(adls_file_path_tgt+"deal_counterparty_summary/")
cnt_after_writing = deal_counterparty_summary.count()
try:
  if cnt_before_writing == cnt_after_writing:
    RefreshCuratedSqlTbl('staging', 'deal_counterparty_summary', 'RADAR')
except Exception as r:
  print("For RADAR source system deal_counteparty_summary counts didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

# DBTITLE 1,Switch Partition from staging table target table
LoadCuratedTargetTbl('staging', 'deal_counterparty_summary', 'cp_data_hub', 'deal_counterparty_summary', 'RADAR')

# COMMAND ----------

# DBTITLE 1,Function to update refresh date
RefreshDateP3('last_update_tstmp','NULL','radar_voy_info_tmstmp','RADAR') 

# COMMAND ----------

Source_System_Code = 'RADAR'
System ='P3'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
