# Databricks notebook source
# MAGIC %sql
# MAGIC clear cache

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

# DBTITLE 1,ADLS Staging and Target Paths of CP Data Hub Project
#parameterize base folder
dbutils.widgets.text("pm_adls_proj_folder", "P00014-Cross_Comm-CPData-DEV")
v_adls_folder = dbutils.widgets.get("pm_adls_proj_folder")

#derive final paths
adls_file_path_full_src = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/staging/aligne/source_file/"
adls_file_path_tgt      = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/cp_data_hub/aligne/"
partition_by_cols_stg= ['source_system_code','report_date_key']
partition_by_cols_tgt = ["source_system_code"]

# COMMAND ----------

create_temp_views_per_source_system('ALIGNE', 'ALIGNE')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view ALIGNE_Z_RISK_TASKFORCECPDATA_DELTA_UNQ as
# MAGIC with latest_dates_delta as (
# MAGIC 
# MAGIC select *, 
# MAGIC 
# MAGIC row_number() over (partition by C1_AUD_BUSKEY, C16_DEL_MONTH order by c26_updated_timestamp desc) rn from ALIGNE_Z_RISK_TASKFORCECPDATA_DELTA t
# MAGIC )
# MAGIC select * from latest_dates_delta where rn = 1;
# MAGIC --This goes to [cp_data_hub].[deal_counterparty_summary]

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view latest_dates as
# MAGIC with latest_dates as (
# MAGIC 
# MAGIC select max(C15_TRADE_DATE) as Latest_Trade_Date, max(GREATEST (C18_DEL_DATEEND, C17_DEL_DATESTART)) as Latest_Delivery_Date , c22_cpty_shortname 
# MAGIC 
# MAGIC from ALIGNE_Z_RISK_TASKFORCECPDATA group by c22_cpty_shortname
# MAGIC ),
# MAGIC  latest_dates_delta as (
# MAGIC 
# MAGIC select max(C15_TRADE_DATE) as Latest_Trade_Date, max(GREATEST (C18_DEL_DATEEND, C17_DEL_DATESTART)) as Latest_Delivery_Date , c22_cpty_shortname 
# MAGIC 
# MAGIC from ALIGNE_Z_RISK_TASKFORCECPDATA_DELTA_UNQ group by c22_cpty_shortname
# MAGIC )
# MAGIC select *  from latest_dates 
# MAGIC union
# MAGIC select * from latest_dates_delta
# MAGIC ;
# MAGIC --This goes to [cp_data_hub].[deal_counterparty_summary]

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view latest_trader_name_all as
# MAGIC with latest_trader_name as (
# MAGIC 
# MAGIC select t.C22_CPTY_SHORTNAME, t.C15_TRADE_DATE, t.C9_TRADER_NAME
# MAGIC from ALIGNE_Z_RISK_TASKFORCECPDATA t
# MAGIC ),
# MAGIC latest_trader_name_delta as (
# MAGIC 
# MAGIC select t.C22_CPTY_SHORTNAME, t.C15_TRADE_DATE, t.C9_TRADER_NAME
# MAGIC from ALIGNE_Z_RISK_TASKFORCECPDATA_DELTA_UNQ t
# MAGIC 
# MAGIC )
# MAGIC select C22_CPTY_SHORTNAME, C15_TRADE_DATE, concat_ws(",", array_sort((collect_set(trim(C9_TRADER_NAME))))) as C9_TRADER_NAME
# MAGIC from
# MAGIC (
# MAGIC select * from latest_trader_name
# MAGIC union
# MAGIC select * from latest_trader_name_delta
# MAGIC )
# MAGIC group by C22_CPTY_SHORTNAME, C15_TRADE_DATE;
# MAGIC --This goes to [cp_data_hub].[deal_counterparty_summary]

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view latest_trader_name as
# MAGIC with latest_trader_name as (
# MAGIC 
# MAGIC select t.C9_TRADER_NAME, t.C22_CPTY_SHORTNAME, row_number() over (partition by C22_CPTY_SHORTNAME order by C15_TRADE_DATE desc) rn from latest_trader_name_all t
# MAGIC )
# MAGIC select * from latest_trader_name where rn = 1
# MAGIC --This goes to [cp_data_hub].[deal_counterparty_summary]

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view latest_trader_name_union as
# MAGIC select lad.C22_CPTY_SHORTNAME, lad.Latest_Trade_Date, lad.Latest_Delivery_Date, ltn.C9_TRADER_NAME
# MAGIC from latest_dates lad, latest_trader_name ltn
# MAGIC where lad.C22_CPTY_SHORTNAME = ltn.C22_CPTY_SHORTNAME
# MAGIC --This goes to [cp_data_hub].[deal_counterparty_summary]

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view raw_table as
# MAGIC with raw_table as (
# MAGIC select  C2_HOUSE_ID  as TRADING_ENTITY,
# MAGIC C3_HOUSE_FULLNAME as Trading_Entity_Long_Name,
# MAGIC C1_AUD_BUSKEY as Deal_Contract_Number,
# MAGIC C4_TRADE_TYPE_DSC as Product_Type,
# MAGIC C5_TRADE_TYPE3 as Deal_Class,
# MAGIC C6_CPTY_ACCT as CPTY_ACCOUNT_NUMBER,
# MAGIC C7_CPTY_DESCR as CPTY_LONG_NAME,
# MAGIC C8__BUY_SELL as  BUY_SELL_INDICATOR,
# MAGIC C9_TRADER_NAME as TRADER_NAME,
# MAGIC C10_BOOK_ATTR1 as TRADING_DESK,
# MAGIC --ABS(C11__AMT) as VOLUME_TRADED,
# MAGIC C11__AMT as VOLUME_TRADED,
# MAGIC C12_AMT_UNIT as VOLUME_UOM,
# MAGIC C13_VALUE_FUNC as VALUE_OF_DEAL,
# MAGIC C14_CCY as PRICE_CURRENCY,
# MAGIC C15_TRADE_DATE as TRADE_DATE,
# MAGIC C16_DEL_MONTH as DEL_MONTH,
# MAGIC C17_DEL_DATESTART as DELIVERY_START_DATE,
# MAGIC C18_DEL_DATEEND as DELIVERY_END_DATE,
# MAGIC GREATEST (C18_DEL_DATEEND, C17_DEL_DATESTART) as DELIVERY_DATE,
# MAGIC C19_MANUM,
# MAGIC C20__CDY_ATTR1_DESC as LOADED_CTRY_CODE,
# MAGIC C21__CDY_ATTR1_DESC as DISCHARGE_CTRY_CODE,
# MAGIC C22_CPTY_SHORTNAME as CP_DEAL_MAPPING_ID,
# MAGIC C22_CPTY_SHORTNAME as ETRM_ACCOUNT_NO,
# MAGIC C23_CPTY_SUB_CATEGORY_DSC,
# MAGIC C24_CPTY_LOC,
# MAGIC C25_PHYS_FIN
# MAGIC from ALIGNE_Z_RISK_TASKFORCECPDATA  ),
# MAGIC raw_table_delta as (
# MAGIC select  C2_HOUSE_ID  as TRADING_ENTITY,
# MAGIC C3_HOUSE_FULLNAME as Trading_Entity_Long_Name,
# MAGIC C1_AUD_BUSKEY as Deal_Contract_Number,
# MAGIC C4_TRADE_TYPE_DSC as Product_Type,
# MAGIC C5_TRADE_TYPE3 as Deal_Class,
# MAGIC C6_CPTY_ACCT as CPTY_ACCOUNT_NUMBER,
# MAGIC C7_CPTY_DESCR as CPTY_LONG_NAME,
# MAGIC C8__BUY_SELL as  BUY_SELL_INDICATOR,
# MAGIC C9_TRADER_NAME as TRADER_NAME,
# MAGIC C10_BOOK_ATTR1 as TRADING_DESK,
# MAGIC --ABS(C11__AMT) as VOLUME_TRADED,
# MAGIC C11__AMT as VOLUME_TRADED,
# MAGIC C12_AMT_UNIT as VOLUME_UOM,
# MAGIC C13_VALUE_FUNC as VALUE_OF_DEAL,
# MAGIC C14_CCY as PRICE_CURRENCY,
# MAGIC C15_TRADE_DATE as TRADE_DATE,
# MAGIC C16_DEL_MONTH as DEL_MONTH,
# MAGIC C17_DEL_DATESTART as DELIVERY_START_DATE,
# MAGIC C18_DEL_DATEEND as DELIVERY_END_DATE,
# MAGIC GREATEST (C18_DEL_DATEEND, C17_DEL_DATESTART) as DELIVERY_DATE,
# MAGIC C19_MANUM,
# MAGIC C20__CDY_ATTR1_DESC as LOADED_CTRY_CODE,
# MAGIC C21__CDY_ATTR1_DESC as DISCHARGE_CTRY_CODE,
# MAGIC C22_CPTY_SHORTNAME as CP_DEAL_MAPPING_ID,
# MAGIC C22_CPTY_SHORTNAME as ETRM_ACCOUNT_NO,
# MAGIC C23_CPTY_SUB_CATEGORY_DSC,
# MAGIC C24_CPTY_LOC,
# MAGIC C25_PHYS_FIN
# MAGIC from ALIGNE_Z_RISK_TASKFORCECPDATA_DELTA  )
# MAGIC 
# MAGIC select sum (VOLUME_TRADED) as Notional_Volume, sum(VALUE_OF_DEAL) as Notional_Value,
# MAGIC CP_DEAL_MAPPING_ID,TRADING_ENTITY,Trading_Entity_Long_Name,TRADING_DESK,
# MAGIC BUY_SELL_INDICATOR,Deal_Class,Product_Type,TRADER_NAME,DEL_MONTH,LOADED_CTRY_CODE,DISCHARGE_CTRY_CODE
# MAGIC ,VOLUME_UOM,PRICE_CURRENCY as Value_UoM
# MAGIC from raw_table group by 
# MAGIC CP_DEAL_MAPPING_ID,TRADING_ENTITY,Trading_Entity_Long_Name,TRADING_DESK,
# MAGIC BUY_SELL_INDICATOR,Deal_Class,Product_Type,TRADER_NAME,DEL_MONTH,LOADED_CTRY_CODE,DISCHARGE_CTRY_CODE
# MAGIC ,VOLUME_UOM,PRICE_CURRENCY
# MAGIC union 
# MAGIC select sum (VOLUME_TRADED) as Notional_Volume, sum(VALUE_OF_DEAL) as Notional_Value,
# MAGIC CP_DEAL_MAPPING_ID,TRADING_ENTITY,Trading_Entity_Long_Name,TRADING_DESK,
# MAGIC BUY_SELL_INDICATOR,Deal_Class,Product_Type,TRADER_NAME,DEL_MONTH,LOADED_CTRY_CODE,DISCHARGE_CTRY_CODE
# MAGIC ,VOLUME_UOM,PRICE_CURRENCY as Value_UoM
# MAGIC from raw_table_delta group by 
# MAGIC CP_DEAL_MAPPING_ID,TRADING_ENTITY,Trading_Entity_Long_Name,TRADING_DESK,
# MAGIC BUY_SELL_INDICATOR,Deal_Class,Product_Type,TRADER_NAME,DEL_MONTH,LOADED_CTRY_CODE,DISCHARGE_CTRY_CODE
# MAGIC ,VOLUME_UOM,PRICE_CURRENCY;
# MAGIC --This goes to [cp_data_hub].[deal_counterparty]

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_deal_counterparty as
# MAGIC select distinct
# MAGIC  'ALIGNE' as source_system_code
# MAGIC ,trim(CP_DEAL_MAPPING_ID) as CP_DEAL_MAPPING_ID
# MAGIC ,trim(TRADING_DESK) as deal_trading_desk
# MAGIC ,trim(TRADING_ENTITY) as deal_trading_entity
# MAGIC ,trim(Trading_Entity_Long_Name) as deal_trading_entity_long_name
# MAGIC ,trim(BUY_SELL_INDICATOR) as deal_buy_sell
# MAGIC ,trim(Deal_Class) as deal_class
# MAGIC ,trim(Product_Type) as deal_product_type
# MAGIC ,date_format(DEL_MONTH, 'yyyyMMdd') as deal_date_month_key
# MAGIC ,trim(TRADER_NAME) as deal_trader_name
# MAGIC ,trim(Value_UoM) as deal_value_unit_of_measure
# MAGIC ,trim(VOLUME_UOM) as deal_volume_unit_of_measure
# MAGIC ,cast(sum(Notional_Value)  as decimal(30,5)) as deal_notional_value
# MAGIC ,cast(sum(Notional_Volume)   as decimal(30,5)) as deal_notional_volume
# MAGIC ,current_timestamp as meta_created_dttm
# MAGIC ,current_timestamp as meta_start_dttm
# MAGIC ,cast('2999-12-31' as timestamp) as meta_end_dttm
# MAGIC ,'Y' as active_indicator
# MAGIC ,date_format(current_date, 'yyyyMMdd') as report_date_key
# MAGIC from raw_table
# MAGIC group by
# MAGIC trim(CP_DEAL_MAPPING_ID) 
# MAGIC ,trim(TRADING_DESK)
# MAGIC ,trim(TRADING_ENTITY) 
# MAGIC ,trim(Trading_Entity_Long_Name) 
# MAGIC ,trim(BUY_SELL_INDICATOR) 
# MAGIC ,trim(Deal_Class) 
# MAGIC ,trim(Product_Type) 
# MAGIC ,DEL_MONTH
# MAGIC ,trim(TRADER_NAME) 
# MAGIC ,trim(Value_UoM)
# MAGIC ,trim(VOLUME_UOM)

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'deal_counterparty', 'ALIGNE')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'deal_counterparty', 'cp_data_hub', 'deal_counterparty', 'ALIGNE')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_deal_counterparty_summary_final as
# MAGIC select distinct
# MAGIC 'ALIGNE' as source_system_code
# MAGIC ,trim(C22_CPTY_SHORTNAME) as cp_deal_mapping_id
# MAGIC ,max(cast(Latest_Trade_Date as timestamp)) as deal_latest_trade_date
# MAGIC ,max(cast(Latest_Delivery_Date as timestamp)) as deal_latest_delivery_date
# MAGIC ,concat_ws(",", array_sort((collect_set(trim(C9_TRADER_NAME))))) as deal_latest_trader_name
# MAGIC ,current_timestamp as meta_created_dttm
# MAGIC ,current_timestamp as meta_start_dttm
# MAGIC ,cast('2999-12-31' as timestamp) as meta_end_dttm
# MAGIC ,'Y'  as active_indicator
# MAGIC ,date_format(current_date, 'yyyyMMdd') as report_date_key
# MAGIC from latest_trader_name_union
# MAGIC group by 
# MAGIC trim(C22_CPTY_SHORTNAME),
# MAGIC Latest_Trade_Date,
# MAGIC Latest_Delivery_Date
# MAGIC --This goes to [cp_data_hub].[deal_counterparty_summary]

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_deal_counterparty_summary_delivery as
# MAGIC with deal_counterparty_summary as (
# MAGIC 
# MAGIC select *, 
# MAGIC 
# MAGIC row_number() over (partition by source_system_code,cp_deal_mapping_id order by deal_latest_delivery_date desc) rn from vw_deal_counterparty_summary_final t
# MAGIC )
# MAGIC select 
# MAGIC source_system_code
# MAGIC ,cp_deal_mapping_id
# MAGIC ,deal_latest_trade_date
# MAGIC ,deal_latest_delivery_date
# MAGIC ,deal_latest_trader_name
# MAGIC ,meta_created_dttm
# MAGIC ,meta_start_dttm
# MAGIC ,meta_end_dttm
# MAGIC ,active_indicator
# MAGIC ,report_date_key
# MAGIC from deal_counterparty_summary where rn = 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_deal_counterparty_summary_trade as
# MAGIC with deal_counterparty_summary as (
# MAGIC 
# MAGIC select *, 
# MAGIC 
# MAGIC row_number() over (partition by source_system_code,cp_deal_mapping_id order by deal_latest_trade_date desc) rn from vw_deal_counterparty_summary_final t
# MAGIC )
# MAGIC select 
# MAGIC source_system_code
# MAGIC ,cp_deal_mapping_id
# MAGIC ,deal_latest_trade_date
# MAGIC ,deal_latest_delivery_date
# MAGIC ,deal_latest_trader_name
# MAGIC ,meta_created_dttm
# MAGIC ,meta_start_dttm
# MAGIC ,meta_end_dttm
# MAGIC ,active_indicator
# MAGIC ,report_date_key
# MAGIC from deal_counterparty_summary where rn = 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_deal_counterparty_summary as
# MAGIC select
# MAGIC a.source_system_code
# MAGIC ,a.cp_deal_mapping_id
# MAGIC ,a.deal_latest_trade_date
# MAGIC ,b.deal_latest_delivery_date
# MAGIC ,a.deal_latest_trader_name
# MAGIC ,a.meta_created_dttm
# MAGIC ,a.meta_start_dttm
# MAGIC ,a.meta_end_dttm
# MAGIC ,a.active_indicator
# MAGIC ,a.report_date_key
# MAGIC from vw_deal_counterparty_summary_trade a, vw_deal_counterparty_summary_delivery b
# MAGIC where a.cp_deal_mapping_id = b.cp_deal_mapping_id

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'deal_counterparty_summary', 'ALIGNE')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'deal_counterparty_summary', 'cp_data_hub', 'deal_counterparty_summary', 'ALIGNE')

# COMMAND ----------

# DBTITLE 1,Function to update refresh date
RefreshDateP3('C26_UPDATED_TIMESTAMP','NULL','ALIGNE_Z_RISK_TASKFORCECPDATA_DELTA','ALIGNE')

# COMMAND ----------

Source_System_Code = 'ALIGNE'
System ='P3'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
