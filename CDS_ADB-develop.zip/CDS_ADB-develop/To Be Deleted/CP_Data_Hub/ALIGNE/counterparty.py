# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

create_temp_views_per_source_system('ALIGNE', 'ALIGNE')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view z_dg_cpty_master_unq as
# MAGIC SELECT  *
# MAGIC from
# MAGIC (
# MAGIC SELECT  distinct B.*
# MAGIC FROM
# MAGIC (
# MAGIC select c31_cpty_cpty, miN(C8_CPTY_AGEN) AS MIN_C8_CPTY_AGEN--, C1_CPTY_ACTIVE
# MAGIC FROM ALIGNE_Z_DG_CPTY_MASTER
# MAGIC GROUP BY c31_cpty_cpty--,C1_CPTY_ACTIVE
# MAGIC ) A, ALIGNE_Z_DG_CPTY_MASTER B
# MAGIC WHERE
# MAGIC A.c31_cpty_cpty=B.c31_cpty_cpty AND A.MIN_C8_CPTY_AGEN <> B.C8_CPTY_AGEN
# MAGIC and b.C1_CPTY_ACTIVE <> 1
# MAGIC --and A.c31_cpty_cpty = 'JRDSEBR'
# MAGIC union all
# MAGIC SELECT DISTINCT B.* 
# MAGIC FROM
# MAGIC (
# MAGIC select c31_cpty_cpty, miN(C8_CPTY_AGEN) AS MIN_C8_CPTY_AGEN--, C1_CPTY_ACTIVE
# MAGIC FROM ALIGNE_Z_DG_CPTY_MASTER
# MAGIC GROUP BY c31_cpty_cpty--,C1_CPTY_ACTIVE
# MAGIC ) A, ALIGNE_Z_DG_CPTY_MASTER B
# MAGIC WHERE
# MAGIC A.c31_cpty_cpty=B.c31_cpty_cpty AND A.MIN_C8_CPTY_AGEN = B.C8_CPTY_AGEN
# MAGIC --and A.c31_cpty_cpty = 'JRDSEBR'
# MAGIC ) z
# MAGIC --where c31_cpty_cpty = 'JRDSEBR'

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view z_dg_cpty_master_base as
# MAGIC SELECT DISTINCT B.* 
# MAGIC FROM
# MAGIC (
# MAGIC select c31_cpty_cpty, max(C2_CPTY_ADATE0) AS MAX_C2_CPTY_ADATE0--, C1_CPTY_ACTIVE
# MAGIC FROM z_dg_cpty_master_unq
# MAGIC GROUP BY c31_cpty_cpty--,C1_CPTY_ACTIVE
# MAGIC ) A, z_dg_cpty_master_unq B
# MAGIC WHERE
# MAGIC A.c31_cpty_cpty=B.c31_cpty_cpty AND A.MAX_C2_CPTY_ADATE0 = B.C2_CPTY_ADATE0

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view z_dg_cpty_master_created_updated as
# MAGIC select c31_cpty_cpty, min(C2_CPTY_ADATE0) as created, max(C2_CPTY_ADATE0) AS updated--, C1_CPTY_ACTIVE
# MAGIC FROM z_dg_cpty_master_unq
# MAGIC GROUP BY c31_cpty_cpty--,C1_CPTY_ACTIVE

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view z_dg_cpty_master_parent1 as
# MAGIC SELECT DISTINCT B.* 
# MAGIC FROM
# MAGIC (
# MAGIC select c.c31_cpty_cpty, max(c.C2_CPTY_ADATE0) AS MAX_C2_CPTY_ADATE0, min(c.C8_CPTY_AGEN) as MIN_C8_CPTY_AGEN
# MAGIC FROM 
# MAGIC (
# MAGIC select distinct c31_cpty_cpty, C2_CPTY_ADATE0, C8_CPTY_AGEN--, C1_CPTY_ACTIVE
# MAGIC FROM z_dg_cpty_master_unq
# MAGIC where C52_CPTY_PARENT is not null or trim(C52_CPTY_PARENT) <> ''--,C1_CPTY_ACTIVE
# MAGIC ) C
# MAGIC GROUP BY c31_cpty_cpty--,C1_CPTY_ACTIVE
# MAGIC ) A, z_dg_cpty_master_unq B
# MAGIC WHERE
# MAGIC A.c31_cpty_cpty=B.c31_cpty_cpty AND A.MAX_C2_CPTY_ADATE0 = B.C2_CPTY_ADATE0 AND A.MIN_C8_CPTY_AGEN = B.C8_CPTY_AGEN

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view z_dg_cpty_master_parent2 as
# MAGIC (
# MAGIC --Step 4. Parent & Child
# MAGIC   with child as
# MAGIC   (
# MAGIC   select * from z_dg_cpty_master_unq
# MAGIC   where C72_CPTY_TYPE != 'P'
# MAGIC   ),
# MAGIC   parent as
# MAGIC   (
# MAGIC   select * from z_dg_cpty_master_unq
# MAGIC   where C72_CPTY_TYPE = 'P'
# MAGIC   )
# MAGIC --Step 5.PARENT_CHILD
# MAGIC --Step 6. Harmonize
# MAGIC --Step 7. CLEANSE
# MAGIC   select distinct
# MAGIC   trim(child.C31_CPTY_CPTY) C31_CPTY_CPTY
# MAGIC   ,trim(parent.C31_CPTY_CPTY) as C52_CPTY_PARENT
# MAGIC   from
# MAGIC   child full outer join parent on child.C31_CPTY_CPTY || '-P' = parent.C31_CPTY_CPTY 
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view z_dg_cpty_master_parent as
# MAGIC (
# MAGIC select distinct C31_CPTY_CPTY, C52_CPTY_PARENT from
# MAGIC (
# MAGIC select * from z_dg_cpty_master_parent1 where C31_CPTY_CPTY is not null
# MAGIC --union
# MAGIC --select * from z_dg_cpty_master_parent2 where C31_CPTY_CPTY is not null and C52_CPTY_PARENT is not null
# MAGIC ) a
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view z_dg_cpty_master_base_dt as
# MAGIC select base.*,dt.created, dt.updated
# MAGIC from  z_dg_cpty_master_base base
# MAGIC left outer join
# MAGIC z_dg_cpty_master_created_updated dt
# MAGIC on base.c31_cpty_cpty = dt.c31_cpty_cpty

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view z_dg_cpty_master_base_dataset as
# MAGIC select base.*,par.C52_CPTY_PARENT as C52_CPTY_PARENT_new
# MAGIC from z_dg_cpty_master_base_dt base
# MAGIC left outer join
# MAGIC z_dg_cpty_master_parent par
# MAGIC on base.c31_cpty_cpty = par.c31_cpty_cpty

# COMMAND ----------

# MAGIC 
# MAGIC %sql
# MAGIC create or replace temporary view z_dg_cpty_master_date as
# MAGIC (
# MAGIC --Step 1. Select All
# MAGIC with raw_z_dg_cpty_master as
# MAGIC (
# MAGIC      select
# MAGIC      C1_CPTY_ACTIVE
# MAGIC     ,C8_CPTY_AGEN
# MAGIC     ,C11_CPTY_AOP0
# MAGIC     ,C2_CPTY_ADATE0
# MAGIC     ,C15_CPTY_ATIME0
# MAGIC     ,C12_CPTY_AOP1
# MAGIC     ,C3_CPTY_ADATE1
# MAGIC     ,C16_CPTY_ATIME1
# MAGIC     ,C9_CPTY_ALF
# MAGIC     ,C10_CPTY_AOHM
# MAGIC     ,C65_CPTY_ROHM
# MAGIC     ,C64_CPTY_REFRESH
# MAGIC     ,C85_CPTY_ZKEY
# MAGIC     ,C76_CPTY_XKEY
# MAGIC     ,C73_CPTY_UTIL1
# MAGIC     ,C74_CPTY_UTIL2
# MAGIC     ,C31_CPTY_CPTY
# MAGIC     ,C22_CPTY_BRO
# MAGIC     ,C75_CPTY_UVAL
# MAGIC     ,C24_CPTY_CITY
# MAGIC     ,C34_CPTY_DSC
# MAGIC     ,C0_CPTY_ACCT
# MAGIC     ,C27_CPTY_CONTACT
# MAGIC     ,C70_CPTY_TELEPHONE
# MAGIC     ,C38_CPTY_FAX
# MAGIC     ,C71_CPTY_TELEX
# MAGIC     ,C36_CPTY_EMAIL
# MAGIC     ,C4_CPTY_ADDR1
# MAGIC     ,C5_CPTY_ADDR2
# MAGIC     ,C6_CPTY_ADDR3
# MAGIC     ,C7_CPTY_ADDR4
# MAGIC     ,C72_CPTY_TYPE
# MAGIC     ,C26_CPTY_CONFIRM
# MAGIC     ,C49_CPTY_NETGROSS
# MAGIC     ,C54_CPTY_PLCCY
# MAGIC     ,C48_CPTY_NETA
# MAGIC     ,C69_CPTY_SWIFT
# MAGIC     ,C53_CPTY_PAYID
# MAGIC     --,C52_CPTY_PARENT
# MAGIC     ,C52_CPTY_PARENT_new as C52_CPTY_PARENT
# MAGIC     ,C77_CPTY_XREF
# MAGIC     ,C78_CPTY_XREF2
# MAGIC     ,C79_CPTY_XREF3
# MAGIC     ,C80_CPTY_XREF4
# MAGIC     ,C81_CPTY_XREFI
# MAGIC     ,C82_CPTY_XREFN
# MAGIC     ,C83_CPTY_XREFN2
# MAGIC     ,C25_CPTY_COMM
# MAGIC     ,C23_CPTY_CHOUSE
# MAGIC     ,C43_CPTY_LOC
# MAGIC     ,C67_CPTY_SALES
# MAGIC     ,C84_CPTY_ZGRID
# MAGIC     ,C50_CPTY_NOVATE
# MAGIC     ,C61_CPTY_PREC1
# MAGIC     ,C39_CPTY_FORM1
# MAGIC     ,C62_CPTY_PREC2
# MAGIC     ,C40_CPTY_FORM2
# MAGIC     ,C41_CPTY_IDATE
# MAGIC     ,C45_CPTY_MARG
# MAGIC     ,C42_CPTY_LIQ
# MAGIC     ,C27_CPTY_CONTACT
# MAGIC     ,C21_CPTY_BID
# MAGIC     ,C51_CPTY_OFFER
# MAGIC     ,C66_CPTY_RSET
# MAGIC     ,C44_CPTY_LOU
# MAGIC     ,C46_CPTY_MKTBASED
# MAGIC     ,C29_CPTY_COSTBASED
# MAGIC     ,C60_CPTY_PPAGMT
# MAGIC     ,C30_CPTY_COSTREF
# MAGIC     ,C57_CPTY_POWERP
# MAGIC     ,C59_CPTY_POWERT
# MAGIC     ,C55_CPTY_POWERG
# MAGIC     ,C56_CPTY_POWERL
# MAGIC     ,C58_CPTY_POWERS
# MAGIC     ,C13_CPTY_APPROVED
# MAGIC     ,C14_CPTY_APPROVEDDSC
# MAGIC     ,C63_CPTY_RECOVERYRATE
# MAGIC     ,C35_CPTY_DUNS
# MAGIC     ,C47_CPTY_NERC
# MAGIC     ,C68_CPTY_SECID
# MAGIC     ,META_CREATED_DTTM
# MAGIC     from 
# MAGIC     --z_dg_cpty_master_unq
# MAGIC     z_dg_cpty_master_base_dataset
# MAGIC  ),
# MAGIC --Step 2. DATE Table
# MAGIC  DATE as
# MAGIC  (
# MAGIC    select 
# MAGIC     z.C85_CPTY_ZKEY
# MAGIC    --,min(z.C2_CPTY_ADATE0) as CREATED
# MAGIC    ,z.created
# MAGIC    --,case when min(C2_CPTY_ADATE0) = max(C2_CPTY_ADATE0) then max(C3_CPTY_ADATE1) else max(C2_CPTY_ADATE0) end as UPDATED
# MAGIC    ,z.updated
# MAGIC    --,case when min(C2_CPTY_ADATE0) = max(C2_CPTY_ADATE0) then max(case when C3_CPTY_ADATE1 > current_date then C2_CPTY_ADATE0 else C3_CPTY_ADATE1 end) else max(C2_CPTY_ADATE0) end as UPDATED
# MAGIC    --,case when min(z.C2_CPTY_ADATE0) = max(z.C2_CPTY_ADATE0) then (select max(z1.C3_CPTY_ADATE1) from z_dg_cpty_master_unq z1 where z1.C85_CPTY_ZKEY=z.C85_CPTY_ZKEY and z1.C3_CPTY_ADATE1 < current_date) else max(z.C2_CPTY_ADATE0) end as UPDATED
# MAGIC    ,max(z.C3_CPTY_ADATE1) as Max_C3_CPTY_ADATE1
# MAGIC    from 
# MAGIC    --z_dg_cpty_master_unq z
# MAGIC    z_dg_cpty_master_base_dataset z
# MAGIC    --group by z.C85_CPTY_ZKEY
# MAGIC    group by z.C85_CPTY_ZKEY,z.created,z.updated
# MAGIC    --having z.C3_CPTY_ADATE1 < current_date
# MAGIC  )
# MAGIC --Step 3. Join
# MAGIC  select raw.*
# MAGIC  ,date.C85_CPTY_ZKEY as R_C85_CPTY_ZKEY
# MAGIC  ,date.CREATED
# MAGIC  ,date.UPDATED 
# MAGIC  ,date.Max_C3_CPTY_ADATE1
# MAGIC  from
# MAGIC  raw_z_dg_cpty_master raw inner join DATE
# MAGIC  on raw.C85_CPTY_ZKEY=date.C85_CPTY_ZKEY and raw.C3_CPTY_ADATE1=date.Max_C3_CPTY_ADATE1
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view HARMONIZE_CHILD as
# MAGIC (
# MAGIC --Step 4. Parent & Child
# MAGIC   with child as
# MAGIC   (
# MAGIC   select * from z_dg_cpty_master_date
# MAGIC   where C72_CPTY_TYPE != 'P'
# MAGIC   ),
# MAGIC   parent as
# MAGIC   (
# MAGIC   select * from z_dg_cpty_master_date
# MAGIC   where C72_CPTY_TYPE = 'P'
# MAGIC   )
# MAGIC --Step 5.PARENT_CHILD
# MAGIC --Step 6. Harmonize
# MAGIC --Step 7. CLEANSE
# MAGIC   select 
# MAGIC   child.C1_CPTY_ACTIVE
# MAGIC   ,child.C65_CPTY_ROHM
# MAGIC   ,child.C85_CPTY_ZKEY
# MAGIC   --,trim(child.C31_CPTY_CPTY) C31_CPTY_CPTY
# MAGIC   ,child.C31_CPTY_CPTY C31_CPTY_CPTY
# MAGIC   ,trim(child.C24_CPTY_CITY) C24_CPTY_CITY
# MAGIC   ,trim(child.C34_CPTY_DSC) C34_CPTY_DSC
# MAGIC   ,trim(child.C0_CPTY_ACCT) C0_CPTY_ACCT
# MAGIC   ,trim(child.C4_CPTY_ADDR1) C4_CPTY_ADDR1
# MAGIC   ,trim(child.C5_CPTY_ADDR2) C5_CPTY_ADDR2
# MAGIC   ,trim(child.C6_CPTY_ADDR3) C6_CPTY_ADDR3
# MAGIC   ,trim(child.C7_CPTY_ADDR4) C7_CPTY_ADDR4
# MAGIC   ,child.C43_CPTY_LOC
# MAGIC   ,child.C72_CPTY_TYPE
# MAGIC   ,child.C52_CPTY_PARENT
# MAGIC   ,child.C13_CPTY_APPROVED
# MAGIC   ,child.CREATED
# MAGIC   ,child.UPDATED  
# MAGIC   ,child.Max_C3_CPTY_ADATE1
# MAGIC   ,parent.C1_CPTY_ACTIVE as PARENT_C1_CPTY_ACTIVE
# MAGIC   ,parent.C65_CPTY_ROHM as PARENT_C65_CPTY_ROHM
# MAGIC   ,parent.C85_CPTY_ZKEY  as PARENT_C85_CPTY_ZKEY
# MAGIC   --,trim(parent.C31_CPTY_CPTY) as PARENT_C31_CPTY_CPTY
# MAGIC   ,parent.C31_CPTY_CPTY  as PARENT_C31_CPTY_CPTY
# MAGIC   ,trim(parent.C24_CPTY_CITY) as PARENT_C24_CPTY_CITY
# MAGIC   ,trim(parent.C34_CPTY_DSC)as PARENT_C34_CPTY_DSC
# MAGIC   ,trim(parent.C0_CPTY_ACCT)as PARENT_C0_CPTY_ACCT
# MAGIC   ,trim(parent.C4_CPTY_ADDR1) as PARENT_C4_CPTY_ADDR1
# MAGIC   ,trim(parent.C5_CPTY_ADDR2) as PARENT_C5_CPTY_ADDR2
# MAGIC   ,trim(parent.C6_CPTY_ADDR3) as PARENT_C6_CPTY_ADDR3
# MAGIC   ,trim(parent.C7_CPTY_ADDR4) as PARENT_C7_CPTY_ADDR4
# MAGIC   ,parent.C72_CPTY_TYPE as PARENT_C72_CPTY_TYPE
# MAGIC   ,parent.C52_CPTY_PARENT as PARENT_C52_CPTY_PARENT
# MAGIC   ,parent.C13_CPTY_APPROVED as PARENT_C13_CPTY_APPROVED
# MAGIC   ,parent.CREATED as PARENT_CREATED
# MAGIC   ,parent.Max_C3_CPTY_ADATE1 as R_Max_C3_CPTY_ADATE1
# MAGIC   ,case when child.META_CREATED_DTTM is null 
# MAGIC      then parent.META_CREATED_DTTM else child.META_CREATED_DTTM 
# MAGIC    end as META_CREATED_DTTM
# MAGIC   from
# MAGIC   child full outer join parent on child.C52_CPTY_PARENT = parent.C31_CPTY_CPTY
# MAGIC )b

# COMMAND ----------

#parameterize base folder
dbutils.widgets.text("pm_adls_proj_folder", "P00014-Cross_Comm-CPData-DEV")
v_adls_folder = dbutils.widgets.get("pm_adls_proj_folder")

#derive final paths
adls_file_path_full_src = f"/mnt/ADLS/PROJECT/{v_adls_folder}/cp-data-hub/staging/aligne/processing_cp/"
partition_by_cols_stg= ['META_CREATED_DTTM']

# COMMAND ----------

df = spark.sql("select * from HARMONIZE_CHILD")
df.write.format('delta').mode("overwrite").option("overwriteSchema","true").partitionBy(partition_by_cols_stg).save(adls_file_path_full_src)

# COMMAND ----------

aligne_df  = spark.read.format('delta').load(adls_file_path_full_src)

# COMMAND ----------

aligne_df.createOrReplaceTempView("HARMONIZE_CHILD")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_l1_l2_id as
# MAGIC select distinct PARENT_C31_CPTY_CPTY as L1_ID, C31_CPTY_CPTY as L2_ID
# MAGIC from HARMONIZE_CHILD

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view zcpty_data_limit_unq as
# MAGIC SELECT DISTINCT B.* 
# MAGIC FROM
# MAGIC (
# MAGIC select C0_COUNTERPARTY_ID, max(C2_CREATION_DATE) AS MAX_C2_CREATION_DATE--, C1_CPTY_ACTIVE
# MAGIC FROM ALIGNE_ZCPTY_DATA_LIMIT
# MAGIC WHERE C13_LIMIT_ACTIVE = 1
# MAGIC GROUP BY C0_COUNTERPARTY_ID--,C1_CPTY_ACTIVE
# MAGIC ) A, ALIGNE_ZCPTY_DATA_LIMIT B
# MAGIC WHERE
# MAGIC A.C0_COUNTERPARTY_ID=B.C0_COUNTERPARTY_ID AND A.MAX_C2_CREATION_DATE = B.C2_CREATION_DATE

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view zcpty_data_limit_base as
# MAGIC SELECT  *
# MAGIC from
# MAGIC (
# MAGIC SELECT DISTINCT B.* 
# MAGIC FROM
# MAGIC (
# MAGIC select C0_COUNTERPARTY_ID, miN(C12_LIMIT_AGEN) AS MIN_C12_LIMIT_AGEN--, C13_LIMIT_ACTIVE
# MAGIC FROM zcpty_data_limit_unq
# MAGIC GROUP BY C0_COUNTERPARTY_ID--,C13_LIMIT_ACTIVE
# MAGIC ) A, zcpty_data_limit_unq B
# MAGIC WHERE
# MAGIC A.C0_COUNTERPARTY_ID=B.C0_COUNTERPARTY_ID AND A.MIN_C12_LIMIT_AGEN = B.C12_LIMIT_AGEN
# MAGIC --and A.c31_cpty_cpty = 'JRDSEBR'
# MAGIC ) z
# MAGIC --where C0_COUNTERPARTY_ID = 'CENGIZB-P'

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view zcpty_data_limit_filter as
# MAGIC select distinct C0_COUNTERPARTY_ID,
# MAGIC C2_CREATION_DATE,
# MAGIC C5_MODIFICATION_DATE,
# MAGIC C7_LIMIT_FUNCTION_DESC,
# MAGIC C13_LIMIT_ACTIVE
# MAGIC  from
# MAGIC zcpty_data_limit_base
# MAGIC where (C7_LIMIT_FUNCTION_DESC = 'E-RATED' or C7_LIMIT_FUNCTION_DESC like '%ON STOP%') and C13_LIMIT_ACTIVE = 1
# MAGIC --where (C7_LIMIT_FUNCTION_DESC = 'E-RATED' ) and C13_LIMIT_ACTIVE = 1
# MAGIC order by C0_COUNTERPARTY_ID asc, C2_CREATION_DATE desc

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_l1_l2_id_1 as
# MAGIC select mast.*
# MAGIC from vw_l1_l2_id mast, zcpty_data_limit_filter lim
# MAGIC where mast.l1_id=lim.C0_COUNTERPARTY_ID

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_l1_l2_id_2 as
# MAGIC (
# MAGIC select * from vw_l1_l2_id
# MAGIC except
# MAGIC select * from vw_l1_l2_id_1
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_limit_1 as
# MAGIC select mast.L1_ID, cast(lim.C2_CREATION_DATE as timestamp) as ERATE_DATE, 
# MAGIC case when mast.L1_ID = lim.C0_COUNTERPARTY_ID then 'Y' else 'N' end as ERATED
# MAGIC from vw_l1_l2_id_1 mast left join zcpty_data_limit_filter lim
# MAGIC on mast.l1_id=lim.C0_COUNTERPARTY_ID

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_limit_2 as
# MAGIC select mast.L2_ID, cast(lim.C2_CREATION_DATE as timestamp) as ERATE_DATE, 
# MAGIC case when mast.L2_ID = lim.C0_COUNTERPARTY_ID then 'Y' else 'N' end as ERATED
# MAGIC from vw_l1_l2_id_2 mast left join zcpty_data_limit_filter lim
# MAGIC on mast.l2_id=lim.C0_COUNTERPARTY_ID

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_mast_1 as
# MAGIC select mast.*, lim.*
# MAGIC from HARMONIZE_CHILD mast, vw_limit_1 lim
# MAGIC where mast.PARENT_C31_CPTY_CPTY=lim.L1_ID

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_mast_2 as
# MAGIC select mast.*, lim.*
# MAGIC from HARMONIZE_CHILD mast, vw_limit_2 lim
# MAGIC where mast.C31_CPTY_CPTY=lim.L2_ID

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view HARMONIZE as
# MAGIC ( 
# MAGIC   select * from vw_mast_1
# MAGIC   union
# MAGIC   select * from vw_mast_2
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view CPTY_TYPE as
# MAGIC select C72_CPTY_TYPE as CPTY_TYPE, C88_CPTY_CODE_DESC as CPTY_TYPE_DESC from (
# MAGIC select distinct C72_CPTY_TYPE , C88_CPTY_CODE_DESC from z_dg_cpty_master_unq order by C72_CPTY_TYPE
# MAGIC ) a

# COMMAND ----------

# MAGIC %sql
# MAGIC --create or replace temporary view UNIONED_HARMONIZED as
# MAGIC create or replace temporary view Final_Harmonize as
# MAGIC --( 
# MAGIC --Step 9. Join
# MAGIC -- with Left_Hamonize_cpty_type as
# MAGIC -- (
# MAGIC   select distinct HARMONIZE.*
# MAGIC   ,CPTY_TYPE.CPTY_TYPE as Left_Right_CPTY_TYPE
# MAGIC   ,CPTY_TYPE.CPTY_TYPE_DESC as CPTY_TYPE_DESC
# MAGIC   ,regexp_replace(trim(C0_CPTY_ACCT), '^[0]*', '') as C0_CPTY_ACCT_RPLC
# MAGIC   from 
# MAGIC   HARMONIZE left join CPTY_TYPE on HARMONIZE.C72_CPTY_TYPE = CPTY_TYPE.CPTY_TYPE
# MAGIC -- ),
# MAGIC  --Joined_Hamonize_cpty_type as
# MAGIC -- (
# MAGIC  -- select HARMONIZE.*
# MAGIC  -- ,CPTY_TYPE.CPTY_TYPE as Left_Right_CPTY_TYPE	
# MAGIC   --,CPTY_TYPE.CPTY_TYPE_DESC
# MAGIC   --from 
# MAGIC  -- HARMONIZE inner join CPTY_TYPE on HARMONIZE.C72_CPTY_TYPE = CPTY_TYPE.CPTY_TYPE
# MAGIC -- )
# MAGIC  
# MAGIC --Step 10. UNIONED_HARMONIZED
# MAGIC  -- select * from Left_Hamonize_cpty_type
# MAGIC  -- union
# MAGIC  -- select * from Joined_Hamonize_cpty_type
# MAGIC --)

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view Unioned_final_harmonised as
# MAGIC (
# MAGIC select distinct * from
# MAGIC ( 
# MAGIC --Step 13. Filter
# MAGIC -- with Final_Harmonize_TRUE as
# MAGIC -- (
# MAGIC -- select Final_Harmonize.*
# MAGIC -- from Final_Harmonize where
# MAGIC -- regexp_replace(trim(C0_CPTY_ACCT), '^[0]*', '') != "" AND C0_CPTY_ACCT is not Null
# MAGIC -- ),
# MAGIC -- Final_Harmonize_FALSE as
# MAGIC -- (
# MAGIC -- select Final_Harmonize.*, cast(Null as string) as RowCount 
# MAGIC -- from Final_Harmonize where
# MAGIC -- regexp_replace(trim(C0_CPTY_ACCT), '^[0]*', '')= "" or C0_CPTY_ACCT is Null
# MAGIC -- ),
# MAGIC  --Final_Harmonize_TRUE_RC as
# MAGIC -- (
# MAGIC  --select Final_Harmonize_TRUE.*,'1' as RowCount from Final_Harmonize_TRUE
# MAGIC  --union all
# MAGIC  --select Final_Harmonize_TRUE.*,'2' as RowCount from Final_Harmonize_TRUE
# MAGIC  select Final_Harmonize.*,'1' as RowCount from Final_Harmonize where C0_CPTY_ACCT_RPLC != "" AND C0_CPTY_ACCT is not Null
# MAGIC  union all
# MAGIC  select Final_Harmonize.*,'2' as RowCount from Final_Harmonize where C0_CPTY_ACCT_RPLC != "" AND C0_CPTY_ACCT is not Null
# MAGIC  union all
# MAGIC  select Final_Harmonize.*, cast(Null as string) as RowCount from Final_Harmonize where C0_CPTY_ACCT_RPLC = "" or C0_CPTY_ACCT is Null
# MAGIC -- )
# MAGIC -- select * from Final_Harmonize_TRUE_RC
# MAGIC -- union
# MAGIC -- select * from Final_Harmonize_FALSE
# MAGIC ) 
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC --create or replace temporary view vw_cp_aligne_master_stg as
# MAGIC create or replace temporary view vw_cp_aligne_master_final as
# MAGIC (  
# MAGIC select distinct 
# MAGIC 
# MAGIC        'ALIGNE' || case when PARENT_C31_CPTY_CPTY is not null then '_' || PARENT_C31_CPTY_CPTY else '_' end || case when C31_CPTY_CPTY is not null then '_' || C31_CPTY_CPTY else '_' end  as UNIQUE_ID
# MAGIC      , PARENT_C34_CPTY_DSC as cp_legal_entity_name
# MAGIC      , PARENT_C31_CPTY_CPTY as L1_ID --Counterparty Legal Entity ID
# MAGIC      , C31_CPTY_CPTY as L2_ID --Counterparty Business Unit ID
# MAGIC      , C34_CPTY_DSC as cp_business_unit_name --Counterparty Business Unit Name
# MAGIC      , CPTY_TYPE_DESC as ENTITY_TYPE
# MAGIC      , case when   C13_CPTY_APPROVED = 'N' or   C1_CPTY_ACTIVE = 0 then 'Y' else 'N' end AS DELETED      
# MAGIC      , cast(CREATED as timestamp) as CREATED --Counterparty Create Date (ETRM) Counterparty Update Date (ETRM)
# MAGIC      , cast(UPDATED as timestamp) as UPDATED
# MAGIC      , C0_CPTY_ACCT_RPLC as SAP_ACCOUNT_NO --Linked SAP Account Number
# MAGIC      , 'ALIGNE' as System
# MAGIC      , IF(C0_CPTY_ACCT_RPLC= "" or C0_CPTY_ACCT is Null, Null, 
# MAGIC        IF(RowCount = 1, 'Customer', 'Vendor')) as SAP_CPTY_TYPE --Linked SAP Account Counterparty Type (Customer/Vendor in ETRM)
# MAGIC      ,PARENT_C31_CPTY_CPTY as PARENT
# MAGIC      , if(C43_CPTY_LOC is not Null, C43_CPTY_LOC, trim(concat(C6_CPTY_ADDR3," ",C7_CPTY_ADDR4))) as COUNTRY --Account country of registration 
# MAGIC      , IF(C0_CPTY_ACCT_RPLC= "" or C0_CPTY_ACCT is Null, Null, 'STNSAP') as SAP_SYSTEM --Linked SAP System
# MAGIC 
# MAGIC      , trim(concat(C4_CPTY_ADDR1," ",C5_CPTY_ADDR2)) as ADDRESS
# MAGIC      , if(C34_CPTY_DSC is Null, PARENT_C34_CPTY_DSC, C34_CPTY_DSC) as NAME
# MAGIC      , IF(C0_CPTY_ACCT_RPLC= "" or C0_CPTY_ACCT is Null, Null, 
# MAGIC        concat('STNSAP_', IF(RowCount = 1, 'Customer', 'Vendor'), '_', (C0_CPTY_ACCT_RPLC))) as SAP_UNIQUE_ID
# MAGIC      , C0_CPTY_ACCT as L1_ID_NEW
# MAGIC      , C72_CPTY_TYPE as L2_TYPE
# MAGIC      , C34_CPTY_DSC as L2_NAME1
# MAGIC      --concat(SAP_SYSTEM,'_',SAP_CPTY_TYPE,'_',SAP_ACCOUNT_NO) as Linked_SAP_Unique_ID --ETRM Linked SAP Unique ID
# MAGIC      , IF(C0_CPTY_ACCT_RPLC= "" or C0_CPTY_ACCT is Null, Null, 'STNSAP') || '_',
# MAGIC      IF(C0_CPTY_ACCT_RPLC= "" or C0_CPTY_ACCT is Null, Null, 
# MAGIC        IF(RowCount = 1, 'Customer', 'Vendor')) || '_',
# MAGIC        C0_CPTY_ACCT_RPLC as Linked_SAP_Unique_ID,
# MAGIC        'ALIGNE' as source_system,
# MAGIC        cast(META_CREATED_DTTM as timestamp) as META_CREATED_DTTM,
# MAGIC        ERATE_DATE,
# MAGIC         ERATED
# MAGIC from
# MAGIC       Unioned_final_harmonised
# MAGIC       where trim(CPTY_TYPE_DESC)="BROKER" or trim(CPTY_TYPE_DESC)="COUNTERPARTY"
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_aligne as
# MAGIC select distinct
# MAGIC UNIQUE_ID,
# MAGIC cp_legal_entity_name,
# MAGIC L1_ID,
# MAGIC L2_ID,
# MAGIC cp_business_unit_name,
# MAGIC ENTITY_TYPE,
# MAGIC DELETED,
# MAGIC CREATED,
# MAGIC UPDATED,
# MAGIC SAP_ACCOUNT_NO,
# MAGIC System,
# MAGIC SAP_CPTY_TYPE,
# MAGIC PARENT,
# MAGIC COUNTRY,
# MAGIC SAP_SYSTEM,
# MAGIC ADDRESS,
# MAGIC NAME,
# MAGIC SAP_UNIQUE_ID,
# MAGIC L1_ID_NEW,
# MAGIC L2_TYPE,
# MAGIC L2_NAME1,
# MAGIC Linked_SAP_Unique_ID,
# MAGIC ERATE_DATE,
# MAGIC ERATED,
# MAGIC source_system,
# MAGIC META_CREATED_DTTM
# MAGIC from vw_cp_aligne_master_final

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty as 
# MAGIC select distinct 
# MAGIC     UNIQUE_ID                               as cp_unique_id                      --REQ-26
# MAGIC     ,L1_ID                                  as cp_legal_entity_id                          --REQ-28
# MAGIC     ,case when cp_business_unit_name is null or length(cp_business_unit_name) = 0 then cp_legal_entity_name
# MAGIC          else cp_business_unit_name end     as cp_name                           --REQ-27
# MAGIC               
# MAGIC     ,L2_ID                                  as cp_business_unit_id                          --REQ-29
# MAGIC     ,cp_business_unit_name                  as cp_business_unit_name                        --REQ-30  
# MAGIC     ,cast(null as string)                   as cp_short_name
# MAGIC     ,CREATED                                as cp_created_date
# MAGIC     ,UPDATED                                as cp_updated_date    
# MAGIC     --ENTITY_TYPE              as cp_entity_type,                    --REQ-31
# MAGIC     --case when CREATED is null 
# MAGIC     --  then UPDATED else CREATED
# MAGIC     --end                      as cp_created_or_updated_date,        --REQ-34
# MAGIC     --greatest(CREATED,UPDATED) as cp_created_or_updated_date,
# MAGIC     ,case when DELETED is null 
# MAGIC       then '' else DELETED
# MAGIC     end                                     as cp_deactivated                    --REQ-32
# MAGIC     --COUNTRY                  as cp_country,                        --REQ-91
# MAGIC     --PARENT                   as cp_parent,                         --REQ-87
# MAGIC     --System                   as cp_system,                         --REQ-36
# MAGIC     --SAP_ACCOUNT_NO           as cp_linked_sap_id,                  --REQ-93
# MAGIC     --SAP_CPTY_TYPE            as cp_sap_account_type,               --REQ-38
# MAGIC     --SAP_UNIQUE_ID            as cp_sap_unique_id,                  --REQ-97 # changed on 8/25/2021 rasied as bug that not having SAP_AccountType_AccountNo
# MAGIC --     Linked_sap_unique_id     as cp_sap_unique_id,               --REQ-97
# MAGIC     --SAP_SYSTEM               as cp_linked_sap_system,              --REQ-93\
# MAGIC     
# MAGIC     --case when (Linked_sap_unique_id is null or length(trim(Linked_sap_unique_id)) = 0 ) 
# MAGIC     --  then 'NO SAP LINK' ELSE 'SAP LINK' 
# MAGIC     --END                      as cp_sap_link,                       
# MAGIC     ,ERATED                                 as cp_erate_flag_source           --REQ-9
# MAGIC     ,ERATE_DATE                             as cp_erate_date_source           --REQ-10
# MAGIC     ,ERATED                                 as cp_erate_flag
# MAGIC     ,ERATE_DATE                             as cp_erate_date   
# MAGIC     ,case when L2_ID is null                                  
# MAGIC       then L1_ID else L2_ID
# MAGIC     end                                     as cp_account_number   
# MAGIC     ,L2_ID                                  as cp_deal_mapping_id
# MAGIC     ,current_timestamp                      as meta_created_ddtm
# MAGIC     ,current_timestamp                      as meta_start_ddtm
# MAGIC     , to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
# MAGIC     ,'Y'                                    as active_indicator
# MAGIC     ,'ALIGNE'                               as source_system_code
# MAGIC     ,date_format(current_date, 'yyyyMMdd')  as report_date_key    
# MAGIC     --cast(null as string)     as cp_erate_lifted_date_in_source,    --REQ-11
# MAGIC     --cast(null as string)     as cp_broker_indicator,               --REQ-86
# MAGIC     --L2_ID                    as cp_mapping_id,
# MAGIC     --source_system,                                                 --Metadata Column       
# MAGIC     --META_CREATED_DTTM        as meta_created_dttm                  --Metadata Column       
# MAGIC from vw_cp_master_aligne

# COMMAND ----------

cp_df = spark.sql("select * from vw_counterparty")
cp_df = cp_df.drop_duplicates()
total_row_cnt = cp_df.count()
print (total_row_cnt)
cp_unique_id_df = cp_df.select(["cp_unique_id"])
cp_unique_id_df = cp_unique_id_df.drop_duplicates()
cp_unique_id_cnt= cp_unique_id_df.count()
print(cp_unique_id_cnt)
try:
  #if total_row_cnt == cp_unique_id_cnt:
  #  RefreshCuratedSqlTbl('staging', 'counterparty', 'ALIGNE')
  RefreshCuratedSqlTbl('staging', 'counterparty', 'ALIGNE')
except Exception as e:
  print("For ALIGNE source system counterparty count vs unique_id cnt didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'counterparty', 'cp_data_hub', 'counterparty', 'ALIGNE')

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['counterparty']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

cp_details_df = spark.sql("""
                          select distinct
                             UNIQUE_ID               as cp_unique_id
                            ,cast(NULL as string)          as cp_company_code
                            ,cast(NULL as string)          as cp_company_name
                            ,COUNTRY          as cp_country_code
                            ,cast(NULL as string)      as cp_country_name
                            ,ENTITY_TYPE          as counterparty_type
                            ,current_timestamp               as meta_created_ddtm
                            ,current_timestamp               as meta_start_ddtm
                            ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                            ,'Y'                                   as active_indicator
                            ,'ALIGNE'                         as source_system_code
                            ,date_format(current_date, 'yyyyMMdd') as  report_date_key
                           from vw_cp_master_aligne
                           where COUNTRY is not null
                           and length(COUNTRY)>0
                          """)
#creating temp view
cp_details_df.createOrReplaceTempView("vw_counterparty_details")

# need to get the distinct unique_id counts
cp_details_cp_unique_id_cnt = cp_details_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_counterparty_details cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)                               
#load process
try:
  if cp_unique_id_cnt >= cp_details_cp_unique_id_cnt and cp_unique_id_not_in_cp_df.count()==0:
    print(f"""Count Match: {cp_unique_id_cnt} and {cp_details_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of counterparty_details is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'counterparty_details', 'ALIGNE')
except Exception as e:
  print("For ALIGNE source system counterparty count and counterparty Details unique_id didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'counterparty_details', 'cp_data_hub', 'counterparty_details', 'ALIGNE')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details_summary as
# MAGIC   
# MAGIC   
# MAGIC 			select cpd.source_system_code
# MAGIC 			      ,cpd.cp_unique_id
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(counterparty_type))) as counterparty_type
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_code))) as cp_company_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_name))) as cp_company_name
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_code))) as cp_country_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_name))) as cp_country_name
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 				  from vw_counterparty_details cpd
# MAGIC 				  where cpd.source_system_code  in ('ALIGNE')
# MAGIC 			group by cpd.source_system_code, cpd.cp_unique_id
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details_summary', 'ALIGNE')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details_summary', 'cp_data_hub', 'counterparty_details_summary', 'ALIGNE')

# COMMAND ----------

bdg_cp_sap_account_df = spark.sql("""
                                 select distinct 
                                    align.UNIQUE_ID               as cp_unique_id
                                   ,align.sap_unique_id              as sap_unique_id
                                   ,align.sap_account_no             as sap_account_number
                                   ,align.SAP_CPTY_TYPE           as sap_account_type
                                   ,align.SAP_SYSTEM          as sap_source_system_code
                                   ,current_timestamp               as meta_created_ddtm
                                   ,current_timestamp               as meta_start_ddtm
                                   ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                                   ,'Y'                                   as active_indicator
                                   ,'ALIGNE'                          as source_system_code
                                   ,date_format(current_date, 'yyyyMMdd') as  report_date_key 
                                from vw_cp_master_aligne align
                                where align.sap_unique_id is not null and length(align.sap_unique_id) > 0
                                """)
#creating temp view
bdg_cp_sap_account_df.createOrReplaceTempView("vw_bridge_counterparty_sap_account")

# need to get the distinct unique_id counts
bdg_cp_sap_account_cp_unique_id_cnt = bdg_cp_sap_account_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
bdg_cp_sap_account_cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_bridge_counterparty_sap_account cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)
                                       
#load process
if cp_unique_id_cnt >= bdg_cp_sap_account_cp_unique_id_cnt and bdg_cp_sap_account_cp_unique_id_not_in_cp_df.count()==0:
  try:
  
    print(f"""Count Match: {cp_unique_id_cnt} and {bdg_cp_sap_account_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of bridge_counterparty_sap_account is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'bridge_counterparty_sap_account', 'ALIGNE')
  
  except Exception as e:
    print("For ALIGNE source system counterparty count and bridge_counterparty_sap_accnt cp_unique_id didn't match")
    raise dbutils.notebook.exit(e)
elif {cp_unique_id_cnt} < {bdg_cp_sap_account_cp_unique_id_cnt}: 
  print(f"""counterparty: {cp_unique_id_cnt}""")
  print(f"""bridge_counterparty_sap_account: {bdg_cp_sap_account_cp_unique_id_cnt}""")
  print("Count match is not working ")
else:
  print(f"""cp_unique_id exists in bridge counterparty sap account table but in counterparty table""")

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'bridge_counterparty_sap_account', 'cp_data_hub', 'bridge_counterparty_sap_account', 'ALIGNE')

# COMMAND ----------

Source_System_Code = 'ALIGNE'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
