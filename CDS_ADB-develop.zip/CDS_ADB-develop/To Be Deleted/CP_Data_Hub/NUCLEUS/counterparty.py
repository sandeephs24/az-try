# Databricks notebook source
# MAGIC %sql CLEAR CACHE

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/custom_functions/custom_functions"

# COMMAND ----------

create_temp_views_per_source_system('NUCLEUS', 'NUCLEUS_PRD')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_cp_master_nucleus as
# MAGIC select 
# MAGIC 'NUCLEUS_' ||  cast(C.COMPANY_KEY as int)  as UNIQUE_ID, 
# MAGIC C.LONG_NAME as NAME, 
# MAGIC C.COMPANY_KEY as L1_ID,
# MAGIC CASE WHEN LE.CY_ENTITY_KEY IS NOT NULL THEN 'INTERNAL' ELSE 'EXTERNAL' END COMPANY_TYPE, 
# MAGIC CASE WHEN C.ACTIVE_FLAG = 'Y' THEN 'N' ELSE 'Y' END AS DEACTIVATED,
# MAGIC cast(C.CREATE_DATE as timestamp) as CREATED,
# MAGIC cast(C.MODIFY_DATE as timestamp) as UPDATED,
# MAGIC TRIM(LEADING '0' FROM VMV.VENDOR_ID)  as SAP_ACCOUNT_NO,
# MAGIC 'NUCLEUS' as SYSTEM,
# MAGIC CASE WHEN VMV.VENDOR_ID IS NOT NULL THEN 'Vendor' ELSE NULL END as SAP_CPTY_TYPE,
# MAGIC CA.STE_COU_COUNTRY_CODE as COUNTRY,
# MAGIC CASE WHEN VMV.VENDOR_ID IS NOT NULL THEN 'STNSAP' ELSE NULL END as SAP_SYSTEM,
# MAGIC CASE WHEN VMV.VENDOR_ID IS NOT NULL THEN 'STNSAP_' || 'Vendor_' || TRIM(LEADING '0' FROM VMV.VENDOR_ID) ELSE NULL END as SAP_UNIQUE_ID,
# MAGIC 'NUCLEUS' as source_system,
# MAGIC cast(C.meta_created_dttm as timestamp) as meta_created_dttm
# MAGIC from nucleus_prd_COMPANIES C
# MAGIC LEFT JOIN nucleus_prd_LEGAL_ENTITIES LE -- for COMPANY_TYPE
# MAGIC ON C.COMPANY_KEY = LE.CY_ENTITY_KEY
# MAGIC LEFT JOIN (SELECT VENDOR_ID, SHORTNAME -- for SAP_ACCOUNT_NO
# MAGIC FROM nucleus_prd_VENDOR_MASTER_VIEW VMV
# MAGIC GROUP BY VENDOR_ID, SHORTNAME) VMV
# MAGIC ON NVL(C.COMPANY_CODE, C.SHORT_NAME) = VMV.SHORTNAME
# MAGIC LEFT JOIN (SELECT CO_CY_COMPANY_KEY, STE_COU_COUNTRY_CODE -- for COUNTRY
# MAGIC FROM nucleus_prd_COMPANY_ADDRESSES
# MAGIC GROUP BY CO_CY_COMPANY_KEY, STE_COU_COUNTRY_CODE) CA
# MAGIC ON C.COMPANY_KEY = CA.CO_CY_COMPANY_KEY
# MAGIC ORDER BY L1_ID ASC;

# COMMAND ----------

nuc_country_code_df = spark.sql("select unique_id, COUNTRY from vw_cp_master_nucleus")
nuc_country_code_df = nuc_country_code_df.groupby("unique_id").agg(sort_array(collect_set(col("country"))).alias("country_arry"))
nuc_country_code_df = nuc_country_code_df.withColumn("country", concat_ws(",", col("country_arry"))).drop("country_arry")
nuc_country_code_df.createOrReplaceTempView("vw_concat_country_code")

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['erate_salesforce']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty as 
# MAGIC select distinct
# MAGIC      cpm.UNIQUE_ID                             as cp_unique_id                -- req-26
# MAGIC     ,cpm.L1_ID                                 as cp_legal_entity_id          -- l1_id (req-28)
# MAGIC     ,cpm.NAME                                  as cp_name                     --  l1_name (req-27)
# MAGIC     ,cast(null as string)                      as cp_business_unit_id         -- l2_id (req-29)
# MAGIC     ,cast(null as string)                      as cp_business_unit_name       -- l2_name (req-30)
# MAGIC     ,cast(null as string)                      as cp_short_name
# MAGIC     ,cpm.CREATED                               as cp_created_date
# MAGIC     ,cpm.UPDATED                               as cp_updated_date    
# MAGIC     ,cpm.DEACTIVATED                           as cp_deactivated              -- req-32
# MAGIC     ,cpm.DEACTIVATED                           as cp_erate_flag_source        -- PBI #958877 (WHEN C.ACTIVE_FLAG = 'Y' THEN 'N' ELSE 'Y' END)
# MAGIC     ,cast(null as string)                      as cp_erate_date_source        -- REQ-10  
# MAGIC     ,cpm.DEACTIVATED                           as cp_erate_flag               -- PBI #958877
# MAGIC     ,case when cpm.DEACTIVATED='Y' then to_date(er.erate_completion_date, 'yyyy-MM-dd') else null end as cp_erate_date    -- PBI #958877   
# MAGIC     ,cpm.L1_ID                                 as cp_account_number
# MAGIC     ,cpm.L1_ID                                 as cp_deal_mapping_id
# MAGIC     ,current_timestamp                         as meta_created_ddtm
# MAGIC     ,current_timestamp                         as meta_start_ddtm
# MAGIC     , to_date('2999-12-31', 'yyyy-MM-dd')      as meta_end_ddtm
# MAGIC     ,'Y'                                       as active_indicator
# MAGIC     ,'NUCLEUS'                                 as source_system_code
# MAGIC     ,date_format(current_date, 'yyyyMMdd')     as report_date_key
# MAGIC from       vw_cp_master_nucleus   cpm
# MAGIC left join  vw_concat_country_code cntry  on cpm.UNIQUE_ID = cntry.unique_id 
# MAGIC left join vw_cp_data_hub_erate_salesforce   er   on (cpm.UNIQUE_ID = er.cp_unique_id and er.source_system ='NUCLEUS')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_detail_temp as 
# MAGIC select distinct
# MAGIC      cpm.UNIQUE_ID                             as cp_unique_id                -- req-26
# MAGIC     ,cntry.COUNTRY                             as cp_country                  -- req-91
# MAGIC     ,cpm.COMPANY_TYPE                          as cp_entity_type
# MAGIC from       vw_cp_master_nucleus   cpm
# MAGIC left join  vw_concat_country_code cntry  on cpm.UNIQUE_ID = cntry.unique_id 

# COMMAND ----------

cp_df = spark.sql("select * from vw_counterparty")
cp_df = cp_df.drop_duplicates()
total_row_cnt = cp_df.count()
print (total_row_cnt)
cp_unique_id_df = cp_df.select(["cp_unique_id"])
cp_unique_id_df = cp_unique_id_df.drop_duplicates()
cp_unique_id_cnt= cp_unique_id_df.count()
print(cp_unique_id_cnt)
try:
  if total_row_cnt == cp_unique_id_cnt:
    RefreshCuratedSqlTbl('staging', 'counterparty', 'NUCLEUS')
except Exception as e:
  print("For NUCLEUS source system counterparty count vs unique_id cnt didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'counterparty', 'cp_data_hub', 'counterparty', 'NUCLEUS')

# COMMAND ----------

tgt_curated_schema_name = 'cp_data_hub'
tgt_curated_tables_list = ['counterparty']
for table_name in tgt_curated_tables_list:
  df = spark.read.jdbc(Stratos_sqldb_URL_curated, table=f'{tgt_curated_schema_name}.{table_name}')
  df.createOrReplaceTempView(f"vw_{tgt_curated_schema_name}_{table_name}")
  print(f"vw_{tgt_curated_schema_name}_{table_name}")

# COMMAND ----------

cp_details_df = spark.sql("""
                          select distinct
                             cp_unique_id               as cp_unique_id
                            ,cast(NULL as string)          as cp_company_code
                            ,cast(NULL as string)          as cp_company_name
                            ,cp_country          as cp_country_code
                            ,cast(NULL as string)      as cp_country_name
                            ,cp_entity_type          as counterparty_type
                            ,current_timestamp               as meta_created_ddtm
                            ,current_timestamp               as meta_start_ddtm
                            ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                            ,'Y'                                   as active_indicator
                            ,'NUCLEUS'                         as source_system_code
                            ,date_format(current_date, 'yyyyMMdd') as  report_date_key
                           from vw_counterparty_detail_temp
                           where cp_country is not null
                           and length(cp_country)>0
                          """)
#creating temp view
cp_details_df.createOrReplaceTempView("vw_counterparty_details")

# need to get the distinct unique_id counts
cp_details_cp_unique_id_cnt = cp_details_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_counterparty_details cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)                               
#load process
try:
  if cp_unique_id_cnt >= cp_details_cp_unique_id_cnt and cp_unique_id_not_in_cp_df.count()==0:
    print(f"""Count Match: {cp_unique_id_cnt} and {cp_details_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of counterparty_details is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'counterparty_details', 'NUCLEUS')
except Exception as e:
  print("For NUCLEUS source system counterparty count and counterparty Details unique_id didn't match")
  raise dbutils.notebook.exit(e)

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'counterparty_details', 'cp_data_hub', 'counterparty_details', 'NUCLEUS')

# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace temporary view vw_counterparty_details_summary as
# MAGIC   
# MAGIC   
# MAGIC 			select cpd.source_system_code
# MAGIC 			      ,cpd.cp_unique_id
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(counterparty_type))) as counterparty_type
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_code))) as cp_company_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_company_name))) as cp_company_name
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_code))) as cp_country_code
# MAGIC 				  ,concat_ws(', ',sort_array(collect_set(cp_country_name))) as cp_country_name
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key
# MAGIC 				  from vw_counterparty_details cpd
# MAGIC 				  where cpd.source_system_code  in ('NUCLEUS')
# MAGIC 			group by cpd.source_system_code, cpd.cp_unique_id
# MAGIC                   ,meta_end_ddtm
# MAGIC                   ,active_indicator
# MAGIC                   ,report_date_key

# COMMAND ----------

RefreshCuratedSqlTbl('staging', 'counterparty_details_summary', 'NUCLEUS')

# COMMAND ----------

LoadCuratedTargetTbl('staging', 'counterparty_details_summary', 'cp_data_hub', 'counterparty_details_summary', 'NUCLEUS')

# COMMAND ----------

bdg_cp_sap_account_df = spark.sql("""
                                 select distinct 
                                    nucl.UNIQUE_ID               as cp_unique_id
                                   ,nucl.sap_unique_id              as sap_unique_id
                                   ,nucl.sap_account_no             as sap_account_number
                                   ,nucl.SAP_CPTY_TYPE           as sap_account_type
                                   ,nucl.SAP_SYSTEM          as sap_source_system_code
                                   ,current_timestamp               as meta_created_ddtm
                                   ,current_timestamp               as meta_start_ddtm
                                   ,to_date('2999-12-31', 'yyyy-MM-dd')   as meta_end_ddtm
                                   ,'Y'                                   as active_indicator
                                   ,'NUCLEUS'                          as source_system_code
                                   ,date_format(current_date, 'yyyyMMdd') as  report_date_key 
                                from vw_cp_master_nucleus nucl
                                where nucl.sap_unique_id is not null and length(nucl.sap_unique_id) > 0
                                """)
#creating temp view
bdg_cp_sap_account_df.createOrReplaceTempView("vw_bridge_counterparty_sap_account")

# need to get the distinct unique_id counts
bdg_cp_sap_account_cp_unique_id_cnt = bdg_cp_sap_account_df[['cp_unique_id']].drop_duplicates().count()

#check if every cp_unique_id of counterparty_details is in counterparty table or not.
bdg_cp_sap_account_cp_unique_id_not_in_cp_df  = spark.sql("""select distinct cp_unique_id from vw_bridge_counterparty_sap_account cpd
                                          where not exists (select 1 from vw_cp_data_hub_counterparty cp where cp.cp_unique_id = cpd.cp_unique_id)
                                       """)
                                       
#load process
if cp_unique_id_cnt >= bdg_cp_sap_account_cp_unique_id_cnt and bdg_cp_sap_account_cp_unique_id_not_in_cp_df.count()==0:
  try:
  
    print(f"""Count Match: {cp_unique_id_cnt} and {bdg_cp_sap_account_cp_unique_id_cnt} are same or less then counterparty""")
    print(f"""Every cp_unique_id of bridge_counterparty_sap_account is in counterparty""")
    RefreshCuratedSqlTbl('staging', 'bridge_counterparty_sap_account', 'NUCLEUS')
  
  except Exception as e:
    print("For NUCLEUS source system counterparty count and bridge_counterparty_sap_accnt cp_unique_id didn't match")
    raise dbutils.notebook.exit(e)
elif {cp_unique_id_cnt} < {bdg_cp_sap_account_cp_unique_id_cnt}: 
  print(f"""counterparty: {cp_unique_id_cnt}""")
  print(f"""bridge_counterparty_sap_account: {bdg_cp_sap_account_cp_unique_id_cnt}""")
  print("Count match is not working ")
else:
  print(f"""cp_unique_id exists in bridge counterparty sap account table but in counterparty table""")

# COMMAND ----------

#parameter seq: staging schema, staging table_name, target_schema_name and target table_name
LoadCuratedTargetTbl('staging', 'bridge_counterparty_sap_account', 'cp_data_hub', 'bridge_counterparty_sap_account', 'NUCLEUS')

# COMMAND ----------

Source_System_Code = 'NUCLEUS'
System = 'P2'

# COMMAND ----------

# MAGIC %run "/CP_Data_Hub/Shared/cp_data_audit_refresh_refactor"
