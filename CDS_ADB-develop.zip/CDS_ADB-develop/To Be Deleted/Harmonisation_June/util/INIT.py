# Databricks notebook source
# MAGIC %run ./ADLSConnection
