# Databricks notebook source
# MAGIC %run ./connection

# COMMAND ----------

import pyodbc
synapse_url = jdbcConnection()

# COMMAND ----------

def writeMetrics(jobName, jobId,SOURCE_ETRM, metricDict):
    import datetime 
    conn_str = pyodbcConnection()
    connection = pyodbc.connect(conn_str)
    SQL = """
    INSERT INTO tsa_curated.tsa_log_details
    (job_name, job_id, src_sys_name, create_date, metric_name, metric_value)
    VALUES (?, ?, ? ,?, ?, ?)
    """
    cursor = connection.cursor()
    currenttime = datetime.datetime.now()
    for k in metricDict.keys():
      cursor.execute(SQL,(jobName,jobId,SOURCE_ETRM, currenttime,k, metricDict[k]))
    
    connection.commit()
    connection.close()

# COMMAND ----------

def insertMasterLog(jobName, jobId, SOURCE_ETRM):
    import datetime 
    conn_str = pyodbcConnection()
    connection = pyodbc.connect(conn_str)
    SQL = """
    INSERT INTO tsa_curated.tsa_log_master
    (job_name, job_id, src_sys_name, create_date)
    VALUES (?, ?, ? ,?)
    """
    cursor = connection.cursor()
    currenttime = datetime.datetime.now()
    cursor.execute(SQL,(jobName,jobId,SOURCE_ETRM, currenttime))
    
    
    connection.commit()
    connection.close()


# COMMAND ----------

def updateMasterLog(jobId, total_time_taken, job_status):
    conn_str = pyodbcConnection()
    connection = pyodbc.connect(conn_str)
    SQL = """
    update tsa_curated.tsa_log_master set total_time_taken = {0}, job_status = '{1}' where job_id = '{2}'
    """.format(total_time_taken,job_status,jobId)
    cursor = connection.cursor()
    cursor.execute(SQL)
    connection.commit()
    connection.close()
