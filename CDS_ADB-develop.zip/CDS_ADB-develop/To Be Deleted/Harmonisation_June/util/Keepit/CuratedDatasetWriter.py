# Databricks notebook source
# MAGIC %run ./../../config/properties

# COMMAND ----------

# MAGIC %run ./connection

# COMMAND ----------

synapse_url = jdbcConnection()

# COMMAND ----------

def writeDatasetSynapseConnector(spark, dataset_df, db_table):
  if os.getenv('EXECUTION_CONTEXT') == 'TEST_HARNESS':
    writeDatasetUsingJdbc(dataset_df, db_table)
  else:
    synapse_url1 = jdbcConnection()
    print(synapse_url1)
    (config, sourceCont, tempDir, accountkey , token) = fetchBlobStorageConfigForSynapseConnector()

    spark.conf.set(
      accountkey,
      token)

    temp_dir=sourceCont+tempDir

    print("config ",config)
    print("temp_dir ",temp_dir)
    print("accountkey ",accountkey)
    print("token ",token)

    print(synapse_url1)

    dataset_df.write.format("com.databricks.spark.sqldw").mode("append") \
          .option("url", synapse_url1) \
          .option("tempDir", temp_dir) \
          .option("forwardSparkAzureStorageCredentials", "true")\
          .option("dbTable",db_table) \
          .save()

# COMMAND ----------

def writeDatasetSynapseConnectorOverwrite(spark, dataset_df, db_table):
  synapse_url1 = jdbcConnection()
  print(synapse_url1)
  (config, sourceCont, tempDir, accountkey , token) = fetchBlobStorageConfigForSynapseConnector()
  
  spark.conf.set(
    accountkey,
    token)
  
  temp_dir=sourceCont+tempDir
  
  print("config ",config)
  print("temp_dir ",temp_dir)
  print("accountkey ",accountkey)
  print("token ",token)
  
  print(synapse_url)
  
  dataset_df.write.format("com.databricks.spark.sqldw").mode("overwrite") \
        .option("url", synapse_url1) \
        .option("tempDir", temp_dir) \
        .option("forwardSparkAzureStorageCredentials", "true")\
        .option("dbTable",db_table) \
        .save()

# COMMAND ----------

def updateDatasetSynapseConnector(ADB_df,dbTable,updateQuery,synapseUrlParam):
    spark.conf.set(accountkey,token)
    if(not ADB_df.rdd.isEmpty()):
      
      if (logEvents == "true"):
        start_time = datetime.datetime.now()
        logEventsToDatabase("UPDATE",dbTable,"START","",0,0)
      
      dbTable_new = dbTable+"_" +datetime.datetime.now().strftime("%Y_%m_%d_%H_%M_%S_%f")
      
      updateQueryNew = updateQuery.replace(dbTable,dbTable_new)
      dropTempTable="drop table {0}".format(dbTable_new)
      postActions=updateQueryNew+';'+dropTempTable
      print(postActions)
      
      ADB_df.write.format("com.databricks.spark.sqldw").mode("overwrite") \
      .option("url", synapseUrlParam) \
      .option("tempDir", tempDir) \
      .option("forwardSparkAzureStorageCredentials", "true")\
      .option("postActions",postActions)\
      .option("dbTable", dbTable_new) \
      .save()
      
      if (logEvents == "true"):
        end_time = datetime.datetime.now()
        total_time = end_time - start_time
        logEventsToDatabase("UPDATE",dbTable_new,"END","",total_time.total_seconds(),ADB_df.count())

# COMMAND ----------

def writeDatasetUsingJdbc(df,dbtable_name):
    df.write.mode("append").format("jdbc").option("url",synapse_url).option("dbtable",dbtable_name).save()

# COMMAND ----------

def writeDatasetUsingJdbcOverWrite(df,dbtable_name):
    df.write.mode("overwrite").format("jdbc").option("url",synapse_url).option("dbtable",dbtable_name).save()

# COMMAND ----------

def executeJdbcQuery(query_string):
  spark.read.format("jdbc").option("url", synapse_url).option("query", query_string).load()

# COMMAND ----------

def executeJdbcQueryAndReturnDF(query_string):
  synapse_url = jdbcConnection()
  df = spark.read.format("jdbc").option("url", synapse_url).option("query", query_string).load()
  return df

# COMMAND ----------

def executePyOdbcQuery(query_string):
    
    
    if not pyodbc.drivers():
      print('here111')
      dbutils.notebook.run("../../util/installPyodbcLib", 60)
  
    conn_str = pyodbcConnection()
    connection = pyodbc.connect(conn_str)
    print("autocommit value ")
    print(connection.autocommit)
    
    cursor = connection.cursor()
    cursor.execute(query_string)
    
    rows_affected = cursor.rowcount
    connection.commit()
    connection.close()
    
    return(rows_affected) 

# COMMAND ----------

def executePyOdbcQueryDDL(query_string):
    
    if not pyodbc.drivers():
      print('here111')
      dbutils.notebook.run("../../util/installPyodbcLib", 60)
  
    conn_str = pyodbcConnection()
    connection = pyodbc.connect(conn_str)
    print("autocommit value ")
    print(connection.autocommit)
    connection.autocommit = True
    
    cursor = connection.cursor()
    cursor.execute(query_string)

    #connection.commit()
    connection.close()

# COMMAND ----------

def executePyOdbcQueryWithParam2_new(query_string, param1, param2):
    
    
    if not pyodbc.drivers():
      print('here111')
      dbutils.notebook.run("../../util/installPyodbcLib", 60)
  
    conn_str = pyodbcConnection()
    connection = pyodbc.connect(conn_str)
    print("autocommit value ")
    print(connection.autocommit)
   # connection.autocommit = False

    cursor = connection.cursor()  
    cursor.execute(query_string,param1, param2)
    #rows_affected = cursor.fetchone()
    rows_affected=len(cursor.fetchall())
    #connection.commit()
    connection.close()
    return(rows_affected) 

# COMMAND ----------

def executePyOdbcQueryWithParam2(query_string, param1, param2):
    
    
    if not pyodbc.drivers():
      print('here111')
      dbutils.notebook.run("../../util/installPyodbcLib", 60)
  
    conn_str = pyodbcConnection()
    connection = pyodbc.connect(conn_str)

    cursor = connection.cursor()
    cursor.execute(query_string,param1, param2)
    rows_affected = cursor.rowcount
    connection.commit()
    connection.close()
    return(rows_affected) 

# COMMAND ----------

def executePyOdbcQueryWithParam3(query_string, param1, param2, param3):
    
    
    if not pyodbc.drivers():
      print('here111')
      dbutils.notebook.run("../../util/installPyodbcLib", 60)
  
    conn_str = pyodbcConnection()
    connection = pyodbc.connect(conn_str)

    cursor = connection.cursor()
    cursor.execute(query_string,param1, param2, param3)
    rows_affected = cursor.rowcount
    connection.commit()
    connection.close()
    return(rows_affected) 

# COMMAND ----------

def executePyOdbcQueryWithParam4(query_string, param1, param2, param3, param4):
    
    
    if not pyodbc.drivers():
      print('here111')
      dbutils.notebook.run("../../util/installPyodbcLib", 60)
  
    conn_str = pyodbcConnection()
    connection = pyodbc.connect(conn_str)

    cursor = connection.cursor()
    cursor.execute(query_string,param1, param2, param3, param4)
    rows_affected = cursor.rowcount
    connection.commit()
    connection.close()
    return(rows_affected) 

# COMMAND ----------

def executePyOdbcQueryWithParam1(query_string, param1):
    
    
    if not pyodbc.drivers():
      print('here111')
      dbutils.notebook.run("../../util/installPyodbcLib", 60)
  
    conn_str = pyodbcConnection()
    connection = pyodbc.connect(conn_str)

    cursor = connection.cursor()
    cursor.execute(query_string,param1)
    rows_affected = cursor.rowcount
    connection.commit()
    connection.close()
    return(rows_affected) 
