# Databricks notebook source
# MAGIC %run ./../../config/properties

# COMMAND ----------

import datetime
import os

# COMMAND ----------

def fetchEnvironment():
  #current_env = tsaConfig['ENV_DETAIL']['CURRENT_ENV']
  current_env = "NOT_SET"
  #try:
    #current_env = os.environ['CURRENT_TSA_ENV']
  #except Exception as e:
     #print("fetchEnvironment- Failed", e)
  
  current_env = "uat"
  print("CURRENT ENV IS ", current_env)
  return current_env

# COMMAND ----------

def getConfigRoot():
  current_env = fetchEnvironment()
  config_root = 'dataSets' + '_' + current_env
  return config_root

# COMMAND ----------

def fetchADLSConnectionConfig():
  config_root = getConfigRoot()
  
  print("config_root", config_root)
  adls_url = tsaConfig[config_root]['ADLSInfo']['adls_url']
  #client_application_id = tsaConfig[config_root]['ADLSInfo']['client_application_id']
  
  client_application_id = '5115c531-6ce8-494d-b67d-964740500504'
  adls_refresh_url = tsaConfig[config_root]['ADLSInfo']['adls_refresh_url']
  kv_scope = tsaConfig[config_root]['ADLSInfo']['kv_scope']
  kv_key = tsaConfig[config_root]['ADLSInfo']['kv_key']
 # spn_key = dbutils.secrets.get(scope = kv_scope, key = kv_key)
  
  #print(spn_key)
  
  #  spn_key
  ###"975bd4e1-3818-4eb1-ba29-dedc06563b7b",
          
  configs = {"dfs.adls.oauth2.access.token.provider.type": "ClientCredential",
           "dfs.adls.oauth2.client.id": client_application_id,
           "dfs.adls.oauth2.credential": "100f44af-fbff-4756-a922-7cb08c381c8c",
           "dfs.adls.oauth2.refresh.url": adls_refresh_url,
            }
  
  return (adls_url, configs)

# COMMAND ----------

def fetchBlobStorageConfigForSynapseConnector():
  config_root = getConfigRoot()
  config = tsaConfig[config_root]['BlobInfo']['config']
  sourceCont = tsaConfig[config_root]['BlobInfo']['sourceCont']
  tempDir = tsaConfig[config_root]['BlobInfo']['tempDir']
  accountkey = tsaConfig[config_root]['BlobInfo']['accountkey']
  token = tsaConfig[config_root]['BlobInfo']['token']
  
  return (config, sourceCont, tempDir, accountkey , token)

# COMMAND ----------

def fetchBlobDetailsFromConfig():
  config_root = getConfigRoot()
  
  sourceCont = tsaConfig[config_root]['BlobInfo']['sourceCont']
  tempDir = sourceCont + tsaConfig[config_root]['BlobInfo']['tempDir']
  accountkey = tsaConfig[config_root]['BlobInfo']['accountkey']
  token = tsaConfig[config_root]['BlobInfo']['token']
  
  return (sourceCont,tempDir,accountkey, token)

# COMMAND ----------

def jdbcConnection():
  import os
  config_root = getConfigRoot()
  kv_scope = tsaConfig[config_root]['authInfo']['kv_scope']
  kv_key = tsaConfig[config_root]['authInfo']['kv_key']
  
    
  dbDatabase = tsaConfig[config_root]['authInfo']['dbDatabase']
  
  if os.getenv('EXECUTION_CONTEXT') == 'TEST_HARNESS':
    dbDatabase = "TSA_CURATED_TEST_HARNESS"
  
  dbServer = tsaConfig[config_root]['authInfo']['dbServer']
  dbUser = tsaConfig[config_root]['authInfo']['dbUser']
  #dbPass = dbutils.secrets.get(scope = kv_scope, key = kv_key)
  dbPass = "UATTrading@123"
  dbJdbcPort = tsaConfig[config_root]['authInfo']['dbJdbcPort']
  dbJdbcExtraOptions = tsaConfig[config_root]['authInfo']['dbJdbcExtraOptions']
  synapseUrl = "jdbc:sqlserver://" + dbServer + ":" + dbJdbcPort + ";database=" + dbDatabase + ";user=" + dbUser+";password=" + dbPass
 
  return synapseUrl
    
def pyodbcConnection():
  import os
  config_root = getConfigRoot()
  
  kv_scope = tsaConfig[config_root]['authInfo']['kv_scope']
  kv_key = tsaConfig[config_root]['authInfo']['kv_key']
  server = tsaConfig[config_root]['authInfo']['dbServer']
  database = tsaConfig[config_root]['authInfo']['dbDatabase']
 
  if os.getenv('EXECUTION_CONTEXT') == 'TEST_HARNESS':
    database = "TSA_CURATED_TEST_HARNESS"
    
  username = tsaConfig[config_root]['authInfo']['dbUser']
  password = dbutils.secrets.get(scope = kv_scope, key = kv_key)
  if pyodbc.drivers():
    drivers = [item for item in pyodbc.drivers()]
    driver = drivers[-1]
  else:
    driver = 'ODBC Driver 17 for SQL Server'
  
  conn_str = ('DRIVER='+driver+';SERVER='+server+
  ';DATABASE='+database+';UID='+username+';PWD='+ password)
  
  return conn_str

def jdbcReaderTable(spark, table_name):
  synapse_url = jdbcConnection()
  read_df = spark.read.format("jdbc") \
      .option("url", synapse_url) \
      .option("dbtable",table_name) \
      .option("inferSchema", True) \
      .load()
  return read_df

def jdbcReaderQuery(spark , query):
  synapse_url = jdbcConnection()
  read_df = spark.read.format("jdbc") \
      .option("url", synapse_url) \
      .option("query",query) \
      .option("inferSchema", True) \
      .load()
  
  return read_df


