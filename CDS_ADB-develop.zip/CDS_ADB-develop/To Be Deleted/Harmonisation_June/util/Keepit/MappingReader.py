# Databricks notebook source
# MAGIC %run ./CuratedDatasetWriter

# COMMAND ----------

def readMapping(spark, mappingName,source_system):
  query = "select * from tsa_curated.user_managed_mapping_data where target_mapping_name = '{0}' and source_system_mapped = '{1}'".format(mappingName,source_system)
  
  df = executeJdbcQueryAndReturnDF(query)
  return df
