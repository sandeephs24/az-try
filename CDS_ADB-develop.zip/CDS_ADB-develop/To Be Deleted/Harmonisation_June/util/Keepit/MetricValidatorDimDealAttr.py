# Databricks notebook source
# MAGIC %run ./MetricValidator

# COMMAND ----------

def validateMetricDimDealAttr(metricDict):
  validateMetricSCDUpdateVsSCDInsertCountWrapperDimDealAttr(metricDict)
  #validateMetricSCDUpdateVsSCDInsertCountWrapperFactPostDimDealAttr(metricDict)
  #validateMetricReaderCountVsUpdateAndInsertCountWrapperForDimDealAttr(metricDict)
  

# COMMAND ----------

def validateMetricSCDUpdateVsSCDInsertCountWrapperDimDealAttr(metricDict):
  
  status = validateMetricSCDUpdateVsSCDInsertCount(metricDict,"update_subeg_scd_type2_rows_affected", "insert_subeg_scd_type2_rows_affected")
  if status != "SUCCESS":
    raise Exception("SCD_UPDATE_SHOULD_EQUAL_TO_SCD_INSERT_SUBLEG_FAILED")
    
  status = validateMetricSCDUpdateVsSCDInsertCount(metricDict,"update_leg_scd_type2_rows_affected", "insert_leg_scd_type2_rows_affected")
  if status != "SUCCESS":
    raise Exception("SCD_UPDATE_SHOULD_EQUAL_TO_SCD_INSERT_LEG_FAILED")
  
  status = validateMetricSCDUpdateVsSCDInsertCount(metricDict,"update_header_scd_type2_rows_affected", "insert_header_scd_type2_rows_affected")
  
  if status != "SUCCESS":
    raise Exception("SCD_UPDATE_SHOULD_EQUAL_TO_SCD_INSERT_HEADER_FAILED")


# COMMAND ----------

def validateMetricSCDUpdateVsSCDInsertCountWrapperFactPostDimDealAttr(metricDict):
  
  status = validateMetricSCDUpdateVsSCDInsertCount(metricDict, "update_sql_post_deals_header_rows_affected", "insert_sql_post_deals_header_rows_affected")
  if status != "SUCCESS":
    raise Exception("SCD_UPDATE_SHOULD_EQUAL_TO_SCD_INSERT_HEADER_POST_FACT_FAILED")
  
  status = validateMetricSCDUpdateVsSCDInsertCount(metricDict, "update_sql_post_deals_leg_rows_affected", "insert_sql_post_deals_leg_rows_affected")
  if status != "SUCCESS":
    raise Exception("SCD_UPDATE_SHOULD_EQUAL_TO_SCD_INSERT_LEG_POST_FACT_FAILED")
  
  status = validateMetricSCDUpdateVsSCDInsertCount(metricDict, "update_sql_post_deals_subleg_rows_affected", "insert_sql_post_deals_subleg_rows_affected")
  
  if status != "SUCCESS":
    raise Exception("SCD_UPDATE_SHOULD_EQUAL_TO_SCD_INSERT_SUBLEG_POST_FACT_FAILED")


# COMMAND ----------

def validateMetricReaderCountVsUpdateAndInsertCountWrapperForDimDealAttr(metricDict) :
  
  status = validateMetricReaderCountVsUpdateAndInsertCount_new(metricDict,'subleg_reader_count','select_subeg_scd_type2_rows_affected','update_subeg_scd_type2_rows_affected','insert_subleg_rows_affected')
  
  if status != 'SUCCESS':
    raise Exception("SUBLEG_READER_COUNT_SHOULD_EQUAL_TO_INSERT_PLUS_UPDATE_COUNT_CHECK_FAILED")
  
  status = validateMetricReaderCountVsUpdateAndInsertCount_new(metricDict,'leg_reader_driven_count','select_leg_scd_type2_rows_affected','update_leg_scd_type2_rows_affected','insert_leg_rows_affected')
  
  if status != 'SUCCESS':
    raise Exception("LEG_READER_COUNT_SHOULD_EQUAL_TO_INSERT_PLUS_UPDATE_COUNT_CHECK_FAILED")
  
  status = validateMetricReaderCountVsUpdateAndInsertCount_new(metricDict,'header_reader_driven_count','select_header_scd_type2_rows_affected','update_header_scd_type2_rows_affected','insert_header_rows_affected')
  
  if status != 'SUCCESS':
    raise Exception("HEADER_READER_COUNT_SHOULD_EQUAL_TO_INSERT_PLUS_UPDATE_COUNT_CHECK_FAILED")
  
