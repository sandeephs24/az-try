# Databricks notebook source
# MAGIC %run ./MetricValidator

# COMMAND ----------

def validateMetricFact(metricDict):
  validateMetricSCDUpdateVsSCDInsertCountWrapperFact(metricDict)
  

# COMMAND ----------

def validateMetricSCDUpdateVsSCDInsertCountWrapperFact(metricDict):
  
  status = validateMetricSCDUpdateVsSCDInsertCount(metricDict, "update_sql_for_existing_deals_header_rows_affected", "insert_sql_for_existing_deals_header_rows_affected")
  if status != "SUCCESS":
    raise Exception("SCD_UPDATE_SHOULD_EQUAL_TO_SCD_INSERT_HEADER_FAILED")
    
  status = validateMetricSCDUpdateVsSCDInsertCount(metricDict ,"update_sql_for_existing_deals_leg_rows_affected", "insert_sql_for_existing_deals_leg_rows_affected")
  if status != "SUCCESS":
    raise Exception("SCD_UPDATE_SHOULD_EQUAL_TO_SCD_INSERT_LEG_FAILED")
  
  status = validateMetricSCDUpdateVsSCDInsertCount(metricDict, "update_sql_for_existing_deals_subleg_rows_affected", "insert_sql_for_existing_deals_subleg_rows_affected")
  
  if status != "SUCCESS":
    raise Exception("SCD_UPDATE_SHOULD_EQUAL_TO_SCD_INSERT_SUBLEG_FAILED")

