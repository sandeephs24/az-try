# Databricks notebook source
# MAGIC %run ./CuratedDatasetWriter

# COMMAND ----------

def loadTable(table_name):
  sql = "select * from {0}".format(table_name)
  df = executeJdbcQueryAndReturnDF(sql)
  return df;
