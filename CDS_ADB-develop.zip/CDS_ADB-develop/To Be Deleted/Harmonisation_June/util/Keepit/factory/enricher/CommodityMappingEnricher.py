# Databricks notebook source
# MAGIC %run ./../../MappingReader

# COMMAND ----------

# MAGIC %run ./../../JDBCSynapseTableLoader

# COMMAND ----------

def enrichCommodityForMapping(spark,df,source_etrm):
  print("here123")
  df.createOrReplaceTempView('COMMODITY_TEMP')
  
  df = readMapping(spark,'COMMODITY_CODE_TO_HIGH_RISK_COMMODITY_MAP', source_etrm)
  df.createOrReplaceTempView('MAPPING_HIGH_RISK_FLAG')
  
  df = readMapping(spark,'COMMODITY_CODE_TO_DUAL_USE_COMMODITY_MAP', source_etrm)
  df.createOrReplaceTempView('MAPPING_DUAL_USE_FLAG')
  
  df = readMapping(spark,'COMMODITY_CODE_TO_COMMODITY_TYPE_NAME',source_etrm)
  df.createOrReplaceTempView('MAPPING_STANDARD_COMMODITY_TYPE_NAME')
  
  df = readMapping(spark,'COMMODITY_TYPE_NAME_TO_STANDARD_COMMODITY_UOM',source_etrm)
  df.createOrReplaceTempView('STD_COMMODITY_TO_UOM_CODE_MAPPING')
  
  df = loadTable("tsa_curated.REF_UNIT_OF_MEASURE")
  df.createOrReplaceTempView('REF_UNIT_OF_MEASURE')
  
 
  SQL = """
    SELECT a.SRC_SYS_COMMODITY_NK,
    a.SRC_COMMODITY_NAME as SRC_COMMODITY_NAME,
    a.SRC_COMMODITY_GROUP_NAME as SRC_COMMODITY_GROUP_NAME,
    ud1.target_mapping_value as STD_COMMODITY_TYPE_NAME,
    ud1.source_mapping_value as MAPPED_STD_COMMODITY_TYPE_NAME,
    a.ACTIVE_COMMODITY_FLAG,
    ud2.target_mapping_value HIGH_RISK_COMMODITY_FLAG,
    ud2.source_mapping_value as MAPPED_HIGH_RISK_COMMODITY_FLAG,
    ud3.target_mapping_value DUAL_USE_COMMODITY_FLAG,
    ud3.source_mapping_value as MAPPED_DUAL_USE_COMMODITY_FLAG,
    ud4.target_mapping_value COMMODITY_UOM_SYMBOL_CODE,
    uom.STANDARD_UoM_CODE MAPPED_COMMODITY_UOM_SYMBOL_CODE,
    uom.UoM_DESCRIPTION COMMODITY_UOM_SYMBOL_DESCRIPTION,
    a.SOURCE_LAST_UPDATE 
    FROM COMMODITY_TEMP a 
    left join MAPPING_STANDARD_COMMODITY_TYPE_NAME ud1
      on a.SRC_SYS_COMMODITY_NK = ud1.source_mapping_value
    left join MAPPING_HIGH_RISK_FLAG ud2
      on a.SRC_SYS_COMMODITY_NK = ud2.source_mapping_value
    left join MAPPING_DUAL_USE_FLAG ud3
      on a.SRC_SYS_COMMODITY_NK = ud3.source_mapping_value
    left join STD_COMMODITY_TO_UOM_CODE_MAPPING ud4
      on ud1.target_mapping_value = ud4.source_mapping_value 
    left join REF_UNIT_OF_MEASURE uom
      on ud4.target_mapping_value = uom.STANDARD_UoM_CODE
     """
  
  df = spark.sql(SQL)
  
  df=df.withColumn("SRC_COMMODITY_NAME",when(df.SRC_COMMODITY_NAME.isNull(),lit(None))
                   .otherwise(df.SRC_COMMODITY_NAME))
  
  df=df.withColumn("SRC_COMMODITY_GROUP_NAME",when(df.SRC_COMMODITY_GROUP_NAME.isNull(),lit(None))
                   .otherwise(df.SRC_COMMODITY_GROUP_NAME))
    
  df = df.withColumn("STD_COMMODITY_TYPE_NAME", when(df.STD_COMMODITY_TYPE_NAME.isNull(),"MAPPING DOES NOT EXIST")
                     .when(df.MAPPED_STD_COMMODITY_TYPE_NAME.isNull(),"TARGET MAPPING IS INVALID")
                     .otherwise(df.STD_COMMODITY_TYPE_NAME))
  df = df.withColumn("HIGH_RISK_COMMODITY_FLAG", when(df.HIGH_RISK_COMMODITY_FLAG.isNull(),"MAPPING DOES NOT EXIST")
                     .when(df.MAPPED_HIGH_RISK_COMMODITY_FLAG.isNull(),"TARGET MAPPING IS INVALID")
                     .otherwise(df.HIGH_RISK_COMMODITY_FLAG))
  df = df.withColumn("DUAL_USE_COMMODITY_FLAG", when(df.DUAL_USE_COMMODITY_FLAG.isNull(),"MAPPING DOES NOT EXIST")
                     .when(df.MAPPED_DUAL_USE_COMMODITY_FLAG.isNull(),"TARGET MAPPING IS INVALID")
                     .otherwise(df.DUAL_USE_COMMODITY_FLAG))
  df = df.withColumn("COMMODITY_UOM_SYMBOL_CODE", when(df.COMMODITY_UOM_SYMBOL_CODE.isNull(),"MAPPING DOES NOT EXIST")
                     .when(df.COMMODITY_UOM_SYMBOL_CODE=='',"MAPPING DOES NOT EXIST")
                     .when(df.MAPPED_COMMODITY_UOM_SYMBOL_CODE.isNull(),"TARGET MAPPING IS INVALID")
                     .otherwise(df.COMMODITY_UOM_SYMBOL_CODE))
  
  df=df.withColumn("COMMODITY_UOM_SYMBOL_DESCRIPTION", when(df.COMMODITY_UOM_SYMBOL_CODE=="MAPPING DOES NOT EXIST","MAPPING DOES NOT EXIST")
                 .when(df.COMMODITY_UOM_SYMBOL_CODE== "TARGET MAPPING IS INVALID" ,"TARGET MAPPING IS INVALID")
                  .otherwise(df.COMMODITY_UOM_SYMBOL_DESCRIPTION))
  df=df.drop("MAPPED_COMMODITY_UOM_SYMBOL_CODE")   
  
  df.show()
  
  return df
