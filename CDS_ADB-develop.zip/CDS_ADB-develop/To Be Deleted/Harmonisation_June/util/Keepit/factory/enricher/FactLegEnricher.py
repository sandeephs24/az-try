# Databricks notebook source
# MAGIC %run ./../../CuratedDatasetWriter

# COMMAND ----------

def enrichFactLeg(dfLeg, spark, SOURCE_ETRM):
  
  dfLeg.createOrReplaceTempView("FACT_LEG_TEMP")
  
  
  df = executeJdbcQueryAndReturnDF("select * from tsa_curated.dim_commodity where src_sys_name = '{0}'".format(SOURCE_ETRM))
  df.createOrReplaceTempView("CURATED_DIM_COMMODITY")
  
  df = executeJdbcQueryAndReturnDF("select * from tsa_curated.dim_unit_of_measure where src_sys_name = '{0}'".format(SOURCE_ETRM))
  df.createOrReplaceTempView("dim_unit_of_measure")
  
  df = executeJdbcQueryAndReturnDF("select * from tsa_curated.ref_unit_of_measure_conversion")
  df.createOrReplaceTempView("REF_UNIT_OF_MEASURE_CONVERSION")
  
  SQL = """
  select
  fact_leg.SRC_SYS_NAME,
  fact_leg.RECORD_CREATED_DTTM,
  fact_leg.DEAL_ATTRIBUTES_CK,
  fact_leg.EXECUTION_DATE_CK,
  fact_leg.TRADE_CREATION_DATE_CK,
  fact_leg.COMMITMENT_DATE_CK,
  fact_leg.COUNTERPARTY_CK,
  fact_leg.SHELL_TRADING_PARTY_CK,
  fact_leg.TRADER_CK,
  fact_leg.DEAL_BROKER_CK,
  fact_leg.UNIT_OF_MEASURE_CK,
  fact_leg.COMMODITY_CK,
  fact_leg.SOURCE_LAST_DATE1,
  fact_leg.SOURCE_LAST_DATE2,
  fact_leg.SOURCE_LAST_DATE3,
  fact_leg.COMMITMENT_QTY,
  case
  when dim_uom.std_unit_of_measure_symbol_code = cmd.COMMODITY_UOM_SYMBOL_CODE 
  then fact_leg.COMMITMENT_QTY
  when cmd.COMMODITY_UOM_SYMBOL_CODE = "MAPPING DOES NOT EXIST" 
  or cmd.COMMODITY_UOM_SYMBOL_CODE = "TARGET MAPPING IS INVALID" 
  or cmd.COMMODITY_UOM_SYMBOL_CODE = "" 
  or cmd.COMMODITY_UOM_SYMBOL_CODE is null
  or dim_uom.std_unit_of_measure_symbol_code  = "MAPPING DOES NOT EXIST" 
  or dim_uom.std_unit_of_measure_symbol_code  = "TARGET MAPPING IS INVALID" 
  or dim_uom.std_unit_of_measure_symbol_code  = "" 
  or dim_uom.std_unit_of_measure_symbol_code is null
  then 0.0
  when dim_uom.std_unit_of_measure_symbol_code <> cmd.COMMODITY_UOM_SYMBOL_CODE 
  then fact_leg.COMMITMENT_QTY * ref_uom_conv.CONVERSION_FACTOR 
  end AS COMMODITY_COMMITMENT_QTY,
  fact_leg.DEAL_LEG_MULTIPLIER as DEAL_LEG_MULTIPLIER,
  fact_leg.SRC_SYS_DEAL_HEADER_KEY
  from fact_leg_temp fact_leg
  left join CURATED_DIM_COMMODITY cmd 
    on fact_leg.commodity_ck = cmd.commodity_ck
  left join dim_unit_of_measure dim_uom
    on fact_leg.unit_of_measure_ck = dim_uom.unit_of_measure_ck
  left join REF_UNIT_OF_MEASURE_CONVERSION ref_uom_conv
    on from_standard_uom_code = dim_uom.std_unit_of_measure_symbol_code 
    and to_standard_uom_code = cmd.COMMODITY_UOM_SYMBOL_CODE
  """
  
  dfLeg = spark.sql(SQL)
      
  return dfLeg
