# Databricks notebook source
# MAGIC %run ./../../../util/SparkSessionBuilder

# COMMAND ----------

# MAGIC %run ./../../../util/DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./PartyGoldTierEnricherT

# COMMAND ----------



# COMMAND ----------

from pyspark.sql.functions import when


# COMMAND ----------

SOURCE_ETRM = 'DEX'      
last_watermark_party = "1900-01-01 00:00:00"

df = executeJdbcQueryAndReturnDF("select SRC_SYS_PARTY_NK,party_type from tsa_curated.dim_party where src_sys_name = '{0}'".format(SOURCE_ETRM))
df.createOrReplaceTempView("CURATED_DIM_PARTY")
        
SQL = """
select sequence_num, CORPORATE_ENTITY_C, rank() over (partition by sequence_num order by last_update_tstmp desc) rnk 
from STO_TRDGACCT TA
"""
        
EXTERNAL_PARTY_READER_SQL = """
        SELECT distinct
        cast(CA.SEQUENCE_NUM as int)  AS SRC_SYS_PARTY_NK
        ,NVL(CO.CMF_SHORT_NAME, CA.COMPANY_MNEM)  AS SRC_SYS_PARTY_SHORT_NAME
        ,CO.CMF_LONG_NAME    AS SRC_SYS_PARTY_LONG_NAME
        ,'External' as Party_Type,
        co.company_mnem as SRC_SYS_LEGAL_ENTITY_NK,
        CO.CMF_LONG_NAME SRC_SYS_LEGAL_ENTITY_NAME,
        CA.LAST_UPDATE_TSTMP SOURCE_LAST_UPDATE
        FROM STO_CHRGACCT CA INNER JOIN STO_COMPANY CO ON CO.COMPANY_MNEM = CA.COMPANY_MNEM
        WHERE CA.CHRG_ACCT_TYP_CODE <> 'T' 
       
        """
format = "delta"

format = "delta"
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CHRGACCT', format, 'STO_CHRGACCT')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CORPENT', format, 'STO_CORPENT')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_TRDGACCT', format, 'STO_TRDGACCT')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_COMPANY',format, 'STO_COMPANY')

dfExternal = spark.sql(EXTERNAL_PARTY_READER_SQL)
  
print(dfExternal.count())

spark = sparkSession("Expl_GoldTier")
df = enrichExternalParty(spark,dfExternal,"DEX")

print(df.count())

df.show(10)


# COMMAND ----------

sql = """
    select * from CRD_VIEW_COUNTERPARTY_MAPPING where object_name = 'COUNTERPARTY' and application_name = 'DEX'
        and Attribute_Name = 'SeqNo'  and Attribute_Value =  31006
        """
spark = sparkSession("Expl_GoldTier")
dfExternal = spark.sql(sql)

dfExternal.show()


# COMMAND ----------

format = 'parquet'
readDatasetConfigAndCreateTempView_WithSPN(spark, 'CRD', 'CRD_TEMP',format, 'CRD_TEMP')
  
SQL = """
    select * from 
    CRD_TEMP  where  object_name = 'COUNTERPARTY' and application_name = 'DEX' 
  """
df = spark.sql(SQL)
print('CRD view')
df.show(20,False)
