# Databricks notebook source
# MAGIC %run ./../../MappingReader

# COMMAND ----------

# MAGIC %run ./../../JDBCSynapseTableLoader

# COMMAND ----------

def enrichUOMForMapping(spark,df, source_etrm):
  df.createOrReplaceTempView('UOM_TEMP')
  print(df.count())
  
  df = readMapping(spark,'UOM_CODE_TO_STANDARD_UOM_CODE', source_etrm)
  df.createOrReplaceTempView('UOM_MAPPING')
 
  df = loadTable("tsa_curated.REF_UNIT_OF_MEASURE")
  df.createOrReplaceTempView('REF_UNIT_OF_MEASURE')
  
  SQL = """
  SELECT a.SRC_SYS_UNIT_OF_MEASURE_NK as SRC_SYS_UNIT_OF_MEASURE_NK,
  b.target_mapping_value as STD_UNIT_OF_MEASURE_SYMBOL_CODE,
  b.source_mapping_value as MAPPED_STD_UNIT_OF_MEASURE_SYMBOL_CODE,
  c.UoM_DESCRIPTION  as STD_UNIT_OF_MEASURE_DESCRIPTION  
  FROM UOM_TEMP a 
  left join UOM_MAPPING b
  on a.SRC_SYS_UNIT_OF_MEASURE_NK = b.source_mapping_value
  left join REF_UNIT_OF_MEASURE c
  on b.target_mapping_value = c.STANDARD_UoM_CODE  
  """
  
  df = spark.sql(SQL)
  
  df=df.withColumn("STD_UNIT_OF_MEASURE_SYMBOL_CODE",
                   when(df.STD_UNIT_OF_MEASURE_SYMBOL_CODE.isNull(),"MAPPING DOES NOT EXIST")
                   .when(df.STD_UNIT_OF_MEASURE_SYMBOL_CODE == '',"MAPPING DOES NOT EXIST")
                   .when(df.MAPPED_STD_UNIT_OF_MEASURE_SYMBOL_CODE.isNull(),"TARGET MAPPING IS INVALID")
                                              .otherwise(df.STD_UNIT_OF_MEASURE_SYMBOL_CODE))
  
  df=df.withColumn("STD_UNIT_OF_MEASURE_DESCRIPTION",
                   when(df.STD_UNIT_OF_MEASURE_SYMBOL_CODE=="MAPPING DOES NOT EXIST","MAPPING DOES NOT EXIST")
                   .when(df.STD_UNIT_OF_MEASURE_SYMBOL_CODE=="TARGET MAPPING IS INVALID","TARGET MAPPING IS INVALID")
                                              .otherwise(df.STD_UNIT_OF_MEASURE_DESCRIPTION))
  df=df.drop("MAPPED_STD_UNIT_OF_MEASURE_SYMBOL_CODE")
   
  print(df.count())
  return df
