# Databricks notebook source
# MAGIC %run ./../../MappingReader

# COMMAND ----------

# MAGIC %run ./../../JDBCSynapseTableLoader

# COMMAND ----------

def enrichExternalParty(spark,df,SOURCE_ETRM): 
        
        #createCRDView(spark)
        createCRDViewTemp(spark) 
        #mk to add crd temp
        GoldTierViews(spark)
        
        application_name=''
        
        if (SOURCE_ETRM == 'ENDUR_GPNA') :
          application_name = 'Endur GP NA'
          Attribute_Name = 'LegalEntityId'
        elif (SOURCE_ETRM == 'DEX') :
          application_name = 'DEX'
          Attribute_Name = 'SeqNo'
        
        df.createOrReplaceTempView('PARTY_TEMP')
        
        df = readMapping(spark,'COUNTRY_NAME_TO_ISO_COUNTRY_CODE', 'GOLDTIER')
        df.createOrReplaceTempView('MAPPING_GT_COUNTRY_NAME_TO_ISO_COUNTRY')
  
              
        df = loadTable("tsa_curated.iso_country")
        df.createOrReplaceTempView('ISO_COUNTRY')
        
        PARTY_JOIN_CRD_GOLDTIER_SQL = """
        WITH v1 as (Select * from GOLDTIER_VW_MI_CUSTOMER_CORE),
        v2 as (select * from GOLDTIER_VW_MI_CUSTOMER_CORE_EXTENDED),
        v3 as (select * from GOLDTIER_VW_MI_ACCOUNT_CORE),
        v4 as (select * from CRD_VIEW_COUNTERPARTY_MAPPING where object_name = 'COUNTERPARTY' and application_name = '{0}'
        and Attribute_Name = '{1}')
        SELECT 
        b.gt_id,
        b.attribute_value,
        
        a.SRC_SYS_PARTY_NK,
        a.SRC_SYS_PARTY_SHORT_NAME,
        a.SRC_SYS_PARTY_LONG_NAME,
        a.PARTY_TYPE,
        a.SRC_SYS_LEGAL_ENTITY_NK,
        a.SRC_SYS_LEGAL_ENTITY_NAME,
        a.SOURCE_LAST_UPDATE
        FROM PARTY_TEMP a 
        """.format(application_name,Attribute_Name)
        crd_join = """
           
           left join v4 b 
           on a.SRC_SYS_PARTY_NK = b.attribute_value
           
        """
        
       
        if (SOURCE_ETRM == 'ENDUR_GPNA') :
          crd_join = """
           left join v4 b 
           on a.SRC_SYS_LEGAL_ENTITY_NK = b.attribute_value
            """
        print (SOURCE_ETRM)
        print(crd_join)
        
        final_join =  """
       
      
        
        where a.SRC_SYS_PARTY_NK = 31006
        """
 
        PARTY_JOIN_CRD_GOLDTIER_SQL = PARTY_JOIN_CRD_GOLDTIER_SQL + crd_join + final_join
  
        print(PARTY_JOIN_CRD_GOLDTIER_SQL)
        
        df = spark.sql(PARTY_JOIN_CRD_GOLDTIER_SQL)
        
        df.show()
        
        df = df.na.fill({'SRC_SYS_PARTY_SHORT_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'KYC_OPERATION_COUNTRY_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'KYC_COUNTERPARTY_KEY':'NULL AT SOURCE'})
        df = df.na.fill({'KYC_LEGAL_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'KYC_LEGAL_COUNTRY_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'KYC_STATUS':'NULL AT SOURCE'})
        df = df.na.fill({'KYC_RISK_LEVEL':'NULL AT SOURCE'})
        df = df.na.fill({'KYC_NEXT_REVIEW_DATE':'NULL AT SOURCE'})
        df = df.na.fill({'KYC_LAST_REVIEW_DATE':'NULL AT SOURCE'})
        df = df.na.fill({'KYC_DUE_DILIGENCE_LEVEL':'NULL AT SOURCE'})
        df = df.na.fill({'ENHANCED_MONITORING_FLAG':'NULL AT SOURCE'})
        df = df.na.fill({'ENHANCED_MONITORING_REVIEW_FREQUENCY':'NULL AT SOURCE'})
        df = df.na.fill({'NEXT_ENHANCED_MONITORING_REQUIRED_DATE':'NULL AT SOURCE'})
        df = df.na.fill({'KYC_AUTHORISED_COMMODITY_TYPE':'NULL AT SOURCE'})
        df = df.na.fill({'KYC_AUTHORISED_DEAL_TYPE':'NULL AT SOURCE'})
        
        
        df=df.withColumn("NEXT_ENHANCED_MONITORING_REQUIRED_DATE",when(df.NEXT_ENHANCED_MONITORING_REQUIRED_DATE.isNull(),"NULL AT SOURCE")
                 .when(df.NEXT_ENHANCED_MONITORING_REQUIRED_DATE=='',"NULL AT SOURCE")
                          .otherwise(df.NEXT_ENHANCED_MONITORING_REQUIRED_DATE))
        
        df=df.withColumn("KYC_NEXT_REVIEW_DATE",when(df.KYC_NEXT_REVIEW_DATE.isNull(),"NULL AT SOURCE")
                 .when(df.KYC_NEXT_REVIEW_DATE=='',"NULL AT SOURCE")
                          .otherwise(df.KYC_NEXT_REVIEW_DATE))
        
        df=df.withColumn("KYC_LAST_REVIEW_DATE",when(df.KYC_LAST_REVIEW_DATE.isNull(),"NULL AT SOURCE")
                 .when(df.KYC_LAST_REVIEW_DATE=='',"NULL AT SOURCE")
                          .otherwise(df.KYC_LAST_REVIEW_DATE))
        
        
        df=df.withColumn("KYC_COUNTERPARTY_KEY",when(df.KYC_COUNTERPARTY_KEY.isNull(),"NULL AT SOURCE")
                 .when(df.KYC_COUNTERPARTY_KEY=='',"NULL AT SOURCE")
                          .otherwise(df.KYC_COUNTERPARTY_KEY))
        
        
        df=df.withColumn("SRC_SYS_LEGAL_ENTITY_NK",when(df.SRC_SYS_LEGAL_ENTITY_NK.isNull(),"NULL AT SOURCE")
                 .when(df.SRC_SYS_LEGAL_ENTITY_NK=='',"NULL AT SOURCE")
                          .otherwise(df.SRC_SYS_LEGAL_ENTITY_NK))
        
        df=df.withColumn("SRC_SYS_PARTY_LONG_NAME",when(df.SRC_SYS_PARTY_LONG_NAME.isNull(),"NULL AT SOURCE")
                 .when(df.SRC_SYS_PARTY_LONG_NAME=='',"NULL AT SOURCE")
                          .otherwise(df.SRC_SYS_PARTY_LONG_NAME))
        
        df=df.withColumn("SRC_SYS_LEGAL_ENTITY_NAME",when(df.SRC_SYS_LEGAL_ENTITY_NAME.isNull(),"NULL AT SOURCE")
                 .when(df.SRC_SYS_LEGAL_ENTITY_NAME=='',"NULL AT SOURCE")
                          .otherwise(df.SRC_SYS_LEGAL_ENTITY_NAME))
        
        
        df=df.withColumn("KYC_OPERATION_COUNTRY_ISO_CODE",when(df.KYC_OPERATION_COUNTRY_ISO_CODE.isNull(),"MAPPING DOES NOT EXIST")
                 .when(df.MAPPED_KYC_OPERATION_COUNTRY_ISO_CODE.isNull(),"TARGET MAPPING IS INVALID")
                         .when (df.KYC_OPERATION_COUNTRY_NAME == "NULL AT SOURCE","NULL AT SOURCE")
                         .otherwise(df.KYC_OPERATION_COUNTRY_ISO_CODE))
        df=df.withColumn("HIGH_RISK_OPERATION_COUNTRY_FLAG",when(df.HIGH_RISK_OPERATION_COUNTRY_FLAG.isNull(),"N")
                 .when(df.KYC_OPERATION_COUNTRY_ISO_CODE == "MAPPING DOES NOT EXIST","MAPPING DOES NOT EXIST")
                         .when(df.KYC_OPERATION_COUNTRY_ISO_CODE == "TARGET MAPPING IS INVALID","TARGET MAPPING IS INVALID")
                         .when (df.KYC_OPERATION_COUNTRY_ISO_CODE == "NULL AT SOURCE","NULL AT SOURCE")
                         .otherwise(df.HIGH_RISK_OPERATION_COUNTRY_FLAG))
        
        df=df.withColumn("EDD_OPERATION_COUNTRY_FLAG",when(df.EDD_OPERATION_COUNTRY_FLAG.isNull(),"N")
                 .when(df.KYC_OPERATION_COUNTRY_ISO_CODE == "MAPPING DOES NOT EXIST","MAPPING DOES NOT EXIST")
                         .when(df.KYC_OPERATION_COUNTRY_ISO_CODE == "TARGET MAPPING IS INVALID","TARGET MAPPING IS INVALID")
                         .when (df.KYC_OPERATION_COUNTRY_ISO_CODE == "NULL AT SOURCE","NULL AT SOURCE")
                         .otherwise(df.EDD_OPERATION_COUNTRY_FLAG))
        
        
        df=df.withColumn("GEC_OPERATION_COUNTRY_FLAG",when(df.GEC_OPERATION_COUNTRY_FLAG.isNull(),"N")
                 .when(df.KYC_OPERATION_COUNTRY_ISO_CODE == "MAPPING DOES NOT EXIST","MAPPING DOES NOT EXIST")
                         .when(df.KYC_OPERATION_COUNTRY_ISO_CODE == "TARGET MAPPING IS INVALID","TARGET MAPPING IS INVALID")
                         .when (df.KYC_OPERATION_COUNTRY_ISO_CODE == "NULL AT SOURCE","NULL AT SOURCE")
                         .otherwise(df.GEC_OPERATION_COUNTRY_FLAG))
        
        df=df.withColumn("KYC_LEGAL_COUNTRY_ISO_CODE",when(df.KYC_LEGAL_COUNTRY_ISO_CODE.isNull(),"MAPPING DOES NOT EXIST")
                 .when(df.MAPPED_KYC_LEGAL_COUNTRY_ISO_CODE.isNull(),"TARGET MAPPING IS INVALID")
                         .when (df.KYC_LEGAL_COUNTRY_NAME == "NULL AT SOURCE","NULL AT SOURCE")
                         .otherwise(df.KYC_LEGAL_COUNTRY_ISO_CODE))
        
        df=df.withColumn("HIGH_RISK_LEGAL_COUNTRY_FLAG",when(df.HIGH_RISK_LEGAL_COUNTRY_FLAG.isNull(),"N")
                 .when(df.KYC_LEGAL_COUNTRY_ISO_CODE == "MAPPING DOES NOT EXIST","MAPPING DOES NOT EXIST")
                         .when(df.KYC_LEGAL_COUNTRY_ISO_CODE == "TARGET MAPPING IS INVALID","TARGET MAPPING IS INVALID")
                         .when (df.KYC_LEGAL_COUNTRY_ISO_CODE == "NULL AT SOURCE","NULL AT SOURCE")
                         .otherwise(df.HIGH_RISK_LEGAL_COUNTRY_FLAG))
        
        df=df.withColumn("EDD_LEGAL_COUNTRY_FLAG",when(df.EDD_LEGAL_COUNTRY_FLAG.isNull(),"N")
                 .when(df.KYC_LEGAL_COUNTRY_ISO_CODE == "MAPPING DOES NOT EXIST","MAPPING DOES NOT EXIST")
                         .when(df.KYC_LEGAL_COUNTRY_ISO_CODE == "TARGET MAPPING IS INVALID","TARGET MAPPING IS INVALID")
                         .when (df.KYC_LEGAL_COUNTRY_ISO_CODE == "NULL AT SOURCE","NULL AT SOURCE")
                         .otherwise(df.EDD_LEGAL_COUNTRY_FLAG))
        
        df=df.withColumn("GEC_LEGAL_COUNTRY_FLAG",when(df.GEC_LEGAL_COUNTRY_FLAG.isNull(),"N")
                 .when(df.KYC_LEGAL_COUNTRY_ISO_CODE == "MAPPING DOES NOT EXIST","MAPPING DOES NOT EXIST")
                         .when(df.KYC_LEGAL_COUNTRY_ISO_CODE == "TARGET MAPPING IS INVALID","TARGET MAPPING IS INVALID")
                         .when (df.KYC_LEGAL_COUNTRY_ISO_CODE == "NULL AT SOURCE","NULL AT SOURCE")
                         .otherwise(df.GEC_LEGAL_COUNTRY_FLAG))
    
        df = df.drop("MAPPED_KYC_OPERATION_COUNTRY_ISO_CODE","MAPPED_KYC_LEGAL_COUNTRY_ISO_CODE")
        
        df.show()
        return df

# COMMAND ----------

def createCRDViewTemp(spark):

  format = 'parquet'
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'CRD', 'CRD_TEMP',format, 'CRD_TEMP')
  
  SQL = """
    select * from 
    CRD_TEMP
  """
  df = spark.sql(SQL)
  print('CRD view')
  df.show(20,False)

  df.createOrReplaceTempView("CRD_VIEW_COUNTERPARTY_MAPPING")
  

# COMMAND ----------

def createCRDView(spark):

  format = 'parquet'
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'CRD', 'X_GT_MAPPING',format, 'X_GT_MAPPING')
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'CRD', 'XREF_MAPPING_OWNER',format, 'XREF_MAPPING_OWNER')
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'CRD', 'XREF_APPLICATION_INSTANCE',format, 'XREF_APPLICATION_INSTANCE')
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'CRD', 'XREF_OBJECT',format, 'XREF_OBJECT')
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'CRD', 'XREF_ATTRIBUTE',format, 'XREF_ATTRIBUTE')
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'CRD', 'X_SCPL_STAGE_DATA',format, 'X_SCPL_STAGE_DATA')
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'CRD', 'XREF_Mapping',format, 'XREF_Mapping')

  SQL = """
  select * from 
  (
  Select 
  XGT.GT_ID,
  MAPOWN.Mapping_Owner_Code AS CRD_Mapping_Owner,
  APPINS.Application_Instance_Name AS Application_Name,
  XOBJ.Object_Name AS Object_Name,
  XATR.Attribute_Name AS Attribute_Name,
  XM.Source_ID AS Attribute_Value, 
  XM.Common_Id AS CRD_Common_ID,
  'CRD-MAPPED' AS CRD_Mapping_Status 
  FROM XREF_Mapping XM 
  INNER JOIN XREF_MAPPING XMAP ON XM.Common_Id = XMAP.Common_Id
  LEFT OUTER JOIN X_GT_MAPPING XGT ON upper(XMAP.GUID) = XGT.GT_SOURCE_GUID
  INNER JOIN XREF_MAPPING_OWNER MAPOWN ON XM.MAPPING_OWNER_ID = MAPOWN.MAPPING_OWNER_ID
  INNER JOIN XREF_APPLICATION_INSTANCE APPINS ON XM.Source_App_Instance_ID = APPINS.Application_Instance_ID
  INNER JOIN XREF_OBJECT XOBJ ON XOBJ.Object_Id = XM.Object_Id
  INNER JOIN XREF_ATTRIBUTE XATR ON XATR.ATTRIBUTE_ID = XM.ATTRIBUTE_ID
  WHERE XM.Source_App_Instance_Id != 47 AND XMAP.Source_App_Instance_Id = 47 AND  XM.Common_Id IS NOT NULL AND
  XMAP.Common_Id IS NOT NULL
  ) AS MAP
  WHERE MAP.GT_ID IS NOT NULL
  """

  df = spark.sql(SQL)
  print('CRD view')
  df.show(20,False)

  df.createOrReplaceTempView("CRD_VIEW_COUNTERPARTY_MAPPING")
  

# COMMAND ----------

def GoldTierViews(spark):
  
  format = 'parquet'
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'GOLDTIER', 'VW_MI_CUSTOMER_CORE',format, 'GOLDTIER_VW_MI_CUSTOMER_CORE1')
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'GOLDTIER', 'VW_MI_CUSTOMER_CORE_EXTENDED',format, 'GOLDTIER_VW_MI_CUSTOMER_CORE_EXTENDED1')
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'GOLDTIER', 'VW_MI_ACCOUNT_CORE',format, 'GOLDTIER_VW_MI_ACCOUNT_CORE1')
  
  SQL1 ="""select distinct cast(goldtier_id as string) as goldtier_id,       
        legal_name,next_em_required_by_date,em_last_datetime_completed,em_flag,review_frequency,policy_next_review_date from 
        GOLDTIER_VW_MI_CUSTOMER_CORE_EXTENDED1 where record_active_flag = 'Y' """
  df1 = spark.sql(SQL1)
  df1.createOrReplaceTempView("GOLDTIER_VW_MI_CUSTOMER_CORE_EXTENDED")
  
  SQL2 ="""select distinct Commodity_Product_Type,Role,cast(goldtier_id as string) as goldtier_id from GOLDTIER_VW_MI_ACCOUNT_CORE1 where 
      record_active_flag = 'Y' """
  df2 = spark.sql(SQL2)
  df2.createOrReplaceTempView("GOLDTIER_VW_MI_ACCOUNT_CORE")

  SQL3 = """select distinct cast(goldtier_id as string) as goldtier_id,policy_status,legal_country,
          country_of_operations,legal_country,policy_approved_risk_level,dd_level_approved,dd_level from    
          GOLDTIER_VW_MI_CUSTOMER_CORE1 where record_active_flag = 'Y' """
  df3 =spark.sql(SQL3)
  df3.createOrReplaceTempView("GOLDTIER_VW_MI_CUSTOMER_CORE")

    
  

# COMMAND ----------

def GoldTierViewsTemp(spark):
  
  format = 'parquet'
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'GOLDTIER', 'VW_MI_CUSTOMER_CORE',format, 'GOLDTIER_VW_MI_CUSTOMER_CORE1')
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'GOLDTIER', 'VW_MI_CUSTOMER_CORE_EXTENDED',format, 'GOLDTIER_VW_MI_CUSTOMER_CORE_EXTENDED1')
  readDatasetConfigAndCreateTempView_WithSPN(spark, 'GOLDTIER', 'VW_MI_ACCOUNT_CORE',format, 'GOLDTIER_VW_MI_ACCOUNT_CORE1')
  
  SQL1 ="""select distinct cast(goldtier_id as string) as goldtier_id,       
        legal_name,next_em_required_by_date,em_last_datetime_completed,em_flag,review_frequency,policy_next_review_date from 
        GOLDTIER_VW_MI_CUSTOMER_CORE_EXTENDED1 where record_active_flag = 'Y' """
  df1 = spark.sql(SQL1)
  df1.createOrReplaceTempView("GOLDTIER_VW_MI_CUSTOMER_CORE_EXTENDED")
  
  SQL2 ="""select distinct Commodity_Product_Type,Role,cast(goldtier_id as string) as goldtier_id from GOLDTIER_VW_MI_ACCOUNT_CORE1 where 
      record_active_flag = 'Y' """
  df2 = spark.sql(SQL2)
  df2.createOrReplaceTempView("GOLDTIER_VW_MI_ACCOUNT_CORE")

  SQL3 = """select distinct cast(goldtier_id as string) as goldtier_id,policy_status,legal_country,
          country_of_operations,legal_country,policy_approved_risk_level,dd_level_approved,dd_level from    
          GOLDTIER_VW_MI_CUSTOMER_CORE1 where record_active_flag = 'Y' """
  df3 =spark.sql(SQL3)
  df3.createOrReplaceTempView("GOLDTIER_VW_MI_CUSTOMER_CORE")

    
  
