# Databricks notebook source
# MAGIC %run ./../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../DatasetConfigReader

# COMMAND ----------

def enrichFactSubLegReplaceCCYDealValueWithHistoryDataSLMT(dfSubLeg, spark, SOURCE_ETRM):
  from pyspark.sql.functions import col
  from pyspark.sql.functions import date_format
  dfSubLeg.show()
  dfSubLeg.createOrReplaceTempView("FACT_SUB_LEG_TEMP")
  readDatasetConfigAndCreateTempView(spark, SOURCE_ETRM, 'FACT_DEAL_PNL', "delta", 'FACT_DEAL_PNL')
  
  SQL = """
with PNL_DETAIL_RESULT_FACT_VIEW
as(
  select FCT2.DEAL_NUM,  
  FCT2.PNL_FROM_DATE, 
  fct2.PNL_TO_DATE,
  FCT2.PARAM_NUM, 
  fct2.TRAN_NUM,
  FCT2.PROFILE_NUM,
  FCT2.REPORT_DATE,
  sum(FCT2.RST_TOTAL_NOTIONAL_VALUE) SUM_RST_TOTAL_NOTIONAL_VALUE
  from FACT_DEAL_PNL fct2
  group by FCT2.DEAL_NUM, 
  FCT2.PNL_FROM_DATE,
  fct2.PNL_TO_DATE,
  FCT2.PARAM_NUM,
  fct2.TRAN_NUM,
  FCT2.PROFILE_NUM,
  FCT2.REPORT_DATE
),
PNL_DETAIL_RESULT_FACT_MIN_DATE_VIEW
as
(
  select FCT.DEAL_NUM, MIN(FCT.REPORT_DATE) REPORT_DATE
  from FACT_DEAL_PNL fct 
  GROUP BY FCT.DEAL_NUM
),
AB_TRAN_VIEW
as(select DEAL_TRACKING_NUM
from ab_tran t
left join instruments bz
      on t.ins_type = bz.id_number
where bz.name not in ('CASH',
'COMM-BAL-POSTING',
'COMM-BAL-POSTING-OFFSET',
'COMM-FEE',
'COMM-IMB',
'COMM-PAL',
'COMM-PAL-SETTLEMENT',
'COMM-PHYS-FEES',
'COMM-PHYS-TRANSPORT',
'COMM-STOR',
'COMM-TRANS',
'COMM-TRANSIT',
'COMM-TRANS-SETTLEMENT',
'PWR-FEE',
'RENEWABLE-INVENTORY',
'COMM-BAL-ACCTNG-IMPACT',
'COMM-BANKGAS-BAL-POSTING',
'COMM-IMBALANCE-CASHOUT',
'COMM-INV-NATGAS',
'COMM-IUK-INV-ADJ',
'COMM-NGL-VIRTUAL',
'COMM-PPA',
'COMM-STOR-BAL',
'COMM-TRANSIT-NGL',
'COMM-VIRTUAL-SWAP',
'LNG-MARGIN-XFER-DIV',
'LNG-MARGIN-XFER-EL'
'CAP-ENTRY',
'CAP-EXIT')   
)
SELECT 
  fact_history.DEAL_NUM,  
  fact_history.PNL_FROM_DATE,
  fact_history.PNL_TO_DATE,
  fact_history.PARAM_NUM, 
  fact_history.TRAN_NUM,
  fact_history.PROFILE_NUM,
  fact_history.REPORT_DATE,
  fact_history.SUM_RST_TOTAL_NOTIONAL_VALUE 
  from PNL_DETAIL_RESULT_FACT_VIEW fact_history left join
  PNL_DETAIL_RESULT_FACT_MIN_DATE_VIEW subq
    on fact_history.DEAL_NUM = subq.DEAL_NUM
    and fact_history.REPORT_DATE = subq.REPORT_DATE 
  where exists(select 1 from AB_TRAN_VIEW a where a.deal_tracking_num = fact_history.DEAL_NUM )
"""
  
  dfHistory = spark.sql(SQL)
  dfHistory.createOrReplaceTempView("PNL_DETAIL_RESULT_FACT_HISTORY_VIEW")
  
  SQL = """
  select
  DEAL_NUM,
  PARAM_NUM,
  PROFILE_NUM,
  SUM_RST_TOTAL_NOTIONAL_VALUE
  FROM
  (
  select 
  DEAL_NUM,
  PARAM_NUM,
  PROFILE_NUM,
  SUM_RST_TOTAL_NOTIONAL_VALUE,
  row_number() over(partition by DEAL_NUM, PARAM_NUM, PROFILE_NUM order by REPORT_DATE ) row_num
  from PNL_DETAIL_RESULT_FACT_HISTORY_VIEW
  ) V where row_num = 1
  """
  dfHistory = spark.sql(SQL)
  dfHistory.createOrReplaceTempView("PNL_DETAIL_RESULT_FACT_HISTORY_VIEW")
  
  
  
  SQL = """
  select 
    a.DEAL_ATTRIBUTES_NK,
    a.EXECUTION_DATE,
    a.TRADE_CREATION_DATE,
    a.COMMITMENT_DATE,
    a.PARCEL_DATE,
    a.COUNTERPARTY_NK,
    a.SHELL_TRADING_PARTY_NK,
    a.TRADER_NK,
    a.DEAL_BROKER_NK,
    a.COMMODITY_NK,
    a.LOADING_LOCATION_NK,
    a.DISCHARGE_LOCATION_NK,
    a.DELIVERY_START_DATE,
    a.DELIVERY_END_DATE,
    a.DEAL_UNIT_OF_MEASURE_NK,
    a.PRICING_UNIT_OF_MEASURE_NK,
    a.DEAL_CCY_NK,
    a.DEAL_QTY,
    a.PRICE_QTY,
    a.DEAL_SUB_LEG_MULTIPLIER,
    a.SOURCE_LAST_DATE1,
    a.SOURCE_LAST_DATE2,
    a.SOURCE_LAST_DATE3,
    CASE WHEN a.TRAN_STATUS = 5 THEN 0 WHEN NVL(a.INS_NUM, -1) = -1 THEN (CASE WHEN a.NOTNL > 0 AND b.SUM_RST_TOTAL_NOTIONAL_VALUE < 0
    THEN b.SUM_RST_TOTAL_NOTIONAL_VALUE ELSE ABS(b.SUM_RST_TOTAL_NOTIONAL_VALUE) END) ELSE a.strike * ABS(a.NOTNL) END AS CCY_DEAL_VALUE,
   a.SRC_SYS_DEAL_HEADER_KEY
  from FACT_SUB_LEG_TEMP a
  left join PNL_DETAIL_RESULT_FACT_HISTORY_VIEW b
    ON a.deal_tracking_num = b.DEAL_NUM
    and a.PARAM_SEQ_NUM = b.PARAM_NUM
    and a.PROFILE_SEQ_NUM = b.PROFILE_NUM
  """
  
  dfSubLeg = spark.sql(SQL)
  dfSubLeg.show()
  return dfSubLeg
