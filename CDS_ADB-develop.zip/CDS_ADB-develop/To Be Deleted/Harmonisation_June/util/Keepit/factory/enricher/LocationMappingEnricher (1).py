# Databricks notebook source
# MAGIC %run ./../../MappingReader

# COMMAND ----------

# MAGIC %run ./../../JDBCSynapseTableLoader

# COMMAND ----------

def enrichLocationForMapping(spark,df,source_etrm):
  df.createOrReplaceTempView('LOCATION_TEMP')
  print(df.count())
  df = readMapping(spark,'LOCATION_CODE_TO_ISO_COUNTRY_CODE', source_etrm)
  df.createOrReplaceTempView('LOCATION_ISO_MAPPING')
  
 
  df = loadTable("tsa_curated.iso_country")
  df.createOrReplaceTempView('ISO_COUNTRY')
  
  SQL = """
    SELECT a.SRC_SYS_LOCATION_NK,
    a.LOCATION_NAME,
    a.LOCATION_TYPE,
    a.LOCATION_AREA,
    a.SOURCE_LAST_UPDATE,
    ud1.target_mapping_value LOCATION_ISO_COUNTRY_CODE,
    c.ISO_COUNTRY_CODE2 MAPPED_LOCATION_ISO_COUNTRY_CODE,
    c.ISO_COUNTRY_NAME LOCATION_COUNTRY_NAME,
    c.HRC_FLAG HIGH_RISK_COUNTRY_FLAG,
    c.EDD_FLAG EDD_COUNTRY_FLAG,
    c.GEC_FLAG GEC_COUNTRY_FLAG
    FROM LOCATION_TEMP a 
    left join LOCATION_ISO_MAPPING ud1
    on a.SRC_SYS_LOCATION_NK = ud1.source_mapping_value
    left join  ISO_COUNTRY c
    on ud1.target_mapping_value = c.ISO_COUNTRY_CODE2
    """
  df = spark.sql(SQL)
  df.show()
  
  df=df.withColumn("LOCATION_NAME",when(df.LOCATION_NAME.isNull(),lit('NULL'))
                    .otherwise(df.LOCATION_NAME))
  
  df=df.withColumn("LOCATION_TYPE",when(df.LOCATION_TYPE.isNull(),lit('NULL'))
                   .otherwise(df.LOCATION_TYPE))
  
  df=df.withColumn("LOCATION_AREA",when(df.LOCATION_AREA == '',lit(''))
                   .when(df.LOCATION_AREA.isNull(),lit(None))
                   .otherwise(df.LOCATION_AREA))
  
  df=df.withColumn("LOCATION_ISO_COUNTRY_CODE",when(df.LOCATION_ISO_COUNTRY_CODE.isNull(),"MAPPING DOES NOT EXIST")
                   .when(df.LOCATION_ISO_COUNTRY_CODE=='',"MAPPING DOES NOT EXIST")
                   .when(df.MAPPED_LOCATION_ISO_COUNTRY_CODE.isNull(),"TARGET MAPPING IS INVALID")
                   .otherwise(df.LOCATION_ISO_COUNTRY_CODE))

  df=df.withColumn("LOCATION_COUNTRY_NAME", when(df.LOCATION_ISO_COUNTRY_CODE=="MAPPING DOES NOT EXIST","MAPPING DOES NOT EXIST")
                 .when(df.LOCATION_ISO_COUNTRY_CODE== "TARGET MAPPING IS INVALID" ,"TARGET MAPPING IS INVALID")
                  .otherwise(df.LOCATION_COUNTRY_NAME))
  
  df=df.withColumn("HIGH_RISK_COUNTRY_FLAG",when(df.LOCATION_ISO_COUNTRY_CODE == "MAPPING DOES NOT EXIST","MAPPING DOES NOT EXIST")
                   .when(df.LOCATION_ISO_COUNTRY_CODE == "TARGET MAPPING IS INVALID","TARGET MAPPING IS INVALID")
                   .when(df.HIGH_RISK_COUNTRY_FLAG.isNull(),"N")
                   .otherwise(df.HIGH_RISK_COUNTRY_FLAG)                  
                  )
  
  df=df.withColumn("EDD_COUNTRY_FLAG",when(df.LOCATION_ISO_COUNTRY_CODE == "MAPPING DOES NOT EXIST","MAPPING DOES NOT EXIST")
                   .when(df.LOCATION_ISO_COUNTRY_CODE == "TARGET MAPPING IS INVALID","TARGET MAPPING IS INVALID")
                   .when(df.EDD_COUNTRY_FLAG.isNull(),"N")
                   .otherwise(df.EDD_COUNTRY_FLAG)
                  )
      
  df=df.withColumn("GEC_COUNTRY_FLAG",when(df.LOCATION_ISO_COUNTRY_CODE == "MAPPING DOES NOT EXIST","MAPPING DOES NOT EXIST")
                   .when(df.LOCATION_ISO_COUNTRY_CODE == "TARGET MAPPING IS INVALID","TARGET MAPPING IS INVALID")
                   .when(df.GEC_COUNTRY_FLAG.isNull(),"N")
                   .otherwise(df.GEC_COUNTRY_FLAG)
                  )
  df.show()
  df=df.drop("MAPPED_LOCATION_ISO_COUNTRY_CODE")
  df.show()
  print(df.count())
  return df
