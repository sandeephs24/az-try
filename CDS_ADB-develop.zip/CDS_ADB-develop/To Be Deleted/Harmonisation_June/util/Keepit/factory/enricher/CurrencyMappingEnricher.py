# Databricks notebook source
# MAGIC %run ./../../MappingReader

# COMMAND ----------

# MAGIC %run ./../../JDBCSynapseTableLoader

# COMMAND ----------

def enrich(spark,df,source_etrm):
  from pyspark.sql.functions import when
      
  df.createOrReplaceTempView('CURRENCY_TEMP')

  df = readMapping(spark,'CURRENCY_CODE_TO_ISO_CURRENCY_CODE',SOURCE_ETRM)
  df.createOrReplaceTempView('CURRENCY_ISO_MAPPING')


  df = loadTable("tsa_curated.iso_currency")
  df.createOrReplaceTempView('ISO_CURRENCY')

  SQL = """
  SELECT a.SRC_SYS_CURRENCY_NK as SRC_SYS_CURRENCY_NK,
  a.CURRENCY_CODE as CURRENCY_CODE,
  b.target_mapping_value as MAPPED_ISO_CURRENCY_CODE,
  c.ISO_CURRENCY_CODE as ISO_CURRENCY_CODE,
  c.ISO_CURRENCY_NAME as ISO_CURRENCY_NAME 
  FROM CURRENCY_TEMP a 
  left join CURRENCY_ISO_MAPPING b 
    on a.SRC_SYS_CURRENCY_NK = b.source_mapping_value 
  left join ISO_CURRENCY c 
    on b.target_mapping_value = c.ISO_CURRENCY_CODE
  """
  
  df = spark.sql(SQL)
    
  df=df.withColumn("ISO_CURRENCY_CODE",when(df.MAPPED_ISO_CURRENCY_CODE.isNull(),"MAPPING DOES NOT EXIST")
                       .when(df.ISO_CURRENCY_CODE.isNull(),"TARGET MAPPING IS INVALID")
                        .otherwise(df.ISO_CURRENCY_CODE))


  df=df.withColumn("ISO_CURRENCY_NAME", when(df.ISO_CURRENCY_CODE=="MAPPING DOES NOT EXIST","MAPPING DOES NOT EXIST")
                       .when(df.ISO_CURRENCY_CODE== "TARGET MAPPING IS INVALID" ,"TARGET MAPPING IS INVALID")
                        .otherwise(df.ISO_CURRENCY_NAME))

  df=df.drop("MAPPED_ISO_CURRENCY_CODE","CURRENCY_CODE")
     
  return df
