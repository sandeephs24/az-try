# Databricks notebook source
# MAGIC %run ./../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../DatasetConfigReader

# COMMAND ----------

def enrichFactSubLeg(dfSubLeg, spark, SOURCE_ETRM):
  dfSubLeg.createOrReplaceTempView("FACT_SUB_LEG_TEMP")
  
  df = executeJdbcQueryAndReturnDF("select * from tsa_curated.dim_commodity where src_sys_name = '{0}'".format(SOURCE_ETRM))
  df.createOrReplaceTempView("CURATED_DIM_COMMODITY")
  
  df = executeJdbcQueryAndReturnDF("select * from tsa_curated.dim_unit_of_measure where src_sys_name = '{0}'".format(SOURCE_ETRM))
  df.createOrReplaceTempView("dim_unit_of_measure")
  
  df = executeJdbcQueryAndReturnDF("select * from tsa_curated.ref_unit_of_measure_conversion")
  df.createOrReplaceTempView("REF_UNIT_OF_MEAURE_CONVERSION")
  
  # mk change  left join dim_unit_of_measure dim_uom  a was here
  SQL = """
  select
    fact_sub_leg.SRC_SYS_NAME,
    fact_sub_leg.RECORD_CREATED_DTTM,
    fact_sub_leg.DEAL_ATTRIBUTES_CK,
    fact_sub_leg.EXECUTION_DATE_CK,
    fact_sub_leg.TRADE_CREATION_DATE_CK,
    fact_sub_leg.COMMITMENT_DATE_CK,
    fact_sub_leg.PARCEL_DATE_CK,
    fact_sub_leg.COUNTERPARTY_CK,
    fact_sub_leg.SHELL_TRADING_PARTY_CK,
    fact_sub_leg.TRADER_CK,
    fact_sub_leg.DEAL_BROKER_CK,
    fact_sub_leg.COMMODITY_CK,
    fact_sub_leg.LOADING_LOCATION_CK,
    fact_sub_leg.DISCHARGE_LOCATION_CK,
    fact_sub_leg.DELIVERY_START_DATE_CK,
    fact_sub_leg.DELIVERY_END_DATE_CK,
    fact_sub_leg.DEAL_UNIT_OF_MEASURE_CK,
    fact_sub_leg.PRICING_UNIT_OF_MEASURE_CK,
    fact_sub_leg.DEAL_CCY_CK,
    fact_sub_leg.DEAL_QTY,
    fact_sub_leg.PRICE_QTY,
    fact_sub_leg.SOURCE_LAST_DATE1,
    fact_sub_leg.SOURCE_LAST_DATE2,
    fact_sub_leg.SOURCE_LAST_DATE3,
    fact_sub_leg.CCY_DEAL_VALUE,
    fact_sub_leg.GBP_DEAL_VALUE,
    fact_sub_leg.USD_DEAL_VALUE,
    fact_sub_leg.EUR_DEAL_VALUE,
    case
      when dim_uom.std_unit_of_measure_symbol_code = cmd.COMMODITY_UOM_SYMBOL_CODE 
      then fact_sub_leg.DEAL_QTY
      when cmd.COMMODITY_UOM_SYMBOL_CODE = "MAPPING DOES NOT EXIST" 
      or cmd.COMMODITY_UOM_SYMBOL_CODE = "TARGET MAPPING IS INVALID" 
      or cmd.COMMODITY_UOM_SYMBOL_CODE = "" 
      or cmd.COMMODITY_UOM_SYMBOL_CODE is null
      or dim_uom.std_unit_of_measure_symbol_code  = "MAPPING DOES NOT EXIST" 
      or dim_uom.std_unit_of_measure_symbol_code  = "TARGET MAPPING IS INVALID" 
      or dim_uom.std_unit_of_measure_symbol_code  = "" 
      or dim_uom.std_unit_of_measure_symbol_code is null
      then 0.0
      when dim_uom.std_unit_of_measure_symbol_code <> cmd.COMMODITY_UOM_SYMBOL_CODE 
      then fact_sub_leg.DEAL_QTY * ref_uom_conv.CONVERSION_FACTOR 
    end AS CMD_DEAL_QTY,
    fact_sub_leg.DEAL_SUB_LEG_MULTIPLIER AS DEAL_SUB_LEG_MULTIPLIER,
    fact_sub_leg.SRC_SYS_DEAL_HEADER_KEY
    from fact_sub_leg_temp fact_sub_leg
    left join CURATED_DIM_COMMODITY cmd 
      on fact_sub_leg.commodity_ck = cmd.commodity_ck
    left join dim_unit_of_measure dim_uom
      on fact_sub_leg.deal_unit_of_measure_ck = dim_uom.unit_of_measure_ck  
    left join REF_UNIT_OF_MEASURE_CONVERSION ref_uom_conv
      on from_standard_uom_code = dim_uom.std_unit_of_measure_symbol_code 
      and to_standard_uom_code = cmd.COMMODITY_UOM_SYMBOL_CODE
  """

  dfSubLeg = spark.sql(SQL)
      
  return dfSubLeg

# COMMAND ----------

def enrichFactSubLegWithCurrencyDealValueConversion(dfSubLeg, spark, SOURCE_ETRM):
  
  from pyspark.sql.functions import date_format
  from pyspark.sql.types import IntegerType
  dfSubLeg.show()
  print("here1")
  #dateformat = 'yyyyMMdd'
  #dfSubLeg = dfSubLeg.withColumn("EXECUTION_DATE",date_format(col("EXECUTION_DATE"),dateformat))
  #dfSubLeg.show()
  dfSubLeg = dfSubLeg.withColumn("EXECUTION_DATE",dfSubLeg.EXECUTION_DATE.cast('int'))
  dfSubLeg.createOrReplaceTempView("FACT_SUB_LEG_TEMP")
  dfSubLeg.show()
  
  readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, "ZEMA", 'vwCrossCurrency', "delta", 'vwCrossCurrency')
  readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, "ZEMA", 'SwiftCurrencyNames', "parquet", 'SwiftCurrencyNames')
  dfFx = spark.sql("select cc.currency , cc.BaseCurrency, date_format(cc.DateQuoted, 'yyyyMMdd') DateQuoted, cc.MeanRate from vwCrossCurrency cc where cc.BaseCurrency in ('GBP','USD','EUR')")
  
  dfFx = dfFx.withColumn("DateQuoted",dfFx.DateQuoted.cast(IntegerType()))
  dfFx.createOrReplaceTempView("FX_RATES")
  
  dfFx.show()
  
  
  df = executeJdbcQueryAndReturnDF("select * from tsa_curated.dim_currency where src_sys_name = '{0}'".format(SOURCE_ETRM))
  df.createOrReplaceTempView("DIM_CURRENCY")
  df.show()
  
  dfSubLeg,dfSubLega= add_converted_deal_value_for_input_currency(dfSubLeg,"GBP","GBP_DEAL_VALUE")
  dfSubLeg11,dfSubLegb= add_converted_deal_value_for_input_currency(dfSubLeg,"USD","USD_DEAL_VALUE")
  dfSubLeg12,dfSubLegc= add_converted_deal_value_for_input_currency(dfSubLeg11,"EUR","EUR_DEAL_VALUE")
  df = combine_deal_value_for_input_currency(dfSubLeg12,dfSubLega,dfSubLegb,dfSubLegc)
  dfSubLeg = df
  
  dfSubLeg.show()
  print(dfSubLeg.count())
  
  


  
  return dfSubLeg
  
  
  

# COMMAND ----------


def add_converted_deal_value_for_input_currency(df, currency_code, column_name):
  
  from pyspark.sql.functions import max
  from pyspark.sql.functions import min
  from pyspark.sql.functions import when
  from pyspark.sql.functions import col
  
  df.createOrReplaceTempView("FACT_SUB_LEG_TEMP")
  spark.sql("select execution_date from FACT_SUB_LEG_TEMP").show()
  print("here 1")
  df.printSchema()
  SQL = """
  select V.*, 
  case 
  when V.ISO_CURRENCY_CODE = '{0}' then CCY_DEAL_VALUE
  when 
  (
  V.ISO_CURRENCY_CODE <> '{1}' 
  and (V.ISO_CURRENCY_CODE is not null or   
      V.ISO_CURRENCY_CODE <> '')
  and conv_rate is not null
  )
  then CCY_DEAL_VALUE / conv_rate
  else
  0.0
  end as {2}
  from
  (
  SELECT	a.*,b.iso_currency_code,
  fx_rate.MeanRate as conv_rate,
  fx_rate.BaseCurrency,
  fx_rate.DateQuoted,
  row_number() over (partition by deal_attributes_ck order by fx_rate.DateQuoted desc) row_number
  FROM	FACT_SUB_LEG_TEMP a											
  left JOIN DIM_CURRENCY b											
    ON	a.DEAL_CCY_CK = b.CURRENCY_CK											
  left JOIN FX_RATES fx_rate											
    ON	b.ISO_CURRENCY_CODE = fx_rate.currency											
    AND	fx_rate.BaseCurrency = '{3}' 
    AND fx_rate.DateQuoted = a.execution_date
  ) V where row_number = 1
  """.format(currency_code, currency_code,column_name, currency_code)
   
  df = spark.sql(SQL)
  
  df.show()
  
  print("here 2")
  df.printSchema()
  
  df.createOrReplaceTempView("CONVERTED_TEMP")
  
 
    
  NON_CONVERTED_DEALS = """select deal_attributes_ck,EXECUTION_DATE, ccy_deal_value, iso_currency_code from  CONVERTED_TEMP where conv_rate is null"""
    
  df1 = spark.sql(NON_CONVERTED_DEALS)
    
  df1.createOrReplaceTempView("SUBLEG_RECORDS_NOT_CONVERTED") 
  
  MINEXECDATE = df1.select(min('EXECUTION_DATE')).first()[0]
  print('min exec date')
  print(MINEXECDATE)
  MAXEXECDATE = df1.select(max('EXECUTION_DATE')).first()[0] 
  print('max exec date')
  print(MAXEXECDATE)
  
  FX_RATES_LIMITED_SQL ="""
  select * from FX_RATES where currency = '{0}' and datequoted >= '{1}' and datequoted <='{2}'
  """.format(currency_code,MINEXECDATE,MAXEXECDATE)
  dFxLtd = spark.sql(FX_RATES_LIMITED_SQL)
  print("FX_RATES_LIMITED")
  dFxLtd.show()
  dFxLtd.createOrReplaceTempView("FX_RATES_LIMITED") 
  
  column_name_new = column_name + "_" + "_1"
  
  CALC_DEAL_VALUE= """
  select  V.*,
  case 
  when V.iso_currency_code = '{0}' then CCY_DEAL_VALUE
  when 
  (
  V.iso_currency_code <> '{1}' 
  and (V.iso_currency_code is not null or   
  V.iso_currency_code <> '')
  and conv_rate is not null
  )
  then CCY_DEAL_VALUE / conv_rate
  else
  0.0
  end as {2}
  from
  (
  SELECT a.*,
  fx_rate.MeanRate as conv_rate,
  fx_rate.BaseCurrency,
  fx_rate.DateQuoted,
  first_value(MeanRate) 
  over(
  partition by deal_attributes_ck 
  order by fx_rate.DateQuoted desc
  ) MeanRate1,
  rank() over(
  partition by deal_attributes_ck 
  order by fx_rate.DateQuoted desc
  ) rnk
  FROM SUBLEG_RECORDS_NOT_CONVERTED a 
  LEFT JOIN FX_RATES fx_rate                                                                             
  ON   a.iso_currency_code = fx_rate.currency                                                                            
  AND  fx_rate.BaseCurrency = '{3}'
  AND   fx_rate.DateQuoted <= a.execution_date
  ) V where rnk = 1
  """.format(currency_code, currency_code,column_name_new, currency_code)
  
  df2 = spark.sql(CALC_DEAL_VALUE)
  df2.createOrReplaceTempView("NONCONVERTED_TO_CONVERTED_DEALS")
  spark.sql("select CCY_DEAL_VALUE,conv_rate from NONCONVERTED_TO_CONVERTED_DEALS").show()
  
 
  df.show()
  df = df.drop('iso_currency_code')
  df = df.drop('currency')
  df = df.drop('BaseCurrency')
  df = df.drop('DateQuoted')
  df = df.drop('row_number')
  df = df.drop('conv_rate')
  print('CONVERTED DEALS')
  df.printSchema()
  
  
   
  return df,df2

# COMMAND ----------

def combine_deal_value_for_input_currency(df, df1, df2,df3):
  
   
  df.createOrReplaceTempView("CONVERTED_TEMP")   
 
  df1.createOrReplaceTempView("CONVERTED_TEMP_GBP")
  
  df2.createOrReplaceTempView("CONVERTED_TEMP_USD")
  
  df3.createOrReplaceTempView("CONVERTED_TEMP_EUR")
  #df2.show()
  
  JOIN_SQL = """
    select 
     a.SRC_SYS_NAME,
    a.RECORD_CREATED_DTTM,
    a.DEAL_ATTRIBUTES_CK,
    a.EXECUTION_DATE_CK,
    a.TRADE_CREATION_DATE_CK,
    a.COMMITMENT_DATE_CK,
    a.PARCEL_DATE_CK,
    a.COUNTERPARTY_CK,
    a.SHELL_TRADING_PARTY_CK,
    a.TRADER_CK,
    a.DEAL_BROKER_CK,
    a.COMMODITY_CK,
    a.LOADING_LOCATION_CK,
    a.DISCHARGE_LOCATION_CK,
    a.DELIVERY_START_DATE_CK,
    a.DELIVERY_END_DATE_CK,
    a.DEAL_UNIT_OF_MEASURE_CK,
    a.PRICING_UNIT_OF_MEASURE_CK,
    a.DEAL_CCY_CK,
    a.DEAL_QTY,
    a.PRICE_QTY,
    a.SOURCE_LAST_DATE1,
    a.SOURCE_LAST_DATE2,
    a.SOURCE_LAST_DATE3,
    a.CCY_DEAL_VALUE,
     CASE WHEN a.GBP_DEAL_VALUE = 0 or a.GBP_DEAL_VALUE = '' THEN b.GBP_DEAL_VALUE__1 ELSE  a.GBP_DEAL_VALUE END as GBP_DEAL_VALUE,
     CASE WHEN a.USD_DEAL_VALUE = 0 or a.USD_DEAL_VALUE = '' THEN c.USD_DEAL_VALUE__1 ELSE  a.USD_DEAL_VALUE END as USD_DEAL_VALUE,
     CASE WHEN a.EUR_DEAL_VALUE = 0 or a.EUR_DEAL_VALUE = '' THEN d.EUR_DEAL_VALUE__1 ELSE  a.EUR_DEAL_VALUE END as EUR_DEAL_VALUE,
    a.DEAL_SUB_LEG_MULTIPLIER,
    a.SRC_SYS_DEAL_HEADER_KEY
          FROM
     CONVERTED_TEMP a 
     LEFT JOIN
     CONVERTED_TEMP_GBP b
     ON
     a.DEAL_ATTRIBUTES_CK = b.deal_attributes_ck
     LEFT JOIN 
     CONVERTED_TEMP_USD c
      ON
     a.DEAL_ATTRIBUTES_CK = c.deal_attributes_ck
     LEFT JOIN
     CONVERTED_TEMP_EUR d
     ON
     a.DEAL_ATTRIBUTES_CK = d.deal_attributes_ck     
     
  """
  df = spark.sql(JOIN_SQL)
  return df
