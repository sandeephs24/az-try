# Databricks notebook source
# MAGIC %run ./../../MappingReader

# COMMAND ----------

# MAGIC %run ./../../JDBCSynapseTableLoader

# COMMAND ----------

def enrich(spark,df,source_etrm):
  df.createOrReplaceTempView('PARTY_TEMP')
  
  df = readMapping(spark,'COUNTRY_CODE_TO_ISO_COUNTRY_CODE',source_etrm)
  df.createOrReplaceTempView('iso_mapping')
  
  SQL = """
  SELECT a.*,
    b.target_mapping_value OPERATION_ISO_COUNTRY_CODE,
    c.target_mapping_value LEGAL_ISO_COUNTRY_CODE
    FROM PARTY_TEMP a 
    left join iso_mapping b
      on a.OPERATION_COUNTRY_NAME = source_mapping_value
    left join iso_mapping c
      on LEGAL_COUNTRY_NAME = source_mapping_value
  """
  
  df = spark.sql(SQL)
  df.createOrReplaceTempView('PARTY_TEMP')
  
  SQL = """
    SELECT a.* ,
    b.gec_flag GEC_OPERATION_COUNTRY_FLAG,
    b.hrc_flag HIGH_RISK_OPERATION_COUNTRY_FLAG,
    b.edd_flag EDD_OPERATION_COUNTRY_FLAG,
    c.gec_flag GEC_LEGAL_COUNTRY_FLAG,
    c.hrc_flag HIGH_RISK_LEGAL_COUNTRY_FLAG,
    c.edd_flag EDD_LEGAL_COUNTRY_FLAG
    from PARTY_TEMP a 
    left join ISO_COUNTRY b
      on OPERATION_ISO_COUNTRY_CODE = iso_country_code
    left join ISO_COUNTRY c
      on LEGAL_ISO_COUNTRY_CODE = iso_country_code
  """
  
  df = spark.sql(SQL)
  
  return df
