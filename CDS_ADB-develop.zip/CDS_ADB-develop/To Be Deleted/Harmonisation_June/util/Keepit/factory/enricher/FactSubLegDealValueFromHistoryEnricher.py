# Databricks notebook source
# MAGIC %run ./../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../DatasetConfigReader

# COMMAND ----------

def enrichFactSubLegReplaceCCYDealValueWithHistoryData(dfSubLeg, spark, SOURCE_ETRM):
  from pyspark.sql.functions import col
  from pyspark.sql.functions import date_format
  dfSubLeg.show()
  dfSubLeg.createOrReplaceTempView("FACT_SUB_LEG_TEMP")
  readDatasetConfigAndCreateTempView(spark, SOURCE_ETRM, 'PNL_DETAIL_RESULT_FACT', "parquet", 'PNL_DETAIL_RESULT_FACT')
  
  SQL = """
with PNL_DETAIL_RESULT_FACT_VIEW
as(
  select FCT2.DEAL_TRACKING_NUM,  
  FCT2.PERIOD_START_DT, 
  fct2.period_end_dt, 
  FCT2.DEAL_LEG_SEQ_NUM, 
  fct2.TRAN_NUM,
  FCT2.DEAL_LEG_PROFILE_SEQ_NUM,
  FCT2.QUOTE_DATE_DIM_KEY,
  sum(FCT2.TOTAL_VAL) SUM_TOTAL_VAL
  from PNL_DETAIL_RESULT_FACT fct2
  where fct2.src_system_Id = 9 
  group by FCT2.DEAL_TRACKING_NUM, 
  FCT2.PERIOD_START_DT, 
  fct2.period_end_dt, 
  FCT2.DEAL_LEG_SEQ_NUM,
  fct2.TRAN_NUM,
  FCT2.DEAL_LEG_PROFILE_SEQ_NUM,
  FCT2.QUOTE_DATE_DIM_KEY
),
PNL_DETAIL_RESULT_FACT_MIN_DATE_VIEW
as
(
  select FCT.DEAL_TRACKING_NUM, MIN(FCT.QUOTE_DATE_DIM_KEY) quote_date_dim_key
  from PNL_DETAIL_RESULT_FACT fct
  where 
  fct.src_system_Id = 9 
  GROUP BY FCT.DEAL_TRACKING_NUM
),
AB_TRAN_VIEW
as(
select deal_tracking_num
from ab_tran t
left join instruments bz
      on t.ins_type = bz.id_number
where bz.name not in ('CASH' ,
                          'COMM-FEE' ,
                          'COMM-IMB' ,
                          'COMM-INV' ,
                          'COMM-INV-PAL' ,
                          'COMM-MAD-SETTLE' ,
                          'COMM-PAL' ,
                          'COMM-PREPAY' ,
                          'COMM-STOR' ,
                          'COMM-TRANS' ,
                          'COMM-TRANS-PLAN' ,
                          'COMM-MAD-JE','COMM-IMB-SENA')      
)
SELECT 
  fact_history.DEAL_TRACKING_NUM,  
  fact_history.PERIOD_START_DT, 
  fact_history.period_end_dt, 
  fact_history.DEAL_LEG_SEQ_NUM, 
  fact_history.TRAN_NUM,
  fact_history.DEAL_LEG_PROFILE_SEQ_NUM,
  fact_history.QUOTE_DATE_DIM_KEY,
  fact_history.SUM_TOTAL_VAL 
  from PNL_DETAIL_RESULT_FACT_VIEW fact_history left join
  PNL_DETAIL_RESULT_FACT_MIN_DATE_VIEW subq
    on fact_history.DEAL_TRACKING_NUM = subq.deal_tracking_num
    and fact_history.QUOTE_DATE_DIM_KEY = subq.quote_date_dim_key 
  where exists(select 1 from AB_TRAN_VIEW a where a.deal_tracking_num = fact_history.DEAL_TRACKING_NUM )
"""
  
  dfHistory = spark.sql(SQL)
  dfHistory.createOrReplaceTempView("PNL_DETAIL_RESULT_FACT_HISTORY_VIEW")
  
  SQL = """
  select
  DEAL_TRACKING_NUM,
  DEAL_LEG_SEQ_NUM,
  DEAL_LEG_PROFILE_SEQ_NUM,
  sum_total_val
  FROM
  (
  select 
  DEAL_TRACKING_NUM,
  DEAL_LEG_SEQ_NUM,
  DEAL_LEG_PROFILE_SEQ_NUM,
  sum_total_val,
  row_number() over(partition by DEAL_TRACKING_NUM, DEAL_LEG_SEQ_NUM, DEAL_LEG_PROFILE_SEQ_NUM order by QUOTE_DATE_DIM_KEY ) row_num
  from PNL_DETAIL_RESULT_FACT_HISTORY_VIEW
  ) V where row_num = 1
  """
  dfHistory = spark.sql(SQL)
  dfHistory.createOrReplaceTempView("PNL_DETAIL_RESULT_FACT_HISTORY_VIEW")
  
  
  
  SQL = """
  select 
    a.DEAL_ATTRIBUTES_NK,
    a.EXECUTION_DATE,
    a.TRADE_CREATION_DATE,
    a.COMMITMENT_DATE,
    a.PARCEL_DATE,
    a.COUNTERPARTY_NK,
    a.SHELL_TRADING_PARTY_NK,
    a.TRADER_NK,
    a.DEAL_BROKER_NK,
    a.COMMODITY_NK,
    a.LOADING_LOCATION_NK,
    a.DISCHARGE_LOCATION_NK,
    a.DELIVERY_START_DATE,
    a.DELIVERY_END_DATE,
    a.DEAL_UNIT_OF_MEASURE_NK,
    a.PRICING_UNIT_OF_MEASURE_NK,
    a.DEAL_CCY_NK,
    a.DEAL_QTY,
    a.PRICE_QTY,
    a.DEAL_SUB_LEG_MULTIPLIER,
    a.SOURCE_LAST_DATE1,
    a.SOURCE_LAST_DATE2,
    a.SOURCE_LAST_DATE3,
    CASE WHEN a.TRAN_STATUS = 5 THEN 0 WHEN NVL(a.INS_NUM, -1) = -1 THEN (CASE WHEN a.NOTNL > 0 AND b.sum_total_val < 0
    THEN b.sum_total_val ELSE ABS(b.sum_total_val) END) ELSE a.strike * ABS(a.NOTNL) END AS CCY_DEAL_VALUE,
   a.SRC_SYS_DEAL_HEADER_KEY
  from FACT_SUB_LEG_TEMP a
  left join PNL_DETAIL_RESULT_FACT_HISTORY_VIEW b
    ON a.deal_tracking_num = b.deal_tracking_num
    and a.PARAM_SEQ_NUM = b.DEAL_LEG_SEQ_NUM
    and a.PROFILE_SEQ_NUM = b.DEAL_LEG_PROFILE_SEQ_NUM
  """
  
  dfSubLeg = spark.sql(SQL)
  dfSubLeg.show()
  return dfSubLeg
