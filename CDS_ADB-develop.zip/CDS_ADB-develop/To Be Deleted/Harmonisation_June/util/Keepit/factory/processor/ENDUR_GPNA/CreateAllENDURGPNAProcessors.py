# Databricks notebook source
# MAGIC %run ./EndurGPNABrokerProcessor

# COMMAND ----------

# MAGIC %run ./EndurGPNACommodityProcessor

# COMMAND ----------

# MAGIC %run ./EndurGPNACounterPartyProcessor

# COMMAND ----------

# MAGIC %run ./EndurGPNALocationProcessor

# COMMAND ----------

# MAGIC %run ./EndurGPNADealAttributesProcessor

# COMMAND ----------

# MAGIC %run ./EndurGPNATraderProcessor

# COMMAND ----------

# MAGIC %run ./EndurGPNACurrencyProcessor

# COMMAND ----------

# MAGIC %run ./EndurGPNAUnitOfMeasureProcessor

# COMMAND ----------

# MAGIC %run ./FACT/EndurGPNAFactProcessor
