# Databricks notebook source
# MAGIC %run ./../DatasetProcessor

# COMMAND ----------

class EndurSLMTDealAttributesProcessor(DatasetProcessor):
    
    def process(spark, df,source_etrm):
        from pyspark.sql import functions as F
        
        df = df.withColumn('SRC_SYS_NAME',lit(source_etrm))
        df = df.withColumn('DEAL_ATTRIBUTES_CK',F.concat(col('SRC_SYS_NAME'),F.lit('_'),F.col('SRC_SYS_DEAL_SUB_LEG_KEY')) )
        df = df.withColumn('RECORD_CREATED_DTTM',F.current_timestamp() )
        for column in df.columns:
          df = df.withColumn(column,F.when(F.trim(df[column])=="","NULL AT SOURCE").otherwise(df[column]))
        df = df.na.fill({'SRC_SYSTEM_DEAL_TYPE_CODE':'NULL AT SOURCE'})
        df = df.na.fill({'SRC_SYSTEM_DEAL_SUBTYPE_CODE':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_HEADER_BUY_SELL_FLAG':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_SPOT_TERM_IND':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_AGREEMENT_TYPE_DESCRIPTION':'NULL AT SOURCE'})
        df = df.na.fill({'HEADER_DEAL_STATUS':'NULL AT SOURCE'})
        df = df.na.fill({'PARENT_CONTRACT_NUMBER':'NULL AT SOURCE'})
        df = df.na.fill({'CONTRACT_NUMBER':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_BOOK_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_LEG_REFERENCE':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_LEG_BUY_SELL_FLAG':'NULL AT SOURCE'})
        df = df.na.fill({'SUB_LEG_DEAL_STATUS':'NULL AT SOURCE'})
        #df = df.na.fill({'DEAL_PRICE':0.0})
        df = df.na.fill({'PRICING_TYPE':'NULL AT SOURCE'})
        df = df.na.fill({'PRICING_COMPONENT':'NULL AT SOURCE'})
        #df = df.na.fill({'PREMIUM_FLOAT_SPREAD':0.0})
        #df = df.na.fill({'INDEX_FACTOR':0.0})
        df = df.na.fill({'PRICING_STATUS':'NULL AT SOURCE'})
        df = df.na.fill({'CALL_PUT_FLAG':'NULL AT SOURCE'})
        #df = df.na.fill({'OPTION_STRIKE_PRICE':0.0})
        #df = df.na.fill({'OPTION_PREMIUM_PRICE':0.0})
        df = df.na.fill({'VESSEL_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_SUB_LEG_REFERENCE':'NULL AT SOURCE'})
        df = df.na.fill({'SETTLEMENT_TYPE':'NULL AT SOURCE'})
        df = df.na.fill({'BILL_OF_LADING_DATE':'N/A'})
        #df = deriveDealInstrumentClassification(df)
        
        df = df.withColumn("PARENT_CONTRACT_NUMBER",when(df.PARENT_CONTRACT_NUMBER.isNull(),"NULL AT SOURCE")
                       .when(df.PARENT_CONTRACT_NUMBER == '',"NULL AT SOURCE")
                        .otherwise(df.PARENT_CONTRACT_NUMBER))
        
        df = df.withColumn("CONTRACT_NUMBER",when(df.CONTRACT_NUMBER.isNull(),"NULL AT SOURCE")
                       .when(df.CONTRACT_NUMBER == '',"NULL AT SOURCE")
                        .otherwise(df.CONTRACT_NUMBER))
        
        #df.drop("DEAL_INSTRUMENT_CLASSIFICATION")
        df.createOrReplaceTempView("ENDUR_SLMT_DIM_DEAL_ATTRIBUTES")
        
        SQL = """
        SELECT a.*,
        CASE 
        WHEN SRC_SYSTEM_DEAL_TYPE_CODE = 'ComSwap' THEN 'SWAP'					
        WHEN SRC_SYSTEM_DEAL_TYPE_CODE IN ( 'ComOpt' , 'ComOptFut' )THEN 'OPTION'					
        WHEN SRC_SYSTEM_DEAL_TYPE_CODE = 'Power' 
        AND SRC_SYSTEM_DEAL_SUBTYPE_CODE IN ('PWR-SWAPTION-CALL','PWR-SWAPTION-PUT','PO-GEN-CALL-D') THEN 'OPTION'	
        WHEN SRC_SYSTEM_DEAL_TYPE_CODE = 'Power' 
        AND SRC_SYSTEM_DEAL_SUBTYPE_CODE IN ('PWR-HRO-SETTLE','PWR-SWAP') THEN 'SWAP'					
        WHEN SRC_SYSTEM_DEAL_TYPE_CODE = 'Power' 
        AND SRC_SYSTEM_DEAL_SUBTYPE_CODE IN ('PWR-PHYS') THEN 'FORWARD'					
        WHEN SRC_SYSTEM_DEAL_TYPE_CODE = 'Commodity' 
        AND SRC_SYSTEM_DEAL_SUBTYPE_CODE IN ('COMM-TIME-SWAP','COMM-LOCATION-SWAP','COMM-BEACH-SWAP','COMM-BEACH-SWAP-HUB','GAS-OTC-SWAP') 
        THEN 'SWAP'	
        WHEN SRC_SYSTEM_DEAL_TYPE_CODE = 'Commodity' 
        AND SRC_SYSTEM_DEAL_SUBTYPE_CODE IN ('COMM-EXCH-LUFG','COMM-PHYS','COMM-PHYS-AGG','COMM-PHYS-AGG-TERMINAL', 'COMM-PHYS-BORROW' ,              'RENEWABLE-PHYS','COMM-FUEL','COMM-NGL','COMM-PHYS-CRUDE','COMM-PHYS-IDX','COMM-PHYS-NGL','COMM-PRODUCTION',
        'COMM-RETRO','GAS', 'GAS-FOR-NGL','GASGDA','COMM-BAL-FWD','COMM-PHYS-TERMINAL','GAS-LOAD-FOLLOWING-HEDGE') THEN 'FORWARD'					
       WHEN SRC_SYSTEM_DEAL_TYPE_CODE = 'Commodity' AND SRC_SYSTEM_DEAL_SUBTYPE_CODE IN ('COMM-CASH-FLOW','COMM-EXCH',
       'COMM-FLOW','GASPHYSBASIS','COMM-BAL-CURRENT','COMM-BAL-FWD','GASIDX') THEN 'FUTURE'					
       WHEN SRC_SYSTEM_DEAL_TYPE_CODE = 'ComFut' THEN 'FUTURE'					
       WHEN SRC_SYSTEM_DEAL_TYPE_CODE = 'FX' AND SRC_SYSTEM_DEAL_SUBTYPE_CODE IN ('FX') THEN 'SPOT'
       WHEN SRC_SYSTEM_DEAL_TYPE_CODE = 'Commodity' AND SRC_SYSTEM_DEAL_SUBTYPE_CODE IN ('GAS-OTC-SWAPTION-CALL','GAS-OTC-SWAPTION-PUT') THEN 'OPTION'
       ELSE 'NOT MAPPED'
       END as DEAL_INSTRUMENT_CLASSIFICATION
        FROM ENDUR_SLMT_DIM_DEAL_ATTRIBUTES a
        """
        
        df = spark.sql(SQL)
        df.show()
        
        return df

# COMMAND ----------

def deriveDealInstrumentClassification(df):
  df = df.withColumn("DEAL_INSTRUMENT_CLASSIFICATION",
  when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='ComSwap') , 'SWAP')
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"] in ('ComOpt','ComOptFut')) , 'OPTION')
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='Power') 
  & (df["SRC_SYSTEM_DEAL_SUBTYPE_CODE"] in ('PWR-SWAPTION-CALL','PWR-SWAPTION-PUT','PO-GEN-CALL-D')) , 'OPTION')
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='Power') 
  & (df["SRC_SYSTEM_DEAL_SUBTYPE_CODE"] in ('PWR-HRO-SETTLE','PWR-SWAP')) , 'SWAP')
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='Power') 
  & (df["SRC_SYSTEM_DEAL_SUBTYPE_CODE"] in ('PWR-PHYS')) , 'FORWARD')
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='Commodity') 
  & (df["SRC_SYSTEM_DEAL_SUBTYPE_CODE"] in ('COMM-TIME-SWAP','COMM-LOCATION-SWAP','COMM-BEACH-SWAP','COMM-BEACH-SWAP-HUB','GAS-OTC-SWAP')) , 'SWAP')
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='Commodity') 
  & (df["SRC_SYSTEM_DEAL_SUBTYPE_CODE"] in ('COMM-EXCH-LUFG','COMM-PHYS','COMM-PHYS-AGG','COMM-PHYS-AGG-TERMINAL','COMM-PHYS-BORROW','RENEWABLE-PHYS','COMM-FUEL','COMM-NGL','COMM-PHYS-CRUDE','COMM-PHYS-IDX','COMM-PHYS-NGL','COMM-PRODUCTION','COMM-RETRO','GAS','GAS-FOR-NGL','GASGDA','COMM-BAL-FWD','COMM-PHYS-TERMINAL')) , 'FORWARD')      
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='Commodity') 
  & (df["SRC_SYSTEM_DEAL_SUBTYPE_CODE"] in ('COMM-CASH-FLOW','COMM-EXCH','COMM-FLOW','GASPHYSBASIS','COMM-BAL-CURRENT','COMM-BAL-FWD','GASIDX')) , 'FUTURE')
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='ComFut') , 'FUTURE')
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='FX') 
  & (df["SRC_SYSTEM_DEAL_SUBTYPE_CODE"] in ('FX')) , 'SPOT')
  .otherwise('NOT MAPPED')
  )
  
  return df
