# Databricks notebook source
# MAGIC %run ./../DatasetProcessor

# COMMAND ----------

class AligneDealAttributesProcessor(DatasetProcessor):
    
    def process(spark, df,source_etrm):
        from pyspark.sql import functions as F
        
        df = df.withColumn('src_sys_name',lit(source_etrm))
        df = df.withColumn('deal_attributes_ck',F.concat(col('src_sys_name'),F.lit('_'),F.col('SRC_SYS_DEAL_SUB_LEG_KEY')) )
        df = df.withColumn('RECORD_CREATED_DTTM',F.current_timestamp() )
       
        df = df.na.fill({'SRC_SYSTEM_DEAL_TYPE_CODE':'NULL AT SOURCE'})
        df = df.na.fill({'SRC_SYSTEM_DEAL_SUBTYPE_CODE':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_HEADER_BUY_SELL_FLAG':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_SPOT_TERM_IND':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_AGREEMENT_TYPE_DESCRIPTION':'NULL AT SOURCE'})
        df = df.na.fill({'HEADER_DEAL_STATUS':'NULL AT SOURCE'})
        #df = df.na.fill({'PARENT_CONTRACT_NUMBER':'NULL AT SOURCE'})
        #df = df.na.fill({'CONTRACT_NUMBER':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_BOOK_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_LEG_REFERENCE':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_LEG_BUY_SELL_FLAG':'NULL AT SOURCE'})
        df = df.na.fill({'SUB_LEG_DEAL_STATUS':'NULL AT SOURCE'})
        #df = df.na.fill({'DEAL_PRICE':0.0})
        df = df.na.fill({'PRICING_TYPE':'NULL AT SOURCE'})
        df = df.na.fill({'PRICING_COMPONENT':'NULL AT SOURCE'})
        #df = df.na.fill({'PREMIUM_FLOAT_SPREAD':0.0})
        #df = df.na.fill({'INDEX_FACTOR':0.0})
        df = df.na.fill({'PRICING_STATUS':'NULL AT SOURCE'})
        df = df.na.fill({'CALL_PUT_FLAG':'NULL AT SOURCE'})
        #df = df.na.fill({'OPTION_STRIKE_PRICE':0.0})
        #df = df.na.fill({'OPTION_PREMIUM_PRICE':0.0})
        df = df.na.fill({'VESSEL_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_SUB_LEG_REFERENCE':'NULL AT SOURCE'})
        df = df.na.fill({'SETTLEMENT_TYPE':'NULL AT SOURCE'})
        df = df.na.fill({'BILL_OF_LADING_DATE':'NULL AT SOURCE'})
        
        df = df.withColumn("PARENT_CONTRACT_NUMBER",when(df.PARENT_CONTRACT_NUMBER.isNull(),"NULL AT SOURCE")
                       .when(df.PARENT_CONTRACT_NUMBER == '',"NULL AT SOURCE")
                        .otherwise(df.PARENT_CONTRACT_NUMBER))
        
        df = df.withColumn("CONTRACT_NUMBER",when(df.CONTRACT_NUMBER.isNull(),"NULL AT SOURCE")
                       .when(df.CONTRACT_NUMBER == '',"NULL AT SOURCE")
                        .otherwise(df.CONTRACT_NUMBER))
        
        
           
        df.show(10,False)
        
        return df
