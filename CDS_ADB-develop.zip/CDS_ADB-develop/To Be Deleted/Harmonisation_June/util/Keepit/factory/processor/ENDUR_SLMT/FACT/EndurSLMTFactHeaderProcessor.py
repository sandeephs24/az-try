# Databricks notebook source
# MAGIC %run ./../../PROCESSOR_UTIL/FactProcessorUtil

# COMMAND ----------

class EndurSLMTFactHeaderProcessor(DatasetProcessor):
    
    dateformat = 'yyyymmdd'
    
    def process(df,spark,source_etrm, metricDict):
        
        (df, metricDict) = processFactHeader(df, spark,source_etrm, metricDict)
        return (df, metricDict)
