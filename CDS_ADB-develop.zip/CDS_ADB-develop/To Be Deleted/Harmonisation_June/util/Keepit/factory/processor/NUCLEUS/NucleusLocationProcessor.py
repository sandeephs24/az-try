# Databricks notebook source
# MAGIC %run ./../DatasetProcessor

# COMMAND ----------

class NucleusLocationProcessor(DatasetProcessor):
    
    def process(df,source_etrm):
        from pyspark.sql import functions as F
        
        df = df.withColumn('src_sys_name',lit(source_etrm))
        df = df.withColumn('location_ck',F.concat(col('src_sys_name'),F.lit('_'),F.col('src_sys_location_nk')) )
        df = df.withColumn('RECORD_CREATED_DTTM',F.current_timestamp() )
        df.show()
        
        return df
