# Databricks notebook source
# MAGIC %run ./../DatasetProcessor

# COMMAND ----------

class DexTraderProcessor(DatasetProcessor):
    
    def process(df,source_etrm):
        from pyspark.sql import functions as F
        
        df = df.withColumn('src_sys_name',lit(source_etrm))
        df = df.withColumn('trader_ck',F.concat(col('src_sys_name'),F.lit('_'),F.col('src_sys_trader_nk')) )
        df = df.withColumn('record_created_dttm',F.current_timestamp() )
        df = df.withColumn('source_last_update',F.date_trunc("second",col('source_last_update')))
        df = df.na.fill({'TRADER_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'TRADER_FIRST_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'TRADER_LAST_NAME':'NULL AT SOURCE'})
        df.show()
        
        return df
