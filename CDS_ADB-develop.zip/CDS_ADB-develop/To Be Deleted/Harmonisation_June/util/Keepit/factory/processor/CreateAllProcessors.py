# Databricks notebook source
# MAGIC %run ./ENDUR_GPNA/CreateAllENDURGPNAProcessors

# COMMAND ----------

# MAGIC %run ./DEX/CreateAllDexProcessors

# COMMAND ----------

# MAGIC %run ./REFERENCE/CreateAllReferenceProcessors
