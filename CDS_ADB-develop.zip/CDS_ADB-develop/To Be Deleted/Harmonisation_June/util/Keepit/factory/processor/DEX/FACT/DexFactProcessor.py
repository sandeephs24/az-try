# Databricks notebook source
# MAGIC %run ./../../DatasetProcessor

# COMMAND ----------

# MAGIC %run ./DexFactHeaderProcessor

# COMMAND ----------

# MAGIC %run ./DexFactLegProcessor

# COMMAND ----------

# MAGIC %run ./DexFactSubLegProcessor

# COMMAND ----------

class DexFactProcessor(DatasetProcessor):
    
    def process(dfFactHeader,dfFactLeg,dfFactSubLeg,spark,source_etrm, metricDict):
        
        
        (dfFactHeader,metricDict) = DexFactHeaderProcessor.process(dfFactHeader,spark,source_etrm, metricDict)
        (dfFactLeg,metricDict) = DexFactLegProcessor.process(dfFactLeg,spark,source_etrm, metricDict)
        (dfFactSubLeg,metricDict) = DexFactSubLegProcessor.process(dfFactSubLeg,spark,source_etrm, metricDict)
        
        return (dfFactHeader,dfFactLeg,dfFactSubLeg,metricDict)
