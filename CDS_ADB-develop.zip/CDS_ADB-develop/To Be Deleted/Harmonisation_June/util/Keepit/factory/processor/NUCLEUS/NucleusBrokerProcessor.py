# Databricks notebook source
# MAGIC %run ./../DatasetProcessor

# COMMAND ----------

class NucleusBrokerProcessor(DatasetProcessor):
    
    def process(df,source_etrm):
        from pyspark.sql import functions as F
        
        df = df.withColumn('SRC_SYS_NAME',lit(source_etrm))
        df = df.withColumn('BROKER_CK',F.concat(col('SRC_SYS_NAME'),F.lit('_'),F.col('SRC_SYS_BROKER_NK')) )
        df = df.withColumn('RECORD_CREATED_DTTM',F.current_timestamp() )
        df = df.na.fill({'BROKER_NAME':'NULL AT SOURCE'})
        #df = df.na.fill({'ACTIVE_BROKER_FLAG':'NULL AT SOURCE'})
        df=df.withColumn("ACTIVE_BROKER_FLAG",when(df.ACTIVE_BROKER_FLAG.isNull(),"NULL AT SOURCE")
                       .when(df.ACTIVE_BROKER_FLAG=='',"NULL AT SOURCE")
                        .otherwise(df.ACTIVE_BROKER_FLAG))
        df.show()
        return df
