# Databricks notebook source
# MAGIC %run ./../DatasetProcessor

# COMMAND ----------

class DexBrokerProcessor(DatasetProcessor):
    
    def process(df,source_etrm):
        from pyspark.sql import functions as F
        
        print('starting processor')
        df = df.withColumn('src_sys_name',lit(source_etrm))
        df = df.withColumn('broker_ck',F.concat(col('src_sys_name'),F.lit('_'),F.col('src_sys_broker_nk')) )
        df = df.withColumn('record_created_dttm',F.current_timestamp() )
        df = df.na.fill({'BROKER_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'ACTIVE_BROKER_FLAG':'NULL AT SOURCE'})
        df.show()
        print('processor completed')
        
        return df
