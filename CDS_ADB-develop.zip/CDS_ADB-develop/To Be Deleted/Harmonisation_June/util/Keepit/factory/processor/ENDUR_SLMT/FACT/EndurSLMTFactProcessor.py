# Databricks notebook source
# MAGIC %run ./../../DatasetProcessor

# COMMAND ----------

# MAGIC %run ./EndurSLMTFactHeaderProcessor

# COMMAND ----------

# MAGIC %run ./EndurSLMTFactLegProcessor

# COMMAND ----------

# MAGIC %run ./EndurSLMTFactSubLegProcessor

# COMMAND ----------

class EndurSLMTFactProcessor(DatasetProcessor):
    
    def process(dfFactHeader,dfFactLeg,dfFactSubLeg,spark,source_etrm, metricDict):
        
        
        (dfFactHeader, metricDict) = EndurSLMTFactHeaderProcessor.process(dfFactHeader,spark,source_etrm, metricDict)
        (dfFactLeg, metricDict) = EndurSLMTFactLegProcessor.process(dfFactLeg,spark,source_etrm, metricDict)
        (dfFactSubLeg, metricDict) = EndurSLMTFactSubLegProcessor.process(dfFactSubLeg,spark,source_etrm, metricDict)
        
        return (dfFactHeader,dfFactLeg,dfFactSubLeg, metricDict)
