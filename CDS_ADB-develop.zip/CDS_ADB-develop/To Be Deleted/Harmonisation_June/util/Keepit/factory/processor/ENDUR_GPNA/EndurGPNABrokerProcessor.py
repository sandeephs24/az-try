# Databricks notebook source
# MAGIC %run ./../DatasetProcessor

# COMMAND ----------

class EndurGPNABrokerProcessor(DatasetProcessor):
    
    def process(df,source_etrm):
        from pyspark.sql import functions as F
        
        print('starting processor')
        df = df.withColumn('SRC_SYS_NAME',lit(source_etrm))
        df = df.withColumn('BROKER_CK',F.concat(col('SRC_SYS_NAME'),F.lit('_'),F.col('SRC_SYS_BROKER_NK')) )
        df = df.withColumn('RECORD_CREATED_DTTM',F.current_timestamp() )
        df = df.withColumn('ACTIVE_BROKER_FLAG',
                          F.when(col("ACTIVE_BROKER_FLAG") == "AUTHORIZED","Y")
                          .otherwise("N") 
                          )
        df = df.na.fill({'BROKER_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'ACTIVE_BROKER_FLAG':'NULL AT SOURCE'})
        df.show()
        print('processor completed')
        return df
