# Databricks notebook source
# MAGIC %run ./../../PROCESSOR_UTIL/FactProcessorUtil

# COMMAND ----------

class DexFactHeaderProcessor(DatasetProcessor):
    
    dateformat = 'yyyyMMdd'
    
    def process(df,spark,source_etrm, metricDict):
        
        (df, metricDict) = processFactHeader(df, spark,source_etrm, metricDict)
        return (df, metricDict)
