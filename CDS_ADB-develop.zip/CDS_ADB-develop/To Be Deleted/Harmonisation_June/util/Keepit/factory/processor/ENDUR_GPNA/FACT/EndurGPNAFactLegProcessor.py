# Databricks notebook source
# MAGIC %run ./../../PROCESSOR_UTIL/FactProcessorUtil

# COMMAND ----------

class EndurGPNAFactLegProcessor(DatasetProcessor):
    
    def process(df,spark,source_etrm, metricDict):
        
        
        (df, metricDict) = processFactLeg(df,spark, source_etrm, metricDict)

        return (df, metricDict)
