# Databricks notebook source
# MAGIC %run ./../DatasetProcessor

# COMMAND ----------

class DexCommodityProcessor(DatasetProcessor):
    
    def process(df,source_etrm):
        from pyspark.sql import functions as F
        
        df = df.withColumn('SRC_SYS_NAME',lit(source_etrm))
        df = df.withColumn('COMMODITY_CK',F.concat(col('SRC_SYS_NAME'),F.lit('_'),F.col('SRC_SYS_COMMODITY_NK')) )
        df = df.withColumn('RECORD_CREATED_DTTM',F.current_timestamp() )
        df.show()
        
        return df
