# Databricks notebook source
# MAGIC %run ./../../DatasetProcessor

# COMMAND ----------

# MAGIC %run ./NucleusFactHeaderProcessor

# COMMAND ----------

# MAGIC %run ./NucleusFactLegProcessor

# COMMAND ----------

# MAGIC %run ./NucleusFactSubLegProcessor

# COMMAND ----------

class NucleusFactProcessor(DatasetProcessor):
    
    def process(dfFactHeader,dfFactLeg,dfFactSubLeg,spark,source_etrm, metricDict):
        
        
        (dfFactHeader,metricDict) = NucleusFactHeaderProcessor.process(dfFactHeader,spark,source_etrm, metricDict)
        (dfFactLeg,metricDict) = NucleusFactLegProcessor.process(dfFactLeg,spark,source_etrm, metricDict)
        (dfFactSubLeg,metricDict) = NucleusFactSubLegProcessor.process(dfFactSubLeg,spark,source_etrm, metricDict)
        
        return (dfFactHeader,dfFactLeg,dfFactSubLeg,metricDict)
