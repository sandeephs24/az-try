# Databricks notebook source
# MAGIC %run ./DexBrokerProcessor

# COMMAND ----------

# MAGIC %run ./DexCommodityProcessor

# COMMAND ----------

# MAGIC %run ./DexCounterPartyProcessor

# COMMAND ----------

# MAGIC %run ./DexLocationProcessor

# COMMAND ----------

# MAGIC %run ./DexTraderProcessor

# COMMAND ----------

# MAGIC %run ./DexCurrencyProcessor

# COMMAND ----------

# MAGIC %run ./DexUnitOfMeasureProcessor

# COMMAND ----------

# MAGIC %run ./DexDealAttributesProcessor

# COMMAND ----------

# MAGIC %run ./FACT/DexFactProcessor
