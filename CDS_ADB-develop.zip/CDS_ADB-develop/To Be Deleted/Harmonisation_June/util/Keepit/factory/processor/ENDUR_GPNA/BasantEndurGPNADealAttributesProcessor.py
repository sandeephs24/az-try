# Databricks notebook source
# MAGIC %run ./../DatasetProcessor

# COMMAND ----------

class EndurGPNADealAttributesProcessor(DatasetProcessor):
    
    def process(df,source_etrm):
        from pyspark.sql import functions as F
        
        df = df.withColumn('SRC_SYS_NAME',lit(source_etrm))
        df = df.withColumn('DEAL_ATTRIBUTES_CK',F.concat(col('SRC_SYS_NAME'),F.lit('_'),F.col('SRC_SYS_DEAL_SUB_LEG_KEY')) )
        df = df.withColumn('RECORD_CREATED_DTTM',F.current_timestamp() )
        
        df = df.na.fill({'SRC_SYSTEM_DEAL_TYPE_CODE':'NULL AT SOURCE'})
        df = df.na.fill({'SRC_SYSTEM_DEAL_SUBTYPE_CODE':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_SPOT_TERM_IND':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_AGREEMENT_TYPE_DESCRIPTION':'NULL AT SOURCE'})
        df = df.na.fill({'HEADER_DEAL_STATUS':'NULL AT SOURCE'})
        df = df.na.fill({'PARENT_CONTRACT_NUMBER':'NULL AT SOURCE'})
        df = df.na.fill({'CONTRACT_NUMBER':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_BOOK_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_LEG_REFERENCE':'NULL AT SOURCE'})
        df = df.na.fill({'BUY_SELL_FLAG':'NULL AT SOURCE'})
        df = df.na.fill({'SUB_LEG_DEAL_STATUS':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_PRICE':0.0})
        df = df.na.fill({'PRICING_TYPE':'NULL AT SOURCE'})
        df = df.na.fill({'PRICING_COMPONENT':'NULL AT SOURCE'})
        df = df.na.fill({'PREMIUM_FLOAT_SPREAD':0.0})
        df = df.na.fill({'INDEX_FACTOR':0.0})
        df = df.na.fill({'PRICING_STATUS':'NULL AT SOURCE'})
        df = df.na.fill({'CALL_PUT_FLAG':'NULL AT SOURCE'})
        df = df.na.fill({'OPTION_STRIKE_PRICE':0.0})
        df = df.na.fill({'OPTION_PREMIUM_PRICE':0.0})
        df = df.na.fill({'VESSEL_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'DEAL_SUB_LEG_REFERENCE':'NULL AT SOURCE'})
        df = df.na.fill({'SETTLEMENT_TYPE':'NULL AT SOURCE'})
        df = df.na.fill({'BILL_OF_LADING_DATE':'NULL AT SOURCE'})
        
        deriveDealInstrumentClassification()
        
        df.show()
        
        return df

# COMMAND ----------

def deriveDealInstrumentClassification():
  df.withColumn("DEAL_INSTRUMENT_CLASSFICATION",
  when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='ComSwap') 
  & (df["SRC_SYSTEM_DEAL_SUBTYPE_CODE"] in ('ENGY-SWAP', 'ENGY-B-SWAP')) , 'SWAP')
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='ComOpt') 
  & (df["SRC_SYSTEM_DEAL_SUBTYPE_CODE"] in ('EO-CALL', 'EO-PUT', 'EO-CSO-CALL', 'EO-CSO-PUT')) , 'OPTION')
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='Commodity') 
  & (df["SRC_SYSTEM_DEAL_SUBTYPE_CODE"] in ('CO-CALL-D', 'CO-PUT-D')) , 'OPTION')
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='ComFut') 
  & (df["SRC_SYSTEM_DEAL_SUBTYPE_CODE"] in ('ENGY-EXCH-FUT')) , 'FUTURE')
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='Commodity') 
  & (df["SRC_SYSTEM_DEAL_SUBTYPE_CODE"] in ('COMM-LDC', 'COMM-PHYS', 'COMM-PHYS-USAGE')) , 'FORWARD')
  .when((df["SRC_SYSTEM_DEAL_TYPE_CODE"]=='FX') 
  & (df["SRC_SYSTEM_DEAL_SUBTYPE_CODE"] in ('FX')) , 'SPOT')
  .otherwise('NOT MAPPED')
  )
