# Databricks notebook source
# MAGIC %run ./../DatasetProcessor

# COMMAND ----------

class EndurGPNALocationProcessor(DatasetProcessor):
    
    def process(df,source_etrm):
        from pyspark.sql import functions as F
        
        df = df.withColumn('SRC_SYS_NAME',lit(source_etrm))
        df = df.withColumn('LOCATION_CK',F.concat(col('SRC_SYS_NAME'),F.lit('_'),F.col('SRC_SYS_LOCATION_NK')) )
        df = df.withColumn('RECORD_CREATED_DTTM',F.current_timestamp() )
        df.show()
        
        return df
