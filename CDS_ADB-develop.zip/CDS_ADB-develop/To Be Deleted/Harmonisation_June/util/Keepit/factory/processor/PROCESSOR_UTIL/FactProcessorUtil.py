# Databricks notebook source
# MAGIC %run ./../../enricher/FactLegEnricher

# COMMAND ----------

# MAGIC %run ./../../enricher/FactSubLegEnricher

# COMMAND ----------

    def processFactHeader(df, spark, source_etrm, metricDict): 
      
      df = df.withColumn('SRC_SYS_NAME',lit(source_etrm))
      df = convertDateColumnToCK(df,'EXECUTION_DATE_CK','EXECUTION_DATE')
      df = convertDateColumnToCK(df,'TRADE_CREATION_DATE_CK','TRADE_CREATION_DATE')
      df = convertStrColumnFromNKToCK(df, 'COUNTERPARTY_CK', 'COUNTERPARTY_NK')
      df = convertStrColumnFromNKToCK(df, 'SHELL_TRADING_PARTY_CK', 'SHELL_TRADING_PARTY_NK')
      df = convertStrColumnFromNKToCK(df, 'DEAL_ATTRIBUTES_CK', 'DEAL_ATTRIBUTES_NK')
      df = convertStrColumnFromNKToCK(df, 'TRADER_CK', 'TRADER_NK')
      df = convertStrColumnFromNKToCK(df, 'DEAL_BROKER_CK', 'BROKER_NK')
      df = convertStrColumnFromNKToCK(df, 'UNIT_OF_MEASURE_CK', 'UNIT_OF_MEASURE_NK')
       
      df = df.withColumn('RECORD_CREATED_DTTM',current_timestamp() )

      return (df, metricDict)

# COMMAND ----------

    def processFactLeg(df,spark, source_etrm, metricDict):
      from pyspark.sql.functions import col
      from pyspark.sql.functions import when
      from pyspark.sql.functions import lit
      from pyspark.sql.functions import date_format
      from pyspark.sql.functions import concat
      
      
      
      dateformat = 'yyyymmdd'
      
      
      df = df.withColumn('SRC_SYS_NAME',lit(source_etrm))
      
      df = convertDateColumnToCK(df,'EXECUTION_DATE_CK','EXECUTION_DATE')
      df = convertDateColumnToCK(df,'TRADE_CREATION_DATE_CK','TRADE_CREATION_DATE')
      df = convertDateColumnToCK(df,'COMMITMENT_DATE_CK','COMMITMENT_DATE')
      
      df = convertStrColumnFromNKToCK(df, 'COUNTERPARTY_CK', 'COUNTERPARTY_NK')
      df = convertStrColumnFromNKToCK(df, 'SHELL_TRADING_PARTY_CK', 'SHELL_TRADING_PARTY_NK')
      df = convertStrColumnFromNKToCK(df, 'DEAL_ATTRIBUTES_CK', 'DEAL_ATTRIBUTES_NK')
      df = convertStrColumnFromNKToCK(df, 'TRADER_CK', 'TRADER_NK')
      df = convertStrColumnFromNKToCK(df, 'COMMODITY_CK', 'COMMODITY_NK')
      df = convertStrColumnFromNKToCK(df, 'DEAL_BROKER_CK', 'DEAL_BROKER_NK')
      df = convertStrColumnFromNKToCK(df, 'UNIT_OF_MEASURE_CK', 'UNIT_OF_MEASURE_NK')
      
      df = df.withColumn('RECORD_CREATED_DTTM',current_timestamp() )
            
      df = enrichFactLeg(df, spark, source_etrm)

      df.show()
      return (df, metricDict)

# COMMAND ----------

    def processFactSubleg(df,spark, source_etrm, metricDict):
    
      from pyspark.sql.functions import col
      from pyspark.sql.functions import when
      from pyspark.sql.functions import lit
      from pyspark.sql.functions import date_format
      from pyspark.sql.functions import concat
      
      
      dateformat = 'yyyymmdd'
      df = df.withColumn('SRC_SYS_NAME',lit(source_etrm))
      df = df.withColumn('RECORD_CREATED_DTTM',current_timestamp() )
      
      df = convertDateColumnToCK(df,'EXECUTION_DATE_CK','EXECUTION_DATE')
      df = convertDateColumnToCK(df,'TRADE_CREATION_DATE_CK','TRADE_CREATION_DATE')
      df = convertDateColumnToCK(df,'COMMITMENT_DATE_CK','COMMITMENT_DATE')
      df = convertDateColumnToCK(df,'PARCEL_DATE_CK','PARCEL_DATE')
      
      df = convertDateColumnToCK(df,'DELIVERY_START_DATE_CK','DELIVERY_START_DATE')
      df = convertDateColumnToCK(df,'DELIVERY_END_DATE_CK','DELIVERY_END_DATE')
            
      df = convertStrColumnFromNKToCK(df, 'COUNTERPARTY_CK', 'COUNTERPARTY_NK')
      df = convertStrColumnFromNKToCK(df, 'SHELL_TRADING_PARTY_CK', 'SHELL_TRADING_PARTY_NK')
      df = convertStrColumnFromNKToCK(df, 'DEAL_ATTRIBUTES_CK', 'DEAL_ATTRIBUTES_NK')
      df = convertStrColumnFromNKToCK(df, 'TRADER_CK', 'TRADER_NK')
      df = convertStrColumnFromNKToCK(df, 'COMMODITY_CK', 'COMMODITY_NK')
      df = convertStrColumnFromNKToCK(df, 'DEAL_BROKER_CK', 'DEAL_BROKER_NK')
      df = convertStrColumnFromNKToCK(df, 'LOADING_LOCATION_CK', 'LOADING_LOCATION_NK')
      df = convertStrColumnFromNKToCK(df, 'DISCHARGE_LOCATION_CK', 'DISCHARGE_LOCATION_NK')
      df = convertStrColumnFromNKToCK(df, 'DEAL_UNIT_OF_MEASURE_CK', 'DEAL_UNIT_OF_MEASURE_NK')
      df = convertStrColumnFromNKToCK(df, 'PRICING_UNIT_OF_MEASURE_CK', 'PRICING_UNIT_OF_MEASURE_NK')
      df = convertStrColumnFromNKToCK(df, 'DEAL_CCY_CK', 'DEAL_CCY_NK')
      
      
      metricDict["subleg_count_in_processor_before_value_conversion"] = df.count()
      df = enrichFactSubLegWithCurrencyDealValueConversion(df, spark, SOURCE_ETRM)
      metricDict["subleg_count_in_processor_after_value_conversion"] = df.count()
      
      df = enrichFactSubLeg(df, spark, SOURCE_ETRM)
      metricDict["subleg_count_in_processor_after_qty_conversion"] = df.count()
      
      return (df,metricDict)

# COMMAND ----------

    def convertStrColumnFromNKToCK(df, ckColumnName, nkColumnName):
      from pyspark.sql.functions import col
      from pyspark.sql.functions import when
      from pyspark.sql.functions import lit
      from pyspark.sql.functions import date_format
      from pyspark.sql.functions import concat

      df = df.withColumn(ckColumnName,
                             when(
                             (col(nkColumnName).isNull()) | (col(nkColumnName) == "") ,lit("")
                             ).otherwise(concat(col('SRC_SYS_NAME'),lit('_'),col(nkColumnName))) 
                            )
      return df

# COMMAND ----------

    def convertDateColumnToCK(df, date_ck_column_name, date_column_name):
      from pyspark.sql.functions import col
      from pyspark.sql.functions import when
      from pyspark.sql.functions import lit
      from pyspark.sql.functions import date_format
      from pyspark.sql.functions import concat
    
      dateformat = 'yyyyMMdd'
      df = df.withColumn(date_column_name,date_format(col(date_column_name),dateformat))
      df = df.withColumn(date_ck_column_name,
                           when(
                             col(date_column_name).isNull(),lit("")
                           ).otherwise(col(date_column_name))
                          )
      return df
