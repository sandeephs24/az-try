# Databricks notebook source
import abc
class DatasetProcessor(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def process(self):
        pass
