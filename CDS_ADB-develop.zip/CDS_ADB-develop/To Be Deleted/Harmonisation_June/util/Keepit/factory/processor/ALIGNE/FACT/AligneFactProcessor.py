# Databricks notebook source
# MAGIC %run ./../../DatasetProcessor

# COMMAND ----------

# MAGIC %run ./AligneFactHeaderProcessor

# COMMAND ----------

# MAGIC %run ./AligneFactLegProcessor

# COMMAND ----------

# MAGIC %run ./AligneFactSubLegProcessor

# COMMAND ----------

class AligneFactProcessor(DatasetProcessor):
    
    def process(dfFactHeader,dfFactLeg,dfFactSubLeg,spark,source_etrm, metricDict):
        
        
        (dfFactHeader, metricDict) = AligneFactHeaderProcessor.process(dfFactHeader,spark,source_etrm, metricDict)
        (dfFactLeg, metricDict) = AligneFactLegProcessor.process(dfFactLeg,spark,source_etrm, metricDict)
        (dfFactSubLeg, metricDict) = AligneFactSubLegProcessor.process(dfFactSubLeg,spark,source_etrm, metricDict)
        
        return (dfFactHeader,dfFactLeg,dfFactSubLeg, metricDict)
