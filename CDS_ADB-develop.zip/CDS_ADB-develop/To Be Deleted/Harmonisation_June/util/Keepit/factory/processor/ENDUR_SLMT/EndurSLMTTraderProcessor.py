# Databricks notebook source
# MAGIC %run ./../DatasetProcessor

# COMMAND ----------

class EndurSLMTTraderProcessor(DatasetProcessor):
    
    def process(df,source_etrm):
        from pyspark.sql import functions as F
        
        df = df.withColumn('SRC_SYS_NAME',lit(source_etrm))
        df = df.withColumn('TRADER_CK',F.concat(col('SRC_SYS_NAME'),F.lit('_'),F.col('SRC_SYS_TRADER_NK')) )
        df = df.withColumn('RECORD_CREATED_DTTM',F.current_timestamp() )
        df = df.withColumn('SOURCE_LAST_UPDATE',F.date_trunc("second",col('SOURCE_LAST_UPDATE')))
        df = df.na.fill({'TRADER_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'TRADER_FIRST_NAME':'NULL AT SOURCE'})
        df = df.na.fill({'TRADER_LAST_NAME':'NULL AT SOURCE'})
        df.show()
        
        return df
