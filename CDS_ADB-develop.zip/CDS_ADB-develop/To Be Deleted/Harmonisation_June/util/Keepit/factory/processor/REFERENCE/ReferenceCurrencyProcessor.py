# Databricks notebook source
class ReferenceCurrencyProcessor(DatasetProcessor):
    
    def process(df,source_etrm):
        from pyspark.sql import functions as F
        
        df = df.withColumn('src_sys_name',lit(source_etrm))
        df = df.withColumn('currency_ck',F.concat(col('src_sys_name'),F.lit('_'),F.col('src_sys_currency_nk')) )
        df = df.withColumn('record_created_dttm',F.current_timestamp() )
        df.show()
        
        return df
