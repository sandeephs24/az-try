# Databricks notebook source
# MAGIC %run ./../../DatasetProcessor

# COMMAND ----------

# MAGIC %run ./EndurGPNAFactHeaderProcessor

# COMMAND ----------

# MAGIC %run ./EndurGPNAFactLegProcessor

# COMMAND ----------

# MAGIC %run ./EndurGPNAFactSubLegProcessor

# COMMAND ----------

class EndurGPNAFactProcessor(DatasetProcessor):
    
    def process(dfFactHeader,dfFactLeg,dfFactSubLeg,spark,source_etrm, metricDict):
        
        
        (dfFactHeader, metricDict) = EndurGPNAFactHeaderProcessor.process(dfFactHeader,spark,source_etrm, metricDict)
        (dfFactLeg, metricDict) = EndurGPNAFactLegProcessor.process(dfFactLeg,spark,source_etrm, metricDict)
        (dfFactSubLeg, metricDict) = EndurGPNAFactSubLegProcessor.process(dfFactSubLeg,spark,source_etrm, metricDict)
        
        return (dfFactHeader,dfFactLeg,dfFactSubLeg, metricDict)
