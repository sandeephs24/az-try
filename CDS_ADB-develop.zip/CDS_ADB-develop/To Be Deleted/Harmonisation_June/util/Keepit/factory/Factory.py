# Databricks notebook source
# MAGIC %run ./source_factory/SourceFactory

# COMMAND ----------

# MAGIC %run ./reader/DatasetReader

# COMMAND ----------

# MAGIC %run ./processor/DatasetProcessor

# COMMAND ----------

# MAGIC %run ./writer/DatasetWriter

# COMMAND ----------

# MAGIC %run ./reader/CreateAllReaders

# COMMAND ----------

# MAGIC %run ./processor/CreateAllProcessors

# COMMAND ----------

# MAGIC %run ./writer/CreateAllWriters

# COMMAND ----------

# MAGIC %run ./source_factory/EndurGpnaSourceFactory  

# COMMAND ----------

# MAGIC %run ./source_factory/DexSourceFactory

# COMMAND ----------

# MAGIC %run ./source_factory/ReferenceSourceFactory

# COMMAND ----------

# MAGIC %run ./source_factory/SourceFactoryProvider
