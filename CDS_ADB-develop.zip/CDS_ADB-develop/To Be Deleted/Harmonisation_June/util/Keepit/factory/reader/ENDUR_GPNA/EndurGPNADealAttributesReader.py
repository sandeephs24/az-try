# Databricks notebook source
# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../enricher/DealAttributeEnricher

# COMMAND ----------

class EndurGPNADealAttributesReader(SourceDatasetReader):
    
   def read(spark,metricDict, initial_load):
      
      SOURCE_ETRM = 'ENDUR_GPNA'
      
      last_watermark_ab_tran = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'AB_TRAN','DIM_DEAL_ATTRIBUTES')
      last_watermark_ab_tran = last_watermark_ab_tran[0:19]
      
      if initial_load == "Y":
        tran_status_list = "3,4,5"
      else:
        tran_status_list = "3,5"
      
      SQL = """
      select 
       a.deal_tracking_num as SRC_SYS_DEAL_HEADER_KEY
      ,a.deal_tracking_num||'_'||a.ins_num||'_'||d.param_seq_num as SRC_SYS_DEAL_LEG_KEY
      ,a.deal_tracking_num||'_'||a.ins_num||'_'||d.param_seq_num||'_'||d.profile_seq_num as SRC_SYS_DEAL_SUB_LEG_KEY
      ,t.name                                       as SRC_SYSTEM_DEAL_TYPE_CODE      
      ,b.name                                       as SRC_SYSTEM_DEAL_SUBTYPE_CODE
      ,case when a.buy_sell=0 then 'Buy'
	   when a.buy_sell=1 then 'Sell'
	   when a.buy_sell IN (4,5) and PAY_REC=1 then 'Sell'
	   when a.buy_sell IN (4,5) and PAY_REC=0 then 'Buy'
	   else 'UNKNOWN' END DEAL_HEADER_BUY_SELL_FLAG
      ,'N/A'                                        as DEAL_SPOT_TERM_IND
      ,agr.agreement_name                           as DEAL_AGREEMENT_TYPE_DESCRIPTION
      ,k.name                                       as HEADER_DEAL_STATUS
      ,a.deal_tracking_num                          as PARENT_CONTRACT_NUMBER        
      ,a.tran_num                                   as CONTRACT_NUMBER
      ,c.long_name                                  as DEAL_BOOK_NAME
      ,a.ins_num||'_'||d.param_seq_num              as DEAL_LEG_REFERENCE
      ,case when a.buy_sell=0 then 'Buy'
	   when a.buy_sell=1 then 'Sell'
	   when a.buy_sell IN (4,5) and PAY_REC=1 then 'Sell'
	   when a.buy_sell IN (4,5) and PAY_REC=0 then 'Buy'
	   else 'UNKNOWN' END DEAL_LEG_BUY_SELL_FLAG
      ,k.name                                       as SUB_LEG_DEAL_STATUS      
      ,a.trade_time                                 as DEAL_EXECUTION_TIMESTAMP
      ,d.rate                                       as DEAL_PRICE
      ,ff.name                                      as PRICING_TYPE
      ,pi.index_name                                as PRICING_COMPONENT
      ,D.FLOAT_SPREAD                               as PREMIUM_FLOAT_SPREAD
      ,D.INDEX_MULTIPLIER                           as INDEX_FACTOR
      ,vs.name                                      as PRICING_STATUS
      ,D.RATE_DTMN_DATE                             as PRICE_SETTLE_DATE 
      ,a.ins_num||'_'||d.param_seq_num||'_'||d.profile_seq_num as DEAL_SUB_LEG_REFERENCE
      ,g.name                                           as SETTLEMENT_TYPE 
      ,a.reference                                   as DEAL_LINE_TEXT        
      ,pc.name                                       as CALL_PUT_FLAG      
      ,l.strike                                      as OPTION_STRIKE_PRICE
      ,CASE WHEN nvl(pnl.cflow_type, 0) = 4 THEN Abs(Round(PNL.PRICE / d.notnl, 4)) ELSE 0.0 END as OPTION_PREMIUM_PRICE
      ,'N/A'                                         as VESSEL_NAME
      ,IC.LOCATION_NAME                              as DELIVERY_JUNCTION_NAME
      ,PIPE.PIPELINE_NAME                            as DELIVERY_METHOD_NAME
      ,a.last_update                                 as SOURCE_LAST_DATE1
      ,''                                            as BILL_OF_LADING_DATE
      from ab_tran a  
      join INSTRUMENTS b on a.ins_type = b.id_number
      join TOOLSETS t on a.toolset = T.ID_NUMBER
      join PORTFOLIO c on a.internal_portfolio = c.id_number
      join INS_PARAMETER f on a.ins_num = f.ins_num
      join PROFILE d on f.param_seq_num = d.param_seq_num and f.ins_num = d.ins_num
      JOIN SETTLE_TYPE g ON          g.id_number =f.settlement_type  
      join TRANS_STATUS k on a.tran_status = k.trans_status_id
      left join INS_OPTION l on f.ins_num = l.ins_num and f.param_seq_num = l.param_seq_num and OPTION_SEQ_NUM = 0
      LEFT JOIN	gas_phys_param gpp 
      ON	gpp.ins_num = f.ins_num 
      AND	gpp.param_seq_num = f.param_seq_num     
      LEFT JOIN	gas_phys_location gpl 
      ON	GPP.LOCATION_ID = GPL.LOCATION_ID     
      LEFT JOIN	gas_phys_pipelines pipe 
      ON	PIPE.PIPELINE_ID = GPL.PIPELINE_ID     
      LEFT JOIN	gas_phys_location ic 
      ON	GPL.INTERCONNECT_LOC_ID = ic.location_id     

      join buy_sell bs on BS.ID_NUMBER = a.buy_sell
      LEFT JOIN	PUT_CALL pc 
      ON	L.PUT_CALL = PC.ID_NUMBER     

      join FX_FLT ff on FF.ID_NUMBER = F.FX_FLT
      left join PARAM_RESET_HEADER prh on f.ins_num = prh.ins_num and f.param_seq_num = prh.param_seq_num and PARAM_RESET_HEADER_SEQ_NUM = 0
      LEFT JOIN          idx_def pi ON     PI.INDEX_ID = prh.proj_index AND pi.validated = 1 AND PARAM_RESET_HEADER_SEQ_NUM = 0 and PI.DB_STATUS = 1 
      JOIN          value_status vs ON                 VS.ID_NUMBER = d.rate_status
      LEFT JOIN            AB_TRAN_AGREEMENT ag ON                 AG.TRAN_NUM = a.tran_num     
      LEFT JOIN            party_agreement pa ON                 AG.PARTY_AGREEMENT_ID = PA.PARTY_AGREEMENT_ID     
      LEFT JOIN            agreement agr ON                 PA.AGREEMENT_ID = AGR.AGREEMENT_ID
      LEFT JOIN            USER_SYN_EXTRACTIONLOG log ON                 LOG.SIM_PFOLIO = A.INTERNAL_PORTFOLIO     
      AND               LOG.SIM_RUN_TIME = (select           max(log2.sim_run_time) from USER_SYN_EXTRACTIONLOG log2 where LOG2.SIM_RUN_TYPE = 1) 
      LEFT JOIN (  
      select sim_run_id, TRAN_NUM, deal_leg, deal_pdc,CFLOW_TYPE, PRICE
      from(
      select PNL.SIM_RUN_ID,
      PNL.TRAN_NUM              ,
      PNL.DEAL_LEG         ,
      PNL.DEAL_PDC ,
      PNL.CFLOW_TYPE,
      PNL.PRICE,
      row_number() 
      over(partition by sim_run_id, TRAN_NUM, deal_leg, deal_pdc
      order by sim_run_id
      ) row_num     
      from USER_SYN_PNL_DETAIL PNL
      where CFLOW_TYPE = 4
      ) where row_num = 1
      ) PNL 
      ON LOG.SIM_RUN_ID  = PNL.SIM_RUN_ID
      AND a.tran_num  = PNL.TRAN_NUM              
      AND d.PARAM_SEQ_NUM  = PNL.DEAL_LEG         
      AND d.profile_seq_num  = PNL.DEAL_PDC       
      where a.tran_status in( {1})
      and a.current_flag = 1
      and a.tran_type = 0
      and (
      (
      b.name in ('COMM-LDC', 'COMM-PHYS', 'COMM-PHYS-USAGE', 'COMM-EXCH') 
      and gpp.ins_num is not null and f.settlement_type = 2
      )
      OR
      ( b.name not in ('COMM-LDC', 'COMM-PHYS', 'COMM-PHYS-USAGE', 'COMM-EXCH'))
      )
      and a.last_update > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
      and b.name not in ('CASH'
      ,'COMM-FEE'
      ,'COMM-IMB'
      ,'COMM-INV'
      ,'COMM-INV-PAL'
      ,'COMM-MAD-SETTLE'
      ,'COMM-PAL'
      ,'COMM-PREPAY'
      ,'COMM-STOR'
      ,'COMM-TRANS'
      ,'COMM-TRANS-PLAN','COMM-MAD-JE','COMM-IMB-SENA')
      """.format(last_watermark_ab_tran, tran_status_list)
      
      loadDatasetConfigsEndurGPNADealAttributes(spark,SOURCE_ETRM)
      df = spark.sql(SQL)
        
      return (df,metricDict)
      
  

# COMMAND ----------

def loadDatasetConfigsEndurGPNADealAttributes(spark, SOURCE_ETRM):
    format = "delta"
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN', format, 'AB_TRAN') 
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'INSTRUMENTS', format, 'INSTRUMENTS') 
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'TOOLSETS', format, 'TOOLSETS') 
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PORTFOLIO', format, 'PORTFOLIO') 
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'INS_PARAMETER', format, 'INS_PARAMETER') 
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PROFILE', format, 'PROFILE') 
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'SETTLE_TYPE', format, 'SETTLE_TYPE') 
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'TRANS_STATUS', format, 'TRANS_STATUS') 
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'INS_OPTION', format, 'INS_OPTION') 
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'GAS_PHYS_PARAM', format, 'GAS_PHYS_PARAM') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'GAS_PHYS_LOCATION', format, 'GAS_PHYS_LOCATION') 
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'GAS_PHYS_PIPELINES', format, 'GAS_PHYS_PIPELINES') 
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'BUY_SELL', format, 'BUY_SELL')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PUT_CALL', format, 'PUT_CALL')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'FX_FLT', format, 'FX_FLT')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PARAM_RESET_HEADER', format, 'PARAM_RESET_HEADER')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'VALUE_STATUS', format, 'VALUE_STATUS')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'USER_SYN_EXTRACTIONLOG', format, 'USER_SYN_EXTRACTIONLOG')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN_AGREEMENT', format, 'AB_TRAN_AGREEMENT')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PARTY_AGREEMENT', format, 'PARTY_AGREEMENT')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'AGREEMENT', 'parquet', 'AGREEMENT')  
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'IDX_DEF', format, 'IDX_DEF') 
    readDatasetConfigAndCreateTempView(spark, SOURCE_ETRM, 'USER_SYN_PNL_DETAIL', "parquet", 'USER_SYN_PNL_DETAIL')
    
