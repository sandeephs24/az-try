# Databricks notebook source
# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../enricher/LocationMappingEnricher

# COMMAND ----------

class AligneLocationReader(SourceDatasetReader):
    
  def read(spark,metricDict):
      SOURCE_ETRM = 'ALIGNE'
      
      #last_watermark_location=getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_LOCATION','DIM_LOCATION')
      #last_watermark_location = last_watermark_location[0:19]
      
      #print(last_watermark_location)
      
      #df = executeJdbcQueryAndReturnDF("select SRC_SYS_LOCATION_NK from tsa_curated.dim_location where src_sys_name = '{0}'".format(SOURCE_ETRM))
      #df.createOrReplaceTempView("CURATED_DIM_LOCATION")
      
      #print(df.count())
      
      LOCATION_READ_SQL = """
      select
      DISTINCT GV.MARKET1||GV.COMPONENT1 AS src_sys_location_nk,
      M.MRKTC_ATTR1 AS LOCATION_NAME,
      v.VALU_NAME AS LOCATION_TYPE,
      v.VALU_DSC AS LOCATION_AREA
      from GV_TRADES GV
      left join STATIC_MRKTC M
      on GV.MARKET1 = M.MRKTC_MKT AND GV.COMPONENT1 = M.MRKTC_COMP
      left join STATIC_VALUE V
      on M.MRKTC_ATTR1 = V.VALU_CODE
      where v.VALU_NAME = 'COUNTRY'
      """   
      
      format = "parquet"
      readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_MRKTC', format, 'STATIC_MRKTC')
      readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_TRADES',format, 'GV_TRADES')
      readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_VALUE',format, 'STATIC_VALUE')

                 
      df = spark.sql(LOCATION_READ_SQL)
      
      print(df.count())
      #df=df.withColumn("SOURCE_LAST_UPDATE", date_trunc("minute", col("SOURCE_LAST_UPDATE")))
      df = enrichLocationForMapping(spark,df,SOURCE_ETRM)
      
      return  (df,metricDict)

# COMMAND ----------

SOURCE_ETRM = 'ALIGNE'
format = 'parquet'
readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_MRKTC', format, 'STATIC_MRKTC')
readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_TRADES',format, 'GV_TRADES')
readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_VALUE',format, 'STATIC_VALUE')


# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC       DISTINCT GV.MARKET1||GV.COMPONENT1 AS src_sys_location_nk,
# MAGIC       M.MRKTC_ATTR1 AS location_name,
# MAGIC       v.VALU_NAME AS location_type,
# MAGIC       v.VALU_DSC AS location_area
# MAGIC       from GV_TRADES GV
# MAGIC       left join STATIC_MRKTC M
# MAGIC       on GV.MARKET1 = M.MRKTC_MKT AND GV.COMPONENT1 = M.MRKTC_COMP
# MAGIC       left join STATIC_VALUE V
# MAGIC       on M.MRKTC_ATTR1 = V.VALU_CODE
# MAGIC       where v.VALU_NAME = 'COUNTRY'
# MAGIC       
