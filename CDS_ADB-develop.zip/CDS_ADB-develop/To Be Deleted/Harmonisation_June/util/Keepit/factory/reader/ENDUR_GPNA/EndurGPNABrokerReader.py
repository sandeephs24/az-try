# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

class EndurGPNABrokerReader(SourceDatasetReader):
    
    def read(spark,metricDict):
        SOURCE_ETRM = 'ENDUR_GPNA'
      
        last_watermark_party_broker = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'PARTY','DIM_BROKER')
        last_watermark_party_broker = last_watermark_party_broker[0:19]
        
        metricDict["broker_reader_last_watermark"] = last_watermark_party_broker
        
        df = executeJdbcQueryAndReturnDF("select src_sys_broker_nk from tsa_curated.dim_broker where src_sys_name = '{0}'".format(SOURCE_ETRM))
        df.createOrReplaceTempView("CURATED_DIM_BROKER")
        
        EXECUTING_BROKER_READER_SQL = """
          SELECT distinct
          b.party_id SRC_SYS_BROKER_NK,
          b.long_name BROKER_NAME,
          upper(c.name) ACTIVE_BROKER_FLAG,
          b.last_update SOURCE_LAST_UPDATE
          FROM AB_TRAN a
          JOIN PARTY b
          ON a.broker_id = b.party_id
          OR a.otc_clearing_broker_id = b.party_id
          JOIN PARTY_STATUS c
          ON b.party_status = c.id_number
          where (
          b.last_update > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss') 
          or
          b.party_id in (select src_sys_broker_nk from CURATED_DIM_BROKER)
          )
          """.format(last_watermark_party_broker)

        
        CLEARING_BROKER_READER_SQL = """
        SELECT distinct
        b.party_id SRC_SYS_BROKER_NK,
        b.long_name BROKER_NAME,
        upper(c.name) ACTIVE_BROKER_FLAG,
        b.last_update SOURCE_LAST_UPDATE
        FROM AB_TRAN a
        JOIN AB_TRAN_INFO d
        ON a.tran_num = d.tran_num
        AND	type_id = 20021
        JOIN PARTY b
        ON d.value = b.short_name
        JOIN PARTY_STATUS c
        ON	b.party_status = c.id_number
        where (
        b.last_update > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss') 
        or
        b.party_id in (select src_sys_broker_nk from CURATED_DIM_BROKER)
        )
union
          SELECT distinct
          b.party_id SRC_SYS_BROKER_NK,
          b.long_name BROKER_NAME,
          upper(c.name) ACTIVE_BROKER_FLAG,
          b.last_update SOURCE_LAST_UPDATE
          FROM AB_TRAN a
          JOIN AB_TRAN_PROVISIONAL ap
          on a.tran_num = ap.tran_num
          JOIN PARTY b
          on ap.broker_id = b.party_id
          JOIN	PARTY_STATUS c
          ON b.party_status = c.id_number
          where (
          b.last_update > to_timestamp('{1}','yyyy-MM-dd HH:mm:ss') 
          or 
          b.party_id in (select src_sys_broker_nk from CURATED_DIM_BROKER)
          )
        """.format(last_watermark_party_broker,last_watermark_party_broker)
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PARTY', "parquet", 'PARTY')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PARTY_STATUS', "parquet", 'PARTY_STATUS')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN', format, 'AB_TRAN')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN_INFO', format, 'AB_TRAN_INFO')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN_PROVISIONAL', format, 'AB_TRAN_PROVISIONAL')
        print('starting reader')
        print('EXECUTING_BROKER_READER_SQL')
        df = spark.sql(EXECUTING_BROKER_READER_SQL)
        df.show(100)
        
        print('CLEARING_BROKER_READER_SQL')
        df1 = spark.sql(CLEARING_BROKER_READER_SQL)
        df1.show(100)
        
        
        df = df.union(df1)
        df = df.dropDuplicates(["SRC_SYS_BROKER_NK"])
        
        
        print('Broker Reader count:')
        print(df.count())
        print('reader completed')
        
        return (df,metricDict)
