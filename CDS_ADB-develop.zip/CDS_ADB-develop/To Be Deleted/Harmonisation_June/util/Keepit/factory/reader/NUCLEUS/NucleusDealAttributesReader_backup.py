# Databricks notebook source
# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../enricher/DealAttributeEnricher

# COMMAND ----------

class NucleusDealAttributesReader(SourceDatasetReader):
    
  def read(spark,metricDict, INITIAL_LOAD):
        SOURCE_ETRM = 'NUCLEUS'



        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'DEAL_MONTH_DETAILS', format, 'DEAL_MONTH_DETAILS') 
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'DEAL_STATUS_MONTHS', format, 'DEAL_STATUS_MONTHS') 
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'CONTRACTS', format, 'CONTRACTS') 
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'DF_DEAL_ATTRIBUTES', format, 'DF_DEAL_ATTRIBUTES') 
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'DEAL_CONFIRMS', format, 'DEAL_CONFIRMS') 
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PORTFOLIOS', format, 'PORTFOLIOS')     
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'DEAL_TYPES', format, 'DEAL_TYPES')  
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'POWER_FEES ', format, 'POWER_FEES ') 
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'FLAT_BROKER_FEES', format, 'FLAT_BROKER_FEES') 
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'CLEARINGBROKER_FEES', format, 'CLEARINGBROKER_FEES')     
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'MISC_CHARGES', format, 'MISC_CHARGES')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'TRADING_HIGHLIGHTS', format, 'TRADING_HIGHLIGHTS')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'DEAL_DETAILS', format, 'DEAL_DETAILS')
        
        
        
        

      
        print("running sql DEAL_ATTRIBUTE_READ_SQL")

        if (INITIAL_LOAD == "Y") :
          DEAL_ATTRIBUTE_READ_SQL = getDealAttrReaderSQLDay0(spark , SOURCE_ETRM)
        else:
          DEAL_ATTRIBUTE_READ_SQL = getDealAttrReaderSQLDay1(spark , SOURCE_ETRM)


        df = spark.sql(DEAL_ATTRIBUTE_READ_SQL) 
        
        print("running sql DEAL_ATTRIBUTE_READ_SQL- count ", df.count())
        df.show(20,False)

        print ("Running enricher")
        #df = DealAttributeenrich(spark,df,SOURCE_ETRM)
        print ("Running enricher - DOne")
        #df.show(20,False)
        df.printSchema()
        return  (df,metricDict)
      

# COMMAND ----------

def getDealAttrReaderSQLDay1(spark , SOURCE_ETRM):

  last_watermark_prclfcst = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PRCLFCST','DIM_DEAL_ATTRIBUTES')
  last_watermark_prclfcst = last_watermark_prclfcst[0:19]

  last_watermark_settlmnt = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_SETTLMNT','DIM_DEAL_ATTRIBUTES')
  last_watermark_settlmnt = last_watermark_settlmnt[0:19]
  
  DEAL_ATTRIBUTE_READ_SQL = """
  SELECT DISTINCT
    DMD.DEAL_KEY                         						AS 	SRC_SYS_DEAL_HEADER_KEY,
    DMD.VOLUME_SEQ                       					AS 	SRC_SYS_DEAL_LEG_KEY,
    DMD.DETAIL_SEQ                      					AS 	SRC_SYS_DEAL_SUB_LEG_KEY,
    DMD.TRUE_DEAL_TYPE                   					AS 	SRC_SYSTEM_DEAL_TYPE_CODE,
    DMD.DLT_DEAL_TYPE                    					AS 	SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    CASE WHEN DMD.DN_DIRECTION ='SALE' THEN 'SELL' ELSE 'BUY' END         AS DEAL_HEADER_BUY_SELL_FLAG,
    'TSA_MAPPED'                        	 					AS 	DEAL_INSTRUMENT_CLASSIFICATION	,
    CASE WHEN (datediff((DMD.DY_END_DAY),(DMD.DY_BEG_DAY)) < 5) THEN 'SPOT' ELSE 'TERM'  END    AS 	DEAL_SPOT_TERM_IND,
    C.KTYP_CONTRACT_TYPE                 					AS 	DEAL_AGREEMENT_TYPE_DESCRIPTION,
    CASE WHEN TH.MESSAGE_TYPE = 'I' THEN 'INSERT' 
    WHEN TH.MESSAGE_TYPE = 'U' THEN 'UPDATE' 
    WHEN TH.MESSAGE_TYPE = 'D' THEN 'DELETE' ELSE  '' END   AS 	HEADER_DEAL_STATUS,
    NVL(cast(C.KK_MASTER_KEY as string),C.CONTRACT_NUMBER) 	AS 	PARENT_CONTRACT_NUMBER,
    C.CONTRACT_NUMBER                    					AS 	CONTRACT_NUMBER,
    P.DESCRIPTION                        						AS 	DEAL_BOOK_NAME,
    DMD.VOLUME_SEQ                       					AS 	DEAL_LEG_REFERENCE,
    CASE WHEN DMD.DN_DIRECTION ='SALE' THEN 'SELL' ELSE 'BUY' END AS 	DEAL_LEG_BUY_SELL_FLAG,
    DSM.STATUS                           						AS 	SUB_LEG_DEAL_STATUS,
    DDA.DF_FIELD_VALUE                  					AS 	DEAL_EXECUTION_TIMESTAMP,
    DMD.DEAL_PRICE                       					AS 	DEAL_PRICE,
    CASE WHEN DMD.PRICE_TYPE='F' THEN 'FIXED' ELSE 'INDEX' END  AS 	PRICING_TYPE,
    DMD.FORMULA                          					AS 	PRICING_COMPONENT,
    NULL                                						AS 	PREMIUM_FLOAT_SPREAD,
    NULL                                 						AS 	INDEX_FACTOR,
    NULL                                 						AS 	PRICING_STATUS,
    DMD.DY_END_DAY                       					AS 	PRICE_SETTLE_DATE,
    DMD.DETAIL_SEQ                       					AS 	DEAL_SUB_LEG_REFERENCE,
    CASE WHEN DMD.ST_SETTLEMENT_TYPE IS NULL THEN DF.PHY_FIN_FLAG ELSE DMD.ST_SETTLEMENT_TYPE END   AS 	SETTLEMENT_TYPE	,   
    DMD.INVOICE_DESC                     					AS 	DEAL_LINE_TEXT,
    CASE WHEN DT.MDT_MASTER_TYPE = 'OPTION' THEN DMD.PUT_CALL_FLAG ELSE '' END AS 	CALL_PUT_FLAG,
    DMD.STRIKE_PRICE                     					AS 	OPTION_STRIKE_PRICE,
        DMD.PREMIUM                          					AS 	OPTION_PREMIUM_PRICE,
      ''                                                        AS VESSEL_NAME,
       ''                                                       AS DELIVERY_JUNCTION_NAME,
       ''                                                       AS BILL_OF_LADING_DATE,
       DMD.MODIFY_DATE                                          AS SOURCE_LAST_DATE1
    FROM DEAL_MONTH_DETAILS DMD
    LEFT JOIN DEAL_STATUS_MONTHS DSM ON DMD.CM_CONTRACT_MONTH = DSM.CM_CONTRACT_MONTH AND DMD.DLT_DEAL_TYPE = DSM.DLT_DEAL_TYPE AND DMD.DEAL_KEY = DSM.DEAL_KEY  
    LEFT JOIN CONTRACTS C ON DMD.KK_CONTRACT_KEY = C.CONTRACT_KEY
    LEFT JOIN DF_DEAL_ATTRIBUTES DDA ON DMD.DLT_DEAL_TYPE = DDA.DLT_DEAL_TYPE AND DMD.DEAL_KEY = DDA.DEAL_KEY AND DF_FIELD_NAME = 'EXECUTION_TIMESTAMP' 
    LEFT JOIN PORTFOLIOS P ON DMD.PRT_PORTFOLIO = P.PORTFOLIO
    LEFT JOIN DEAL_CONFIRMS DF ON DMD.DLT_DEAL_TYPE = DF.DLT_DEAL_TYPE AND DMD.DEAL_KEY = DF.DEAL_KEY
    LEFT JOIN DEAL_TYPES DT ON DMD.DLT_DEAL_TYPE = DT.DEAL_TYPE
    LEFT JOIN TRADING_HIGHLIGHTS TH ON DMD.DLT_DEAL_TYPE = TH.DLT_DEAL_TYPE AND DMD.DEAL_KEY = TH.DEAL_KEY 
    WHERE DMD.TRADE_DATE >='{0}' 
    AND NOT EXISTS (SELECT * FROM POWER_FEES WHERE DLT_DEAL_TYPE = DMD.DLT_DEAL_TYPE AND DEAL_KEY = DMD.DEAL_KEY)
    AND NOT EXISTS (SELECT * FROM FLAT_BROKER_FEES WHERE DLT_DEAL_TYPE = DMD.DLT_DEAL_TYPE AND DEAL_KEY = DMD.DEAL_KEY)
    AND NOT EXISTS (SELECT * FROM CLEARINGBROKER_FEES WHERE DLT_DEAL_TYPE = DMD.DLT_DEAL_TYPE AND DEAL_KEY = DMD.DEAL_KEY)
    AND NOT EXISTS (SELECT * FROM MISC_CHARGES WHERE CY_COMPANY_KEY = DMD.CY_COMPANY_KEY AND MISC_CHARGE_KEY = DMD.DEAL_KEY)
    AND DSM.MODIFY_DATE=(select MAX(MODIFY_DATE)from DEAL_STATUS_MONTHS where DEAL_KEY=DMD.DEAL_KEY)
    AND TH.MODIFY_DATE=(select MAX(MODIFY_DATE)from TRADING_HIGHLIGHTS where DEAL_KEY=DMD.DEAL_KEY)

  """.format(last_watermark_dmd)  
  return DEAL_ATTRIBUTE_READ_SQL

# COMMAND ----------

def getDealAttrReaderSQLDay0(spark , SOURCE_ETRM):
  last_watermark_dmd = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'DEAL_MONTH_DETAILS','DIM_DEAL_ATTRIBUTES')
  last_watermark_dmd = last_watermark_dmd[0:19]

  
  DEAL_ATTRIBUTE_READ_SQL = """
  SELECT 
    DC.DEAL_KEY    						AS 	SRC_SYS_DEAL_HEADER_KEY,
    DC.DEAL_KEY||'_'||DC.DLT_DEAL_TYPE||'_'||DMD.VOLUME_SEQ            AS 	SRC_SYS_DEAL_LEG_KEY,
    DC.DEAL_KEY||'_'||DC.DLT_DEAL_TYPE||'_'||DMD.VOLUME_SEQ||'_'||DMD.DETAIL_SEQ||'_'||DMD.CM_CONTRACT_MONTH   AS 	SRC_SYS_DEAL_SUB_LEG_KEY,
    DC.DLT_DEAL_TYPE                  					AS 	SRC_SYSTEM_DEAL_TYPE_CODE,
    DMD.DLT_DEAL_TYPE                    					AS 	SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    CASE WHEN DMD.DN_DIRECTION ='SALE' THEN 'SELL' ELSE 'BUY' END         AS DEAL_HEADER_BUY_SELL_FLAG,
    CASE WHEN DT.MDT_MASTER_TYPE = 'SWAP' THEN 'SWAP' 
    WHEN DT.DESCRIPTION LIKE '%SWAP%' THEN  'SWAP' 
    WHEN DT.MDT_MASTER_TYPE = 'OPTION' THEN 'OPTION'
    WHEN DT.DESCRIPTION LIKE '%OPTION%' THEN 'OPTION'
    WHEN DT.MDT_MASTER_TYPE IN ( 'TRANS', 'EMSSN', 'CAPCTY', 'POWER', 'PTP') THEN 'FORWARD' 
    ELSE 'NOT MAPPED' END AS  DEAL_INSTRUMENT_CLASSIFICATION,
    CASE WHEN (datediff((DMD.DY_END_DAY),(DMD.DY_BEG_DAY)) < 5) THEN 'SPOT' ELSE 'TERM'  END    AS 	DEAL_SPOT_TERM_IND,
    C.KTYP_CONTRACT_TYPE                 					AS 	DEAL_AGREEMENT_TYPE_DESCRIPTION,
    DSM.STATUS    AS 	HEADER_DEAL_STATUS,
    NVL(cast(C.KK_MASTER_KEY as string),C.CONTRACT_NUMBER) 	AS 	PARENT_CONTRACT_NUMBER,
    C.CONTRACT_NUMBER                    					AS 	CONTRACT_NUMBER,
    P.DESCRIPTION                        						AS 	DEAL_BOOK_NAME,
    DMD.VOLUME_SEQ                       					AS 	DEAL_LEG_REFERENCE,
    CASE WHEN DMD.DN_DIRECTION ='SALE' THEN 'SELL' ELSE 'BUY' END AS 	DEAL_LEG_BUY_SELL_FLAG,
    DSM.STATUS                           						AS 	SUB_LEG_DEAL_STATUS,
    DDA.DF_FIELD_VALUE                  					AS 	DEAL_EXECUTION_TIMESTAMP,
    DMD.DEAL_PRICE                       					AS 	DEAL_PRICE,
    CASE WHEN DMD.PRICE_TYPE='F' THEN 'FIXED' ELSE 'INDEX' END  AS 	PRICING_TYPE,
    DMD.FORMULA                          					AS 	PRICING_COMPONENT,
    'NA'                                						AS 	PREMIUM_FLOAT_SPREAD,
    'NA'                                 						AS 	INDEX_FACTOR,
    'NA'                                 						AS 	PRICING_STATUS,
    DMD.DY_END_DAY                       					AS 	PRICE_SETTLE_DATE,
    DMD.DETAIL_SEQ ||DMD.CM_CONTRACT_MONTH                       					AS 	DEAL_SUB_LEG_REFERENCE,
    DC.PHY_FIN_FLAG    AS 	SETTLEMENT_TYPE	,   
    DMD.INVOICE_DESC                     					AS 	DEAL_LINE_TEXT,
    CASE WHEN DT.MDT_MASTER_TYPE = 'OPTION' THEN DMD.PUT_CALL_FLAG ELSE '' END AS 	CALL_PUT_FLAG,
    DMD.STRIKE_PRICE                     					AS 	OPTION_STRIKE_PRICE,
        DMD.PREMIUM                          					AS 	OPTION_PREMIUM_PRICE,
      'NA'                                                        AS VESSEL_NAME,
       'NA'                                                       AS DELIVERY_JUNCTION_NAME,
       'NA' AS   DELIVERY_METHOD_NAME,
       'NA'                                                       AS BILL_OF_LADING_DATE,
       DMD.MODIFY_DATE                                          AS SOURCE_LAST_DATE1
       FROM   DEAL_CONFIRMS DC
      LEFT JOIN  DEAL_MONTH_DETAILS DMD 
      ON DMD.DEAL_KEY = DC.DEAL_KEY 
      AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = DC.DLT_DEAL_TYPE)
      LEFT JOIN   DEAL_DETAILS DD 
      ON DC.DEAL_KEY = DD.DEAL_KEY AND DC.DLT_DEAL_TYPE = DD.DLT_DEAL_TYPE 
      LEFT JOIN   CONTRACTS C 
      ON DC.KK_CONTRACT_KEY = C.CONTRACT_KEY
      LEFT JOIN   PORTFOLIOS P 
      ON DC.PRT_PORTFOLIO = P.PORTFOLIO
      LEFT JOIN (select DLT_DEAL_TYPE,DEAL_KEY,CM_CONTRACT_MONTH,STATUS
      from(
      SELECT DLT_DEAL_TYPE,DEAL_KEY,CM_CONTRACT_MONTH,STATUS,ROW_NUMBER() OVER(PARTITION BY DLT_DEAL_TYPE,DEAL_KEY,CM_CONTRACT_MONTH ORDER BY MODIFY_DATE DESC, STATUS DESC) rownum FROM DEAL_STATUS_MONTHS DSM WHERE STATUS_TYPE IN('D','D PPA'))
      where rownum=1) DSM
      ON DMD.CM_CONTRACT_MONTH = DSM.CM_CONTRACT_MONTH 
      AND DMD.DEAL_KEY = DSM.DEAL_KEY 
      AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE DSM.DLT_DEAL_TYPE WHEN 'PFOPTS' THEN 'POPTS' WHEN 'PWRNSD' THEN 'POWER' WHEN 'PWRFIN' THEN 'POWER' ELSE DSM.DLT_DEAL_TYPE END) 
      LEFT JOIN   DF_DEAL_ATTRIBUTES DDA 
    ON DMD.DEAL_KEY = DDA.DEAL_KEY AND DF_FIELD_NAME = 'EXECUTION_TIMESTAMP' 
    AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE DDA.DLT_DEAL_TYPE WHEN 'PWRNSD' THEN 'POWER' WHEN 'PNSSWP' THEN 'PSWPS' ELSE DDA.DLT_DEAL_TYPE END)
    LEFT JOIN   DEAL_TYPES DT 
    ON DC.DLT_DEAL_TYPE = DT.DEAL_TYPE
    WHERE       DC.TRADE_DATE >= '{0}' 
    AND         DC.DLT_DEAL_TYPE NOT IN('BSWPS', 'BSWPOF', 'SWPS', 'SSWPS', 'OTCOPT', 'FSWPS', 'IMBAL', 'FTOPOF', 'FTSWOF', 'TCSWOF')
    AND       (DMD.ST_SETTLEMENT_TYPE NOT LIKE 'NG%' OR DMD.ST_SETTLEMENT_TYPE IS NULL)

  """.format(last_watermark_dmd)
  
  return DEAL_ATTRIBUTE_READ_SQL
