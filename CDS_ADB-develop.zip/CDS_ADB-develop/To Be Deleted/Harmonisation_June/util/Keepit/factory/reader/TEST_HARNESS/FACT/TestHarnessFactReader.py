# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../../factory/reader/DatasetReader

# COMMAND ----------

class TestHarnessFactReader(SourceDatasetReader):
    
   def read(spark, SOURCE_ETRM, metricDict, initial_load):

      dfHeader = executeJdbcQueryAndReturnDF("select * from hardcoded_fact_header_reader")
      dfLeg = executeJdbcQueryAndReturnDF("select * from hardcoded_fact_leg_reader")
      dfSubleg = executeJdbcQueryAndReturnDF("select * from hardcoded_fact_subleg_reader")
      
      return (dfHeader,dfLeg,dfSubleg, metricDict);
      
  
