# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class EndurGPNATraderReader(SourceDatasetReader):
    
  def read(spark,metricDict):
        
        SOURCE_ETRM = 'ENDUR_GPNA'
        last_watermark = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'PERSONNEL','DIM_TRADER')
        last_watermark = last_watermark[0:19]
        
        df = executeJdbcQueryAndReturnDF("select src_sys_trader_nk from tsa_curated.dim_trader where src_sys_name = '{0}'".format(SOURCE_ETRM))
        df.createOrReplaceTempView("CURATED_DIM_TRADER")
        
        TRADER_READER_SQL = """
        SELECT b.id_number SRC_SYS_TRADER_NK,
        b.name TRADER_NAME,
        b.first_name TRADER_FIRST_NAME,
        b.last_name TRADER_LAST_NAME,
        b.last_update SOURCE_LAST_UPDATE
        FROM PERSONNEL b WHERE 
        (
        b.last_update > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
        or
        b.id_number in (select src_sys_trader_nk from CURATED_DIM_TRADER)
        )
        AND EXISTS(
          SELECT 1 
          FROM AB_TRAN a
          WHERE a.internal_contact = b.id_number)
         
        """.format(last_watermark)
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PERSONNEL', format, 'PERSONNEL')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN', format, 'AB_TRAN')
        
        df = spark.sql(TRADER_READER_SQL)
        
        return (df,metricDict)

# COMMAND ----------

 
