# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

class DexFactLegReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
        
    (dfLeg,metricDict) = readFactLeg(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD)

    return (dfLeg,metricDict)

# COMMAND ----------

  def readFactLeg(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
    
    last_watermark_fact_contract1 = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'STO_CONTRACT','CONTRACT_DATE','FACT_DEAL_LEG')
    last_watermark_fact_contract1 = last_watermark_fact_contract1[0:19]

    last_watermark_fact_contract2= getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'STO_CONTRACT','LAST_UPDATE_TSTMP','FACT_DEAL_LEG')
    last_watermark_fact_contract2 = last_watermark_fact_contract2[0:19]
   
    if INITIAL_LOAD == "Y" :
      SQL = getLegReaderSQLDay0(last_watermark_fact_contract1)
    else:
      SQL = getLegReaderSQLDay1(last_watermark_fact_contract1, last_watermark_fact_contract2)
  
    
    format = "delta"
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CONTRACT', format, 'STO_CONTRACT')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CDTYCTMT', format, 'STO_CDTYCTMT')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLCST', format, 'STO_PRCLCST')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PARCEL', format, 'STO_PARCEL')
   
    dfFactLeg = spark.sql(SQL)
    
    dfFactLeg = dfFactLeg.withColumn("SHELL_TRADING_PARTY_NK",dfFactLeg.SHELL_TRADING_PARTY_NK.cast('int'))
    dfFactLeg = dfFactLeg.withColumn("COUNTERPARTY_NK",dfFactLeg.COUNTERPARTY_NK.cast('int'))
    
    dfFactLeg.show(10,truncate=False)
    
    print("DexFactLegReader" , dfFactLeg.count())
    
    return (dfFactLeg,metricDict)

# COMMAND ----------

def getLegReaderSQLDay1(last_watermark_fact_contract1, last_watermark_fact_contract2):
  SQL = """
  
  	 WITH DEALS_IN_SCOPE AS 
				(
				SELECT DISTINCT CONTRACT_NUM
				,CONTRACT_CREATE_D
				FROM		STO_CONTRACT
				WHERE  		  ( 
							  (
							  CONTRACT_DATE > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
							  ) 
							  OR
							  (
							  CONTRACT_DATE < to_timestamp('{1}','yyyy-MM-dd HH:mm:ss') 
							  and LAST_UPDATE_TSTMP > to_timestamp('{2}','yyyy-MM-dd HH:mm:ss')	
							  )		
							  )	
				)
   SELECT a.TRDG_COMP_MNEM||'_'||a.CONTRACT_NUM||'_'|| date_format(a.CONTRACT_CREATE_D,'yyyyMMdd')||'_'||b.CTMT_SEQ_NUM	AS DEAL_ATTRIBUTES_NK	,LEAST(CAST(c.EXECUTION_TSTMP AS DATE), CAST(b.EXECUTION_TSTMP AS DATE) ) 									         AS EXECUTION_DATE
   ,a.CONTRACT_DATE  																							        AS TRADE_CREATION_DATE	 ,b.COMMITMENT_DATE 																							      AS COMMITMENT_DATE
   ,a.CLT_CHRG_ACCT_NUM 																					            AS COUNTERPARTY_NK
   ,a.OWNG_CHRG_ACCT_NUM 																						      AS SHELL_TRADING_PARTY_NK    ,a.TRADER_USERID 																							        AS TRADER_NK
   ,'-3' 																										        AS DEAL_BROKER_NK	      ,b.QTY_UNIT_CODE 																							        AS UNIT_OF_MEASURE_NK	      ,b.GRADE_CODE 																								         AS COMMODITY_NK
   ,b.QTY_AMT 																									          AS COMMITMENT_QTY			      ,CASE 
       WHEN b.OWNER_BUY_SELL_IND = 'S' THEN -1 
       WHEN b.OWNER_BUY_SELL_IND = 'B' THEN 1 
       ELSE 0 END 			                                                                                             AS DEAL_LEG_MULTIPLIER	   ,a.LAST_UPDATE_TSTMP 																						      AS SOURCE_LAST_DATE1
    ,a.CONTRACT_DATE 																							       AS SOURCE_LAST_DATE2
    ,'' 																										       AS SOURCE_LAST_DATE3, '' as SRC_SYS_DEAL_HEADER_KEY
      FROM		STO_CONTRACT a
      JOIN       STO_CDTYCTMT b
      ON  		a.CONTRACT_NUM = b.CONTRACT_NUM
      AND         a.CONTRACT_CREATE_D = b.CONTRACT_CREATE_D
      JOIN        (
                  SELECT 	CONTRACT_NUM, CONTRACT_CREATE_D, CDTY_CTMT_SEQ_NUM ,EXECUTION_TSTMP
                  FROM	(
                          SELECT CONTRACT_NUM, CONTRACT_CREATE_D, CDTY_CTMT_SEQ_NUM, EXECUTION_TSTMP,
                                      ROW_NUMBER() OVER(PARTITION BY CONTRACT_NUM, CONTRACT_CREATE_D, CDTY_CTMT_SEQ_NUM 
                                      ORDER BY NVL(EXECUTION_TSTMP,'31-DEC-9999') asc) AS ROW_NUM	
                          FROM	STO_PARCEL C
                          ) WHERE ROW_NUM = 1
                  ) c
      ON          b.CONTRACT_NUM = c.CONTRACT_NUM 
      AND 		b.CONTRACT_CREATE_D = c.CONTRACT_CREATE_D
      AND 		b.CTMT_SEQ_NUM = c.CDTY_CTMT_SEQ_NUM  
      JOIN		INSCOPE_DEALS d
      ON          a.CONTRACT_NUM = d.CONTRACT_NUM
      AND         a.CONTRACT_CREATE_D = d.CONTRACT_CREATE_D  
      where b.grade_code not in ('LPROP') 
AND  a.OWNG_CHRG_ACCT_NUM not In ('2304','2391','2390')
  """.format(last_watermark_fact_contract1,last_watermark_fact_contract1,last_watermark_fact_contract2)
  return SQL

# COMMAND ----------

def getLegReaderSQLDay0(last_watermark_fact_contract1):
  SQL = """
          WITH INSCOPE_DEALS AS 
              (
              SELECT  DISTINCT CONTRACT_NUM
              ,CONTRACT_CREATE_D
              FROM    STO_PARCEL
              WHERE 	PARCEL_DATE > '{0}'
              and PARCEL_DATE < '2019-05-01 00:00:00'
              )

   SELECT a.TRDG_COMP_MNEM||'_'||a.CONTRACT_NUM||'_'|| date_format(a.CONTRACT_CREATE_D,'yyyyMMdd')||'_'||b.CTMT_SEQ_NUM	AS DEAL_ATTRIBUTES_NK	,LEAST(CAST(c.EXECUTION_TSTMP AS DATE), CAST(b.EXECUTION_TSTMP AS DATE) ) 									         AS EXECUTION_DATE
   ,a.CONTRACT_DATE  																							        AS TRADE_CREATION_DATE	 ,b.COMMITMENT_DATE 																							      AS COMMITMENT_DATE
   ,a.CLT_CHRG_ACCT_NUM 																					            AS COUNTERPARTY_NK
   ,a.OWNG_CHRG_ACCT_NUM 																						      AS SHELL_TRADING_PARTY_NK    ,a.TRADER_USERID 																							        AS TRADER_NK
   ,'-3' 																										        AS DEAL_BROKER_NK	      ,b.QTY_UNIT_CODE 																							        AS UNIT_OF_MEASURE_NK	      ,b.GRADE_CODE 																								         AS COMMODITY_NK
   ,b.QTY_AMT 																									          AS COMMITMENT_QTY			      ,CASE 
       WHEN b.OWNER_BUY_SELL_IND = 'S' THEN -1 
       WHEN b.OWNER_BUY_SELL_IND = 'B' THEN 1 
       ELSE 0 END 			                                                                                             AS DEAL_LEG_MULTIPLIER	   ,a.LAST_UPDATE_TSTMP 																						      AS SOURCE_LAST_DATE1
    ,a.CONTRACT_DATE 																							       AS SOURCE_LAST_DATE2
    ,'' 																										       AS SOURCE_LAST_DATE3, '' as SRC_SYS_DEAL_HEADER_KEY
      FROM		STO_CONTRACT a
      JOIN       STO_CDTYCTMT b
      ON  		a.CONTRACT_NUM = b.CONTRACT_NUM
      AND         a.CONTRACT_CREATE_D = b.CONTRACT_CREATE_D
      JOIN        (
                  SELECT 	CONTRACT_NUM, CONTRACT_CREATE_D, CDTY_CTMT_SEQ_NUM ,EXECUTION_TSTMP
                  FROM	(
                          SELECT CONTRACT_NUM, CONTRACT_CREATE_D, CDTY_CTMT_SEQ_NUM, EXECUTION_TSTMP,
                                      ROW_NUMBER() OVER(PARTITION BY CONTRACT_NUM, CONTRACT_CREATE_D, CDTY_CTMT_SEQ_NUM 
                                      ORDER BY NVL(EXECUTION_TSTMP,'31-DEC-9999') asc) AS ROW_NUM	
                          FROM	STO_PARCEL C
                          ) WHERE ROW_NUM = 1
                  ) c
      ON          b.CONTRACT_NUM = c.CONTRACT_NUM 
      AND 		b.CONTRACT_CREATE_D = c.CONTRACT_CREATE_D
      AND 		b.CTMT_SEQ_NUM = c.CDTY_CTMT_SEQ_NUM  
      JOIN		INSCOPE_DEALS d
      ON          a.CONTRACT_NUM = d.CONTRACT_NUM
      AND         a.CONTRACT_CREATE_D = d.CONTRACT_CREATE_D   
      where b.grade_code not in ('LPROP') 
AND  a.OWNG_CHRG_ACCT_NUM not In ('2304','2391','2390')
  """.format(last_watermark_fact_contract1)

  return SQL

