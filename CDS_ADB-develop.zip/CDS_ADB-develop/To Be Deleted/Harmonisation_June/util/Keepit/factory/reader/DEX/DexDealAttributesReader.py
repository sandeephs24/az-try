# Databricks notebook source
# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../enricher/DealAttributeEnricher

# COMMAND ----------

class DexDealAttributesReader(SourceDatasetReader):
    
  def read(spark,metricDict, INITIAL_LOAD):
        SOURCE_ETRM = 'DEX'



        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PARCEL', format, 'STO_PARCEL')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CONTRACT', format, 'STO_CONTRACT')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CHRGACCT', format, 'STO_CHRGACCT')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRICING', format, 'STO_PRICING')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCGTERM', format, 'STO_PRCGTERM')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CDTYCTMT', format, 'STO_CDTYCTMT')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLOPRN', format, 'STO_PRCLOPRN')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_VOYAGE', format, 'STO_VOYAGE')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_VESSEL', format, 'STO_VESSEL')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLDCH', format, 'STO_PRCLDCH')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_LOCATION', format, 'STO_LOCATION')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_BKOTPRCL', format, 'STO_BKOTPRCL')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_BKOTCHN', format, 'STO_BKOTCHN')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLFCST', format, 'STO_PRCLFCST')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_SETTLMNT', format, 'STO_SETTLMNT')     

      
        print("running sql DEAL_ATTRIBUTE_READ_SQL")

        if (INITIAL_LOAD == "Y") :
          DEAL_ATTRIBUTE_READ_SQL = getDealAttrReaderSQLDay0(spark , SOURCE_ETRM)
        else:
          DEAL_ATTRIBUTE_READ_SQL = getDealAttrReaderSQLDay1(spark , SOURCE_ETRM)


        df = spark.sql(DEAL_ATTRIBUTE_READ_SQL) 
        df = df.withColumn("SOURCE_LAST_DATE1", substring('SOURCE_LAST_DATE1', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE2", substring('SOURCE_LAST_DATE2', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE3", substring('SOURCE_LAST_DATE3', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE4", substring('SOURCE_LAST_DATE4', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE5", substring('SOURCE_LAST_DATE5', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE6", substring('SOURCE_LAST_DATE6', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE7", substring('SOURCE_LAST_DATE7', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE8", substring('SOURCE_LAST_DATE8', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE9", substring('SOURCE_LAST_DATE9', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE10", substring('SOURCE_LAST_DATE10', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE11", substring('SOURCE_LAST_DATE11', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE12", substring('SOURCE_LAST_DATE12', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE13", substring('SOURCE_LAST_DATE13', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE14", substring('SOURCE_LAST_DATE14', 1,19)) 
        df = df.withColumn("SOURCE_LAST_DATE15", substring('SOURCE_LAST_DATE15', 1,19)) 
        df = df.withColumn("DEAL_EXECUTION_TIMESTAMP", substring('DEAL_EXECUTION_TIMESTAMP', 1,19))       
        df = df.withColumn("BILL_OF_LADING_DATE", substring('BILL_OF_LADING_DATE', 1,19)) 
        df = df.withColumn("PRICE_SETTLE_DATE", substring('PRICE_SETTLE_DATE', 1,19)) 

        print("running sql DEAL_ATTRIBUTE_READ_SQL- count ", df.count())
        df.show(20,False)

        print ("Running enricher")
        df = DealAttributeenrich(spark,df,SOURCE_ETRM)
        print ("Running enricher - DOne")
        #df.show(20,False)
        df.printSchema()
        return  (df,metricDict)
      

# COMMAND ----------

def getDealAttrReaderSQLDay1(spark , SOURCE_ETRM):
  last_watermark_parcel = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PARCEL','DIM_DEAL_ATTRIBUTES')
  last_watermark_parcel = last_watermark_parcel[0:19]

  last_watermark_contract = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_CONTRACT','DIM_DEAL_ATTRIBUTES')
  last_watermark_contract = last_watermark_contract[0:19]

  last_watermark_chrgacct = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_CHRGACCT','DIM_DEAL_ATTRIBUTES')
  last_watermark_chrgacct = last_watermark_chrgacct[0:19]

  last_watermark_pricing = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PRICING','DIM_DEAL_ATTRIBUTES')
  last_watermark_pricing = last_watermark_pricing[0:19]

  last_watermark_prcgterm = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PRCGTERM','DIM_DEAL_ATTRIBUTES')
  last_watermark_prcgterm = last_watermark_prcgterm[0:19]

  last_watermark_cdtyctmt = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_CDTYCTMT','DIM_DEAL_ATTRIBUTES')
  last_watermark_cdtyctmt = last_watermark_cdtyctmt[0:19]

  last_watermark_prcloprn = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PRCLOPRN','DIM_DEAL_ATTRIBUTES')
  last_watermark_prcloprn = last_watermark_prcloprn[0:19]

  last_watermark_voyage = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_VOYAGE','DIM_DEAL_ATTRIBUTES')
  last_watermark_voyage = last_watermark_voyage[0:19]

  last_watermark_vessel = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_VESSEL','DIM_DEAL_ATTRIBUTES')
  last_watermark_vessel = last_watermark_vessel[0:19]

  last_watermark_prcldch = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PRCLDCH','DIM_DEAL_ATTRIBUTES')
  last_watermark_prcldch = last_watermark_prcldch[0:19]

  last_watermark_location = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_LOCATION','DIM_DEAL_ATTRIBUTES')
  last_watermark_location = last_watermark_location[0:19]

  last_watermark_bkotprcl = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_BKOTPRCL','DIM_DEAL_ATTRIBUTES')
  last_watermark_bkotprcl = last_watermark_bkotprcl[0:19]

  last_watermark_bkotchn = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_BKOTCHN','DIM_DEAL_ATTRIBUTES')
  last_watermark_bkotchn = last_watermark_bkotchn[0:19]

  last_watermark_prclfcst = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PRCLFCST','DIM_DEAL_ATTRIBUTES')
  last_watermark_prclfcst = last_watermark_prclfcst[0:19]

  last_watermark_settlmnt = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_SETTLMNT','DIM_DEAL_ATTRIBUTES')
  last_watermark_settlmnt = last_watermark_settlmnt[0:19]

  DEAL_ATTRIBUTE_READ_SQL = """
  select distinct a.TRDG_COMP_MNEM||'_'||a.CONTRACT_NUM||'_'||date_format(a.CONTRACT_CREATE_D,'yyyyMMdd')  as SRC_SYS_DEAL_HEADER_KEY
  ,b.TRDG_COMP_MNEM||'_'||b.CONTRACT_NUM||'_'|| date_format(a.CONTRACT_CREATE_D,'yyyyMMdd') ||'_'||b.CTMT_SEQ_NUM as SRC_SYS_DEAL_LEG_KEY
  ,c.TRDG_COMP_MNEM||'_'||c.CONTRACT_NUM||'_'||date_format(a.CONTRACT_CREATE_D,'yyyyMMdd')||'_'||c.CDTY_CTMT_SEQ_NUM||'_'||c.PRCL_SEQ_NUM as SRC_SYS_DEAL_SUB_LEG_KEY
  ,c.DEAL_CLASS_CODE                                                                     as SRC_SYSTEM_DEAL_TYPE_CODE      
  ,c.DEAL_TYPE_CODE                                                                      as SRC_SYSTEM_DEAL_SUBTYPE_CODE 
  ,CASE WHEN b2.OWNER_BUY_SELL_IND = 'S' THEN 'Sell'
     WHEN b2.OWNER_BUY_SELL_IND = 'B' THEN 'Buy'
     ELSE 'Unknown' END                                                                  as  DEAL_HEADER_BUY_SELL_FLAG
  ,CASE WHEN c.DEAL_CLASS_CODE = 'EXE' THEN 'SWAP' 
     WHEN c.DEAL_CLASS_CODE = 'OPT' THEN 'OPTION' 
     WHEN c.DEAL_CLASS_CODE = 'FUT' THEN 'FUTURE' 
     WHEN c.DEAL_CLASS_CODE = 'FWD' THEN 'FORWARD'
     WHEN c.DEAL_CLASS_CODE = 'WET' THEN 'WET' 
     WHEN c.DEAL_CLASS_CODE = 'NULL' THEN 'NULL AT SOURCE' ELSE 'MAPPING NOT FOUND' END  as DEAL_INSTRUMENT_CLASSIFICATION
  ,a.SPOT_TERM_CODE                                                                      as DEAL_SPOT_TERM_IND
  ,b.GT_AND_C_CODE                                                                       as DEAL_AGREEMENT_TYPE_DESCRIPTION
  ,a.VLDT_LEVEL                                                                          as HEADER_DEAL_STATUS
  ,a.CONTRACT_NUM                                                                        as PARENT_CONTRACT_NUMBER
  ,a.CONTRACT_NUM                                                                        as CONTRACT_NUMBER
  ,d.CHARGE_ACCT_NAME                                                                    as DEAL_BOOK_NAME
  ,c.CDTY_CTMT_SEQ_NUM                                                                   as DEAL_LEG_REFERENCE
  ,CASE WHEN b.DEAL_CLASS_CODE != 'EXE' 
        THEN ( CASE WHEN b.OWNER_BUY_SELL_IND = 'S' THEN 'Sell' WHEN b.OWNER_BUY_SELL_IND = 'B' THEN 'Buy' END)
        WHEN b2.OWNER_BUY_SELL_IND = NVL(b3.OWNER_BUY_SELL_IND,b2.OWNER_BUY_SELL_IND) 
        THEN ( CASE WHEN b2.OWNER_BUY_SELL_IND = 'S' THEN 'Sell' WHEN b2.OWNER_BUY_SELL_IND = 'B' THEN 'Buy' END)
        WHEN b2.OWNER_BUY_SELL_IND != b3.OWNER_BUY_SELL_IND
        AND b.CTMT_SEQ_NUM IN ('01', '02') 
        THEN ( CASE WHEN b2.OWNER_BUY_SELL_IND = 'S' THEN 'Sell' WHEN b2.OWNER_BUY_SELL_IND = 'B' THEN 'Buy' END)
        WHEN b2.OWNER_BUY_SELL_IND != b3.OWNER_BUY_SELL_IND
        AND b.CTMT_SEQ_NUM IN ('03', '04')
        THEN ( CASE WHEN b3.OWNER_BUY_SELL_IND = 'S' THEN 'Sell' WHEN b3.OWNER_BUY_SELL_IND = 'B' THEN 'Buy' END)
    ELSE 'UNKNOWN' END                                                                   as DEAL_LEG_BUY_SELL_FLAG
  ,CASE WHEN c.QTY_AMT = 0 THEN 'DEX SYNTHETIC CANCELLATION' ELSE c.VLDT_LEVEL END       as SUB_LEG_DEAL_STATUS
  ,b.EXECUTION_TSTMP                                                                     as DEAL_EXECUTION_TIMESTAMP
  ,e.FINAL_PRCL_PRICE                                                                    as DEAL_PRICE
  ,CASE WHEN e.FIXED_PRICE <>'0' THEN 'FIXED'  ELSE 'FLOAT'  END                         as PRICING_TYPE
  ,case when f.PRCG_SEQ_NUM = f3.PRCG_SEQ_NUM then 'Highest Weight:'|| f.FRML_NAME else f.FRML_NAME end as PRICING_COMPONENT
  ,f.PREMIUM_PRICE                                                                       as PREMIUM_FLOAT_SPREAD
  ,c.BT_FACTOR_NUM                                                                       as INDEX_FACTOR
  ,CASE WHEN e.FINAL_PRCL_PRICE <>'0' THEN 'KNOWN'  ELSE 'UNKNOWN'  END                  as PRICING_STATUS
  ,CASE WHEN c.WET_OR_DRY_IND = 'D' THEN k.PAYMENT_DATE ELSE m.SETTLEMENT_MADE_D END     as PRICE_SETTLE_DATE
  ,c.PRCL_SEQ_NUM                                                                        as DEAL_SUB_LEG_REFERENCE
  ,CASE WHEN c.DEAL_CLASS_CODE ='OPT' THEN c.OPT_SETL_TYPE_CODE 
  WHEN c.WET_OR_DRY_IND = 'W' THEN 'PHYSICAL' ELSE 'FINANCIAL'  END                      as SETTLEMENT_TYPE
  ,'NA'                                                                                  as DEAL_LINE_TEXT
  ,c.OPT_CALL_PUT_IND                                                                    as CALL_PUT_FLAG
  ,c.OPT_STRIKE_PRICE                                                                    as OPTION_STRIKE_PRICE
  ,e.FIXED_PRICE                                                                         as OPTION_PREMIUM_PRICE
  ,i.CURRENT_NAME                                                                        as VESSEL_NAME
  ,o.LOCATION_CODE                                                                       as DELIVERY_JUNCTION_NAME
  ,i.TRANSPORT_TYP_CODE                                                                  as TRANSPORT_TYP_CODE
  ,C.BOL_DATE                                                                            as BILL_OF_LADING_DATE
  ,a.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE1
  ,b.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE2
  ,c.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE3
  ,d.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE4
  ,e.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE5
  ,f.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE6
  ,g.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE7
  ,h.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE8
  ,i.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE9
  ,k.LAST_UPDATE_TSTMP1                                                                   as SOURCE_LAST_DATE10
  ,k.LAST_UPDATE_TSTMP2                                                                   as SOURCE_LAST_DATE11
  ,l.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE12
  ,m.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE13
  ,n.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE14 
  ,o.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE15
  FROM        STO_CONTRACT a
  JOIN        STO_CDTYCTMT b
  ON          a.CONTRACT_NUM = b.CONTRACT_NUM 
  AND         a.CONTRACT_CREATE_D = b.CONTRACT_CREATE_D
  JOIN(
	SELECT	CONTRACT_NUM
		,CONTRACT_CREATE_D
		,OWNER_BUY_SELL_IND
	FROM	STO_CDTYCTMT
	WHERE	CTMT_SEQ_NUM = '01'
	) b2 
    ON a.CONTRACT_NUM = b2.CONTRACT_NUM 
    AND a.CONTRACT_CREATE_D = b2.CONTRACT_CREATE_D
    LEFT JOIN(
	SELECT	CONTRACT_NUM
		,CONTRACT_CREATE_D
		,OWNER_BUY_SELL_IND
	FROM	STO_CDTYCTMT
	WHERE	CTMT_SEQ_NUM = '03'
	) b3
    ON a.CONTRACT_NUM = b3.CONTRACT_NUM
    AND a.CONTRACT_CREATE_D = b3.CONTRACT_CREATE_D
  JOIN        STO_PARCEL c
  ON          b.CONTRACT_NUM = c.CONTRACT_NUM 
  AND         b.CTMT_SEQ_NUM = c.CDTY_CTMT_SEQ_NUM
  AND         b.CONTRACT_CREATE_D = c.CONTRACT_CREATE_D
  AND         c.VLDT_LEVEL <> 'V'
  LEFT JOIN   STO_CHRGACCT d 
  ON          a.OWNG_CHRG_ACCT_NUM = d.SEQUENCE_NUM 
  LEFT JOIN   STO_PRICING e
  ON          c.PRCG_SEQ_NUM  = e.SEQUENCE_NUM
  LEFT JOIN   (

  select  f1.* 
  ,row_number() OVER(PARTITION BY f1.prcg_seq_num
  ORDER BY f1.WEIGHTING_PC desc,SEQ_NUM asc) row_num
  from    STO_PRCGTERM f1 
  ) f
  ON          c.PRCG_SEQ_NUM = f.PRCG_SEQ_NUM
  AND         f.row_num = 1
  LEFT JOIN   (

  select  f2.* 
  ,row_number() OVER(PARTITION BY f2.prcg_seq_num
  ORDER BY f2.WEIGHTING_PC desc,SEQ_NUM asc) row_num
  from    STO_PRCGTERM f2 
  ) f3
  ON          c.PRCG_SEQ_NUM = f3.PRCG_SEQ_NUM
  AND         f3.row_num = 2
  LEFT JOIN   STO_PRCLOPRN g 
  ON          c.CONTRACT_NUM = g.CONTRACT_NUM
  AND         c.PRCL_SEQ_NUM = g.PRCL_SEQ_NUM
  LEFT JOIN   (select SEQUENCE_NUM,VESSEL_SEQ_NUM,LAST_UPDATE_TSTMP
  from(
  select
  SEQUENCE_NUM,VESSEL_SEQ_NUM,LAST_UPDATE_TSTMP, row_number()
  over(partition by SEQUENCE_NUM order by SEQUENCE_NUM) row_num
  from
  STO_VOYAGE
  ) where row_num = 1) h
  ON          g.VOYAGE_SEQ_NUM  = h.SEQUENCE_NUM
  LEFT JOIN	STO_VESSEL i
  ON	        h.VESSEL_SEQ_NUM = i.SEQUENCE_NUM
  LEFT JOIN   (
  SELECT  j1.CONTRACT_NUM 
  ,j1.PRCL_SEQ_NUM
  ,j1.CONTRACT_CREATE_D
  ,j2.PAYMENT_DATE
  ,j1.LAST_UPDATE_TSTMP LAST_UPDATE_TSTMP1
  ,j1.LAST_UPDATE_TSTMP LAST_UPDATE_TSTMP2
  ,row_number() OVER(PARTITION BY j1.CONTRACT_NUM, j1.PRCL_SEQ_NUM, j1.CONTRACT_CREATE_D
  ORDER BY j2.PAYMENT_DATE desc) row_num
  FROM    STO_BKOTPRCL j1
  JOIN STO_BKOTCHN j2 
  ON      j1.REF_MNEM = j2.REF_MNEM
  ) k
  ON          c.CONTRACT_NUM  = k.CONTRACT_NUM
  AND         c.PRCL_SEQ_NUM  = k.PRCL_SEQ_NUM
  AND         c.CONTRACT_CREATE_D = k.CONTRACT_CREATE_D
  AND         k.row_num = 1
  LEFT JOIN (
  select  y.* 
  ,row_number() OVER(PARTITION BY y.CONTRACT_NUM, y.PRCL_SEQ_NUM
  ORDER BY y.SETTLEMENT_SEQ_NUM desc) row_num
  from    STO_PRCLFCST y
  where   y.COST_TYPE_CODE = 'OIL' 
  and     y.COST_CODE='OIL' 
  ) l
  ON          a.CONTRACT_NUM = l.CONTRACT_NUM
  AND         c.PRCL_SEQ_NUM = l.PRCL_SEQ_NUM
  AND         l.row_num = 1
  LEFT JOIN   STO_SETTLMNT m
  ON          l.SETTLEMENT_SEQ_NUM = m.SEQUENCE_NUM
  LEFT JOIN  STO_PRCLDCH n 
  on          c.CONTRACT_NUM = n.CONTRACT_NUM
  AND         c.PRCL_SEQ_NUM = n.PRCL_SEQ_NUM 
  LEFT JOIN  STO_location o
  ON          n.LOC_SEQ_NUM = o.SEQUENCE_NUM
  WHERE 
  (
  a.LAST_UPDATE_TSTMP > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
  or 
  b.LAST_UPDATE_TSTMP > to_timestamp('{1}','yyyy-MM-dd HH:mm:ss')
  or
  c.LAST_UPDATE_TSTMP > to_timestamp('{2}','yyyy-MM-dd HH:mm:ss') 
  or
  d.LAST_UPDATE_TSTMP > to_timestamp('{3}','yyyy-MM-dd HH:mm:ss')
  or
  e.LAST_UPDATE_TSTMP > to_timestamp('{4}','yyyy-MM-dd HH:mm:ss')
  or
  f.LAST_UPDATE_TSTMP > to_timestamp('{5}','yyyy-MM-dd HH:mm:ss')
  or
  g.LAST_UPDATE_TSTMP > to_timestamp('{6}','yyyy-MM-dd HH:mm:ss')
  or
  h.LAST_UPDATE_TSTMP > to_timestamp('{7}','yyyy-MM-dd HH:mm:ss')
  or
  i.LAST_UPDATE_TSTMP > to_timestamp('{8}','yyyy-MM-dd HH:mm:ss')
  or
  k.LAST_UPDATE_TSTMP1 > to_timestamp('{9}','yyyy-MM-dd HH:mm:ss')
  or
  k.LAST_UPDATE_TSTMP2 > to_timestamp('{10}','yyyy-MM-dd HH:mm:ss')
  or
  l.LAST_UPDATE_TSTMP > to_timestamp('{11}','yyyy-MM-dd HH:mm:ss')
  or
  m.LAST_UPDATE_TSTMP > to_timestamp('{12}','yyyy-MM-dd HH:mm:ss')
  or
  n.LAST_UPDATE_TSTMP > to_timestamp('{13}','yyyy-MM-dd HH:mm:ss')
  or
  o.LAST_UPDATE_TSTMP > to_timestamp('{14}','yyyy-MM-dd HH:mm:ss')
  )
  and 
    b.grade_code not in ('LPROP') AND  a.OWNG_CHRG_ACCT_NUM not In ('2304','2391','2390')
  """.format(last_watermark_contract,last_watermark_cdtyctmt,last_watermark_parcel,last_watermark_chrgacct,
  last_watermark_pricing,last_watermark_prcgterm,last_watermark_prcloprn,last_watermark_voyage,
  last_watermark_vessel,last_watermark_bkotprcl,last_watermark_bkotchn,last_watermark_prclfcst,
  last_watermark_settlmnt,last_watermark_prcldch,last_watermark_location)
  
  return DEAL_ATTRIBUTE_READ_SQL

# COMMAND ----------

def getDealAttrReaderSQLDay0(spark , SOURCE_ETRM):
  last_watermark_parcel = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PARCEL','DIM_DEAL_ATTRIBUTES')
  last_watermark_parcel = last_watermark_parcel[0:19]

  
  DEAL_ATTRIBUTE_READ_SQL = """
  select distinct a.TRDG_COMP_MNEM||'_'||a.CONTRACT_NUM||'_'||date_format(a.CONTRACT_CREATE_D,'yyyyMMdd')  as SRC_SYS_DEAL_HEADER_KEY
  ,b.TRDG_COMP_MNEM||'_'||b.CONTRACT_NUM||'_'|| date_format(a.CONTRACT_CREATE_D,'yyyyMMdd') ||'_'||b.CTMT_SEQ_NUM as SRC_SYS_DEAL_LEG_KEY
  ,c.TRDG_COMP_MNEM||'_'||c.CONTRACT_NUM||'_'||date_format(a.CONTRACT_CREATE_D,'yyyyMMdd')||'_'||c.CDTY_CTMT_SEQ_NUM||'_'||
  c.PRCL_SEQ_NUM as SRC_SYS_DEAL_SUB_LEG_KEY
  ,c.DEAL_CLASS_CODE                                                                     as SRC_SYSTEM_DEAL_TYPE_CODE      
  ,c.DEAL_TYPE_CODE                                                                      as SRC_SYSTEM_DEAL_SUBTYPE_CODE
  ,CASE WHEN b2.OWNER_BUY_SELL_IND = 'S' THEN 'Sell'
     WHEN b2.OWNER_BUY_SELL_IND = 'B' THEN 'Buy'
     ELSE 'Unknown' END                                                                  as  DEAL_HEADER_BUY_SELL_FLAG
  ,CASE WHEN c.DEAL_CLASS_CODE = 'EXE' THEN 'SWAP' 
    WHEN c.DEAL_CLASS_CODE = 'OPT' THEN 'OPTION' 
    WHEN c.DEAL_CLASS_CODE = 'FUT' THEN 'FUTURE'
    WHEN c.DEAL_CLASS_CODE = 'FWD' THEN 'FORWARD'
    WHEN c.DEAL_CLASS_CODE = 'WET' THEN 'WET' 
    WHEN c.DEAL_CLASS_CODE = 'NULL' THEN 'NULL AT SOURCE' ELSE 'MAPPING NOT FOUND' END   as DEAL_INSTRUMENT_CLASSIFICATION
  ,a.SPOT_TERM_CODE                                                                      as DEAL_SPOT_TERM_IND
  ,b.GT_AND_C_CODE                                                                       as DEAL_AGREEMENT_TYPE_DESCRIPTION
  ,a.VLDT_LEVEL                                                                          as HEADER_DEAL_STATUS
  ,a.CONTRACT_NUM                                                                        as PARENT_CONTRACT_NUMBER
  ,a.CONTRACT_NUM                                                                        as CONTRACT_NUMBER
  ,d.CHARGE_ACCT_NAME                                                                    as DEAL_BOOK_NAME
  ,c.CDTY_CTMT_SEQ_NUM                                                                   as DEAL_LEG_REFERENCE
  ,CASE WHEN b.DEAL_CLASS_CODE != 'EXE' 
        THEN ( CASE WHEN b.OWNER_BUY_SELL_IND = 'S' THEN 'Sell' WHEN b.OWNER_BUY_SELL_IND = 'B' THEN 'Buy' END)
        WHEN b2.OWNER_BUY_SELL_IND = NVL(b3.OWNER_BUY_SELL_IND,b2.OWNER_BUY_SELL_IND) 
        THEN ( CASE WHEN b2.OWNER_BUY_SELL_IND = 'S' THEN 'Sell' WHEN b2.OWNER_BUY_SELL_IND = 'B' THEN 'Buy' END)
        WHEN b2.OWNER_BUY_SELL_IND != b3.OWNER_BUY_SELL_IND
        AND b.CTMT_SEQ_NUM IN ('01', '02') 
        THEN ( CASE WHEN b2.OWNER_BUY_SELL_IND = 'S' THEN 'Sell' WHEN b2.OWNER_BUY_SELL_IND = 'B' THEN 'Buy' END)
        WHEN b2.OWNER_BUY_SELL_IND != b3.OWNER_BUY_SELL_IND
        AND b.CTMT_SEQ_NUM IN ('03', '04')
        THEN ( CASE WHEN b3.OWNER_BUY_SELL_IND = 'S' THEN 'Sell' WHEN b3.OWNER_BUY_SELL_IND = 'B' THEN 'Buy' END)
    ELSE 'UNKNOWN' END                                                                   as DEAL_LEG_BUY_SELL_FLAG
  ,CASE WHEN c.QTY_AMT = 0 THEN 'DEX SYNTHETIC CANCELLATION' ELSE c.VLDT_LEVEL END       as SUB_LEG_DEAL_STATUS
  ,b.EXECUTION_TSTMP                                                                     as DEAL_EXECUTION_TIMESTAMP
  ,e.FINAL_PRCL_PRICE                                                                    as DEAL_PRICE
  ,CASE WHEN e.FIXED_PRICE <>'0' THEN 'FIXED'  ELSE 'FLOAT'  END                         as PRICING_TYPE
  ,case when f.PRCG_SEQ_NUM = f3.PRCG_SEQ_NUM then 'Highest Weight:'|| f.FRML_NAME else f.FRML_NAME end as PRICING_COMPONENT
  ,f.PREMIUM_PRICE                                                                       as PREMIUM_FLOAT_SPREAD
  ,c.BT_FACTOR_NUM                                                                       as INDEX_FACTOR
  ,CASE WHEN e.FINAL_PRCL_PRICE <>'0' THEN 'KNOWN'  ELSE 'UNKNOWN'  END                  as PRICING_STATUS
  ,CASE WHEN c.WET_OR_DRY_IND = 'D' THEN k.PAYMENT_DATE ELSE m.SETTLEMENT_MADE_D END     as PRICE_SETTLE_DATE
  ,c.PRCL_SEQ_NUM                                                                        as DEAL_SUB_LEG_REFERENCE
  ,CASE WHEN c.DEAL_CLASS_CODE ='OPT' THEN c.OPT_SETL_TYPE_CODE 
  WHEN c.WET_OR_DRY_IND = 'W' THEN 'PHYSICAL' ELSE 'FINANCIAL'  END                      as SETTLEMENT_TYPE
  ,'NA'                                                                                  as DEAL_LINE_TEXT
  ,c.OPT_CALL_PUT_IND                                                                    as CALL_PUT_FLAG
  ,c.OPT_STRIKE_PRICE                                                                    as OPTION_STRIKE_PRICE
  ,e.FIXED_PRICE                                                                         as OPTION_PREMIUM_PRICE
  ,i.CURRENT_NAME                                                                        as VESSEL_NAME
  ,o.LOCATION_CODE                                                                       as DELIVERY_JUNCTION_NAME
  ,i.TRANSPORT_TYP_CODE                                                                  as TRANSPORT_TYP_CODE
  ,C.BOL_DATE                                                                            as BILL_OF_LADING_DATE
  ,''                                                                   as SOURCE_LAST_DATE1
  ,b.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE2
  ,c.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE3
  ,d.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE4
  ,e.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE5
  ,f.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE6
  ,g.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE7
  ,h.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE8
  ,i.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE9
  ,k.LAST_UPDATE_TSTMP1                                                                   as SOURCE_LAST_DATE10
  ,k.LAST_UPDATE_TSTMP2                                                                   as SOURCE_LAST_DATE11
  ,l.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE12
  ,m.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE13
  ,n.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE14 
  ,o.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE15
  FROM        STO_CONTRACT a
  JOIN        STO_CDTYCTMT b
  ON          a.CONTRACT_NUM = b.CONTRACT_NUM 
  AND         a.CONTRACT_CREATE_D = b.CONTRACT_CREATE_D
  JOIN(
	SELECT	CONTRACT_NUM
		,CONTRACT_CREATE_D
		,OWNER_BUY_SELL_IND
	FROM	STO_CDTYCTMT
	WHERE	CTMT_SEQ_NUM = '01'
	) b2 
    ON a.CONTRACT_NUM = b2.CONTRACT_NUM 
    AND a.CONTRACT_CREATE_D = b2.CONTRACT_CREATE_D
    LEFT JOIN(
	SELECT	CONTRACT_NUM
		,CONTRACT_CREATE_D
		,OWNER_BUY_SELL_IND
	FROM	STO_CDTYCTMT
	WHERE	CTMT_SEQ_NUM = '03'
	) b3
    ON a.CONTRACT_NUM = b3.CONTRACT_NUM
    AND a.CONTRACT_CREATE_D = b3.CONTRACT_CREATE_D
  JOIN        STO_PARCEL c
  ON          b.CONTRACT_NUM = c.CONTRACT_NUM 
  AND         b.CTMT_SEQ_NUM = c.CDTY_CTMT_SEQ_NUM
  AND         b.CONTRACT_CREATE_D = c.CONTRACT_CREATE_D
  AND         c.VLDT_LEVEL <> 'V'
  LEFT JOIN   STO_CHRGACCT d 
  ON          a.OWNG_CHRG_ACCT_NUM = d.SEQUENCE_NUM 
  LEFT JOIN   STO_PRICING e
  ON          c.PRCG_SEQ_NUM  = e.SEQUENCE_NUM
  LEFT JOIN   (

  select  f1.* 
  ,row_number() OVER(PARTITION BY f1.prcg_seq_num
  ORDER BY f1.WEIGHTING_PC desc,SEQ_NUM asc) row_num
  from    STO_PRCGTERM f1 
  ) f
  ON          c.PRCG_SEQ_NUM = f.PRCG_SEQ_NUM
  AND         f.row_num = 1
  LEFT JOIN   (

  select  f2.* 
  ,row_number() OVER(PARTITION BY f2.prcg_seq_num
  ORDER BY f2.WEIGHTING_PC desc,SEQ_NUM asc) row_num
  from    STO_PRCGTERM f2 
  ) f3
  ON          c.PRCG_SEQ_NUM = f3.PRCG_SEQ_NUM
  AND         f3.row_num = 2
  LEFT JOIN   STO_PRCLOPRN g 
  ON          c.CONTRACT_NUM = g.CONTRACT_NUM
  AND         c.PRCL_SEQ_NUM = g.PRCL_SEQ_NUM
  LEFT JOIN   (select SEQUENCE_NUM,VESSEL_SEQ_NUM,LAST_UPDATE_TSTMP
  from(
  select
  SEQUENCE_NUM,VESSEL_SEQ_NUM,LAST_UPDATE_TSTMP, row_number()
  over(partition by SEQUENCE_NUM order by SEQUENCE_NUM) row_num
  from
  STO_VOYAGE
  ) where row_num = 1) h
  ON          g.VOYAGE_SEQ_NUM  = h.SEQUENCE_NUM
  LEFT JOIN	STO_VESSEL i
  ON	        h.VESSEL_SEQ_NUM = i.SEQUENCE_NUM
  LEFT JOIN   (
  SELECT  j1.CONTRACT_NUM 
  ,j1.PRCL_SEQ_NUM
  ,j1.CONTRACT_CREATE_D
  ,j2.PAYMENT_DATE
  ,j1.LAST_UPDATE_TSTMP LAST_UPDATE_TSTMP1
  ,j1.LAST_UPDATE_TSTMP LAST_UPDATE_TSTMP2
  ,row_number() OVER(PARTITION BY j1.CONTRACT_NUM, j1.PRCL_SEQ_NUM, j1.CONTRACT_CREATE_D
  ORDER BY j2.PAYMENT_DATE desc) row_num
  FROM    STO_BKOTPRCL j1
  JOIN STO_BKOTCHN j2 
  ON      j1.REF_MNEM = j2.REF_MNEM
  ) k
  ON          c.CONTRACT_NUM  = k.CONTRACT_NUM
  AND         c.PRCL_SEQ_NUM  = k.PRCL_SEQ_NUM
  AND         c.CONTRACT_CREATE_D = k.CONTRACT_CREATE_D
  AND         k.row_num = 1
  LEFT JOIN (
  select  y.* 
  ,row_number() OVER(PARTITION BY y.CONTRACT_NUM, y.PRCL_SEQ_NUM
  ORDER BY y.SETTLEMENT_SEQ_NUM desc) row_num
  from    STO_PRCLFCST y
  where   y.COST_TYPE_CODE = 'OIL' 
  and     y.COST_CODE='OIL' 
  ) l
  ON          a.CONTRACT_NUM = l.CONTRACT_NUM
  AND         c.PRCL_SEQ_NUM = l.PRCL_SEQ_NUM
  AND         l.row_num = 1
  LEFT JOIN   STO_SETTLMNT m
  ON          l.SETTLEMENT_SEQ_NUM = m.SEQUENCE_NUM
  LEFT JOIN  STO_PRCLDCH n 
  on          c.CONTRACT_NUM = n.CONTRACT_NUM
  AND         c.PRCL_SEQ_NUM = n.PRCL_SEQ_NUM 
  LEFT JOIN  STO_location o
  ON          n.LOC_SEQ_NUM = o.SEQUENCE_NUM
  JOIN      (
  SELECT  DISTINCT TRDG_COMP_MNEM 
  ,CONTRACT_NUM
  ,CONTRACT_CREATE_D
  FROM    STO_PARCEL
  WHERE PARCEL_DATE > '{0}'
  and PARCEL_DATE < '2019-05-01 00:00:00'
  ) j
  ON                        a.TRDG_COMP_MNEM = j.TRDG_COMP_MNEM
  AND                      a.CONTRACT_NUM = j.CONTRACT_NUM
  AND                      a.CONTRACT_CREATE_D = j.CONTRACT_CREATE_D
  WHERE 
  b.grade_code not in ('LPROP') AND  a.OWNG_CHRG_ACCT_NUM not In ('2304','2391','2390')
  """.format(last_watermark_parcel)
  
  return DEAL_ATTRIBUTE_READ_SQL
