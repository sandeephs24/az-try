# Databricks notebook source
# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../enricher/DealAttributeEnricher

# COMMAND ----------

class AligneDealAttributesReader(SourceDatasetReader):
    
  def read(spark,metricDict, INITIAL_LOAD):
        SOURCE_ETRM = 'ALIGNE'



        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'GV_TRADES', 'parquet', 'GV_TRADES')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'GV_TRADESAUX', 'parquet', 'GV_TRADESAUX')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'STATIC_CPTY', 'parquet', 'STATIC_CPTY')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'STATIC_UNITS', 'parquet', 'STATIC_UNITS')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'GV_TRADEFEES', 'parquet', 'GV_TRADEFEES')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'STATIC_VOL_IMB_PK_GL', 'parquet', 'STATIC_VOL_IMB_PK_GL')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'GV_RAWTPOW', 'parquet', 'GV_RAWTPOW')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'STATIC_USERS', 'parquet', 'STATIC_USERS')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'STATIC_HOUSE', 'parquet', 'STATIC_HOUSE')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'STATIC_VALUE', 'parquet', 'STATIC_VALUE')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'STATIC_MRKTC', 'parquet', 'STATIC_MRKTC')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'STATIC_BOOKS', 'parquet', 'STATIC_BOOKS')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'GV_PNL_MONTHLY', 'parquet', 'GV_PNL_MONTHLY')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'GV_PNL_MONTHLY_OPTS', 'parquet', 'GV_PNL_MONTHLY_OPTS')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'GV_PNL_DAILY', 'parquet', 'GV_PNL_DAILY')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'GV_PNL_DAILY_OPTS', 'parquet', 'GV_PNL_DAILY_OPTS') 
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, 'ALIGNE', 'STATIC_CONTRACTS', 'parquet', 'STATIC_CONTRACTS')    

      
        print("running sql DEAL_ATTRIBUTE_READ_SQL")

        if (INITIAL_LOAD == "Y") :
          DEAL_ATTRIBUTE_READ_SQL = getDealAttrReaderSQLDay0(spark , SOURCE_ETRM)
        else:
          DEAL_ATTRIBUTE_READ_SQL = getDealAttrReaderSQLDay1(spark , SOURCE_ETRM)


        df = spark.sql(DEAL_ATTRIBUTE_READ_SQL) 
        print("running sql DEAL_ATTRIBUTE_READ_SQL- count ", df.count())
        df.show(10,False)

        print ("Running enricher")
        #df = DealAttributeenrich(spark,df,SOURCE_ETRM)
        print ("Running enricher - DOne")
        #df.show(20,False)
        df.printSchema()
        return  (df,metricDict)
      

# COMMAND ----------

def getDealAttrReaderSQLDay1(spark , SOURCE_ETRM):
        
  last_watermark_gv_trade = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'GV_TRADES','DIM_DEAL_ATTRIBUTES')
  last_watermark_gv_trade = last_watermark_gv_trade[0:19]
  DEAL_ATTRIBUTE_READ_SQL = """
            SELECT  
            GT.ZKEY                                                    							AS SRC_SYS_DEAL_HEADER_KEY,
            GT.ZKEY||'_'||PDM.DMO1                                               						AS SRC_SYS_DEAL_LEG_KEY,
            GT.ZKEY||'_'||PDM.DMO1||'_'||PDM.START1                              					AS SRC_SYS_DEAL_SUB_LEG_KEY,
            GT.TRADE_TYPE                                                                       							AS SRC_SYSTEM_DEAL_TYPE_CODE,
            GT.TRADE_TYPE2_I                                                                    							AS SRC_SYSTEM_DEAL_SUBTYPE_CODE,
            DECODE(GT.BUYSELL, 'S', 'SELL', 'BUY')                                              						AS DEAL_HEADER_BUY_SELL_FLAG,
            CASE WHEN GT.TRADE_TYPE2_I LIKE '%SWAP' THEN 'SWAP' 
            WHEN GT.TRADE_TYPE2_I LIKE '%FUTURE' OR GT.TRADE_TYPE2_I= 'BASIS FINANCIAL SHAP' THEN 'FUTURE' 
            WHEN GT.TRADE_TYPE2_I LIKE '%OPTION' OR GT.TRADE_TYPE2_I= 'SWAPTION' THEN 'OPTION' 
            WHEN GT.TRADE_TYPE2_I LIKE '%FORWARD' THEN 'FORWARD' 
            WHEN GT.TRADE_TYPE2_I LIKE '%PHYSICAL' OR GT.TRADE_TYPE2_I LIKE '%SHAPE' OR GT.TRADE_TYPE2_I IN ('GAS TRANSPORT','TRANSMISSION' )THEN 'FORWARD' 
            ELSE 'NOT MAPPED' END                                                               						AS  DEAL_INSTRUMENT_CLASSIFICATION,
            'NULL'							                                                    		AS DEAL_SPOT_TERM_IND,
            SC.CONTRACT_DSC                                                                     							AS DEAL_AGREMENT_TYPE_DESCRIPTION,
            CASE WHEN GT.VOID_FLAG = 'N' THEN'ACTIVE' WHEN GT.VOID_FLAG = 'Y'THEN 'CANCELLED' ELSE 'UKNOWNN STATUS' END 		AS HEADER_DEAL_STATUS,
            GT.CONTRACT_CODE 									AS PARENT_CONTRACT_NUMBER,
            GT.CONTRACT_CODE									AS CONTRACT_NUMBER,
            B.BOOK_DSC                     					                                    			AS DEAL_BOOK_NAME,  --ADDED A PARTTION TO REMOVE DUPLICATES--
            PDM.DMO1	                                                                       						AS DEAL_LEG_REFERENCE,
            DECODE(GT.BUYSELL, 'S', 'SELL', 'BUY')                                              						AS DEAL_LEG_BUY_SELL_FLAG,
            CASE WHEN GT.VOID_FLAG = 'N' THEN'ACTIVE' WHEN GT.VOID_FLAG = 'Y'THEN 'CANCELLED' ELSE 'UKNOWNN STATUS' END 		AS SUB_LEG_DEAL_STATUS,
             GTA.REG_EXEC_TIMESTAMP                                                              AS DEAL_EXECUTION_TIMESTAMP,
            PDM.PRICE1_IC               									AS DEAL_PRICE,
            GT.MARKET2    									AS PRICING_TYPE,
            GT.COMPONENT2									AS PRICING_COMPONENT,
            PDM.FLOAT_MULT  									AS PREMIUM_FLOAT_SPREAD,
            GT.FORMULA_SYNTAX									AS INDEX_FACTOR,
            'NULL' 										AS PRICING_STATUS,
            PDM.END1 AS PRICE_SETTLE_DATE,
            --from_unixtime(unix_timestamp(PDM.END1,'ddMMMyy'),'dd-MM-yyyy')                      					AS PRICE_SETTLE_DATE,
            PDM.DMO1||'_'||PDM.START1           								AS DEAL_SUB_LEG_REFERENCE,
            DECODE(GT.PHYS_FIN, 'P', 'PHYSICAL', 'FINANCIAL')        							AS SETTLEMENT_TYPE,
            GT.MEMOLINE1  									AS DEAL_LINE_TEXT,
            CASE WHEN GT.IS_OPTION = 'Y' THEN GT.PUT_CALL ELSE NULL END 		                				AS CALL_PUT_FLAG,
            PDMO.STRIKE_IC    									AS OPTION_STRIKE_PRICE,
            PDMO.OPT_PREM_IC  									AS OPTION_PREMIUM_PRICE
                       
            FROM GV_TRADES GT
            LEFT JOIN
            (
            SELECT BOOK_DSC,BOOK_BOOK 
            FROM
            (SELECT BOOK_DSC,BOOK_BOOK,row_number() over (Partition by BOOK_BOOK ORDER BY BOOK_ALF DESC) row_num 
            FROM STATIC_BOOKS B
            ) WHERE row_num=1 
            )B
            ON B.BOOK_BOOK = GT.BOOK 
           
            LEFT JOIN GV_TRADESAUX GTA
            ON GTA.TNUM = GT.TNUM
           
             LEFT JOIN 
            (SELECT CONTRACT_CPTY,CONTRACT_MANUM,CONTRACT_HOUSE,CONTRACT_DSC 
            FROM
            (SELECT CONTRACT_CPTY,CONTRACT_MANUM,CONTRACT_HOUSE,CONTRACT_DSC,row_number() over (Partition by CONTRACT_CPTY,CONTRACT_MANUM,CONTRACT_HOUSE  ORDER BY AUDIT_ADATE0 DESC)   row_num 
            FROM STATIC_CONTRACTS SC
            )WHERE row_num=1
            )SC
            ON SC.CONTRACT_CPTY = GT.CPTY AND SC.CONTRACT_MANUM = GT.MANUM AND SC.CONTRACT_HOUSE = GT.HOUSE_ID 
            
            LEFT JOIN 
            ( select * FROM 
            (select distinct PM.ZKEY,PM.TNUM,PM.START1,PM.END1,PM.PRICE1_IC,PM.QTY1,PM.SIDE,PM.DMO1,PM.FLOAT_MULT,row_number() over (Partition by PM.ZKEY,PM.TNUM,PM.START1,PM.END1 ORDER                   BY ASOF_DATE DESC) row_num
            from GV_PNL_MONTHLY PM
            UNION
            select distinct  PD.ZKEY,PD.TNUM,PD.START1,PD.END1,PD.PRICE1_IC,PD.QTY1,PD.SIDE,PD.DMO1,PD.FLOAT_MULT,row_number() over (Partition by PD.ZKEY,PD.TNUM,PD.START1,PD.END1 ORDER                   BY ASOF_DATE DESC) row_num
            from GV_PNL_DAILY PD
            )WHERE row_num=1) PDM
            ON PDM.ZKEY = GT.ZKEY AND PDM.TNUM = GT.TNUM 
            
           LEFT JOIN 
          (select * from 
          (select distinct PMO.ZKEY,PMO.TNUM,PMO.STRIKE_IC,PMO.OPT_PREM_IC,row_number() over (Partition by PMO.ZKEY,PMO.TNUM ORDER BY ASOF_DATE DESC) row_num
           FROM GV_PNL_MONTHLY_OPTS PMO
          -- UNION
         --  select distinct  PDO.ZKEY,PDO.TNUM,PDO.STRIKE_IC,PDO.OPT_PREM_IC,row_number() over (Partition by PDO.ZKEY,PDO.TNUM ORDER BY ASOF_DATE DESC) row_num
          -- from GV_PNL_DAILY_OPTS PDO
           ) WHERE row_num=1) PDMO                  
          ON PDMO.ZKEY = GT.ZKEY AND PDMO.TNUM = GT.TNUM 
          WHERE GT.VOID_FLAG='N'
          and PDM.DMO1 is not null and PDM.START1  is not null
          and GT.TRADE_DATE > {0}
  """.format(last_watermark_gv_trade)
  
  return DEAL_ATTRIBUTE_READ_SQL

# COMMAND ----------

def getDealAttrReaderSQLDay0(spark , SOURCE_ETRM):
  
  spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
  
  last_watermark_gv_trade = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'GV_TRADES','DIM_DEAL_ATTRIBUTES')
  last_watermark_gv_trade = last_watermark_gv_trade[0:19]

  
  DEAL_ATTRIBUTE_READ_SQL = """
          SELECT    
            GT.ZKEY                                                                             AS SRC_SYS_DEAL_HEADER_KEY,
            GT.ZKEY||'_'||PDM.DMO1                                                              AS SRC_SYS_DEAL_LEG_KEY,
            GT.ZKEY||'_'||PDM.DMO1||'_'||PDM.START1                                             AS SRC_SYS_DEAL_SUB_LEG_KEY,
            GT.TRADE_TYPE                                                                       AS SRC_SYSTEM_DEAL_TYPE_CODE,
            GT.TRADE_TYPE2_I                                                                    AS SRC_SYSTEM_DEAL_SUBTYPE_CODE,
            DECODE(GT.BUYSELL, 'S', 'SELL', 'BUY')                                              AS DEAL_HEADER_BUY_SELL_FLAG,
            CASE WHEN GT.TRADE_TYPE2_I LIKE '%SWAP' THEN 'SWAP' 
            WHEN GT.TRADE_TYPE2_I LIKE '%FUTURE' OR GT.TRADE_TYPE2_I= 'BASIS FINANCIAL SHAP' THEN 'FUTURE' 
            WHEN GT.TRADE_TYPE2_I LIKE '%OPTION' OR GT.TRADE_TYPE2_I= 'SWAPTION' THEN 'OPTION' 
            WHEN GT.TRADE_TYPE2_I LIKE '%FORWARD' THEN 'FORWARD' 
            WHEN GT.TRADE_TYPE2_I LIKE '%PHYSICAL' OR GT.TRADE_TYPE2_I LIKE '%SHAPE' OR GT.TRADE_TYPE2_I IN ('GAS TRANSPORT','TRANSMISSION' )THEN 'FORWARD' 
            ELSE 'NOT MAPPED' END                                                               AS  DEAL_INSTRUMENT_CLASSIFICATION,
            'NULL'							                                                    AS DEAL_SPOT_TERM_IND,
            SC.CONTRACT_DSC                                                                     AS DEAL_AGREEMENT_TYPE_DESCRIPTION,
            CASE WHEN GT.VOID_FLAG = 'N' THEN'ACTIVE' WHEN GT.VOID_FLAG = 'Y'THEN 'CANCELLED' ELSE 'UKNOWNN STATUS' END AS HEADER_DEAL_STATUS,
            GT.CONTRACT_CODE 										                            AS PARENT_CONTRACT_NUMBER,
            GT.CONTRACT_CODE													                AS CONTRACT_NUMBER,
            B.BOOK_DSC                     					                                    AS DEAL_BOOK_NAME,  --ADDED A PARTTION TO REMOVE DUPLICATES--
            PDM.DMO1	                                                                        AS DEAL_LEG_REFERENCE,
            DECODE(GT.BUYSELL, 'S', 'SELL', 'BUY')                                              AS DEAL_LEG_BUY_SELL_FLAG,
            CASE WHEN GT.VOID_FLAG = 'N' THEN'ACTIVE' WHEN GT.VOID_FLAG = 'Y'THEN 'CANCELLED' ELSE 'UKNOWNN STATUS' END AS SUB_LEG_DEAL_STATUS,
            coalesce(from_unixtime(unix_timestamp(GTA.REG_EXEC_TIMESTAMP,'dd/MM/yyyy HH:mm:ss'),'yyyy-MM-dd HH:mm:ss'),
from_unixtime(unix_timestamp(GTA.REG_EXEC_TIMESTAMP,'dd/MM/yyyy HH:mm'),'yyyy-MM-dd HH:mm:ss'),GTA.REG_EXEC_TIMESTAMP)   AS DEAL_EXECUTION_TIMESTAMP,
            PDM.PRICE1_IC               													    AS DEAL_PRICE,
            GT.MARKET2    											                            AS PRICING_TYPE,
            GT.COMPONENT2													                    AS PRICING_COMPONENT,
            PDM.FLOAT_MULT  														            AS PREMIUM_FLOAT_SPREAD,
            GT.FORMULA_SYNTAX													                AS INDEX_FACTOR,
            'NULL' 														                        AS PRICING_STATUS,
            PDM.END1                                                                            AS PRICE_SETTLE_DATE,
            PDM.DMO1||'_'||PDM.START1           											    AS DEAL_SUB_LEG_REFERENCE,
            DECODE(GT.PHYS_FIN, 'P', 'PHYSICAL', 'FINANCIAL')        							AS SETTLEMENT_TYPE,
            GT.MEMOLINE1  													                    AS DEAL_LINE_TEXT,
            CASE WHEN GT.IS_OPTION = 'Y' THEN GT.PUT_CALL ELSE NULL END 		                AS CALL_PUT_FLAG,
            PDMO.STRIKE_IC    													                AS OPTION_STRIKE_PRICE,
            PDMO.OPT_PREM_IC  													                AS OPTION_PREMIUM_PRICE,
            'N/A'                                                                               as VESSEL_NAME,
            'N/A'                                                                               as DELIVERY_JUNCTION_NAME,
            'N/A'                                                                               as  DELIVERY_METHOD_NAME,
            'N/A'                                                                               as BILL_OF_LADING_DATE,
            GT.TRADE_DATE                                                                       AS SOURCE_LAST_DATE1
                              
            FROM GV_TRADES GT
            LEFT JOIN
            (
            SELECT BOOK_DSC,BOOK_BOOK 
            FROM
            (SELECT BOOK_DSC,BOOK_BOOK,row_number() over (Partition by BOOK_BOOK ORDER BY BOOK_ALF DESC) row_num 
            FROM STATIC_BOOKS B
            ) WHERE row_num=1 
            )B
            ON B.BOOK_BOOK = GT.BOOK 
           
            LEFT JOIN GV_TRADESAUX GTA
            ON GTA.TNUM = GT.TNUM
            LEFT JOIN 
            (SELECT CONTRACT_CPTY,CONTRACT_MANUM,CONTRACT_HOUSE,CONTRACT_DSC 
            FROM
            (SELECT CONTRACT_CPTY,CONTRACT_MANUM,CONTRACT_HOUSE,CONTRACT_DSC,row_number() over (Partition by CONTRACT_CPTY,CONTRACT_MANUM,CONTRACT_HOUSE  ORDER BY AUDIT_ADATE0 DESC) row_num 
            FROM STATIC_CONTRACTS SC
            )WHERE row_num=1
            )SC
            ON SC.CONTRACT_CPTY = GT.CPTY AND SC.CONTRACT_MANUM = GT.MANUM AND SC.CONTRACT_HOUSE = GT.HOUSE_ID 
            LEFT JOIN 
           ( select * FROM 
            (select distinct PM.ZKEY,PM.TNUM,PM.START1,PM.END1,PM.PRICE1_IC,PM.QTY1,PM.SIDE,PM.DMO1,PM.FLOAT_MULT,row_number() over (Partition by PM.ZKEY,PM.TNUM,PM.START1,PM.END1 ORDER                   BY ASOF_DATE DESC) row_num
            from GV_PNL_MONTHLY PM
            UNION
            select distinct  PD.ZKEY,PD.TNUM,PD.START1,PD.END1,PD.PRICE1_IC,PD.QTY1,PD.SIDE,PD.DMO1,PD.FLOAT_MULT,row_number() over (Partition by PD.ZKEY,PD.TNUM,PD.START1,PD.END1 ORDER                   BY ASOF_DATE DESC) row_num
            from GV_PNL_DAILY PD
            )WHERE row_num=1) PDM
            ON PDM.ZKEY = GT.ZKEY AND PDM.TNUM = GT.TNUM 
            
           LEFT JOIN 
          (select * from 
          (select distinct PMO.ZKEY,PMO.TNUM,PMO.STRIKE_IC,PMO.OPT_PREM_IC,row_number() over (Partition by PMO.ZKEY,PMO.TNUM ORDER BY ASOF_DATE DESC) row_num
           FROM GV_PNL_MONTHLY_OPTS PMO
          -- UNION
         --  select distinct  PDO.ZKEY,PDO.TNUM,PDO.STRIKE_IC,PDO.OPT_PREM_IC,row_number() over (Partition by PDO.ZKEY,PDO.TNUM ORDER BY ASOF_DATE DESC) row_num
          -- from GV_PNL_DAILY_OPTS PDO
           ) WHERE row_num=1) PDMO
           ON PDMO.ZKEY = GT.ZKEY AND PDMO.TNUM = GT.TNUM 
               
            WHERE GT.VOID_FLAG='N'
            and GT.TRADE_DATE > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss') 
      """.format(last_watermark_gv_trade)
  
  return DEAL_ATTRIBUTE_READ_SQL
