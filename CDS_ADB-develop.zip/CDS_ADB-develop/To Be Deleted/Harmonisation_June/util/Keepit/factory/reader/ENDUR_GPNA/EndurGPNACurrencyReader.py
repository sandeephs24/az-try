# Databricks notebook source
# MAGIC %run ./../../enricher/CurrencyMappingEnricher

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class EndurGPNACurrencyReader(SourceDatasetReader):
    
    def read(spark,metricDict):
        SOURCE_ETRM = 'ENDUR_GPNA'
      
        CURRENCY_READER_SQL = """
        select 
        c.id_number as SRC_SYS_CURRENCY_NK,
        c.name as CURRENCY_CODE
        from CURRENCY c 
        """
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'CURRENCY', format, 'CURRENCY')
     
        df = spark.sql(CURRENCY_READER_SQL)
        df = enrich(spark,df, SOURCE_ETRM)
        return (df,metricDict)
