# Databricks notebook source
# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../enricher/LocationMappingEnricher

# COMMAND ----------

class NucleusLocationReader(SourceDatasetReader):
    
  def read(spark,metricDict):
      SOURCE_ETRM = 'NUCLEUS'
      
      last_watermark_location=getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'CUSTODY_TRANSFER_POINTS','DIM_LOCATION')
      last_watermark_location = last_watermark_location[0:19]
      
      print(last_watermark_location)
      
      df = executeJdbcQueryAndReturnDF("select SRC_SYS_LOCATION_NK from tsa_curated.dim_location where src_sys_name = '{0}'".format(SOURCE_ETRM))
      df.createOrReplaceTempView("CURATED_DIM_LOCATION")
      
      print(df.count())
      
      LOCATION_READ_SQL = """
      SELECT CTP.POINT_CODE AS SRC_SYS_LOCATION_NK,
        CTP.POINT_NAME AS LOCATION_NAME,
        CTP.MOD_MODULE    as LOCATION_TYPE,
        CTP.STE_TO_STATE_CODE AS LOCATION_AREA,
        CTP.MODIFY_DATE as SOURCE_LAST_UPDATE
      FROM CUSTODY_TRANSFER_POINTS CTP JOIN COUNTRIES C ON CTP.COU_TO_COUNTRY_CODE = C.COUNTRY_CODE
      WHERE EXISTS(SELECT DMD.CTP_POINT_CODE FROM DEAL_MONTH_DETAILS DMD WHERE DMD.CTP_POINT_CODE = CTP.POINT_CODE)
       AND
      (
      CTP.MODIFY_DATE > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
      or
      CTP.POINT_CODE in (select SRC_SYS_LOCATION_NK from CURATED_DIM_LOCATION)
      )      
      """.format(last_watermark_location)     
      
      format = "delta"
      readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'CUSTODY_TRANSFER_POINTS', format, 'CUSTODY_TRANSFER_POINTS')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'COUNTRIES',format, 'COUNTRIES')
      readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'DEAL_MONTH_DETAILS', format, 'DEAL_MONTH_DETAILS')

                 
      df = spark.sql(LOCATION_READ_SQL)
      
      print(df.count())
      #df=df.withColumn("SOURCE_LAST_UPDATE", date_trunc("minute", col("SOURCE_LAST_UPDATE")))
      df = enrichLocationForMapping(spark,df,SOURCE_ETRM)
      
      return  (df,metricDict)
