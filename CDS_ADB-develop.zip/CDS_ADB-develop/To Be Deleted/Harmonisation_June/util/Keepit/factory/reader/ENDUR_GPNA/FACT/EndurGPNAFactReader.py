# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ../../DatasetReader

# COMMAND ----------

# MAGIC %run ./EndurGPNAFactHeaderReader

# COMMAND ----------

# MAGIC %run ./EndurGPNAFactLegReader

# COMMAND ----------

# MAGIC %run ./EndurGPNAFactSubLegReader

# COMMAND ----------

class EndurGPNAFactReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD_ENDUR_GPNA):
        
    (dfHeader, metricDict) = EndurGPNAFactHeaderReader.read(spark,SOURCE_ETRM, metricDict, INITIAL_LOAD_ENDUR_GPNA)
    (dfLeg, metricDict) = EndurGPNAFactLegReader.read(spark,SOURCE_ETRM, metricDict, INITIAL_LOAD_ENDUR_GPNA)
    (dfSubLeg, metricDict) = EndurGPNAFactSubLegReader.read(spark,SOURCE_ETRM, metricDict, INITIAL_LOAD_ENDUR_GPNA)

    return (dfHeader,dfLeg,dfSubLeg, metricDict)
