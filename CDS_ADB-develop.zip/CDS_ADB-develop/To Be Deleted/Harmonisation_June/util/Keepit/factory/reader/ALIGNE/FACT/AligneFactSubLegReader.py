# Databricks notebook source


# COMMAND ----------

# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

class AligneFactSubLegReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
    
    (dfSubLeg, metricDict) = readFactSubLeg(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD)

    return (dfSubLeg, metricDict)

# COMMAND ----------

def readFactSubLeg(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
   
  from pyspark.sql.functions import concat
  from datetime import datetime
  current_date_yyyymmdd = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
  print(current_date_yyyymmdd) 

  last_watermark_fact_gv_trade = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'GV_TRADES','TRADE_DATE','FACT_DEAL_SUB_LEG')
  last_watermark_fact_gv_trade = last_watermark_fact_gv_trade[0:19]


  last_watermark_fact_gv_input = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'GV_TRADES','INPUT_DATE','FACT_DEAL_SUB_LEG')
  last_watermark_fact_gv_input = last_watermark_fact_gv_input[0:19]
  
  if INITIAL_LOAD == "Y" :
    SQL = getSublegReaderSQLDay0(last_watermark_fact_gv_trade)
  else:
    SQL = getSublegReaderSQLDay1(last_watermark_fact_gv_trade,current_date_yyyymmdd,last_watermark_fact_gv_input)
  
  
  format = "delta"
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_TRADES', 'parquet', 'GV_TRADES')
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_TRADESAUX', 'parquet', 'GV_TRADESAUX')
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_CPTY', 'parquet', 'STATIC_CPTY')
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_UNITS', 'parquet', 'STATIC_UNITS')
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_TRADEFEES', 'parquet', 'GV_TRADEFEES')
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_VOL_IMB_PK_GL', 'parquet', 'STATIC_VOL_IMB_PK_GL')
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_RAWTPOW', 'parquet', 'GV_RAWTPOW')
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_USERS', 'parquet', 'STATIC_USERS')
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_HOUSE', 'parquet', 'STATIC_HOUSE')
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_VALUE', 'parquet', 'STATIC_VALUE')
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_MRKTC', 'parquet', 'STATIC_MRKTC')
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_BOOKS', 'parquet', 'STATIC_BOOKS')
  readDatasetConfigAndCreateTempView(spark, SOURCE_ETRM, 'GV_PNL_MONTHLY', 'parquet', 'GV_PNL_MONTHLY')
  readDatasetConfigAndCreateTempView(spark, SOURCE_ETRM, 'GV_PNL_MONTHLY_OPTS', 'parquet', 'GV_PNL_MONTHLY_OPTS')
  readDatasetConfigAndCreateTempView(spark, SOURCE_ETRM, 'GV_PNL_DAILY', 'parquet', 'GV_PNL_DAILY')
  readDatasetConfigAndCreateTempView(spark, SOURCE_ETRM, 'GV_PNL_DAILY_OPTS', 'parquet', 'GV_PNL_DAILY_OPTS') 
  readDatasetConfigAndCreateTempView(spark, SOURCE_ETRM, 'STATIC_CONTRACTS', 'parquet', 'STATIC_CONTRACTS')    


  dfSubLeg = spark.sql(SQL)
  
  #dfSubLeg.show(10,truncate=False)
  
  #print("DexFactSubLegReader" , dfSubLeg.count())

  
  return (dfSubLeg, metricDict)

# COMMAND ----------

def getSublegReaderSQLDay1(last_watermark_fact_gv_trade,current_date_yyyymmdd,last_watermark_fact_gv_input):
  SQL = """
   SELECT  
           
           GT.ZKEY||'_'||PDM.DMO1||'_'||PDM.START1   			        AS DEAL_ATTRIBUTES_NK,
           GT.TRADE_DATE                                             					AS EXECUTION_DATE,
           GT.TRADE_DATE                                            					AS TRADE_CREATION_DATE,
           PDM.START1                                             					AS COMMITMENT_DATE,
           PDM.START1 						                                            AS PARCEL_DATE,
           GT.CPTY							                                            AS COUNTERPARTY_NK,
           GT.HOUSE_ID		                                        			        AS SHELL_TRADING_PARTY_NK,
           GT.TRADER						                                            AS TRADER_NK,
           CASE WHEN GT.CPTY_BROKER='DIRECT' THEN NULL
                 ELSE GT.CPTY_BROKER
                 END							                                        AS DEAL_BROKER_NK,
           GT.CDY1_RISKDESC               					                            AS COMMODITY_NK,
           'INVALID'						                                                    AS LOADING_LOCATION_NK,
           GT.MARKET1||GT.COMPONENT1                                 				    AS DISCHARGE_LOCATION_NK,
           PDM.START1         						                                    AS DELIVERY_START_DATE,
           PDM.END1  						                                            AS DELIVERY_END_DATE,
           GT.AMT_UNIT                                               					AS DEAL_UNIT_OF_MEASURE_NK,
           'TBD'           						                                        AS PRICING_UNIT_OF_MEASURE_NK,
           GT.TRADE_CCY						                                            AS DEAL_CCY_NK,
           ABS(PDM.VALUE2_IC)                               				    AS CCY_DEAL_VALUE,
           ABS(PDM.QTY1)                                             					AS DEAL_QTY,
           'TBD'           						                                        AS PRICE_QTY,
           CASE WHEN (PDM.QTY1)<0 THEN '-1' ELSE '1' END            			        AS DEAL_SUB_LEG_MULTIPLIER,
           GT.ZKEY                                                   					AS SRC_SYS_DEAL_HEADER_KEY,
            GT.trade_date source_last_date1,
   GT.INPUT_DATE as source_last_date2,
    ''  as source_last_date3
           FROM GV_TRADES GT
           LEFT JOIN 
           ( select * FROM
            (select distinct PM.ZKEY,PM.TNUM,PM.START1,PM.END1,PM.VALUE2_IC,PM.QTY1,PM.SIDE,PM.DMO1,PM.FLOAT_MULT,row_number() over (Partition by PM.ZKEY,PM.TNUM,PM.START1,PM.DMO1 ORDER BY ASOF_DATE DESC) row_num
            from GV_PNL_MONTHLY PM
            UNION
            select distinct PD.ZKEY,PD.TNUM,PD.START1,PD.END1,PD.VALUE2_IC,PD.QTY1,PD.SIDE,PD.DMO1,PD.FLOAT_MULT,row_number() over (Partition by PD.ZKEY,PD.TNUM,PD.START1,PD.DMO1  ORDER BY ASOF_DATE DESC) row_num
            from GV_PNL_DAILY PD
            )WHERE row_num=1)PDM
            ON PDM.ZKEY = GT.ZKEY AND PDM.TNUM = GT.TNUM
            WHERE GT.VOID_FLAG='N'
           and GT.AMT_UNIT not in ('CASH')
            and (
            (GT.TRADE_DATE > '{0}')
            or
            (GT.trade_date <= '{1}' and GT.input_date > '{2}')
            or
            (GT.input_date > '{3}'))
  """.format(last_watermark_fact_gv_trade,current_date_yyyymmdd,last_watermark_fact_gv_input,last_watermark_fact_gv_input)
  
  return SQL
  

# COMMAND ----------

def getSublegReaderSQLDay0(last_watermark_fact_gv_trade):
  SQL = """
   SELECT  
           
           GT.ZKEY||'_'||PDM.DMO1||'_'||PDM.START1   			        AS DEAL_ATTRIBUTES_NK,
           GT.TRADE_DATE                                             					AS EXECUTION_DATE,
           GT.TRADE_DATE                                            					AS TRADE_CREATION_DATE,
           PDM.START1                                             					AS COMMITMENT_DATE,
           PDM.START1 						                                            AS PARCEL_DATE,
           GT.CPTY							                                            AS COUNTERPARTY_NK,
           GT.HOUSE_ID		                                        			        AS SHELL_TRADING_PARTY_NK,
           GT.TRADER						                                            AS TRADER_NK,
           CASE WHEN GT.CPTY_BROKER='DIRECT' THEN NULL
                 ELSE GT.CPTY_BROKER
                 END							                                        AS DEAL_BROKER_NK,
           GT.CDY1_RISKDESC               					                            AS COMMODITY_NK,
           'INVALID'						                                                    AS LOADING_LOCATION_NK,
           GT.MARKET1||GT.COMPONENT1                                 				    AS DISCHARGE_LOCATION_NK,
           PDM.START1         						                                    AS DELIVERY_START_DATE,
           PDM.END1  						                                            AS DELIVERY_END_DATE,
           GT.AMT_UNIT                                               					AS DEAL_UNIT_OF_MEASURE_NK,
           'TBD'           						                                        AS PRICING_UNIT_OF_MEASURE_NK,
           GT.TRADE_CCY						                                            AS DEAL_CCY_NK,
           ABS(PDM.VALUE2_IC)                               				    AS CCY_DEAL_VALUE,
           ABS(PDM.QTY1)                                             					AS DEAL_QTY,
           'TBD'           						                                        AS PRICE_QTY,
           CASE WHEN (PDM.QTY1)<0 THEN '-1' ELSE '1' END            			        AS DEAL_SUB_LEG_MULTIPLIER,
           GT.ZKEY                                                   					AS SRC_SYS_DEAL_HEADER_KEY,
            GT.trade_date source_last_date1,
   GT.INPUT_DATE as source_last_date2,
    ''  as source_last_date3
           FROM GV_TRADES GT
           LEFT JOIN 
           ( select * FROM
            (select distinct PM.ZKEY,PM.TNUM,PM.START1,PM.END1,PM.VALUE2_IC,PM.QTY1,PM.SIDE,PM.DMO1,PM.FLOAT_MULT,row_number() over (Partition by PM.ZKEY,PM.TNUM,PM.START1,PM.DMO1 ORDER BY ASOF_DATE DESC) row_num
            from GV_PNL_MONTHLY PM
            UNION
            select distinct PD.ZKEY,PD.TNUM,PD.START1,PD.END1,PD.VALUE2_IC,PD.QTY1,PD.SIDE,PD.DMO1,PD.FLOAT_MULT,row_number() over (Partition by PD.ZKEY,PD.TNUM,PD.START1,PD.DMO1 ORDER BY ASOF_DATE DESC) row_num
            from GV_PNL_DAILY PD
            )WHERE row_num=1)PDM
            ON PDM.ZKEY = GT.ZKEY AND PDM.TNUM = GT.TNUM
            WHERE GT.VOID_FLAG='N'
            and GT.AMT_UNIT not in ('CASH')
           and GT.TRADE_DATE >to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')

           
  """.format(last_watermark_fact_gv_trade)
  
  return SQL
  
