# Databricks notebook source
# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../enricher/UOMMappingEnricher

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class AligneUnitOfMeasureReader(SourceDatasetReader):
    
    def read(spark,metricDict):
        SOURCE_ETRM = 'ALIGNE'
        
        UOM_READER_SQL = """
        SELECT DISTINCT a.AMT_UNIT as SRC_SYS_UNIT_OF_MEASURE_NK FROM GV_TRADES a WHERE a.VOID_FLAG='N'
          UNION
        SELECT SUBSTRING(b.UNIT_DSC,0,10) as SRC_SYS_UNIT_OF_MEASURE_NK FROM STATIC_UNITS b
        WHERE SUBSTRING(b.UNIT_DSC,0,10) NOT IN (SELECT DISTINCT AMT_UNIT FROM GV_TRADES a)
        """
        
        format = "parquet"
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_UNITS', format, 'STATIC_UNITS')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_TRADES', format, 'GV_TRADES')
        df = spark.sql(UOM_READER_SQL)
        df = enrichUOMForMapping(spark,df, SOURCE_ETRM)
        
        
        return  (df,metricDict)
