# Databricks notebook source
# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../enricher/DealAttributeEnricher

# COMMAND ----------

class AligneDealAttributesReader(SourceDatasetReader):
    
   def read(spark,metricDict, initial_load):
      
      SOURCE_ETRM = 'ALIGNE'
      
      last_watermark_gv_trades = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'GV_TRADES','DIM_DEAL_ATTRIBUTES')
      last_watermark_gv_trades = last_watermark_gv_trades[0:19]
      
      if initial_load == "Y":
        date_attribute = "from_unixtime(unix_timestamp(GT.TRADE_DATE,'ddMMMyy'),'dd-MM-yyyy')||' '||date_format(GT.TRADE_DATE,'HH:mm:ss')"
      else:
        date_attribute = "last_update"
      
      SQL = """
    SELECT  
            GT.ZKEY                                                    							AS SRC_SYS_DEAL_HEADER_KEY,
            'ALIGNE'||'_'||GT.ZKEY||'_'||PDM.DMO1                                               						AS SRC_SYS_DEAL_LEG_KEY,
            'ALIGNE'||'_'||GT.ZKEY||'_'||PDM.DMO1||'_'||PDM.START1                              					AS SRC_SYS_DEAL_SUB_LEG_KEY,
            GT.TRADE_TYPE                                                                       							AS SRC_SYSTEM_DEAL_TYPE_CODE,
            GT.TRADE_TYPE2_I                                                                    							AS SRC_SYSTEM_DEAL_SUBTYPE_CODE,
            DECODE(GT.BUYSELL, 'S', 'SELL', 'BUY')                                              						AS DEAL_HEADER_BUY_SELL_FLAG,
            CASE WHEN GT.TRADE_TYPE2_I LIKE '%SWAP' THEN 'SWAP' 
            WHEN GT.TRADE_TYPE2_I LIKE '%FUTURE' OR GT.TRADE_TYPE2_I= 'BASIS FINANCIAL SHAP' THEN 'FUTURE' 
            WHEN GT.TRADE_TYPE2_I LIKE '%OPTION' OR GT.TRADE_TYPE2_I= 'SWAPTION' THEN 'OPTION' 
            WHEN GT.TRADE_TYPE2_I LIKE '%FORWARD' THEN 'FORWARD' 
            WHEN GT.TRADE_TYPE2_I LIKE '%PHYSICAL' OR GT.TRADE_TYPE2_I LIKE '%SHAPE' OR GT.TRADE_TYPE2_I IN ('GAS TRANSPORT','TRANSMISSION' )THEN 'FORWARD' 
            ELSE 'NOT MAPPED' END                                                               						AS  DEAL_INSTRUMENT_CLASSIFICATION,
            'NULL'							                                                    		AS DEAL_SPOT_TERM_IND,
            SC.CONTRACT_DSC                                                                     							AS DEAL_AGREMENT_TYPE_DESCRIPTION,
            CASE WHEN GT.VOID_FLAG = 'N' THEN'ACTIVE' WHEN GT.VOID_FLAG = 'Y'THEN 'CANCELLED' ELSE 'UKNOWNN STATUS' END 		AS HEADER_DEAL_STATUS,
            GT.CONTRACT_CODE 									AS PARENT_CONTRACT_NUMBER,
            GT.CONTRACT_CODE									AS CONTRACT_NUMBER,
            B.BOOK_DSC                     					                                    			AS DEAL_BOOK_NAME,  --ADDED A PARTTION TO REMOVE DUPLICATES--
            PDM.DMO1	                                                                       						AS DEAL_LEG_REFERENCE,
            DECODE(GT.BUYSELL, 'S', 'SELL', 'BUY')                                              						AS DEAL_LEG_BUY_SELL_FLAG,
            CASE WHEN GT.VOID_FLAG = 'N' THEN'ACTIVE' WHEN GT.VOID_FLAG = 'Y'THEN 'CANCELLED' ELSE 'UKNOWNN STATUS' END 		AS SUB_LEG_DEAL_STATUS,
            GTA.REG_EXEC_TIMESTAMP                                                              						AS REG_EXEC_TIMESTAMP,
            --case 
              --when GTA.REG_EXEC_TIMESTAMP is null then from_unixtime(unix_timestamp(GT.INPUT_DATE,'ddMMMyy'),'dd-MM-yyyy')||' '||date_format(GT.INPUT_TIME,'HH:mm:ss')
              --when GTA.REG_EXEC_TIMESTAMP is not null then from_unixtime(unix_timestamp(GTA.REG_EXEC_TIMESTAMP,'dd/MM/yyyy HH:mm:ss'),'dd-MM-yyyy HH:mm:ss') 
            --end 										DEAL_EXECUTION_TIMESTAMP,
            PDM.PRICE1_IC               									AS DEAL_PRICE,
            GT.MARKET2    									AS PRICING_TYPE,
            GT.COMPONENT2									AS PRICING_COMPONENT,
            PDM.FLOAT_MULT  									AS PREMIUM_FLOAT_SPREAD,
            GT.FORMULA_SYNTAX									AS INDEX_FACTOR,
            'NULL' 										AS PRICING_STATUS,
            from_unixtime(unix_timestamp(PDM.END1,'ddMMMyy'),'dd-MM-yyyy')                      					AS PRICE_SETTLE_DATE,
            PDM.DMO1||'_'||PDM.START1           								AS DEAL_SUB_LEG_REFERENCE,
            DECODE(GT.PHYS_FIN, 'P', 'PHYSICAL', 'FINANCIAL')        							AS SETTLEMENT_TYPE,
            GT.MEMOLINE1  									AS DEAL_LINE_TEXT,
            CASE WHEN GT.IS_OPTION = 'Y' THEN GT.PUT_CALL ELSE NULL END 		                				AS CALL_PUT_FLAG,
            PDMO.STRIKE_IC    									AS OPTION_STRIKE_PRICE,
            PDMO.OPT_PREM_IC  									AS OPTION_PREMIUM_PRICE
                       
            FROM GV_TRADES GT
            LEFT JOIN
            (
            SELECT BOOK_DSC,BOOK_BOOK 
            FROM
            (SELECT BOOK_DSC,BOOK_BOOK,row_number() over (Partition by BOOK_BOOK ORDER BY BOOK_ALF DESC) row_num 
            FROM STATIC_BOOKS B
            ) WHERE row_num=1 
            )B
            ON B.BOOK_BOOK = GT.BOOK 
           
            LEFT JOIN GV_TRADESAUX GTA
            ON GTA.TNUM = GT.TNUM
           
             LEFT JOIN 
            (SELECT CONTRACT_CPTY,CONTRACT_MANUM,CONTRACT_HOUSE,CONTRACT_DSC 
            FROM
            (SELECT CONTRACT_CPTY,CONTRACT_MANUM,CONTRACT_HOUSE,CONTRACT_DSC,row_number() over (Partition by CONTRACT_CPTY,CONTRACT_MANUM,CONTRACT_HOUSE  ORDER BY AUDIT_ADATE0 DESC) row_num 
            FROM STATIC_CONTRACTS SC
            )WHERE row_num=1
            )SC
            ON SC.CONTRACT_CPTY = GT.CPTY AND SC.CONTRACT_MANUM = GT.MANUM AND SC.CONTRACT_HOUSE = GT.HOUSE_ID 
            
            LEFT JOIN 
            (select distinct PM.ZKEY,PM.TNUM,PM.START1,PM.END1,PM.PRICE1_IC,PM.QTY1,PM.SIDE,PM.DMO1,PM.FLOAT_MULT
            from GV_PNL_MONTHLY PM
            UNION
            select distinct  PD.ZKEY,PD.TNUM,PD.START1,PD.END1,PD.PRICE1_IC,PD.QTY1,PD.SIDE,PD.DMO1,PD.FLOAT_MULT
            from GV_PNL_DAILY PD
            ) as PDM
            ON PDM.ZKEY = GT.ZKEY AND PDM.TNUM = GT.TNUM 
            
           LEFT JOIN 
          (select distinct PMO.ZKEY,PMO.TNUM,PMO.STRIKE_IC,PMO.OPT_PREM_IC
           FROM GV_PNL_MONTHLY_OPTS PMO
           UNION
           select distinct  PDO.ZKEY,PDO.TNUM,PDO.STRIKE_IC,PDO.OPT_PREM_IC
           from GV_PNL_DAILY_OPTS PDO
           ) as PDMO                     

          WHERE GT.VOID_FLAG='N'
            and {1} > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')

      """.format(last_watermark_gv_trades,date_attribute)
      
      loadDatasetConfigsAligneDealAttributes(spark,SOURCE_ETRM)
      df = spark.sql(SQL)
        
      return (df,metricDict)
     
      
  

# COMMAND ----------

def loadDatasetConfigsAligneDealAttributes(spark, SOURCE_ETRM):
    format = "delta"
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'GV_TRADES', 'parquet', 'GV_TRADES')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'GV_TRADESAUX', 'parquet', 'GV_TRADESAUX')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'STATIC_CPTY', 'parquet', 'STATIC_CPTY')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'STATIC_UNITS', 'parquet', 'STATIC_UNITS')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'GV_TRADEFEES', 'parquet', 'GV_TRADEFEES')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'STATIC_VOL_IMB_PK_GL', 'parquet', 'STATIC_VOL_IMB_PK_GL')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'GV_RAWTPOW', 'parquet', 'GV_RAWTPOW')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'STATIC_USERS', 'parquet', 'STATIC_USERS')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'STATIC_HOUSE', 'parquet', 'STATIC_HOUSE')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'STATIC_VALUE', 'parquet', 'STATIC_VALUE')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'STATIC_MRKTC', 'parquet', 'STATIC_MRKTC')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'STATIC_BOOKS', 'parquet', 'STATIC_BOOKS')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'GV_PNL_MONTHLY', 'parquet', 'GV_PNL_MONTHLY')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'GV_PNL_MONTHLY_OPTS', 'parquet', 'GV_PNL_MONTHLY_OPTS')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'GV_PNL_DAILY', 'parquet', 'GV_PNL_DAILY')
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'GV_PNL_DAILY_OPTS', 'parquet', 'GV_PNL_DAILY_OPTS') 
    readDatasetConfigAndCreateTempView(spark, 'ALIGNE', 'STATIC_CONTRACTS', 'parquet', 'STATIC_CONTRACTS')
