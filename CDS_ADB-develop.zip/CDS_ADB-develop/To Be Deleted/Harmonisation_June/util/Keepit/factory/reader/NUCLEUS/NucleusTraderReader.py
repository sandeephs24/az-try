# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class NucleusTraderReader(SourceDatasetReader):
    
  def read(spark,metricDict):
        
        SOURCE_ETRM = 'NUCLEUS'
        
        df = executeJdbcQueryAndReturnDF("select src_sys_trader_nk from tsa_curated.dim_trader where src_sys_name = '{0}'".format(SOURCE_ETRM))
        df.createOrReplaceTempView("CURATED_DIM_TRADER")
        
        TRADER_READER_SQL = """
        SELECT U.USER_CODE AS SRC_SYS_TRADER_NK, 
              U.USER_NAME AS TRADER_NAME,  
              SUBSTR(U.USER_NAME, 0, INSTR(U.USER_NAME, ' ')-1) AS TRADER_FIRST_NAME, 
              SUBSTR(U.USER_NAME, INSTR(U.USER_NAME, ' ')+1) AS TRADER_LAST_NAME,
              '1900-01-01 00:00:00'                AS SOURCE_LAST_UPDATE
        FROM    USERS U
        WHERE EXISTS (SELECT DMD.UR_TRADER FROM DEAL_MONTH_DETAILS DMD WHERE DMD.UR_TRADER = U.USER_CODE);

        """
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'USERS', format, 'USERS')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'DEAL_MONTH_DETAILS', format, 'DEAL_MONTH_DETAILS')
        
        
        df = spark.sql(TRADER_READER_SQL)
        
        return (df,metricDict)

# COMMAND ----------

 
