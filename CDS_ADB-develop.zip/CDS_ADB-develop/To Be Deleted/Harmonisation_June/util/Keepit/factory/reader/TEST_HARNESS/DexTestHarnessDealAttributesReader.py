# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../enricher/DealAttributeEnricher

# COMMAND ----------

class DexTestHarnessDealAttributesReader(SourceDatasetReader):
    
   def read(spark, metricDict, initial_load):

      df = executeJdbcQueryAndReturnDF("select * from tsa_curated.hardcoded_deal_attributes_reader_dex")
      df.createOrReplaceTempView("hardcoded_deal_attributes_reader")
      print('Hardcoded Reader')
      df = DealAttributeenrich(spark,df,SOURCE_ETRM)
      return (df, metricDict);
      
  
