# Databricks notebook source
# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../enricher/LocationMappingEnricher

# COMMAND ----------

class DexLocationReader(SourceDatasetReader):
    
  def read(spark,metricDict):
      SOURCE_ETRM = 'DEX'
      
      last_watermark_location=getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_LOCATION','DIM_LOCATION')
      last_watermark_location = last_watermark_location[0:19]
      
      print(last_watermark_location)
      
      df = executeJdbcQueryAndReturnDF("select cast(SRC_SYS_LOCATION_NK as int) as SRC_SYS_LOCATION_NK from tsa_curated.dim_location where src_sys_name = '{0}'".format(SOURCE_ETRM))
      df.createOrReplaceTempView("CURATED_DIM_LOCATION")
      
      print(df.count())
      
      LOCATION_READ_SQL = """
      select distinct 	
      cast(c.sequence_num as int) as SRC_SYS_LOCATION_NK,	
      c.location_name as LOCATION_NAME,	
      c.Location_Type_Code as LOCATION_TYPE,	
      '' as LOCATION_AREA,
      c.LAST_UPDATE_TSTMP as SOURCE_LAST_UPDATE
      from STO_LOCATION c 	
      left join STO_LOCRELD e 	
      on e.ownd_loc_seq_num = c.sequence_num 	
      and e.loc_typ_owng_code='CTRY'
      left join STO_LOCATION d on              
      d.sequence_num=e.owng_loc_seq_num        
      and d.location_type_code ='CTRY'     
      where 
      (
      c.LAST_UPDATE_TSTMP > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
      or
      cast(c.sequence_num as int) in (select SRC_SYS_LOCATION_NK from CURATED_DIM_LOCATION)
      )      
      """.format(last_watermark_location)     
      
      format = "delta"
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_LOCATION', format, 'STO_LOCATION')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_LOCRELD',format, 'STO_LOCRELD')

                 
      df = spark.sql(LOCATION_READ_SQL)
      
      print(df.count())
      #df=df.withColumn("SOURCE_LAST_UPDATE", date_trunc("minute", col("SOURCE_LAST_UPDATE")))
      df = enrichLocationForMapping(spark,df,SOURCE_ETRM)
      
      return  (df,metricDict)
