# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ../../DatasetReader

# COMMAND ----------

# MAGIC %run ./DexFactHeaderReader

# COMMAND ----------

# MAGIC %run ./DexFactLegReader

# COMMAND ----------

# MAGIC %run ./DexFactSubLegReader

# COMMAND ----------

class DexFactReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
    
    (dfHeader,metricDict) = DexFactHeaderReader.read(spark,SOURCE_ETRM,metricDict, INITIAL_LOAD)
    (dfLeg, metricDict) = DexFactLegReader.read(spark,SOURCE_ETRM,metricDict, INITIAL_LOAD)
    (dfSubLeg, metricDict) = DexFactSubLegReader.read(spark,SOURCE_ETRM,metricDict, INITIAL_LOAD)

    return (dfHeader,dfLeg,dfSubLeg, metricDict)
