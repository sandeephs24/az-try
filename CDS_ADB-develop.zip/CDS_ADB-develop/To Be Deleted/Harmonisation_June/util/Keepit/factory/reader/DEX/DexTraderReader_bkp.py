# Databricks notebook source
# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run /TSA/pyspark/util/CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

from pyspark.sql.functions import *

df = spark.createDataFrame([("2018-03-21 08:15:00",)], ["timestamp"])
newDf= df.withColumn("newtimestamp", to_timestamp(col('timestamp'), "yyyy-MM-dd HH:mm:ss")
)
df.show()

df1= executeJdbcQueryAndReturnDF("select RECORD_CREATED_DTTM from tsa_curated.dim_broker where src_sys_name = 'DEX'")
#df = spark.sql(SQL)
df1show()

# COMMAND ----------

class DexTraderReader(SourceDatasetReader):
    def read(spark,metricDict):
      
      import pyspark.sql.functions as F
      
      SOURCE_ETRM = 'DEX'
      last_watermark = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_USR','DIM_TRADER')
      last_watermark = last_watermark[0:19]
      
      df = executeJdbcQueryAndReturnDF("select src_sys_trader_nk from tsa_curated.dim_trader where src_sys_name = '{0}'".format(SOURCE_ETRM))
      df.createOrReplaceTempView("CURATED_DIM_TRADER")
      
      TRADER_READ_SQL = """
      SELECT
      a.NICKNAME_USERID AS SRC_SYS_TRADER_NK,
      a.user_desc_txt AS TRADER_NAME, 
      a.user_first_name as TRADER_FIRST_NAME,
      a.user_surname_txt as TRADER_LAST_NAME,
      a.LAST_UPDATE_TSTMP as SOURCE_LAST_UPDATE
      from STO_USR a
      where 
      (
      a.last_update_tstmp > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss') 
      or 
      a.NICKNAME_USERID in (select src_sys_trader_nk from CURATED_DIM_TRADER)
      )
      and exists(select 1 from STO_CONTRACT b where b.TRADER_USERID=a.NICKNAME_USERID ) 
      """.format(last_watermark)


      format = "delta"
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_USR', format, 'STO_USR')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CONTRACT', format, 'STO_CONTRACT')
     
      df = spark.sql(TRADER_READ_SQL)
      print('Reader Count')
      print(df.count())
      return  (df,metricDict)
