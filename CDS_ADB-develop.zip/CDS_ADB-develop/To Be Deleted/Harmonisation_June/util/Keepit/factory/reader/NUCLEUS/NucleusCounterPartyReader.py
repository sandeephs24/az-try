# Databricks notebook source
# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../enricher/InternalPartyEmptyEnricher

# COMMAND ----------

# MAGIC %run ./../../enricher/PartyGoldTierEnricher

# COMMAND ----------

class NucleusCounterPartyReader(SourceDatasetReader):
     
    def read(spark,metricDict):
        
        SOURCE_ETRM = 'NUCLEUS'
      
        last_watermark_party = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'COMPANIES','DIM_PARTY')
        last_watermark_party = last_watermark_party[0:19]
        
        df = executeJdbcQueryAndReturnDF("select src_sys_party_nk from tsa_curated.dim_party where src_sys_name = '{0}'".format(SOURCE_ETRM))
        df.createOrReplaceTempView("CURATED_DIM_PARTY")
        
        
                    
        INTERNAL_PARTY_READER_SQL = """
        SELECT  cast(C.COMPANY_KEY as int)             AS SRC_SYS_PARTY_NK,
               C.SHORT_NAME               AS SRC_SYS_PARTY_SHORT_NAME,
               C.LONG_NAME                AS SRC_SYS_PARTY_LONG_NAME,
               'INTERNAL'                 AS PARTY_TYPE, 
               ''           AS SRC_SYS_LEGAL_ENTITY_NK,
               ''             AS SRC_SYS_LEGAL_ENTITY_NAME,
               C.MODIFY_DATE              AS SOURCE_LAST_UPDATE
          FROM COMPANIES C 
          WHERE UPPER(C.LONG_NAME) like '%SHELL%'
          OR EXISTS (SELECT LE.CY_ENTITY_KEY FROM LEGAL_ENTITIES LE WHERE LE.CY_ENTITY_KEY = C.COMPANY_KEY)
          AND
          (
          C.MODIFY_DATE > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss') 
          or 
          C.COMPANY_KEY in (select src_sys_party_nk from CURATED_DIM_PARTY)
          )
        """.format(last_watermark_party)
    
        EXTERNAL_PARTY_READER_SQL = """
        SELECT  cast(C.COMPANY_KEY as int)          AS SRC_SYS_PARTY_NK,
               C.SHORT_NAME               AS SRC_SYS_PARTY_SHORT_NAME,
               C.LONG_NAME                AS SRC_SYS_PARTY_LONG_NAME,
               'EXTERNAL'                 AS PARTY_TYPE,  
               ''                         AS SRC_SYS_LEGAL_ENTITY_NK,
               ''                         AS SRC_SYS_LEGAL_ENTITY_NAME,
               C.MODIFY_DATE              AS SOURCE_LAST_UPDATE
        FROM COMPANIES C 
        WHERE UPPER(C.LONG_NAME) not like '%SHELL%'
        AND NOT EXISTS (SELECT LE.CY_ENTITY_KEY FROM LEGAL_ENTITIES LE WHERE LE.CY_ENTITY_KEY = C.COMPANY_KEY)
         AND 
        (
        C.MODIFY_DATE > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss') 
        or 
        C.COMPANY_KEY in (select src_sys_party_nk from CURATED_DIM_PARTY)
        ) 
        """.format(last_watermark_party)
        
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'COMPANIES', 'parquet', 'COMPANIES')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'COMPANY_LEGAL_ENTITIES', 'parquet', 'COMPANY_LEGAL_ENTITIES')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'LEGAL_ENTITIES', 'parquet', 'LEGAL_ENTITIES')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'DEAL_MONTH_DETAILS',format, 'DEAL_MONTH_DETAILS')
               
             
        
        dfInternal = spark.sql(INTERNAL_PARTY_READER_SQL)
        
        dfExternal = spark.sql(EXTERNAL_PARTY_READER_SQL)
        
        df1 = enrichInternalParty(dfInternal)
        spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
        df1 = df1.withColumn("NEXT_ENHANCED_MONITORING_REQUIRED_DATE",to_date(col("NEXT_ENHANCED_MONITORING_REQUIRED_DATE"),"yyyy-MM-dd"))
        df1 = df1.withColumn("KYC_NEXT_REVIEW_DATE",to_date(col("KYC_NEXT_REVIEW_DATE"),"yyyy-MM-dd"))
        df1 = df1.withColumn("KYC_LAST_REVIEW_DATE",to_date(col("KYC_LAST_REVIEW_DATE"),"yyyy-MM-dd"))
        df1 = df1.withColumn("SOURCE_LAST_UPDATE",to_timestamp(col("SOURCE_LAST_UPDATE")))
        df2 = enrichExternalParty(spark,dfExternal,SOURCE_ETRM)
        df2 = df2.withColumn("NEXT_ENHANCED_MONITORING_REQUIRED_DATE",to_date(col("NEXT_ENHANCED_MONITORING_REQUIRED_DATE"),"yyyy-MM-dd"))
        df2 = df2.withColumn("KYC_NEXT_REVIEW_DATE",to_date(col("KYC_NEXT_REVIEW_DATE"),"yyyy-MM-dd"))
        df2 = df2.withColumn("KYC_LAST_REVIEW_DATE",to_date(col("KYC_LAST_REVIEW_DATE"),"yyyy-MM-dd"))
        df2 = df2.withColumn("SOURCE_LAST_UPDATE",to_timestamp(col("SOURCE_LAST_UPDATE")))
        
        
        totalDf = df1.union(df2)
      
        return (totalDf,metricDict)
        
