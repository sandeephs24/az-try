# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ../../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./NucleusFactHeaderReader

# COMMAND ----------

# MAGIC %run ./NucleusFactLegReader

# COMMAND ----------

# MAGIC %run ./NucleusFactSubLegReader

# COMMAND ----------

class NucleusFactReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
    
    (dfHeader,metricDict) = NucleusFactHeaderReader.read(spark,SOURCE_ETRM,metricDict, INITIAL_LOAD)
    (dfLeg, metricDict) = NucleusFactLegReader.read(spark,SOURCE_ETRM,metricDict, INITIAL_LOAD)
    (dfSubLeg, metricDict) = NucleusFactSubLegReader.read(spark,SOURCE_ETRM,metricDict, INITIAL_LOAD)

    return (dfHeader,dfLeg,dfSubLeg, metricDict)
