# Databricks notebook source
# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../enricher/CommodityMappingEnricher

# COMMAND ----------

class DexCommodityReader(SourceDatasetReader):
    def read(spark,metricDict):
      print('here')
      SOURCE_ETRM = 'DEX'
      last_watermark = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_GRADE','DIM_COMMODITY')
      last_watermark = last_watermark[0:19]
      
      df = executeJdbcQueryAndReturnDF("select src_sys_commodity_nk from tsa_curated.dim_commodity where src_sys_name = '{0}'".format(SOURCE_ETRM))
      df.createOrReplaceTempView("CURATED_DIM_COMMODITY")

      COMMODITY_READ_SQL = """
      SELECT
      b.grade_code as SRC_SYS_COMMODITY_NK,
      b.long_name as SRC_COMMODITY_NAME,
      c.desc_long_text as SRC_COMMODITY_GROUP_NAME,
      b.active_rec_ind as ACTIVE_COMMODITY_FLAG,
      b.last_update_tstmp as SOURCE_LAST_UPDATE
      from STO_GRADE b
      left join STO_GRADEGP c on c.grade_group_code = b.grade_group_code
      WHERE (b.last_update_tstmp > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss') or
      b.grade_code in (select SRC_SYS_COMMODITY_NK from CURATED_DIM_COMMODITY))
      """.format(last_watermark)
      
          
      format = "delta"
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_GRADE', format, 'STO_GRADE')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_GRADEGP', format, 'STO_GRADEGP')

      df = spark.sql(COMMODITY_READ_SQL)
      print(df.count())
      df.show()
      df=df.withColumn("SOURCE_LAST_UPDATE", date_trunc("minute", col("SOURCE_LAST_UPDATE")))
      df = enrichCommodityForMapping(spark,df,SOURCE_ETRM)
      return (df,metricDict)

