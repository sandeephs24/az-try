# Databricks notebook source
# MAGIC %run ./../../enricher/UOMMappingEnricher

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class EndurGPNAUnitOfMeasureReader(SourceDatasetReader):
    
    def read(spark,metricDict):
        SOURCE_ETRM = 'ENDUR_GPNA'
        
        UOM_READER_SQL = """
        select 
        unit_id SRC_SYS_UNIT_OF_MEASURE_NK, 
        unit_label 
        from IDX_UNIT
        """
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'IDX_UNIT', format, 'IDX_UNIT')

        df = spark.sql(UOM_READER_SQL)
        df = enrichUOMForMapping(spark,df, SOURCE_ETRM)
        
        
        return (df,metricDict)
