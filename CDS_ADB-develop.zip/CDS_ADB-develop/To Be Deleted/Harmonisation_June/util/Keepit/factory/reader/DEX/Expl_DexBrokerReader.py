# Databricks notebook source
# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

SOURCE_ETRM = "DEX"
df = executeJdbcQueryAndReturnDF("select src_sys_broker_nk from tsa_curated.dim_broker where src_sys_name = '{0}'".format(SOURCE_ETRM))
df.createOrReplaceTempView("CURATED_DIM_BROKER")

BROKER_READ_SQL = """
SELECT
cast(a.sequence_num as int) as SRC_SYS_BROKER_NK,        
c.CMF_LONG_NAME as BROKER_NAME, 
a.active_rec_ind as ACTIVE_BROKER_FLAG ,
a.last_update_tstmp as SOURCE_LAST_UPDATE  
FROM
STO_CHRGACCT a 
LEFT JOIN STO_COMPANY c
ON c.company_mnem = a.company_mnem
WHERE  
 a.sequence_num in (select src_sys_broker_nk from CURATED_DIM_BROKER)
and exists(select 1 from STO_PRCLCST b where b.chrg_acct_num = a.sequence_num AND b.cost_type_code = 'BROKE' )
"""

format = "delta"
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CHRGACCT', format, 'STO_CHRGACCT')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLCST', format, 'STO_PRCLCST')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_COMPANY',format, 'STO_COMPANY')

df = spark.sql(BROKER_READ_SQL)
print(df.count())
df.show(20, truncate=False)


# COMMAND ----------

SOURCE_ETRM = "DEX"


BROKER_READ_SQL = """
SELECT
cast(a.sequence_num as int) as SRC_SYS_BROKER_NK,        

a.active_rec_ind as ACTIVE_BROKER_FLAG ,
a.last_update_tstmp as SOURCE_LAST_UPDATE  
FROM
STO_CHRGACCT a 

"""

format = "delta"
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CHRGACCT', format, 'STO_CHRGACCT')


df = spark.sql(BROKER_READ_SQL)
print(df.count())
df.show(1020, truncate=False)
