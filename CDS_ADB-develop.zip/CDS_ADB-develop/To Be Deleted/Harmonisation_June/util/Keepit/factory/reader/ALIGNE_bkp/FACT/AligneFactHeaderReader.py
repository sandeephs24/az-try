# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../../WatermarkReader

# COMMAND ----------

class AligneFactHeaderReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM,metricDict, INITIAL_LOAD):
    
    (dfHeader,metricDict) = readFactHeader(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD)

    return (dfHeader,metricDict) 

# COMMAND ----------

def readFactHeader(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
  
  last_watermark_fact_gv_trade = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'GV_TRADES','TRADE_DATE','FACT_DEAL_HEADER')
  last_watermark_fact_gv_trade = last_watermark_fact_gv_trade[0:19]
   
  format = "delta"
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_TRADES', 'parquet', 'GV_TRADES')
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_PNL_MONTHLY', 'parquet', 'GV_PNL_MONTHLY')
  readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_PNL_DAILY', 'parquet', 'GV_PNL_DAILY')
  
  

  if INITIAL_LOAD == "Y" :
    SQL = getHeaderReaderSQLDay0(last_watermark_fact_gv_trade)
  else:
    SQL = getHeaderReaderSQLDay1(last_watermark_fact_gv_trade)
  
    
  dfFactHeader = spark.sql(SQL)
  
  
  dfFactHeader.show(10, truncate=False)
  
  print("AligneFactHeaderReader" , dfFactHeader.count())

  return (dfFactHeader,metricDict)

# COMMAND ----------

def getHeaderReaderSQLDay1(last_watermark_fact_gv_trade):
  SQL = """
   WITH DEALS_IN_SCOPE AS 
            (
            SELECT DISTINCT CONTRACT_NUM
			,CONTRACT_CREATE_D
            FROM		STO_CONTRACT
            WHERE  		  ( 
						  (
						  CONTRACT_DATE > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
						  ) 
						  OR
						  (
						  CONTRACT_DATE < to_timestamp('{1}','yyyy-MM-dd HH:mm:ss') 
						  and LAST_UPDATE_TSTMP > to_timestamp('{2}','yyyy-MM-dd HH:mm:ss')	
						  )		
                          )	
            )
        ,QTY_CALCULATOR AS 
            (
            SELECT		a.CONTRACT_NUM
			,a.CONTRACT_CREATE_D
			,CASE WHEN c.QTY_UNIT_CODE = 'M3' THEN 'BBL' 
				WHEN c.QTY_UNIT_CODE = 'LIT' THEN 'BBL'
				WHEN c.QTY_UNIT_CODE = 'KT' THEN 'MT'
				WHEN c.QTY_UNIT_CODE = 'KB' THEN 'BBL'
				ELSE c.QTY_UNIT_CODE END							AS PARCEL_UNIT_CODE	
			,SUM((CASE WHEN c.QTY_UNIT_CODE = 'M3' THEN 6.291
						WHEN c.QTY_UNIT_CODE = 'LIT' THEN 0.006291
						WHEN c.QTY_UNIT_CODE = 'KT' THEN 1000
						WHEN c.QTY_UNIT_CODE = 'KB' THEN 1000
						ELSE 1 END)*c.QTY_AMT)  					AS PARCEL_QTY		
                FROM		STO_CONTRACT a
                JOIN		STO_CDTYCTMT b
                ON			a.CONTRACT_NUM = b.CONTRACT_NUM 
                AND     	a.CONTRACT_CREATE_D = b.CONTRACT_CREATE_D
                JOIN    	STO_PARCEL c
                ON      	a.CONTRACT_NUM = c.CONTRACT_NUM 
                AND     	a.CONTRACT_CREATE_D = c.CONTRACT_CREATE_D
                AND     	b.CTMT_SEQ_NUM = c.CDTY_CTMT_SEQ_NUM
                AND     	NVL(c.QTY_AMT,0) > 0
                JOIN    	DEALS_IN_SCOPE d
                ON      	a.CONTRACT_NUM = d.CONTRACT_NUM 
                AND     	a.CONTRACT_CREATE_D = d.CONTRACT_CREATE_D
                WHERE   	a.DEAL_CLASS_CODE in ( 'FWD', 'FUT', 'WET')           
                AND     	a.CTRACL_QTY_AMT IS NULL                             
                GROUP BY 	a.CONTRACT_NUM
                            ,a.CONTRACT_CREATE_D
                            ,CASE WHEN c.QTY_UNIT_CODE = 'M3' THEN 'BBL' 
                                WHEN c.QTY_UNIT_CODE = 'LIT' THEN 'BBL'
                                WHEN c.QTY_UNIT_CODE = 'KT' THEN 'MT'
                                WHEN c.QTY_UNIT_CODE = 'KB' THEN 'BBL'
                                ELSE c.QTY_UNIT_CODE END   
            )                   

        ,QTY_MULTIPLES AS (							
        SELECT		CONTRACT_NUM
                    ,CONTRACT_CREATE_D
                    ,SUM(PARCEL_QTY)                            			AS MULTI_PARCEL_QTY
                    ,COUNT(1)                                   			AS MULTIPLE_IND
        FROM		QTY_CALCULATOR
        GROUP BY 	CONTRACT_NUM
                    ,CONTRACT_CREATE_D
        HAVING  COUNT(1) > 1)

        ,PARCEL_QTY AS (	
        SELECT		a.CONTRACT_NUM
                    ,a.CONTRACT_CREATE_D
                    ,a.PARCEL_UNIT_CODE
                    ,a.PARCEL_QTY
        FROM		QTY_CALCULATOR a
        LEFT JOIN	QTY_MULTIPLES b
        ON			a.CONTRACT_NUM = b.CONTRACT_NUM 
        AND         a.CONTRACT_CREATE_D = b.CONTRACT_CREATE_D
        WHERE       b.MULTIPLE_IND IS NULL) 
        


        SELECT   a.TRDG_COMP_MNEM||'_'||a.CONTRACT_NUM||'_'|| date_format(a.CONTRACT_CREATE_D,'yyyyMMdd')			AS DEAL_ATTRIBUTES_NK			         ,b.EXECUTION_DATE 																				    AS EXECUTION_DATE				         ,a.CONTRACT_DATE 																				    AS TRADE_CREATION_DATE					 ,a.CLT_CHRG_ACCT_NUM 																			    AS COUNTERPARTY_NK
			     ,a.OWNG_CHRG_ACCT_NUM 																			    AS SHELL_TRADING_PARTY_NK
			     ,a.TRADER_USERID 																				    AS TRADER_NK
			     ,'-3' 																							    AS BROKER_NK						,CASE 
                   WHEN a.DEAL_CLASS_CODE in ( 'EXE', 'OPT') THEN a.CTRACL_QTY_UNIT_C
                   WHEN a.DEAL_CLASS_CODE = 'FWD' AND a.CTRACL_QTY_AMT IS NOT NULL THEN a.CTRACL_QTY_UNIT_C
                   WHEN qm.MULTIPLE_IND IS NOT NULL THEN 'JOIN_NOT_SUPPORTED'
                   ELSE pq.PARCEL_UNIT_CODE END 																    AS UNIT_OF_MEASURE_NK			
			,CASE 
                  WHEN a.DEAL_CLASS_CODE in ( 'EXE', 'OPT') THEN a.CTRACL_QTY_AMT
                  WHEN a.DEAL_CLASS_CODE = 'FWD' AND a.CTRACL_QTY_AMT IS NOT NULL THEN a.CTRACL_QTY_AMT
                  WHEN qm.MULTIPLE_IND IS NOT NULL THEN qm.MULTI_PARCEL_QTY
                  ELSE pq.PARCEL_QTY END 																		    AS CONTRACT_QTY					
			,CASE 
                  WHEN b2.OWNER_BUY_SELL_IND = 'S' THEN -1 
                  WHEN b2.OWNER_BUY_SELL_IND = 'B' THEN 1 
                   ELSE 0 END  																				        AS DEAL_HEADER_MULTIPLIER			 ,a.LAST_UPDATE_TSTMP 																			         AS SOURCE_LAST_DATE1
			,a.CONTRACT_DATE 																				        AS SOURCE_LAST_DATE2
			,'' 																							        AS SOURCE_LAST_DATE3
              FROM STO_CONTRACT a
              JOIN	DEALS_IN_SCOPE deals
              ON          a.CONTRACT_NUM = deals.CONTRACT_NUM
              AND         a.CONTRACT_CREATE_D = deals.CONTRACT_CREATE_D
                            JOIN        (
                          SELECT  CONTRACT_NUM, CONTRACT_CREATE_D, EXECUTION_DATE,grade_code
                          FROM  (      
                                  SELECT v.CONTRACT_NUM, v.CONTRACT_CREATE_D, v.EXECUTION_DATE ,v.grade_code
                                  ,ROW_NUMBER() OVER(PARTITION BY v.CONTRACT_NUM, v.CONTRACT_CREATE_D 
                                  ORDER BY NVL(v.EXECUTION_DATE,'31-DEC-9999') asc) AS RNUM
                                      FROM (     
                                             SELECT	b1.CONTRACT_NUM,b1.CONTRACT_CREATE_D
                                              ,LEAST(CAST(c1.EXECUTION_TSTMP AS DATE), CAST(b1.EXECUTION_TSTMP AS DATE)) AS EXECUTION_DATE,b1.grade_code
                                                  FROM STO_CDTYCTMT b1
                                                  JOIN	STO_PARCEL c1
                                                  ON		b1.TRDG_COMP_MNEM = c1.TRDG_COMP_MNEM
                                                  AND     b1.CONTRACT_NUM = c1.CONTRACT_NUM 
                                                  AND     b1.CONTRACT_CREATE_D = c1.CONTRACT_CREATE_D
                                                  AND     b1.CTMT_SEQ_NUM = c1.CDTY_CTMT_SEQ_NUM
                                                  ) v
                                      ) WHERE RNUM = 1
                            ) b
              ON          a.CONTRACT_NUM = b.CONTRACT_NUM 
              AND         a.CONTRACT_CREATE_D = b.CONTRACT_CREATE_D
              JOIN        (
                          SELECT	CONTRACT_NUM
                                  ,CONTRACT_CREATE_D
                                  ,OWNER_BUY_SELL_IND
                          FROM	STO_CDTYCTMT
                          WHERE	CTMT_SEQ_NUM = '01'
                          ) b2
              ON          a.CONTRACT_NUM = b2.CONTRACT_NUM 
              AND         a.CONTRACT_CREATE_D = b2.CONTRACT_CREATE_D
              LEFT JOIN	QTY_MULTIPLES qm
              ON          a.CONTRACT_NUM = qm.CONTRACT_NUM 
              AND         a.CONTRACT_CREATE_D = qm.CONTRACT_CREATE_D
              LEFT JOIN	PARCEL_QTY pq
              ON          a.CONTRACT_NUM = pq.CONTRACT_NUM 
              AND         a.CONTRACT_CREATE_D = pq.CONTRACT_CREATE_D 
              where b.grade_code not in ('LPROP') 
AND  a.OWNG_CHRG_ACCT_NUM not In ('2304','2391','2390')
  """.format(last_watermark_fact_gv_trade)
  
  return SQL


# COMMAND ----------

def getHeaderReaderSQLDay0(last_watermark_fact_gv_trade):
  SQL = """
        
      SELECT
      DEAL_ATTRIBUTES_NK,
      EXECUTION_DATE,
      TRADE_CREATION_DATE,
      COUNTERPARTY_NK,
      SHELL_TRADING_PARTY_NK,
      TRADER_NK,
      BROKER_NK,
      UNIT_OF_MEASURE_NK,
      sum(CONTRACT_QTY) AS CONTRACT_QTY,
      DEAL_HEADER_MULTIPLIER,
      source_last_date1,
      source_last_date2,
      source_last_date3
      from (
            SELECT
           GT.ZKEY                                                  	AS DEAL_ATTRIBUTES_NK,
            GT.TRADE_DATE                                                          	AS EXECUTION_DATE,
            GT.INPUT_DATE                                                         	 AS TRADE_CREATION_DATE,
            GT.CPTY                                                               	 AS COUNTERPARTY_NK,
            GT.HOUSE_ID                                                           	 AS SHELL_TRADING_PARTY_NK,
            GT.TRADER                                                             	 AS TRADER_NK,
            CASE WHEN GT.CPTY_BROKER='DIRECT' THEN NULL
                 ELSE GT.CPTY_BROKER
                 END                                                               	AS BROKER_NK,
            GT.AMT_UNIT                                                            	AS UNIT_OF_MEASURE_NK,
             PDM.QTY1                 AS CONTRACT_QTY,
            CASE WHEN GT.BUYSELL='B' THEN 1
                 WHEN GT.BUYSELL='S' THEN -1
                 ELSE 0 END                                                     	AS DEAL_HEADER_MULTIPLIER,
                    GT.trade_date source_last_date1,
   '' as source_last_date2,
    ''  as source_last_date3
            FROM GV_TRADES GT
             LEFT JOIN 
               ( select * FROM
      (select distinct PM.ZKEY,PM.TNUM,PM.START1,PM.END1,PM.PRICE1_IC,PM.QTY1,PM.SIDE,PM.DMO1,PM.FLOAT_MULT,row_number() over (Partition by PM.ZKEY,PM.START1,PM.END1 ORDER BY ASOF_DATE DESC) row_num
      from GV_PNL_MONTHLY PM
      UNION
      select distinct PD.ZKEY,PD.TNUM,PD.START1,PD.END1,PD.PRICE1_IC,PD.QTY1,PD.SIDE,PD.DMO1,PD.FLOAT_MULT,row_number() over (Partition by PD.ZKEY,PD.START1,PD.END1 ORDER BY ASOF_DATE DESC) row_num
      from GV_PNL_DAILY PD
      )WHERE row_num=1)PDM
      ON PDM.ZKEY = GT.ZKEY AND PDM.TNUM = GT.TNUM
      WHERE GT.VOID_FLAG='N'
          and GT.TRADE_DATE>'{0}'
            )
    group by
    DEAL_ATTRIBUTES_NK,EXECUTION_DATE,TRADE_CREATION_DATE,COUNTERPARTY_NK,SHELL_TRADING_PARTY_NK,TRADER_NK,BROKER_NK,
    UNIT_OF_MEASURE_NK, DEAL_HEADER_MULTIPLIER,source_last_date1,source_last_date2,source_last_date3
                   

  """.format(last_watermark_fact_gv_trade)
  
  return SQL
