# Databricks notebook source
# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../enricher/CommodityMappingEnricher

# COMMAND ----------

class AligneCommodityReader(SourceDatasetReader):
    def read(spark,metricDict):
      print('here')
      SOURCE_ETRM = 'ALIGNE'
      #last_watermark = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_GRADE','DIM_COMMODITY')
      #last_watermark = last_watermark[0:19]
      
      df = executeJdbcQueryAndReturnDF("select src_sys_commodity_nk from tsa_curated.dim_commodity where src_sys_name = '{0}'".format(SOURCE_ETRM))
      df.createOrReplaceTempView("CURATED_DIM_COMMODITY")

      COMMODITY_READ_SQL = """
      SELECT distinct
      d.CDY1_RISKDESC  as SRC_SYS_COMMODITY_NK,
      d.CDY1_RISKDESC   as SRC_COMMODITY_NAME,
      d.CDY1_RISKDESC   as SRC_COMMODITY_GROUP_NAME,
      'Y' as ACTIVE_COMMODITY_FLAG,
      '1900-01-01' as SOURCE_LAST_UPDATE
      FROM  GV_TRADES d
      WHERE d.VOID_FLAG='N'
      """
      
          
      format = "parquet"
      readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_TRADES', format, 'GV_TRADES')

      df = spark.sql(COMMODITY_READ_SQL)
      print(df.count())
      df.show()
      df=df.withColumn("SOURCE_LAST_UPDATE", date_trunc("minute", col("SOURCE_LAST_UPDATE")))
      df = enrichCommodityForMapping(spark,df,SOURCE_ETRM)
      return (df,metricDict)

