# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../enricher/CurrencyMappingEnricher

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class NucleusCurrencyReader(SourceDatasetReader):
    
  def read(spark,metricDict):
        
        SOURCE_ETRM = 'NUCLEUS'
        
        df = executeJdbcQueryAndReturnDF("select src_sys_currency_nk from tsa_curated.dim_currency where src_sys_name = '{0}'".format(SOURCE_ETRM))
        df.createOrReplaceTempView("CURATED_DIM_CURRENCY")
        
        CURRENCY_READER_SQL = """
        SELECT	
          C.CURRENCY		as SRC_SYS_CURRENCY_NK,
          '' as CURRENCY_CODE
          FROM  CURRENCIES C 
          """
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'CURRENCIES', format, 'CURRENCIES')
        
        
        df = spark.sql(CURRENCY_READER_SQL)
        df = enrich(spark,df, SOURCE_ETRM)
        
        return (df,metricDict)

# COMMAND ----------

 
