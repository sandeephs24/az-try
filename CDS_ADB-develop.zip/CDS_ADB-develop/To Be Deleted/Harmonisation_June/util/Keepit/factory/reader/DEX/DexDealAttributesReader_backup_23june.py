# Databricks notebook source
# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../enricher/DealAttributeEnricher

# COMMAND ----------

class DexDealAttributesReader(SourceDatasetReader):
    
  def read(spark,metricDict, INITIAL_LOAD):
      SOURCE_ETRM = 'DEX'
      
      last_watermark_parcel = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PARCEL','DIM_DEAL_ATTRIBUTES')
      last_watermark_parcel = last_watermark_parcel[0:19]

      last_watermark_contract = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_CONTRACT','DIM_DEAL_ATTRIBUTES')
      last_watermark_contract = last_watermark_contract[0:19]

      last_watermark_chrgacct = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_CHRGACCT','DIM_DEAL_ATTRIBUTES')
      last_watermark_chrgacct = last_watermark_chrgacct[0:19]

      last_watermark_pricing = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PRICING','DIM_DEAL_ATTRIBUTES')
      last_watermark_pricing = last_watermark_pricing[0:19]
      
      last_watermark_prcgterm = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PRCGTERM','DIM_DEAL_ATTRIBUTES')
      last_watermark_prcgterm = last_watermark_prcgterm[0:19]
      
      last_watermark_cdtyctmt = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_CDTYCTMT','DIM_DEAL_ATTRIBUTES')
      last_watermark_cdtyctmt = last_watermark_cdtyctmt[0:19]
      
      last_watermark_prcloprn = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PRCLOPRN','DIM_DEAL_ATTRIBUTES')
      last_watermark_prcloprn = last_watermark_prcloprn[0:19]
      
      last_watermark_voyage = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_VOYAGE','DIM_DEAL_ATTRIBUTES')
      last_watermark_voyage = last_watermark_voyage[0:19]
      
      last_watermark_vessel = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_VESSEL','DIM_DEAL_ATTRIBUTES')
      last_watermark_vessel = last_watermark_vessel[0:19]
      
      last_watermark_prcldch = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PRCLDCH','DIM_DEAL_ATTRIBUTES')
      last_watermark_prcldch = last_watermark_prcldch[0:19]
      
      last_watermark_location = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_LOCATION','DIM_DEAL_ATTRIBUTES')
      last_watermark_location = last_watermark_location[0:19]
      
      last_watermark_bkotprcl = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_BKOTPRCL','DIM_DEAL_ATTRIBUTES')
      last_watermark_bkotprcl = last_watermark_bkotprcl[0:19]
      
      last_watermark_bkotchn = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_BKOTCHN','DIM_DEAL_ATTRIBUTES')
      last_watermark_bkotchn = last_watermark_bkotchn[0:19]
      
      last_watermark_prclfcst = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_PRCLFCST','DIM_DEAL_ATTRIBUTES')
      last_watermark_prclfcst = last_watermark_prclfcst[0:19]
      
      last_watermark_settlmnt = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_SETTLMNT','DIM_DEAL_ATTRIBUTES')
      last_watermark_settlmnt = last_watermark_settlmnt[0:19]
      
      DEAL_ATTRIBUTE_READ_SQL = """
      select distinct a.TRDG_COMP_MNEM||'_'||a.CONTRACT_NUM||'_'||CASE WHEN date_format(a.CONTRACT_DATE,'yyyyMMdd') = '19000101' THEN  
      date_format(a.CONTRACT_CREATE_D,'yyyyMMdd') ELSE date_format(a.CONTRACT_DATE,'yyyyMMdd') END as SRC_SYS_DEAL_HEADER_KEY
      ,b.TRDG_COMP_MNEM||'_'||b.CONTRACT_NUM||'_'|| CASE WHEN date_format(a.CONTRACT_DATE,'yyyyMMdd') = '19000101' THEN 
      date_format(a.CONTRACT_CREATE_D,'yyyyMMdd') ELSE date_format(a.CONTRACT_DATE,'yyyyMMdd') END||'_'||b.CTMT_SEQ_NUM as SRC_SYS_DEAL_LEG_KEY
      ,c.TRDG_COMP_MNEM||'_'||c.CONTRACT_NUM||'_'|| CASE WHEN date_format(a.CONTRACT_DATE,'yyyyMMdd') = '19000101' THEN 
      date_format(a.CONTRACT_CREATE_D,'yyyyMMdd') ELSE date_format(a.CONTRACT_DATE,'yyyyMMdd')  
      END||'_'||c.CDTY_CTMT_SEQ_NUM||'_'||c.PRCL_SEQ_NUM             as SRC_SYS_DEAL_SUB_LEG_KEY
      ,c.DEAL_CLASS_CODE                                                                     as SRC_SYSTEM_DEAL_TYPE_CODE      
      ,c.DEAL_TYPE_CODE                                                                      as SRC_SYSTEM_DEAL_SUBTYPE_CODE      
      ,CASE WHEN c.DEAL_CLASS_CODE = 'EXE' THEN 'SWAP' WHEN c.DEAL_CLASS_CODE = 'OPT' THEN 'OPTION' 
      WHEN c.DEAL_CLASS_CODE = 'FUT' THEN 'FUTURE' WHEN c.DEAL_CLASS_CODE = 'FWD' THEN 'FORWARD'
      WHEN c.DEAL_CLASS_CODE = 'WET' THEN 'WET' 
      WHEN c.DEAL_CLASS_CODE = 'NULL' THEN 'NULL AT SOURCE' ELSE 'MAPPING NOT FOUND' END as DEAL_INSTRUMENT_CLASSIFICATION
      ,a.SPOT_TERM_CODE                                                                      as DEAL_SPOT_TERM_IND
      ,b.GT_AND_C_CODE                                                                       as DEAL_AGREEMENT_TYPE_DESCRIPTION
      ,a.VLDT_LEVEL                                                                          as HEADER_DEAL_STATUS
      ,a.CONTRACT_NUM                                                                        as PARENT_CONTRACT_NUMBER
      ,a.CONTRACT_NUM                                                                        as CONTRACT_NUMBER
      ,d.CHARGE_ACCT_NAME                                                                    as DEAL_BOOK_NAME
      ,c.CDTY_CTMT_SEQ_NUM                                                                   as DEAL_LEG_REFERENCE
      ,b.OWNER_BUY_SELL_IND                                                                  as BUY_SELL_FLAG
      ,c.VLDT_LEVEL                                                                          as SUB_LEG_DEAL_STATUS
      ,b.EXECUTION_TSTMP                                                                     as DEAL_EXECUTION_TIMESTAMP
      ,e.FINAL_PRCL_PRICE                                                                    as DEAL_PRICE
      ,CASE WHEN e.FIXED_PRICE <>'0' THEN 'FIXED'  ELSE 'FLOAT'  END                         as PRICING_TYPE
      ,f.FRML_NAME                                                                           as PRICING_COMPONENT
      ,f.PREMIUM_PRICE                                                                       as PREMIUM_FLOAT_SPREAD
      ,c.BT_FACTOR_NUM                                                                       as INDEX_FACTOR
      ,CASE WHEN e.FINAL_PRCL_PRICE <>'0' THEN 'KNOWN'  ELSE 'UNKNOWN'  END                  as PRICING_STATUS
      ,CASE WHEN c.WET_OR_DRY_IND = 'D' THEN k.PAYMENT_DATE ELSE m.SETTLEMENT_MADE_D END     as PRICE_SETTLE_DATE
      ,c.PRCL_SEQ_NUM                                                                        as DEAL_SUB_LEG_REFERENCE
      ,CASE WHEN c.DEAL_CLASS_CODE ='OPT' THEN c.OPT_SETL_TYPE_CODE 
      WHEN c.WET_OR_DRY_IND = 'W' THEN 'PHYSICAL' ELSE 'FINANCIAL'  END                      as SETTLEMENT_TYPE
      ,'NA'                                                                                  as DEAL_LINE_TEXT
      ,c.OPT_CALL_PUT_IND                                                                    as CALL_PUT_FLAG
      ,c.OPT_STRIKE_PRICE                                                                    as OPTION_STRIKE_PRICE
      ,e.FIXED_PRICE                                                                         as OPTION_PREMIUM_PRICE
      ,i.CURRENT_NAME                                                                        as VESSEL_NAME
      ,o.LOCATION_CODE                                                                       as DELIVERY_JUNCTION_NAME
      ,i.TRANSPORT_TYP_CODE                                                                  as TRANSPORT_TYP_CODE
      ,C.BOL_DATE                                                                            as BILL_OF_LADING_DATE
      ,a.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE1
      ,b.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE2
      ,c.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE3
      ,d.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE4
      ,e.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE5
      ,f.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE6
      ,g.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE7
      ,h.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE8
      ,i.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE9
      ,k.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE10
      ,j.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE11
      ,l.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE12
      ,m.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE13
      ,n.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE14 
      ,o.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE15
      FROM        STO_CONTRACT a
      JOIN        STO_CDTYCTMT b
      ON          a.CONTRACT_NUM = b.CONTRACT_NUM 
      AND         a.CONTRACT_CREATE_D = b.CONTRACT_CREATE_D
      JOIN        STO_PARCEL c
      ON          b.CONTRACT_NUM = c.CONTRACT_NUM 
      AND         b.CONTRACT_CREATE_D = c.CONTRACT_CREATE_D
      AND         b.CTMT_SEQ_NUM = c.CDTY_CTMT_SEQ_NUM
      AND         c.VLDT_LEVEL <> 'V'	
      LEFT JOIN   STO_CHRGACCT d 
      ON 	        a.OWNG_CHRG_ACCT_NUM = d.SEQUENCE_NUM 
      LEFT JOIN	STO_PRICING e
      ON	        c.PRCG_SEQ_NUM  = e.SEQUENCE_NUM
      LEFT JOIN	STO_PRCGTERM f 
      ON c.PRCG_SEQ_NUM = f.PRCG_SEQ_NUM
      AND f.SEQ_NUM = 1
      LEFT JOIN	STO_PRCLOPRN g 
      ON	        c.CONTRACT_NUM = g.CONTRACT_NUM
      AND 	    c.PRCL_SEQ_NUM = g.PRCL_SEQ_NUM
      LEFT JOIN	STO_VOYAGE h
      ON	        g.VOYAGE_SEQ_NUM  = h.SEQUENCE_NUM
      LEFT JOIN	STO_VESSEL i
      ON	        h.VESSEL_SEQ_NUM = i.SEQUENCE_NUM
      LEFT JOIN 	STO_BKOTPRCL j
      ON 	        c.CONTRACT_NUM  = j.CONTRACT_NUM
      AND         c.PRCL_SEQ_NUM  = j.PRCL_SEQ_NUM
      AND         c.CONTRACT_CREATE_D = j.CONTRACT_CREATE_D
        LEFT JOIN 	STO_BKOTCHN k 
      ON 	        j.REF_MNEM = k.REF_MNEM
      LEFT JOIN 	STO_PRCLFCST l
      ON 	        c.CONTRACT_NUM = l.CONTRACT_NUM
      AND         c.PRCL_SEQ_NUM = l.PRCL_SEQ_NUM
      AND         l.COST_TYPE_CODE = 'OIL' 
      AND         l.COST_CODE='OIL' 
      LEFT JOIN   STO_SETTLMNT m
      ON          l.SETTLEMENT_SEQ_NUM = m.SEQUENCE_NUM
      LEFT JOIN	STO_PRCLDCH n 
      ON          c.CONTRACT_NUM = n.CONTRACT_NUM
      AND         c.PRCL_SEQ_NUM = n.PRCL_SEQ_NUM 
      LEFT JOIN	STO_location o
      ON          n.LOC_SEQ_NUM = o.SEQUENCE_NUM
      WHERE 
      (
      a.LAST_UPDATE_TSTMP > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
      or 
      b.LAST_UPDATE_TSTMP > to_timestamp('{1}','yyyy-MM-dd HH:mm:ss')
      or
      c.LAST_UPDATE_TSTMP > to_timestamp('{2}','yyyy-MM-dd HH:mm:ss') 
      or
      d.LAST_UPDATE_TSTMP > to_timestamp('{3}','yyyy-MM-dd HH:mm:ss')
      or
      e.LAST_UPDATE_TSTMP > to_timestamp('{4}','yyyy-MM-dd HH:mm:ss')
      or
      f.LAST_UPDATE_TSTMP > to_timestamp('{5}','yyyy-MM-dd HH:mm:ss')
      or
      g.LAST_UPDATE_TSTMP > to_timestamp('{6}','yyyy-MM-dd HH:mm:ss')
      or
      h.LAST_UPDATE_TSTMP > to_timestamp('{7}','yyyy-MM-dd HH:mm:ss')
      or
      i.LAST_UPDATE_TSTMP > to_timestamp('{8}','yyyy-MM-dd HH:mm:ss')
      or
      j.LAST_UPDATE_TSTMP > to_timestamp('{9}','yyyy-MM-dd HH:mm:ss')
      or
      k.LAST_UPDATE_TSTMP > to_timestamp('{10}','yyyy-MM-dd HH:mm:ss')
      or
      l.LAST_UPDATE_TSTMP > to_timestamp('{11}','yyyy-MM-dd HH:mm:ss')
      or
      m.LAST_UPDATE_TSTMP > to_timestamp('{12}','yyyy-MM-dd HH:mm:ss')
      or
      n.LAST_UPDATE_TSTMP > to_timestamp('{13}','yyyy-MM-dd HH:mm:ss')
      or
      o.LAST_UPDATE_TSTMP > to_timestamp('{14}','yyyy-MM-dd HH:mm:ss')
      )
      """.format(last_watermark_contract,last_watermark_cdtyctmt,last_watermark_parcel,last_watermark_chrgacct,
                 last_watermark_pricing,last_watermark_prcgterm,last_watermark_prcloprn,last_watermark_voyage,
                  last_watermark_vessel,last_watermark_bkotprcl,last_watermark_bkotchn,last_watermark_prclfcst,
                    last_watermark_settlmnt,last_watermark_prcldch,last_watermark_location)      

      
      format = "delta"
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PARCEL', format, 'STO_PARCEL')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CONTRACT', format, 'STO_CONTRACT')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CHRGACCT', format, 'STO_CHRGACCT')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRICING', format, 'STO_PRICING')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCGTERM', format, 'STO_PRCGTERM')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CDTYCTMT', format, 'STO_CDTYCTMT')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLOPRN', format, 'STO_PRCLOPRN')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_VOYAGE', format, 'STO_VOYAGE')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_VESSEL', format, 'STO_VESSEL')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLDCH', format, 'STO_PRCLDCH')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_LOCATION', format, 'STO_LOCATION')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_BKOTPRCL', format, 'STO_BKOTPRCL')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_BKOTCHN', format, 'STO_BKOTCHN')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLFCST', format, 'STO_PRCLFCST')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_SETTLMNT', format, 'STO_SETTLMNT')     
      
      
      print("running sql DEAL_ATTRIBUTE_READ_SQL")
      
      df = spark.sql(DEAL_ATTRIBUTE_READ_SQL) 
      
      print("running sql DEAL_ATTRIBUTE_READ_SQL- count ", df.count())
      #df = df.withColumn("SOURCE_LAST_UPDATE", date_trunc("minute", col("SOURCE_LAST_UPDATE")))
      #dateformat = "YYYYMMDD"
      spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
      df = df.withColumn("PRICE_SETTLE_DATE",date_format(col("PRICE_SETTLE_DATE"),'yyyy-MM-dd'))
      df = df.withColumn('BILL_OF_LADING_DATE',date_format(col("BILL_OF_LADING_DATE"),'yyyy-MM-dd'))
      df = df.withColumn('DEAL_EXECUTION_TIMESTAMP',to_timestamp("DEAL_EXECUTION_TIMESTAMP", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE1',to_timestamp("SOURCE_LAST_DATE1", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE2',to_timestamp("SOURCE_LAST_DATE2", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE3',to_timestamp("SOURCE_LAST_DATE3", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE4',to_timestamp("SOURCE_LAST_DATE4", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE5',to_timestamp("SOURCE_LAST_DATE5", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE6',to_timestamp("SOURCE_LAST_DATE6", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE7',to_timestamp("SOURCE_LAST_DATE7", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE8',to_timestamp("SOURCE_LAST_DATE8", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE9',to_timestamp("SOURCE_LAST_DATE9", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE10',to_timestamp("SOURCE_LAST_DATE10", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE11',to_timestamp("SOURCE_LAST_DATE11", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE12',to_timestamp("SOURCE_LAST_DATE12", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE13',to_timestamp("SOURCE_LAST_DATE13", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE14',to_timestamp("SOURCE_LAST_DATE14", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn('SOURCE_LAST_DATE15',to_timestamp("SOURCE_LAST_DATE15", "yyyy-MM-dd HH:mm:ss"))
      df = df.withColumn("SOURCE_LAST_DATE1", date_trunc("minute", col("SOURCE_LAST_DATE1")))
      df = df.withColumn("SOURCE_LAST_DATE2", date_trunc("minute", col("SOURCE_LAST_DATE2")))
      df = df.withColumn("SOURCE_LAST_DATE3", date_trunc("minute", col("SOURCE_LAST_DATE3")))
      df = df.withColumn("SOURCE_LAST_DATE4", date_trunc("minute", col("SOURCE_LAST_DATE4")))
      df = df.withColumn("SOURCE_LAST_DATE5", date_trunc("minute", col("SOURCE_LAST_DATE5")))
      df = df.withColumn("SOURCE_LAST_DATE6", date_trunc("minute", col("SOURCE_LAST_DATE6")))
      df = df.withColumn("SOURCE_LAST_DATE7", date_trunc("minute", col("SOURCE_LAST_DATE7")))
      df = df.withColumn("SOURCE_LAST_DATE8", date_trunc("minute", col("SOURCE_LAST_DATE8")))
      df = df.withColumn("SOURCE_LAST_DATE9", date_trunc("minute", col("SOURCE_LAST_DATE9")))
      df = df.withColumn("SOURCE_LAST_DATE10", date_trunc("minute", col("SOURCE_LAST_DATE10")))
      df = df.withColumn("SOURCE_LAST_DATE11", date_trunc("minute", col("SOURCE_LAST_DATE11")))
      df = df.withColumn("SOURCE_LAST_DATE12", date_trunc("minute", col("SOURCE_LAST_DATE12")))
      df = df.withColumn("SOURCE_LAST_DATE13", date_trunc("minute", col("SOURCE_LAST_DATE13")))
      df = df.withColumn("SOURCE_LAST_DATE14", date_trunc("minute", col("SOURCE_LAST_DATE14")))
      df = df.withColumn("SOURCE_LAST_DATE15", date_trunc("minute", col("SOURCE_LAST_DATE15")))
      df = df.withColumn("DEAL_EXECUTION_TIMESTAMP", date_trunc("minute", col("DEAL_EXECUTION_TIMESTAMP")))
      df.show(20,False)
      
      print ("Running enricher")
      df = DealAttributeenrich(spark,df,SOURCE_ETRM)
      print ("Running enricher - DOne")
      df.show(20,False)
      df.printSchema()
      return  (df,metricDict)
      
