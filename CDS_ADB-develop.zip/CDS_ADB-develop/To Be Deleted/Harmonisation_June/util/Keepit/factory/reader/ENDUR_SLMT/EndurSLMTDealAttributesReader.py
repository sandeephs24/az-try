# Databricks notebook source
# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../enricher/DealAttributeEnricher

# COMMAND ----------

class EndurSLMTDealAttributesReader(SourceDatasetReader):
    
   def read(spark,metricDict, initial_load):
      
      SOURCE_ETRM = 'ENDUR_SLMT'
      
      last_watermark_ab_tran = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'AB_TRAN','DIM_DEAL_ATTRIBUTES')
      last_watermark_ab_tran = last_watermark_ab_tran[0:19]
      
      if initial_load == "Y":
        tran_status_list = "3,4,5"
        date_attribute = "input_date"
      else:
        tran_status_list = "3,5"
        date_attribute = "last_update"
      
      SQL = """
      select distinct
       a.deal_tracking_num as SRC_SYS_DEAL_HEADER_KEY
      ,a.deal_tracking_num||'_'||a.ins_num||'_'||d.param_seq_num as SRC_SYS_DEAL_LEG_KEY
      ,a.deal_tracking_num||'_'||a.ins_num||'_'||d.param_seq_num||'_'||d.profile_seq_num as SRC_SYS_DEAL_SUB_LEG_KEY
      ,t.name                                       as SRC_SYSTEM_DEAL_TYPE_CODE      
      ,b.name                                       as SRC_SYSTEM_DEAL_SUBTYPE_CODE
      ,case when a.buy_sell=0 then 'Buy'
	   when a.buy_sell=1 then 'Sell'
	   when a.buy_sell IN (4,5) and f.PAY_REC=1 then 'Sell'
	   when a.buy_sell IN (4,5) and f.PAY_REC=0 then 'Buy'
	   else 'UNKNOWN' END DEAL_HEADER_BUY_SELL_FLAG
      ,'N/A'                                        as DEAL_SPOT_TERM_IND
      ,agr.agreement_name                           as DEAL_AGREEMENT_TYPE_DESCRIPTION
      ,k.name                                       as HEADER_DEAL_STATUS
      ,a.deal_tracking_num                          as PARENT_CONTRACT_NUMBER        
      ,a.tran_num                                   as CONTRACT_NUMBER
      ,c.long_name                                  as DEAL_BOOK_NAME
      ,a.ins_num||'_'||d.param_seq_num              as DEAL_LEG_REFERENCE
      ,case when a.buy_sell=0 then 'Buy'
	   when a.buy_sell=1 then 'Sell'
	   when a.buy_sell IN (4,5) and f.PAY_REC=1 then 'Sell'
	   when a.buy_sell IN (4,5) and f.PAY_REC=0 then 'Buy'
	   else 'UNKNOWN' END DEAL_LEG_BUY_SELL_FLAG
      ,k.name                                       as SUB_LEG_DEAL_STATUS      
      ,a.trade_time                                 as DEAL_EXECUTION_TIMESTAMP
      ,d.rate                                       as DEAL_PRICE
      ,ff.name                                      as PRICING_TYPE
      ,pi.index_name                                as PRICING_COMPONENT
      ,D.FLOAT_SPREAD                               as PREMIUM_FLOAT_SPREAD
      ,D.INDEX_MULTIPLIER                           as INDEX_FACTOR
      ,vs.name                                      as PRICING_STATUS
      ,D.RATE_DTMN_DATE                             as PRICE_SETTLE_DATE 
      ,a.ins_num||'_'||d.param_seq_num||'_'||d.profile_seq_num as DEAL_SUB_LEG_REFERENCE
      ,g.name                                           as SETTLEMENT_TYPE 
      ,a.reference                                   as DEAL_LINE_TEXT        
      ,pc.name                                       as CALL_PUT_FLAG      
      ,l.strike                                      as OPTION_STRIKE_PRICE
      ,CASE WHEN nvl(PNL.RST_CASH_FLOW_TYPE_ID, 0) = 4 THEN Abs(Round(PNL.RST_PRICE*PNL.RST_VOLUME, 4)) ELSE 0.0 END as OPTION_PREMIUM_PRICE
      ,'N/A'                                         as VESSEL_NAME
      ,gpl2.location_name                            as DELIVERY_JUNCTION_NAME
      ,PIPE.PIPELINE_NAME                            as DELIVERY_METHOD_NAME
      ,a.last_update                                 as SOURCE_LAST_DATE1
      ,'N/A'                                            as BILL_OF_LADING_DATE
      from ab_tran a  
      join INSTRUMENTS b on a.ins_type = b.id_number
      join TOOLSETS t on a.toolset = T.ID_NUMBER
      join PORTFOLIO c on a.internal_portfolio = c.id_number
      join INS_PARAMETER f on a.ins_num = f.ins_num
      join PROFILE d on f.param_seq_num = d.param_seq_num and f.ins_num = d.ins_num
      JOIN SETTLE_TYPE g ON          g.id_number =f.settlement_type  
      join TRANS_STATUS k on a.tran_status = k.trans_status_id
      left join INS_OPTION l on f.ins_num = l.ins_num and f.param_seq_num = l.param_seq_num and OPTION_SEQ_NUM = 0
      LEFT JOIN	gas_phys_param gpp 
      ON	gpp.ins_num = f.ins_num 
      AND	gpp.param_seq_num = f.param_seq_num     
      LEFT JOIN	gas_phys_location gpl 
      ON	GPP.LOCATION_ID = GPL.LOCATION_ID     
      LEFT JOIN	gas_phys_pipelines pipe 
      ON	PIPE.PIPELINE_ID = GPL.PIPELINE_ID
      LEFT JOIN	gas_phys_location ic 
      ON	GPL.INTERCONNECT_LOC_ID = ic.location_id
      join buy_sell bs on BS.ID_NUMBER = a.buy_sell
      LEFT JOIN	PUT_CALL pc 
      ON	L.PUT_CALL = PC.ID_NUMBER     

      join FX_FLT ff on FF.ID_NUMBER = F.FX_FLT
      left join PARAM_RESET_HEADER prh on f.ins_num = prh.ins_num and f.param_seq_num = prh.param_seq_num and PARAM_RESET_HEADER_SEQ_NUM = 0
      LEFT JOIN          idx_def pi ON     PI.INDEX_ID = prh.proj_index AND pi.validated = 1 AND PARAM_RESET_HEADER_SEQ_NUM = 0 and PI.DB_STATUS = 1 
      JOIN          value_status vs ON                 VS.ID_NUMBER = d.rate_status
      LEFT JOIN            AB_TRAN_AGREEMENT ag ON                 AG.TRAN_NUM = a.tran_num     
      LEFT JOIN            party_agreement pa ON                 AG.PARTY_AGREEMENT_ID = PA.PARTY_AGREEMENT_ID     
      LEFT JOIN            agreement agr ON                 PA.AGREEMENT_ID = AGR.AGREEMENT_ID
    left join (
    select REPORT_DATE,DEAL_NUM,TRAN_NUM,RST_CASH_FLOW_TYPE_ID,
    RST_PRICE,RST_VOLUME from
    (
    select PNL.REPORT_DATE,
    DEAL_NUM,
    PNL.TRAN_NUM,
    PNL.RST_CASH_FLOW_TYPE_ID,
    PNL.RST_PRICE,
    PNL.RST_VOLUME,
    row_number()
    over (Partition by DEAL_NUM,TRAN_NUM
    order by REPORT_DATE DESC)
    row_num
    from USER_DW_DEAL_INFORMATION PNL
    where RST_CASH_FLOW_TYPE_ID=4
    and  PNL.OPTION_TYPE IS NOT NULL
    ) where row_num=1
    ) PNL
    ON PNL.DEAL_NUM=a.deal_tracking_num
    AND A.TRAN_NUM=PNL.TRAN_NUM
    LEFT JOIN ( SELECT SCHEDULE_ID,INS_NUM,PARAM_SEQ_NUM,PROFILE_SEQ_NUM,LOCATION_ID FROM
( SELECT DL.SCHEDULE_ID,
DL.INS_NUM,
DL.PARAM_SEQ_NUM,
DL.PROFILE_SEQ_NUM,
DL.LOCATION_ID,
ROW_NUMBER()
OVER (PARTITION BY INS_NUM,PARAM_SEQ_NUM,PROFILE_SEQ_NUM ORDER BY SCHEDULE_ID DESC)
row_num
FROM COMM_SCHEDULE_HEADER DL
) WHERE row_num=1
) DL
ON A.INS_NUM = DL.INS_NUM
AND D.PARAM_SEQ_NUM=DL.PARAM_SEQ_NUM
AND D.PROFILE_SEQ_NUM=DL.PROFILE_SEQ_NUM
    left join gas_phys_location gpl2
    on DL.location_id=gpl2.location_id
    where   a.tran_status in ( {1})
and     a.tran_type = 0
and     a.current_flag = 1    
AND (
		(b.name in('COMM-BEACH-SWAP',
'COMM-BEACH-SWAP-HUB',
'COMM-CASH-FLOW',
'COMM-FUEL',
'COMM-NGL',
'COMM-PHYS-CRUDE',
'COMM-PHYS-IDX',
'COMM-PHYS-NGL',
'COMM-PHYS-TERMINAL',
'COMM-PRODUCTION',
'COMM-RETRO',
'GAS',
'GAS-FOR-NGL',
'GASGDA',
'GASPHYSBASIS',
'COMM-LOCATION-SWAP',
'COMM-PHYS-AGG',
'COMM-PHYS-AGG-TERMINAL',
'COMM-PHYS-BORROW',
'COMM-TIME-SWAP',
'GASIDX',
'RENEWABLE-PHYS','COMM-PHYS')
		and gpp.ins_num is not null and f.settlement_type=2)
				
			OR
		
		(b.name not in ('COMM-BEACH-SWAP','COMM-BEACH-SWAP-HUB','COMM-CASH-FLOW','COMM-FUEL','COMM-NGL',
'COMM-PHYS-CRUDE','COMM-PHYS-IDX','COMM-PHYS-NGL','COMM-PHYS-TERMINAL','COMM-PRODUCTION',
'COMM-RETRO','GAS','GAS-FOR-NGL','GASGDA','GASPHYSBASIS','COMM-LOCATION-SWAP','COMM-PHYS-AGG',
'COMM-PHYS-AGG-TERMINAL','COMM-PHYS-BORROW','COMM-TIME-SWAP','GASIDX','RENEWABLE-PHYS','COMM-PHYS'))
        and a.{2} > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
		AND b.name not in ('CASH',
'COMM-BAL-POSTING',
'COMM-BAL-POSTING-OFFSET',
'COMM-FEE',
'COMM-IMB',
'COMM-PAL',
'COMM-PAL-SETTLEMENT',
'COMM-PHYS-FEES',
'COMM-PHYS-TRANSPORT',
'COMM-STOR',
'COMM-TRANS',
'COMM-TRANSIT',
'COMM-TRANS-SETTLEMENT',
'PWR-FEE',
'RENEWABLE-INVENTORY',
'COMM-BAL-ACCTNG-IMPACT',
'COMM-BANKGAS-BAL-POSTING',
'COMM-IMBALANCE-CASHOUT',
'COMM-INV-NATGAS',
'COMM-IUK-INV-ADJ',
'COMM-NGL-VIRTUAL',
'COMM-PPA',
'COMM-STOR-BAL',
'COMM-TRANSIT-NGL',
'COMM-VIRTUAL-SWAP',
'LNG-MARGIN-XFER-DIV',
'LNG-MARGIN-XFER-EL','CAP-ENTRY',
'CAP-EXIT','COMM-TRANS-FORECAST')
	)
      """.format(last_watermark_ab_tran, tran_status_list,date_attribute)
      
      loadDatasetConfigsEndurSLMTDealAttributes(spark,SOURCE_ETRM)
      df = spark.sql(SQL)
        
      return (df,metricDict)
     
      
  

# COMMAND ----------

def loadDatasetConfigsEndurSLMTDealAttributes(spark, SOURCE_ETRM):
    format = "delta"
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'AB_TRAN', format, 'AB_TRAN') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'INSTRUMENTS', "parquet", 'INSTRUMENTS') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'TOOLSETS', "parquet", 'TOOLSETS') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PORTFOLIO', "parquet", 'PORTFOLIO') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'INS_PARAMETER', format, 'INS_PARAMETER') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PROFILE', format, 'PROFILE') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'SETTLE_TYPE', "parquet", 'SETTLE_TYPE') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'TRANS_STATUS', "parquet", 'TRANS_STATUS') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'INS_OPTION', "parquet", 'INS_OPTION') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'GAS_PHYS_PARAM', format, 'GAS_PHYS_PARAM') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'GAS_PHYS_LOCATION', "parquet", 'GAS_PHYS_LOCATION') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'GAS_PHYS_PIPELINES', "parquet", 'GAS_PHYS_PIPELINES') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'BUY_SELL', "parquet", 'BUY_SELL')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PUT_CALL', "parquet", 'PUT_CALL')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'FX_FLT', "parquet", 'FX_FLT')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PARAM_RESET_HEADER', format, 'PARAM_RESET_HEADER')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'VALUE_STATUS', "parquet", 'VALUE_STATUS')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'AB_TRAN_AGREEMENT', format, 'AB_TRAN_AGREEMENT')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PARTY_AGREEMENT', "parquet", 'PARTY_AGREEMENT')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'AGREEMENT', "parquet", 'AGREEMENT')  
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'IDX_DEF', "parquet", 'IDX_DEF') 
    readDatasetConfigAndCreateTempView(spark, SOURCE_ETRM, 'USER_DW_DEAL_INFORMATION', format, 'USER_DW_DEAL_INFORMATION')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'COMM_SCHEDULE_HEADER', format, 'COMM_SCHEDULE_HEADER')
    
