# Databricks notebook source
# MAGIC %run ./../../enricher/CurrencyMappingEnricher

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class EndurSLMTCurrencyReader(SourceDatasetReader):
    
    def read(spark,metricDict):
        SOURCE_ETRM = 'ENDUR_SLMT'
      
        CURRENCY_READER_SQL = """
        select 
        c.id_number as SRC_SYS_CURRENCY_NK,
        c.name as CURRENCY_CODE
        from CURRENCY c 
        """
        
        
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'CURRENCY', 'parquet', 'CURRENCY')
     
        df = spark.sql(CURRENCY_READER_SQL)
        df = enrich(spark,df, SOURCE_ETRM)
        return (df,metricDict)
