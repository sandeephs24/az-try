# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../enricher/DealAttributeEnricher

# COMMAND ----------

class EndurGPNATestHarnessDealAttributesReader(SourceDatasetReader):
    
   def read(spark, metricDict, initial_load):

      df = executeJdbcQueryAndReturnDF("select * from tsa_curated.hardcoded_deal_attributes_reader_endur_gpna")
      df.createOrReplaceTempView("hardcoded_deal_attributes_reader")
      df.printSchema()
      #df = DealAttributeenrich(spark,df,SOURCE_ETRM)
      return (df, metricDict);
      
  
