# Databricks notebook source
# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../enricher/InternalPartyEmptyEnricher

# COMMAND ----------

# MAGIC %run ./../../enricher/PartyGoldTierEnricher

# COMMAND ----------

class AligneCounterPartyReader(SourceDatasetReader):
     
    def read(spark,metricDict):
        
        SOURCE_ETRM = 'ALIGNE'
      
        #last_watermark_party = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_CHRGACCT','DIM_PARTY')
        #last_watermark_party = last_watermark_party[0:19]
        
        df = executeJdbcQueryAndReturnDF("select src_sys_party_nk from tsa_curated.dim_party where src_sys_name = '{0}'".format(SOURCE_ETRM))
        df.createOrReplaceTempView("CURATED_DIM_PARTY")
        
        
                    
        INTERNAL_PARTY_READER_SQL = """ 
            SELECT SRC_SYS_PARTY_NK,SRC_SYS_PARTY_SHORT_NAME,SRC_SYS_PARTY_LONG_NAME,PARTY_TYPE,SRC_SYS_LEGAL_ENTITY_NK,SRC_SYS_LEGAL_ENTITY_NAME, CPTY_ACCT, CPTY_TYPE,SOURCE_LAST_UPDATE
              FROM
              (SELECT DISTINCT
              SC.CPTY_CPTY AS SRC_SYS_PARTY_NK,
              SC.CPTY_CPTY AS SRC_SYS_PARTY_SHORT_NAME,
              SC.CPTY_DSC AS SRC_SYS_PARTY_LONG_NAME,
              'INTERNAL' AS PARTY_TYPE,
              SC.CPTY_PARENT AS SRC_SYS_LEGAL_ENTITY_NK,
              SC2.CPTY_DSC AS SRC_SYS_LEGAL_ENTITY_NAME,
              SC.CPTY_ACCT AS CPTY_ACCT,
              SC.CPTY_TYPE AS CPTY_TYPE,
              '1900-01-01 00:00:00' AS SOURCE_LAST_UPDATE,
              row_number() over (Partition by SC.CPTY_CPTY ORDER BY SC.CPTY_ADATE1 DESC) row_num
              FROM STATIC_CPTY SC
              LEFT JOIN STATIC_CPTY SC2
              ON SC.CPTY_PARENT = SC2.CPTY_CPTY
              )
              WHERE row_num = 1
              AND
              ((CPTY_ACCT LIKE 'A%' OR CPTY_ACCT LIKE 'G%' OR CPTY_ACCT LIKE 'C%' OR CPTY_ACCT LIKE 'U%')
              AND CPTY_TYPE = 'C'
              OR CPTY_TYPE = 'M')
              UNION
              SELECT DISTINCT
              HC.HOUSE_ID AS SRC_SYS_PARTY_NK,
              HC.HOUSE_ID AS SRC_SYS_PARTY_SHORT_NAME,
              HC.HOUSE_FULLNAME AS SRC_SYS_PARTY_LONG_NAME,
              'INTERNAL' AS PARTY_TYPE,
              'UNKNOWN' AS SRC_SYS_LEGAL_ENTITY_NK,
              'UNKNOWN' AS SRC_SYS_LEGAL_ENTITY_NAME,
              'UNKNOWN' AS CPTY_ACCT,
              'UNKNOWN' AS CPTY_TYPE,
              '1900-01-01 00:00:00' AS SOURCE_LAST_UPDATE
              FROM STATIC_HOUSE HC
              WHERE HOUSE_ID IN (SELECT DISTINCT HOUSE_ID FROM STATIC_HOUSE MINUS SELECT DISTINCT CPTY_CPTY FROM STATIC_CPTY)
             """
    
        EXTERNAL_PARTY_READER_SQL = """
        SELECT *
FROM 
(
             SELECT SRC_SYS_PARTY_NK,SRC_SYS_PARTY_SHORT_NAME,SRC_SYS_PARTY_LONG_NAME,PARTY_TYPE,SRC_SYS_LEGAL_ENTITY_NK,SRC_SYS_LEGAL_ENTITY_NAME,CPTY_ACCT,CPTY_TYPE,SOURCE_LAST_UPDATE
          FROM
          (SELECT DISTINCT
          SC.CPTY_CPTY AS SRC_SYS_PARTY_NK,
          SC.CPTY_CPTY AS SRC_SYS_PARTY_SHORT_NAME,
          SC.CPTY_DSC AS SRC_SYS_PARTY_LONG_NAME,
          'EXTERNAL' AS PARTY_TYPE,
          SC.CPTY_PARENT AS SRC_SYS_LEGAL_ENTITY_NK,
          SC2.CPTY_DSC AS SRC_SYS_LEGAL_ENTITY_NAME,
          '1900-01-01 00:00:00' AS SOURCE_LAST_UPDATE,
          SC.CPTY_ACCT AS CPTY_ACCT,
          SC.CPTY_TYPE AS CPTY_TYPE,
          row_number() over (Partition by SC.CPTY_CPTY ORDER BY SC.CPTY_ADATE1 DESC) row_num
          FROM STATIC_CPTY SC
          LEFT JOIN     STATIC_CPTY SC2
          ON   SC.CPTY_PARENT = SC2.CPTY_CPTY
          )
          WHERE row_num=1
          AND (CPTY_ACCT NOT IN (
          SELECT SC.CPTY_ACCT FROM STATIC_CPTY SC WHERE (SC.CPTY_ACCT LIKE 'A%' OR SC.CPTY_ACCT LIKE 'G%' OR SC.CPTY_ACCT LIKE 'C%' OR SC.CPTY_ACCT LIKE 'U%') AND (SC.CPTY_TYPE = 'C') )
          AND CPTY_TYPE NOT IN ('M', 'B') )
          UNION
SELECT SRC_SYS_PARTY_NK,SRC_SYS_PARTY_SHORT_NAME,SRC_SYS_PARTY_LONG_NAME,PARTY_TYPE,SRC_SYS_LEGAL_ENTITY_NK,SRC_SYS_LEGAL_ENTITY_NAME,CPTY_ACCT,CPTY_TYPE,SOURCE_LAST_UPDATE
FROM
(SELECT DISTINCT
SC.CPTY_CPTY AS SRC_SYS_PARTY_NK,
SC.CPTY_CPTY AS SRC_SYS_PARTY_SHORT_NAME,
SC.CPTY_DSC AS SRC_SYS_PARTY_LONG_NAME,
'EXTERNAL' AS PARTY_TYPE,
SC.CPTY_PARENT AS SRC_SYS_LEGAL_ENTITY_NK,
SC2.CPTY_DSC AS SRC_SYS_LEGAL_ENTITY_NAME,
'1900-01-01 00:00:00' AS SOURCE_LAST_UPDATE,
SC.CPTY_ACCT AS CPTY_ACCT,
SC.CPTY_TYPE AS CPTY_TYPE,
row_number() over (Partition by SC.CPTY_CPTY ORDER BY SC.CPTY_ADATE1 DESC) row_num
FROM STATIC_CPTY SC
LEFT JOIN STATIC_CPTY SC2
ON SC.CPTY_PARENT = SC2.CPTY_CPTY
)
WHERE row_num=1
AND (CPTY_TYPE = 'C' and CPTY_ACCT IS NULL))where SRC_SYS_PARTY_NK <>'ENERJI'

                """
        
        
        format = "parquet"
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_CPTY', format, 'STATIC_CPTY')
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_HOUSE', format, 'STATIC_HOUSE')
               
             
        
        
        dfInternal = spark.sql(INTERNAL_PARTY_READER_SQL)
                
        dfInternal = dfInternal.drop("CPTY_ACCT","CPTY_TYPE")        
        
        dfExternal = spark.sql(EXTERNAL_PARTY_READER_SQL)
        
        df1 = enrichInternalParty(dfInternal)
        spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
        df1 = df1.withColumn("NEXT_ENHANCED_MONITORING_REQUIRED_DATE",to_date(col("NEXT_ENHANCED_MONITORING_REQUIRED_DATE"),"yyyy-MM-dd"))
        df1 = df1.withColumn("KYC_NEXT_REVIEW_DATE",to_date(col("KYC_NEXT_REVIEW_DATE"),"yyyy-MM-dd"))
        df1 = df1.withColumn("KYC_LAST_REVIEW_DATE",to_date(col("KYC_LAST_REVIEW_DATE"),"yyyy-MM-dd"))
        df1 = df1.withColumn("SOURCE_LAST_UPDATE",to_timestamp(col("SOURCE_LAST_UPDATE")))
        df2 = enrichExternalParty(spark,dfExternal,SOURCE_ETRM)
        df2 = df2.withColumn("NEXT_ENHANCED_MONITORING_REQUIRED_DATE",to_date(col("NEXT_ENHANCED_MONITORING_REQUIRED_DATE"),"yyyy-MM-dd"))
        df2 = df2.withColumn("KYC_NEXT_REVIEW_DATE",to_date(col("KYC_NEXT_REVIEW_DATE"),"yyyy-MM-dd"))
        df2 = df2.withColumn("KYC_LAST_REVIEW_DATE",to_date(col("KYC_LAST_REVIEW_DATE"),"yyyy-MM-dd"))
        df2 = df2.withColumn("SOURCE_LAST_UPDATE",to_timestamp(col("SOURCE_LAST_UPDATE")))
        
        
        totalDf = df1.union(df2)
      
        return (totalDf,metricDict)
        
