# Databricks notebook source
# MAGIC %run ./DexDealAttributesReader

# COMMAND ----------

def getDealAttrReaderSQLDay0_X(spark , SOURCE_ETRM):
   
  DEAL_ATTRIBUTE_READ_SQL = """
  select DEAL_PRICE from (
  select distinct a.TRDG_COMP_MNEM||'_'||a.CONTRACT_NUM||'_'||date_format(a.CONTRACT_CREATE_D,'yyyyMMdd')  as SRC_SYS_DEAL_HEADER_KEY
  ,b.TRDG_COMP_MNEM||'_'||b.CONTRACT_NUM||'_'|| date_format(a.CONTRACT_CREATE_D,'yyyyMMdd') ||'_'||b.CTMT_SEQ_NUM as SRC_SYS_DEAL_LEG_KEY
  ,c.TRDG_COMP_MNEM||'_'||c.CONTRACT_NUM||'_'||date_format(a.CONTRACT_CREATE_D,'yyyyMMdd')||'_'||c.CDTY_CTMT_SEQ_NUM||'_'||
  c.PRCL_SEQ_NUM as SRC_SYS_DEAL_SUB_LEG_KEY
  ,c.DEAL_CLASS_CODE                                                                     as SRC_SYSTEM_DEAL_TYPE_CODE      
  ,c.DEAL_TYPE_CODE                                                                      as SRC_SYSTEM_DEAL_SUBTYPE_CODE      
  ,CASE WHEN c.DEAL_CLASS_CODE = 'EXE' THEN 'SWAP' WHEN c.DEAL_CLASS_CODE = 'OPT' THEN 'OPTION' 
  WHEN c.DEAL_CLASS_CODE = 'FUT' THEN 'FUTURE' WHEN c.DEAL_CLASS_CODE = 'FWD' THEN 'FORWARD'
  WHEN c.DEAL_CLASS_CODE = 'WET' THEN 'WET' 
  WHEN c.DEAL_CLASS_CODE = 'NULL' THEN 'NULL AT SOURCE' ELSE 'MAPPING NOT FOUND' END as DEAL_INSTRUMENT_CLASSIFICATION
  ,a.SPOT_TERM_CODE                                                                      as DEAL_SPOT_TERM_IND
  ,b.GT_AND_C_CODE                                                                       as DEAL_AGREEMENT_TYPE_DESCRIPTION
  ,a.VLDT_LEVEL                                                                          as HEADER_DEAL_STATUS
  ,a.CONTRACT_NUM                                                                        as PARENT_CONTRACT_NUMBER
  ,a.CONTRACT_NUM                                                                        as CONTRACT_NUMBER
  ,d.CHARGE_ACCT_NAME                                                                    as DEAL_BOOK_NAME
  ,c.CDTY_CTMT_SEQ_NUM                                                                   as DEAL_LEG_REFERENCE
  ,b.OWNER_BUY_SELL_IND                                                                  as BUY_SELL_FLAG
  ,c.VLDT_LEVEL                                                                          as SUB_LEG_DEAL_STATUS
  ,b.EXECUTION_TSTMP                                                                     as DEAL_EXECUTION_TIMESTAMP
  ,e.FINAL_PRCL_PRICE                                                                 as DEAL_PRICE
  ,CASE WHEN e.FIXED_PRICE <>'0' THEN 'FIXED'  ELSE 'FLOAT'  END                         as PRICING_TYPE
  ,f.FRML_NAME                                                                           as PRICING_COMPONENT
  ,f.PREMIUM_PRICE                                                                       as PREMIUM_FLOAT_SPREAD
  ,c.BT_FACTOR_NUM                                                                       as INDEX_FACTOR
  ,CASE WHEN e.FINAL_PRCL_PRICE <>'0' THEN 'KNOWN'  ELSE 'UNKNOWN'  END                  as PRICING_STATUS
  ,CASE WHEN c.WET_OR_DRY_IND = 'D' THEN k.PAYMENT_DATE ELSE m.SETTLEMENT_MADE_D END     as PRICE_SETTLE_DATE
  ,c.PRCL_SEQ_NUM                                                                        as DEAL_SUB_LEG_REFERENCE
  ,CASE WHEN c.DEAL_CLASS_CODE ='OPT' THEN c.OPT_SETL_TYPE_CODE 
  WHEN c.WET_OR_DRY_IND = 'W' THEN 'PHYSICAL' ELSE 'FINANCIAL'  END                      as SETTLEMENT_TYPE
  ,'NA'                                                                                  as DEAL_LINE_TEXT
  ,c.OPT_CALL_PUT_IND                                                                    as CALL_PUT_FLAG
  ,c.OPT_STRIKE_PRICE                                                                    as OPTION_STRIKE_PRICE
  ,e.FIXED_PRICE                                                                         as OPTION_PREMIUM_PRICE
  ,i.CURRENT_NAME                                                                        as VESSEL_NAME
  ,o.LOCATION_CODE                                                                       as DELIVERY_JUNCTION_NAME
  ,i.TRANSPORT_TYP_CODE                                                                  as TRANSPORT_TYP_CODE
  ,C.BOL_DATE                                                                            as BILL_OF_LADING_DATE
  ,a.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE1
  ,b.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE2
  ,c.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE3
  ,d.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE4
  ,e.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE5
  ,f.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE6
  ,g.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE7
  ,h.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE8
  ,i.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE9
  ,k.LAST_UPDATE_TSTMP1                                                                   as SOURCE_LAST_DATE10
  ,k.LAST_UPDATE_TSTMP2                                                                   as SOURCE_LAST_DATE11
  ,l.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE12
  ,m.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE13
  ,n.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE14 
  ,o.LAST_UPDATE_TSTMP                                                                   as SOURCE_LAST_DATE15
  FROM        STO_CONTRACT a
  JOIN        STO_CDTYCTMT b
  ON          a.CONTRACT_NUM = b.CONTRACT_NUM 
  AND         a.CONTRACT_CREATE_D = b.CONTRACT_CREATE_D
  JOIN        STO_PARCEL c
  ON          b.CONTRACT_NUM = c.CONTRACT_NUM 
  AND         b.CTMT_SEQ_NUM = c.CDTY_CTMT_SEQ_NUM
  AND         b.CONTRACT_CREATE_D = c.CONTRACT_CREATE_D
  AND         c.VLDT_LEVEL <> 'V'
  LEFT JOIN   STO_CHRGACCT d 
  ON          a.OWNG_CHRG_ACCT_NUM = d.SEQUENCE_NUM 
  LEFT JOIN   STO_PRICING e
  ON          c.PRCG_SEQ_NUM  = e.SEQUENCE_NUM
  LEFT JOIN   (

  select  f1.* 
  ,row_number() OVER(PARTITION BY f1.prcg_seq_num
  ORDER BY f1.WEIGHTING_PC desc,SEQ_NUM asc) row_num
  from    STO_PRCGTERM f1 
  ) f
  ON          c.PRCG_SEQ_NUM = f.PRCG_SEQ_NUM
  AND         f.row_num = 1
  LEFT JOIN   STO_PRCLOPRN g 
  ON          c.CONTRACT_NUM = g.CONTRACT_NUM
  AND         c.PRCL_SEQ_NUM = g.PRCL_SEQ_NUM
  LEFT JOIN   (select SEQUENCE_NUM,VESSEL_SEQ_NUM,LAST_UPDATE_TSTMP
  from(
  select
  SEQUENCE_NUM,VESSEL_SEQ_NUM,LAST_UPDATE_TSTMP, row_number()
  over(partition by SEQUENCE_NUM order by SEQUENCE_NUM) row_num
  from
  STO_VOYAGE
  ) where row_num = 1) h
  ON          g.VOYAGE_SEQ_NUM  = h.SEQUENCE_NUM
  LEFT JOIN	STO_VESSEL i
  ON	        h.VESSEL_SEQ_NUM = i.SEQUENCE_NUM
  LEFT JOIN   (
  SELECT  j1.CONTRACT_NUM 
  ,j1.PRCL_SEQ_NUM
  ,j1.CONTRACT_CREATE_D
  ,j2.PAYMENT_DATE
  ,j1.LAST_UPDATE_TSTMP LAST_UPDATE_TSTMP1
  ,j1.LAST_UPDATE_TSTMP LAST_UPDATE_TSTMP2
  ,row_number() OVER(PARTITION BY j1.CONTRACT_NUM, j1.PRCL_SEQ_NUM, j1.CONTRACT_CREATE_D
  ORDER BY j2.PAYMENT_DATE desc) row_num
  FROM    STO_BKOTPRCL j1
  JOIN STO_BKOTCHN j2 
  ON      j1.REF_MNEM = j2.REF_MNEM
  ) k
  ON          c.CONTRACT_NUM  = k.CONTRACT_NUM
  AND         c.PRCL_SEQ_NUM  = k.PRCL_SEQ_NUM
  AND         c.CONTRACT_CREATE_D = k.CONTRACT_CREATE_D
  AND         k.row_num = 1
  LEFT JOIN (
  select  y.* 
  ,row_number() OVER(PARTITION BY y.CONTRACT_NUM, y.PRCL_SEQ_NUM
  ORDER BY y.SETTLEMENT_SEQ_NUM desc) row_num
  from    STO_PRCLFCST y
  where   y.COST_TYPE_CODE = 'OIL' 
  and     y.COST_CODE='OIL' 
  ) l
  ON          a.CONTRACT_NUM = l.CONTRACT_NUM
  AND         c.PRCL_SEQ_NUM = l.PRCL_SEQ_NUM
  AND         l.row_num = 1
  LEFT JOIN   STO_SETTLMNT m
  ON          l.SETTLEMENT_SEQ_NUM = m.SEQUENCE_NUM
  LEFT JOIN  STO_PRCLDCH n 
  on          c.CONTRACT_NUM = n.CONTRACT_NUM
  AND         c.PRCL_SEQ_NUM = n.PRCL_SEQ_NUM 
  LEFT JOIN  STO_location o
  ON          n.LOC_SEQ_NUM = o.SEQUENCE_NUM
  JOIN      (
  SELECT  DISTINCT TRDG_COMP_MNEM 
  ,CONTRACT_NUM
  ,CONTRACT_CREATE_D
  FROM    STO_PARCEL
 
  ) j
  ON                        a.TRDG_COMP_MNEM = j.TRDG_COMP_MNEM
  AND                      a.CONTRACT_NUM = j.CONTRACT_NUM
  AND                      a.CONTRACT_CREATE_D = j.CONTRACT_CREATE_D
  ) where SRC_SYS_DEAL_SUB_LEG_KEY = 'IT_005B_20180406_02_0002'
  """
  
  #where DEAL_ATTRIBUTE_NK = 'IT_01XN_20180410_04_0004'
  return DEAL_ATTRIBUTE_READ_SQL

# COMMAND ----------

spark = sparkSession("dim_broker_load" )

format = "delta"
SOURCE_ETRM = "DEX"
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PARCEL', format, 'STO_PARCEL')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CONTRACT', format, 'STO_CONTRACT')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CHRGACCT', format, 'STO_CHRGACCT')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRICING', format, 'STO_PRICING')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCGTERM', format, 'STO_PRCGTERM')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CDTYCTMT', format, 'STO_CDTYCTMT')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLOPRN', format, 'STO_PRCLOPRN')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_VOYAGE', format, 'STO_VOYAGE')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_VESSEL', format, 'STO_VESSEL')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLDCH', format, 'STO_PRCLDCH')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_LOCATION', format, 'STO_LOCATION')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_BKOTPRCL', format, 'STO_BKOTPRCL')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_BKOTCHN', format, 'STO_BKOTCHN')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLFCST', format, 'STO_PRCLFCST')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_SETTLMNT', format, 'STO_SETTLMNT')     
      
      
print("running sql DEAL_ATTRIBUTE_READ_SQL")
DEAL_ATTRIBUTE_READ_SQL = getDealAttrReaderSQLDay0_X(spark , SOURCE_ETRM)
       
df = spark.sql(DEAL_ATTRIBUTE_READ_SQL) 
df.printSchema()  
df.show(20,truncate=False)
      
