# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../enricher/CommodityMappingEnricher

# COMMAND ----------

class NucleusCommodityReader(SourceDatasetReader):
    
  def read(spark,metricDict):
        
        SOURCE_ETRM = 'NUCLEUS'
        
        last_watermark = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'DEAL_MONTH_DETAILS','DIM_COMMODITY')
        last_watermark = last_watermark[0:19]
        
        df = executeJdbcQueryAndReturnDF("select src_sys_commodity_nk from tsa_curated.dim_commodity where src_sys_name = '{0}'".format(SOURCE_ETRM))
        df.createOrReplaceTempView("CURATED_DIM_COMMODITY")
        
        COMMODITY_READER_SQL = """
        SELECT DISTINCT
            DMD.COM_COMMODITY 	AS SRC_SYS_COMMODITY_NK,
            C.DESCRIPTION 		AS SRC_COMMODITY_NAME,
            C.GR_DEFAULT_REGION 	AS SRC_COMMODITY_GROUP_NAME,
            'Y' 		AS ACTIVE_COMMODITY_FLAG ,
            max(DMD.MODIFY_DATE) as SOURCE_LAST_UPDATE
            FROM DEAL_MONTH_DETAILS DMD 
LEFT JOIN COMMODITIES C
ON DMD.COM_COMMODITY = C.COMMODITY
             where 
            (DMD.MODIFY_DATE > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss') or
            DMD.COM_COMMODITY in (select src_sys_commodity_nk from CURATED_DIM_COMMODITY)) 
            group by DMD.COM_COMMODITY,
            C.DESCRIPTION,
            C.GR_DEFAULT_REGION
        """.format(last_watermark)
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'COMMODITIES', format, 'COMMODITIES')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'UNITS', format, 'UNITS')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'DEAL_MONTH_DETAILS', format, 'DEAL_MONTH_DETAILS')
        
        
        df = spark.sql(COMMODITY_READER_SQL)
        df = enrichCommodityForMapping(spark,df,SOURCE_ETRM)
        
        return (df,metricDict)

# COMMAND ----------

 
