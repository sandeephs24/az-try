# Databricks notebook source


# COMMAND ----------

# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

class DexFactSubLegReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
    
    (dfSubLeg, metricDict) = readFactSubLeg(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD)

    return (dfSubLeg, metricDict)

# COMMAND ----------

def readFactSubLeg(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
  last_watermark_fact_contract1 = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'STO_CONTRACT','CONTRACT_DATE','FACT_DEAL_SUB_LEG')
  last_watermark_fact_contract1 = last_watermark_fact_contract1[0:19] 
  
  last_watermark_fact_contract2=getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'STO_CONTRACT','LAST_UPDATE_TSTMP','FACT_DEAL_SUB_LEG')
  last_watermark_fact_contract2 = last_watermark_fact_contract2[0:19]
  
  last_watermark_fact_parcel=getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'STO_PARCEL','PARCEL_DATE','FACT_DEAL_SUB_LEG')
  last_watermark_fact_parcel = last_watermark_fact_parcel[0:19]
   
  
  if INITIAL_LOAD == "Y" :
    SQL = getSublegReaderSQLDay0(last_watermark_fact_parcel)
  else:
    SQL = getSublegReaderSQLDay1(last_watermark_fact_contract1, last_watermark_fact_contract2)
  
  
  format = "delta"
  readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CONTRACT', format, 'STO_CONTRACT')
  readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CDTYCTMT', format, 'STO_CDTYCTMT')
  readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLCST', format, 'STO_PRCLCST')
  readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PARCEL', format, 'STO_PARCEL')
  readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRICING', format, 'STO_PRICING')
  readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLLDG', format, 'STO_PRCLLDG')
  readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLDCH', format, 'STO_PRCLDCH')
  readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCGTERM', format, 'STO_PRCGTERM')
  readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCGPRDD', format, 'STO_PRCGPRDD')
  readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CHRGACCT', format, 'STO_CHRGACCT')

  dfSubLeg = spark.sql(SQL)
  
  dfSubLeg = dfSubLeg.withColumn("SHELL_TRADING_PARTY_NK",dfSubLeg.SHELL_TRADING_PARTY_NK.cast('int'))
  dfSubLeg = dfSubLeg.withColumn("COUNTERPARTY_NK",dfSubLeg.COUNTERPARTY_NK.cast('int'))

  dfSubLeg.show(10,truncate=False)
  
  print("DexFactSubLegReader" , dfSubLeg.count())

  
  return (dfSubLeg, metricDict)

# COMMAND ----------

def getSublegReaderSQLDay1(last_watermark_fact_contract1,last_watermark_fact_parcel, last_watermark_fact_contract2):
  SQL = """
         WITH DEALS_IN_SCOPE AS 
				(
				SELECT DISTINCT z.CONTRACT_NUM
				,z.CONTRACT_CREATE_D
				FROM		STO_CONTRACT z
                JOIN       STO_CDTYCTMT b
          ON          z.CONTRACT_NUM = b.CONTRACT_NUM 
          AND         z.CONTRACT_CREATE_D = b.CONTRACT_CREATE_D
          JOIN       STO_PARCEL c
          ON          b.CONTRACT_NUM = c.CONTRACT_NUM 
          AND         b.CONTRACT_CREATE_D = c.CONTRACT_CREATE_D
          AND         b.CTMT_SEQ_NUM = c.CDTY_CTMT_SEQ_NUM
          AND         c.VLDT_LEVEL <> 'V'
				WHERE  		  ( 
							  (
							  z.CONTRACT_DATE > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
							  ) 
							  OR
							  (
							  c.PARCEL_DATE < to_timestamp('{1}','yyyy-MM-dd HH:mm:ss') 
							  and Z.LAST_UPDATE_TSTMP > to_timestamp('{2}','yyyy-MM-dd HH:mm:ss')	
							  )		
							  )	
				)
          SELECT 
          a.TRDG_COMP_MNEM
          ||'_'||a.CONTRACT_NUM||'_'|| 
          date_format(a.CONTRACT_CREATE_D,'yyyyMMdd')
          ||'_'||b.CTMT_SEQ_NUM||'_'||c.PRCL_SEQ_NUM		                                                 AS DEAL_ATTRIBUTES_NK		
          ,LEAST( CAST(c.EXECUTION_TSTMP AS DATE), CAST(b.EXECUTION_TSTMP AS DATE) )                         AS EXECUTION_DATE
          ,a.CONTRACT_DATE 		       																		 AS TRADE_CREATION_DATE    			      ,b.COMMITMENT_DATE 																	             AS COMMITMENT_DATE
          ,c.PARCEL_DATE 																				     AS PARCEL_DATE
         ,a.CLT_CHRG_ACCT_NUM 											                                     AS COUNTERPARTY_NK
         ,a.OWNG_CHRG_ACCT_NUM 								                                                 AS SHELL_TRADING_PARTY_NK
         ,a.TRADER_USERID 		  																			 AS TRADER_NK
         ,CAST(d1.CHRG_ACCT_NUM  AS INT) 														             AS DEAL_BROKER_NK					     ,b.GRADE_CODE 																				         AS COMMODITY_NK
         ,CAST(f.LOC_SEQ_NUM AS INT) 																	     AS LOADING_LOCATION_NK
         ,CAST(g.LOC_SEQ_NUM AS INT) 																		 AS DISCHARGE_LOCATION_NK
         ,c.DEL_PRD_START_DATE 																	             AS DELIVERY_START_DATE
         ,c.DEL_PRD_END_DATE 																			     AS DELIVERY_END_DATE
         ,c.QTY_UNIT_CODE 													                                 AS DEAL_UNIT_OF_MEASURE_NK		            ,c.QTY_UNIT_CODE																				    AS PRICING_UNIT_OF_MEASURE_NK		     ,d2.CURRENCY_CODE 																                     AS DEAL_CCY_NK
         ,CASE
           WHEN c.VLDT_LEVEL  = 'P' THEN 0 
           WHEN d2.CURRENCY_CODE = 'USC' THEN (d2.LATEST_COST_VALUE/100)
           ELSE d2.LATEST_COST_VALUE END    																AS CCY_DEAL_VALUE					     ,c.QTY_AMT 																					    AS DEAL_QTY							     ,c.QTY_AMT 																				        AS PRICE_QTY						     ,CASE 
            WHEN b.OWNER_BUY_SELL_IND = 'S' THEN -1
            WHEN b.OWNER_BUY_SELL_IND = 'B' THEN 1 
            ELSE 0 END 									                                                    AS DEAL_SUB_LEG_MULTIPLIER			     ,a.LAST_UPDATE_TSTMP 																				AS SOURCE_LAST_DATE1
         ,a.CONTRACT_DATE 																					AS SOURCE_LAST_DATE2
         ,c.PARCEL_DATE 																								AS SOURCE_LAST_DATE3, '' as SRC_SYS_DEAL_HEADER_KEY
          FROM		STO_CONTRACT a
          JOIN       STO_CDTYCTMT b
          ON          a.CONTRACT_NUM = b.CONTRACT_NUM 
          AND         a.CONTRACT_CREATE_D = b.CONTRACT_CREATE_D
          JOIN       STO_PARCEL c
          ON          b.CONTRACT_NUM = c.CONTRACT_NUM 
          AND         b.CONTRACT_CREATE_D = c.CONTRACT_CREATE_D
          AND         b.CTMT_SEQ_NUM = c.CDTY_CTMT_SEQ_NUM
          AND         c.VLDT_LEVEL <> 'V'
          LEFT JOIN  STO_PRCLCST d1					
          ON          c.CONTRACT_NUM = d1.CONTRACT_NUM 
          AND         c.PRCL_SEQ_NUM = d1.PRCL_SEQ_NUM
          AND         c.CONTRACT_CREATE_D = d1.CONTRACT_CREATE_D
          AND			d1.COST_TYPE_CODE = 'BROKE'
          AND			d1.COST_CODE IN ('CLEAR', 'BROKE')	
          AND			d1.CHRG_ACCT_NUM != 0
          LEFT JOIN   STO_PRCLCST d2							
          ON          c.CONTRACT_NUM = d2.CONTRACT_NUM 
          AND         c.PRCL_SEQ_NUM = d2.PRCL_SEQ_NUM
          AND         c.CONTRACT_CREATE_D = d2.CONTRACT_CREATE_D
          AND			d2.COST_TYPE_CODE = 'OIL'
          AND			d2.COST_CODE = 'OIL'
          LEFT JOIN   STO_PRCLLDG f
          ON       	f.TRDG_COMP_MNEM = c.TRDG_COMP_MNEM
          AND    		f.CONTRACT_NUM = c.CONTRACT_NUM
          AND    		f.PRCL_SEQ_NUM = c. PRCL_SEQ_NUM
          AND   		f.LOC_SEQ_NUM !=0
          LEFT JOIN 	STO_PRCLDCH g
          ON       	g.TRDG_COMP_MNEM = c.TRDG_COMP_MNEM
          AND    		g.CONTRACT_NUM = c.CONTRACT_NUM
          AND    		g.PRCL_SEQ_NUM = c. PRCL_SEQ_NUM
          AND   		g.LOC_SEQ_NUM !=0
          JOIN      	INSCOPE_DEALS h
          ON          a.TRDG_COMP_MNEM = h.TRDG_COMP_MNEM
          AND         a.CONTRACT_NUM = h.CONTRACT_NUM
          AND         a.CONTRACT_CREATE_D = h.CONTRACT_CREATE_D
          where b.grade_code not in ('LPROP') 
AND  a.OWNG_CHRG_ACCT_NUM not In ('2304','2391','2390')
  """.format(last_watermark_fact_contract1,last_watermark_fact_parcel,last_watermark_fact_contract2)
  
  return SQL
  

# COMMAND ----------

def getSublegReaderSQLDay0(last_watermark_fact_parcel):
  SQL = """
  WITH INSCOPE_DEALS AS 
          (
          SELECT  DISTINCT TRDG_COMP_MNEM 
                          ,CONTRACT_NUM
                          ,CONTRACT_CREATE_D
          FROM    STO_PARCEL
          WHERE PARCEL_DATE > '{0}'
          and PARCEL_DATE < '2019-05-01 00:00:00'
          )
          SELECT 
          a.TRDG_COMP_MNEM
          ||'_'||a.CONTRACT_NUM||'_'|| 
          date_format(a.CONTRACT_CREATE_D,'yyyyMMdd')
          ||'_'||b.CTMT_SEQ_NUM||'_'||c.PRCL_SEQ_NUM		                                                 AS DEAL_ATTRIBUTES_NK		
          ,LEAST( CAST(c.EXECUTION_TSTMP AS DATE), CAST(b.EXECUTION_TSTMP AS DATE) )                         AS EXECUTION_DATE
          ,a.CONTRACT_DATE 		       																		 AS TRADE_CREATION_DATE    			      ,b.COMMITMENT_DATE 																	             AS COMMITMENT_DATE
          ,c.PARCEL_DATE 																				     AS PARCEL_DATE
         ,a.CLT_CHRG_ACCT_NUM 											                                     AS COUNTERPARTY_NK
         ,a.OWNG_CHRG_ACCT_NUM 								                                                 AS SHELL_TRADING_PARTY_NK
         ,a.TRADER_USERID 		  																			 AS TRADER_NK
         ,CASE WHEN SC.CHRG_ACCT_TYP_CODE='T' THEN NULL ELSE CAST(d1.CHRG_ACCT_NUM AS INT) END	         AS DEAL_BROKER_NK					     ,
         b.GRADE_CODE 																				         AS COMMODITY_NK
         ,CAST(f.LOC_SEQ_NUM AS INT) 																	     AS LOADING_LOCATION_NK
         ,CAST(g.LOC_SEQ_NUM AS INT) 																		 AS DISCHARGE_LOCATION_NK
         ,c.DEL_PRD_START_DATE 																	             AS DELIVERY_START_DATE
         ,c.DEL_PRD_END_DATE 																			     AS DELIVERY_END_DATE
         ,c.QTY_UNIT_CODE 													                                 AS DEAL_UNIT_OF_MEASURE_NK		            ,c.QTY_UNIT_CODE																				    AS PRICING_UNIT_OF_MEASURE_NK		     ,d2.CURRENCY_CODE 																                     AS DEAL_CCY_NK
         ,CASE
           WHEN c.VLDT_LEVEL  = 'P' THEN 0 
           WHEN d2.CURRENCY_CODE = 'USC' THEN (d2.LATEST_COST_VALUE/100)
           ELSE d2.LATEST_COST_VALUE END    																AS CCY_DEAL_VALUE
           ,c.QTY_AMT 																					    AS DEAL_QTY	
           ,c.QTY_AMT 																				        AS PRICE_QTY
           ,CASE 
            WHEN b.OWNER_BUY_SELL_IND = 'S' THEN -1
            WHEN b.OWNER_BUY_SELL_IND = 'B' THEN 1 
            ELSE 0 END 									                                                    AS DEAL_SUB_LEG_MULTIPLIER			     ,a.LAST_UPDATE_TSTMP 																				AS SOURCE_LAST_DATE1
         ,a.CONTRACT_DATE 																					AS SOURCE_LAST_DATE2
         ,c.PARCEL_DATE 																								AS SOURCE_LAST_DATE3, '' as SRC_SYS_DEAL_HEADER_KEY
          FROM		STO_CONTRACT a
          JOIN       STO_CDTYCTMT b
          ON          a.CONTRACT_NUM = b.CONTRACT_NUM 
          AND         a.CONTRACT_CREATE_D = b.CONTRACT_CREATE_D
          JOIN       STO_PARCEL c
          ON          b.CONTRACT_NUM = c.CONTRACT_NUM 
          AND         b.CONTRACT_CREATE_D = c.CONTRACT_CREATE_D
          AND         b.CTMT_SEQ_NUM = c.CDTY_CTMT_SEQ_NUM
          AND         c.VLDT_LEVEL <> 'V'
          LEFT JOIN  STO_PRCLCST d1					
          ON          c.CONTRACT_NUM = d1.CONTRACT_NUM 
          AND         c.PRCL_SEQ_NUM = d1.PRCL_SEQ_NUM
          AND         c.CONTRACT_CREATE_D = d1.CONTRACT_CREATE_D
          AND			d1.COST_TYPE_CODE = 'BROKE'
          AND			d1.COST_CODE IN ('INTNL', 'WET', 'EXE', 'OPT', 'BROKE')
          AND			d1.CHRG_ACCT_NUM != 0
          LEFT JOIN   STO_PRCLCST d2							
          ON          c.CONTRACT_NUM = d2.CONTRACT_NUM 
          AND         c.PRCL_SEQ_NUM = d2.PRCL_SEQ_NUM
          AND         c.CONTRACT_CREATE_D = d2.CONTRACT_CREATE_D
          AND			d2.COST_TYPE_CODE = 'OIL'
          AND			d2.COST_CODE = 'OIL'
          LEFT JOIN   STO_PRCLLDG f
          ON       	f.TRDG_COMP_MNEM = c.TRDG_COMP_MNEM
          AND    		f.CONTRACT_NUM = c.CONTRACT_NUM
          AND    		f.PRCL_SEQ_NUM = c. PRCL_SEQ_NUM
          AND   		f.LOC_SEQ_NUM !=0
          LEFT JOIN 	STO_PRCLDCH g
          ON       	g.TRDG_COMP_MNEM = c.TRDG_COMP_MNEM
          AND    		g.CONTRACT_NUM = c.CONTRACT_NUM
          AND    		g.PRCL_SEQ_NUM = c. PRCL_SEQ_NUM
          AND   		g.LOC_SEQ_NUM !=0
           LEFT JOIN STO_CHRGACCT SC
          ON SC.sequence_num=d1.CHRG_ACCT_NUM
          JOIN      	INSCOPE_DEALS h
          ON          a.TRDG_COMP_MNEM = h.TRDG_COMP_MNEM
          AND         a.CONTRACT_NUM = h.CONTRACT_NUM
          AND         a.CONTRACT_CREATE_D = h.CONTRACT_CREATE_D
          where b.grade_code not in ('LPROP') 
AND  a.OWNG_CHRG_ACCT_NUM not In ('2304','2391','2390')
  """.format(last_watermark_fact_parcel)
  
  return SQL
  
