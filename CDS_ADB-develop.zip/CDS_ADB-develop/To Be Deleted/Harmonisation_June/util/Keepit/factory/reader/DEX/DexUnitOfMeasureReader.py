# Databricks notebook source
# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../enricher/UOMMappingEnricher

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class DexUnitOfMeasureReader(SourceDatasetReader):
    
    def read(spark,metricDict):
        SOURCE_ETRM = 'DEX'
        
        UOM_READER_SQL = """
        select 
        distinct QTY_UNIT_CODE SRC_SYS_UNIT_OF_MEASURE_NK 
        from STO_PARCEL where QTY_UNIT_CODE is not null
        """
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PARCEL', format, 'STO_PARCEL')
      
        df = spark.sql(UOM_READER_SQL)
        df = enrichUOMForMapping(spark,df, SOURCE_ETRM)
        
        
        return  (df,metricDict)
