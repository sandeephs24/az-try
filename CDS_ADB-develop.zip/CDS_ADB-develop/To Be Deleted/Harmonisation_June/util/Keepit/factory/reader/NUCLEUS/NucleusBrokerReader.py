# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class NucleusBrokerReader(SourceDatasetReader):
    
  def read(spark,metricDict):
        
        SOURCE_ETRM = 'NUCLEUS'
        
        df = executeJdbcQueryAndReturnDF("select src_sys_broker_nk from tsa_curated.dim_broker where src_sys_name = '{0}'".format(SOURCE_ETRM))
        df.createOrReplaceTempView("CURATED_DIM_BROKER")
        
        BROKER_READER_SQL = """
        SELECT	cast(C.COMPANY_KEY as int) 	    AS 	SRC_SYS_BROKER_NK,
        C.LONG_NAME 		AS 	BROKER_NAME,
        C.ACTIVE_FLAG		AS 	ACTIVE_BROKER_FLAG,
		'1900-01-01 00:00:00'                AS SOURCE_LAST_UPDATE
          from        COMPANIES c
          join        (
                       select      DISTINCT b.CY_BROKER_KEY
                from        DEAL_MONTH_DETAILS a
                left join   BROKER_COMMISSION_MONTHS b
                on           a.dlt_deal_type = b.dlt_deal_type
                and         a.deal_key = b.deal_key
                and         a.cm_contract_month = b.cm_contract_month)brk1
        on          brk1.CY_BROKER_KEY = c.COMPANY_KEY
        union
        SELECT	cast(C.COMPANY_KEY as int) 	    AS 	SRC_SYS_BROKER_NK,
                C.LONG_NAME 		AS 	BROKER_NAME,
                C.ACTIVE_FLAG		AS 	ACTIVE_BROKER_FLAG,
                '1900-01-01 00:00:00'                AS SOURCE_LAST_UPDATE		
        from       COMPANIES c
        join        (
                        select      DISTINCT b.CY_BROKER_KEY
                from        DEAL_MONTH_DETAILS a
                left join   FLAT_BROKER_FEES b
                on          a.dlt_deal_type = b.dlt_deal_type
                and         a.deal_key = b.deal_key
                )brk2
          on          brk2.CY_BROKER_KEY = c.COMPANY_KEY
          UNION 
          SELECT	cast(C.COMPANY_KEY as int)	    AS 	SRC_SYS_BROKER_NK,
                  C.LONG_NAME 		AS 	BROKER_NAME,
                  C.ACTIVE_FLAG		AS 	ACTIVE_BROKER_FLAG,
                  '1900-01-01 00:00:00'                AS SOURCE_LAST_UPDATE
          from        COMPANIES c
          join        (
                          select      DISTINCT b.CY_CBROKER_KEY
                          from        DEAL_MONTH_DETAILS a
                          left join   CLEARINGBROKER_FEES b
                          on          a.dlt_deal_type = b.dlt_deal_type
                          and         a.deal_key = b.deal_key
                          )brk3
          on          brk3.CY_CBROKER_KEY = c.COMPANY_KEY
        """
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'COMPANIES', 'parquet', 'COMPANIES')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'DEAL_MONTH_DETAILS', format, 'DEAL_MONTH_DETAILS')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'BROKER_COMMISSION_MONTHS', format, 'BROKER_COMMISSION_MONTHS')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'FLAT_BROKER_FEES', format, 'FLAT_BROKER_FEES')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'CLEARINGBROKER_FEES', format, 'CLEARINGBROKER_FEES')
        
        
        
        df = spark.sql(BROKER_READER_SQL)
        
        return (df,metricDict)

# COMMAND ----------

 
