# Databricks notebook source
# MAGIC %run ../DatasetReader

# COMMAND ----------

# MAGIC %run ./DexBrokerReader

# COMMAND ----------

# MAGIC %run ./DexCommodityReader

# COMMAND ----------

# MAGIC %run ./DexCounterPartyReader

# COMMAND ----------

# MAGIC %run ./DexLocationReader

# COMMAND ----------

# MAGIC %run ./DexTraderReader

# COMMAND ----------

# MAGIC %run ./DexCurrencyReader

# COMMAND ----------

# MAGIC %run ./DexUnitOfMeasureReader

# COMMAND ----------

# MAGIC %run ./DexDealAttributesReader
