# Databricks notebook source
# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../enricher/InternalPartyEmptyEnricher

# COMMAND ----------

# MAGIC %run ./../../enricher/PartyGoldTierEnricher

# COMMAND ----------

class EndurGPNACounterPartyReader(SourceDatasetReader):
     def read(spark,metricDict):
        SOURCE_ETRM = 'ENDUR_GPNA'
      
        last_watermark_party = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'PARTY','DIM_PARTY')
        last_watermark_party = last_watermark_party[0:19]

        df = executeJdbcQueryAndReturnDF("select SRC_SYS_PARTY_NK,party_type from tsa_curated.dim_party where src_sys_name = '{0}'".format(SOURCE_ETRM))
        df.createOrReplaceTempView("CURATED_DIM_PARTY")
             
        INTERNAL_PARTY_READER_SQL = """
              WITH legal_enity_view as
              (
              select DISTINCT a.internal_bunit,
              first_value(a.internal_lentity) 
              OVER ( partition BY internal_bunit ORDER BY last_update desc ) AS internal_lentity
              from AB_TRAN a
              )
              select cast(p.party_id as string) as SRC_SYS_PARTY_NK,
              p.short_name SRC_SYS_PARTY_SHORT_NAME,
              p.long_name SRC_SYS_PARTY_LONG_NAME,
              c.name PARTY_TYPE,
              p1.party_id SRC_SYS_LEGAL_ENTITY_NK, 
              p1.long_name SRC_SYS_LEGAL_ENTITY_NAME,
              p.LAST_UPDATE SOURCE_LAST_UPDATE 
              from PARTY p, legal_enity_view t,PARTY p1,INTERNAL_EXTERNAL c 
              where p.party_id=t.internal_bunit 
              and t.internal_lentity = p1.party_id
              and p.int_ext = c.id_number
              and 
              (
              p.last_update > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
              or
              p.party_id in (select SRC_SYS_PARTY_NK from CURATED_DIM_PARTY where party_type = 'Internal')
              )
              
              """.format(last_watermark_party)

        EXTERNAL_PARTY_READER_SQL = """
              WITH legal_enity_view as
              (
              select DISTINCT a.external_bunit,
              first_value(a.external_lentity) 
              OVER ( partition BY external_bunit ORDER BY last_update desc ) AS external_lentity
              from AB_TRAN a
              )
              select cast(p.party_id as string) as SRC_SYS_PARTY_NK,
              p.short_name SRC_SYS_PARTY_SHORT_NAME,
              p.long_name SRC_SYS_PARTY_LONG_NAME,
              c.name PARTY_TYPE,
              p1.party_id SRC_SYS_LEGAL_ENTITY_NK, 
              p1.long_name SRC_SYS_LEGAL_ENTITY_NAME,
              p.LAST_UPDATE source_last_update 
              from PARTY p, legal_enity_view t,PARTY p1,INTERNAL_EXTERNAL c 
              where p.party_id=t.external_bunit 
              and t.external_lentity = p1.party_id
              and p.int_ext = c.id_number
              and 
              (
              p.last_update > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
              OR
              p.party_id in (select SRC_SYS_PARTY_NK from CURATED_DIM_PARTY where party_type = 'External')
              )
              
        """.format(last_watermark_party)
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PARTY', "parquet", 'PARTY')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN', format, 'AB_TRAN')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'INTERNAL_EXTERNAL', format, 'INTERNAL_EXTERNAL')

        
        dfInternal1 = spark.sql(INTERNAL_PARTY_READER_SQL)
        dfExternal1 = spark.sql(EXTERNAL_PARTY_READER_SQL)
        dfboth = dfInternal1.union(dfExternal1)
        dfInternal = dfboth.filter(dfboth.PARTY_TYPE=='Internal')
        dfExternal = dfboth.filter(dfboth.PARTY_TYPE=='External')
        dfExternal = dfExternal.dropDuplicates(["SRC_SYS_PARTY_NK"])
        df1 = enrichInternalParty(dfInternal)
        spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
        df1 = df1.withColumn("NEXT_ENHANCED_MONITORING_REQUIRED_DATE",to_date(col("NEXT_ENHANCED_MONITORING_REQUIRED_DATE"),"yyyy-MM-dd"))
        df1 = df1.withColumn("KYC_NEXT_REVIEW_DATE",to_date(col("KYC_NEXT_REVIEW_DATE"),"yyyy-MM-dd"))
        df1 = df1.withColumn("KYC_LAST_REVIEW_DATE",to_date(col("KYC_LAST_REVIEW_DATE"),"yyyy-MM-dd"))
        df1 = df1.withColumn("SOURCE_LAST_UPDATE",to_timestamp(col("SOURCE_LAST_UPDATE")))
        df2 = enrichExternalParty(spark,dfExternal,SOURCE_ETRM)
        df2 = df2.withColumn("NEXT_ENHANCED_MONITORING_REQUIRED_DATE",to_date(col("NEXT_ENHANCED_MONITORING_REQUIRED_DATE"),"yyyy-MM-dd"))
        df2 = df2.withColumn("KYC_NEXT_REVIEW_DATE",to_date(col("KYC_NEXT_REVIEW_DATE"),"yyyy-MM-dd"))
        df2 = df2.withColumn("KYC_LAST_REVIEW_DATE",to_date(col("KYC_LAST_REVIEW_DATE"),"yyyy-MM-dd"))
        df2 = df2.withColumn("SOURCE_LAST_UPDATE",to_timestamp(col("SOURCE_LAST_UPDATE")))
        
        totalDf = df1.union(df2)
        totalDf = totalDf.dropDuplicates(["SRC_SYS_PARTY_NK"])
        print(totalDf.count())
        
        return (totalDf,metricDict)
        
        
