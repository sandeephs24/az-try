# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../../../WatermarkReader

# COMMAND ----------

import abc
class SourceDatasetReader(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def read(self):
        pass

# COMMAND ----------

class EndurSLMTFactSubLegReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM,metricDict, initial_load):
    
    (dfSubLeg,metricDict) = readFactSubLeg(spark, SOURCE_ETRM,metricDict, initial_load)

    return (dfSubLeg,metricDict)

# COMMAND ----------

def readFactSubLeg(spark, SOURCE_ETRM,metricDict, initial_load):
    from pyspark.sql.functions import concat
    from pyspark.sql.functions import date_format
    
    from datetime import datetime
    current_date_yyyymmdd = datetime.today().strftime('%Y%m%d')
    
    last_watermark_trade_date = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'AB_TRAN','TRADE_DATE', 'FACT_DEAL_SUB_LEG')
    last_watermark_trade_date = last_watermark_trade_date[0:19]
    
    last_watermark_input_date = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'AB_TRAN','INPUT_DATE', 'FACT_DEAL_SUB_LEG')
    last_watermark_input_date = last_watermark_input_date[0:19]
    
    last_watermark_last_update = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'AB_TRAN','LAST_UPDATE', 'FACT_DEAL_SUB_LEG')
    last_watermark_last_update = last_watermark_last_update[0:19]
    
    if initial_load == "Y":
      tran_status_list = "3,4,5"
      date_attribute ="""t.input_date >= to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')""".format(last_watermark_input_date)
    else:
      tran_status_list = "3,5"
      date_attribute = """( 
    (t.trade_date > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss') and t.input_date <= '{1}')
    OR
    (t.trade_date <= '{2}' and t.input_date > to_timestamp('{3}','yyyy-MM-dd HH:mm:ss'))
    OR
    (t.last_update > to_timestamp('{4}','yyyy-MM-dd HH:mm:ss') )
    )""".format(last_watermark_trade_date, 
               current_date_yyyymmdd, 
               current_date_yyyymmdd, 
               last_watermark_input_date, 
               last_watermark_last_update)
    
    SQL = """   
    SELECT 
    DEAL_ATTRIBUTES_NK,
    DEAL_TRACKING_NUM,
    TRAN_NUM,
    INS_NUM,
    PARAM_SEQ_NUM,
    PROFILE_SEQ_NUM,
    EXECUTION_DATE,
    TRADE_CREATION_DATE,
    COMMITMENT_DATE,
    PARCEL_DATE,
    COUNTERPARTY_NK,
    SHELL_TRADING_PARTY_NK,
    TRADER_NK,
    DEAL_BROKER_NK,
    COMMODITY_NK,
    LOADING_LOCATION_NK,
    DISCHARGE_LOCATION_NK,
    DELIVERY_START_DATE,
    DELIVERY_END_DATE,
    DEAL_UNIT_OF_MEASURE_NK,
    PRICING_UNIT_OF_MEASURE_NK,
    DEAL_CCY_NK,
    DEAL_QTY,
    PRICE_QTY,
    DEAL_SUB_LEG_MULTIPLIER,
    TRAN_STATUS,
    SOURCE_LAST_DATE1,
    SOURCE_LAST_DATE2,
    SOURCE_LAST_DATE3,
    NOTNL,
    strike,
    CASE WHEN DEAL_QTY = 0 THEN 0 ELSE sum(CCY_DEAL_VALUE) END CCY_DEAL_VALUE,
    SRC_SYS_DEAL_HEADER_KEY
    FROM(
SELECT 
    t.trade_date AS EXECUTION_DATE,
    t.input_date AS TRADE_CREATION_DATE,
    t.TRADE_DATE AS COMMITMENT_DATE,
    d.START_DATE AS PARCEL_DATE,
    t.EXTERNAL_BUNIT AS COUNTERPARTY_NK,
    t.INTERNAL_BUNIT AS SHELL_TRADING_PARTY_NK,
    t.DEAL_TRACKING_NUM||'_'||t.INS_NUM||'_'||d.PARAM_SEQ_NUM||'_'||d.PROFILE_SEQ_NUM AS DEAL_ATTRIBUTES_NK,
    t.DEAL_TRACKING_NUM,
    t.tran_num,
    l.INS_NUM,
    d.PARAM_SEQ_NUM,
    d.PROFILE_SEQ_NUM,
    t.INTERNAL_CONTACT AS TRADER_NK,
    CASE WHEN T.OTC_CLEARING_BROKER_ID = 0
         THEN (CASE WHEN t.BROKER_ID!=0 THEN t.BROKER_ID
                    WHEN pa2.PARTY_ID is not null then pa2.PARTY_ID
                    ELSE NULL END)
         ELSE T.OTC_CLEARING_BROKER_ID 
    END AS DEAL_BROKER_NK,
    d2.id_number AS COMMODITY_NK,
    '' AS LOADING_LOCATION_NK,
    gpl.LOCATION_ID DISCHARGE_LOCATION_NK,
    d.START_DATE DELIVERY_START_DATE,
    d.END_DATE DELIVERY_END_DATE,
    f.UNIT DEAL_UNIT_OF_MEASURE_NK,
    f.PRICE_UNIT PRICING_UNIT_OF_MEASURE_NK,
    t.CURRENCY DEAL_CCY_NK,
    CASE WHEN t.TRAN_STATUS = 5
THEN 0
WHEN NVL(l.INS_NUM, -1) = -1
THEN (CASE WHEN d.NOTNL > 0 AND PNL.RST_TOTAL_NOTIONAL_VALUE  < 0
THEN PNL.RST_TOTAL_NOTIONAL_VALUE 
ELSE ABS(PNL.RST_TOTAL_NOTIONAL_VALUE ) END)
ELSE l.strike * ABS(d.notnl) END AS CCY_DEAL_VALUE,
    abs(d.NOTNL) AS DEAL_QTY,
    abs(d.NOTNL) * f.PRICE_UNIT_CONV AS PRICE_QTY,
    CASE WHEN d.notnl < 0 THEN -1 WHEN d.notnl > 0 THEN 1 ELSE 0 END DEAL_SUB_LEG_MULTIPLIER,
    t.TRAN_STATUS,
    t.trade_date source_last_date1,
    t.input_date source_last_date2,
    t.last_update source_last_date3,
    d.NOTNL,
    l.strike,
    t.DEAL_TRACKING_NUM as SRC_SYS_DEAL_HEADER_KEY
    from  AB_TRAN t
    join     	INSTRUMENTS bz
    on       	t.ins_type = bz.id_number
    join        INS_PARAMETER f
    on          t.ins_num = f.ins_num
    join        PROFILE d 
    on          f.param_seq_num = d.param_seq_num and f.ins_num = d.ins_num
    join        TOOLSETS ts 
    on          t.toolset = TS.ID_NUMBER
    join        PORTFOLIO c 
    on          t.internal_portfolio = c.id_number
    join        SETTLE_TYPE g 
    on          g.id_number =f.settlement_type
    join        PARTY j 
    on          t.internal_lentity = j.party_id
    join        TRANS_STATUS k 
    on          t.tran_status = k.trans_status_id
    left join   INS_OPTION l 
    on          f.ins_num = l.ins_num 
    and f.param_seq_num = l.param_seq_num
    and         option_seq_num =0
    left join   gas_phys_param gpp 
    on          gpp.ins_num = f.ins_num and gpp.param_seq_num = f.param_seq_num
    left join   gas_phys_location gpl 
    on          GPP.LOCATION_ID = GPL.LOCATION_ID
    left join   gas_phys_pipelines pipe 
    on          PIPE.PIPELINE_ID = GPL.PIPELINE_ID
    left join   gas_phys_location ic 
    on          GPL.INTERCONNECT_LOC_ID = ic.location_id
    join        buy_sell bs 
    on          BS.ID_NUMBER = t.buy_sell
    left join   PUT_CALL pc 
    on          L.PUT_CALL = PC.ID_NUMBER 
    join        FX_FLT ff 
    on          FF.ID_NUMBER = F.FX_FLT
    left join   PARAM_RESET_HEADER prh 
    on          f.ins_num = prh.ins_num and f.param_seq_num = prh.param_seq_num
    AND PARAM_RESET_HEADER_SEQ_NUM = 0
    left join   idx_def pi 
    on          PI.INDEX_ID = prh.proj_index and pi.validated = 1 and PI.DB_STATUS = 1
    left join IDX_GROUP d2
    on pi.idx_group =d2.id_number
    join        value_status vs 
    on          VS.ID_NUMBER = d.rate_status
    left join   AB_TRAN_AGREEMENT ag 
    on          AG.TRAN_NUM = t.tran_num
    left join   party_agreement pa 
    on          AG.PARTY_AGREEMENT_ID = PA.PARTY_AGREEMENT_ID
    left join   agreement agr 
    on          PA.AGREEMENT_ID = AGR.AGREEMENT_ID
    left join (select tran_num,broker_id from AB_TRAN_PROVISIONAL where PROV_TYPE=2) ap2
    on t.tran_num=ap2.tran_num
    left join 	PARTY pa2
    on 	ap2.broker_id = pa2.party_id
   left join (
    select REPORT_DATE,DEAL_NUM,TRAN_NUM,PARAM_NUM,PROFILE_NUM,RST_CASH_FLOW_TYPE_ID,
    RST_TOTAL_NOTIONAL_VALUE  from
    (
    select PNL.REPORT_DATE,
    PNL.DEAL_NUM,
    PNL.TRAN_NUM,
    PNL.PARAM_NUM,
    PNL.PROFILE_NUM,
    PNL.RST_CASH_FLOW_TYPE_ID,
    PNL.RST_TOTAL_NOTIONAL_VALUE,
    row_number()
    over (Partition by DEAL_NUM,TRAN_NUM,PARAM_NUM,PROFILE_NUM
    order by REPORT_DATE DESC,LOCAL_BASE_CURRENCY ASC)
    row_num
    from USER_DW_DEAL_INFORMATION PNL
    where RST_CASH_FLOW_TYPE_ID=-1
    ) where row_num=1 
    ) PNL
    ON t.DEAL_TRACKING_NUM=PNL.DEAL_NUM
      AND t.TRAN_NUM=PNL.TRAN_NUM
     and  d.PARAM_SEQ_NUM=PNL.PARAM_NUM
     and  d.profile_seq_num=PNL.PROFILE_NUM       
    WHERE t.tran_status in ({5})
    AND   t.current_flag = 1
    AND t.tran_type = 0
        and (
      (
      bz.name in ('COMM-BEACH-SWAP',
'COMM-BEACH-SWAP-HUB',
'COMM-CASH-FLOW',
'COMM-FUEL',
'COMM-NGL',
'COMM-PHYS-CRUDE',
'COMM-PHYS-IDX',
'COMM-PHYS-NGL',
'COMM-PHYS-TERMINAL',
'COMM-PRODUCTION',
'COMM-RETRO',
'GAS',
'GAS-FOR-NGL',
'GASGDA',
'GASPHYSBASIS',
'COMM-LOCATION-SWAP',
'COMM-PHYS-AGG',
'COMM-PHYS-AGG-TERMINAL',
'COMM-PHYS-BORROW',
'COMM-TIME-SWAP',
'GASIDX',
'RENEWABLE-PHYS',
'COMM-PHYS') 
      and gpp.ins_num is not null and f.settlement_type = 2
      )
      OR
      ( bz.name not in ('COMM-BEACH-SWAP',
'COMM-BEACH-SWAP-HUB',
'COMM-CASH-FLOW',
'COMM-FUEL',
'COMM-NGL',
'COMM-PHYS-CRUDE',
'COMM-PHYS-IDX',
'COMM-PHYS-NGL',
'COMM-PHYS-TERMINAL',
'COMM-PRODUCTION',
'COMM-RETRO',
'GAS',
'GAS-FOR-NGL',
'GASGDA',
'GASPHYSBASIS',
'COMM-LOCATION-SWAP',
'COMM-PHYS-AGG',
'COMM-PHYS-AGG-TERMINAL',
'COMM-PHYS-BORROW',
'COMM-TIME-SWAP',
'GASIDX',
'RENEWABLE-PHYS',
'COMM-PHYS'))
      ) 
    AND
    {6}	
    AND     bz.name not in ('CASH',
'COMM-BAL-POSTING',
'COMM-BAL-POSTING-OFFSET',
'COMM-FEE',
'COMM-IMB',
'COMM-PAL',
'COMM-PAL-SETTLEMENT',
'COMM-PHYS-FEES',
'COMM-PHYS-TRANSPORT',
'COMM-STOR',
'COMM-TRANS',
'COMM-TRANSIT',
'COMM-TRANS-SETTLEMENT',
'PWR-FEE',
'RENEWABLE-INVENTORY',
'COMM-BAL-ACCTNG-IMPACT',
'COMM-BANKGAS-BAL-POSTING',
'COMM-IMBALANCE-CASHOUT',
'COMM-INV-NATGAS',
'COMM-IUK-INV-ADJ',
'COMM-NGL-VIRTUAL',
'COMM-PPA',
'COMM-STOR-BAL',
'COMM-TRANSIT-NGL',
'COMM-VIRTUAL-SWAP',
'LNG-MARGIN-XFER-DIV',
'LNG-MARGIN-XFER-EL',
'CAP-ENTRY',
'CAP-EXIT',
'COMM-TRANS-FORECAST') 	

    ) V group by
    DEAL_ATTRIBUTES_NK,
    DEAL_TRACKING_NUM,
    TRAN_NUM,
    INS_NUM,
    PARAM_SEQ_NUM,
    PROFILE_SEQ_NUM,
    EXECUTION_DATE,
    TRADE_CREATION_DATE,
    COMMITMENT_DATE,
    PARCEL_DATE,
    COUNTERPARTY_NK,
    SHELL_TRADING_PARTY_NK,
    TRADER_NK,
    DEAL_BROKER_NK,
    COMMODITY_NK,
    LOADING_LOCATION_NK,
    DISCHARGE_LOCATION_NK,
    DELIVERY_START_DATE,
    DELIVERY_END_DATE,
    DEAL_UNIT_OF_MEASURE_NK,
    PRICING_UNIT_OF_MEASURE_NK,
    DEAL_CCY_NK,
    DEAL_QTY,
    TRAN_STATUS,
    PRICE_QTY,
    DEAL_SUB_LEG_MULTIPLIER,
    source_last_date1,
    source_last_date2,
    source_last_date3,
    NOTNL,
    strike,
    SRC_SYS_DEAL_HEADER_KEY
    """.format(last_watermark_trade_date, 
    current_date_yyyymmdd, 
    current_date_yyyymmdd, 
    last_watermark_input_date, 
    last_watermark_last_update,
    tran_status_list,
    date_attribute
    )
       
    format = "delta"
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'AB_TRAN', format, 'AB_TRAN') 
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'INSTRUMENTS', "parquet", 'INSTRUMENTS')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PARAMETER', format, 'PARAMETER')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PROFILE', format, 'PROFILE')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'TOOLSETS', 'parquet', 'TOOLSETS')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PORTFOLIO', 'parquet', 'PORTFOLIO')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'SETTLE_TYPE', 'parquet', 'SETTLE_TYPE')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PARTY', 'parquet', 'PARTY')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'TRANS_STATUS', 'parquet', 'TRANS_STATUS')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'INS_OPTION', 'parquet', 'INS_OPTION')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'GAS_PHYS_PARAM', format, 'GAS_PHYS_PARAM')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'GAS_PHYS_LOCATION', 'parquet', 'GAS_PHYS_LOCATION')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'GAS_PHYS_PIPELINES', 'parquet', 'GAS_PHYS_PIPELINES')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'BUY_SELL', 'parquet', 'BUY_SELL')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PUT_CALL', 'parquet', 'PUT_CALL')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'FX_FLT', 'parquet', 'FX_FLT')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PARAM_RESET_HEADER', format, 'PARAM_RESET_HEADER')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'IDX_DEF', 'parquet', 'IDX_DEF')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'VALUE_STATUS', 'parquet', 'VALUE_STATUS')
    readDatasetConfigAndCreateTempView(spark, SOURCE_ETRM, 'USER_DW_DEAL_INFORMATION', format, 'USER_DW_DEAL_INFORMATION')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'AB_TRAN_AGREEMENT', format, 'AB_TRAN_AGREEMENT')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PARTY_AGREEMENT', 'parquet', 'PARTY_AGREEMENT')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'AGREEMENT', 'parquet', 'AGREEMENT')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'AB_TRAN_INFO', format, 'AB_TRAN_INFO')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'AB_TRAN_PROVISIONAL', format, 'AB_TRAN_PROVISIONAL')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'INS_PARAMETER', format, 'INS_PARAMETER')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'IDX_GROUP', 'parquet', 'IDX_GROUP')

    
    dfSubLeg = spark.sql(SQL)
    
    return (dfSubLeg,metricDict)
