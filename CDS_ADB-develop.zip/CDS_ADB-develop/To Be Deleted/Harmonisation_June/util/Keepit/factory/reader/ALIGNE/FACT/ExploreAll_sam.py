# Databricks notebook source
# MAGIC %run ./../../util/installPyodbcLib

# COMMAND ----------

def readDatasetConfigAndCreateTempViewWithSCD_CDS(spark, source_etrm, dataset_name, read_format, view_name):
  adls_path = getDatasetConfigForTheTable(spark,source_etrm,dataset_name)
  df = spark.read.format(read_format).load(adls_path)
  df.createOrReplaceTempView(view_name)
  df = spark.sql("select * from {0} where IS_RECORD_ACTIVE = 1".format(view_name))
  df.createOrReplaceTempView(view_name)

# COMMAND ----------

# MAGIC %run ./../../util/ADLSConnection

# COMMAND ----------

# MAGIC %run ./../../util/DatasetConfigReader

# COMMAND ----------

tsaConfig = {
  "ENV_DETAIL": {
    "CURRENT_ENV": "dev"
  },
  "dataSets_dev": {
    "description": "Here we define configuration of storage acoount we use for reading different files ",
    "authInfo": {
              "dbDatabase": "shell-01-eun-sqdw-qcjndxivoedifdplsoyc",
              "dbServer": "shell-01-eun-sq-ymkuptlzfbcqiajeswov.database.windows.net",
              "dbUser": "tsa_login2", 
              "kv_scope": "key-vault-scope",
              "kv_key": "curated-db-key",
              "dbJdbcPort": "1433",
              "dbJdbcExtraOptions": "encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
      },    
      "BlobInfo":{
      "config" : "fs.azure.sas.tsafiles.tcfilestoreblob.blob.core.windows.net",
      "sourceCont" : "wasbs://tsafiles@tcfilestoreblob.blob.core.windows.net",
      "tempDir" : "/tempDirsTSA",
      "accountkey" : "fs.azure.account.key.tcfilestoreblob.blob.core.windows.net",
      "token" : "poQM6Hn0SuFP34iG8lGE/G9N9U9EaLT23+TMt7Sta4V4CC2Tb5NM55SZb+StS70BRt/a0yqapyVSB+FqNN9K/Q=="
    },
      "ADLSInfo":{
        "adls_url" : "adl://shell01eunadls1lserrccrn.azuredatalakestore.net/",
        "client_application_id" : "5115c531-6ce8-494d-b67d-964740500504",
        "adls_refresh_url" : "https://login.microsoftonline.com/db1e96a8-a3da-442a-930b-235cac24cd5c/oauth2/token"
      }
  },
  "dataSets_uat": {
    "description": "Here we define configuration of storage acoount we use for reading different files ",
    "authInfo": {
              "dbDatabase": "shell-01-eun-sqdw-kcwepgnmwgpalqxuhvva",
              "dbServer": "shell-01-eun-sq-yqdgvswztemplburonfj.database.windows.net",
              "dbUser": "tsa_login2", 
              "kv_scope": "key-vault-scope",
              "kv_key": "curated-db-key",
              "dbJdbcPort": "1433",
              "dbJdbcExtraOptions": "encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
      },    
   "BlobInfo":{
      "config" : "fs.azure.sas.tcfiles.tcfilestoreblob.blob.core.windows.net",
      "sourceCont" : "wasbs://tcfiles@tcfilestoreblob.blob.core.windows.net",
      "tempDir" : "/tempDirsTSA",
      "accountkey" : "fs.azure.account.key.tcfilestoreblob.blob.core.windows.net",
      "token" : "poQM6Hn0SuFP34iG8lGE/G9N9U9EaLT23+TMt7Sta4V4CC2Tb5NM55SZb+StS70BRt/a0yqapyVSB+FqNN9K/Q=="
    },
      "ADLSInfo":{
        "adls_url" : "adl://shell01eunadls1lserrccrn.azuredatalakestore.net/",
        "client_application_id" : "5115c531-6ce8-494d-b67d-964740500504",
        "adls_refresh_url" : "https://login.microsoftonline.com/db1e96a8-a3da-442a-930b-235cac24cd5c/oauth2/token"
      }
  },
  "dataSets_prod": {
    "description": "Here we define configuration of storage acoount we use for reading different files ",
    "authInfo": {
              "dbDatabase": "shell-01-eun-sqdw-qcjndxivoedifdplsoyc",
              "dbServer": "shell-01-eun-sq-ymkuptlzfbcqiajeswov.database.windows.net",
              "dbUser": "tsa_login2", 
              "kv_scope": "key-vault-scope",
              "kv_key": "curated-db-key",
              "dbJdbcPort": "1433",
              "dbJdbcExtraOptions": "encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
      },    
    "BlobInfo":{
      "config" : "fs.azure.sas.tcfiles.tcfilestoreblob.blob.core.windows.net",
      "sourceCont" : "wasbs://tcfiles@tcfilestoreblob.blob.core.windows.net",
      "tempDir" : "/tempDirsTSA",
      "accountkey" : "fs.azure.account.key.tcfilestoreblob.blob.core.windows.net",
      "token" : "poQM6Hn0SuFP34iG8lGE/G9N9U9EaLT23+TMt7Sta4V4CC2Tb5NM55SZb+StS70BRt/a0yqapyVSB+FqNN9K/Q=="
    },
      "ADLSInfo":{
        "adls_url" : "adl://shell01eunadls1lserrccrn.azuredatalakestore.net/",
        "client_application_id" : "5115c531-6ce8-494d-b67d-964740500504",
        "adls_refresh_url" : "https://login.microsoftonline.com/db1e96a8-a3da-442a-930b-235cac24cd5c/oauth2/token"
      }
    }
}

# COMMAND ----------

from pyspark.sql import SparkSession, SQLContext

def sparkSession(app_name):
  spark = SparkSession\
      .builder\
      .appName(app_name)\
      .getOrCreate()
  return spark

# COMMAND ----------

# MAGIC %fs ls  dbfs:/mnt/ADLS/PROJECT/P00270-WONA_DWH_DEAL_DEV_UNHARM/NONPROD/MIRDBA.STO_PARCEL/WONA_DWH_DEAL_DEV_NONPROD_MIRDBA.STO_PARCEL.parquet/part-00135-efb22210-93f5-42fa-8a23-1b4e1d93d89a-c000.snappy.parquet

# COMMAND ----------

spark = sparkSession("dim_broker_load" )              
source_name = "DEX"
dataset_name = "STO_PRCLLDG"
query = "select adls_path as adls_full_path from tsa_curated.dataset_config a,tsa_curated.dataset_connection b where a.connection_name = b.connection_name and source_name = '{0}' and dataset_name = '{1}'".format(source_name,dataset_name)
  
df = jdbcReaderQuery(spark,query)

print("count", df.count())
v_adls_full_path=df.select('adls_full_path').collect()[0][0]
v_adls_full_path='/mnt/ADLS' + v_adls_full_path
  
print(v_adls_full_path)

# COMMAND ----------

from delta.tables import *

# COMMAND ----------

def jdbcConnection():
  import os
  config_root = getConfigRoot()
  kv_scope = tsaConfig[config_root]['authInfo']['kv_scope']
  kv_key = tsaConfig[config_root]['authInfo']['kv_key']
  
    
  dbDatabase = tsaConfig[config_root]['authInfo']['dbDatabase']
  
  if os.getenv('EXECUTION_CONTEXT') == 'TEST_HARNESS':
    dbDatabase = "TSA_CURATED_TEST_HARNESS"
  
  dbServer = tsaConfig[config_root]['authInfo']['dbServer']
  dbUser = tsaConfig[config_root]['authInfo']['dbUser']
  dbPass = dbutils.secrets.get(scope = kv_scope, key = kv_key)
  dbJdbcPort = tsaConfig[config_root]['authInfo']['dbJdbcPort']
  dbJdbcExtraOptions = tsaConfig[config_root]['authInfo']['dbJdbcExtraOptions']
  synapseUrl = "jdbc:sqlserver://" + dbServer + ":" + dbJdbcPort + ";database=" + dbDatabase + ";user=" + dbUser+";password=" + dbPass
 
  return synapseUrl

# COMMAND ----------

def readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, source_etrm, dataset_name, read_format, view_name):
  adls_path = getDatasetConfigForTheTable_new(spark,source_etrm,dataset_name)
  print(adls_path)
  df = spark.read.format(read_format).load(adls_path)
  df.createOrReplaceTempView(view_name)
  df = spark.sql("select * from {0} where IS_RECORD_ACTIVE = 1".format(view_name))
  df.createOrReplaceTempView(view_name)

# COMMAND ----------

spark = sparkSession("fact_dex_load" )              
SOURCE_ETRM = "DEX"
format = "delta"
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CONTRACT', format, 'STO_CONTRACT')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CDTYCTMT', format, 'STO_CDTYCTMT')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLCST', format, 'STO_PRCLCST')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PARCEL', format, 'STO_PARCEL')



# COMMAND ----------

df = spark.sql("select DEAL_ATTRIBUTES_NK,  count(*) from DEAL_ATTR_TEMP group by SRC_SYS_DEAL_SUB_LEG_KEY having count(*) > 1 ")
print("Total Duplicate Records")
df.show()

# COMMAND ----------

def getLastWaterMarkForTheTableColumnWise(spark, source_name,source_table_name,offset_column, table_name):
  
  query = "select last_offset_value from tsa_curated.watermark where source_name = '{0}' and source_table_name = '{1}' and table_name='{2}' and offset_column = '{3}'".format(source_name,source_table_name,table_name,offset_column)
  
  print(query)
  df = jdbcReaderQuery(spark,query)
  print("df" , df)
  print("df count" , df.count())
  v_last_offset_value=df.select('last_offset_value').collect()[0][0]
  
  return v_last_offset_value

# COMMAND ----------

def fetchEnvironment():
  current_env = tsaConfig['ENV_DETAIL']['CURRENT_ENV']
  return current_env

# COMMAND ----------

def getConfigRoot():
  current_env = fetchEnvironment()
  config_root = 'dataSets' + '_' + current_env
  return config_root

# COMMAND ----------

def jdbcReaderQuery(spark , query):
  synapse_url = jdbcConnection()
  read_df = spark.read.format("jdbc") \
      .option("url", synapse_url) \
      .option("query",query) \
      .option("inferSchema", True) \
      .load()
  
  return read_df

# COMMAND ----------

def getDatasetConfigForTheTable_new(spark,source_name,dataset_name):
  
  query = "select adls_path as adls_full_path from tsa_curated.dataset_config a,tsa_curated.dataset_connection b where a.connection_name = b.connection_name and source_name = '{0}' and dataset_name = '{1}'".format(source_name,dataset_name)
  
  df = jdbcReaderQuery(spark,query)
  v_adls_full_path=df.select('adls_full_path').collect()[0][0]
  v_adls_full_path='/mnt/ADLS' + v_adls_full_path
  
  return v_adls_full_path

# COMMAND ----------

last_watermark_fact_contract1 = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'STO_CONTRACT','CONTRACT_DATE','FACT_DEAL_HEADER')

print("readFactHeader", last_watermark_fact_contract1)
last_watermark_fact_contract1 = last_watermark_fact_contract1[0:19]

last_watermark_fact_contract2 =      getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'STO_CONTRACT','LAST_UPDATE_TSTMP','FACT_DEAL_HEADER')

last_watermark_fact_contract2 = last_watermark_fact_contract2[0:19]

#sum without group by
#watermark on which columns
#

SQL = """ select DEAL_ATTRIBUTES_NK,count(*) from (
          SELECT 
          a.TRDG_COMP_MNEM||'_'||a.CONTRACT_NUM||'_'||date_format(a.CONTRACT_CREATE_D,'yyyyMMdd') AS DEAL_ATTRIBUTES_NK,
          least(cast(c.execution_TSTMP as date), b.execution_TSTMP) AS EXECUTION_DATE,
          CASE WHEN date_format(a.CONTRACT_DATE,'yyyyMMdd') = '19000101' THEN a.CONTRACT_CREATE_D 
          ELSE A.CONTRACT_DATE END TRADE_CREATION_DATE,
          a.CLT_CHRG_ACCT_NUM AS COUNTERPARTY_NK,
          a.OWNG_CHRG_ACCT_NUM AS SHELL_TRADING_PARTY_NK,    
          a.TRADER_USERID AS TRADER_NK,
          d.CHRG_ACCT_NUM AS BROKER_NK,
          a.CTRACL_QTY_UNIT_C AS UNIT_OF_MEASURE_NK,
          a.CTRACL_QTY_AMT AS CONTRACT_QTY,
          a.LAST_UPDATE_TSTMP as SOURCE_LAST_DATE1,
          a.CONTRACT_DATE as SOURCE_LAST_DATE2,
          'NULL' as SOURCE_LAST_DATE3
          FROM        	STO_CONTRACT a
          JOIN        	STO_CDTYCTMT b
          ON          	a.contract_num = b.contract_num 
          AND         	a.contract_create_d = b.contract_create_d
          JOIN        	STO_PARCEL c
          ON          	b.contract_num = c.contract_num 
          AND         	b.contract_create_d = c.contract_create_d
          AND         	b.ctmt_seq_num = c.cdty_ctmt_seq_num
          LEFT JOIN   	STO_PRCLCST d
          ON          	c.contract_num = d.contract_num 
          AND         	c.prcl_seq_num = d.prcl_seq_num
          AND         	c.contract_create_d = d.contract_create_d
          WHERE
             ( 
             (
             a.CONTRACT_DATE > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
             ) 
             OR
             (
             a.CONTRACT_DATE < to_timestamp('{1}','yyyy-MM-dd HH:mm:ss') 
             and a.LAST_UPDATE_TSTMP > to_timestamp('{2}','yyyy-MM-dd HH:mm:ss')
             )
             ) )group by DEAL_ATTRIBUTES_NK having count(*) >1
    """.format(last_watermark_fact_contract1,last_watermark_fact_contract1,last_watermark_fact_contract2)

df = spark.sql(SQL)
df.count()

# COMMAND ----------

last_watermark_fact_contract1 = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'STO_CONTRACT','CONTRACT_DATE','FACT_DEAL_SUB_LEG')
last_watermark_fact_contract1 = last_watermark_fact_contract1[0:19] 

last_watermark_fact_contract2=getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'STO_CONTRACT','LAST_UPDATE_TSTMP','FACT_DEAL_SUB_LEG')
last_watermark_fact_contract2 = last_watermark_fact_contract2[0:19]

  #sum without group by
  #watermark on which columns
  #

# Changes
#  Removed Case    CASE WHEN date_format(a.CONTRACT_DATE,'yyyyMMdd') = '19000101' THEN CONTRACT_CREATE_D ELSE a.CONTRACT_DATE END
 # CASE WHEN date_format(a.CONTRACT_DATE,'yyyyMMdd') = '19000101' 
 #  THEN A.CONTRACT_CREATE_D ELSE a.CONTRACT_DATE END TRADE_CREATION_DATE,
#  Added   AND   h.SEQ_NUM = 1 
#

SQL = """ select DEAL_ATTRIBUTES_NK,count(*) from (
    SELECT	
    a.TRDG_COMP_MNEM||'_'||a.CONTRACT_NUM||'_'|| date_format(a.CONTRACT_CREATE_D,'yyyyMMdd')  AS DEAL_ATTRIBUTES_NK,
    least( cast(c.execution_TSTMP as date), b.execution_TSTMP) AS EXECUTION_DATE,
    a.CONTRACT_CREATE_D AS TRADE_CREATION_DATE,    
    b.COMMITMENT_DATE as COMMITMENT_DATE,
    c.PARCEL_DATE as PARCEL_DATE,
    a.CLT_CHRG_ACCT_NUM AS COUNTERPARTY_NK,
    a.OWNG_CHRG_ACCT_NUM AS SHELL_TRADING_PARTY_NK,
    a.TRADER_USERID AS TRADER_NK,
    d.CHRG_ACCT_NUM AS DEAL_BROKER_NK,
    b.GRADE_CODE as COMMODITY_NK,
    f.LOC_SEQ_NUM as LOADING_LOCATION_NK,
    g.LOC_SEQ_NUM as DISCHARGE_LOCATION_NK,
    c.DEL_PRD_START_DATE as DELIVERY_START_DATE,
    c.DEL_PRD_END_DATE as DELIVERY_END_DATE,
    (least(I.CALC_PRD_STRT_DATE, I.CALC_PRD_STRT_DATE)) as PRICING_START_DATE,
    ( greatest(I.CALC_PRD_END_DATE , I.CALC_PRD_END_DATE )) as PRICING_END_DATE,
    c.QTY_UNIT_CODE as DEAL_UNIT_OF_MEASURE_NK,
    d.UNITS_CODE as PRICING_UNIT_OF_MEASURE_NK,
    c.UNDL_PRC_CCY_C as DEAL_CCY_NK,
    e.FINAL_PRCL_PRICE * c.QTY_AMT * (CASE WHEN c.QTY_UNIT_CODE IN ('KT', 'KB') THEN 1000 ELSE 1 END) as CCY_DEAL_VALUE,
    c.QTY_AMT as DEAL_QTY,
    d.UNIT_COST_AMT as PRICE_QTY,    
    a.LAST_UPDATE_TSTMP as SOURCE_LAST_DATE1,
    a.CONTRACT_DATE as SOURCE_LAST_DATE2,
    '' as SOURCE_LAST_DATE3
    FROM        	STO_CONTRACT a
    JOIN        	STO_CDTYCTMT b
    ON          	a.CONTRACT_NUM = b.CONTRACT_NUM 
    AND         	a.CONTRACT_CREATE_D = b.CONTRACT_CREATE_D
    JOIN        	STO_PARCEL c
    ON          	b.CONTRACT_NUM = c.CONTRACT_NUM 
    AND         	b.CONTRACT_CREATE_D = c.CONTRACT_CREATE_D
    AND         	b.CTMT_SEQ_NUM = c.CDTY_CTMT_SEQ_NUM
    LEFT JOIN   	STO_PRCLCST d
    ON          	c.CONTRACT_NUM = d.CONTRACT_NUM 
    AND         	c.PRCL_SEQ_NUM = d.PRCL_SEQ_NUM
    AND         	c.CONTRACT_CREATE_D = d.CONTRACT_CREATE_D
    left join   	STO_PRICING e
    on          	c.PRCG_SEQ_NUM = e.SEQUENCE_NUM
    LEFT JOIN	STO_PRCLLDG f
    ON 	f.TRDG_COMP_MNEM = c.TRDG_COMP_MNEM
    AND 	f.CONTRACT_NUM = c.CONTRACT_NUM
    AND 	f.PRCL_SEQ_NUM = c. PRCL_SEQ_NUM
    LEFT JOIN STO_PRCLDCH g
    ON 	g.TRDG_COMP_MNEM = c.TRDG_COMP_MNEM
    AND 	g.CONTRACT_NUM = c.CONTRACT_NUM
    AND 	g.PRCL_SEQ_NUM = c. PRCL_SEQ_NUM
    LEFT JOIN 	STO_PRCGTERM h
    ON 	h. PRCG_SEQ_NUM = c.PRCG_SEQ_NUM
    AND   h.SEQ_NUM = 1 
    LEFT JOIN STO_PRCGPRDD i
    ON 	i.SEQUENCE_NUM = h.PRCG_PRD_DEF_SEQ_N 
    WHERE
       ( 
       (
       a.CONTRACT_DATE > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
       ) 
       OR
       (
       a.CONTRACT_DATE < to_timestamp('{1}','yyyy-MM-dd HH:mm:ss') 
       and a.LAST_UPDATE_TSTMP > to_timestamp('{2}','yyyy-MM-dd HH:mm:ss')
       )
       )   )group by DEAL_ATTRIBUTES_NK having count(*) >1

    """.format(last_watermark_fact_contract1,last_watermark_fact_contract1,last_watermark_fact_contract2)
df = spark.sql(SQL)
df.count()


# COMMAND ----------

readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CONTRACT', format, 'STO_CONTRACT')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CDTYCTMT', format, 'STO_CDTYCTMT')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLCST', format, 'STO_PRCLCST')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PARCEL', format, 'STO_PARCEL')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRICING', format, 'STO_PRICING')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLLDG', format, 'STO_PRCLLDG')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCLDCH', format, 'STO_PRCLDCH')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCGTERM', format, 'STO_PRCGTERM')
readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PRCGPRDD', format, 'STO_PRCGPRDD')

# COMMAND ----------

def writeDatasetSynapseConnector(spark, dataset_df, db_table):
  synapse_url1 = jdbcConnection()
  print(synapse_url1)
  (config, sourceCont, tempDir, accountkey , token) = fetchBlobStorageConfigForSynapseConnector()
  
  spark.conf.set(
    accountkey,
    token)
  
  temp_dir=sourceCont+tempDir
  
  print("config ",config)
  print("temp_dir ",temp_dir)
  print("accountkey ",accountkey)
  print("token ",token)
  
  print(synapse_url1)
  
  dataset_df.write.format("com.databricks.spark.sqldw").mode("append") \
        .option("url", synapse_url1) \
        .option("tempDir", temp_dir) \
        .option("forwardSparkAzureStorageCredentials", "true")\
        .option("dbTable",db_table) \
        .save()

# COMMAND ----------

#spark = sparkSession("dim_broker_load" )          
from pyspark.sql.functions import col
from pyspark.sql.functions import when
dataDF = spark.createDataFrame([(66, "a", "4"), 
                                (67, "a", "0"), 
                                (70, "b", "4"), 
                                (71, "d", "4")],
                                ("id", "code", "amt"))
dataDF.withColumn("new_column",
       when((col("code") == "a") | (col("code") == "d"), "A")
      .when((col("code") == "b") & (col("amt") == "4"), "B")
      .otherwise("A1")).show()

# COMMAND ----------

# Azure Blob Storage
containerName = "tcfiles"
storageAccountName = "tcfilestoreblob"
config = "fs.azure.sas." + containerName+ "." + storageAccountName + ".blob.core.windows.net"
sourceCont = "wasbs://" + containerName + "@" + storageAccountName + ".blob.core.windows.net"


tempDir = sourceCont +"/tempDirs"

#synapse_server="shell-01-eun-sq-jugjhnpwhhmrodlueolg.database.windows.net"
#synapse_db="shell-01-eun-sqdw-zhmlmkezgutgtabfdenp"
#synapse_secret="geneva-dbmaint-pwd"
#synapse_db_user="geneva_dbmaint"
#synapse_jdbc_port="1433"

#synapse_url = f"jdbc:sqlserver://{synapse_server}:{synapse_jdbc_port};database={synapse_db};user={synapse_db_user};password={dbutils.secrets.get(scope='DatabricksKVScope', key=synapse_secret)}"

spark.conf.set(
  "fs.azure.account.key.tcfilestoreblob.blob.core.windows.net",
  "poQM6Hn0SuFP34iG8lGE/G9N9U9EaLT23+TMt7Sta4V4CC2Tb5NM55SZb+StS70BRt/a0yqapyVSB+FqNN9K/Q==")



df = spark.read \
  .format("com.databricks.spark.sqldw") \
  .option("url", synapse_url) \
  .option("tempDir", tempDir) \
  .option("forwardSparkAzureStorageCredentials", "true")\
  .option("dbTable", "system_terminal_cockpit.synapse_Con_test") \
  .load()

# COMMAND ----------

  df = spark.sql("select DEAL_ATTRIBUTES_NK,  count(*) from DEAL_ATTR_TEMP group by SRC_SYS_DEAL_SUB_LEG_KEY having count(*) > 1 ")
  print("Total Duplicate Records")
  df.show()

# COMMAND ----------

  SQL = """select *
  from USER_SYN_EXTRACTIONLOG log 
where LOG.SIM_PFOLIO = 40059.0
and LOG.SIM_RUN_TIME = (select max(log2.sim_run_time) from USER_SYN_EXTRACTIONLOG log2 where LOG2.SIM_RUN_TYPE = 1)   
  """      
  df = spark.sql(SQL)
  print("Total Duplicate Records")
  df.show()

# COMMAND ----------

  SQL = """select a.deal_tracking_num, a.ins_num,d.param_seq_num,profile_seq_num, count(*)
  from ab_tran a  
  join INSTRUMENTS b on a.ins_type = b.id_number
  join TOOLSETS t on a.toolset = T.ID_NUMBER
  join PORTFOLIO c on a.internal_portfolio = c.id_number
  join INS_PARAMETER f on a.ins_num = f.ins_num
  join PROFILE d on f.param_seq_num = d.param_seq_num and f.ins_num = d.ins_num
  JOIN SETTLE_TYPE g ON          g.id_number =f.settlement_type  
  join TRANS_STATUS k on a.tran_status = k.trans_status_id
  left join INS_OPTION l on f.ins_num = l.ins_num and f.param_seq_num = l.param_seq_num
  where tran_status in( 3, 4, 5)
  and current_flag = 1
  and b.name not in ('CASH'
      ,'COMM-FEE'
      ,'COMM-IMB'
      ,'COMM-INV'
      ,'COMM-INV-PAL'
      ,'COMM-MAD-SETTLE'
      ,'COMM-PAL'
      ,'COMM-PREPAY'
      ,'COMM-STOR'
      ,'COMM-TRANS'
      ,'COMM-TRANS-PLAN')
  group by a.deal_tracking_num, a.ins_num,d.param_seq_num,profile_seq_num
  having count(*) > 1
  """      
  df = spark.sql(SQL)
  print("Total Duplicate Records")
  df.show(100)

# COMMAND ----------

  readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN', format, 'AB_TRAN') 

  SQL = """
select ins_num,param_seq_num, count(1) 
from INS_OPTION a 
where LatestSCDRecordFlag ='Y' 
group by ins_num,param_seq_num having count(1) > 1

  """      
  df = spark.sql(SQL)
  print("Total Duplicate Records")
  df.show()

# COMMAND ----------

print(df.count())

# COMMAND ----------

  SQL = """select a.deal_tracking_num, a.ins_num,a.tran_num, tran_status,SCDColumnsHash,LatestSCDRecordFlag
  from ab_tran a  
  where a.deal_tracking_num = 12284596
  and a.ins_num = 9282773
  """      
  df = spark.sql(SQL)
  print("Total Duplicate Records")
  df.show()

# COMMAND ----------

  SQL = """select a.deal_tracking_num, a.ins_num
  from ab_tran a  
  join INS_PARAMETER f on a.ins_num = f.ins_num
  join PROFILE d on f.param_seq_num = d.param_seq_num and f.ins_num = d.ins_num
  where a.deal_tracking_num = 12284596
  and a.ins_num = 9282773
  and d.param_seq_num
  """      
  df = spark.sql(SQL)
  print("Total Duplicate Records")
  df.show()

# COMMAND ----------

  SQL = """select a.deal_tracking_num, a.ins_num,d.PARAM_SEQ_NUM,d.profile_seq_num 
  from ab_tran a  
  join INS_PARAMETER f on a.ins_num = f.ins_num
  join PROFILE d on f.param_seq_num = d.param_seq_num and f.ins_num = d.ins_num
  where a.deal_tracking_num = 12284596
  and a.ins_num = 9282773
  and d.PARAM_SEQ_NUM	= 4
  and d.profile_seq_num = 6
  """      
  df = spark.sql(SQL)
  print("Total Duplicate Records")
  df.show()
  
