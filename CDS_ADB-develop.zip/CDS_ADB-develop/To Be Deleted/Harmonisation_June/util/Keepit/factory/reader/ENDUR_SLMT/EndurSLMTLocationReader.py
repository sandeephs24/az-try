# Databricks notebook source
# MAGIC %run ./../../enricher/LocationMappingEnricher

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../enricher/LocationMappingEnricher

# COMMAND ----------

class EndurSLMTLocationReader(SourceDatasetReader):
    
   def read(spark,metricDict):
      SOURCE_ETRM = 'ENDUR_SLMT'
      
      last_watermark_location=getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'GAS_PHYS_LOCATION','DIM_LOCATION')
      last_watermark_location = last_watermark_location[0:19]
      
      df = executeJdbcQueryAndReturnDF("select SRC_SYS_LOCATION_NK from tsa_curated.dim_location where src_sys_name = '{0}'".format(SOURCE_ETRM))
      df.createOrReplaceTempView("CURATED_DIM_LOCATION")
        
      LOCATION_READ_SQL = """
      select gpl.location_id SRC_SYS_LOCATION_NK,          
      gpl.location_name LOCATION_NAME,           
      gplt.loc_type_name LOCATION_TYPE,           
      gpz.zone_name LOCATION_AREA,
      gpl.last_update SOURCE_LAST_UPDATE
      from gas_phys_location gpl
      left join gas_phys_loc_type gplt
      on gplt.loc_type_id = gpl.location_type
      left join gas_phys_zones gpz
      on gpl.zone_id = gpz.zone_id
      where (
      gpl.last_update > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss')
      or 
      gpl.location_id in (select SRC_SYS_LOCATION_NK from CURATED_DIM_LOCATION)
      )
      """.format(last_watermark_location)      
      
      #format = "delta"
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'GAS_PHYS_LOCATION', 'parquet', 'GAS_PHYS_LOCATION')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'GAS_PHYS_LOC_TYPE', 'parquet', 'GAS_PHYS_LOC_TYPE')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'GAS_PHYS_ZONES', 'parquet', 'GAS_PHYS_ZONES')
      
      df = spark.sql(LOCATION_READ_SQL)
      
      df = enrichLocationForMapping(spark,df,SOURCE_ETRM)
            
      return (df,metricDict)
  
