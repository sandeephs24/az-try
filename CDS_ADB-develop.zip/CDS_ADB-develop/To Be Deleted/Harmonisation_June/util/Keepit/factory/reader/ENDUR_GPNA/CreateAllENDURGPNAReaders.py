# Databricks notebook source
# MAGIC %run ../DatasetReader

# COMMAND ----------

# MAGIC %run ./EndurGPNABrokerReader

# COMMAND ----------

# MAGIC %run ./EndurGPNACommodityReader

# COMMAND ----------

# MAGIC %run ./EndurGPNACounterPartyReader

# COMMAND ----------

# MAGIC %run ./EndurGPNALocationReader

# COMMAND ----------

# MAGIC %run ./EndurGPNADealAttributesReader

# COMMAND ----------

# MAGIC %run ./EndurGPNATraderReader

# COMMAND ----------

# MAGIC %run ./EndurGPNACurrencyReader

# COMMAND ----------

# MAGIC %run ./EndurGPNAUnitOfMeasureReader

# COMMAND ----------

# MAGIC %run ./FACT/EndurGPNAFactReader
