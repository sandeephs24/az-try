# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../../../WatermarkReader

# COMMAND ----------

class EndurGPNAFactLegReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM,metricDict, initial_load):
        
    (dfLeg, metricDict) = readFactLeg(spark, SOURCE_ETRM,metricDict, initial_load)

    return (dfLeg, metricDict)

# COMMAND ----------

  def readFactLeg(spark, SOURCE_ETRM,metricDict, initial_load):
    from pyspark.sql.functions import concat
    from datetime import datetime
    current_date_yyyymmdd = datetime.today().strftime('%Y%m%d')
    
    last_watermark_trade_date = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'AB_TRAN','TRADE_DATE', 'FACT_DEAL_LEG')
    last_watermark_trade_date = last_watermark_trade_date[0:19]
    
    last_watermark_input_date = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'AB_TRAN','INPUT_DATE', 'FACT_DEAL_LEG')
    last_watermark_input_date = last_watermark_input_date[0:19]
    
    last_watermark_last_update = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'AB_TRAN','LAST_UPDATE', 'FACT_DEAL_LEG')
    last_watermark_last_update = last_watermark_last_update[0:19]
    
    if initial_load == "Y":
      tran_status_list = "3,4,5"
    else:
      tran_status_list = "3,5"
    
    SQL = """   
    select 
    DEAL_ATTRIBUTES_NK,
    EXECUTION_DATE,
    TRADE_CREATION_DATE,
    COMMITMENT_DATE,
    COUNTERPARTY_NK,
    SHELL_TRADING_PARTY_NK,
    TRADER_NK,
    DEAL_BROKER_NK,
    UNIT_OF_MEASURE_NK,
    COMMODITY_NK,
    SOURCE_LAST_DATE1,
    SOURCE_LAST_DATE2,
    SOURCE_LAST_DATE3,
    COMMITMENT_QTY,
    CASE WHEN notnl < 0 THEN -1 WHEN notnl > 0 THEN 1 ELSE 0 END as DEAL_LEG_MULTIPLIER,
    SRC_SYS_DEAL_HEADER_KEY
    from(
    select DEAL_ATTRIBUTES_NK,
    EXECUTION_DATE,
    TRADE_CREATION_DATE,
    COMMITMENT_DATE,
    COUNTERPARTY_NK,
    SHELL_TRADING_PARTY_NK,
    TRADER_NK,
    DEAL_BROKER_NK,
    UNIT_OF_MEASURE_NK,
    COMMODITY_NK,
    SOURCE_LAST_DATE1,
    SOURCE_LAST_DATE2,
    SOURCE_LAST_DATE3,
    sum(abs(COMMITMENT_QTY)) COMMITMENT_QTY,
    sum(notnl) notnl,
    SRC_SYS_DEAL_HEADER_KEY
    from(
    SELECT 
    t.input_date EXECUTION_DATE
    , t.trade_date TRADE_CREATION_DATE
    , t.trade_date COMMITMENT_DATE
    , T.EXTERNAL_BUNIT  as COUNTERPARTY_NK
    , T.INTERNAL_BUNIT  as SHELL_TRADING_PARTY_NK
    , (t.deal_tracking_num || '_' || fz.ins_num || '_' || fz.param_seq_num) as DEAL_ATTRIBUTES_NK
    , T.INTERNAL_CONTACT AS TRADER_NK
    , CASE WHEN t.OTC_CLEARING_BROKER_ID = 0 
         THEN (CASE WHEN t.BROKER_ID != 0 THEN t.BROKER_ID
         WHEN (pa3.PARTY_ID IS NOT NULL or pa1.PARTY_ID IS NOT NULL or pa5.PARTY_ID IS NOT NULL or pa2.PARTY_ID IS NOT NULL)
    THEN (case 
    when pa3.PARTY_ID is not null then pa3.PARTY_ID
    when pa1.PARTY_ID is not null then pa1.PARTY_ID
    when pa5.PARTY_ID is not null then pa5.PARTY_ID
    when pa2.PARTY_ID is not null then pa2.PARTY_ID else null end)
	ELSE pa.PARTY_ID END)
    ELSE  T.OTC_CLEARING_BROKER_ID 
    END AS DEAL_BROKER_NK
    , fz.unit as UNIT_OF_MEASURE_NK
    , d2.id_number as COMMODITY_NK
    , t.trade_date source_last_date1
    , t.input_date source_last_date2
    , t.last_update source_last_date3
    , dz.notnl COMMITMENT_QTY
    ,dz.notnl notnl
    ,t.deal_tracking_num SRC_SYS_DEAL_HEADER_KEY
    FROM	AB_TRAN t
    JOIN 	INSTRUMENTS bz 
      ON 	t.ins_type = bz.id_number
    LEFT JOIN	AB_TRAN_INFO  d
      ON	t.tran_num = d.tran_num and d.type_id = 20021
    LEFT JOIN	PARTY pa          
      ON	d.value = pa.short_name
    left join (select tran_num,broker_id from AB_TRAN_PROVISIONAL where PROV_TYPE=3) ap3 
              on t.tran_num=ap3.tran_num 
    left join (select tran_num,broker_id from AB_TRAN_PROVISIONAL where PROV_TYPE=1) ap1 
              on t.tran_num=ap1.tran_num
    left join (select tran_num,broker_id from AB_TRAN_PROVISIONAL where PROV_TYPE=5) ap5 
              on t.tran_num=ap5.tran_num
   left join (select tran_num,broker_id from AB_TRAN_PROVISIONAL where PROV_TYPE=2) ap2 
              on t.tran_num=ap2.tran_num
    left join PARTY pa3 
    on ap3.broker_id = pa3.party_id
    left join PARTY pa1
    on ap1.broker_id = pa1.party_id
    left join PARTY pa5 
    on ap5.broker_id = pa5.party_id
    left join PARTY pa2
    on ap2.broker_id = pa2.party_id
    JOIN	INS_PARAMETER fz 
      ON	t.ins_num = fz.ins_num
    JOIN	PROFILE dz
      ON	fz.param_seq_num = dz.param_seq_num 
      and fz.ins_num = dz.ins_num 
    JOIN	PARAMETER b2 
      ON	t.ins_num =b2.ins_num 
      and b2.param_seq_num = dz.param_seq_num
    LEFT JOIN	gas_phys_param gpp 
      ON	gpp.ins_num = b2.ins_num 
      AND	gpp.param_seq_num = b2.param_seq_num      
    LEFT JOIN	IDX_DEF c2 
      ON	b2.proj_index =c2.index_id AND	c2.VALIDATED = 1 and c2.DB_STATUS = 1
    LEFT JOIN	IDX_GROUP d2 
      ON	c2.idx_group =d2.id_number   
    WHERE t.tran_status in ({5})
    AND t.current_flag = 1
    and t.tran_type = 0
    and (
      (
      bz.name in ('COMM-LDC', 'COMM-PHYS', 'COMM-PHYS-USAGE', 'COMM-EXCH') 
      and gpp.ins_num is not null and b2.settlement_type = 2
      )
      OR
      ( bz.name not in ('COMM-LDC', 'COMM-PHYS', 'COMM-PHYS-USAGE', 'COMM-EXCH'))
      )
    AND(    
     (t.trade_date > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss') and t.trade_date <= '{1}')
     OR
     (t.trade_date <= '{2}' and t.input_date > to_timestamp('{3}','yyyy-MM-dd HH:mm:ss'))
     OR
     (t.last_update > to_timestamp('{4}','yyyy-MM-dd HH:mm:ss') )
    )
    AND bz.name not in ('CASH' ,
                            'COMM-FEE' ,
                            'COMM-IMB' ,
                            'COMM-INV' ,
                            'COMM-INV-PAL' ,
                            'COMM-MAD-SETTLE' ,
                            'COMM-PAL' ,
                            'COMM-PREPAY' ,
                            'COMM-STOR' ,
                            'COMM-TRANS' ,
                            'COMM-TRANS-PLAN' ,
                            'COMM-MAD-JE','COMM-IMB-SENA') 
    ) V group by
    DEAL_ATTRIBUTES_NK,
    EXECUTION_DATE,
    TRADE_CREATION_DATE,
    COMMITMENT_DATE,
    COUNTERPARTY_NK,
    SHELL_TRADING_PARTY_NK,
    TRADER_NK,
    DEAL_BROKER_NK,
    UNIT_OF_MEASURE_NK,
    COMMODITY_NK,
    source_last_date1,
    source_last_date2,
    source_last_date3,
    SRC_SYS_DEAL_HEADER_KEY
    )
    """.format(last_watermark_trade_date, 
               current_date_yyyymmdd, 
               current_date_yyyymmdd, 
               last_watermark_input_date, 
               last_watermark_last_update,
               tran_status_list
              )
    
    format = "delta"
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN', format, 'AB_TRAN')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'INSTRUMENTS', format, 'INSTRUMENTS')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN_INFO', format, 'AB_TRAN_INFO')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PARTY', "parquet", 'PARTY')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'INS_PARAMETER', format, 'INS_PARAMETER')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'GAS_PHYS_PARAM', format, 'GAS_PHYS_PARAM')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PROFILE', format, 'PROFILE')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'IDX_DEF', format, 'IDX_DEF')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'IDX_GROUP', format, 'IDX_GROUP')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PARAMETER', format, 'PARAMETER')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN_PROVISIONAL', format, 'AB_TRAN_PROVISIONAL')
    
    dfLeg = spark.sql(SQL)
    return (dfLeg, metricDict)
