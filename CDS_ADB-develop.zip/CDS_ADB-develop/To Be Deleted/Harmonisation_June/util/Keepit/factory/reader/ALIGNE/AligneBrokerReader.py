# Databricks notebook source
# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

class AligneBrokerReader(SourceDatasetReader):
        def read(spark,metricDict):
          print('here')
          SOURCE_ETRM = 'ALIGNE'
          #last_watermark = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_CHRGACCT','DIM_BROKER')
          #last_watermark = last_watermark[0:19]
          
          df = executeJdbcQueryAndReturnDF("select src_sys_broker_nk from tsa_curated.dim_broker where src_sys_name = '{0}'".format(SOURCE_ETRM))
          df.createOrReplaceTempView("CURATED_DIM_BROKER")
        
        
        
          BROKER_READ_SQL = """
           SELECT CPTY_CPTY as SRC_SYS_BROKER_NK,CPTY_DSC as BROKER_NAME,CPTY_ACTIVE as ACTIVE_BROKER_FLAG,SOURCE_LAST_UPDATE FROM (
             SELECT b.CPTY_CPTY,b.CPTY_DSC,b.CPTY_ACTIVE,b.CPTY_ADATE1,'1900-01-01 00:00:00' as SOURCE_LAST_UPDATE ,
             row_number() over (Partition by CPTY_CPTY ORDER BY CPTY_ADATE1 DESC) row_num
             FROM STATIC_CPTY b
             WHERE CPTY_TYPE='B'
             AND CPTY_CPTY <> 'DIRECT'
          ) WHERE row_num=1
          """

          format = "parquet"
          readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_CPTY', format, 'STATIC_CPTY')
          print('starting reader')
          df = spark.sql(BROKER_READ_SQL)
          print('Broker Reader count:')
          print(df.count())
          print('reader completed')
          return (df,metricDict)

