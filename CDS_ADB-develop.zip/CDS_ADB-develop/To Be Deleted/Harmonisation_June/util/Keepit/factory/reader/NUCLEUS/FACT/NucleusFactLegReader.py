# Databricks notebook source



# COMMAND ----------

# MAGIC 
# MAGIC 
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

class NucleusFactLegReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
    
    (dfLeg, metricDict) = readFactLeg(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD)

    return (dfLeg, metricDict)

# COMMAND ----------

def readFactLeg(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
  from pyspark.sql.functions import concat
  from datetime import datetime
  current_date_yyyymmdd = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
  print(current_date_yyyymmdd)
  
  last_watermark_dmd1 = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'DEAL_MONTH_DETAILS','TRADE_DATE','FACT_DEAL_HEADER')
  last_watermark_dmd1 = last_watermark_dmd1[0:19]

  last_watermark_dmd2 = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'DEAL_MONTH_DETAILS','MODIFY_DATE','FACT_DEAL_HEADER')
  last_watermark_dmd2 = last_watermark_dmd2[0:19]
  
  last_watermark_dd = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'DEAL_DETAILS','CREATE_DATE','FACT_DEAL_HEADER')
  last_watermark_dd = last_watermark_dd[0:19]  
  
   
  
  if INITIAL_LOAD == "Y" :
    SQL = getLegReaderSQLDay0(last_watermark_dmd1)
  else:
    SQL = getLegReaderSQLDay1(last_watermark_dmd1,current_date_yyyymmdd,last_watermark_dd,last_watermark_dmd2)
  
  
  format = "delta"
  readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'DEAL_MONTH_DETAILS', format, 'DEAL_MONTH_DETAILS')
  readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'FLAT_BROKER_FEES', format, 'FLAT_BROKER_FEES')
  readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'DEAL_CONFIRMS', format, 'DEAL_CONFIRMS')
  readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'BROKER_COMMISSION_MONTHS', format, 'BROKER_COMMISSION_MONTHS')
  readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'CLEARINGBROKER_FEES', format, 'CLEARINGBROKER_FEES')
  readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'DEAL_DETAILS', format, 'DEAL_DETAILS')
  readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'PROCESS_DATE', format, 'PROCESS_DATE')
  readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN_history(spark, SOURCE_ETRM, 'NXTGEN_CCR_DTL_HIST_VIEW', 'parquet', 'NXTGEN_CCR_DTL_HIST_VIEW')
  readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN_history(spark, SOURCE_ETRM, 'NXTGEN_CCR_DTL_VIEW', 'parquet', 'NXTGEN_CCR_DTL_VIEW')

  dfLeg = spark.sql(SQL)
  
  dfLeg = dfLeg.withColumn("SHELL_TRADING_PARTY_NK",dfLeg.SHELL_TRADING_PARTY_NK.cast('int'))
  dfLeg = dfLeg.withColumn("COUNTERPARTY_NK",dfLeg.COUNTERPARTY_NK.cast('int'))

  dfLeg.show(10,truncate=False)
  
  print("DexFactLegReader" , dfLeg.count())

  
  return (dfLeg, metricDict)

# COMMAND ----------

def getLegReaderSQLDay1(last_watermark_dmd1,current_date_yyyymmdd,last_watermark_dd,last_watermark_dmd2):

    SQL = """   SELECT
      DEAL_ATTRIBUTES_NK,
      EXECUTION_DATE,
      TRADE_CREATION_DATE,
      COMMITMENT_DATE,
      COUNTERPARTY_NK,
      SHELL_TRADING_PARTY_NK,
      TRADER_NK,
      DEAL_BROKER_NK,
      COMMODITY_NK,
      UNIT_OF_MEASURE_NK,
      sum(COMMITMENT_QTY_AMT) AS COMMITMENT_QTY,
      DEAL_LEG_MULTIPLIER,
      max(source_last_date1) as source_last_date1 ,
      max(source_last_date2) as source_last_date2,
      max(source_last_date3) as source_last_date3,
      SRC_SYS_DEAL_HEADER_KEY
      from(     
	      SELECT DMD.DEAL_KEY||'_'||(CASE WHEN DMD.DLT_DEAL_TYPE = 'POWER' AND DMD.PRICE_TYPE = 'I' THEN 'PWRIDX' 
             WHEN DMD.TRUE_DEAL_TYPE IN ('TCCSWP','POWER') THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END)
             ||'_'||cast(DMD.VOLUME_SEQ as int)||'_'||cast(DMD.DETAIL_SEQ as int)||'_'||cast(DMD.CM_CONTRACT_MONTH as int)	 AS DEAL_ATTRIBUTES_NK,
             DMD.TRADE_DATE  AS EXECUTION_DATE,
            DMD.TRADE_DATE  AS TRADE_CREATION_DATE,
            DMD.DY_BEG_DAY  AS COMMITMENT_DATE,
            DMD.CY_COMPANY_KEY  AS COUNTERPARTY_NK,
            DMD.LGL_CY_ENTITY_KEY  AS SHELL_TRADING_PARTY_NK,
            FIRST_VALUE (NVL(DC.UR_TRADER,DMD.UR_TRADER)) OVER(PARTITION BY DMD.DEAL_KEY, DMD.TRUE_DEAL_TYPE ORDER BY DMD.DEAL_KEY, DMD.TRUE_DEAL_TYPE, DMD.VOLUME_SEQ, DMD.DETAIL_SEQ, DMD.CM_CONTRACT_MONTH)  AS TRADER_NK,
            CASE WHEN FBF.CY_BROKER_KEY IS NOT NULL THEN FBF.CY_BROKER_KEY
                  WHEN BCM.CY_BROKER_KEY IS NOT NULL THEN BCM.CY_BROKER_KEY
                  WHEN CBC.CY_CBROKER_KEY IS NOT NULL THEN CBC.CY_CBROKER_KEY
                  ELSE NULL END AS DEAL_BROKER_NK,
      CASE WHEN DMD.DLT_DEAL_TYPE IN ('SPDOPT','HRSWPS','EXOTIC') THEN 'INVALID' ELSE FIRST_VALUE (DMD.COM_COMMODITY)over(partition by dmd.true_deal_type, dmd.deal_key) END AS COMMODITY_NK,
            DMD.UT_UNIT  AS UNIT_OF_MEASURE_NK,
            ABS(DMD.R_DEAL_VOLUME + DMD.U_DEAL_VOLUME) AS COMMITMENT_QTY_AMT,
            FIRST_VALUE(CASE WHEN DMD.DLT_DEAL_TYPE IN('FTROPT', 'FTRSWP', 'TCCSWP')
                    OR (DMD.DLT_DEAL_TYPE = 'HRSWPS' AND DMD.UT_UNIT = 'MMBTU') 
                    THEN
                        CASE WHEN DMD.DN_DIRECTION = 'SALE' THEN 1.0
                        ELSE -1.0
                        END
                    ELSE
                        CASE WHEN DMD.DN_DIRECTION = 'SALE' THEN -1.0
                        ELSE 1.0
                        END
                END)  OVER(PARTITION BY CASE WHEN DMD.DLT_DEAL_TYPE = 'POWER' AND DMD.PRICE_TYPE = 'I' THEN 'PWRIDX' WHEN DMD.TRUE_DEAL_TYPE IN ('TCCSWP','POWER') THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END,
                            DMD.DEAL_KEY ORDER BY DMD.CM_CONTRACT_MONTH, DMD.VOLUME_SEQ, DMD.DETAIL_SEQ)   AS DEAL_LEG_MULTIPLIER,
           DMD.TRADE_DATE AS source_last_date1,
            dd.create_date AS source_last_date2,
            dmd.modify_date AS source_last_date3, 
            DMD.DEAL_KEY||'_'||(CASE WHEN DMD.DLT_DEAL_TYPE = 'POWER' AND DMD.PRICE_TYPE = 'I' THEN 'PWRIDX' 
             WHEN DMD.TRUE_DEAL_TYPE IN ('TCCSWP','POWER') THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END) AS SRC_SYS_DEAL_HEADER_KEY
            FROM DEAL_MONTH_DETAILS DMD
        LEFT JOIN FLAT_BROKER_FEES FBF 
            ON DMD.DEAL_KEY = FBF.DEAL_KEY 
            AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE FBF.DLT_DEAL_TYPE WHEN 'PWRNSD' THEN 'POWER' ELSE FBF.DLT_DEAL_TYPE END)

        LEFT JOIN BROKER_COMMISSION_MONTHS BCM ON DMD.DEAL_KEY = BCM.DEAL_KEY AND DMD.CM_CONTRACT_MONTH = BCM.CM_CONTRACT_MONTH 
            AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE BCM.DLT_DEAL_TYPE WHEN 'PWRNSD' THEN 'POWER' ELSE BCM.DLT_DEAL_TYPE END) 
            AND DMD.FP_LOCATION = BCM.BP_BASIS_POINT

        LEFT JOIN CLEARINGBROKER_FEES CBC ON DMD.DEAL_KEY = CBC.DEAL_KEY 
            AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE CBC.DLT_DEAL_TYPE WHEN 'PWRNSD' THEN 'POWER' ELSE CBC.DLT_DEAL_TYPE END)


        LEFT JOIN   DEAL_DETAILS DD 
        ON DMD.DEAL_KEY = DD.DEAL_KEY AND DMD.DLT_DEAL_TYPE = DD.DLT_DEAL_TYPE
        LEFT JOIN   DEAL_CONFIRMS DC
ON DMD.DEAL_KEY = DC.DEAL_KEY
AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = DC.DLT_DEAL_TYPE) 
where (
            (DMD.TRADE_DATE >= '{0}' and dd.create_date <= '{1}')
            or
            (dmd.trade_date <= '{2}' and  dd.create_date > '{3}')
            or
            (dmd.modify_date > '{4}'))
    AND        DMD.DLT_DEAL_TYPE NOT IN('BSWPS', 'BSWPOF', 'SWPS', 'SSWPS', 'OTCOPT', 'FSWPS', 'IMBAL', 'FTOPOF', 'FTSWOF', 'TCSWOF')  
    AND       (DMD.ST_SETTLEMENT_TYPE NOT LIKE 'NG%' OR DMD.ST_SETTLEMENT_TYPE IS NULL))
    group by
    DEAL_ATTRIBUTES_NK,EXECUTION_DATE,TRADE_CREATION_DATE,COMMITMENT_DATE,COUNTERPARTY_NK,SHELL_TRADING_PARTY_NK,TRADER_NK,DEAL_BROKER_NK,
    COMMODITY_NK,UNIT_OF_MEASURE_NK,DEAL_LEG_MULTIPLIER,
      SRC_SYS_DEAL_HEADER_KEY
       """.format(last_watermark_dmd1,current_date_yyyymmdd,current_date_yyyymmdd,last_watermark_dd,last_watermark_dmd2)
  
    return SQL
  

# COMMAND ----------

def getLegReaderSQLDay0(last_watermark_dmd1):
      SQL = """ 
      SELECT
      DEAL_ATTRIBUTES_NK,
      EXECUTION_DATE,
      TRADE_CREATION_DATE,
      COMMITMENT_DATE,
      COUNTERPARTY_NK,
      SHELL_TRADING_PARTY_NK,
      TRADER_NK,
      DEAL_BROKER_NK,
      COMMODITY_NK,
      UNIT_OF_MEASURE_NK,
      sum(COMMITMENT_QTY_AMT) AS COMMITMENT_QTY,
      DEAL_LEG_MULTIPLIER,
      max(source_last_date1) as source_last_date1 ,
      max(source_last_date2) as source_last_date2,
      max(source_last_date3) as source_last_date3,
      SRC_SYS_DEAL_HEADER_KEY
      from(     
	      SELECT DMD.DEAL_KEY||'_'||(CASE WHEN DMD.DLT_DEAL_TYPE = 'POWER' AND DMD.PRICE_TYPE = 'I' THEN 'PWRIDX' 
             WHEN DMD.TRUE_DEAL_TYPE IN ('TCCSWP','POWER') THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END)
             ||'_'||cast(DMD.VOLUME_SEQ as int)||'_'||cast(DMD.DETAIL_SEQ as int)||'_'||cast(DMD.CM_CONTRACT_MONTH as int)	 AS DEAL_ATTRIBUTES_NK,
             DMD.TRADE_DATE  AS EXECUTION_DATE,
            DMD.TRADE_DATE  AS TRADE_CREATION_DATE,
            DMD.DY_BEG_DAY  AS COMMITMENT_DATE,
            DMD.CY_COMPANY_KEY  AS COUNTERPARTY_NK,
            DMD.LGL_CY_ENTITY_KEY  AS SHELL_TRADING_PARTY_NK,
            FIRST_VALUE (NVL(DC.UR_TRADER,DMD.UR_TRADER)) OVER(PARTITION BY DMD.DEAL_KEY, DMD.TRUE_DEAL_TYPE ORDER BY DMD.DEAL_KEY, DMD.TRUE_DEAL_TYPE, DMD.VOLUME_SEQ, DMD.DETAIL_SEQ, DMD.CM_CONTRACT_MONTH)  AS TRADER_NK,
            CASE WHEN FBF.CY_BROKER_KEY IS NOT NULL THEN FBF.CY_BROKER_KEY
                  WHEN BCM.CY_BROKER_KEY IS NOT NULL THEN BCM.CY_BROKER_KEY
                  WHEN CBC.CY_CBROKER_KEY IS NOT NULL THEN CBC.CY_CBROKER_KEY
                  ELSE NULL END AS DEAL_BROKER_NK,
      CASE WHEN DMD.DLT_DEAL_TYPE IN ('SPDOPT','HRSWPS','EXOTIC') THEN 'INVALID' ELSE FIRST_VALUE (DMD.COM_COMMODITY)over(partition by dmd.true_deal_type, dmd.deal_key) END AS COMMODITY_NK,
            DMD.UT_UNIT  AS UNIT_OF_MEASURE_NK,
            ABS(DMD.R_DEAL_VOLUME + DMD.U_DEAL_VOLUME) AS COMMITMENT_QTY_AMT,
            FIRST_VALUE(CASE WHEN DMD.DLT_DEAL_TYPE IN('FTROPT', 'FTRSWP', 'TCCSWP')
                    OR (DMD.DLT_DEAL_TYPE = 'HRSWPS' AND DMD.UT_UNIT = 'MMBTU') 
                    THEN
                        CASE WHEN DMD.DN_DIRECTION = 'SALE' THEN 1.0
                        ELSE -1.0
                        END
                    ELSE
                        CASE WHEN DMD.DN_DIRECTION = 'SALE' THEN -1.0
                        ELSE 1.0
                        END
                END)  OVER(PARTITION BY CASE WHEN DMD.DLT_DEAL_TYPE = 'POWER' AND DMD.PRICE_TYPE = 'I' THEN 'PWRIDX' WHEN DMD.TRUE_DEAL_TYPE IN ('TCCSWP','POWER') THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END,
                            DMD.DEAL_KEY ORDER BY DMD.CM_CONTRACT_MONTH, DMD.VOLUME_SEQ, DMD.DETAIL_SEQ)   AS DEAL_LEG_MULTIPLIER,
           DMD.TRADE_DATE AS source_last_date1,
            dd.create_date AS source_last_date2,
            dmd.modify_date AS source_last_date3, 
            DMD.DEAL_KEY||'_'||(CASE WHEN DMD.DLT_DEAL_TYPE = 'POWER' AND DMD.PRICE_TYPE = 'I' THEN 'PWRIDX' 
             WHEN DMD.TRUE_DEAL_TYPE IN ('TCCSWP','POWER') THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END) AS SRC_SYS_DEAL_HEADER_KEY
            FROM DEAL_MONTH_DETAILS DMD
        LEFT JOIN FLAT_BROKER_FEES FBF 
            ON DMD.DEAL_KEY = FBF.DEAL_KEY 
            AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE FBF.DLT_DEAL_TYPE WHEN 'PWRNSD' THEN 'POWER' ELSE FBF.DLT_DEAL_TYPE END)

        LEFT JOIN BROKER_COMMISSION_MONTHS BCM ON DMD.DEAL_KEY = BCM.DEAL_KEY AND DMD.CM_CONTRACT_MONTH = BCM.CM_CONTRACT_MONTH 
            AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE BCM.DLT_DEAL_TYPE WHEN 'PWRNSD' THEN 'POWER' ELSE BCM.DLT_DEAL_TYPE END)
            AND DMD.FP_LOCATION = BCM.BP_BASIS_POINT

        LEFT JOIN CLEARINGBROKER_FEES CBC ON DMD.DEAL_KEY = CBC.DEAL_KEY 
            AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE CBC.DLT_DEAL_TYPE WHEN 'PWRNSD' THEN 'POWER' ELSE CBC.DLT_DEAL_TYPE END)


        LEFT JOIN   DEAL_DETAILS DD 
        ON DMD.DEAL_KEY = DD.DEAL_KEY AND DMD.DLT_DEAL_TYPE = DD.DLT_DEAL_TYPE
        LEFT JOIN   DEAL_CONFIRMS DC
ON DMD.DEAL_KEY = DC.DEAL_KEY
AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = DC.DLT_DEAL_TYPE) 
        where 
         DMD.TRADE_DATE >= '{0}' 
    AND        DMD.DLT_DEAL_TYPE NOT IN('BSWPS', 'BSWPOF', 'SWPS', 'SSWPS', 'OTCOPT', 'FSWPS', 'IMBAL', 'FTOPOF', 'FTSWOF', 'TCSWOF')  
    AND       (DMD.ST_SETTLEMENT_TYPE NOT LIKE 'NG%' OR DMD.ST_SETTLEMENT_TYPE IS NULL))
    group by
    DEAL_ATTRIBUTES_NK,EXECUTION_DATE,TRADE_CREATION_DATE,COMMITMENT_DATE,COUNTERPARTY_NK,SHELL_TRADING_PARTY_NK,TRADER_NK,DEAL_BROKER_NK,
    COMMODITY_NK,UNIT_OF_MEASURE_NK,DEAL_LEG_MULTIPLIER,
      SRC_SYS_DEAL_HEADER_KEY

      """.format(last_watermark_dmd1)
       
    
  
      return SQL
  
