# Databricks notebook source
# MAGIC 
# MAGIC %run ./../../../../WatermarkReader

# COMMAND ----------

# MAGIC 
# MAGIC 
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

class NucleusFactHeaderReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
    
    (dfHeader, metricDict) = readFactHeader(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD)

    return (dfHeader, metricDict)

# COMMAND ----------

def readFactHeader(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
  
  from pyspark.sql.functions import concat
  from datetime import datetime
  current_date_yyyymmdd = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
  print(current_date_yyyymmdd)
  
  last_watermark_dmd1 = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'DEAL_MONTH_DETAILS','TRADE_DATE','FACT_DEAL_HEADER')
  last_watermark_dmd1 = last_watermark_dmd1[0:19]

  last_watermark_dmd2 = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'DEAL_MONTH_DETAILS','MODIFY_DATE','FACT_DEAL_HEADER')
  last_watermark_dmd2 = last_watermark_dmd2[0:19]
  
  last_watermark_dd = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'DEAL_DETAILS','CREATE_DATE','FACT_DEAL_HEADER')
  last_watermark_dd = last_watermark_dd[0:19] 
  
  
   
  
  if INITIAL_LOAD == "Y" :
    SQL = getHeaderReaderSQLDay0(last_watermark_dmd1)
  else:
    SQL = getHeaderReaderSQLDay1(last_watermark_dmd1,current_date_yyyymmdd,last_watermark_dd,last_watermark_dmd2)
  
  
  format = "delta"
  readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'DEAL_MONTH_DETAILS', format, 'DEAL_MONTH_DETAILS')
  readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'FLAT_BROKER_FEES', format, 'FLAT_BROKER_FEES')
  readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'BROKER_COMMISSION_MONTHS', format, 'BROKER_COMMISSION_MONTHS')
  readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'CLEARINGBROKER_FEES', format, 'CLEARINGBROKER_FEES')
  readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'DEAL_DETAILS', format, 'DEAL_DETAILS')
  readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PROCESS_DATE', format, 'PROCESS_DATE')
  readDatasetConfigAndCreateTempView_WithSPN(spark, SOURCE_ETRM, 'NXTGEN_CCR_DTL_HIST_VIEW', format, 'NXTGEN_CCR_DTL_HIST_VIEW')
  readDatasetConfigAndCreateTempView_WithSPN(spark, SOURCE_ETRM, 'NXTGEN_CCR_DTL_VIEW', 'parquet', 'NXTGEN_CCR_DTL_VIEW')

  dfHeader = spark.sql(SQL)
  
  dfHeader = dfHeader.withColumn("SHELL_TRADING_PARTY_NK",dfHeader.SHELL_TRADING_PARTY_NK.cast('int'))
  dfHeader = dfHeader.withColumn("COUNTERPARTY_NK",dfHeader.COUNTERPARTY_NK.cast('int'))

  dfHeader.show(10,truncate=False)
  
  print("NucleusFactHeaderReader" , dfHeader.count())

  
  return (dfHeader, metricDict)

# COMMAND ----------

def getHeaderReaderSQLDay1(last_watermark_dmd1,current_date_yyyymmdd,last_watermark_dd,last_watermark_dmd2):

    SQL = """   
   SELECT 
            DMD.DEAL_KEY||'_'||(CASE WHEN DMD.DLT_DEAL_TYPE = 'POWER' AND DMD.PRICE_TYPE = 'I' THEN 'PWRIDX' 
             WHEN DMD.TRUE_DEAL_TYPE IN ('TCCSWP','POWER') THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END) AS DEAL_ATTRIBUTES_NK,
            DMD.TRADE_DATE  AS EXECUTION_DATE,
            DMD.TRADE_DATE  AS TRADE_CREATION_DATE,
            cast(DMD.CY_COMPANY_KEY as string)  AS COUNTERPARTY_NK,
            DMD.LGL_CY_ENTITY_KEY  AS SHELL_TRADING_PARTY_NK,
            DMD.UR_TRADER   	AS TRADER_NK,
            CASE WHEN FBF.CY_BROKER_KEY IS NOT NULL THEN FBF.CY_BROKER_KEY
                  WHEN BCM.CY_BROKER_KEY IS NOT NULL THEN BCM.CY_BROKER_KEY
                  WHEN CBC.CY_CBROKER_KEY IS NOT NULL THEN CBC.CY_CBROKER_KEY
                  ELSE NULL END AS BROKER_NK,                                                                                       				        DMD.UT_UNIT AS UNIT_OF_MEASURE_NK,
            ABS(DMD.R_DEAL_VOLUME + DMD.U_DEAL_VOLUME) AS CONTRACT_QTY,
	        CASE WHEN DMD.DLT_DEAL_TYPE IN('FTROPT', 'FTRSWP', 'TCCSWP')
                    OR (DMD.DLT_DEAL_TYPE = 'HRSWPS' AND DMD.UT_UNIT = 'MMBTU') 
                    THEN
                        CASE WHEN DMD.DN_DIRECTION = 'SALE' THEN 1.0
                        ELSE -1.0
                        END
                    ELSE
                        CASE WHEN DMD.DN_DIRECTION = 'SALE' THEN -1.0
                        ELSE 1.0
                        END
                END					AS DEAL_HEADER_MULTIPLIER,
            DMD.TRADE_DATE AS source_last_date1,
            dd.create_date AS source_last_date2,
            dmd.modify_date AS source_last_date3
            FROM DEAL_MONTH_DETAILS DMD
            LEFT JOIN FLAT_BROKER_FEES FBF 
                ON DMD.DEAL_KEY = FBF.DEAL_KEY 
                AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE FBF.DLT_DEAL_TYPE WHEN 'PWRNSD' THEN 'POWER' ELSE FBF.DLT_DEAL_TYPE END)
                LEFT JOIN BROKER_COMMISSION_MONTHS BCM ON DMD.DEAL_KEY = BCM.DEAL_KEY AND DMD.CM_CONTRACT_MONTH = BCM.CM_CONTRACT_MONTH 
                AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE BCM.DLT_DEAL_TYPE WHEN 'PWRNSD' THEN 'POWER' ELSE BCM.DLT_DEAL_TYPE END) 
                LEFT JOIN CLEARINGBROKER_FEES CBC ON DMD.DEAL_KEY = CBC.DEAL_KEY 
                AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE CBC.DLT_DEAL_TYPE WHEN 'PWRNSD' THEN 'POWER' ELSE CBC.DLT_DEAL_TYPE END)
            LEFT JOIN   DEAL_DETAILS DD 
            ON DMD.DEAL_KEY = DD.DEAL_KEY AND DMD.DLT_DEAL_TYPE = DD.DLT_DEAL_TYPE
            WHERE   (
            (DMD.TRADE_DATE >= '{0}' and dd.create_date <= '{1}')
            or
            (dmd.trade_date <= '{2}' and  dd.create_date > '{3}')
            or
            (dmd.modify_date > '{4}'))
            AND     DMD.DLT_DEAL_TYPE NOT IN('BSWPS', 'BSWPOF', 'SWPS', 'SSWPS', 'OTCOPT', 'FSWPS', 'IMBAL', 'FTOPOF', 'FTSWOF', 'TCSWOF')  
            AND     (DMD.ST_SETTLEMENT_TYPE NOT LIKE 'NG%' OR DMD.ST_SETTLEMENT_TYPE IS NULL) GROUP BY DMD.DEAL_KEY, DMD.TRUE_DEAL_TYPE,DMD.DLT_DEAL_TYPE,DMD.TRADE_DATE,DMD.CY_COMPANY_KEY, DMD.LGL_CY_ENTITY_KEY,DMD.UR_TRADER,DMD.UT_UNIT, FBF.CY_BROKER_KEY,BCM.CY_BROKER_KEY,CBC.CY_CBROKER_KEY   
    """.format(last_watermark_dmd1,current_date_yyyymmdd,current_date_yyyymmdd,last_watermark_dd,last_watermark_dmd2)
  
    return SQL
  

# COMMAND ----------

def getHeaderReaderSQLDay0(last_watermark_dmd1):
      SQL = """
       with cte as (
 select * from(
 SELECT *,rank() over (partition by DMD.DEAL_KEY,DMD.DLT_DEAL_TYPE,DMD.TRUE_DEAL_TYPE,DMD.VOLUME_SEQ,DMD.DETAIL_SEQ,DMD.CM_CONTRACT_MONTH
	ORDER BY DMD.MODIFY_DATE,DMD.trade_date desc) as r FROM DEAL_MONTH_DETAILS DMD)
	where r=1 
	and TRADE_DATE >= '{0}' 
    AND         DLT_DEAL_TYPE NOT IN('BSWPS', 'BSWPOF', 'SWPS', 'SSWPS', 'OTCOPT', 'FSWPS', 'IMBAL', 'FTOPOF', 'FTSWOF', 'TCSWOF')  
    AND       (ST_SETTLEMENT_TYPE NOT LIKE 'NG%' OR ST_SETTLEMENT_TYPE IS NULL))
    
      SELECT 
            DMD.DEAL_KEY||'_'||(CASE WHEN DMD.DLT_DEAL_TYPE = 'POWER' AND DMD.PRICE_TYPE = 'I' THEN 'PWRIDX' 
             WHEN DMD.TRUE_DEAL_TYPE IN ('TCCSWP','POWER') THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END) AS DEAL_ATTRIBUTES_NK,
            DMD.TRADE_DATE  AS EXECUTION_DATE,
            DMD.TRADE_DATE  AS TRADE_CREATION_DATE,
            cast(DMD.CY_COMPANY_KEY as string)  AS COUNTERPARTY_NK,
            cast(DMD.LGL_CY_ENTITY_KEY as string)  AS SHELL_TRADING_PARTY_NK,
            DMD.UR_TRADER   	AS TRADER_NK,
            CASE WHEN FBF.CY_BROKER_KEY IS NOT NULL THEN FBF.CY_BROKER_KEY
                  WHEN BCM.CY_BROKER_KEY IS NOT NULL THEN BCM.CY_BROKER_KEY
                  WHEN CBC.CY_CBROKER_KEY IS NOT NULL THEN CBC.CY_CBROKER_KEY
                  ELSE NULL END AS BROKER_NK,                                                                                       				        DMD.UT_UNIT AS UNIT_OF_MEASURE_NK,
            ABS(DMD.R_DEAL_VOLUME + DMD.U_DEAL_VOLUME) AS CONTRACT_QTY,
	        CASE WHEN DMD.DLT_DEAL_TYPE IN('FTROPT', 'FTRSWP', 'TCCSWP')
                    OR (DMD.DLT_DEAL_TYPE = 'HRSWPS' AND DMD.UT_UNIT = 'MMBTU') 
                    THEN
                        CASE WHEN DMD.DN_DIRECTION = 'SALE' THEN 1.0
                        ELSE -1.0
                        END
                    ELSE
                        CASE WHEN DMD.DN_DIRECTION = 'SALE' THEN -1.0
                        ELSE 1.0
                        END
                END					AS DEAL_HEADER_MULTIPLIER,
            DMD.TRADE_DATE AS source_last_date1,
            dd.create_date AS source_last_date2,
            dmd.modify_date AS source_last_date3
            FROM cte DMD
            LEFT JOIN FLAT_BROKER_FEES FBF 
                ON DMD.DEAL_KEY = FBF.DEAL_KEY 
                AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE FBF.DLT_DEAL_TYPE WHEN 'PWRNSD' THEN 'POWER' ELSE FBF.DLT_DEAL_TYPE END)
                LEFT JOIN BROKER_COMMISSION_MONTHS BCM ON DMD.DEAL_KEY = BCM.DEAL_KEY AND DMD.CM_CONTRACT_MONTH = BCM.CM_CONTRACT_MONTH 
                AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE BCM.DLT_DEAL_TYPE WHEN 'PWRNSD' THEN 'POWER' ELSE BCM.DLT_DEAL_TYPE END) 
                LEFT JOIN CLEARINGBROKER_FEES CBC ON DMD.DEAL_KEY = CBC.DEAL_KEY 
                AND (CASE DMD.TRUE_DEAL_TYPE WHEN 'TCCSWP' THEN DMD.DLT_DEAL_TYPE ELSE DMD.TRUE_DEAL_TYPE END = CASE CBC.DLT_DEAL_TYPE WHEN 'PWRNSD' THEN 'POWER' ELSE CBC.DLT_DEAL_TYPE END)
            LEFT JOIN   DEAL_DETAILS DD 
            ON DMD.DEAL_KEY = DD.DEAL_KEY AND DMD.DLT_DEAL_TYPE = DD.DLT_DEAL_TYPE
             
                """.format(last_watermark_dmd1)
       
    
  
      return SQL
  
