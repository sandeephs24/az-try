# Databricks notebook source
# MAGIC %run ./../../enricher/CurrencyMappingEnricher

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class AligneCurrencyReader(SourceDatasetReader):
    
    def read(spark,metricDict):
        SOURCE_ETRM = 'ALIGNE'
      
        CURRENCY_READER_SQL = """
        select distinct
        c.MRKTC_PRCY as SRC_SYS_CURRENCY_NK,
        '' as CURRENCY_CODE
        FROM 	STATIC_MRKTC  c
        """
        
        format = "parquet"
        readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_MRKTC', format, 'STATIC_MRKTC')
                
        df = spark.sql(CURRENCY_READER_SQL)
        df = enrich(spark,df, SOURCE_ETRM)
        return (df,metricDict)
