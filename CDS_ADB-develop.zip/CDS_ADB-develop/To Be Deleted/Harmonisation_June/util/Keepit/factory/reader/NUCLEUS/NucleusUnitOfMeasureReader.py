# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../../enricher/UOMMappingEnricher

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class NucleusUnitOfMeasureReader(SourceDatasetReader):
    
  def read(spark,metricDict):
        
        SOURCE_ETRM = 'NUCLEUS'
        
        df = executeJdbcQueryAndReturnDF("select SRC_SYS_UNIT_OF_MEASURE_NK from tsa_curated.dim_unit_of_measure where src_sys_name = '{0}'".format(SOURCE_ETRM))
        df.createOrReplaceTempView("CURATED_DIM_UNIT_OF_MEASURE")
        
        UOM_READER_SQL = """
        SELECT 
          DISTINCT U.UNIT AS SRC_SYS_UNIT_OF_MEASURE_NK          
        FROM UNITS U
        """
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'UNITS', format, 'UNITS')
        
        df = spark.sql(UOM_READER_SQL)
        df = enrichUOMForMapping(spark,df, SOURCE_ETRM)
        
        return (df,metricDict)

# COMMAND ----------

 
