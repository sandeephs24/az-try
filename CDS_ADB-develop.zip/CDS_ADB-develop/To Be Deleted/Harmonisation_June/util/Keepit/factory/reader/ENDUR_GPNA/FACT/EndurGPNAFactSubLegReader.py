# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../../../WatermarkReader

# COMMAND ----------

import abc
class SourceDatasetReader(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def read(self):
        pass

# COMMAND ----------

class EndurGPNAFactSubLegReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM,metricDict, initial_load):
    
    (dfSubLeg,metricDict) = readFactSubLeg(spark, SOURCE_ETRM,metricDict, initial_load)

    return (dfSubLeg,metricDict)

# COMMAND ----------

def readFactSubLeg(spark, SOURCE_ETRM,metricDict, initial_load):
    from pyspark.sql.functions import concat
    from pyspark.sql.functions import date_format
    
    from datetime import datetime
    current_date_yyyymmdd = datetime.today().strftime('%Y%m%d')
    
    last_watermark_trade_date = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'AB_TRAN','TRADE_DATE', 'FACT_DEAL_SUB_LEG')
    last_watermark_trade_date = last_watermark_trade_date[0:19]
    
    last_watermark_input_date = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'AB_TRAN','INPUT_DATE', 'FACT_DEAL_SUB_LEG')
    last_watermark_input_date = last_watermark_input_date[0:19]
    
    last_watermark_last_update = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'AB_TRAN','LAST_UPDATE', 'FACT_DEAL_SUB_LEG')
    last_watermark_last_update = last_watermark_last_update[0:19]
    
    if initial_load == "Y":
      tran_status_list = "3,4,5"
    else:
      tran_status_list = "3,5"
    
    SQL = """   
    SELECT 
    DEAL_ATTRIBUTES_NK,
    DEAL_TRACKING_NUM,
    TRAN_NUM,
    INS_NUM,
    PARAM_SEQ_NUM,
    PROFILE_SEQ_NUM,
    EXECUTION_DATE,
    TRADE_CREATION_DATE,
    COMMITMENT_DATE,
    PARCEL_DATE,
    COUNTERPARTY_NK,
    SHELL_TRADING_PARTY_NK,
    TRADER_NK,
    DEAL_BROKER_NK,
    COMMODITY_NK,
    LOADING_LOCATION_NK,
    DISCHARGE_LOCATION_NK,
    DELIVERY_START_DATE,
    DELIVERY_END_DATE,
    DEAL_UNIT_OF_MEASURE_NK,
    PRICING_UNIT_OF_MEASURE_NK,
    DEAL_CCY_NK,
    DEAL_QTY,
    PRICE_QTY,
    DEAL_SUB_LEG_MULTIPLIER,
    TRAN_STATUS,
    SOURCE_LAST_DATE1,
    SOURCE_LAST_DATE2,
    SOURCE_LAST_DATE3,
    NOTNL,
    strike,
    sum(CCY_DEAL_VALUE) CCY_DEAL_VALUE,
    SRC_SYS_DEAL_HEADER_KEY
    FROM(
    SELECT 
    t.input_date AS EXECUTION_DATE,
    t.TRADE_DATE AS TRADE_CREATION_DATE,
    t.TRADE_DATE AS COMMITMENT_DATE,
    d.START_DATE AS PARCEL_DATE,
    t.EXTERNAL_BUNIT AS COUNTERPARTY_NK,
    t.INTERNAL_BUNIT AS SHELL_TRADING_PARTY_NK,
    t.DEAL_TRACKING_NUM||'_'||t.INS_NUM||'_'||d.PARAM_SEQ_NUM||'_'||d.PROFILE_SEQ_NUM AS DEAL_ATTRIBUTES_NK,
    t.DEAL_TRACKING_NUM,
    t.tran_num,
    l.INS_NUM,
    d.PARAM_SEQ_NUM,
    d.PROFILE_SEQ_NUM,
    t.INTERNAL_CONTACT AS TRADER_NK,
    CASE WHEN t.OTC_CLEARING_BROKER_ID = 0 
    THEN (CASE WHEN t.BROKER_ID != 0 THEN t.BROKER_ID
    WHEN (pa3.PARTY_ID IS NOT NULL or pa1.PARTY_ID IS NOT NULL or pa5.PARTY_ID IS NOT NULL or pa2.PARTY_ID IS NOT NULL)
    THEN (case 
    when pa3.PARTY_ID is not null then pa3.PARTY_ID
    when pa1.PARTY_ID is not null then pa1.PARTY_ID
    when pa5.PARTY_ID is not null then pa5.PARTY_ID
    when pa2.PARTY_ID is not null then pa2.PARTY_ID else null end)
	ELSE pa.PARTY_ID END)
    ELSE  T.OTC_CLEARING_BROKER_ID 
    END AS DEAL_BROKER_NK,
    t.IDX_GROUP AS COMMODITY_NK,
    '' AS LOADING_LOCATION_NK,
    gpl.LOCATION_ID DISCHARGE_LOCATION_NK,
    d.START_DATE DELIVERY_START_DATE,
    d.END_DATE DELIVERY_END_DATE,
    f.UNIT DEAL_UNIT_OF_MEASURE_NK,
    f.PRICE_UNIT PRICING_UNIT_OF_MEASURE_NK,
    t.CURRENCY DEAL_CCY_NK,
    CASE WHEN t.TRAN_STATUS = 5 THEN 0 
    WHEN NVL(l.INS_NUM, -1) = -1 THEN 
    (CASE WHEN d.NOTNL > 0 AND pnl.TOTAL_VAL < 0 
    THEN pnl.TOTAL_VAL 
    ELSE       ABS(pnl.TOTAL_VAL) 
    END) 
    ELSE l.strike * ABS(d.notnl) END AS CCY_DEAL_VALUE,
    abs(d.NOTNL) AS DEAL_QTY,
    abs(d.NOTNL) * f.PRICE_UNIT_CONV AS PRICE_QTY,
    CASE WHEN d.notnl < 0 THEN -1 WHEN d.notnl > 0 THEN 1 ELSE 0 END DEAL_SUB_LEG_MULTIPLIER,
    t.TRAN_STATUS,
    t.trade_date source_last_date1,
    t.input_date source_last_date2,
    t.last_update source_last_date3,
    d.NOTNL,
    l.strike,
    t.DEAL_TRACKING_NUM as SRC_SYS_DEAL_HEADER_KEY
    FROM	AB_TRAN t
    JOIN 	INSTRUMENTS bz 
    ON 	t.ins_type = bz.id_number
    JOIN	PARAMETER f 
    ON	t.ins_num = f.ins_num
    JOIN	PROFILE d 
    ON	f.param_seq_num = d.param_seq_num 
    AND	f.ins_num = d.ins_num
    JOIN	TOOLSETS ts 
    ON	t.toolset = TS.ID_NUMBER
    JOIN	PORTFOLIO c 
    ON	t.internal_portfolio = c.id_number
    JOIN	SETTLE_TYPE g 
    ON	g.id_number =f.settlement_type
    JOIN	PARTY j 
    ON	t.internal_lentity = j.party_id
    JOIN	TRANS_STATUS k 
    ON	t.tran_status = k.trans_status_id
    LEFT JOIN	INS_OPTION l 
    ON	f.ins_num = l.ins_num 
    AND	f.param_seq_num = l.param_seq_num
    AND OPTION_SEQ_NUM = 0
    LEFT JOIN	gas_phys_param gpp 
    ON	gpp.ins_num = f.ins_num 
    AND	gpp.param_seq_num = f.param_seq_num
    LEFT JOIN	gas_phys_location gpl 
    ON	GPP.LOCATION_ID = GPL.LOCATION_ID
    LEFT JOIN	gas_phys_pipelines pipe 
    ON	PIPE.PIPELINE_ID = GPL.PIPELINE_ID
    LEFT JOIN	gas_phys_location ic 
    ON	GPL.INTERCONNECT_LOC_ID = ic.location_id
    JOIN	buy_sell bs 
    ON	BS.ID_NUMBER = t.buy_sell
    LEFT JOIN	PUT_CALL pc 
    ON	L.PUT_CALL = PC.ID_NUMBER 
    JOIN	FX_FLT ff 
    ON	FF.ID_NUMBER = F.FX_FLT
    LEFT JOIN	PARAM_RESET_HEADER prh 
    ON	f.ins_num = prh.ins_num 
    AND	f.param_seq_num = prh.param_seq_num
    AND prh.PARAM_RESET_HEADER_SEQ_NUM = 0
    LEFT JOIN	idx_def pi 
    ON	PI.INDEX_ID = prh.proj_index 
    AND	pi.validated = 1 and PI.DB_STATUS = 1
    JOIN	value_status vs 
    ON	VS.ID_NUMBER = d.rate_status
    LEFT JOIN	AB_TRAN_AGREEMENT ag 
    ON	AG.TRAN_NUM = t.tran_num
    LEFT JOIN	party_agreement pa 
    ON	AG.PARTY_AGREEMENT_ID = PA.PARTY_AGREEMENT_ID
    LEFT JOIN	agreement agr 
    ON 	PA.AGREEMENT_ID = AGR.AGREEMENT_ID
    LEFT JOIN	AB_TRAN_INFO  d2
    ON	t.tran_num = d2.tran_num and d2.type_id = 20021
    LEFT JOIN	PARTY pa          
    ON	d2.value = pa.short_name
    left join (select tran_num,broker_id from AB_TRAN_PROVISIONAL where PROV_TYPE=3) ap3 
              on t.tran_num=ap3.tran_num 
    left join (select tran_num,broker_id from AB_TRAN_PROVISIONAL where PROV_TYPE=1) ap1 
              on t.tran_num=ap1.tran_num
    left join (select tran_num,broker_id from AB_TRAN_PROVISIONAL where PROV_TYPE=5) ap5 
              on t.tran_num=ap5.tran_num
   left join (select tran_num,broker_id from AB_TRAN_PROVISIONAL where PROV_TYPE=2) ap2 
              on t.tran_num=ap2.tran_num
    left join PARTY pa3 
    on ap3.broker_id = pa3.party_id
    left join PARTY pa1
    on ap1.broker_id = pa1.party_id
    left join PARTY pa5 
    on ap5.broker_id = pa5.party_id
    left join PARTY pa2
    on ap2.broker_id = pa2.party_id
    LEFT JOIN	USER_SYN_EXTRACTIONLOG log 
    ON	LOG.SIM_PFOLIO = t.INTERNAL_PORTFOLIO
    AND   LOG.SIM_RUN_TIME = (select max(log2.sim_run_time) from USER_SYN_EXTRACTIONLOG log2 where LOG2.SIM_RUN_TYPE = 1)
    LEFT JOIN (  
    select sim_run_id, TRAN_NUM, deal_leg, deal_pdc, CFLOW_TYPE,TOTAL_VAL
    from(
    select PNL.SIM_RUN_ID,
    PNL.TRAN_NUM              ,
    PNL.DEAL_LEG         ,
    PNL.DEAL_PDC ,
    PNL.CFLOW_TYPE,
    PNL.TOTAL_VAL,
    row_number() 
    over(partition by sim_run_id, TRAN_NUM, deal_leg, deal_pdc
    order by sim_run_id
    ) row_num     
    from USER_SYN_PNL_DETAIL PNL
    where CFLOW_TYPE = -1
    ) where row_num = 1
    ) PNL 
    ON LOG.SIM_RUN_ID  = PNL.SIM_RUN_ID
    AND t.tran_num  = PNL.TRAN_NUM              
    AND d.PARAM_SEQ_NUM  = PNL.DEAL_LEG         
    AND d.profile_seq_num  = PNL.DEAL_PDC       
    WHERE t.tran_status in ({5})
    AND   t.current_flag = 1
    AND t.tran_type = 0
    and (
      (
      bz.name in ('COMM-LDC', 'COMM-PHYS', 'COMM-PHYS-USAGE', 'COMM-EXCH') 
      and gpp.ins_num is not null and f.settlement_type = 2
      )
      OR
      ( bz.name not in ('COMM-LDC', 'COMM-PHYS', 'COMM-PHYS-USAGE', 'COMM-EXCH'))
      ) 
    AND
    ( 
    (t.trade_date > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss') and t.trade_date <= '{1}')
    OR
    (t.trade_date <= '{2}' and t.input_date > to_timestamp('{3}','yyyy-MM-dd HH:mm:ss'))
    OR
    (t.last_update > to_timestamp('{4}','yyyy-MM-dd HH:mm:ss') )
    )	
    AND     bz.name not in ('CASH' ,
    'COMM-FEE' ,
    'COMM-IMB' ,
    'COMM-INV' ,
    'COMM-INV-PAL' ,
    'COMM-MAD-SETTLE' ,
    'COMM-PAL' ,
    'COMM-PREPAY' ,
    'COMM-STOR' ,
    'COMM-TRANS' ,
    'COMM-TRANS-PLAN' ,
    'COMM-MAD-JE','COMM-IMB-SENA') 	

    ) V group by
    DEAL_ATTRIBUTES_NK,
    DEAL_TRACKING_NUM,
    TRAN_NUM,
    INS_NUM,
    PARAM_SEQ_NUM,
    PROFILE_SEQ_NUM,
    EXECUTION_DATE,
    TRADE_CREATION_DATE,
    COMMITMENT_DATE,
    PARCEL_DATE,
    COUNTERPARTY_NK,
    SHELL_TRADING_PARTY_NK,
    TRADER_NK,
    DEAL_BROKER_NK,
    COMMODITY_NK,
    LOADING_LOCATION_NK,
    DISCHARGE_LOCATION_NK,
    DELIVERY_START_DATE,
    DELIVERY_END_DATE,
    DEAL_UNIT_OF_MEASURE_NK,
    PRICING_UNIT_OF_MEASURE_NK,
    DEAL_CCY_NK,
    DEAL_QTY,
    TRAN_STATUS,
    PRICE_QTY,
    DEAL_SUB_LEG_MULTIPLIER,
    source_last_date1,
    source_last_date2,
    source_last_date3,
    NOTNL,
    strike,
    SRC_SYS_DEAL_HEADER_KEY
    """.format(last_watermark_trade_date, 
    current_date_yyyymmdd, 
    current_date_yyyymmdd, 
    last_watermark_input_date, 
    last_watermark_last_update,
    tran_status_list
    )
    
    
    format = "delta"
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN', format, 'AB_TRAN')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'INSTRUMENTS', format, 'INSTRUMENTS')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PARAMETER', format, 'PARAMETER')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PROFILE', format, 'PROFILE')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'TOOLSETS', format, 'TOOLSETS')

    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PORTFOLIO', format, 'PORTFOLIO')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'SETTLE_TYPE', format, 'SETTLE_TYPE')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'PARTY', "parquet", 'PARTY')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'TRANS_STATUS', format, 'TRANS_STATUS')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'INS_OPTION', format, 'INS_OPTION')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'GAS_PHYS_PARAM', format, 'GAS_PHYS_PARAM')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'GAS_PHYS_LOCATION', format, 'GAS_PHYS_LOCATION')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'GAS_PHYS_PIPELINES', format, 'GAS_PHYS_PIPELINES')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'BUY_SELL', format, 'BUY_SELL')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PUT_CALL', format, 'PUT_CALL')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'FX_FLT', format, 'FX_FLT')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PARAM_RESET_HEADER', format, 'PARAM_RESET_HEADER')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'IDX_DEF', format, 'IDX_DEF')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'VALUE_STATUS', format, 'VALUE_STATUS')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'USER_SYN_EXTRACTIONLOG', format, 'USER_SYN_EXTRACTIONLOG')
    readDatasetConfigAndCreateTempView(spark, SOURCE_ETRM, 'USER_SYN_PNL_DETAIL', "parquet", 'USER_SYN_PNL_DETAIL')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN_AGREEMENT', format, 'AB_TRAN_AGREEMENT')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'PARTY_AGREEMENT', format, 'PARTY_AGREEMENT')
    readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'AGREEMENT', 'parquet', 'AGREEMENT')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN_INFO', format, 'AB_TRAN_INFO')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'AB_TRAN_PROVISIONAL', format, 'AB_TRAN_PROVISIONAL')

    
    dfSubLeg = spark.sql(SQL)
    
    return (dfSubLeg,metricDict)
