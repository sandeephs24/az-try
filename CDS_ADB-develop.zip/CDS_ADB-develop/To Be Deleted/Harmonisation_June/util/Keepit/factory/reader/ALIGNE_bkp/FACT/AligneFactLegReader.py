# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

class AligneFactLegReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
        
    (dfLeg,metricDict) = readFactLeg(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD)

    return (dfLeg,metricDict)

# COMMAND ----------

  def readFactLeg(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
    
    last_watermark_fact_gv_trade = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'GV_TRADES','TRADE_DATE','FACT_DEAL_LEG')
    last_watermark_fact_gv_trade = last_watermark_fact_gv_trade[0:19]

    #last_watermark_fact_contract2= getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'STO_CONTRACT','LAST_UPDATE_TSTMP','FACT_DEAL_LEG')
    #last_watermark_fact_contract2 = last_watermark_fact_contract2[0:19]
   
    if INITIAL_LOAD == "Y" :
      SQL = getLegReaderSQLDay0(last_watermark_fact_gv_trade)
    else:
      SQL = getLegReaderSQLDay1(last_watermark_fact_gv_trade)
  
    
    format = "delta"
    readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_TRADES', 'parquet', 'GV_TRADES')
    readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_PNL_MONTHLY', 'parquet', 'GV_PNL_MONTHLY')
    readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_PNL_DAILY', 'parquet', 'GV_PNL_DAILY')
   
   
    dfFactLeg = spark.sql(SQL)
    
    dfFactLeg.show(10,truncate=False)
    
    print("AligneFactLegReader" , dfFactLeg.count())
    
    return (dfFactLeg,metricDict)

# COMMAND ----------

def getLegReaderSQLDay1(last_watermark_fact_gv_trade):
  SQL = """select
 DEAL_ATTRIBUTES_NK,
      EXECUTION_DATE_SK,
      TRADE_CREATION_DATE_SK,
      COMMITMENT_DATE_SK,
      COUNTERPARTY_SK,
      SHELL_TRADING_PARTY_SK,
      TRADER_SK,
      DEAL_BROKER_SK,
      COMMODITY_SK,
      UNIT_OF_MEASURE_SK,
      COMMITMENT_QTY,
      CASE WHEN COMMITMENT_QTY <0 THEN '-1' ELSE '1' END AS DEAL_LEG_MULTIPLIER,
      SRC_SYS_DEAL_HEADER_KEY

FROM 
(
      SELECT
      DEAL_ATTRIBUTES_NK,
      EXECUTION_DATE
      TRADE_CREATION_DATE,
      COMMITMENT_DATE,
      COUNTERPARTY_NK,
      SHELL_TRADING_PARTY_NK,
      TRADER_NK,
      DEAL_BROKER_NK,
      COMMODITY_NK,
      UNIT_OF_MEASURE_NK,
      sum(COMMITMENT_QTY_AMT) AS COMMITMENT_QTY,
      SRC_SYS_DEAL_HEADER_KEY
      from (
             select
            GT.ZKEY||'_'|| PDM.DMO1 			AS DEAL_ATTRIBUTES_NK,
            GT.TRADE_DATE 					AS EXECUTION_DATE,
            GT.INPUT_DATE 					AS TRADE_CREATION_DATE,
            GT.TRADE_DATE 					AS COMMITMENT_DATE,
            GT.CPTY 						AS COUNTERPARTY_NK,
            GT.HOUSE_ID 					AS SHELL_TRADING_PARTY_NK,
            GT.TRADER 					AS TRADER_NK,
            CASE WHEN GT.CPTY_BROKER='DIRECT' THEN NULL 
                 ELSE GT.CPTY_BROKER
                 END 						AS DEAL_BROKER_NK,
            GT.CDY1_RISKDESC 					AS COMMODITY_NK,
            GT.AMT_UNIT 					AS UNIT_OF_MEASURE_NK,
            ABS(PDM.QTY1) 					AS COMMITMENT_QTY_AMT,
            'POPULATED BY TSA ENRICHER' 				AS COMMODITY_COMMITMENT_QTY,
            GT.ZKEY 						AS SRC_SYS_DEAL_HEADER_KEY,
            GT.trade_date source_last_date1,
   '' as source_last_date2,
    ''  as source_last_date3
            
FROM GV_TRADES GT
            
LEFT JOIN 
(select distinct PM.ZKEY,PM.TNUM,PM.START1,PM.END1,PM.PRICE1_IC,PM.QTY1,PM.SIDE,PM.DMO1
from GV_PNL_MONTHLY PM
UNION

select distinct  PD.ZKEY,PD.TNUM,PD.START1,PD.END1,PD.PRICE1_IC,PD.QTY1,PD.SIDE,PD.DMO1
from GV_PNL_DAILY PD
) as PDM
ON PDM.ZKEY = GT.ZKEY AND PDM.TNUM = GT.TNUM 
WHERE GT.VOID_FLAG='N' and PDM.DMO1  is not null
and GT.TRADE_DATE >'{0}')           
         
    group by
    DEAL_ATTRIBUTES_NK,EXECUTION_DATE,TRADE_CREATION_DATE,COMMITMENT_DATE,COUNTERPARTY_NK,SHELL_TRADING_PARTY_NK,TRADER_NK,DEAL_BROKER_NK,
    COMMODITY_NK,UNIT_OF_MEASURE_NK, SRC_SYS_DEAL_HEADER_KEY    
  )
  """.format(last_watermark_fact_gv_trade)
  return SQL

# COMMAND ----------

def getLegReaderSQLDay0(last_watermark_fact_gv_trade):
  SQL = """ select
 DEAL_ATTRIBUTES_NK,
      EXECUTION_DATE,
      TRADE_CREATION_DATE,
      COMMITMENT_DATE,
      COUNTERPARTY_NK,
      SHELL_TRADING_PARTY_NK,
      TRADER_NK,
      DEAL_BROKER_NK,
      COMMODITY_NK,
      UNIT_OF_MEASURE_NK,
      COMMITMENT_QTY,
      CASE WHEN COMMITMENT_QTY <0 THEN '-1' ELSE '1' END AS DEAL_LEG_MULTIPLIER,
      SRC_SYS_DEAL_HEADER_KEY,
      source_last_date1,
      source_last_date2,
      source_last_date3

FROM 
(
      SELECT
      DEAL_ATTRIBUTES_NK,
      EXECUTION_DATE,
      TRADE_CREATION_DATE,
      COMMITMENT_DATE,
      COUNTERPARTY_NK,
      SHELL_TRADING_PARTY_NK,
      TRADER_NK,
      DEAL_BROKER_NK,
      COMMODITY_NK,
      UNIT_OF_MEASURE_NK,
      sum(COMMITMENT_QTY_AMT) AS COMMITMENT_QTY,
      SRC_SYS_DEAL_HEADER_KEY,
      source_last_date1,
      source_last_date2,
      source_last_date3
      from (
             select
            GT.ZKEY||'_'|| PDM.DMO1 			AS DEAL_ATTRIBUTES_NK,
            GT.TRADE_DATE 					AS EXECUTION_DATE,
            GT.INPUT_DATE 					AS TRADE_CREATION_DATE,
            GT.TRADE_DATE 					AS COMMITMENT_DATE,
            GT.CPTY 						AS COUNTERPARTY_NK,
            GT.HOUSE_ID 					AS SHELL_TRADING_PARTY_NK,
            GT.TRADER 					AS TRADER_NK,
            CASE WHEN GT.CPTY_BROKER='DIRECT' THEN NULL 
                 ELSE GT.CPTY_BROKER
                 END 						AS DEAL_BROKER_NK,
            GT.CDY1_RISKDESC 					AS COMMODITY_NK,
            GT.AMT_UNIT 					AS UNIT_OF_MEASURE_NK,
            ABS(PDM.QTY1) 					AS COMMITMENT_QTY_AMT,
            GT.ZKEY 						AS SRC_SYS_DEAL_HEADER_KEY,
            GT.trade_date source_last_date1,
   '' as source_last_date2,
    ''  as source_last_date3
            
FROM GV_TRADES GT
 LEFT JOIN           
      ( select * FROM
(
select distinct PM.ZKEY,PM.TNUM,PM.START1,PM.END1,PM.PRICE1_IC,PM.QTY1,PM.SIDE,PM.DMO1,PM.FLOAT_MULT,row_number() over (Partition by PM.ZKEY,PM.START1,PM.END1 ORDER BY ASOF_DATE DESC) row_num
from GV_PNL_MONTHLY PM
UNION
select distinct PD.ZKEY,PD.TNUM,PD.START1,PD.END1,PD.PRICE1_IC,PD.QTY1,PD.SIDE,PD.DMO1,PD.FLOAT_MULT,row_number() over (Partition by PD.ZKEY,PD.START1,PD.END1 ORDER BY ASOF_DATE DESC) row_num
from GV_PNL_DAILY PD
)
        WHERE row_num=1
        )PDM
ON PDM.ZKEY = GT.ZKEY AND PDM.TNUM = GT.TNUM
WHERE GT.VOID_FLAG='N'
and GT.TRADE_DATE >'{0}')
 group by
    DEAL_ATTRIBUTES_NK,EXECUTION_DATE,TRADE_CREATION_DATE,COMMITMENT_DATE,COUNTERPARTY_NK,SHELL_TRADING_PARTY_NK,TRADER_NK,DEAL_BROKER_NK,
    COMMODITY_NK,UNIT_OF_MEASURE_NK, SRC_SYS_DEAL_HEADER_KEY,source_last_date1,source_last_date2,source_last_date3
)       
         
   
    
  
   """.format(last_watermark_fact_gv_trade)

  return SQL

