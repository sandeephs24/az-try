# Databricks notebook source
# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class DexTraderReader(SourceDatasetReader):
    def read(spark,metricDict):
      
      import pyspark.sql.functions as F
      
      SOURCE_ETRM = 'DEX'
      last_watermark = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_USR','DIM_TRADER')
      last_watermark = last_watermark[0:19]
      
      df = executeJdbcQueryAndReturnDF("select src_sys_trader_nk from tsa_curated.dim_trader where src_sys_name = '{0}'".format(SOURCE_ETRM))
      df.createOrReplaceTempView("CURATED_DIM_TRADER")
      
      TRADER_READ_SQL = """
      
       WITH SRC_SYS_TRADER AS (
        SELECT	DISTINCT TRADER_USERID AS TRADER_USERID
        FROM	STO_CONTRACT where TRADER_USERID is not null
        )
        SELECT	a.TRADER_USERID as SRC_SYS_TRADER_NK,
                b.USER_DESC_TXT     as TRADER_NAME,         
                b.USER_FIRST_NAME  as TRADER_FIRST_NAME,
                b.USER_SURNAME_TXT   as TRADER_LAST_NAME,
                '' as SOURCE_LAST_UPDATE
        FROM	SRC_SYS_TRADER a
        LEFT JOIN	STO_USR b
        ON	a.TRADER_USERID = b.NICKNAME_USERID
        
        """


      format = "delta"
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_USR', format, 'STO_USR')
      readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CONTRACT', format, 'STO_CONTRACT')
     
      df = spark.sql(TRADER_READ_SQL)
      print('Reader Count')
      print(df.count())
      return  (df,metricDict)
