# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ../../DatasetReader

# COMMAND ----------

# MAGIC %run ./AligneFactHeaderReader

# COMMAND ----------

# MAGIC %run ./AligneFactLegReader

# COMMAND ----------

# MAGIC %run ./AligneFactSubLegReader

# COMMAND ----------

class AligneFactReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD):
    
    (dfHeader,metricDict) = AligneFactHeaderReader.read(spark,SOURCE_ETRM,metricDict, INITIAL_LOAD)
    (dfLeg, metricDict) = AligneFactLegReader.read(spark,SOURCE_ETRM,metricDict, INITIAL_LOAD)
    (dfSubLeg, metricDict) = AligneFactSubLegReader.read(spark,SOURCE_ETRM,metricDict, INITIAL_LOAD)

    return (dfHeader,dfLeg,dfSubLeg, metricDict)
