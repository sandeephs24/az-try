# Databricks notebook source
# MAGIC %run ./../../enricher/CurrencyMappingEnricher

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class DexCurrencyReader(SourceDatasetReader):
    
    def read(spark,metricDict):
        SOURCE_ETRM = 'DEX'
      
        CURRENCY_READER_SQL = """
        select distinct
        UNDL_PRC_CCY_C as SRC_SYS_CURRENCY_NK,
        UNDL_PRC_CCY_C as CURRENCY_CODE
        from STO_PARCEL where UNDL_PRC_CCY_C is NOT NULL
        """
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_PARCEL', format, 'STO_PARCEL')
                
        df = spark.sql(CURRENCY_READER_SQL)
        df = enrich(spark,df, SOURCE_ETRM)
        return (df,metricDict)
