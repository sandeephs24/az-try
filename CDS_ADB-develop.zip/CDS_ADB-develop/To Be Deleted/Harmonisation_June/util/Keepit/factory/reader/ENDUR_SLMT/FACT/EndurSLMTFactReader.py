# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ../../DatasetReader

# COMMAND ----------

# MAGIC %run ./EndurSLMTFactHeaderReader

# COMMAND ----------

# MAGIC %run ./EndurSLMTFactLegReader

# COMMAND ----------

# MAGIC %run ./EndurSLMTFactSubLegReader

# COMMAND ----------

class EndurSLMTFactReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM, metricDict, INITIAL_LOAD_ENDUR_GPNA):
        
    (dfHeader, metricDict) = EndurSLMTFactHeaderReader.read(spark,SOURCE_ETRM, metricDict, INITIAL_LOAD_ENDUR_GPNA)
    (dfLeg, metricDict) = EndurSLMTFactLegReader.read(spark,SOURCE_ETRM, metricDict, INITIAL_LOAD_ENDUR_GPNA)
    (dfSubLeg, metricDict) = EndurSLMTFactSubLegReader.read(spark,SOURCE_ETRM, metricDict, INITIAL_LOAD_ENDUR_GPNA)

    return (dfHeader,dfLeg,dfSubLeg, metricDict)
