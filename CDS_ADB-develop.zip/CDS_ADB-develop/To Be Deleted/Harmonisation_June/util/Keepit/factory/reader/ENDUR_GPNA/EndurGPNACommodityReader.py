# Databricks notebook source
# MAGIC %run ./../../enricher/CommodityMappingEnricher

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class EndurGPNACommodityReader(SourceDatasetReader):
    
   def read(spark,metricDict):
     
      SOURCE_ETRM = 'ENDUR_GPNA'
        
      COMMODITY_READ_SQL = """
      SELECT      
      d.id_number             as SRC_SYS_COMMODITY_NK
      ,d.name                 as SRC_COMMODITY_NAME     
      ,d.name                 as SRC_COMMODITY_GROUP_NAME       
      ,'Y'                    as ACTIVE_COMMODITY_FLAG 
      ,'1900-01-01'                   as SOURCE_LAST_UPDATE
      from IDX_GROUP d
      """      
      
      format = "delta"
      readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'IDX_GROUP', format, 'IDX_GROUP')
      
      df = spark.sql(COMMODITY_READ_SQL)
      df = enrichCommodityForMapping(spark,df,SOURCE_ETRM)
      
      return (df,metricDict)
      
   
