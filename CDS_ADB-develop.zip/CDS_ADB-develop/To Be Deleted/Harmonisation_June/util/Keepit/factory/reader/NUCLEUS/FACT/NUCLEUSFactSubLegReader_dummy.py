# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../../../WatermarkReader

# COMMAND ----------

import abc
class SourceDatasetReader(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def read(self):
        pass

# COMMAND ----------

class NUCLEUSFactSubLegReader(SourceDatasetReader):
    
  def read(spark, SOURCE_ETRM,metricDict, initial_load):
    
    (dfSubLeg,metricDict) = readFactSubLeg(spark, SOURCE_ETRM,metricDict, initial_load)

    return (dfSubLeg,metricDict)

# COMMAND ----------

def readFactSubLeg(spark, SOURCE_ETRM,metricDict, initial_load):
    from pyspark.sql.functions import concat
    from pyspark.sql.functions import date_format
    
    from datetime import datetime
    current_date_yyyymmdd = datetime.today().strftime('%Y%m%d')
    last_watermark_trade_date = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'DEAL_MONTH_DETAILS','TRADE_DATE', 'FACT_DEAL_SUB_LEG')
    last_watermark_trade_date = last_watermark_trade_date[0:19]
    last_watermark_modify_date = getLastWaterMarkForTheTableColumnWise(spark,SOURCE_ETRM,'DEAL_MONTH_DETAILS','MODIFY_DATE', 'FACT_DEAL_SUB_LEG')
    last_watermark_modify_date = last_watermark_modify_date[0:19]
    

    format = "delta"
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'DEAL_MONTH_DETAILS', format, 'DEAL_MONTH_DETAILS')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'FLAT_BROKER_FEES', format, 'FLAT_BROKER_FEES')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'BROKER_COMMISSION_MONTHS', format, 'BROKER_COMMISSION_MONTHS')
    readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, SOURCE_ETRM, 'CLEARINGBROKER_FEES', format, 'CLEARINGBROKER_FEES')

    
    dfSubLeg = spark.sql(SQL)
    
    return (dfSubLeg,metricDict)
