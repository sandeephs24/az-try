# Databricks notebook source
# MAGIC %run ./../../../../../util/installPyodbcLib

# COMMAND ----------

# MAGIC %run ./../../../../../util/MappingReader

# COMMAND ----------

# MAGIC %run ./../../../../../util/factory/writer/DatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../../../util/CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../../../../util/WatermarkReader

# COMMAND ----------

# MAGIC %run ./../../../../../util/DatasetConfigReader

# COMMAND ----------


        from pyspark.sql.functions import concat
        from datetime import datetime
        current_date_yyyymmdd = datetime.today().strftime('%Y-%m-%d %H:%M:%S')
        print(current_date_yyyymmdd) 
        SOURCE_ETRM = 'NUCLEUS'
        
        last_watermark = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'DEAL_MONTH_DETAILS','DIM_COMMODITY')
        last_watermark = last_watermark[0:19]
        
        df = executeJdbcQueryAndReturnDF("select src_sys_commodity_nk from tsa_curated.dim_commodity where src_sys_name = '{0}'".format(SOURCE_ETRM))
        df.createOrReplaceTempView("CURATED_DIM_COMMODITY")
        
        df = readMapping(spark,'COMMODITY_CODE_TO_COMMODITY_TYPE_NAME','NUCLEUS')
        df.createOrReplaceTempView('MAPPING_STANDARD_COMMODITY_TYPE_NAME')
        
        #df = executeJdbcQueryAndReturnDF("select * from tsa_curated.test_udm") 
        #df.createOrReplaceTempView("testudm")
        
        COMMODITY_READER_SQL = """
        SELECT 
        '77555' AS MAPPING_ID,
        '7' as TARGET_MAPPING_ID,
        'COMMODITY_CODE_TO_COMMODITY_TYPE_NAME' as TARGET_MAPPING_NAME,
        'NUCLEUS' AS SOURCE_SYSTEM_MAPPED,
        SOURCE_MAPPING_VALUE,
        CASE 
        WHEN TARGET_MAPPING_VALUE = 'POWER' THEN 'POWER'
        WHEN TARGET_MAPPING_VALUE = 'ELECTRICITY' THEN 'POWER'
        WHEN TARGET_MAPPING_VALUE= 'NATURAL GAS' THEN 'GAS'
        WHEN TARGET_MAPPING_VALUE = 'CRUDE OIL' THEN 'OIL'
        WHEN TARGET_MAPPING_VALUE = 'AIR EMISSIONS' THEN 'EMISSIONS'
        WHEN TARGET_MAPPING_VALUE ='CAPACITY' THEN 'CAPACITY' 
                            END AS TARGET_MAPPING_VALUE,
        '{0}' as RECORD_CREATED_DTTM,
        'batch insert' as RECORD_CREATED_BY,
         '{1}' as RECORD_UPDATED_DTTM,
        'batch update' as RECORD_UPDATED_BY
        from(        
        SELECT DISTINCT
            DMD.COM_COMMODITY 	AS SOURCE_MAPPING_VALUE,
           CASE WHEN C.DESCRIPTION is null THEN 'POWER'	
           WHEN C.DESCRIPTION is not null THEN C.UNC_UNDERLYING_COMMODITY  END
           AS TARGET_MAPPING_VALUE                    
            FROM DEAL_MONTH_DETAILS DMD 
            LEFT JOIN COMMODITIES C
            ON DMD.COM_COMMODITY = C.COMMODITY
             where 
            (
            DMD.MODIFY_DATE > '1900-01-01 00:00:00' and
            DMD.COM_COMMODITY not in (select src_sys_commodity_nk from CURATED_DIM_COMMODITY)
            
            ) 
           )
           UNION
           
           SELECT 
        '77556' AS MAPPING_ID,
        '8' as TARGET_MAPPING_ID,
        'COMMODITY_CODE_TO_HIGH_RISK_COMMODITY_MAP' as TARGET_MAPPING_NAME,
        'NUCLEUS' AS SOURCE_SYSTEM_MAPPED,
        SOURCE_MAPPING_VALUE,
         'UNKNOWN' AS TARGET_MAPPING_VALUE,
        '{2}' as RECORD_CREATED_DTTM,
        'batch insert' as RECORD_CREATED_BY,
         '{3}' as RECORD_UPDATED_DTTM,
        'batch update' as RECORD_UPDATED_BY
        from(        
        SELECT DISTINCT
            DMD.COM_COMMODITY 	AS SOURCE_MAPPING_VALUE,
           CASE WHEN C.DESCRIPTION is null THEN 'POWER'	
           WHEN C.DESCRIPTION is not null THEN C.UNC_UNDERLYING_COMMODITY  END
           AS TARGET_MAPPING_VALUE                    
            FROM DEAL_MONTH_DETAILS DMD 
            LEFT JOIN COMMODITIES C
            ON DMD.COM_COMMODITY = C.COMMODITY
             where 
            (
            DMD.MODIFY_DATE > '1900-01-01 00:00:00' and
            DMD.COM_COMMODITY not in (select src_sys_commodity_nk from CURATED_DIM_COMMODITY)
            
            ) 
           )
           UNION
            SELECT 
        '77557' AS MAPPING_ID,
        '9' as TARGET_MAPPING_ID,
        'COMMODITY_CODE_TO_DUAL_USE_COMMODITY_MAP' as TARGET_MAPPING_NAME,
        'NUCLEUS' AS SOURCE_SYSTEM_MAPPED,
        SOURCE_MAPPING_VALUE,
         'NO' AS TARGET_MAPPING_VALUE,
        '{4}' as RECORD_CREATED_DTTM,
        'batch insert' as RECORD_CREATED_BY,
         '{5}' as RECORD_UPDATED_DTTM,
        'batch update' as RECORD_UPDATED_BY
        from(        
        SELECT DISTINCT
            DMD.COM_COMMODITY 	AS SOURCE_MAPPING_VALUE,
           CASE WHEN C.DESCRIPTION is null THEN 'POWER'	
           WHEN C.DESCRIPTION is not null THEN C.UNC_UNDERLYING_COMMODITY  END
           AS TARGET_MAPPING_VALUE                    
            FROM DEAL_MONTH_DETAILS DMD 
            LEFT JOIN COMMODITIES C
            ON DMD.COM_COMMODITY = C.COMMODITY
             where 
            (
            DMD.MODIFY_DATE > '1900-01-01 00:00:00' and
            DMD.COM_COMMODITY not in (select src_sys_commodity_nk from CURATED_DIM_COMMODITY)
            
            ) 
           )
        """.format(current_date_yyyymmdd,current_date_yyyymmdd,current_date_yyyymmdd,current_date_yyyymmdd,current_date_yyyymmdd,current_date_yyyymmdd)
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'COMMODITIES', format, 'COMMODITIES')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'UNITS', format, 'UNITS')
        readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, SOURCE_ETRM, 'DEAL_MONTH_DETAILS', format, 'DEAL_MONTH_DETAILS')
        
        
        df = spark.sql(COMMODITY_READER_SQL)
        df = df.withColumn("TARGET_MAPPING_ID",df.TARGET_MAPPING_ID.cast('int'))
        df = df.withColumn("TARGET_MAPPING_NAME",df.TARGET_MAPPING_NAME.cast('string'))
        df = df.withColumn("SOURCE_SYSTEM_MAPPED",df.SOURCE_SYSTEM_MAPPED.cast('string'))
        df = df.withColumn("SOURCE_MAPPING_VALUE",df.SOURCE_MAPPING_VALUE.cast('string'))
        df = df.withColumn("TARGET_MAPPING_VALUE",df.TARGET_MAPPING_VALUE.cast('string'))
        df = df.withColumn("RECORD_CREATED_DTTM",df.RECORD_CREATED_DTTM.cast('timestamp'))
        df = df.withColumn("RECORD_CREATED_BY",df.RECORD_CREATED_BY.cast('string'))
        df = df.withColumn("RECORD_UPDATED_DTTM",df.RECORD_UPDATED_DTTM.cast('timestamp'))
        df = df.withColumn("RECORD_UPDATED_BY",df.RECORD_UPDATED_BY.cast('string'))
        df.createOrReplaceTempView('NEW_COMMS')
        
        INSERT_SQL = """
           SELECT 
                a.TARGET_MAPPING_ID,
                a.TARGET_MAPPING_NAME,
                a.SOURCE_SYSTEM_MAPPED,
                a.SOURCE_MAPPING_VALUE,
                a.TARGET_MAPPING_VALUE,
                a.RECORD_CREATED_DTTM,
               a.RECORD_CREATED_BY,
               a. RECORD_UPDATED_DTTM,
               a.RECORD_UPDATED_BY
         FROM NEW_COMMS a
                  WHERE a.SOURCE_MAPPING_VALUE NOT IN (select SOURCE_MAPPING_VALUE from MAPPING_STANDARD_COMMODITY_TYPE_NAME )  
                  
        """
        
        df1 = spark.sql(INSERT_SQL)
        df1.show(20,False)
       
        writeDatasetSynapseConnector(spark, df1,"tsa_curated.USER_MANAGED_MAPPING_DATA")
        
        
