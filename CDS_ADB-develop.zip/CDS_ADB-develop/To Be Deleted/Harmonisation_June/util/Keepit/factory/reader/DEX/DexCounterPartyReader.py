# Databricks notebook source
# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

# MAGIC %run ./../../enricher/InternalPartyEmptyEnricher

# COMMAND ----------

# MAGIC %run ./../../enricher/PartyGoldTierEnricher

# COMMAND ----------

class DexCounterPartyReader(SourceDatasetReader):
     
    def read(spark,metricDict):
        
        SOURCE_ETRM = 'DEX'
      
        last_watermark_party = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_CHRGACCT','DIM_PARTY')
        last_watermark_party = last_watermark_party[0:19]
        
        df = executeJdbcQueryAndReturnDF("select src_sys_party_nk from tsa_curated.dim_party where src_sys_name = '{0}'".format(SOURCE_ETRM))
        df.createOrReplaceTempView("CURATED_DIM_PARTY")
        
        SQL = """
        select sequence_num, CORPORATE_ENTITY_C, rank() over (partition by sequence_num order by last_update_tstmp desc) rnk 
        from STO_TRDGACCT TA
        """
                    
        INTERNAL_PARTY_READER_SQL = """
        WITH legal_enity_view as
        (
        SELECT distinct cast(CA.SEQUENCE_NUM as int) AS SRC_SYS_PARTY_NK ,
        CA.CHARGE_ACCT_MNEM AS SRC_SYS_PARTY_SHORT_NAME,
        CR.NAME_TEXT        AS SRC_SYS_PARTY_LONG_NAME,
        cr.CORPORATE_ENTITY_C as SRC_SYS_LEGAL_ENTITY_NK,
        cr.NAME_TEXT  as SRC_SYS_LEGAL_ENTITY_NAME,
        CA.LAST_UPDATE_TSTMP SOURCE_LAST_UPDATE
        FROM 	STO_CHRGACCT ca 
        JOIN 	STO_TRDGACCT ta    
        ON 	ta.SEQUENCE_NUM = ca.SEQUENCE_NUM
        JOIN 	STO_CORPENT cr    
        ON 	cr.CORPORATE_ENTITY_C = ta.CORPORATE_ENTITY_C
        WHERE 	ca.CHRG_ACCT_TYP_CODE = 'T'
        )
        SELECT SRC_SYS_PARTY_NK,
        SRC_SYS_PARTY_SHORT_NAME,
        SRC_SYS_PARTY_LONG_NAME,
        'Internal' AS Party_Type,
        SRC_SYS_LEGAL_ENTITY_NK,
        SRC_SYS_LEGAL_ENTITY_NAME,
        SOURCE_LAST_UPDATE
        FROM legal_enity_view VW
        WHERE (VW.SOURCE_LAST_UPDATE > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss') or
        VW.SRC_SYS_PARTY_NK in (select src_sys_party_nk from CURATED_DIM_PARTY))
        """.format(last_watermark_party)
    
        EXTERNAL_PARTY_READER_SQL = """
        SELECT distinct
        cast(CA.SEQUENCE_NUM as int)  AS SRC_SYS_PARTY_NK
        ,NVL(CO.CMF_SHORT_NAME, CA.COMPANY_MNEM)  AS SRC_SYS_PARTY_SHORT_NAME
        ,CO.CMF_LONG_NAME    AS SRC_SYS_PARTY_LONG_NAME
        ,'External' as Party_Type,
        co.company_mnem as SRC_SYS_LEGAL_ENTITY_NK,
        CO.CMF_LONG_NAME SRC_SYS_LEGAL_ENTITY_NAME,
        CA.LAST_UPDATE_TSTMP SOURCE_LAST_UPDATE
        FROM STO_CHRGACCT CA INNER JOIN STO_COMPANY CO ON CO.COMPANY_MNEM = CA.COMPANY_MNEM
        WHERE CA.CHRG_ACCT_TYP_CODE <> 'T' 
        AND 
        (
        CA.LAST_UPDATE_TSTMP > to_timestamp('{0}','yyyy-MM-dd HH:mm:ss') 
        or 
        CA.SEQUENCE_NUM in (select src_sys_party_nk from CURATED_DIM_PARTY)
        )
        """.format(last_watermark_party)
        
        
        format = "delta"
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CHRGACCT', format, 'STO_CHRGACCT')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_CORPENT', format, 'STO_CORPENT')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_TRDGACCT', format, 'STO_TRDGACCT')
        readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, SOURCE_ETRM, 'STO_COMPANY',format, 'STO_COMPANY')
               
             
        df = spark.sql(SQL)
        
        dfInternal = spark.sql(INTERNAL_PARTY_READER_SQL)
        
        dfExternal = spark.sql(EXTERNAL_PARTY_READER_SQL)
        
        df1 = enrichInternalParty(dfInternal)
        spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
        df1 = df1.withColumn("NEXT_ENHANCED_MONITORING_REQUIRED_DATE",to_date(col("NEXT_ENHANCED_MONITORING_REQUIRED_DATE"),"yyyy-MM-dd"))
        df1 = df1.withColumn("KYC_NEXT_REVIEW_DATE",to_date(col("KYC_NEXT_REVIEW_DATE"),"yyyy-MM-dd"))
        df1 = df1.withColumn("KYC_LAST_REVIEW_DATE",to_date(col("KYC_LAST_REVIEW_DATE"),"yyyy-MM-dd"))
        df1 = df1.withColumn("SOURCE_LAST_UPDATE",to_timestamp(col("SOURCE_LAST_UPDATE")))
        df2 = enrichExternalParty(spark,dfExternal,SOURCE_ETRM)
        df2 = df2.withColumn("NEXT_ENHANCED_MONITORING_REQUIRED_DATE",to_date(col("NEXT_ENHANCED_MONITORING_REQUIRED_DATE"),"yyyy-MM-dd"))
        df2 = df2.withColumn("KYC_NEXT_REVIEW_DATE",to_date(col("KYC_NEXT_REVIEW_DATE"),"yyyy-MM-dd"))
        df2 = df2.withColumn("KYC_LAST_REVIEW_DATE",to_date(col("KYC_LAST_REVIEW_DATE"),"yyyy-MM-dd"))
        df2 = df2.withColumn("SOURCE_LAST_UPDATE",to_timestamp(col("SOURCE_LAST_UPDATE")))
        
        
        totalDf = df1.union(df2)
      
        return (totalDf,metricDict)
        
