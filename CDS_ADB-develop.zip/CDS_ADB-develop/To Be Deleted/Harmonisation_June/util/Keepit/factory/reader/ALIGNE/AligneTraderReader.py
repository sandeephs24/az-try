# Databricks notebook source
# MAGIC %run ./../DatasetReader

# COMMAND ----------

# MAGIC %run ./../../../WatermarkReader

# COMMAND ----------

# MAGIC %run ./../../../DatasetConfigReader

# COMMAND ----------

class AligneTraderReader(SourceDatasetReader):
    def read(spark,metricDict):
      
      import pyspark.sql.functions as F
      
      SOURCE_ETRM = 'ALIGNE'
      #last_watermark = getLastWaterMarkForTheTable(spark,SOURCE_ETRM,'STO_USR','DIM_TRADER')
      #last_watermark = last_watermark[0:19]
      
      df = executeJdbcQueryAndReturnDF("select src_sys_trader_nk from tsa_curated.dim_trader where src_sys_name = '{0}'".format(SOURCE_ETRM))
      df.createOrReplaceTempView("CURATED_DIM_TRADER")
      
      TRADER_READ_SQL = """
      
         SELECT	DISTINCT a.USR_ID as SRC_SYS_TRADER_NK,
                a.USR_NAME     as TRADER_NAME,         
               SUBSTR(a.USR_NAME, 0, INSTR(a.USR_NAME, ' ')-1)    as TRADER_FIRST_NAME,
               SUBSTR(a.USR_NAME, INSTR(a.USR_NAME, ' ')+1) as TRADER_LAST_NAME,
                '' as SOURCE_LAST_UPDATE
                FROM	STATIC_USERS a 
        JOIN	GV_TRADES b 
        ON	a.USR_ID=b.TRADER
      
        """


      format = "parquet"
      readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'STATIC_USERS', format, 'STATIC_USERS')
      readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, SOURCE_ETRM, 'GV_TRADES', format, 'GV_TRADES')
     
      df = spark.sql(TRADER_READ_SQL)
      print('Reader Count')
      print(df.count())
      return  (df,metricDict)
