# Databricks notebook source
class ReferenceUnitOfMeasureReader(SourceDatasetReader):
    
   def read(spark):
      df = spark.createDataFrame(
      [
      ('1', 'code1','desc1'), 
      ('2', 'code2','desc2'),
      ('3', 'code3','desc3'),
      ],
      ['SRC_SYS_UNIT_OF_MEASURE_NK','STD_UNIT_OF_MEASURE_SYMBOL_CODE','STD_UNIT_OF_MEASURE_DESCRIPTION']
      )
      return df
