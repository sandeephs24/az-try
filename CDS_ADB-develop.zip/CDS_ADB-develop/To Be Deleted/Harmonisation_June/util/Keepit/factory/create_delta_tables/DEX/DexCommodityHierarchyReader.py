# Databricks notebook source
class DexCommodityHierarchyReader(SourceDatasetReader):
    
   def read(spark):
      df = spark.createDataFrame(
      [
      ('1', 'name1','type name 1','Y','Y','Y','01-01-2021 01:25:00'), 
      ('2', 'name2','type name 2','Y','Y','Y','01-01-2021 01:25:00'), 
      ('3', 'name3','type name 3','Y','Y','Y','01-01-2021 01:25:00')
      ],
      ['SRC_SYS_COMMODITY_NK',
      'COMMODITY_NAME',
      'COMMODITY_TYPE_NAME',
      'ACTIVE_COMMODITY_FLAG',
      'HIGH_RISK_COMMODITY_FLAG',
      'DUAL_USE_COMMODITY_FLAG',
      'source_last_update']
      )
      return df
