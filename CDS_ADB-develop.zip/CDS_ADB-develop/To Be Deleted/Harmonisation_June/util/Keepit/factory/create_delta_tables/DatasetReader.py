# Databricks notebook source
import abc
class SourceDatasetReader(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def read(self):
        pass
