# Databricks notebook source
class DexCounterPartyReader(SourceDatasetReader):
    
    def read(spark):
      df = spark.createDataFrame(
      [
      ('1', 'Party1','LongName1','Type1','Party1','Some Name1','Some Key1','US','US','Y','N','Y','US','US','Y','Y','Y','T','A','02-01-2021 01:25:00','02-01-2021 01:25:00','level1','term1','Y','2','02-01-2021 01:25:00','type1','type2','02-01-2021 01:25:00') 
      ],
      ['src_sys_party_nk',
      'SRC_SYS_PARTY_SHORT_NAME',
      'SRC_SYS_PARTY_LONG_NAME',
      'PARTY_TYPE',
      'SRC_SYS_LEGAL_ENTITY_NK',
      'SRC_SYS_LEGAL_ENTITY_NAME',
      'KYC_COUNTERPARTY_KEY',
      'KYC_LEGAL_NAME',
      'KYC_OPERATION_COUNTRY_NAME',
      'KYC_OPERATION_COUNTRY_ISO_CODE',
      'HIGH_RISK_OPERATION_COUNTRY_FLAG',
      'EDD_OPERATION_COUNTRY_FLAG',
      'GEC_OPERATION_COUNTRY_FLAG',
      'KYC_LEGAL_COUNTRY_NAME',
      'KYC_LEGAL_COUNTRY_ISO_CODE',
      'HIGH_RISK_LEGAL_COUNTRY_FLAG',
      'EDD_LEGAL_COUNTRY_FLAG',
      'GEC_LEGAL_COUNTRY_FLAG',
      'KYC_STATUS',
      'KYC_RISK_LEVEL',
      'KYC_NEXT_REVIEW_DATE',
      'KYC_LAST_REVIEW_DATE',
      'KYC_DUE_DILIGENCE_LEVEL',
      'KYC_MONITORING_TERM',
      'ENHANCED_MONITORING_FLAG',
      'ENHANCED_MONITORING_REVIEW_FREQUENCY',
      'NEXT_ENHANCED_MONITORING_REQUIRED_DATE',
      'KYC_AUTHORISED_COMMODITY_TYPE',
      'KYC_AUTHORISED_DEAL_TYPE',
      'source_last_update'] # add your columns label here
      )
      return df
