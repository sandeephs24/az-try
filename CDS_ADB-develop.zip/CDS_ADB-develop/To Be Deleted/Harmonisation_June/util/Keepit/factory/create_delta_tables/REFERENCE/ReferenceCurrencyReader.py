# Databricks notebook source
class ReferenceCurrencyReader(SourceDatasetReader):
    
   def read(spark):
      df = spark.createDataFrame(
      [
      ('1', 'USD','USD'), 
      ('2', 'INR','INR'),
      ('3', 'ABC','ABC')
      ],
      ['SRC_SYS_CURRENCY_NK','ISO_CURRENCY_CODE','ISO_CURRENCY_NAME'] 
      )
      return df
