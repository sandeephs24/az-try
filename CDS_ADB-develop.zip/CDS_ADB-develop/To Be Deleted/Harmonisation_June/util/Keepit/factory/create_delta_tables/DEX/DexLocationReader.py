# Databricks notebook source
class DexLocationReader(SourceDatasetReader):
    
   def read(spark):
      df = spark.createDataFrame(
      [
      ('1', 'name1','type1','US','USA','Y','N','Y','01-01-2021 01:25:00'), 
      ('2', 'name2','type2','IN','India','Y','N','Y','01-01-2021 01:25:00'), 
      ('3', 'name3','type3','CH','China','Y','N','Y','01-01-2021 01:25:00') 

      ],
      ['SRC_SYS_LOCATION_NK',
      'LOCATION_NAME',
      'LOCATION_TYPE',
      'LOCATION_ISO_COUNTRY_CODE',
      'LOCATION_COUNTRY_NAME',
      'HIGH_RISK_COUNTRY_FLAG',
      'EDD_COUNTRY_FLAG',
      'GEC_COUNTRY_FLAG',
      'source_last_update'] # add your columns label here
      )
      return df
