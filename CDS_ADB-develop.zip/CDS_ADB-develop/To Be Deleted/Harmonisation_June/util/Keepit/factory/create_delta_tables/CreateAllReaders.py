# Databricks notebook source
# MAGIC %run ./ENDUR_GPNA/CreateAllENDURGPNAReaders

# COMMAND ----------

# MAGIC %run ./DEX/CreateAllDexReaders

# COMMAND ----------

# MAGIC %run ./REFERENCE/CreateAllReferenceReaders
