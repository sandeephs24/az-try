# Databricks notebook source
class EndurGPNATradeAttributesReader(SourceDatasetReader):
    
   def read(spark):
      df = spark.createDataFrame(
      [
      ('1', 'Virat Kohli','Virat','Kohli','01-01-2021 01:25:00'), # create your data here, be consistent in the types.
      ('2', 'Rishabh Pant','Rishabh','Pant','02-01-2021 01:25:00'),
      ('3', 'Rohit Sharma','Rohit','Rohit Sharma','02-01-2021 01:25:00')
      ],
      ['src_sys_trader_nk','trader_name','trader_first_name','trader_last_name','source_last_update'] # add your columns label here
      )
      return df
