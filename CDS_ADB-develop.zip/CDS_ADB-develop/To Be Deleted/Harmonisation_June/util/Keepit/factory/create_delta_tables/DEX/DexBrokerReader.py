# Databricks notebook source
class DexBrokerReader(SourceDatasetReader):
    
    def read(spark):
        df = spark.createDataFrame(
        [
          ('1', 'foo1','Y','01-01-2021 01:25:00'), # create your data here, be consistent in the types.
          ('2', 'bar','N','02-01-2021 01:25:00'),
          ('3', 'zzz','Y','02-01-2021 01:25:00')
          ],
          ['src_sys_broker_nk','broker_name','active_broker_flag','source_last_update'] # add your columns label here
        )
        return df
