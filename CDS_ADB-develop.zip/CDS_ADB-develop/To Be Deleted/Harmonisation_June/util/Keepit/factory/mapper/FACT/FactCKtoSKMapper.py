# Databricks notebook source
# MAGIC %run ./FactHeaderCKtoSKMapper

# COMMAND ----------

# MAGIC %run ./FactLegCKtoSKMapper

# COMMAND ----------

# MAGIC %run ./FactSublegCKtoSKMapper

# COMMAND ----------

def map(dfFactHeader, dfFactLeg, dfFactSubleg):
  
  dfFactHeader = FactHeaderCKtoSKMapper.map(dfFactHeader)
  dfFactLeg = FactLegCKtoSKMapper.map(dfFactLeg)
  dfFactSubleg = FactSublegCKtoSKMapper.map(dfFactSubleg)
  
  return (dfFactHeader, dfFactLeg, dfFactSubleg)
