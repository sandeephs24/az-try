# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

def map(dfFactLeg,SOURCE_ETRM):
  
  writeDatasetUsingJdbc(dfFactLeg,"tsa_stage.fact_leg_batch_stage")


  SQL = """
  SELECT
  fact_header.SRC_SYS_NAME,
  fact_header.DEAL_ATTRIBUTES_CK,
  date1.date_sk EXECUTION_DATE_SK,
  date2.date_sk TRADE_CREATION_DATE_SK,
  date3.date_sk COMMITMENT_DATE_SK,
  party1.party_sk COUNTERPARTY_SK,
  party2.party_sk SHELL_TRADING_PARTY_SK,
  attr.DEAL_ATTRIBUTES_SK DEAL_ATTRIBUTES_SK,
  trader.TRADER_SK TRADER_SK,
  broker.BROKER_SK DEAL_BROKER_SK,
  commodity.commodity_sk commodity_sk,
  uom.UNIT_OF_MEASURE_SK UNIT_OF_MEASURE_SK,
  fact_header.CONTRACT_QTY
  FROM tsa_stage.fact_header_batch_stage fact_header
  left join tsa_curated.dim_date date1 
    on fact_header.execution_date_ck = date1.date_ck
  left join tsa_curated.dim_date date2 
    on fact_header.trade_date_ck = date2.date_ck
  left join tsa_curated.dim_date date3 
    on fact_header.COMMITMENT_DATE_CK = date3.date_ck
  left join tsa_curated.dim_party party1 
    on fact_header.counterparty_ck = party1.party_ck
  left join tsa_curated.dim_party party2 
    on fact_header.SHELL_TRADING_PARTY_CK = party2.party_ck
  left join tsa_curated.dim_deal_attributes attr 
    on fact_header.deal_attributes_ck = attr.deal_attributes_ck
  left join tsa_curated.dim_trader trader 
    on fact_header.trader_ck = trader.trader_ck
  left join tsa_curated.dim_broker broker 
    on fact_header.broker_ck = broker.broker_ck
  left join tsa_curated.dim_commodity commodity 
    on fact_header.commodity_ck = commodity.commodity_ck
  left join tsa_curated.dim_unit_of_measure uom 
    on fact_header.unit_of_measure_ck = uom.unit_of_measure_ck
  where src_sys_name = '{0}'
  """.format(SOURCE_ETRM)
  
  df = executeJdbcQueryAndReturnDF(SQL,SOURCE_ETRM)
  
  return df
