# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

def map(dfFactHeader,SOURCE_ETRM):
  
  dfFactHeader.createOrReplaceTempView("BATCH_FACT_HEADER_VIEW")
  
  SQL = "select * from tsa_curated.dim_broker where src_sys_name = '{0}'".format(SOURCE_ETRM)
  df = executeJdbcQueryAndReturnDF(SQL)
  df.createOrReplaceTempView("CURATED_DIM_BROKER_VIEW")
  
  SQL = "select * from tsa_curated.dim_trader where src_sys_name = '{0}'".format(SOURCE_ETRM)
  df = executeJdbcQueryAndReturnDF(SQL)
  df.createOrReplaceTempView("CURATED_DIM_TRADER_VIEW")
  
  SQL = "select * from tsa_curated.dim_party where src_sys_name = '{0}'".format(SOURCE_ETRM)
  df = executeJdbcQueryAndReturnDF(SQL)
  df.createOrReplaceTempView("CURATED_DIM_PARTY_VIEW")
  
  SQL = "select * from tsa_curated.dim_commodity where src_sys_name = '{0}'".format(SOURCE_ETRM)
  df = executeJdbcQueryAndReturnDF(SQL)
  df.createOrReplaceTempView("CURATED_DIM_COMMODITY_VIEW")
  
  SQL = "select * from tsa_curated.dim_deal_attributes where src_sys_name = '{0}'".format(SOURCE_ETRM)
  df = executeJdbcQueryAndReturnDF(SQL)
  df.createOrReplaceTempView("CURATED_DIM_DEAL_ATTRIBUTES_VIEW")
  
  SQL = "select * from tsa_curated.dim_unit_of_measure where src_sys_name = '{0}'".format(SOURCE_ETRM)
  df = executeJdbcQueryAndReturnDF(SQL)
  df.createOrReplaceTempView("CURATED_DIM_UOM_VIEW")
  
  SQL = "select * from tsa_curated.dim_currency where src_sys_name = '{0}'".format(SOURCE_ETRM)
  df = executeJdbcQueryAndReturnDF(SQL)
  df.createOrReplaceTempView("CURATED_DIM_CURRENCY_VIEW")
  
  SQL = """
  SELECT
  FROM BATCH_FACT_HEADER_VIEW a
  left join CURATED_DIM_BROKER_VIEW b on a.broker_ck = b.broker_ck
  left join CURATED_DIM_TRADER_VIEW c on a.trader_ck = b.trader_ck
  left join CURATED_DIM_PARTY_VIEW d on a.party_ck = b.party_ck
  left join CURATED_DIM_COMMODITY_VIEW e on a.commodity_ck = b.commodity_ck
  left join CURATED_DIM_DEAL_ATTRIBUTES_VIEW f on a.dim_attributes_ck = b.dim_attributes_ck
  left join CURATED_DIM_UOM_VIEW g on a.unit_of_measure_ck = b.unit_of_measure_ck
  
  
  
  
  """
  
  
  
  
  

  
  
  
  
  return dfFactHeader
