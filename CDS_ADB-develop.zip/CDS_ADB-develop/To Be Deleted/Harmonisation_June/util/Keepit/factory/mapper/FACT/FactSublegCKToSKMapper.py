# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

def map(dfFactSubleg,SOURCE_ETRM):
  
  writeDatasetUsingJdbc(dfFactSubleg,"tsa_stage.fact_subleg_batch_stage")
    
  SQL = """
  SELECT
  fact_header.SRC_SYS_NAME,
  fact_header.DEAL_SUBLEG_CK,
  date1.date_sk EXECUTION_DATE_SK,
  date2.date_sk TRADE_CREATION_DATE_SK,
  date3.date_sk COMMITMENT_DATE_SK,
  date4.date_sk PARCEL_DATE_CK
  party1.party_sk COUNTERPARTY_SK,
  party2.party_sk SHELL_TRADING_PARTY_SK,
  attr.DEAL_ATTRIBUTES_SK DEAL_ATTRIBUTES_SK,
  trader.TRADER_SK TRADER_SK,
  broker.BROKER_SK DEAL_BROKER_SK,
  commodity.commodity_sk commodity_sk,
  uom.UNIT_OF_MEASURE_SK UNIT_OF_MEASURE_SK,
  fact_header.CONTRACT_QTY
  FROM tsa_stage.fact_header_batch_stage fact_header
  left join tsa_curated.dim_date date1 
    on fact_header.execution_date_ck = date1.date_ck
  left join tsa_curated.dim_date date2 
    on fact_header.trade_date_ck = date2.date_ck
  left join tsa_curated.dim_date date3 
    on fact_header.COMMITMENT_DATE_CK = date3.date_ck
  left join tsa_curated.dim_date date4 
    on fact_header.PARCEL_DATE_CK = date4.date_ck
  left join tsa_curated.dim_party party1 
    on fact_header.counterparty_ck = party1.party_ck
  left join tsa_curated.dim_party party2 
    on fact_header.SHELL_TRADING_PARTY_CK = party2.party_ck
  left join tsa_curated.dim_deal_attributes attr 
    on fact_header.deal_attributes_ck = attr.deal_attributes_ck
  left join tsa_curated.dim_trader trader 
    on fact_header.trader_ck = trader.trader_ck
  left join tsa_curated.dim_broker broker 
    on fact_header.broker_ck = broker.broker_ck
  left join tsa_curated.dim_commodity commodity 
    on fact_header.commodity_ck = commodity.commodity_ck
  left join tsa_curated.dim_location location1 
    on fact_header.LOADING_LOCATION_CK = location1.location_ck
  left join tsa_curated.dim_location location2 
    on fact_header.DISCHARGE_LOCATION_CK = location2.location_ck
  left join tsa_curated.dim_date date5 
    on fact_header.execution_date_ck = date5.date_ck
  left join tsa_curated.dim_date date6 
    on fact_header.trade_date_ck = date6.date_ck
  left join tsa_curated.dim_date date7 
    on fact_header.COMMITMENT_DATE_CK = date7.date_ck
  left join tsa_curated.dim_date date8 
    on fact_header.PARCEL_DATE_CK = date8.date_ck
  left join tsa_curated.dim_unit_of_measure uom1
    on fact_header.DEAL_UNIT_OF_MEASURE_CK = uom1.unit_of_measure_ck
  left join tsa_curated.dim_unit_of_measure uom2
    on fact_header.PRICING_UNIT_OF_MEASURE_CK = uom2.unit_of_measure_ck
  left join tsa_curated.dim_currency ccy
    on fact_header.DEAL_CCY_CK = ccy.currency_ck
  where src_sys_name = '{0}'
  """.format(SOURCE_ETRM)
  
  df = executeJdbcQueryAndReturnDF(SQL,SOURCE_ETRM)
  
  return df
