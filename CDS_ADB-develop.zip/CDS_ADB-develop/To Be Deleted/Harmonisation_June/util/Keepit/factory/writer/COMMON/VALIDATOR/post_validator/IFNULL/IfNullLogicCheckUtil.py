# Databricks notebook source
# MAGIC %run ./../../../../../../CuratedDatasetWriter

# COMMAND ----------

def runSQLandCheckIfNull(SQL):
  df = executeJdbcQueryAndReturnDF(SQL)
  TEST_STATUS = df.select('TEST_STATUS').collect()[0][0]
  print(TEST_STATUS)
  if (TEST_STATUS == 'IFNULL TEST FAILED'):
    return "IFNULL TEST FAILED"
  else:
    return "SUCCESS"
  
