# Databricks notebook source
# MAGIC %run ./IfNullLogicCheckUtil

# COMMAND ----------

def validateIfNullLogicCurrency(SOURCE_ETRM):
  
  SQL = """
  SELECT 
            CASE WHEN [ISO_CURRENCY_CODE] = [ISO_CURRENCY_NAME]            
            THEN 'IFNULL TEST PASSED'
            ELSE 'IFNULL TEST FAILED' END AS TEST_STATUS
            FROM (select		[SRC_SYS_NAME]
			,[ISO_CURRENCY_CODE]
			,[ISO_CURRENCY_NAME]
			,COUNT(1) AS RECORD_COUNT
            from		[tsa_curated].[DIM_CURRENCY]
            where		(LEN(NULLIF([ISO_CURRENCY_CODE],'')) != 3
            or [ISO_CURRENCY_CODE] is null)
            group by	[SRC_SYS_NAME]
			,[ISO_CURRENCY_CODE]
			,[ISO_CURRENCY_NAME]
     )ifnullcheck     
     union 
		select 'NA' as TEST_STATUS where not exists(select *
		from		[tsa_curated].[DIM_CURRENCY]
            where		(LEN(NULLIF([ISO_CURRENCY_CODE],'')) != 3
            or [ISO_CURRENCY_CODE] is null)     
        and [SRC_SYS_NAME] ='{1}'
      )
  """.format(SOURCE_ETRM,SOURCE_ETRM)
  
    
  status = runSQLandCheckIfNull(SQL)
  return status
