# Databricks notebook source
# MAGIC %run ./IfNullLogicCheckUtil

# COMMAND ----------

def validateIfNullLogicUOM(SOURCE_ETRM):
  
  SQL = """  
  SELECT 
            CASE WHEN [STD_UNIT_OF_MEASURE_SYMBOL_CODE] = [STD_UNIT_OF_MEASURE_DESCRIPTION] 			
			 THEN 'IFNULL TEST PASSED'
            ELSE 'IFNULL TEST FAILED' END AS TEST_STATUS
			  FROM (select		[SRC_SYS_NAME]
			,[STD_UNIT_OF_MEASURE_SYMBOL_CODE]
			,[STD_UNIT_OF_MEASURE_DESCRIPTION]
			
						from [tsa_curated].[DIM_UNIT_OF_MEASURE]
      where	(LEN(NULLIF([STD_UNIT_OF_MEASURE_SYMBOL_CODE],'')) not in (2,3) OR
      [STD_UNIT_OF_MEASURE_SYMBOL_CODE] is null)      
        and [SRC_SYS_NAME] ='{0}'
      group by	[SRC_SYS_NAME]
                  ,[STD_UNIT_OF_MEASURE_SYMBOL_CODE]
                  ,[STD_UNIT_OF_MEASURE_DESCRIPTION]
				  
           )ifnullcheck
		union 
		select 'NA' as TEST_STATUS where not exists(
		select		* from [tsa_curated].[DIM_UNIT_OF_MEASURE]
      where	(LEN(NULLIF([STD_UNIT_OF_MEASURE_SYMBOL_CODE],'')) not in (2,3) OR
      [STD_UNIT_OF_MEASURE_SYMBOL_CODE] is null)      
        and [SRC_SYS_NAME] ='{1}'
      )
  """.format(SOURCE_ETRM,SOURCE_ETRM)
  
  status = runSQLandCheckIfNull(SQL)
  return status
