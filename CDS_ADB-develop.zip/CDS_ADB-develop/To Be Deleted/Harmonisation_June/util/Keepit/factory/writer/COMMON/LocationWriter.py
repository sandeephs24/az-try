# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../DatasetWriter

# COMMAND ----------

# MAGIC %run ./VALIDATOR/pre_validator/duplicate/LocationDuplicatePreValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/duplicate/LocationDuplicatePostValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/UNIQUENESS/LocationUniquenessPostValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/IFNULL/LocationifnullPostValidator

# COMMAND ----------

class LocationWriter(DatasetWriter):
    DELETE_DIM_LOCATION_STAGE_SQL = """DELETE from tsa_stage.dim_location_stage where src_sys_name = ?"""
    INSERT_DIM_LOCATION_SQL = """
    INSERT INTO tsa_curated.dim_location
    (
    location_ck,
    record_created_dttm,
    record_updated_dttm,
    src_sys_name,
    src_sys_location_nk,
    location_name,
    location_type,
    LOCATION_AREA,
    LOCATION_ISO_COUNTRY_CODE,
    LOCATION_COUNTRY_NAME,
    HIGH_RISK_COUNTRY_FLAG,
    EDD_COUNTRY_FLAG,
    GEC_COUNTRY_FLAG
    )
    SELECT location_ck,
    current_timestamp record_created_dttm,
    current_timestamp record_updated_dttm,
    src_sys_name src_sys_name,
    src_sys_location_nk,
    location_name,
    location_type,
    LOCATION_AREA,
    LOCATION_ISO_COUNTRY_CODE,
    LOCATION_COUNTRY_NAME,
    HIGH_RISK_COUNTRY_FLAG,
    EDD_COUNTRY_FLAG,
    GEC_COUNTRY_FLAG 
    FROM tsa_stage.dim_location_stage stage
    WHERE NOT EXISTS
    (SELECT 1 
    FROM tsa_curated.dim_location main 
    WHERE main.location_ck = stage.location_ck ) and stage.src_sys_name = ? 
    """
    
    UPDATE_DIM_LOCATION_SQL = """UPDATE main_table 
    SET main_table.location_name =stage_table.location_name,
    main_table.location_type =stage_table.location_type,
    main_table.location_area =stage_table.location_area,
    main_table.LOCATION_ISO_COUNTRY_CODE =stage_table.LOCATION_ISO_COUNTRY_CODE,
    main_table.LOCATION_COUNTRY_NAME = stage_table.LOCATION_COUNTRY_NAME,
    main_table.HIGH_RISK_COUNTRY_FLAG = stage_table.HIGH_RISK_COUNTRY_FLAG,
    main_table.EDD_COUNTRY_FLAG = stage_table.EDD_COUNTRY_FLAG,
    main_table.GEC_COUNTRY_FLAG = stage_table.GEC_COUNTRY_FLAG,
    record_updated_dttm = current_timestamp
    FROM tsa_curated.dim_location main_table
    JOIN tsa_stage.dim_location_stage stage_table
    ON main_table.location_ck = stage_table.location_ck and stage_table.src_sys_name = ? """
    
    UPDATE_WATERMARK_SQL = """
    UPDATE tsa_curated.watermark SET last_offset_value =
    (
    SELECT CONVERT(varchar(20), max(source_last_update), 120)
    FROM tsa_curated.dim_location main_table,tsa_stage.dim_location_stage stage_table 
    WHERE main_table.location_ck = stage_table.location_ck
    ) 
    WHERE source_name = ?
    and source_table_name = ?
    and table_name = 'DIM_LOCATION' 
    """
    
    def write(df, SOURCE_ETRM, metricDict):
        import time
        from pyspark.sql.types import DateType
        print('deleting stage records')
        executePyOdbcQueryWithParam1(LocationWriter.DELETE_DIM_LOCATION_STAGE_SQL,SOURCE_ETRM)
        start = time.time()
       
        df = df.withColumn("SRC_SYS_LOCATION_NK",df.SRC_SYS_LOCATION_NK.cast('string')) 
        df = df.withColumn("RECORD_CREATED_DTTM",df.RECORD_CREATED_DTTM.cast(DateType()))
        df = df.withColumn("SOURCE_LAST_UPDATE",df.SOURCE_LAST_UPDATE.cast(DateType()))
        
        df = df.select(
          col("LOCATION_CK"),
          col("RECORD_CREATED_DTTM"),
          col("SRC_SYS_NAME"),
          col("SRC_SYS_LOCATION_NK"),
          col("LOCATION_NAME"),
          col("LOCATION_TYPE"),
          col("LOCATION_AREA"),
          col("LOCATION_ISO_COUNTRY_CODE"),
          col("LOCATION_COUNTRY_NAME"),
          col("HIGH_RISK_COUNTRY_FLAG"),
          col("EDD_COUNTRY_FLAG"),
          col("GEC_COUNTRY_FLAG"),
          col("SOURCE_LAST_UPDATE") 
          )
        df.printSchema() 
        print("writing to stage table")
        writeDatasetSynapseConnector(spark, df,"tsa_stage.dim_location_stage")
        
        end = time.time()
        time_taken = end - start
        metricDict["location_writer_stage_load_time_taken_in_sec"] = time_taken 
        
        status = validateDuplicateLocation(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
        
        start = time.time()
        print('updating existing records')
        row_affected = executePyOdbcQueryWithParam1(LocationWriter.UPDATE_DIM_LOCATION_SQL, SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["location_writer_update_sql_time_taken_in_sec"] = time_taken 
        metricDict["update_sql_rows_affected"] = row_affected 
        
        start = time.time()
        print('inserting new records')
        row_affected = executePyOdbcQueryWithParam1(LocationWriter.INSERT_DIM_LOCATION_SQL, SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["location_writer_insert_sql_time_taken_in_sec"] = time_taken 
        metricDict["insert_sql_rows_affected"] = row_affected
        
        if(SOURCE_ETRM == 'DEX'):
          SOURCE_TABLE_NAME = 'STO_LOCATION'
          executePyOdbcQueryWithParam2(LocationWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_TABLE_NAME)
        elif(SOURCE_ETRM == 'ENDUR_GPNA'):
          SOURCE_TABLE_NAME = 'GAS_PHYS_LOCATION'
          executePyOdbcQueryWithParam2(LocationWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_TABLE_NAME)
        elif(SOURCE_ETRM == 'ENDUR_SLMT'):
          SOURCE_TABLE_NAME = 'GAS_PHYS_LOCATION'
          executePyOdbcQueryWithParam2(LocationWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_TABLE_NAME)
        elif(SOURCE_ETRM == 'NUCLEUS'):
          SOURCE_TABLE_NAME = 'CUSTODY_TRANSFER_POINTS'
          executePyOdbcQueryWithParam2(LocationWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_TABLE_NAME)
        elif(SOURCE_ETRM == 'ALIGNE'):
          print("Data load completed]") 
        #executePyOdbcQueryWithParam2(LocationWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_TABLE_NAME)
        
        print('data load completed')
        
        status = validateUniqueLocation(SOURCE_ETRM)
        if status != "SUCCESS":
          print("Uniqueness validation ....")
          raise Exception("UNIQUENESS_TEST_FAILED")
        
        print("starting duplicate SK check")
        status = validateDuplicateLocationSK(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
          
        status = validateIfNullLogicLocation(SOURCE_ETRM)
        if status != "SUCCESS":
          print("IF NULL LOGIC has failed")
          warnings.warn("Warning : IF NULL LOGIC has failed")
        
        return ("SUCCESS", metricDict)

