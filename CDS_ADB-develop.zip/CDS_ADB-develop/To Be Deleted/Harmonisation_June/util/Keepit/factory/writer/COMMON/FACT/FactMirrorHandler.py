# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

def pointCurrentDBFactViewToMirror2():
  HEADER_VIEW_DELETE_SQL = """
  drop view tsa_consumption.fact_deal_header_view
  """
  HEADER_VIEW_CREATE_SQL = """
  create view tsa_consumption.fact_deal_header_view as select * from tsa_curated.fact_deal_header_mirror2
  """
  LEG_VIEW_DELETE_SQL = """
  drop view tsa_consumption.fact_deal_leg_view
  """
  LEG_VIEW_CREATE_SQL = """
  create view tsa_consumption.fact_deal_leg_view as select * from tsa_curated.fact_deal_leg_mirror2
  """
  SUBLEG_VIEW_DELETE_SQL = """
  drop view tsa_consumption.fact_deal_sub_leg_view
  """
  SUBLEG_VIEW_CREATE_SQL = """
  create view tsa_consumption.fact_deal_sub_leg_view as select * from tsa_curated.fact_deal_sub_leg_mirror2
  """
  
  executePyOdbcQueryDDL(HEADER_VIEW_DELETE_SQL)
  executePyOdbcQueryDDL(HEADER_VIEW_CREATE_SQL)
  executePyOdbcQueryDDL(LEG_VIEW_DELETE_SQL)
  executePyOdbcQueryDDL(LEG_VIEW_CREATE_SQL)
  executePyOdbcQueryDDL(SUBLEG_VIEW_DELETE_SQL)
  executePyOdbcQueryDDL(SUBLEG_VIEW_CREATE_SQL)
  

# COMMAND ----------

def pointCurrentDBFactViewToMirror1():
  HEADER_VIEW_DELETE_SQL = """
  drop view tsa_consumption.fact_deal_header_view
  """
  HEADER_VIEW_CREATE_SQL = """
  create view tsa_consumption.fact_deal_header_view as select * from tsa_curated.fact_deal_header_mirror1
  """
  LEG_VIEW_DELETE_SQL = """
  drop view tsa_consumption.fact_deal_leg_view
  """
  LEG_VIEW_CREATE_SQL = """
  create view tsa_consumption.fact_deal_leg_view as select * from tsa_curated.fact_deal_leg_mirror1
  """
  SUBLEG_VIEW_DELETE_SQL = """
  drop view tsa_consumption.fact_deal_sub_leg_view
  """
  SUBLEG_VIEW_CREATE_SQL = """
  create view tsa_consumption.fact_deal_sub_leg_view as select * from tsa_curated.fact_deal_sub_leg_mirror1
  """
  
  executePyOdbcQueryDDL(HEADER_VIEW_DELETE_SQL)
  executePyOdbcQueryDDL(HEADER_VIEW_CREATE_SQL)
  executePyOdbcQueryDDL(LEG_VIEW_DELETE_SQL)
  executePyOdbcQueryDDL(LEG_VIEW_CREATE_SQL)
  executePyOdbcQueryDDL(SUBLEG_VIEW_DELETE_SQL)
  executePyOdbcQueryDDL(SUBLEG_VIEW_CREATE_SQL)
  

# COMMAND ----------

def updateMetadataForCurrentMirror(MIRROR):
  UPDATE_CURRENT_MIRROR_SQL = """
  update tsa_curated.CURRENT_FACT_MIRROR set current_mirror = ?
  """
  executePyOdbcQueryWithParam1(UPDATE_CURRENT_MIRROR_SQL,MIRROR)
  

# COMMAND ----------

def getCurrentFactMirrorFromMetadata():
  
  query = "select current_mirror from tsa_curated.CURRENT_FACT_MIRROR"
  
  df = jdbcReaderQuery(spark,query)
  current_mirror = df.select('current_mirror').collect()[0][0]
  
  return current_mirror

# COMMAND ----------

def replaceTableToken(SQL_TXT, write_to_mirror_table):
    SQL_TXT = SQL_TXT.replace("FACT_TABLE_TOKEN",write_to_mirror_table)
    return SQL_TXT
