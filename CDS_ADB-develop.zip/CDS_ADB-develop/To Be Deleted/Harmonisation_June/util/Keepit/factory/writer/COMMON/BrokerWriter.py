# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../DatasetWriter

# COMMAND ----------

# MAGIC %run ./VALIDATOR/pre_validator/duplicate/BrokerDuplicatePreValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/duplicate/BrokerDuplicatePostValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/UNIQUENESS/BrokerUniquenessPostValidator

# COMMAND ----------

class BrokerWriter(DatasetWriter):
    DELETE_DIM_BROKER_STAGE_SQL = """DELETE from tsa_stage.dim_broker_stage WHERE src_sys_name = ?"""
    INSERT_DIM_BROKER_SQL = """
    INSERT INTO tsa_curated.dim_broker
    (
    broker_ck,
    record_created_dttm,
    record_updated_dttm,
    src_sys_name,
    src_sys_broker_nk,
    broker_name,
    active_broker_flag
    )
    SELECT broker_ck,
    current_timestamp record_created_dttm,
    current_timestamp record_updated_dttm,
    src_sys_name,
    src_sys_broker_nk,
    broker_name,
    active_broker_flag 
    FROM tsa_stage.dim_broker_stage stage
    WHERE NOT EXISTS
    (SELECT 1 
    FROM tsa_curated.dim_broker main 
    WHERE main.broker_ck = stage.broker_ck ) and stage.SRC_SYS_NAME = ?
    """
    
    UPDATE_DIM_BROKER_SQL = """UPDATE main_table 
    SET main_table.broker_name =stage_table.broker_name,
    main_table.active_broker_flag =stage_table.active_broker_flag,
    record_updated_dttm = current_timestamp
    FROM tsa_curated.dim_broker main_table
    JOIN tsa_stage.dim_broker_stage stage_table
    ON main_table.broker_ck = stage_table.broker_ck and stage_table.SRC_SYS_NAME = ? """
    
    UPDATE_WATERMARK_SQL = """
    UPDATE tsa_curated.watermark SET last_offset_value =
    (
    SELECT CONVERT(varchar(20), max(source_last_update), 120)   
    FROM tsa_curated.dim_broker main_table,tsa_stage.dim_broker_stage stage_table 
    WHERE main_table.broker_ck = stage_table.broker_ck
    ) 
    WHERE source_name = ?
    and source_table_name = ?
    and table_name = 'DIM_BROKER' 
    """
    
    def write(df, SOURCE_ETRM, metricDict):
        import time
        print('deleting stage records')
        executePyOdbcQueryWithParam1(BrokerWriter.DELETE_DIM_BROKER_STAGE_SQL,SOURCE_ETRM)
        
        start = time.time()
        df.printSchema()
        df = df.withColumn("SRC_SYS_BROKER_NK",df.SRC_SYS_BROKER_NK.cast('string'))
        df = df.withColumn("ACTIVE_BROKER_FLAG",df.ACTIVE_BROKER_FLAG.cast('string'))
        
        df = df.withColumn("SOURCE_LAST_UPDATE",df.SOURCE_LAST_UPDATE.cast('timestamp'))      
        
        df = df.select(
          col("BROKER_CK"),
          col("RECORD_CREATED_DTTM"),
          col("SRC_SYS_NAME"),
          col("SRC_SYS_BROKER_NK"),
          col("BROKER_NAME"),
          col("ACTIVE_BROKER_FLAG"),
          col("SOURCE_LAST_UPDATE")          
          )
        print("writing to stage table")
        writeDatasetSynapseConnector(spark, df,"tsa_stage.dim_broker_stage")
        end = time.time()
        time_taken = end - start
        metricDict["broker_writer_stage_load_time_taken_in_sec"] = time_taken 
        
        status = validateDuplicateBroker(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
        
        start = time.time()
        print('updating existing records')
        row_affected = executePyOdbcQueryWithParam1(BrokerWriter.UPDATE_DIM_BROKER_SQL,SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["broker_writer_update_sql_time_taken_in_sec"] = time_taken 
        metricDict["update_sql_rows_affected"] = row_affected 
        
        start = time.time()
        print('inserting new records')
        row_affected = executePyOdbcQueryWithParam1(BrokerWriter.INSERT_DIM_BROKER_SQL,SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["broker_writer_insert_sql_time_taken_in_sec"] = time_taken 
        metricDict["insert_sql_rows_affected"] = row_affected 
        
        if(SOURCE_ETRM == 'DEX'):
          SOURCE_TABLE_NAME = 'STO_CHRGACCT'          
          executePyOdbcQueryWithParam2(BrokerWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_TABLE_NAME)
        elif(SOURCE_ETRM == 'ENDUR_GPNA'):
          SOURCE_TABLE_NAME = 'PARTY'          
          executePyOdbcQueryWithParam2(BrokerWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_TABLE_NAME)
        elif(SOURCE_ETRM == 'ENDUR_SLMT'):
          SOURCE_TABLE_NAME = 'PARTY'          
          executePyOdbcQueryWithParam2(BrokerWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_TABLE_NAME)
        elif(SOURCE_ETRM == 'NUCLEUS' or SOURCE_ETRM == 'ALIGNE') :
          print('data load completed')
        
        status = validateUniqueBroker(SOURCE_ETRM)
        if status != "SUCCESS":
          print("Uniqueness validation ....")
          raise Exception("UNIQUENESS_TEST_FAILED")
         
        print("Starting SK Duplicate check")
        status = validateDuplicateBrokerSK(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
        
        return ("SUCCESS",metricDict)

