# Databricks notebook source
# MAGIC %run ./UniquenessCheckUtil

# COMMAND ----------

def validateUniqueParty(SOURCE_ETRM):
  
  SQL = """
  select party_check.*,
		case when party_sk_count = party_ck_count
		and 
		party_ck_count=record_count
		THEN 'UNIQUESNESS TEST PASSED'
		ELSE 'UNIQUESNESS TEST FAILED' END AS TEST_STATUS
	FROM ( SELECT count(distinct party_sk) as party_sk_count,
					count(distinct party_ck) as party_ck_count,
					count(1) as record_count,
					current_timestamp as SQL_EXEC_DATETIME
				FROM [tsa_curated].[DIM_PARTY]
				where src_sys_name = '{0}'
		)party_check
  """.format(SOURCE_ETRM)
  
  status = runSQLandCheckUniqueness(SQL)
  return status
