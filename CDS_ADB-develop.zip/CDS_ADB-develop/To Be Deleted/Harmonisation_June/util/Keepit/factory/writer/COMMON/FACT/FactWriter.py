# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../../DatasetWriter

# COMMAND ----------

# MAGIC %run ./FactHeaderWriter

# COMMAND ----------

# MAGIC %run ./FactLegWriter

# COMMAND ----------

# MAGIC %run ./../VALIDATOR/pre_validator/OrphanCheck/FactLegOrphanCheckPreValidator

# COMMAND ----------

# MAGIC %run ./FactSublegWriter

# COMMAND ----------

# MAGIC %run ./FactMirrorHandler

# COMMAND ----------

class FactWriter(DatasetWriter):
     
    def write(dfFactHeader,dfFactLeg, dfFactSubLeg, SOURCE_ETRM, metricDict, watermarkUpdater):
        
        
        dfFactHeader = dfFactHeader.select(col("SRC_SYS_NAME"),
                  col("DEAL_ATTRIBUTES_CK"),
                  col("EXECUTION_DATE_CK"),
                  col("TRADE_CREATION_DATE_CK"),
                  col("COUNTERPARTY_CK"),
                  col("SHELL_TRADING_PARTY_CK"),
                  col("TRADER_CK"),
                  col("DEAL_BROKER_CK"),
                  col("UNIT_OF_MEASURE_CK"),
                  col("CONTRACT_QTY"),
                  col("DEAL_HEADER_MULTIPLIER"),
                  col("record_created_dttm"),
                  col("source_last_date1"),
                  col("source_last_date2"),
                  col("source_last_date3")                         
                 )
        
        dfFactLeg = dfFactLeg.select(
                  col("SRC_SYS_NAME"),
                  col("DEAL_ATTRIBUTES_CK"),
                  col("EXECUTION_DATE_CK"),
                  col("TRADE_CREATION_DATE_CK"),
                  col("COMMITMENT_DATE_CK"),
                  col("COUNTERPARTY_CK"),
                  col("SHELL_TRADING_PARTY_CK"),
                  col("TRADER_CK"),
                  col("DEAL_BROKER_CK"),
                  col("COMMODITY_CK"),
                  col("UNIT_OF_MEASURE_CK"),
                  col("COMMITMENT_QTY"),
                  col("COMMODITY_COMMITMENT_QTY"),
                  col("DEAL_LEG_MULTIPLIER"),
                  col("record_created_dttm"),
                  col("source_last_date1"),
                  col("source_last_date2"),
                  col("source_last_date3"),
                  col("SRC_SYS_DEAL_HEADER_KEY") 
                 )
        
        dfFactSubLeg = dfFactSubLeg.select(col("SRC_SYS_NAME"),
                  col("DEAL_ATTRIBUTES_CK"),
                  col("EXECUTION_DATE_CK"),
                  col("TRADE_CREATION_DATE_CK"),
                  col("COMMITMENT_DATE_CK"),
                  col("PARCEL_DATE_CK"),                    
                  col("COUNTERPARTY_CK"),
                  col("SHELL_TRADING_PARTY_CK"),
                  col("TRADER_CK"),
                  col("DEAL_BROKER_CK"),
                  col("COMMODITY_CK"),                         
                  col("LOADING_LOCATION_CK"),
                  col("DISCHARGE_LOCATION_CK"),
                  col("DELIVERY_START_DATE_CK"),
                  col("DELIVERY_END_DATE_CK"),
                  col("DEAL_UNIT_OF_MEASURE_CK"),
                  col("PRICING_UNIT_OF_MEASURE_CK"),
                  col("DEAL_CCY_CK"),
                  col("CCY_DEAL_VALUE"),
                  col("GBP_DEAL_VALUE"),
                  col("USD_DEAL_VALUE"),
                  col("EUR_DEAL_VALUE"),
                  col("DEAL_QTY"),
                  col("PRICE_QTY"),
                  col("CMD_DEAL_QTY"),
                  col("DEAL_SUB_LEG_MULTIPLIER"),
                  col("record_created_dttm"),
                  col("source_last_date1"),
                  col("source_last_date2"),
                  col("source_last_date3"),
                  col("SRC_SYS_DEAL_HEADER_KEY")
                 )
        
        current_mirror = getCurrentFactMirrorFromMetadata()
      
        
        if current_mirror == "MIRROR1":
          write_to_mirror_header = "tsa_curated.fact_deal_header_mirror2"
          write_to_mirror_leg = "tsa_curated.fact_deal_leg_mirror2"
          write_to_mirror_sub_leg = "tsa_curated.fact_deal_sub_leg_mirror2"
        
        if current_mirror == "MIRROR2":
          write_to_mirror_header = "tsa_curated.fact_deal_header_mirror1"
          write_to_mirror_leg = "tsa_curated.fact_deal_leg_mirror1"
          write_to_mirror_sub_leg = "tsa_curated.fact_deal_sub_leg_mirror1"
        
          
        
        metricDict = FactHeaderWriter.write(dfFactHeader, SOURCE_ETRM, write_to_mirror_header, metricDict)
        #orphan_status = validateOrphanFactLeg(SOURCE_ETRM)
        #if orphan_status != "SUCCESS":
         # print("Orphan Check validation ....")
          #raise Exception("ORPHAN_HEADER_RECORDS_FOUND_LEG")
        metricDict = FactLegWriter.write(dfFactLeg, SOURCE_ETRM, write_to_mirror_leg, metricDict)
        #if orphan_status != "SUCCESS":
         # print("Orphan Check validation ....")
          #raise Exception("ORPHAN_HEADER_RECORDS_FOUND_SUB_LEG")
        metricDict = FactSublegWriter.write(dfFactSubLeg, SOURCE_ETRM, write_to_mirror_sub_leg, metricDict)
        
        if current_mirror == "MIRROR1":
          
          pointCurrentDBFactViewToMirror2()
        if current_mirror == "MIRROR2":
          
          pointCurrentDBFactViewToMirror1()
        
        if current_mirror == "MIRROR1":
          write_to_mirror_header = "tsa_curated.fact_deal_header_mirror1"
          write_to_mirror_leg = "tsa_curated.fact_deal_leg_mirror1"
          write_to_mirror_sub_leg = "tsa_curated.fact_deal_sub_leg_mirror1"
        
        if current_mirror == "MIRROR2":
          write_to_mirror_header = "tsa_curated.fact_deal_header_mirror2"
          write_to_mirror_leg = "tsa_curated.fact_deal_leg_mirror2"
          write_to_mirror_sub_leg = "tsa_curated.fact_deal_sub_leg_mirror2"
        
        
        metricDict = postProcessWriteToCurrentMirrorHeader(SOURCE_ETRM, write_to_mirror_header, metricDict)
        #orphan_status = validateOrphanFactLeg(SOURCE_ETRM)
        #if orphan_status != "SUCCESS":
          ##print("Orphan Check validation ....")
          #raise Exception("ORPHAN_HEADER_RECORDS_FOUND_LEG")
        metricDict = postProcessWriteToCurrentMirrorLeg( SOURCE_ETRM, write_to_mirror_leg, metricDict)
        ##if orphan_status != "SUCCESS":
          #print("Orphan Check validation ....")
          #raise Exception("ORPHAN_HEADER_RECORDS_FOUND_SUB_LEG")
        metricDict = postProcessWriteToCurrentMirrorSubleg(SOURCE_ETRM, write_to_mirror_sub_leg, metricDict)
        
        if current_mirror == "MIRROR1":
          update_mirror_to = "MIRROR2"
        if current_mirror == "MIRROR2":
          update_mirror_to = "MIRROR1"
        
      
        
        updateMetadataForCurrentMirror(update_mirror_to)
        
        watermarkUpdater.updateWatermarkForHeader(write_to_mirror_header)
        watermarkUpdater.updateWatermarkForLeg(write_to_mirror_leg)
        watermarkUpdater.updateWatermarkForSubleg(write_to_mirror_sub_leg)
        
        
        
        return ("SUCCESS", metricDict)


# COMMAND ----------

  def writeAfterDealAttrSCD(SOURCE_ETRM, metricDict):
        current_mirror = getCurrentFactMirrorFromMetadata()
      
        
        if current_mirror == "MIRROR1":
          write_to_mirror_header = "tsa_curated.fact_deal_header_mirror2"
          write_to_mirror_leg = "tsa_curated.fact_deal_leg_mirror2"
          write_to_mirror_sub_leg = "tsa_curated.fact_deal_sub_leg_mirror2"
        
        if current_mirror == "MIRROR2":
          write_to_mirror_header = "tsa_curated.fact_deal_header_mirror1"
          write_to_mirror_leg = "tsa_curated.fact_deal_leg_mirror1"
          write_to_mirror_sub_leg = "tsa_curated.fact_deal_sub_leg_mirror1"
        
          
        
        metricDict = writeAfterDealAttrSCDFactHeader(SOURCE_ETRM, write_to_mirror_header, metricDict)
        metricDict = writeAfterDealAttrSCDFactLeg(SOURCE_ETRM, write_to_mirror_leg, metricDict)
        metricDict = writeAfterDealAttrSCDFactSubleg(SOURCE_ETRM, write_to_mirror_sub_leg, metricDict)
        
        if current_mirror == "MIRROR1":
          
          pointCurrentDBFactViewToMirror2()
        if current_mirror == "MIRROR2":
          
          pointCurrentDBFactViewToMirror1()
        
        if current_mirror == "MIRROR1":
          write_to_mirror_header = "tsa_curated.fact_deal_header_mirror1"
          write_to_mirror_leg = "tsa_curated.fact_deal_leg_mirror1"
          write_to_mirror_sub_leg = "tsa_curated.fact_deal_sub_leg_mirror1"
        
        if current_mirror == "MIRROR2":
          write_to_mirror_header = "tsa_curated.fact_deal_header_mirror2"
          write_to_mirror_leg = "tsa_curated.fact_deal_leg_mirror2"
          write_to_mirror_sub_leg = "tsa_curated.fact_deal_sub_leg_mirror2"
        
        
        metricDict = writeAfterDealAttrSCDFactHeader(SOURCE_ETRM, write_to_mirror_header, metricDict)
        metricDict = writeAfterDealAttrSCDFactLeg(SOURCE_ETRM, write_to_mirror_leg, metricDict)
        metricDict = writeAfterDealAttrSCDFactSubleg(SOURCE_ETRM, write_to_mirror_sub_leg, metricDict)
        
        if current_mirror == "MIRROR1":
          update_mirror_to = "MIRROR2"
        if current_mirror == "MIRROR2":
          update_mirror_to = "MIRROR1"
        
      
        
        updateMetadataForCurrentMirror(update_mirror_to)
        
        return metricDict
