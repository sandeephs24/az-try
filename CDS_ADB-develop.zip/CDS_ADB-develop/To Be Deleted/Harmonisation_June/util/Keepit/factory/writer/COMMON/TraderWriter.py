# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../DatasetWriter

# COMMAND ----------

# MAGIC %run ./VALIDATOR/pre_validator/duplicate/TraderDuplicatePreValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/duplicate/TraderDuplicatePostValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/UNIQUENESS/TraderUniquenessPostValidator

# COMMAND ----------

class TraderWriter(DatasetWriter):
    DELETE_DIM_TRADER_STAGE_SQL = """DELETE from tsa_stage.dim_trader_stage where src_sys_name = ?"""
    INSERT_DIM_TRADER_SQL = """
    INSERT INTO tsa_curated.dim_trader
    (
    trader_ck,
    record_created_dttm,
    record_updated_dttm,
    src_sys_name,
    src_sys_trader_nk,
    trader_name,
    trader_first_name,
    trader_last_name
    )
    SELECT trader_ck,
    current_timestamp record_created_dttm,
    current_timestamp record_updated_dttm,
    src_sys_name src_sys_name,
    src_sys_trader_nk,
    trader_name,
    trader_first_name,
    trader_last_name
    FROM tsa_stage.dim_trader_stage stage
    WHERE NOT EXISTS
    (SELECT 1 
    FROM tsa_curated.dim_trader main 
    WHERE main.trader_ck = stage.trader_ck ) and stage.SRC_SYS_NAME = ?
    """
    
    UPDATE_DIM_TRADER_SQL = """UPDATE main_table 
    SET main_table.trader_name =stage_table.trader_name,
    main_table.trader_first_name =stage_table.trader_first_name,
    main_table.trader_last_name =stage_table.trader_last_name,
    record_updated_dttm = current_timestamp
    FROM tsa_curated.dim_trader main_table
    JOIN tsa_stage.dim_trader_stage stage_table
    ON main_table.trader_ck = stage_table.trader_ck
    and stage_table.SRC_SYS_NAME = ? """
    
    UPDATE_WATERMARK_SQL = """
    UPDATE tsa_curated.watermark SET last_offset_value =
    (
    SELECT CONVERT(varchar(20), max(source_last_update), 120)
    FROM tsa_curated.dim_trader main_table,tsa_stage.dim_trader_stage stage_table 
    WHERE main_table.trader_ck = stage_table.trader_ck
    ) 
    WHERE source_name = ?
    and source_table_name = ?
    and table_name = 'DIM_TRADER' 
    """
    
    def write(df,SOURCE_ETRM, metricDict):
        print('deleting stage records')
        executePyOdbcQueryWithParam1(TraderWriter.DELETE_DIM_TRADER_STAGE_SQL,SOURCE_ETRM)
        start = time.time()
           
        df = df.withColumn("SRC_SYS_TRADER_NK",df.SRC_SYS_TRADER_NK.cast('string'))        
        df = df.select(
          col("TRADER_CK"),
          col("RECORD_CREATED_DTTM"),
          col("SRC_SYS_NAME"),
          col("SRC_SYS_TRADER_NK"),
          col("TRADER_NAME"),
          col("TRADER_FIRST_NAME"),
          col("TRADER_LAST_NAME"),
          col("SOURCE_LAST_UPDATE")
          )
        print("writing to stage table")    
        writeDatasetSynapseConnector(spark, df,"tsa_stage.dim_trader_stage")
        
        end = time.time()
        time_taken = end - start
        metricDict["trader_writer_stage_load_time_taken_in_sec"] = time_taken 
        
        status = validateDuplicateTrader(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
        
        start = time.time() 
        print('updating existing records')
        row_affected = executePyOdbcQueryWithParam1(TraderWriter.UPDATE_DIM_TRADER_SQL,SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["trader_writer_update_sql_time_taken_in_sec"] = time_taken 
        metricDict["update_sql_rows_affected"] = row_affected
        
        start = time.time()
        print('inserting new records')
        row_affected = executePyOdbcQueryWithParam1(TraderWriter.INSERT_DIM_TRADER_SQL,SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["trader_writer_insert_sql_time_taken_in_sec"] = time_taken 
        metricDict["insert_sql_rows_affected"] = row_affected
        
        if(SOURCE_ETRM == 'DEX'):
          SOURCE_TABLE_NAME = 'STO_USR'
          executePyOdbcQueryWithParam2(TraderWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_TABLE_NAME)
        elif(SOURCE_ETRM == 'ENDUR_GPNA'):
          SOURCE_TABLE_NAME = 'PERSONNEL'
          executePyOdbcQueryWithParam2(TraderWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_TABLE_NAME)
        elif(SOURCE_ETRM == 'ENDUR_SLMT'):
          SOURCE_TABLE_NAME = 'PERSONNEL'
          executePyOdbcQueryWithParam2(TraderWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_TABLE_NAME)      
        elif (SOURCE_ETRM == 'NUCLEUS' or SOURCE_ETRM == 'ALIGNE') :
          print('Data loaded')
        
        print('data load completed')
        
        status = validateUniqueTrader(SOURCE_ETRM)
        if status != "SUCCESS":
          print("Uniqueness validation ....")
          raise Exception("UNIQUENESS_TEST_FAILED")
        
        print("starting duplicate SK check")
        status = validateDuplicateTraderSK(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
        
        return ("SUCCESS", metricDict)

