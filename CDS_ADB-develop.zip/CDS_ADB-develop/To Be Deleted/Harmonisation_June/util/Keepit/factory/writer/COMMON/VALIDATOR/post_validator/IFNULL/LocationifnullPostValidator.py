# Databricks notebook source
# MAGIC %run ./IfNullLogicCheckUtil

# COMMAND ----------

def validateIfNullLogicLocation(SOURCE_ETRM):
  
  SQL = """
  SELECT     CASE WHEN [LOCATION_ISO_COUNTRY_CODE] = [LOCATION_COUNTRY_NAME] OR
            [LOCATION_ISO_COUNTRY_CODE] = [HIGH_RISK_COUNTRY_FLAG] OR
            [LOCATION_ISO_COUNTRY_CODE] = [EDD_COUNTRY_FLAG] OR
            [LOCATION_ISO_COUNTRY_CODE] = [GEC_COUNTRY_FLAG] 
            THEN 'IFNULL TEST PASSED'
            ELSE 'IFNULL TEST FAILED' END AS TEST_STATUS
            FROM (
            select		[SRC_SYS_NAME]
			,[LOCATION_ISO_COUNTRY_CODE]
			,[LOCATION_COUNTRY_NAME]
			,[HIGH_RISK_COUNTRY_FLAG]
			,[EDD_COUNTRY_FLAG]
			,[GEC_COUNTRY_FLAG]
			,COUNT(1) AS RECORD_COUNT
          from		[tsa_curated].[DIM_LOCATION]
          where	[SRC_SYS_NAME] = '{0}'
          and	(LEN(NULLIF([LOCATION_ISO_COUNTRY_CODE],'')) != 2
           or [LOCATION_ISO_COUNTRY_CODE] is null)
          group by	[SRC_SYS_NAME]
			,[LOCATION_ISO_COUNTRY_CODE]
			,[LOCATION_COUNTRY_NAME]
			,[HIGH_RISK_COUNTRY_FLAG]
			,[EDD_COUNTRY_FLAG]
			,[GEC_COUNTRY_FLAG]
     )ifnullcheck
     union 
		select 'NA' as TEST_STATUS where not exists( select *
		from		[tsa_curated].[DIM_LOCATION]
          where	(LEN(NULLIF([LOCATION_ISO_COUNTRY_CODE],'')) != 2
           or [LOCATION_ISO_COUNTRY_CODE] is null)     
        and [SRC_SYS_NAME] ='{1}' )
  """.format(SOURCE_ETRM,SOURCE_ETRM)
  
  status = runSQLandCheckIfNull(SQL)
  return status
