# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../DatasetWriter

# COMMAND ----------

# MAGIC %run ./UTIL/DealAttributesStageWriter

# COMMAND ----------

# MAGIC %run ./VALIDATOR/pre_validator/duplicate/DealAttributesDuplicatePreValidator

# COMMAND ----------

# MAGIC %run ./FACT/FactWriter

# COMMAND ----------

class DealAttributesWriter(DatasetWriter):
    
    
    INSERT_DIM_DEAL_ATTRIBUTES_SUBLEG_SQL = """ 
    WITH new_sub_leg_records_view as(
    SELECT DISTINCT SRC_SYS_DEAL_SUB_LEG_KEY
    FROM tsa_stage.dim_deal_attributes_stage stage
    WHERE 
    stage.SRC_SYS_DEAL_SUB_LEG_KEY is not null
    and stage.SRC_SYS_DEAL_SUB_LEG_KEY <> '' 
    and src_sys_name = ?
    and NOT EXISTS
    (SELECT 1
    FROM tsa_curated.dim_deal_attributes main 
    WHERE main.SRC_SYS_DEAL_SUB_LEG_KEY = stage.SRC_SYS_DEAL_SUB_LEG_KEY)
    )
    INSERT INTO tsa_curated.dim_deal_attributes
    (
    deal_attributes_ck,
    record_created_dttm,
    record_updated_dttm,
    src_sys_name,
    SRC_SYS_DEAL_HEADER_KEY,
    SRC_SYS_DEAL_LEG_KEY,
    SRC_SYS_DEAL_SUB_LEG_KEY,
    SRC_SYSTEM_DEAL_TYPE_CODE,
    SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    DEAL_HEADER_BUY_SELL_FLAG,
    DEAL_INSTRUMENT_CLASSIFICATION,
    DEAL_SPOT_TERM_IND,
    DEAL_AGREEMENT_TYPE_DESCRIPTION,
    HEADER_DEAL_STATUS,
    PARENT_CONTRACT_NUMBER,
    CONTRACT_NUMBER,
    DEAL_BOOK_NAME,
    DEAL_LEG_REFERENCE,
    DEAL_LEG_BUY_SELL_FLAG,
    SUB_LEG_DEAL_STATUS,
    DEAL_EXECUTION_TIMESTAMP,
    DEAL_PRICE,
    PRICING_TYPE,
    PRICING_COMPONENT,
    PREMIUM_FLOAT_SPREAD,
    INDEX_FACTOR,
    PRICING_STATUS,
    PRICE_SETTLE_DATE,
    DEAL_SUB_LEG_REFERENCE,
    SETTLEMENT_TYPE,
    DEAL_LINE_TEXT,
    CALL_PUT_FLAG,
    OPTION_STRIKE_PRICE,
    OPTION_PREMIUM_PRICE,
    VESSEL_NAME,
    DELIVERY_JUNCTION_NAME,
    DELIVERY_METHOD_NAME,
    BILL_OF_LADING_DATE,
    VALID_FROM_DATE,
    VALID_TO_DATE
    )
    SELECT  deal_attributes_ck,
    current_timestamp record_created_dttm,
    current_timestamp record_updated_dttm,
    src_sys_name,
    SRC_SYS_DEAL_HEADER_KEY,
    SRC_SYS_DEAL_LEG_KEY,
    SRC_SYS_DEAL_SUB_LEG_KEY,
    SRC_SYSTEM_DEAL_TYPE_CODE,
    SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    DEAL_HEADER_BUY_SELL_FLAG,
    DEAL_INSTRUMENT_CLASSIFICATION,
    DEAL_SPOT_TERM_IND,
    DEAL_AGREEMENT_TYPE_DESCRIPTION,
    HEADER_DEAL_STATUS,
    PARENT_CONTRACT_NUMBER,
    CONTRACT_NUMBER,
    DEAL_BOOK_NAME,
    DEAL_LEG_REFERENCE,
    DEAL_LEG_BUY_SELL_FLAG,
    SUB_LEG_DEAL_STATUS,
    DEAL_EXECUTION_TIMESTAMP,
    DEAL_PRICE,
    PRICING_TYPE,
    PRICING_COMPONENT,
    PREMIUM_FLOAT_SPREAD,
    INDEX_FACTOR,
    PRICING_STATUS,
    PRICE_SETTLE_DATE,
    DEAL_SUB_LEG_REFERENCE,
    SETTLEMENT_TYPE,
    DEAL_LINE_TEXT,
    CALL_PUT_FLAG,
    OPTION_STRIKE_PRICE,
    OPTION_PREMIUM_PRICE,
    VESSEL_NAME,
    DELIVERY_JUNCTION_NAME,
    DELIVERY_METHOD_NAME,
    BILL_OF_LADING_DATE,
    current_timestamp VALID_FROM_DATE,
    '9999-12-31 00:00:00' VALID_TO_DATE
    FROM tsa_stage.dim_deal_attributes_stage stage
    WHERE (SRC_SYS_DEAL_SUB_LEG_KEY is not null and SRC_SYS_DEAL_SUB_LEG_KEY <> '') and 
    SRC_SYS_DEAL_SUB_LEG_KEY in
    (select SRC_SYS_DEAL_SUB_LEG_KEY 
    from new_sub_leg_records_view)
    and src_sys_name = ?
    """
    
    INSERT_DIM_DEAL_ATTRIBUTES_LEG_SQL = """
    WITH new_leg_records_view as(
    SELECT DISTINCT SRC_SYS_DEAL_LEG_KEY
    FROM tsa_stage.dim_deal_attributes_stage stage
    WHERE stage.SRC_SYS_DEAL_LEG_KEY is not null
    and stage.SRC_SYS_DEAL_LEG_KEY <> ''
    and src_sys_name = ?
    and NOT EXISTS
    (SELECT 1
    FROM tsa_curated.dim_deal_attributes main 
    WHERE main.SRC_SYS_DEAL_LEG_KEY = stage.SRC_SYS_DEAL_LEG_KEY)
    )
    INSERT INTO tsa_curated.dim_deal_attributes
    (
    deal_attributes_ck,
    record_created_dttm,
    record_updated_dttm,
    src_sys_name,
    SRC_SYS_DEAL_HEADER_KEY,
    SRC_SYS_DEAL_LEG_KEY,
    SRC_SYSTEM_DEAL_TYPE_CODE,
    SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    DEAL_HEADER_BUY_SELL_FLAG,
    DEAL_INSTRUMENT_CLASSIFICATION,
    DEAL_SPOT_TERM_IND,
    DEAL_AGREEMENT_TYPE_DESCRIPTION,
    HEADER_DEAL_STATUS,
    PARENT_CONTRACT_NUMBER,
    CONTRACT_NUMBER,
    DEAL_BOOK_NAME,
    DEAL_LEG_REFERENCE,
    DEAL_LEG_BUY_SELL_FLAG,
    SUB_LEG_DEAL_STATUS,
    PRICING_TYPE,
    PRICING_COMPONENT,
    PRICING_STATUS,
    DEAL_SUB_LEG_REFERENCE,
    SETTLEMENT_TYPE,
    DEAL_LINE_TEXT,
    CALL_PUT_FLAG,
    VESSEL_NAME,
    DELIVERY_JUNCTION_NAME,
    DELIVERY_METHOD_NAME,
    BILL_OF_LADING_DATE,
    VALID_FROM_DATE,
    VALID_TO_DATE
    )
    SELECT  
    deal_attributes_ck,
    current_timestamp record_created_dttm,
    current_timestamp record_updated_dttm,
    src_sys_name,
    SRC_SYS_DEAL_HEADER_KEY,
    SRC_SYS_DEAL_LEG_KEY,
    SRC_SYSTEM_DEAL_TYPE_CODE,
    SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    DEAL_HEADER_BUY_SELL_FLAG,
    DEAL_INSTRUMENT_CLASSIFICATION,
    DEAL_SPOT_TERM_IND,
    DEAL_AGREEMENT_TYPE_DESCRIPTION,
    HEADER_DEAL_STATUS,
    PARENT_CONTRACT_NUMBER,
    CONTRACT_NUMBER,
    DEAL_BOOK_NAME,
    DEAL_LEG_REFERENCE,
    DEAL_LEG_BUY_SELL_FLAG,
    'NOT APPLICABLE' AS SUB_LEG_DEAL_STATUS,
    'NOT APPLICABLE' AS PRICING_TYPE,
    'NOT APPLICABLE' AS PRICING_COMPONENT,
    'NOT APPLICABLE' AS PRICING_STATUS,
    'NOT APPLICABLE' AS DEAL_SUB_LEG_REFERENCE,
    'NOT APPLICABLE' AS SETTLEMENT_TYPE,
    'NOT APPLICABLE' AS DEAL_LINE_TEXT,
    'NOT APPLICABLE' AS CALL_PUT_FLAG,
    'NOT APPLICABLE' AS VESSEL_NAME,
    'NOT APPLICABLE' AS DELIVERY_JUNCTION_NAME,
    'NOT APPLICABLE' AS DELIVERY_METHOD_NAME,
    ''               as BILL_OF_LADING_DATE,
    current_timestamp VALID_FROM_DATE,
    '9999-12-31 00:00:00' VALID_TO_DATE
    FROM(
      select * from tsa_stage.dim_deal_attributes_stage where 
      (SRC_SYS_DEAL_LEG_KEY is not null and SRC_SYS_DEAL_LEG_KEY <> '')
      and (SRC_SYS_DEAL_SUB_LEG_KEY is null or SRC_SYS_DEAL_SUB_LEG_KEY = '')
      and SRC_SYS_DEAL_LEG_KEY in 
      (select SRC_SYS_DEAL_LEG_KEY from new_leg_records_view)
      and src_sys_name = ?
    ) A
    """
    
    INSERT_DIM_DEAL_ATTRIBUTES_HEADER_SQL = """
    WITH new_header_records_view as(
    SELECT DISTINCT SRC_SYS_DEAL_HEADER_KEY
    FROM tsa_stage.dim_deal_attributes_stage stage
    WHERE 
    src_sys_name = ? and
    NOT EXISTS
    (SELECT 1
    FROM tsa_curated.dim_deal_attributes main 
    WHERE main.SRC_SYS_DEAL_HEADER_KEY = stage.SRC_SYS_DEAL_HEADER_KEY)
    )
    INSERT INTO tsa_curated.dim_deal_attributes
    (
    deal_attributes_ck,
    record_created_dttm,
    record_updated_dttm,
    src_sys_name,
    SRC_SYS_DEAL_HEADER_KEY,
    SRC_SYSTEM_DEAL_TYPE_CODE,
    SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    DEAL_HEADER_BUY_SELL_FLAG,
    DEAL_INSTRUMENT_CLASSIFICATION,
    DEAL_SPOT_TERM_IND,
    DEAL_AGREEMENT_TYPE_DESCRIPTION,
    HEADER_DEAL_STATUS,
    PARENT_CONTRACT_NUMBER,
    CONTRACT_NUMBER,
    DEAL_BOOK_NAME,
    DEAL_LEG_REFERENCE,
    DEAL_LEG_BUY_SELL_FLAG,	
    SUB_LEG_DEAL_STATUS,
    PRICING_TYPE,
    PRICING_COMPONENT,
    PRICING_STATUS,
    DEAL_SUB_LEG_REFERENCE,
    SETTLEMENT_TYPE,
    DEAL_LINE_TEXT,
    CALL_PUT_FLAG,
    VESSEL_NAME,
    DELIVERY_JUNCTION_NAME,
    DELIVERY_METHOD_NAME,
    BILL_OF_LADING_DATE,
    VALID_FROM_DATE,
    VALID_TO_DATE
    )
    SELECT  deal_attributes_ck,
    current_timestamp record_created_dttm,
    current_timestamp record_updated_dttm,
    src_sys_name,
    SRC_SYS_DEAL_HEADER_KEY,
    SRC_SYSTEM_DEAL_TYPE_CODE,
    SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    DEAL_HEADER_BUY_SELL_FLAG,
    DEAL_INSTRUMENT_CLASSIFICATION,
    DEAL_SPOT_TERM_IND,
    DEAL_AGREEMENT_TYPE_DESCRIPTION,
    HEADER_DEAL_STATUS,
    PARENT_CONTRACT_NUMBER,
    CONTRACT_NUMBER,
    DEAL_BOOK_NAME,
    'NOT APPLICABLE' AS DEAL_LEG_REFERENCE,
    'NOT APPLICABLE' AS DEAL_LEG_BUY_SELL_FLAG,	
    'NOT APPLICABLE' AS SUB_LEG_DEAL_STATUS,
    'NOT APPLICABLE' AS PRICING_TYPE,
    'NOT APPLICABLE' AS PRICING_COMPONENT,
    'NOT APPLICABLE' AS PRICING_STATUS,
    'NOT APPLICABLE' AS DEAL_SUB_LEG_REFERENCE,
    'NOT APPLICABLE' AS SETTLEMENT_TYPE,
    'NOT APPLICABLE' AS DEAL_LINE_TEXT,
    'NOT APPLICABLE' AS CALL_PUT_FLAG,
    'NOT APPLICABLE' AS VESSEL_NAME,
    'NOT APPLICABLE' AS DELIVERY_JUNCTION_NAME,
    'NOT APPLICABLE' AS DELIVERY_METHOD_NAME,
    ''               AS BILL_OF_LADING_DATE,
    CURRENT_TIMESTAMP VALID_FROM_DATE,
    '9999-12-31 00:00:00' VALID_TO_DATE
    FROM(
      select * from tsa_stage.dim_deal_attributes_stage 
      where 
      (SRC_SYS_DEAL_HEADER_KEY is not null and SRC_SYS_DEAL_HEADER_KEY <> '')
      and (SRC_SYS_DEAL_LEG_KEY is null or SRC_SYS_DEAL_LEG_KEY = '')
      and (SRC_SYS_DEAL_SUB_LEG_KEY is null or SRC_SYS_DEAL_SUB_LEG_KEY = '')
      and SRC_SYS_DEAL_HEADER_KEY in (select SRC_SYS_DEAL_HEADER_KEY from new_header_records_view)
      and src_sys_name = ?
    ) A   
    """
    
    SUBLEG_SCD_TYPE_2_UPDATE_SQL = """
    WITH existing_sub_leg_records_view as(
    SELECT DISTINCT SRC_SYS_DEAL_SUB_LEG_KEY
    FROM tsa_stage.dim_deal_attributes_stage stage
    WHERE 
    stage.SRC_SYS_DEAL_SUB_LEG_KEY is not null
    and stage.SRC_SYS_DEAL_SUB_LEG_KEY <> '' 
    and src_sys_name = ?
    and EXISTS
    (
    SELECT 1
    FROM tsa_curated.dim_deal_attributes main 
    WHERE main.SRC_SYS_DEAL_SUB_LEG_KEY = stage.SRC_SYS_DEAL_SUB_LEG_KEY)
    ),
    subleg_current_main_records_view as (
    select * from 
    (
    select a.*, row_number()
      over(partition by SRC_SYS_DEAL_SUB_LEG_KEY order by valid_to_date desc) row_number 
      from tsa_curated.dim_deal_attributes a 
    where (SRC_SYS_DEAL_SUB_LEG_KEY is not null and SRC_SYS_DEAL_SUB_LEG_KEY <> '')
    and src_sys_name = ?
    ) V where row_number = 1
    )
    UPDATE main_table set main_table.valid_to_date = current_timestamp,
    record_updated_dttm = current_timestamp 
    FROM tsa_stage.dim_deal_attributes_stage stage_table,
    subleg_current_main_records_view main_table
    where stage_table.SRC_SYS_DEAL_SUB_LEG_KEY = main_table.SRC_SYS_DEAL_SUB_LEG_KEY 
    and stage_table.SRC_SYS_DEAL_SUB_LEG_KEY in (select SRC_SYS_DEAL_SUB_LEG_KEY from existing_sub_leg_records_view)
    and (
    main_table.SUB_LEG_DEAL_STATUS <> stage_table.SUB_LEG_DEAL_STATUS OR 
    main_table.DEAL_EXECUTION_TIMESTAMP <> stage_table.DEAL_EXECUTION_TIMESTAMP OR 
    main_table.PRICING_TYPE <> stage_table.PRICING_TYPE OR 
    main_table.PRICING_STATUS <> stage_table.PRICING_STATUS OR 
    main_table.PRICING_COMPONENT <> stage_table.PRICING_COMPONENT OR 
    main_table.PREMIUM_FLOAT_SPREAD <> stage_table.PREMIUM_FLOAT_SPREAD OR 
    main_table.INDEX_FACTOR <> stage_table.INDEX_FACTOR OR  
    main_table.SETTLEMENT_TYPE <> stage_table.SETTLEMENT_TYPE OR 
    main_table.DEAL_LINE_TEXT <> stage_table.DEAL_LINE_TEXT OR 
    main_table.CALL_PUT_FLAG <> stage_table.CALL_PUT_FLAG OR 
    main_table.OPTION_STRIKE_PRICE <> stage_table.OPTION_STRIKE_PRICE OR 
    main_table.OPTION_PREMIUM_PRICE <> stage_table.OPTION_PREMIUM_PRICE OR
    main_table.VESSEL_NAME <> stage_table.VESSEL_NAME OR
    main_table.DELIVERY_JUNCTION_NAME <> stage_table.DELIVERY_JUNCTION_NAME OR 
    main_table.DELIVERY_METHOD_NAME <> stage_table.DELIVERY_METHOD_NAME OR
    main_table.DEAL_LEG_BUY_SELL_FLAG <> stage_table.DEAL_LEG_BUY_SELL_FLAG OR 
    main_table.DEAL_HEADER_BUY_SELL_FLAG <> stage_table.DEAL_HEADER_BUY_SELL_FLAG OR
    main_table.DEAL_BOOK_NAME <> stage_table.DEAL_BOOK_NAME OR
    main_table.HEADER_DEAL_STATUS <> stage_table.HEADER_DEAL_STATUS OR
    main_table.DEAL_AGREEMENT_TYPE_DESCRIPTION <> stage_table.DEAL_AGREEMENT_TYPE_DESCRIPTION OR
    main_table.DEAL_SPOT_TERM_IND <> stage_table.DEAL_SPOT_TERM_IND
       )
    """
    #ps   --> added above 329,mod 328
    SUBLEG_SCD_TYPE_2_INSERT_SQL = """
    WITH existing_sub_leg_records_view as(
    SELECT DISTINCT SRC_SYS_DEAL_SUB_LEG_KEY
    FROM tsa_stage.dim_deal_attributes_stage stage
    WHERE 
    stage.SRC_SYS_DEAL_SUB_LEG_KEY is not null
    and stage.SRC_SYS_DEAL_SUB_LEG_KEY <> '' 
    and src_sys_name = ?
    and EXISTS
    (
    SELECT 1
    FROM tsa_curated.dim_deal_attributes main 
    WHERE main.SRC_SYS_DEAL_SUB_LEG_KEY = stage.SRC_SYS_DEAL_SUB_LEG_KEY)
    ),
    subleg_current_main_records_view as (
      select * from(
      select a.*, row_number()
      over(partition by SRC_SYS_DEAL_SUB_LEG_KEY order by valid_to_date desc) row_number 
      from tsa_curated.dim_deal_attributes a 
      where 
      (SRC_SYS_DEAL_SUB_LEG_KEY is not null and SRC_SYS_DEAL_SUB_LEG_KEY <> '')
      and src_sys_name = ?
      and SRC_SYS_DEAL_SUB_LEG_KEY in (
      select distinct SRC_SYS_DEAL_SUB_LEG_KEY
      from tsa_stage.dim_deal_attributes_stage)
      ) V where row_number = 1
    )
    INSERT INTO tsa_curated.dim_deal_attributes
    (
    deal_attributes_ck,
    record_created_dttm,
    record_updated_dttm,
    src_sys_name,
    SRC_SYS_DEAL_HEADER_KEY,
    SRC_SYS_DEAL_LEG_KEY,
    SRC_SYS_DEAL_SUB_LEG_KEY,
    SRC_SYSTEM_DEAL_TYPE_CODE,
    SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    DEAL_HEADER_BUY_SELL_FLAG,
    DEAL_INSTRUMENT_CLASSIFICATION,
    DEAL_SPOT_TERM_IND,
    DEAL_AGREEMENT_TYPE_DESCRIPTION,
    HEADER_DEAL_STATUS,
    PARENT_CONTRACT_NUMBER,
    CONTRACT_NUMBER,
    DEAL_BOOK_NAME,
    DEAL_LEG_REFERENCE,
    DEAL_LEG_BUY_SELL_FLAG,
    SUB_LEG_DEAL_STATUS,
    DEAL_EXECUTION_TIMESTAMP,
    DEAL_PRICE,
    PRICING_TYPE,
    PRICING_COMPONENT,
    PREMIUM_FLOAT_SPREAD,
    INDEX_FACTOR,
    PRICING_STATUS,
    PRICE_SETTLE_DATE,
    DEAL_SUB_LEG_REFERENCE,
    SETTLEMENT_TYPE,
    DEAL_LINE_TEXT,
    CALL_PUT_FLAG,
    OPTION_STRIKE_PRICE,
    OPTION_PREMIUM_PRICE,
    VESSEL_NAME,
    DELIVERY_JUNCTION_NAME,
    DELIVERY_METHOD_NAME,
    BILL_OF_LADING_DATE,
    VALID_FROM_DATE,
    VALID_TO_DATE
    )  
    SELECT
    stage_table.deal_attributes_ck,
    current_timestamp record_created_dttm,
    current_timestamp record_updated_dttm,
    stage_table.src_sys_name,
    stage_table.SRC_SYS_DEAL_HEADER_KEY,
    stage_table.SRC_SYS_DEAL_LEG_KEY,
    stage_table.SRC_SYS_DEAL_SUB_LEG_KEY,
    main_table.SRC_SYSTEM_DEAL_TYPE_CODE,
    main_table.SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    stage_table.DEAL_HEADER_BUY_SELL_FLAG,
    main_table.DEAL_INSTRUMENT_CLASSIFICATION,
    stage_table.DEAL_SPOT_TERM_IND,
    stage_table.DEAL_AGREEMENT_TYPE_DESCRIPTION,
    stage_table.HEADER_DEAL_STATUS,
    main_table.PARENT_CONTRACT_NUMBER,
    main_table.CONTRACT_NUMBER,
    stage_table.DEAL_BOOK_NAME,
    main_table.DEAL_LEG_REFERENCE,
    stage_table.DEAL_LEG_BUY_SELL_FLAG,
    stage_table.SUB_LEG_DEAL_STATUS,
    stage_table.DEAL_EXECUTION_TIMESTAMP,
    main_table.DEAL_PRICE,
    stage_table.PRICING_TYPE,
    stage_table.PRICING_COMPONENT,
    stage_table.PREMIUM_FLOAT_SPREAD,
    stage_table.INDEX_FACTOR,
    stage_table.PRICING_STATUS,
    main_table.PRICE_SETTLE_DATE,
    main_table.DEAL_SUB_LEG_REFERENCE,
    stage_table.SETTLEMENT_TYPE,
    stage_table.DEAL_LINE_TEXT,
    stage_table.CALL_PUT_FLAG,
    stage_table.OPTION_STRIKE_PRICE,
    stage_table.OPTION_PREMIUM_PRICE,
    stage_table.VESSEL_NAME,
    stage_table.DELIVERY_JUNCTION_NAME,
    stage_table.DELIVERY_METHOD_NAME,
    stage_table.BILL_OF_LADING_DATE,
    current_timestamp valid_from_date,
    '9999-12-31 00:00:00' VALID_TO_DATE
    FROM tsa_stage.dim_deal_attributes_stage stage_table,
    subleg_current_main_records_view main_table
    where stage_table.SRC_SYS_DEAL_SUB_LEG_KEY = main_table.SRC_SYS_DEAL_SUB_LEG_KEY and
    stage_table.SRC_SYS_DEAL_SUB_LEG_KEY in (select SRC_SYS_DEAL_SUB_LEG_KEY from existing_sub_leg_records_view)
    and (
    main_table.SUB_LEG_DEAL_STATUS <> stage_table.SUB_LEG_DEAL_STATUS OR 
    main_table.DEAL_EXECUTION_TIMESTAMP <> stage_table.DEAL_EXECUTION_TIMESTAMP OR 
    main_table.PRICING_TYPE <> stage_table.PRICING_TYPE OR 
    main_table.PRICING_COMPONENT <> stage_table.PRICING_COMPONENT OR 
    main_table.PREMIUM_FLOAT_SPREAD <> stage_table.PREMIUM_FLOAT_SPREAD OR 
    main_table.INDEX_FACTOR <> stage_table.INDEX_FACTOR OR  
    main_table.PRICING_STATUS <> stage_table.PRICING_STATUS OR 
    main_table.SETTLEMENT_TYPE <> stage_table.SETTLEMENT_TYPE OR 
    main_table.DEAL_LINE_TEXT <> stage_table.DEAL_LINE_TEXT OR 
    main_table.CALL_PUT_FLAG <> stage_table.CALL_PUT_FLAG OR 
    main_table.OPTION_STRIKE_PRICE <> stage_table.OPTION_STRIKE_PRICE OR
    main_table.OPTION_PREMIUM_PRICE <> stage_table.OPTION_PREMIUM_PRICE OR
    main_table.VESSEL_NAME <> stage_table.VESSEL_NAME OR
    main_table.DELIVERY_JUNCTION_NAME <> stage_table.DELIVERY_JUNCTION_NAME OR 
    main_table.DELIVERY_METHOD_NAME <> stage_table.DELIVERY_METHOD_NAME OR
    main_table.DEAL_LEG_BUY_SELL_FLAG <> stage_table.DEAL_LEG_BUY_SELL_FLAG OR 
    main_table.DEAL_HEADER_BUY_SELL_FLAG <> stage_table.DEAL_HEADER_BUY_SELL_FLAG OR 
    main_table.DEAL_BOOK_NAME <> stage_table.DEAL_BOOK_NAME OR
    main_table.HEADER_DEAL_STATUS <> stage_table.HEADER_DEAL_STATUS OR
    main_table.DEAL_AGREEMENT_TYPE_DESCRIPTION <> stage_table.DEAL_AGREEMENT_TYPE_DESCRIPTION OR
    main_table.DEAL_SPOT_TERM_IND <> stage_table.DEAL_SPOT_TERM_IND OR
    main_table.BILL_OF_LADING_DATE <> stage_table.BILL_OF_LADING_DATE
    )
    """
    
    LEG_SCD_TYPE_2_UPDATE_SQL = """
    WITH existing_leg_records_view as(
    SELECT DISTINCT SRC_SYS_DEAL_LEG_KEY
    FROM tsa_stage.dim_deal_attributes_stage stage
    WHERE 
    stage.SRC_SYS_DEAL_LEG_KEY is not null
    and stage.SRC_SYS_DEAL_LEG_KEY <> ''
    and src_sys_name = ?
    and EXISTS
    (SELECT 1
    FROM tsa_curated.dim_deal_attributes main 
    WHERE main.SRC_SYS_DEAL_LEG_KEY = stage.SRC_SYS_DEAL_LEG_KEY)
    ),
    leg_current_main_records_view as (
    select * from (
    select a.*,row_number()
    over(partition by SRC_SYS_DEAL_LEG_KEY order by valid_to_date desc) row_number from tsa_curated.dim_deal_attributes a
    where (SRC_SYS_DEAL_SUB_LEG_KEY is null or SRC_SYS_DEAL_SUB_LEG_KEY = '')
    and (SRC_SYS_DEAL_LEG_KEY is not null and SRC_SYS_DEAL_LEG_KEY <> '')
    and src_sys_name = ?
    )
    V where row_number = 1
    )
    UPDATE main_table 
    set main_table.valid_to_date = current_timestamp,
    record_updated_dttm = current_timestamp
    FROM tsa_stage.dim_deal_attributes_stage stage_table,
    leg_current_main_records_view main_table
    where stage_table.SRC_SYS_DEAL_LEG_KEY = main_table.SRC_SYS_DEAL_LEG_KEY 
    and (stage_table.SRC_SYS_DEAL_LEG_KEY is not null and stage_table.src_sys_deal_leg_key <> '')
    and (stage_table.SRC_SYS_DEAL_SUB_LEG_KEY is null or stage_table.SRC_SYS_DEAL_SUB_LEG_KEY = '') 
    and stage_table.SRC_SYS_DEAL_LEG_KEY in (select SRC_SYS_DEAL_LEG_KEY from existing_leg_records_view)
    and (
      main_table.DEAL_LEG_BUY_SELL_FLAG <> stage_table.DEAL_LEG_BUY_SELL_FLAG OR
      main_table.DEAL_BOOK_NAME <> stage_table.DEAL_BOOK_NAME OR
      main_table.HEADER_DEAL_STATUS <> stage_table.HEADER_DEAL_STATUS OR
      main_table.DEAL_AGREEMENT_TYPE_DESCRIPTION <> stage_table.DEAL_AGREEMENT_TYPE_DESCRIPTION OR
      main_table.DEAL_SPOT_TERM_IND <> stage_table.DEAL_SPOT_TERM_IND OR
      main_table.DEAL_HEADER_BUY_SELL_FLAG <> stage_table.DEAL_HEADER_BUY_SELL_FLAG
    )
    """
    
    LEG_SCD_TYPE_2_INSERT_SQL = """
    WITH existing_leg_records_view as(
    SELECT DISTINCT SRC_SYS_DEAL_LEG_KEY
    FROM tsa_stage.dim_deal_attributes_stage stage
    WHERE 
    stage.SRC_SYS_DEAL_LEG_KEY is not null
    and stage.SRC_SYS_DEAL_LEG_KEY <> ''
    and src_sys_name = ?
    and EXISTS
    (SELECT 1
    FROM tsa_curated.dim_deal_attributes main 
    WHERE main.SRC_SYS_DEAL_LEG_KEY = stage.SRC_SYS_DEAL_LEG_KEY)
    ), 
    leg_current_main_records_view as (
    select * from(
    select a.*, row_number()
    over(partition by SRC_SYS_DEAL_LEG_KEY order by valid_to_date desc) row_number 
    from tsa_curated.dim_deal_attributes a 
    where 
    (SRC_SYS_DEAL_SUB_LEG_KEY is null or SRC_SYS_DEAL_SUB_LEG_KEY = '') 
    and (SRC_SYS_DEAL_LEG_KEY is not null and src_sys_deal_leg_key <> '')
    and src_sys_name = ?
    and SRC_SYS_DEAL_LEG_KEY in (
    select distinct SRC_SYS_DEAL_LEG_KEY 
    from tsa_stage.dim_deal_attributes_stage)
    ) V where row_number = 1
    )
    INSERT INTO tsa_curated.dim_deal_attributes
    (
    deal_attributes_ck,
    record_created_dttm,
    record_updated_dttm,
    src_sys_name,
    SRC_SYS_DEAL_HEADER_KEY,
    SRC_SYS_DEAL_LEG_KEY,
    SRC_SYSTEM_DEAL_TYPE_CODE,
    SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    DEAL_HEADER_BUY_SELL_FLAG,
    DEAL_INSTRUMENT_CLASSIFICATION,
    DEAL_SPOT_TERM_IND,
    DEAL_AGREEMENT_TYPE_DESCRIPTION,
    HEADER_DEAL_STATUS,
    PARENT_CONTRACT_NUMBER,
    CONTRACT_NUMBER,
    DEAL_BOOK_NAME,
    DEAL_LEG_REFERENCE,
    DEAL_LEG_BUY_SELL_FLAG,
    SUB_LEG_DEAL_STATUS,
    PRICING_TYPE,
    PRICING_COMPONENT,
    PRICING_STATUS,
    DEAL_SUB_LEG_REFERENCE,
    SETTLEMENT_TYPE,
    DEAL_LINE_TEXT,
    CALL_PUT_FLAG,
    VESSEL_NAME,
    DELIVERY_JUNCTION_NAME,
    DELIVERY_METHOD_NAME,
    BILL_OF_LADING_DATE,
    valid_from_date,
    VALID_TO_DATE
    )
    SELECT  
    stage_table.deal_attributes_ck,
    current_timestamp record_created_dttm,
    current_timestamp record_updated_dttm,
    stage_table.src_sys_name,
    stage_table.SRC_SYS_DEAL_HEADER_KEY,
    stage_table.SRC_SYS_DEAL_LEG_KEY,
    main_table.SRC_SYSTEM_DEAL_TYPE_CODE,
    main_table.SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    stage_table.DEAL_HEADER_BUY_SELL_FLAG,
    main_table.DEAL_INSTRUMENT_CLASSIFICATION,
    stage_table.DEAL_SPOT_TERM_IND,
    stage_table.DEAL_AGREEMENT_TYPE_DESCRIPTION,
    stage_table.HEADER_DEAL_STATUS,
    main_table.PARENT_CONTRACT_NUMBER,
    main_table.CONTRACT_NUMBER,
    stage_table.DEAL_BOOK_NAME,
    main_table.DEAL_LEG_REFERENCE,
    stage_table.DEAL_LEG_BUY_SELL_FLAG,
    'NOT APPLICABLE' AS SUB_LEG_DEAL_STATUS,
    'NOT APPLICABLE' AS PRICING_TYPE,
    'NOT APPLICABLE' AS PRICING_COMPONENT,
    'NOT APPLICABLE' AS PRICING_STATUS,
    'NOT APPLICABLE' AS DEAL_SUB_LEG_REFERENCE,
    'NOT APPLICABLE' AS SETTLEMENT_TYPE,
    'NOT APPLICABLE' AS DEAL_LINE_TEXT,
    'NOT APPLICABLE' AS CALL_PUT_FLAG,
    'NOT APPLICABLE' AS VESSEL_NAME,
    'NOT APPLICABLE' AS DELIVERY_JUNCTION_NAME,
    'NOT APPLICABLE' AS DELIVERY_METHOD_NAME,
    ''               AS BILL_OF_LADING_DATE,
    current_timestamp valid_from_date,
    '9999-12-31 00:00:00' VALID_TO_DATE
    FROM
    tsa_stage.dim_deal_attributes_stage stage_table,
    leg_current_main_records_view main_table
    where stage_table.SRC_SYS_DEAL_LEG_KEY = main_table.SRC_SYS_DEAL_LEG_KEY 
    and (stage_table.SRC_SYS_DEAL_LEG_KEY is not null and stage_table.src_sys_deal_leg_key <> '')
    and (stage_table.SRC_SYS_DEAL_SUB_LEG_KEY is null or stage_table.SRC_SYS_DEAL_SUB_LEG_KEY = '') 
    and stage_table.SRC_SYS_DEAL_LEG_KEY in (select SRC_SYS_DEAL_LEG_KEY from existing_leg_records_view)
    and (
      main_table.DEAL_LEG_BUY_SELL_FLAG <> stage_table.DEAL_LEG_BUY_SELL_FLAG OR
      main_table.DEAL_BOOK_NAME <> stage_table.DEAL_BOOK_NAME OR
      main_table.HEADER_DEAL_STATUS <> stage_table.HEADER_DEAL_STATUS OR
      main_table.DEAL_AGREEMENT_TYPE_DESCRIPTION <> stage_table.DEAL_AGREEMENT_TYPE_DESCRIPTION OR
      main_table.DEAL_SPOT_TERM_IND <> stage_table.DEAL_SPOT_TERM_IND OR
      main_table.DEAL_HEADER_BUY_SELL_FLAG <> stage_table.DEAL_HEADER_BUY_SELL_FLAG
      
    )
    """
    
    HEADER_SCD_TYPE_2_UPDATE_SQL = """
    WITH existing_header_records_view as(
    SELECT DISTINCT SRC_SYS_DEAL_HEADER_KEY
    FROM tsa_stage.dim_deal_attributes_stage stage
    WHERE src_sys_name = ? and EXISTS
    (SELECT 1
    FROM tsa_curated.dim_deal_attributes main 
    WHERE main.SRC_SYS_DEAL_HEADER_KEY = stage.SRC_SYS_DEAL_HEADER_KEY)
    ),
    header_current_main_records_view as (
      select * from(
        select a.*,row_number()
        over(partition by SRC_SYS_DEAL_HEADER_KEY order by valid_to_date desc) row_number from tsa_curated.dim_deal_attributes a 
        where (SRC_SYS_DEAL_SUB_LEG_KEY is null or SRC_SYS_DEAL_SUB_LEG_KEY = '') 
        and (SRC_SYS_DEAL_LEG_KEY is null or SRC_SYS_DEAL_LEG_KEY = '') 
        and (SRC_SYS_DEAL_HEADER_KEY is not null and SRC_SYS_DEAL_HEADER_KEY <> '')
        and src_sys_name = ?
      ) V where row_number = 1
    )
    UPDATE main_table 
    set main_table.valid_to_date = current_timestamp,
    record_updated_dttm = current_timestamp 
    FROM tsa_stage.dim_deal_attributes_stage stage_table,
    header_current_main_records_view main_table
    where 
    (stage_table.SRC_SYS_DEAL_LEG_KEY is null or stage_table.SRC_SYS_DEAL_LEG_KEY = '')
    and (stage_table.SRC_SYS_DEAL_SUB_LEG_KEY is null or stage_table.SRC_SYS_DEAL_SUB_LEG_KEY = '') 
    and (stage_table.SRC_SYS_DEAL_HEADER_KEY is not null and stage_table.SRC_SYS_DEAL_HEADER_KEY <> '')
    and stage_table.SRC_SYS_DEAL_HEADER_KEY = main_table.SRC_SYS_DEAL_HEADER_KEY 
    and stage_table.SRC_SYS_DEAL_HEADER_KEY in 
    (select SRC_SYS_DEAL_HEADER_KEY from existing_header_records_view)
    and (
      main_table.DEAL_BOOK_NAME <> stage_table.DEAL_BOOK_NAME OR
      main_table.HEADER_DEAL_STATUS <> stage_table.HEADER_DEAL_STATUS OR
      main_table.DEAL_AGREEMENT_TYPE_DESCRIPTION <> stage_table.DEAL_AGREEMENT_TYPE_DESCRIPTION OR
      main_table.DEAL_SPOT_TERM_IND <> stage_table.DEAL_SPOT_TERM_IND OR
      main_table.DEAL_HEADER_BUY_SELL_FLAG <> stage_table.DEAL_HEADER_BUY_SELL_FLAG
    )
    """
    
    HEADER_SCD_TYPE_2_INSERT_SQL = """
    WITH existing_header_records_view as(
    SELECT DISTINCT SRC_SYS_DEAL_HEADER_KEY
    FROM tsa_stage.dim_deal_attributes_stage stage
    WHERE src_sys_name = ? and EXISTS
    (SELECT 1
    FROM tsa_curated.dim_deal_attributes main 
    WHERE main.SRC_SYS_DEAL_HEADER_KEY = stage.SRC_SYS_DEAL_HEADER_KEY)
    ),
    header_current_main_records_view as (
    select * from(
    select a.*, row_number()
    over(partition by SRC_SYS_DEAL_HEADER_KEY order by valid_to_date desc) row_number 
    from tsa_curated.dim_deal_attributes a 
    where src_sys_name = ? and
    (SRC_SYS_DEAL_SUB_LEG_KEY is null or SRC_SYS_DEAL_SUB_LEG_KEY = '') 
    and (SRC_SYS_DEAL_LEG_KEY is null or SRC_SYS_DEAL_LEG_KEY = '') 
    and (SRC_SYS_DEAL_HEADER_KEY is not null and SRC_SYS_DEAL_HEADER_KEY <> '')
    and SRC_SYS_DEAL_HEADER_KEY in (
    select distinct SRC_SYS_DEAL_HEADER_KEY 
    from tsa_stage.dim_deal_attributes_stage)
    ) V where row_number = 1 
    )
    INSERT INTO tsa_curated.dim_deal_attributes
    (
    deal_attributes_ck,
    record_created_dttm,
    record_updated_dttm,
    src_sys_name,
    SRC_SYS_DEAL_HEADER_KEY,
    SRC_SYSTEM_DEAL_TYPE_CODE,
    SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    DEAL_HEADER_BUY_SELL_FLAG,
    DEAL_INSTRUMENT_CLASSIFICATION,
    DEAL_SPOT_TERM_IND,
    DEAL_AGREEMENT_TYPE_DESCRIPTION,
    HEADER_DEAL_STATUS,
    PARENT_CONTRACT_NUMBER,
    CONTRACT_NUMBER,
    DEAL_BOOK_NAME,
    DEAL_LEG_REFERENCE,
    DEAL_LEG_BUY_SELL_FLAG,	
    SUB_LEG_DEAL_STATUS,
    PRICING_TYPE,
    PRICING_COMPONENT,
    PRICING_STATUS,
    DEAL_SUB_LEG_REFERENCE,
    SETTLEMENT_TYPE,
    DEAL_LINE_TEXT,
    CALL_PUT_FLAG,
    VESSEL_NAME,
    DELIVERY_JUNCTION_NAME,
    DELIVERY_METHOD_NAME,
    BILL_OF_LADING_DATE,
    valid_from_date,
    VALID_TO_DATE
    )
    SELECT  stage_table.deal_attributes_ck,
    current_timestamp record_created_dttm,
    current_timestamp record_updated_dttm,
    stage_table.src_sys_name,
    stage_table.SRC_SYS_DEAL_HEADER_KEY,
    main_table.SRC_SYSTEM_DEAL_TYPE_CODE,
    main_table.SRC_SYSTEM_DEAL_SUBTYPE_CODE,
    stage_table.DEAL_HEADER_BUY_SELL_FLAG,
    main_table.DEAL_INSTRUMENT_CLASSIFICATION,
    stage_table.DEAL_SPOT_TERM_IND,
    stage_table.DEAL_AGREEMENT_TYPE_DESCRIPTION,
    stage_table.HEADER_DEAL_STATUS,
    main_table.PARENT_CONTRACT_NUMBER,
    main_table.CONTRACT_NUMBER,
    stage_table.DEAL_BOOK_NAME,
    'NOT APPLICABLE' AS DEAL_LEG_REFERENCE,
    'NOT APPLICABLE' AS DEAL_LEG_BUY_SELL_FLAG,	
    'NOT APPLICABLE' AS SUB_LEG_DEAL_STATUS,
    'NOT APPLICABLE' AS PRICING_TYPE,
    'NOT APPLICABLE' AS PRICING_COMPONENT,
    'NOT APPLICABLE' AS PRICING_STATUS,
    'NOT APPLICABLE' AS DEAL_SUB_LEG_REFERENCE,
    'NOT APPLICABLE' AS SETTLEMENT_TYPE,
    'NOT APPLICABLE' AS DEAL_LINE_TEXT,
    'NOT APPLICABLE' AS CALL_PUT_FLAG,
    'NOT APPLICABLE' AS VESSEL_NAME,
    'NOT APPLICABLE' AS DELIVERY_JUNCTION_NAME,
    'NOT APPLICABLE' AS DELIVERY_METHOD_NAME,
    ''               AS BILL_OF_LADING_DATE,
    current_timestamp valid_from_date,
    '9999-12-31 00:00:00' VALID_TO_DATE
    FROM tsa_stage.dim_deal_attributes_stage stage_table,
    header_current_main_records_view main_table
    where 
    (stage_table.SRC_SYS_DEAL_LEG_KEY is null or stage_table.SRC_SYS_DEAL_LEG_KEY = '')
    and (stage_table.SRC_SYS_DEAL_SUB_LEG_KEY is null or stage_table.SRC_SYS_DEAL_SUB_LEG_KEY = '') 
    and (stage_table.SRC_SYS_DEAL_HEADER_KEY is not null and stage_table.SRC_SYS_DEAL_HEADER_KEY <> '')
    and stage_table.SRC_SYS_DEAL_HEADER_KEY = main_table.SRC_SYS_DEAL_HEADER_KEY 
    and stage_table.SRC_SYS_DEAL_HEADER_KEY in 
    (select SRC_SYS_DEAL_HEADER_KEY from existing_header_records_view)
    and (
      main_table.DEAL_BOOK_NAME <> stage_table.DEAL_BOOK_NAME OR
      main_table.HEADER_DEAL_STATUS <> stage_table.HEADER_DEAL_STATUS OR
      main_table.DEAL_AGREEMENT_TYPE_DESCRIPTION <> stage_table.DEAL_AGREEMENT_TYPE_DESCRIPTION OR
      main_table.DEAL_SPOT_TERM_IND <> stage_table.DEAL_SPOT_TERM_IND OR
      main_table.DEAL_HEADER_BUY_SELL_FLAG <> stage_table.DEAL_HEADER_BUY_SELL_FLAG
      
    )
    """
    
        
    
        
    def write(df, SOURCE_ETRM, metricDict, watermarkUpdater):
      import time
      
      start = time.time()
      metricDict = WriteToStage(df,SOURCE_ETRM, metricDict)
      end = time.time()
      time_taken = end - start
      metricDict["deal_attributes_writer_stage_load_time_taken_in_sec"] = time_taken 
      
      print("before duplicate check")
      status = validateDuplicateDealAttr(SOURCE_ETRM)
      if status != "SUCCESS":
        print("duplicate validation ....")
        raise Exception("DUPLICATE_RECORDS_FOUND")

      

      metricDict = executeAndLogMetric(DealAttributesWriter.SUBLEG_SCD_TYPE_2_UPDATE_SQL,SOURCE_ETRM,metricDict,"update_subeg_scd_type2")     
      metricDict = executeAndLogMetric(DealAttributesWriter.SUBLEG_SCD_TYPE_2_INSERT_SQL,SOURCE_ETRM,metricDict,"insert_subeg_scd_type2")


      metricDict = executeAndLogMetric(DealAttributesWriter.LEG_SCD_TYPE_2_UPDATE_SQL,SOURCE_ETRM,metricDict,"update_leg_scd_type2")     
      metricDict = executeAndLogMetric(DealAttributesWriter.LEG_SCD_TYPE_2_INSERT_SQL,SOURCE_ETRM,metricDict,"insert_leg_scd_type2")

      metricDict = executeAndLogMetric(DealAttributesWriter.HEADER_SCD_TYPE_2_UPDATE_SQL,SOURCE_ETRM,metricDict,"update_header_scd_type2")   
      metricDict = executeAndLogMetric(DealAttributesWriter.HEADER_SCD_TYPE_2_INSERT_SQL,SOURCE_ETRM,metricDict,"insert_header_scd_type2")
      
      metricDict = executeAndLogMetric(DealAttributesWriter.INSERT_DIM_DEAL_ATTRIBUTES_HEADER_SQL,SOURCE_ETRM,metricDict,"insert_header")
      metricDict = executeAndLogMetric(DealAttributesWriter.INSERT_DIM_DEAL_ATTRIBUTES_LEG_SQL,SOURCE_ETRM,metricDict,"insert_leg")
      metricDict = executeAndLogMetric(DealAttributesWriter.INSERT_DIM_DEAL_ATTRIBUTES_SUBLEG_SQL,SOURCE_ETRM,metricDict,"insert_subleg")

      start = time.time()
      metricDict = writeAfterDealAttrSCD(SOURCE_ETRM, metricDict)
      end = time.time()
      time_taken = end - start
      metricDict["deal_attributes_post_scd_fact_processing_time_taken_in_sec"] = time_taken 
      
      start = time.time()
      #watermarkUpdater.updateWatermarkForDimDealAttributes()
      watermarkUpdater.updateWatermarkForDealAttributes()
      end = time.time()
      time_taken = end - start
      metricDict["watermark_update_time_taken_in_sec"] = time_taken 
      
      
      return ("SUCCESS", metricDict)


# COMMAND ----------

  def executeAndLogMetric(SQL,SOURCE_ETRM,metricDict,metricName):
      import time
      start = time.time()
      row_affected = executePyOdbcQueryWithParam2(SQL,SOURCE_ETRM, SOURCE_ETRM)
      end = time.time()
      time_taken = end - start
      metricDict[metricName + "_time_taken_in_sec"] = time_taken 
      metricDict[metricName + "_rows_affected"] = row_affected
      return metricDict
