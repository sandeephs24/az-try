# Databricks notebook source
# MAGIC %run ./UniquenessCheckUtil

# COMMAND ----------

def validateUniqueCurrency(SOURCE_ETRM):
  
  SQL = """
  select currency_check.*,
		case when currency_sk_count = currency_ck_count
		and 
		currency_ck_count=record_count
		THEN 'UNIQUESNESS TEST PASSED'
		ELSE 'UNIQUESNESS TEST FAILED' END AS TEST_STATUS
	FROM ( SELECT count(distinct currency_sk) as currency_sk_count,
					count(distinct currency_ck) as currency_ck_count,
					count(1) as record_count,
					current_timestamp as SQL_EXEC_DATETIME
				FROM [tsa_curated].[DIM_currency]
				where src_sys_name = '{0}'
		)currency_check
  """.format(SOURCE_ETRM)
  
  status = runSQLandCheckUniqueness(SQL)
  return status
