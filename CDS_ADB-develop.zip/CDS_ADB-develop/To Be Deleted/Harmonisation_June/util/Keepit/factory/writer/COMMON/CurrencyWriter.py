# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../DatasetWriter

# COMMAND ----------

# MAGIC %run ./VALIDATOR/pre_validator/duplicate/CurrencyDuplicatePreValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/duplicate/CurrencyDuplicatePostValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/UNIQUENESS/CurrencyUniquenessPostValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/IFNULL/CurrencyifnullPostValidator

# COMMAND ----------

class CurrencyWriter(DatasetWriter):
    DELETE_DIM_CURRENCY_STAGE_SQL = """DELETE from tsa_stage.dim_currency_stage WHERE src_sys_name = ?"""
    INSERT_DIM_CURRENCY_SQL = """
    INSERT INTO tsa_curated.dim_currency
    (
    currency_ck,
    record_created_dttm,
    record_updated_dttm,
    src_sys_name,
    src_sys_currency_nk,
    ISO_CURRENCY_CODE,
    ISO_CURRENCY_NAME
    )
    SELECT currency_ck,
    current_timestamp record_created_dttm,
    current_timestamp record_updated_dttm,
    src_sys_name src_sys_name,
    src_sys_currency_nk,
    ISO_CURRENCY_CODE,
    ISO_CURRENCY_NAME 
    FROM tsa_stage.dim_currency_stage stage
    WHERE NOT EXISTS
    (SELECT 1 
    FROM tsa_curated.dim_currency main 
    WHERE main.currency_ck = stage.currency_ck ) and stage.src_sys_name = ?
    """
    
    UPDATE_DIM_CURRENCY_SQL = """UPDATE main_table 
    SET main_table.ISO_CURRENCY_CODE =stage_table.ISO_CURRENCY_CODE,
    main_table.ISO_CURRENCY_NAME =stage_table.ISO_CURRENCY_NAME,
    main_table.record_updated_dttm = current_timestamp
    FROM tsa_curated.dim_currency main_table
    JOIN tsa_stage.dim_currency_stage stage_table
    ON main_table.currency_ck = stage_table.currency_ck and stage_table.src_sys_name = ? """
    
    def write(spark, df, SOURCE_ETRM, metricDict):
        import time
        print('deleting stage records')
        executePyOdbcQueryWithParam1(CurrencyWriter.DELETE_DIM_CURRENCY_STAGE_SQL,SOURCE_ETRM)
        start = time.time()
        
        df = df.withColumn("SRC_SYS_CURRENCY_NK",df.SRC_SYS_CURRENCY_NK.cast('string'))
        
        df = df.select(
          col("CURRENCY_CK"),
          col("RECORD_CREATED_DTTM"),
          col("SRC_SYS_NAME"),
          col("SRC_SYS_CURRENCY_NK"),
          col("ISO_CURRENCY_CODE"),
          col("ISO_CURRENCY_NAME")                         
          )

        print("writing to stage table")
        writeDatasetSynapseConnector(spark, df,"tsa_stage.dim_currency_stage")
        end = time.time()
        time_taken = end - start
        metricDict["currency_writer_stage_load_time_taken_in_sec"] = time_taken 
        
        status = validateDuplicateCurrency(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
          
        start = time.time()
        print('updating existing records')
        row_affected = executePyOdbcQueryWithParam1(CurrencyWriter.UPDATE_DIM_CURRENCY_SQL,SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["currency_writer_update_sql_time_taken_in_sec"] = time_taken 
        metricDict["update_sql_rows_affected"] = row_affected 
        
        start = time.time()
        print('inserting new records')
        row_affected = executePyOdbcQueryWithParam1(CurrencyWriter.INSERT_DIM_CURRENCY_SQL,SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["currency_writer_insert_sql_time_taken_in_sec"] = time_taken 
        metricDict["insert_sql_rows_affected"] = row_affected 
        
        print('data load completed')
        
        status = validateUniqueCurrency(SOURCE_ETRM)
        if status != "SUCCESS":
          print("Uniqueness validation ....")
          raise Exception("UNIQUENESS_TEST_FAILED")
          
        print("starting duplicate SK check")
        status = validateDuplicateCurrencySK(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
        
          
        status = validateIfNullLogicCurrency(SOURCE_ETRM)
        if status != "SUCCESS":
          print("IF NULL LOGIC has failed")
          warnings.warn("Warning : IF NULL LOGIC has failed")
        
        return ("SUCCESS", metricDict)

