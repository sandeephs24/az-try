# Databricks notebook source
# MAGIC %run ./UniquenessCheckUtil

# COMMAND ----------

def validateUniqueBroker(SOURCE_ETRM):
  
  SQL = """
  select broker_check.*,
		case when broker_sk_count = broker_ck_count
		and 
		broker_ck_count=record_count
		THEN 'UNIQUESNESS TEST PASSED'
		ELSE 'UNIQUESNESS TEST FAILED' END AS TEST_STATUS
	FROM ( SELECT count(distinct broker_sk) as broker_sk_count,
					count(distinct broker_ck) as broker_ck_count,
					count(1) as record_count,
					current_timestamp as SQL_EXEC_DATETIME
				FROM [tsa_curated].[DIM_broker]
				where src_sys_name = '{0}'
		)broker_check
  """.format(SOURCE_ETRM)
  
  status = runSQLandCheckUniqueness(SQL)
  return status
