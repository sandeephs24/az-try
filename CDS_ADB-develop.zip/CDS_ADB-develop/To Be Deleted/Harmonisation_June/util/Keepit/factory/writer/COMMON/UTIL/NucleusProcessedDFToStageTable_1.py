# Databricks notebook source
def appendHeaderAndLegforNucleus(df, metricDict):
  df.createOrReplaceTempView("DEAL_ATTRIBUTES_SUBLEG_VIEW")
  print("subleg schema_withoutselect")
  df.printSchema()
  metricDict["subleg_reader_count"] = df.count()
  
  dfLeg = driveLegRecords()
  metricDict["leg_reader_driven_count"] = dfLeg.count()
  
  print(dfLeg.count())
  #print(dfLeg.count())
  dfHeader = driveHeaderRecords()
  metricDict["header_reader_driven_count"] = dfHeader.count()
  
  print(dfHeader.count())
  #print(dfHeader.count())

  #df = selectColumnsToEnsureSequenceToMakeUnionWorkProperly(df)
  #dfLeg = selectColumnsToEnsureSequenceToMakeUnionWorkProperly(dfLeg)
  dfHeader = selectColumnsToEnsureSequenceToMakeUnionWorkProperly(dfHeader)
  
  print("subleg schema")
  df.printSchema()
  print("leg schema")
  dfLeg.printSchema()
  print("header schema")
  dfHeader.printSchema()
  
  df = df.union(dfLeg)
  df = df.union(dfHeader)
  metricDict["total_count_after_union"] = df.count()
  print(df.count())
  df.select(col("SRC_SYS_NAME"), col("DEAL_ATTRIBUTES_CK")).show()
      
  
  return (df,metricDict)

# COMMAND ----------

  def selectColumnsToEnsureSequenceToMakeUnionWorkProperly(dfDealAttr):
    dfDealAttr = dfDealAttr.select(
    col("SRC_SYS_DEAL_HEADER_KEY"),
    col("SRC_SYS_DEAL_LEG_KEY"),
    col("SRC_SYS_DEAL_SUB_LEG_KEY"),
    col("SRC_SYSTEM_DEAL_TYPE_CODE"),
    col("SRC_SYSTEM_DEAL_SUBTYPE_CODE"),
    col("DEAL_HEADER_BUY_SELL_FLAG"),
    col("DEAL_SPOT_TERM_IND"),
    col("DEAL_AGREEMENT_TYPE_DESCRIPTION"),
    col("HEADER_DEAL_STATUS"),
    col("PARENT_CONTRACT_NUMBER"),
    col("CONTRACT_NUMBER"),
    col("DEAL_BOOK_NAME"),
    col("DEAL_LEG_REFERENCE"),
    col("DEAL_LEG_BUY_SELL_FLAG"),
    col("SUB_LEG_DEAL_STATUS"),
    col("DEAL_EXECUTION_TIMESTAMP"),
    col("DEAL_PRICE"),
    col("PRICING_TYPE"),
    col("PRICING_COMPONENT"),
    col("PREMIUM_FLOAT_SPREAD"),
    col("INDEX_FACTOR"),
    col("PRICING_STATUS"),
    col("PRICE_SETTLE_DATE"),
    col("DEAL_SUB_LEG_REFERENCE"),
    col("SETTLEMENT_TYPE"),
    col("DEAL_LINE_TEXT"),
    col("CALL_PUT_FLAG"),
    col("OPTION_STRIKE_PRICE"),
    col("OPTION_PREMIUM_PRICE"),
    col("VESSEL_NAME"),
    col("DELIVERY_JUNCTION_NAME"),
    col("DELIVERY_METHOD_NAME"),
    col("SOURCE_LAST_DATE1"),
    col("SOURCE_LAST_DATE2"), 
    col("BILL_OF_LADING_DATE"),
    col("SRC_SYS_NAME"),
    col("DEAL_ATTRIBUTES_CK"),
    col("RECORD_CREATED_DTTM"),
    col("DEAL_INSTRUMENT_CLASSIFICATION")
    )  
    return dfDealAttr
 

# COMMAND ----------

  def driveHeaderRecords():
    SQL = """
    WITH header_stage_view as(
    select * from(
      SELECT  
      a.*,
      row_number() over(partition by SRC_SYS_DEAL_HEADER_KEY 
      order by SRC_SYS_DEAL_HEADER_KEY) row_number
      from DEAL_ATTRIBUTES_SUBLEG_VIEW a
      ) V where row_number = 1
    )
    select SRC_SYS_DEAL_HEADER_KEY
       ,'' as SRC_SYS_DEAL_LEG_KEY
       ,'' as SRC_SYS_DEAL_SUB_LEG_KEY
       ,SRC_SYSTEM_DEAL_TYPE_CODE      
       ,SRC_SYSTEM_DEAL_SUBTYPE_CODE
       ,DEAL_HEADER_BUY_SELL_FLAG
       ,DEAL_INSTRUMENT_CLASSIFICATION
       ,DEAL_SPOT_TERM_IND
       ,DEAL_AGREEMENT_TYPE_DESCRIPTION
       ,HEADER_DEAL_STATUS
       ,PARENT_CONTRACT_NUMBER        
       ,CONTRACT_NUMBER
       ,DEAL_BOOK_NAME
       ,'' as DEAL_LEG_REFERENCE
       ,'' as DEAL_LEG_BUY_SELL_FLAG
       ,'' as SUB_LEG_DEAL_STATUS      
       ,'' as DEAL_EXECUTION_TIMESTAMP
       ,'0.0' as DEAL_PRICE
       ,'' as PRICING_TYPE
       ,'' as PRICING_COMPONENT
       ,'0.0' as PREMIUM_FLOAT_SPREAD
       ,'0.0' as INDEX_FACTOR
       ,'' as PRICING_STATUS
       ,'' as PRICE_SETTLE_DATE 
       ,'' as DEAL_SUB_LEG_REFERENCE
       ,'' as SETTLEMENT_TYPE 
       ,'' as DEAL_LINE_TEXT        
       ,'' as CALL_PUT_FLAG      
       ,'0.0' as OPTION_STRIKE_PRICE
       ,'0.0' as OPTION_PREMIUM_PRICE
       ,'' as VESSEL_NAME
       ,'' as DELIVERY_JUNCTION_NAME
       ,'' as DELIVERY_METHOD_NAME
       ,SOURCE_LAST_DATE1
       ,SOURCE_LAST_DATE2
       ,'' as BILL_OF_LADING_DATE
       ,src_sys_name
       ,concat(src_sys_name , '_' , SRC_SYS_DEAL_HEADER_KEY) as  deal_attributes_ck
       ,record_created_dttm 
       from header_stage_view
    """
    df = spark.sql(SQL)
    df.select(df.src_sys_name,df.SRC_SYS_DEAL_HEADER_KEY,df.deal_attributes_ck).show()
    return df

# COMMAND ----------

def driveLegRecords():
    SQL = """
    WITH leg_stage_view as(
    select * from(
    SELECT  
    a.*,
    row_number() over(partition by SRC_SYS_DEAL_LEG_KEY 
    order by SRC_SYS_DEAL_LEG_KEY) row_number
    from DEAL_ATTRIBUTES_SUBLEG_VIEW a
    ) V 
    where row_number = 1
    )
    select SRC_SYS_DEAL_HEADER_KEY
    ,SRC_SYS_DEAL_LEG_KEY
    ,'' as SRC_SYS_DEAL_SUB_LEG_KEY
    ,SRC_SYSTEM_DEAL_TYPE_CODE      
    ,SRC_SYSTEM_DEAL_SUBTYPE_CODE
    ,DEAL_HEADER_BUY_SELL_FLAG
    ,DEAL_INSTRUMENT_CLASSIFICATION
    ,DEAL_SPOT_TERM_IND
    ,DEAL_AGREEMENT_TYPE_DESCRIPTION
    ,HEADER_DEAL_STATUS
    ,PARENT_CONTRACT_NUMBER        
    ,CONTRACT_NUMBER
    ,DEAL_BOOK_NAME
    ,DEAL_LEG_REFERENCE
    ,DEAL_LEG_BUY_SELL_FLAG
    ,'' as SUB_LEG_DEAL_STATUS      
    ,'' as DEAL_EXECUTION_TIMESTAMP
    ,'0.0' as DEAL_PRICE
    ,'' as PRICING_TYPE
    ,'' as PRICING_COMPONENT
    ,'0.0' as PREMIUM_FLOAT_SPREAD
    ,'0.0' as INDEX_FACTOR
    ,'' as PRICING_STATUS
    ,'' as PRICE_SETTLE_DATE 
    ,'' as DEAL_SUB_LEG_REFERENCE
    ,'' as SETTLEMENT_TYPE 
    ,'' as DEAL_LINE_TEXT        
    ,'' as CALL_PUT_FLAG      
    ,'0.0' as OPTION_STRIKE_PRICE
    ,'0.0' as OPTION_PREMIUM_PRICE
    ,'' as VESSEL_NAME
    ,'' as DELIVERY_JUNCTION_NAME
    ,'' as DELIVERY_METHOD_NAME
    ,SOURCE_LAST_DATE1
    ,SOURCE_LAST_DATE2
    ,'' as BILL_OF_LADING_DATE
    ,src_sys_name
    ,concat(src_sys_name , '_' ,SRC_SYS_DEAL_LEG_KEY) as  deal_attributes_ck
    ,record_created_dttm 
    from leg_stage_view
    """
    
    df = spark.sql(SQL)
    df.select(df.src_sys_name,df.SRC_SYS_DEAL_LEG_KEY,df.deal_attributes_ck).show()
    return df
