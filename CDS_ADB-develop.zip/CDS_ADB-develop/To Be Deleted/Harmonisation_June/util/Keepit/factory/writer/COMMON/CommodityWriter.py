# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../DatasetWriter

# COMMAND ----------

# MAGIC %run ./VALIDATOR/pre_validator/duplicate/CommodityDuplicatePreValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/duplicate/CommodityDuplicatePostValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/UNIQUENESS/CommodityUniquenessPostValidator

# COMMAND ----------

class CommodityWriter(DatasetWriter):
    DELETE_DIM_COMMODITY_STAGE_SQL = """DELETE from tsa_stage.dim_commodity_stage WHERE src_sys_name = ?"""
    INSERT_DIM_COMMODITY_SQL = """
    INSERT INTO tsa_curated.dim_commodity
    (
    commodity_ck,
    record_created_dttm,
    record_updated_dttm,
    src_sys_name,
    src_sys_commodity_nk,
    src_commodity_name,
    src_commodity_group_name,
    std_commodity_type_name,
    active_commodity_flag,
    HIGH_RISK_COMMODITY_FLAG,
    DUAL_USE_COMMODITY_FLAG,
    COMMODITY_UOM_SYMBOL_CODE,
    COMMODITY_UOM_SYMBOL_DESCRIPTION
    )
    SELECT commodity_ck,
    current_timestamp record_created_dttm,
    current_timestamp record_updated_dttm,
    src_sys_name src_sys_name,
    src_sys_commodity_nk,
    src_commodity_name,
    src_commodity_group_name,
    std_commodity_type_name,
    active_commodity_flag,
    HIGH_RISK_COMMODITY_FLAG,
    DUAL_USE_COMMODITY_FLAG,
    COMMODITY_UOM_SYMBOL_CODE,
    COMMODITY_UOM_SYMBOL_DESCRIPTION
    FROM tsa_stage.dim_commodity_stage stage
    WHERE NOT EXISTS
    (SELECT 1 
    FROM tsa_curated.dim_commodity main 
    WHERE main.commodity_ck = stage.commodity_ck ) and stage.src_sys_name = ?
    """
    
    UPDATE_DIM_COMMODITY_SQL = """UPDATE main_table 
    SET main_table.src_commodity_name =stage_table.src_commodity_name,
    main_table.src_commodity_group_name =stage_table.src_commodity_group_name,
    main_table.std_commodity_type_name =stage_table.std_commodity_type_name,
    main_table.active_commodity_flag =stage_table.active_commodity_flag,
    main_table.HIGH_RISK_COMMODITY_FLAG =stage_table.HIGH_RISK_COMMODITY_FLAG,
    main_table.DUAL_USE_COMMODITY_FLAG =stage_table.DUAL_USE_COMMODITY_FLAG,
    main_table.COMMODITY_UOM_SYMBOL_CODE =stage_table.COMMODITY_UOM_SYMBOL_CODE,
    main_table.COMMODITY_UOM_SYMBOL_DESCRIPTION =stage_table.COMMODITY_UOM_SYMBOL_DESCRIPTION,
    record_updated_dttm = current_timestamp
    FROM tsa_curated.dim_commodity main_table
    JOIN tsa_stage.dim_commodity_stage stage_table
    ON main_table.commodity_ck = stage_table.commodity_ck and stage_table.src_sys_name = ? """
    
    UPDATE_WATERMARK_SQL = """
    UPDATE tsa_curated.watermark SET last_offset_value =
    (
    SELECT CONVERT(varchar(20), max(source_last_update), 120) 
    FROM tsa_curated.dim_commodity main_table,tsa_stage.dim_commodity_stage stage_table 
    WHERE main_table.commodity_ck = stage_table.commodity_ck
    ) 
    WHERE source_name = ?
    and source_table_name = ?
    and table_name = 'DIM_COMMODITY' 
    """
    
    def write(df, SOURCE_ETRM, metricDict):
        import time
        from pyspark.sql.types import DateType
        print('deleting stage records')
        executePyOdbcQueryWithParam1(CommodityWriter.DELETE_DIM_COMMODITY_STAGE_SQL, SOURCE_ETRM)
        start = time.time()
        df = df.withColumn("SRC_SYS_COMMODITY_NK",df.SRC_SYS_COMMODITY_NK.cast('string'))
        df.printSchema()
        
        df = df.withColumn("RECORD_CREATED_DTTM",df.RECORD_CREATED_DTTM.cast(DateType()))
        df = df.withColumn("SOURCE_LAST_UPDATE",df.SOURCE_LAST_UPDATE.cast(DateType()))
        
       
        
        df = df.select(
          col("COMMODITY_CK"),
          col("RECORD_CREATED_DTTM"),
          col("SRC_SYS_NAME"),
          col("SRC_SYS_COMMODITY_NK"),
          col("SRC_COMMODITY_NAME"),
          col("STD_COMMODITY_TYPE_NAME"),
          col("SRC_COMMODITY_GROUP_NAME"),
          col("ACTIVE_COMMODITY_FLAG"),
          col("HIGH_RISK_COMMODITY_FLAG"),
          col("DUAL_USE_COMMODITY_FLAG"),
          col("SOURCE_LAST_UPDATE"),
          col("COMMODITY_UOM_SYMBOL_CODE"),
          col("COMMODITY_UOM_SYMBOL_DESCRIPTION")          
          )
        print("here88888888888888")
        df.printSchema()
        print("writing to stage table")
        writeDatasetSynapseConnector(spark, df,"tsa_stage.dim_commodity_stage")
        end = time.time()
        time_taken = end - start
        metricDict["commodity_writer_stage_load_time_taken_in_sec"] = time_taken 
        
        status = validateDuplicateCommodity(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
        
        start = time.time()
        print('updating existing records')
        rows_affected = executePyOdbcQueryWithParam1(CommodityWriter.UPDATE_DIM_COMMODITY_SQL,SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["commodity_writer_update_time_taken_in_sec"] = time_taken 
        metricDict["update_sql_rows_affected"] = rows_affected 
        
        
        start = time.time()
        print('inserting new records')
        rows_affected = executePyOdbcQueryWithParam1(CommodityWriter.INSERT_DIM_COMMODITY_SQL,SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["commodity_writer_insert_time_taken_in_sec"] = time_taken 
        metricDict["insert_sql_rows_affected"] = rows_affected 
        
        if(SOURCE_ETRM == 'DEX'):
          SOURCE_TABLE_NAME = 'STO_GRADE'
          executePyOdbcQueryWithParam2(CommodityWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_TABLE_NAME)
        if(SOURCE_ETRM == 'NUCLEUS'):
          SOURCE_TABLE_NAME = 'DEAL_MONTH_DETAILS'
          executePyOdbcQueryWithParam2(CommodityWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_TABLE_NAME)
        
        
        status = validateUniqueCommodity(SOURCE_ETRM)
        if status != "SUCCESS":
          print("Uniqueness validation ....")
          raise Exception("UNIQUENESS_TEST_FAILED")
          
        print("Starting SK duplicate check")  
        status = validateDuplicateCommoditySK(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
        
        print('data load completed')
        return ("SUCCESS", metricDict)

