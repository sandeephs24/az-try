# Databricks notebook source
# MAGIC %run ../DatasetWriter

# COMMAND ----------

# MAGIC %run ./BrokerWriter

# COMMAND ----------

# MAGIC %run ./CommodityWriter

# COMMAND ----------

# MAGIC %run ./CounterPartyWriter

# COMMAND ----------

# MAGIC %run ./CurrencyWriter

# COMMAND ----------

# MAGIC %run ./LocationWriter

# COMMAND ----------

# MAGIC %run ./DealAttributesWriter

# COMMAND ----------

# MAGIC %run ./TraderWriter

# COMMAND ----------

# MAGIC %run ./UnitOfMeasureWriter

# COMMAND ----------

# MAGIC %run ./FACT/FactWriter
