# Databricks notebook source
# MAGIC %run ./../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./../DatasetWriter

# COMMAND ----------

# MAGIC %run ./VALIDATOR/pre_validator/duplicate/UnitOfMeasureDuplicatePreValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/UNIQUENESS/UnitOfMeasureUniquenessPostValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/duplicate/UnitOfMeasureDuplicatePostValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/IFNULL/UnitOfMeasureifnullPostValidator

# COMMAND ----------

class UnitOfMeasureWriter(DatasetWriter):
    DELETE_DIM_UNIT_OF_MEASURE_STAGE_SQL = """DELETE from tsa_stage.dim_unit_of_measure_stage WHERE src_sys_name = ?"""
    INSERT_DIM_UNIT_OF_MEASURE_SQL = """
    INSERT INTO tsa_curated.dim_unit_of_measure
    (
    unit_of_measure_ck,
    record_created_dttm,
    record_updated_dttm,
    src_sys_name,
    SRC_SYS_UNIT_OF_MEASURE_NK,
    STD_UNIT_OF_MEASURE_SYMBOL_CODE,
    STD_UNIT_OF_MEASURE_DESCRIPTION
    )
    SELECT unit_of_measure_ck,
    current_timestamp record_created_dttm,
    current_timestamp record_updated_dttm,
    src_sys_name,
    SRC_SYS_UNIT_OF_MEASURE_NK,
    STD_UNIT_OF_MEASURE_SYMBOL_CODE,
    STD_UNIT_OF_MEASURE_DESCRIPTION 
    FROM tsa_stage.dim_unit_of_measure_stage stage
    WHERE NOT EXISTS
    (SELECT 1 
    FROM tsa_curated.dim_unit_of_measure main 
    WHERE main.unit_of_measure_ck = stage.unit_of_measure_ck ) and stage.src_sys_name = ? 
    """
    
    UPDATE_DIM_UNIT_OF_MEASURE_SQL = """UPDATE main_table 
    SET main_table.STD_UNIT_OF_MEASURE_SYMBOL_CODE =stage_table.STD_UNIT_OF_MEASURE_SYMBOL_CODE,
    main_table.STD_UNIT_OF_MEASURE_DESCRIPTION =stage_table.STD_UNIT_OF_MEASURE_DESCRIPTION,
    record_updated_dttm = current_timestamp
    FROM tsa_curated.dim_unit_of_measure main_table
    JOIN tsa_stage.dim_unit_of_measure_stage stage_table
    ON main_table.unit_of_measure_ck = stage_table.unit_of_measure_ck and stage_table.src_sys_name = ? """
    
        
    def write(df, SOURCE_ETRM, metricDict):
        executePyOdbcQueryWithParam1(UnitOfMeasureWriter.DELETE_DIM_UNIT_OF_MEASURE_STAGE_SQL, SOURCE_ETRM)
        start = time.time()
    
        df = df.withColumn("SRC_SYS_UNIT_OF_MEASURE_NK",df.SRC_SYS_UNIT_OF_MEASURE_NK.cast('string'))  
      
        df = df.select(
          col("UNIT_OF_MEASURE_CK"),
          col("RECORD_CREATED_DTTM"),
          col("SRC_SYS_NAME"),
          col("SRC_SYS_UNIT_OF_MEASURE_NK"),
          col("STD_UNIT_OF_MEASURE_SYMBOL_CODE"),
          col("STD_UNIT_OF_MEASURE_DESCRIPTION")
          )
            
        writeDatasetSynapseConnector(spark, df,"tsa_stage.dim_unit_of_measure_stage")
        
        
        end = time.time()
        time_taken = end - start
        metricDict["uom_writer_stage_load_time_taken_in_sec"] = time_taken 
        
        status = validateDuplicateUOM(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
          
        start = time.time()
        row_affected = executePyOdbcQueryWithParam1(UnitOfMeasureWriter.UPDATE_DIM_UNIT_OF_MEASURE_SQL, SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["uom_writer_update_sql_time_taken_in_sec"] = time_taken 
        metricDict["update_sql_rows_affected"] = row_affected 
        
        start = time.time()
        row_affected = executePyOdbcQueryWithParam1(UnitOfMeasureWriter.INSERT_DIM_UNIT_OF_MEASURE_SQL, SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["uom_writer_insert_sql_time_taken_in_sec"] = time_taken 
        metricDict["insert_sql_rows_affected"] = row_affected
        
        status = validateUniqueUnitOfMeasure(SOURCE_ETRM)
        if status != "SUCCESS":
          print("Uniqueness validation ....")
          raise Exception("UNIQUENESS_TEST_FAILED")
        
        print("starting SK Duplicate check")
        status = validateDuplicateUOMSK(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
        
        status = validateIfNullLogicUOM(SOURCE_ETRM)
        if status != "SUCCESS":
          print("IF NULL LOGIC has failed")
          warnings.warn("Warning : IF NULL LOGIC has failed")
          
        
        return ("SUCCESS", metricDict)

