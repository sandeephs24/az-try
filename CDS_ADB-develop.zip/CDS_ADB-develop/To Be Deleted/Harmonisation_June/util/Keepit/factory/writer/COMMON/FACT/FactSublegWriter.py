# Databricks notebook source
# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

# MAGIC %run ./FactMirrorHandler

# COMMAND ----------

# MAGIC %run ./../VALIDATOR/pre_validator/duplicate/FactSubLegDuplicatePreValidator

# COMMAND ----------

# MAGIC %run ./../VALIDATOR/pre_validator/OrphanCheck/FactLegOrphanCheckPreValidator

# COMMAND ----------

# MAGIC %run ./../VALIDATOR/post_validator/UNIQUENESS/FactSubLegUniquenessPostValidator

# COMMAND ----------

# MAGIC %run ./../../DatasetWriter

# COMMAND ----------

class FactSublegWriter(DatasetWriter):
    DELETE_FACT_DEAL_SUB_LEG_STAGE_SQL = """DELETE from tsa_stage.fact_deal_sub_leg_stage WHERE src_sys_name = ?"""
    
    UPDATE_SQL_FOR_EXISTING_DEALS_SUB_LEG = """
      with main_table_view as(
	  select a.deal_attributes_ck, 
	  a.version_value, 
	  a.deal_qty,
      a.counterparty_sk, 
      a.shell_trading_party_sk,
	  a.RECORD_UPDATED_DTTM, 
	  case 
		when b.version_value is null then -99999
		else b.version_value + 1
	  end version_to_be_updated
	  from FACT_TABLE_TOKEN a
	  left join (select deal_attributes_ck,version_value from(
	  select deal_attributes_ck,version_value, rank() 
	  over(partition by deal_attributes_ck order by 
	  version_value desc) rnk
	  from FACT_TABLE_TOKEN
	  ) v1 where rnk = 2) b on
	  a.deal_attributes_ck = b.deal_attributes_ck  
	  where 
	  src_sys_name = ?
	  and a.version_value = 1
	  )
	update main_table set version_value = version_to_be_updated, RECORD_UPDATED_DTTM = current_timestamp 
    FROM tsa_stage.fact_deal_sub_leg_stage stage_table
    join main_table_view main_table on stage_table.deal_attributes_ck = main_table.deal_attributes_ck
    left join tsa_curated.dim_party dim_party_table1 ON stage_table.counterparty_ck =  dim_party_table1.party_ck
    left join tsa_curated.dim_party dim_party_table2 ON stage_table.shell_trading_party_ck =  dim_party_table2.party_ck 
    where main_table.version_value = 1
    and stage_table.src_sys_name = ?
    and (main_table.deal_qty <> stage_table.deal_qty
	or main_table.counterparty_sk <> dim_party_table1.party_sk 
    or main_table.shell_trading_party_sk <> dim_party_table2.party_sk)
    and exists(
    select 1 from FACT_TABLE_TOKEN 
    where deal_attributes_ck = stage_table.deal_attributes_ck
    )
    """
    
    UPDATE_SQL_FOR_EXISTING_DEALS_SUB_LEG2 = """
    with main_table_view as( 
	  select a.deal_attributes_ck, a.version_value,a.RECORD_UPDATED_DTTM, 
	  a.SRC_SYS_DEAL_HEADER_KEY,
	  case 
		when b.version_value is null then -99999
		else b.version_value + 1
	  end version_to_be_updated
	  from FACT_TABLE_TOKEN a
	  left join (select deal_attributes_ck,version_value from(
	  select deal_attributes_ck,version_value, rank() 
	  over(partition by deal_attributes_ck order by 
	  version_value desc) rnk
	  from FACT_TABLE_TOKEN 
	  ) v1 where rnk = 2) b on
	  a.deal_attributes_ck = b.deal_attributes_ck  
	  where 
	  src_sys_name = ?
	  and a.version_value = 1
	  ) 
	update main_table set version_value = version_to_be_updated, RECORD_UPDATED_DTTM = current_timestamp
    FROM tsa_stage.fact_deal_sub_leg_stage stage_table
    join main_table_view main_table on stage_table.deal_attributes_ck <> main_table.deal_attributes_ck
	and main_table.SRC_SYS_DEAL_HEADER_KEY = stage_table.SRC_SYS_DEAL_HEADER_KEY
	 where main_table.version_value = 1
    and stage_table.src_sys_name = ?
       and exists(
    select 1 from FACT_TABLE_TOKEN a
    where  a.deal_attributes_ck <> stage_table.deal_attributes_ck
	and a.SRC_SYS_DEAL_HEADER_KEY = stage_table.SRC_SYS_DEAL_HEADER_KEY) 
	and not exists(
	 select 1 from FACT_TABLE_TOKEN a
	where  a.deal_attributes_ck = stage_table.deal_attributes_ck
	and a.SRC_SYS_DEAL_HEADER_KEY = stage_table.SRC_SYS_DEAL_HEADER_KEY
    ) 
    """
    
    
    
    
    INSERT_SQL_FOR_EXISTING_DEALS_SUB_LEG = """
    with latest_version_main_record as(
    select * from 
    (
    select a.*,
    row_number() over(partition by DEAL_ATTRIBUTES_CK order by version_value desc) row_number
    from FACT_TABLE_TOKEN a
    )V where row_number = 1 and src_sys_name = ?
    )
    INSERT INTO FACT_TABLE_TOKEN
    (
    RECORD_CREATED_DTTM,
	RECORD_UPDATED_DTTM,
	VERSION_VALUE,
	SRC_SYS_NAME,
	DEAL_ATTRIBUTES_CK,
	EXECUTION_DATE_SK,
	TRADE_CREATION_DATE_SK,
	COMMITMENT_DATE_SK,
	PARCEL_DATE_SK,
	COUNTERPARTY_SK,
	SHELL_TRADING_PARTY_SK,
	DEAL_ATTRIBUTES_SK,
	TRADER_SK,
	DEAL_BROKER_SK,
	COMMODITY_SK,
	LOADING_LOCATION_SK,
	DISCHARGE_LOCATION_SK,
	DELIVERY_START_DATE_SK,
	DELIVERY_END_DATE_SK,
	DEAL_UNIT_OF_MEASURE_SK,
	PRICING_UNIT_OF_MEASURE_SK,
	DEAL_CCY_SK,
	CCY_DEAL_VALUE,
	GBP_DEAL_VALUE,
	USD_DEAL_VALUE,
	EUR_DEAL_VALUE,
	DEAL_QTY,
	PRICE_QTY,
	CMD_DEAL_QTY,
    DEAL_SUB_LEG_MULTIPLIER,
    SRC_SYS_DEAL_HEADER_KEY
    )
    SELECT
    current_timestamp RECORD_CREATED_DTTM,
    current_timestamp RECORD_UPDATED_DTTM,
    1 as VERSION_VALUE,
    main_table.SRC_SYS_NAME,
	main_table.DEAL_ATTRIBUTES_CK,
	main_table.EXECUTION_DATE_SK,
	main_table.TRADE_CREATION_DATE_SK,
    main_table.COMMITMENT_DATE_SK,
    main_table.PARCEL_DATE_SK,
	CASE 
      when stage_table.counterparty_ck = '' then -1
      when dim_party_table1.party_sk is null then -2
      else dim_party_table1.party_sk
    END
    AS COUNTERPARTY_SK,
    CASE 
      when stage_table.SHELL_TRADING_PARTY_CK = '' then -1
      when dim_party_table2.party_sk is null then -2
      else dim_party_table2.party_sk
    END
    AS SHELL_TRADING_PARTY_SK,
	main_table.DEAL_ATTRIBUTES_SK,
	main_table.TRADER_SK,
	main_table.DEAL_BROKER_SK,
    main_table.COMMODITY_SK,
	main_table.LOADING_LOCATION_SK,
	main_table.DISCHARGE_LOCATION_SK,
	main_table.DELIVERY_START_DATE_SK,
	main_table.DELIVERY_END_DATE_SK,
	main_table.DEAL_UNIT_OF_MEASURE_SK,
	main_table.PRICING_UNIT_OF_MEASURE_SK,
	main_table.DEAL_CCY_SK,
	CASE WHEN main_table.deal_qty <> stage_table.deal_qty THEN stage_table.CCY_DEAL_VALUE ELSE main_table.CCY_DEAL_VALUE END,
	CASE WHEN main_table.deal_qty <> stage_table.deal_qty THEN stage_table.GBP_DEAL_VALUE ELSE main_table.GBP_DEAL_VALUE END,
	CASE WHEN main_table.deal_qty <> stage_table.deal_qty THEN stage_table.USD_DEAL_VALUE ELSE main_table.USD_DEAL_VALUE END,
	CASE WHEN main_table.deal_qty <> stage_table.deal_qty THEN stage_table.EUR_DEAL_VALUE ELSE main_table.EUR_DEAL_VALUE END,
	CASE WHEN main_table.deal_qty <> stage_table.deal_qty THEN stage_table.DEAL_QTY ELSE main_table.DEAL_QTY END,
	CASE WHEN main_table.deal_qty <> stage_table.deal_qty THEN stage_table.PRICE_QTY ELSE main_table.PRICE_QTY END,
	CASE WHEN main_table.deal_qty <> stage_table.deal_qty THEN stage_table.CMD_DEAL_QTY ELSE main_table.CMD_DEAL_QTY END,
    main_table.DEAL_SUB_LEG_MULTIPLIER,
    main_table.SRC_SYS_DEAL_HEADER_KEY
    FROM tsa_stage.fact_deal_sub_leg_stage stage_table
    join latest_version_main_record main_table on stage_table.deal_attributes_ck = main_table.deal_attributes_ck
    left join tsa_curated.dim_party dim_party_table1 ON stage_table.counterparty_ck =  dim_party_table1.party_ck
    left join tsa_curated.dim_party dim_party_table2 ON stage_table.shell_trading_party_ck =  dim_party_table2.party_ck
    where main_table.row_number = 1
    and stage_table.src_sys_name = ? 
    and (main_table.deal_qty <> stage_table.deal_qty
    or main_table.counterparty_sk <> dim_party_table1.party_sk 
    or main_table.shell_trading_party_sk <> dim_party_table2.party_sk
    )
    and exists(
    select 1 from FACT_TABLE_TOKEN 
    where deal_attributes_ck = stage_table.deal_attributes_ck
    )
    """

    INSERT_SQL_FOR_NEW_DEALS_SUB_LEG = """
    INSERT INTO FACT_TABLE_TOKEN
    (
    RECORD_CREATED_DTTM,
	RECORD_UPDATED_DTTM,
	VERSION_VALUE,
	SRC_SYS_NAME,
	DEAL_ATTRIBUTES_CK,
	EXECUTION_DATE_SK,
	TRADE_CREATION_DATE_SK,
	COMMITMENT_DATE_SK,
	PARCEL_DATE_SK,
	COUNTERPARTY_SK,
	SHELL_TRADING_PARTY_SK,
	DEAL_ATTRIBUTES_SK,
	TRADER_SK,
	DEAL_BROKER_SK,
	COMMODITY_SK,
	LOADING_LOCATION_SK,
	DISCHARGE_LOCATION_SK,
	DELIVERY_START_DATE_SK,
	DELIVERY_END_DATE_SK,
	DEAL_UNIT_OF_MEASURE_SK,
	PRICING_UNIT_OF_MEASURE_SK,
	DEAL_CCY_SK,
	CCY_DEAL_VALUE,
	GBP_DEAL_VALUE,
	USD_DEAL_VALUE,
	EUR_DEAL_VALUE,
	DEAL_QTY,
	PRICE_QTY,
	CMD_DEAL_QTY,
    DEAL_SUB_LEG_MULTIPLIER,
    SRC_SYS_DEAL_HEADER_KEY
    )
    SELECT
    current_timestamp RECORD_CREATED_DTTM,
	current_timestamp RECORD_UPDATED_DTTM,
	1 as VERSION_VALUE,
	stage_table.SRC_SYS_NAME,
	stage_table.DEAL_ATTRIBUTES_CK,
	CASE 
      when stage_table.execution_date_ck = '' then -1
      when date1.date_sk is null then -2
      else date1.date_sk
    END
    AS EXECUTION_DATE_SK,
    CASE 
      when stage_table.trade_creation_date_ck = '' then -1 
      when date2.date_sk is null then -2
      else date2.date_sk
    END
    AS TRADE_CREATION_DATE_SK,
    CASE 
      when stage_table.commitment_date_ck = '' then -1
      when date3.date_sk is null then -2
      else date3.date_sk
    END
    AS COMMITMENT_DATE_SK,
    CASE 
      when stage_table.parcel_date_ck = '' then -1
      when date4.date_sk is null then -2
      else date4.date_sk
    END
    AS PARCEL_DATE_SK,
	CASE 
      when stage_table.counterparty_ck = '' then -1
      when party1.party_sk is null then -2
      else party1.party_sk
    END
    AS COUNTERPARTY_SK,
    CASE 
      when stage_table.SHELL_TRADING_PARTY_CK = '' then -1
      when party2.party_sk is null then -2
      else party2.party_sk
    END
    AS SHELL_TRADING_PARTY_SK,
    CASE 
      when stage_table.deal_attributes_ck = '' then -1
      when attr.DEAL_ATTRIBUTES_SK is null then -2
      else attr.DEAL_ATTRIBUTES_SK
    END
    AS DEAL_ATTRIBUTES_SK,
    CASE 
      when stage_table.trader_ck = '' then -1
      when trader.TRADER_SK is null then -2
      else trader.TRADER_SK
    END
    AS TRADER_SK,
    CASE 
      when stage_table.deal_broker_ck = '' then -1
      when broker.BROKER_SK is null then -2
      else broker.BROKER_SK
    END
    AS DEAL_BROKER_SK,
    CASE 
      when stage_table.commodity_ck = '' then -1
      when commodity.commodity_sk is null then -2
      else commodity.commodity_sk
    END
    AS commodity_sk,
    CASE 
      when  (stage_table.src_sys_name ='ENDUR_GPNA' or stage_table.src_sys_name ='ENDUR_SLMT') then -3
      when (stage_table.SRC_SYS_NAME='NUCLEUS' and stage_table.LOADING_LOCATION_CK = 'NUCLEUS_INVALID') then -3
      when (stage_table.SRC_SYS_NAME='ALIGNE' and stage_table.LOADING_LOCATION_CK = 'ALIGNE_INVALID') then -3
      when stage_table.LOADING_LOCATION_CK = '' then -1
      when location1.location_sk is null then -2
      else location1.location_sk
    END
    AS LOADING_LOCATION_SK,
	CASE 
      when stage_table.DISCHARGE_LOCATION_CK = '' then -1
      when location2.location_sk is null then -2
      else location2.location_sk
    END
    AS DISCHARGE_LOCATION_SK,
	CASE 
      when stage_table.DELIVERY_START_DATE_CK = '' then -1
      when date5.date_sk is null then -2
      else date5.date_sk
    END
    AS DELIVERY_START_DATE_SK,
	CASE 
      when stage_table.DELIVERY_END_DATE_CK = '' then -1
      when date6.date_sk is null then -2
      else date6.date_sk
    END
    AS DELIVERY_END_DATE_SK,
	CASE 
      when stage_table.DEAL_UNIT_OF_MEASURE_cK = '' then -1
      when uom1.UNIT_OF_MEASURE_SK is null then -2
      else uom1.UNIT_OF_MEASURE_SK
    END
    AS DEAL_UNIT_OF_MEASURE_SK,
	CASE 
      when stage_table.PRICING_UNIT_OF_MEASURE_CK = '' then -1
      when uom2.UNIT_OF_MEASURE_SK is null then -2
      else uom2.UNIT_OF_MEASURE_SK
    END
    AS PRICING_UNIT_OF_MEASURE_SK,
	CASE 
      when stage_table.DEAL_CCY_CK = '' then -1
      when ccy.CURRENCY_CK  is null then -2
      else ccy.CURRENCY_SK
    END
    AS DEAL_CCY_SK,
    stage_table.CCY_DEAL_VALUE,
	stage_table.GBP_DEAL_VALUE,
	stage_table.USD_DEAL_VALUE,
	stage_table.EUR_DEAL_VALUE,
	stage_table.DEAL_QTY,
	stage_table.PRICE_QTY,
	stage_table.CMD_DEAL_QTY,
    stage_table.DEAL_SUB_LEG_MULTIPLIER,
    stage_table.SRC_SYS_DEAL_HEADER_KEY
    FROM tsa_stage.fact_deal_sub_leg_stage stage_table
    left join tsa_curated.dim_date date1 
      on stage_table.execution_date_ck = date1.date_ck
    left join tsa_curated.dim_date date2 
      on stage_table.trade_creation_date_ck = date2.date_ck
    left join tsa_curated.dim_date date3 
      on stage_table.COMMITMENT_DATE_CK = date3.date_ck
    left join tsa_curated.dim_date date4 
      on stage_table.PARCEL_DATE_CK = date4.date_ck
    left join tsa_curated.dim_party party1 
      on stage_table.counterparty_ck = party1.party_ck
    left join tsa_curated.dim_party party2 
      on stage_table.SHELL_TRADING_PARTY_CK = party2.party_ck
    left join tsa_curated.dim_deal_attributes attr 
      on stage_table.deal_attributes_ck = attr.deal_attributes_ck and YEAR(attr.VALID_TO_DATE) = 9999
    left join tsa_curated.dim_trader trader 
      on stage_table.trader_ck = trader.trader_ck
    left join tsa_curated.dim_broker broker 
      on stage_table.deal_broker_ck = broker.broker_ck
    left join tsa_curated.dim_commodity commodity 
      on stage_table.commodity_ck = commodity.commodity_ck
    left join tsa_curated.dim_location location1 
      on stage_table.LOADING_LOCATION_CK = location1.location_ck
    left join tsa_curated.dim_location location2 
      on stage_table.DISCHARGE_LOCATION_CK = location2.location_ck
    left join tsa_curated.dim_date date5 
      on stage_table.DELIVERY_START_DATE_CK = date5.date_ck
    left join tsa_curated.dim_date date6 
      on stage_table.DELIVERY_END_DATE_CK = date6.date_ck
    left join tsa_curated.dim_date date7 
      on stage_table.COMMITMENT_DATE_CK = date7.date_ck
    left join tsa_curated.dim_date date8 
      on stage_table.PARCEL_DATE_CK = date8.date_ck
    left join tsa_curated.dim_unit_of_measure uom1
      on stage_table.DEAL_UNIT_OF_MEASURE_CK = uom1.unit_of_measure_ck
    left join tsa_curated.dim_unit_of_measure uom2
      on stage_table.PRICING_UNIT_OF_MEASURE_CK = uom2.unit_of_measure_ck
    left join tsa_curated.dim_currency ccy
      on stage_table.DEAL_CCY_CK = ccy.currency_ck
    where stage_table.src_sys_name = ?
    and not exists(
    select 1 from FACT_TABLE_TOKEN where deal_attributes_ck = stage_table.deal_attributes_ck
    )
    """
    
    
    def write(df, SOURCE_ETRM, write_to_mirror_table, metricDict):
      import time
      executePyOdbcQueryWithParam1(FactSublegWriter.DELETE_FACT_DEAL_SUB_LEG_STAGE_SQL,SOURCE_ETRM)
      start = time.time()
           
      df = df.withColumn("CCY_DEAL_VALUE",df.CCY_DEAL_VALUE.cast('decimal(15,4)'))
      df = df.withColumn("GBP_DEAL_VALUE",df.GBP_DEAL_VALUE.cast('decimal(15,4)'))
      df = df.withColumn("USD_DEAL_VALUE",df.USD_DEAL_VALUE.cast('decimal(15,4)'))
      df = df.withColumn("EUR_DEAL_VALUE",df.EUR_DEAL_VALUE.cast('decimal(15,4)'))
      df = df.withColumn("DEAL_QTY",df.DEAL_QTY.cast('decimal(15,4)'))
      df = df.withColumn("PRICE_QTY",df.PRICE_QTY.cast('decimal(15,4)'))
      df = df.withColumn("CMD_DEAL_QTY",df.CMD_DEAL_QTY.cast('decimal(15,4)'))
      
      df = df.withColumn("source_last_date1",df.source_last_date1.cast('date'))
      df = df.withColumn("source_last_date2",df.source_last_date2.cast('date'))
      df = df.withColumn("source_last_date3",df.source_last_date3.cast('date'))
      df = df.withColumn("SRC_SYS_DEAL_HEADER_KEY",df.SRC_SYS_DEAL_HEADER_KEY.cast('string'))
      
      df = df.withColumn("COUNTERPARTY_CK",df.COUNTERPARTY_CK.cast('string'))
      df = df.withColumn("SHELL_TRADING_PARTY_CK",df.SHELL_TRADING_PARTY_CK.cast('string'))
      df = df.withColumn("TRADER_CK",df.TRADER_CK.cast('string'))
      
      
      df = df.withColumn("DEAL_BROKER_CK",df.DEAL_BROKER_CK.cast('string'))
      df = df.withColumn("COMMODITY_CK",df.COMMODITY_CK.cast('string'))
      df = df.withColumn("LOADING_LOCATION_CK",df.LOADING_LOCATION_CK.cast('string'))
      
      df = df.withColumn("DISCHARGE_LOCATION_CK",df.DISCHARGE_LOCATION_CK.cast('string'))
      df = df.withColumn("DELIVERY_START_DATE_CK",df.DELIVERY_START_DATE_CK.cast('string'))
      df = df.withColumn("DELIVERY_END_DATE_CK",df.DELIVERY_END_DATE_CK.cast('string'))
      
      df = df.withColumn("DEAL_UNIT_OF_MEASURE_CK",df.DEAL_UNIT_OF_MEASURE_CK.cast('string'))
      df = df.withColumn("PRICING_UNIT_OF_MEASURE_CK",df.PRICING_UNIT_OF_MEASURE_CK.cast('string'))
      df = df.withColumn("DEAL_CCY_CK",df.DEAL_CCY_CK.cast('string'))
      df = df.withColumn("DEAL_SUB_LEG_MULTIPLIER",df.DEAL_SUB_LEG_MULTIPLIER.cast('int'))
      
      df = df.select(
      col("RECORD_CREATED_DTTM"),
      col("SRC_SYS_NAME"),
      col("DEAL_ATTRIBUTES_CK"),
      col("EXECUTION_DATE_CK"),
      col("TRADE_CREATION_DATE_CK"),
      col("COMMITMENT_DATE_CK"),
      col("PARCEL_DATE_CK"),  
      col("COUNTERPARTY_CK"),  
      col("SHELL_TRADING_PARTY_CK"),
      col("TRADER_CK"),
      col("DEAL_BROKER_CK"),
      col("COMMODITY_CK"),
      col("LOADING_LOCATION_CK"),
      col("DISCHARGE_LOCATION_CK"),
      col("DELIVERY_START_DATE_CK"),
      col("DELIVERY_END_DATE_CK"),
      col("DEAL_UNIT_OF_MEASURE_CK"),
      col("PRICING_UNIT_OF_MEASURE_CK"),
      col("DEAL_CCY_CK"),
      col("CCY_DEAL_VALUE"),
      col("GBP_DEAL_VALUE"),
      col("USD_DEAL_VALUE"),
      col("EUR_DEAL_VALUE"),
      col("DEAL_QTY"),  
      col("PRICE_QTY"),
      col("CMD_DEAL_QTY"),
      col("DEAL_SUB_LEG_MULTIPLIER"),
      col("source_last_date1"),
      col("source_last_date2"),
      col("source_last_date3"),
      col("SRC_SYS_DEAL_HEADER_KEY")
      )
      
      df.printSchema()
      df.show()
      
      writeDatasetSynapseConnector(spark, df,"tsa_stage.fact_deal_sub_leg_stage")
      print('Here1')
      #fact_deal_sub_leg_stage
      end = time.time()
      time_taken = end - start
      metricDict["fact_writer_subleg_stage_load_time_taken_in_sec"] = time_taken 
      status = validateDuplicateFactSubLeg(SOURCE_ETRM)
      if status != "SUCCESS":
        print("duplicate validation ....")
        raise Exception("DUPLICATE_RECORDS_FOUND_SUB_LEG")
      orphan_status = validateOrphanFactSubLeg(SOURCE_ETRM)
      """if orphan_status != "SUCCESS":
        print("Orphan Check validation ....")
        raise Exception("ORPHAN_HEADER_RECORDS_FOUND_SUB_LEG")"""
        
      metricDict = runLoadForSubleg(SOURCE_ETRM, write_to_mirror_table, metricDict)
      
     
      
      return metricDict


# COMMAND ----------

def runLoadForSubleg(SOURCE_ETRM, write_to_mirror_table, metricDict):
    
  if (SOURCE_ETRM =='ENDUR_GPNA' or SOURCE_ETRM =='ENDUR_SLMT'):
    UPDATE_SQL_FOR_EXISTING_DEALS_SUB_LEG = replaceTableToken(FactSublegWriter.UPDATE_SQL_FOR_EXISTING_DEALS_SUB_LEG, write_to_mirror_table)
    executeAndLogMetric(UPDATE_SQL_FOR_EXISTING_DEALS_SUB_LEG,SOURCE_ETRM,metricDict,"update_sql_for_existing_deals_subleg" )
    INSERT_SQL_FOR_EXISTING_DEALS_SUB_LEG = replaceTableToken(FactSublegWriter.INSERT_SQL_FOR_EXISTING_DEALS_SUB_LEG, write_to_mirror_table)
    executeAndLogMetric(INSERT_SQL_FOR_EXISTING_DEALS_SUB_LEG,SOURCE_ETRM,metricDict,"insert_sql_for_existing_deals_subleg" )
    UPDATE_SQL_FOR_EXISTING_DEALS_SUB_LEG2 = replaceTableToken(FactSublegWriter.UPDATE_SQL_FOR_EXISTING_DEALS_SUB_LEG2, write_to_mirror_table)
    executePyOdbcQueryWithParam2(UPDATE_SQL_FOR_EXISTING_DEALS_SUB_LEG2,SOURCE_ETRM, SOURCE_ETRM)

    INSERT_SQL_FOR_NEW_DEALS_SUB_LEG = replaceTableToken(FactSublegWriter.INSERT_SQL_FOR_NEW_DEALS_SUB_LEG, write_to_mirror_table)
    start = time.time()
    row_affected = executePyOdbcQueryWithParam1(INSERT_SQL_FOR_NEW_DEALS_SUB_LEG, SOURCE_ETRM)
    end = time.time()
    time_taken = end - start
    metricDict["insert_new_subleg_time_taken_in_sec"] = time_taken 
    metricDict["insert_new_subleg_rows_affected"] = row_affected
    
  else:

    UPDATE_SQL_FOR_EXISTING_DEALS_SUB_LEG = replaceTableToken(FactSublegWriter.UPDATE_SQL_FOR_EXISTING_DEALS_SUB_LEG, write_to_mirror_table)
    executeAndLogMetric(UPDATE_SQL_FOR_EXISTING_DEALS_SUB_LEG,SOURCE_ETRM,metricDict,"update_sql_for_existing_deals_subleg" )
    INSERT_SQL_FOR_EXISTING_DEALS_SUB_LEG = replaceTableToken(FactSublegWriter.INSERT_SQL_FOR_EXISTING_DEALS_SUB_LEG, write_to_mirror_table)
    executeAndLogMetric(INSERT_SQL_FOR_EXISTING_DEALS_SUB_LEG,SOURCE_ETRM,metricDict,"insert_sql_for_existing_deals_subleg" )

    INSERT_SQL_FOR_NEW_DEALS_SUB_LEG = replaceTableToken(FactSublegWriter.INSERT_SQL_FOR_NEW_DEALS_SUB_LEG, write_to_mirror_table)
    start = time.time()
    row_affected = executePyOdbcQueryWithParam1(INSERT_SQL_FOR_NEW_DEALS_SUB_LEG, SOURCE_ETRM)
    end = time.time()
    time_taken = end - start
    metricDict["insert_new_subleg_time_taken_in_sec"] = time_taken 
    metricDict["insert_new_subleg_rows_affected"] = row_affected

  return metricDict

# COMMAND ----------

    def postProcessWriteToCurrentMirrorSubleg(SOURCE_ETRM, write_to_mirror_table, metricDict):
      metricDict = runLoadForSubleg(SOURCE_ETRM, write_to_mirror_table, metricDict)
      return metricDict

# COMMAND ----------

    def writeAfterDealAttrSCDFactSubleg(SOURCE_ETRM, write_to_mirror_table, metricDict):
      UPDATE_SQL_FOR_POST_DEAL_ATTR_SUBLEG = """
      with main_table_view as(
	  select a.deal_attributes_ck,a.deal_attributes_sk, a.version_value,
	  a.RECORD_UPDATED_DTTM, 
	  case 
		when b.version_value is null then -99999
		else b.version_value + 1
	  end version_to_be_updated
	  from FACT_TABLE_TOKEN a
	  left join (select deal_attributes_ck,version_value from(
	  select deal_attributes_ck,version_value, rank() 
	  over(partition by deal_attributes_ck order by 
	  version_value desc) rnk
	  from FACT_TABLE_TOKEN
	  ) v1 where rnk = 2) b on
	  a.deal_attributes_ck = b.deal_attributes_ck  
	  where 
	  src_sys_name = ?
	  and a.version_value = 1
	  ) 
      update main_table set version_value = version_to_be_updated, RECORD_UPDATED_DTTM = current_timestamp 
      from tsa_curated.dim_deal_attributes attr 
      ,main_table_view main_table
      where year(valid_to_date) = '9999'
      and (src_sys_deal_leg_key is not null and src_sys_deal_leg_key <> '')
      and (src_sys_deal_sub_leg_key is not null and src_sys_deal_sub_leg_key <> '')
      and main_table.deal_attributes_ck = attr.deal_attributes_ck
      and main_table.version_value = 1
      and main_table.deal_attributes_sk <> attr.deal_attributes_sk
      and attr.src_sys_name = ?
      """ 
      
      INSERT_SQL_FOR_POST_DEAL_ATTR_SUBLEG = """
      with latest_version_main_record as(
      select * from 
      (
      select  a.*,
      row_number() over(partition by DEAL_ATTRIBUTES_CK order by version_value desc) row_number
      from FACT_TABLE_TOKEN a
      )V where row_number = 1 and src_sys_name = ?
      )
      INSERT INTO FACT_TABLE_TOKEN
      (
      RECORD_CREATED_DTTM,
      RECORD_UPDATED_DTTM,
      VERSION_VALUE,
      SRC_SYS_NAME,
      DEAL_ATTRIBUTES_CK,
      EXECUTION_DATE_SK,
      TRADE_CREATION_DATE_SK,
      COMMITMENT_DATE_SK,
      PARCEL_DATE_SK,
      COUNTERPARTY_SK,
      SHELL_TRADING_PARTY_SK,
      DEAL_ATTRIBUTES_SK,
      TRADER_SK,
      DEAL_BROKER_SK,
      COMMODITY_SK,
      LOADING_LOCATION_SK,
      DISCHARGE_LOCATION_SK,
      DELIVERY_START_DATE_SK,
      DELIVERY_END_DATE_SK,
      DEAL_UNIT_OF_MEASURE_SK,
      PRICING_UNIT_OF_MEASURE_SK,
      DEAL_CCY_SK,
      CCY_DEAL_VALUE,
      GBP_DEAL_VALUE,
      USD_DEAL_VALUE,
      EUR_DEAL_VALUE,
      DEAL_QTY,
      PRICE_QTY,
      CMD_DEAL_QTY,
      DEAL_SUB_LEG_MULTIPLIER,
      SRC_SYS_DEAL_HEADER_KEY
      )
      SELECT
      current_timestamp RECORD_CREATED_DTTM,
      current_timestamp RECORD_UPDATED_DTTM,
      1 as VERSION_VALUE,
      main_table.SRC_SYS_NAME,
      main_table.DEAL_ATTRIBUTES_CK,
      main_table.EXECUTION_DATE_SK,
      main_table.TRADE_CREATION_DATE_SK,
      main_table.COMMITMENT_DATE_SK,
      main_table.PARCEL_DATE_SK,
      main_table.COUNTERPARTY_SK,
      main_table.SHELL_TRADING_PARTY_SK,
      attr.DEAL_ATTRIBUTES_SK,
      main_table.TRADER_SK,
      main_table.DEAL_BROKER_SK,
      main_table.COMMODITY_SK,
      main_table.LOADING_LOCATION_SK,
      main_table.DISCHARGE_LOCATION_SK,
      main_table.DELIVERY_START_DATE_SK,
      main_table.DELIVERY_END_DATE_SK,
      main_table.DEAL_UNIT_OF_MEASURE_SK,
      main_table.PRICING_UNIT_OF_MEASURE_SK,
      main_table.DEAL_CCY_SK,
      main_table.CCY_DEAL_VALUE,
      main_table.GBP_DEAL_VALUE,
      main_table.USD_DEAL_VALUE,
      main_table.EUR_DEAL_VALUE,
      main_table.DEAL_QTY,
      main_table.PRICE_QTY,
      main_table.CMD_DEAL_QTY,
      main_table.DEAL_SUB_LEG_MULTIPLIER,
      main_table.SRC_SYS_DEAL_HEADER_KEY
      FROM tsa_curated.dim_deal_attributes attr 
      ,latest_version_main_record main_table
      where year(valid_to_date) = '9999'
      and (src_sys_deal_leg_key is not null and src_sys_deal_leg_key <> '')
      and (src_sys_deal_sub_leg_key is not null and src_sys_deal_sub_leg_key <> '')
      and main_table.deal_attributes_ck = attr.deal_attributes_ck
      and main_table.row_number = 1
      and main_table.deal_attributes_sk <> attr.deal_attributes_sk
      and attr.src_sys_name = ?
      """
      
      UPDATE_SQL_FOR_POST_DEAL_ATTR_SUBLEG = replaceTableToken(UPDATE_SQL_FOR_POST_DEAL_ATTR_SUBLEG, write_to_mirror_table)
      executeAndLogMetric(UPDATE_SQL_FOR_POST_DEAL_ATTR_SUBLEG,SOURCE_ETRM,metricDict,"update_sql_post_deals_subleg" )

      INSERT_SQL_FOR_POST_DEAL_ATTR_SUBLEG = replaceTableToken(INSERT_SQL_FOR_POST_DEAL_ATTR_SUBLEG, write_to_mirror_table)
      executeAndLogMetric(INSERT_SQL_FOR_POST_DEAL_ATTR_SUBLEG,SOURCE_ETRM,metricDict,"insert_sql_post_deals_subleg" )
      return metricDict

# COMMAND ----------

  def executeAndLogMetric(SQL,SOURCE_ETRM,metricDict,metricName):
      import time
      start = time.time()
      row_affected = executePyOdbcQueryWithParam2(SQL,SOURCE_ETRM, SOURCE_ETRM)
      end = time.time()
      time_taken = end - start
      metricDict[metricName + "_time_taken_in_sec"] = time_taken 
      metricDict[metricName + "_rows_affected"] = row_affected
      return metricDict
