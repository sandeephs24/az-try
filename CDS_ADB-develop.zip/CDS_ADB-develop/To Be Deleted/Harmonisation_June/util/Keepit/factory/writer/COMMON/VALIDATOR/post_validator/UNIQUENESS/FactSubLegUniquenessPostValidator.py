# Databricks notebook source
# MAGIC %run ./UniquenessCheckUtil

# COMMAND ----------

def validateUniqueFactSubLeg(SOURCE_ETRM):
  
  SQL = """
  select fact_check.*,
        case when FACT_UNIQUE_CK = RECORD_COUNT
		THEN 'UNIQUESNESS TEST PASSED'
		ELSE 'UNIQUESNESS TEST FAILED' END AS TEST_STATUS
	FROM ( select src_sys_name,
          count(distinct (DEAL_ATTRIBUTES_CK + cast(version_value as nvarchar(10)))) as FACT_UNIQUE_CK
          ,count(1) as RECORD_COUNT
          current_timestamp as SQL_EXEC_DATETIME
          FROM [tsa_curated].[FACT_DEAL_SUB_LEG_MIRROR1]
		where src_sys_name = '{0}'
		)fact_check
  """.format(SOURCE_ETRM)
  
  status = runSQLandCheckUniqueness(SQL)
  return status
