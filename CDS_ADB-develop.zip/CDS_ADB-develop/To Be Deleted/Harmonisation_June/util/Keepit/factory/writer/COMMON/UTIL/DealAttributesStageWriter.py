# Databricks notebook source
# MAGIC %run ./DexProcessedDFToStageTable

# COMMAND ----------

# MAGIC %run ./EndurGPNAProcessedDFToStageTable

# COMMAND ----------

# MAGIC %run ./NucleusProcessedDFToStageTable

# COMMAND ----------

# MAGIC %run ./EndurSLMTProcessedDFToStageTable

# COMMAND ----------

# MAGIC %run ./AligneProcessedDFToStageTable

# COMMAND ----------

# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

def WriteToStage(df,SOURCE_ETRM, metricDict) :
        
    DELETE_DIM_DEAL_ATTRIBUTES_STAGE_SQL = """DELETE from tsa_stage.dim_deal_attributes_stage where src_sys_name = ?"""

    executePyOdbcQueryWithParam1(DELETE_DIM_DEAL_ATTRIBUTES_STAGE_SQL,SOURCE_ETRM)
    
    if (SOURCE_ETRM == 'ENDUR_GPNA'):
      
      (df,metricDict) = appendHeaderAndLegforEndurGPNA(df, metricDict)
      df = df.withColumn("VALID_FROM_DATE", lit(''))
      df = df.withColumn("VALID_TO_DATE", lit(''))
      
      df = df.withColumn("SRC_SYS_DEAL_HEADER_KEY",df.SRC_SYS_DEAL_HEADER_KEY.cast('string'))
      df = df.withColumn("PARENT_CONTRACT_NUMBER",df.PARENT_CONTRACT_NUMBER.cast('string'))
      df = df.withColumn("CONTRACT_NUMBER",df.CONTRACT_NUMBER.cast('string'))
      
      df = df.withColumn("PREMIUM_FLOAT_SPREAD",df.PREMIUM_FLOAT_SPREAD.cast('decimal(15,3)'))
      df = df.withColumn("INDEX_FACTOR",df.INDEX_FACTOR.cast('decimal(15,3)'))
      df = df.withColumn("OPTION_STRIKE_PRICE",df.OPTION_STRIKE_PRICE.cast('decimal(15,3)'))
      df = df.withColumn("OPTION_PREMIUM_PRICE",df.OPTION_PREMIUM_PRICE.cast('decimal(15,3)'))
      df = df.withColumn("DEAL_PRICE",df.DEAL_PRICE.cast('decimal(15,3)'))
      
      
      df = df.withColumn("VALID_FROM_DATE",df.VALID_FROM_DATE.cast('date'))
      df = df.withColumn("VALID_TO_DATE",df.VALID_TO_DATE.cast('date'))
      df = df.withColumn("DEAL_EXECUTION_TIMESTAMP",df.DEAL_EXECUTION_TIMESTAMP.cast('timestamp'))
      df = df.withColumn("PRICE_SETTLE_DATE",df.PRICE_SETTLE_DATE.cast('date'))
      df = df.withColumn("BILL_OF_LADING_DATE",df.BILL_OF_LADING_DATE.cast('date'))
      
      df = df.withColumn("RECORD_CREATED_DTTM",df.RECORD_CREATED_DTTM.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE1",df.SOURCE_LAST_DATE1.cast('timestamp'))
      
      df = df.select(
      col("DEAL_ATTRIBUTES_CK"),
      col("RECORD_CREATED_DTTM"),
      col("SRC_SYS_NAME"),
      col("SRC_SYS_DEAL_HEADER_KEY"),
      col("SRC_SYS_DEAL_LEG_KEY"),
      col("SRC_SYS_DEAL_SUB_LEG_KEY"),
      col("VALID_FROM_DATE"),
      col("VALID_TO_DATE"),
      col("SRC_SYSTEM_DEAL_TYPE_CODE"),
      col("SRC_SYSTEM_DEAL_SUBTYPE_CODE"),
      col("DEAL_HEADER_BUY_SELL_FLAG"),
      col("DEAL_INSTRUMENT_CLASSIFICATION"),
      col("DEAL_SPOT_TERM_IND"),
      col("DEAL_AGREEMENT_TYPE_DESCRIPTION"),
      col("HEADER_DEAL_STATUS"),
      col("PARENT_CONTRACT_NUMBER"),
      col("CONTRACT_NUMBER"),
      col("DEAL_BOOK_NAME"),
      col("DEAL_LEG_REFERENCE"),
      col("DEAL_LEG_BUY_SELL_FLAG"),
      col("SUB_LEG_DEAL_STATUS"),
      col("DEAL_EXECUTION_TIMESTAMP"),
      col("DEAL_PRICE"),
      col("PRICING_TYPE"),
      col("PRICING_COMPONENT"),
      col("PREMIUM_FLOAT_SPREAD"),
      col("INDEX_FACTOR"),
      col("PRICING_STATUS"),
      col("PRICE_SETTLE_DATE"),
      col("DEAL_SUB_LEG_REFERENCE"),
      col("SETTLEMENT_TYPE"),
      col("DEAL_LINE_TEXT"),
      col("CALL_PUT_FLAG"),
      col("OPTION_STRIKE_PRICE"),
      col("OPTION_PREMIUM_PRICE"),
      col("VESSEL_NAME"),
      col("DELIVERY_JUNCTION_NAME"),
      col("DELIVERY_METHOD_NAME"),
      col("BILL_OF_LADING_DATE"),
      col("SOURCE_LAST_DATE1")         
      )
      df.select(col("SRC_SYS_NAME"), col("DEAL_ATTRIBUTES_CK")).show()
      
      df.show()
      writeDatasetSynapseConnector(spark, df,"tsa_stage.dim_deal_attributes_stage") 
      
    if (SOURCE_ETRM == 'ALIGNE'):
      
      (df,metricDict) = appendHeaderAndLegforAligne(df, metricDict)
      df = df.withColumn("VALID_FROM_DATE", lit(''))
      df = df.withColumn("VALID_TO_DATE", lit(''))
      
      df = df.withColumn("SRC_SYS_DEAL_HEADER_KEY",df.SRC_SYS_DEAL_HEADER_KEY.cast('string'))
      df = df.withColumn("PARENT_CONTRACT_NUMBER",df.PARENT_CONTRACT_NUMBER.cast('string'))
      df = df.withColumn("CONTRACT_NUMBER",df.CONTRACT_NUMBER.cast('string'))
      
      df = df.withColumn("PREMIUM_FLOAT_SPREAD",df.PREMIUM_FLOAT_SPREAD.cast('decimal(15,3)'))
      df = df.withColumn("INDEX_FACTOR",df.INDEX_FACTOR.cast('decimal(15,3)'))
      df = df.withColumn("OPTION_STRIKE_PRICE",df.OPTION_STRIKE_PRICE.cast('decimal(15,3)'))
      df = df.withColumn("OPTION_PREMIUM_PRICE",df.OPTION_PREMIUM_PRICE.cast('decimal(15,3)'))
      df = df.withColumn("DEAL_PRICE",df.DEAL_PRICE.cast('decimal(15,3)'))
      
      
      df = df.withColumn("VALID_FROM_DATE",df.VALID_FROM_DATE.cast('date'))
      df = df.withColumn("VALID_TO_DATE",df.VALID_TO_DATE.cast('date'))
      df = df.withColumn("DEAL_EXECUTION_TIMESTAMP",df.DEAL_EXECUTION_TIMESTAMP.cast('timestamp'))
      df = df.withColumn("PRICE_SETTLE_DATE",df.PRICE_SETTLE_DATE.cast('date'))
      df = df.withColumn("BILL_OF_LADING_DATE",df.BILL_OF_LADING_DATE.cast('date'))
      
      df = df.withColumn("RECORD_CREATED_DTTM",df.RECORD_CREATED_DTTM.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE1",df.SOURCE_LAST_DATE1.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE2",df.SOURCE_LAST_DATE2.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE3",df.SOURCE_LAST_DATE3.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE4",df.SOURCE_LAST_DATE4.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE5",df.SOURCE_LAST_DATE5.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE6",df.SOURCE_LAST_DATE6.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE7",df.SOURCE_LAST_DATE7.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE8",df.SOURCE_LAST_DATE8.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE9",df.SOURCE_LAST_DATE9.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE10",df.SOURCE_LAST_DATE10.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE11",df.SOURCE_LAST_DATE11.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE12",df.SOURCE_LAST_DATE12.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE13",df.SOURCE_LAST_DATE13.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE14",df.SOURCE_LAST_DATE14.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE15",df.SOURCE_LAST_DATE15.cast('timestamp'))
      
      df = df.select(
      col("DEAL_ATTRIBUTES_CK"),
      col("RECORD_CREATED_DTTM"),
      col("SRC_SYS_NAME"),
      col("SRC_SYS_DEAL_HEADER_KEY"),
      col("SRC_SYS_DEAL_LEG_KEY"),
      col("SRC_SYS_DEAL_SUB_LEG_KEY"),
      col("VALID_FROM_DATE"),
      col("VALID_TO_DATE"),
      col("SRC_SYSTEM_DEAL_TYPE_CODE"),
      col("SRC_SYSTEM_DEAL_SUBTYPE_CODE"),
      col("DEAL_HEADER_BUY_SELL_FLAG"),
      col("DEAL_INSTRUMENT_CLASSIFICATION"),
      col("DEAL_SPOT_TERM_IND"),
      col("DEAL_AGREEMENT_TYPE_DESCRIPTION"),
      col("HEADER_DEAL_STATUS"),
      col("PARENT_CONTRACT_NUMBER"),
      col("CONTRACT_NUMBER"),
      col("DEAL_BOOK_NAME"),
      col("DEAL_LEG_REFERENCE"),
      col("DEAL_LEG_BUY_SELL_FLAG"),
      col("SUB_LEG_DEAL_STATUS"),
      col("DEAL_EXECUTION_TIMESTAMP"),
      col("DEAL_PRICE"),
      col("PRICING_TYPE"),
      col("PRICING_COMPONENT"),
      col("PREMIUM_FLOAT_SPREAD"),
      col("INDEX_FACTOR"),
      col("PRICING_STATUS"),
      col("PRICE_SETTLE_DATE"),
      col("DEAL_SUB_LEG_REFERENCE"),
      col("SETTLEMENT_TYPE"),
      col("DEAL_LINE_TEXT"),
      col("CALL_PUT_FLAG"),
      col("OPTION_STRIKE_PRICE"),
      col("OPTION_PREMIUM_PRICE"),
      col("VESSEL_NAME"),
      col("DELIVERY_JUNCTION_NAME"),
      col("DELIVERY_METHOD_NAME"),
      col("BILL_OF_LADING_DATE"),
      col("SOURCE_LAST_DATE1"),
      col("SOURCE_LAST_DATE2"),
      col("SOURCE_LAST_DATE3"),
      col("SOURCE_LAST_DATE4"),
      col("SOURCE_LAST_DATE5"),
      col("SOURCE_LAST_DATE6"),
      col("SOURCE_LAST_DATE7"),
      col("SOURCE_LAST_DATE8"),
      col("SOURCE_LAST_DATE9"),
      col("SOURCE_LAST_DATE10"),
      col("SOURCE_LAST_DATE11"),
      col("SOURCE_LAST_DATE12"),
      col("SOURCE_LAST_DATE13"),
      col("SOURCE_LAST_DATE14"),
      col("SOURCE_LAST_DATE15")
      )
      df.select(col("SRC_SYS_NAME"), col("DEAL_ATTRIBUTES_CK")).show()
      
      df.show()
      writeDatasetSynapseConnectorOverwrite(spark,df,"tsa_stage.dim_deal_attributes_stage_temp_aligne")
      writeStageTempToStageTableForALIGNE() 
      
    if (SOURCE_ETRM == 'DEX') :
      (df,metricDict) = appendHeaderAndLegforDex(df, metricDict)
      
      #spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
      
      df = df.withColumn("VALID_FROM_DATE", lit(''))
      df = df.withColumn("VALID_TO_DATE", lit(''))
      
      df = df.withColumn("SOURCE_LAST_DATE1",df.SOURCE_LAST_DATE1.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE2",df.SOURCE_LAST_DATE2.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE3",df.SOURCE_LAST_DATE3.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE4",df.SOURCE_LAST_DATE4.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE5",df.SOURCE_LAST_DATE5.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE6",df.SOURCE_LAST_DATE6.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE7",df.SOURCE_LAST_DATE7.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE8",df.SOURCE_LAST_DATE8.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE9",df.SOURCE_LAST_DATE9.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE10",df.SOURCE_LAST_DATE10.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE11",df.SOURCE_LAST_DATE11.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE12",df.SOURCE_LAST_DATE12.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE13",df.SOURCE_LAST_DATE13.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE14",df.SOURCE_LAST_DATE14.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE15",df.SOURCE_LAST_DATE15.cast('timestamp'))
      df = df.withColumn("DEAL_EXECUTION_TIMESTAMP",df.DEAL_EXECUTION_TIMESTAMP.cast('timestamp'))
      df = df.withColumn("BILL_OF_LADING_DATE",df.BILL_OF_LADING_DATE.cast('date'))
      df = df.withColumn("PRICE_SETTLE_DATE",df.PRICE_SETTLE_DATE.cast('date'))
      df = df.withColumn("VALID_FROM_DATE",df.VALID_FROM_DATE.cast('date'))
      df = df.withColumn("VALID_TO_DATE",df.VALID_TO_DATE.cast('date'))
      df = df.withColumn("RECORD_CREATED_DTTM", date_trunc("second", col("RECORD_CREATED_DTTM")))
      df = df.withColumn("PREMIUM_FLOAT_SPREAD",df.PREMIUM_FLOAT_SPREAD.cast('decimal(15,3)'))
      df = df.withColumn("INDEX_FACTOR",df.INDEX_FACTOR.cast('decimal(15,3)'))
      df = df.withColumn("OPTION_STRIKE_PRICE",df.OPTION_STRIKE_PRICE.cast('decimal(15,3)'))
      df = df.withColumn("OPTION_PREMIUM_PRICE",df.OPTION_PREMIUM_PRICE.cast('decimal(15,3)'))
      df = df.withColumn("DEAL_PRICE",df.DEAL_PRICE.cast('decimal(15,3)'))
      
      
      
      df = df.select(
      col("DEAL_ATTRIBUTES_CK"),
      col("RECORD_CREATED_DTTM"),
      col("SRC_SYS_NAME"),
      col("SRC_SYS_DEAL_HEADER_KEY"),
      col("SRC_SYS_DEAL_LEG_KEY"),
      col("SRC_SYS_DEAL_SUB_LEG_KEY"),
      col("VALID_FROM_DATE"),
      col("VALID_TO_DATE"),
      col("SRC_SYSTEM_DEAL_TYPE_CODE"),
      col("SRC_SYSTEM_DEAL_SUBTYPE_CODE"),
      col("DEAL_HEADER_BUY_SELL_FLAG"),
      col("DEAL_INSTRUMENT_CLASSIFICATION"),
      col("DEAL_SPOT_TERM_IND"),
      col("DEAL_AGREEMENT_TYPE_DESCRIPTION"),
      col("HEADER_DEAL_STATUS"),
      col("PARENT_CONTRACT_NUMBER"),
      col("CONTRACT_NUMBER"),
      col("DEAL_BOOK_NAME"),
      col("DEAL_LEG_REFERENCE"),
      col("DEAL_LEG_BUY_SELL_FLAG"),
      col("SUB_LEG_DEAL_STATUS"),
      col("DEAL_EXECUTION_TIMESTAMP"),
      col("DEAL_PRICE"),
      col("PRICING_TYPE"),
      col("PRICING_COMPONENT"),
      col("PREMIUM_FLOAT_SPREAD"),
      col("INDEX_FACTOR"),
      col("PRICING_STATUS"),
      col("PRICE_SETTLE_DATE"),
      col("DEAL_SUB_LEG_REFERENCE"),
      col("SETTLEMENT_TYPE"),
      col("DEAL_LINE_TEXT"),
      col("CALL_PUT_FLAG"),
      col("OPTION_STRIKE_PRICE"),
      col("OPTION_PREMIUM_PRICE"),
      col("VESSEL_NAME"),
      col("DELIVERY_JUNCTION_NAME"),
      col("DELIVERY_METHOD_NAME"),
      col("BILL_OF_LADING_DATE"),
      col("SOURCE_LAST_DATE1"),
      col("SOURCE_LAST_DATE2"),
      col("SOURCE_LAST_DATE3"),
      col("SOURCE_LAST_DATE4"),
      col("SOURCE_LAST_DATE5"),
      col("SOURCE_LAST_DATE6"),
      col("SOURCE_LAST_DATE7"),
      col("SOURCE_LAST_DATE8"),
      col("SOURCE_LAST_DATE9"),
      col("SOURCE_LAST_DATE10"),
      col("SOURCE_LAST_DATE11"),
      col("SOURCE_LAST_DATE12"),
      col("SOURCE_LAST_DATE13"),
      col("SOURCE_LAST_DATE14"),
      col("SOURCE_LAST_DATE15")
      )
      print("wrinting to stage schema")
      df.printSchema()
      #writeDatasetSynapseConnector(spark,df,"tsa_stage.dim_deal_attributes_stage")
      writeDatasetSynapseConnectorOverwrite(spark,df,"tsa_stage.dim_deal_attributes_stage_temp")
      writeStageTempToStageTableForDEX()
      
      
    if (SOURCE_ETRM == 'NUCLEUS'):
      
      (df,metricDict) = appendHeaderAndLegforNucleus(df, metricDict)
      df = df.withColumn("VALID_FROM_DATE", lit(''))
      df = df.withColumn("VALID_TO_DATE", lit(''))
      
      df = df.withColumn("SRC_SYS_DEAL_HEADER_KEY",df.SRC_SYS_DEAL_HEADER_KEY.cast('string'))
      df = df.withColumn("PARENT_CONTRACT_NUMBER",df.PARENT_CONTRACT_NUMBER.cast('string'))
      df = df.withColumn("CONTRACT_NUMBER",df.CONTRACT_NUMBER.cast('string'))
      
      df = df.withColumn("PREMIUM_FLOAT_SPREAD",df.PREMIUM_FLOAT_SPREAD.cast('decimal(15,3)'))
      df = df.withColumn("INDEX_FACTOR",df.INDEX_FACTOR.cast('decimal(15,3)'))
      df = df.withColumn("OPTION_STRIKE_PRICE",df.OPTION_STRIKE_PRICE.cast('decimal(15,3)'))
      df = df.withColumn("OPTION_PREMIUM_PRICE",df.OPTION_PREMIUM_PRICE.cast('decimal(15,3)'))
      df = df.withColumn("DEAL_PRICE",df.DEAL_PRICE.cast('decimal(15,3)'))
      
      
      df = df.withColumn("VALID_FROM_DATE",df.VALID_FROM_DATE.cast('date'))
      df = df.withColumn("VALID_TO_DATE",df.VALID_TO_DATE.cast('date'))
      df = df.withColumn("DEAL_EXECUTION_TIMESTAMP",df.DEAL_EXECUTION_TIMESTAMP.cast('timestamp'))
      df = df.withColumn("PRICE_SETTLE_DATE",df.PRICE_SETTLE_DATE.cast('date'))
      df = df.withColumn("BILL_OF_LADING_DATE",df.BILL_OF_LADING_DATE.cast('date'))
      
      df = df.withColumn("RECORD_CREATED_DTTM",df.RECORD_CREATED_DTTM.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE1",df.SOURCE_LAST_DATE1.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE2",df.SOURCE_LAST_DATE2.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE1",df.SOURCE_LAST_DATE3.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE2",df.SOURCE_LAST_DATE4.cast('timestamp'))
      
      df = df.select(
      col("DEAL_ATTRIBUTES_CK"),
      col("RECORD_CREATED_DTTM"),
      col("SRC_SYS_NAME"),
      col("SRC_SYS_DEAL_HEADER_KEY"),
      col("SRC_SYS_DEAL_LEG_KEY"),
      col("SRC_SYS_DEAL_SUB_LEG_KEY"),
      col("VALID_FROM_DATE"),
      col("VALID_TO_DATE"),
      col("SRC_SYSTEM_DEAL_TYPE_CODE"),
      col("SRC_SYSTEM_DEAL_SUBTYPE_CODE"),
      col("DEAL_HEADER_BUY_SELL_FLAG"),
      col("DEAL_INSTRUMENT_CLASSIFICATION"),
      col("DEAL_SPOT_TERM_IND"),
      col("DEAL_AGREEMENT_TYPE_DESCRIPTION"),
      col("HEADER_DEAL_STATUS"),
      col("PARENT_CONTRACT_NUMBER"),
      col("CONTRACT_NUMBER"),
      col("DEAL_BOOK_NAME"),
      col("DEAL_LEG_REFERENCE"),
      col("DEAL_LEG_BUY_SELL_FLAG"),
      col("SUB_LEG_DEAL_STATUS"),
      col("DEAL_EXECUTION_TIMESTAMP"),
      col("DEAL_PRICE"),
      col("PRICING_TYPE"),
      col("PRICING_COMPONENT"),
      col("PREMIUM_FLOAT_SPREAD"),
      col("INDEX_FACTOR"),
      col("PRICING_STATUS"),
      col("PRICE_SETTLE_DATE"),
      col("DEAL_SUB_LEG_REFERENCE"),
      col("SETTLEMENT_TYPE"),
      col("DEAL_LINE_TEXT"),
      col("CALL_PUT_FLAG"),
      col("OPTION_STRIKE_PRICE"),
      col("OPTION_PREMIUM_PRICE"),
      col("VESSEL_NAME"),
      col("DELIVERY_JUNCTION_NAME"),
      col("DELIVERY_METHOD_NAME"),
      col("BILL_OF_LADING_DATE"),
      col("SOURCE_LAST_DATE1"),
      col("SOURCE_LAST_DATE2"),
      col("SOURCE_LAST_DATE3"),
      col("SOURCE_LAST_DATE4")
      )
      df.select(col("SRC_SYS_NAME"), col("DEAL_ATTRIBUTES_CK")).show()
      
      df.show()
      writeDatasetSynapseConnector(spark, df,"tsa_stage.dim_deal_attributes_stage")
      
    if (SOURCE_ETRM == 'ENDUR_SLMT'):
      
      (df,metricDict) = appendHeaderAndLegforEndurSLMT(df, metricDict)
      df = df.withColumn("VALID_FROM_DATE", lit(''))
      df = df.withColumn("VALID_TO_DATE", lit(''))
      df = df.withColumn("SRC_SYS_DEAL_HEADER_KEY",df.SRC_SYS_DEAL_HEADER_KEY.cast('string'))
      df = df.withColumn("PARENT_CONTRACT_NUMBER",df.PARENT_CONTRACT_NUMBER.cast('string'))
      df = df.withColumn("CONTRACT_NUMBER",df.CONTRACT_NUMBER.cast('string'))
      df = df.withColumn("PREMIUM_FLOAT_SPREAD",df.PREMIUM_FLOAT_SPREAD.cast('decimal(15,3)'))
      df = df.withColumn("INDEX_FACTOR",df.INDEX_FACTOR.cast('decimal(15,3)'))
      df = df.withColumn("OPTION_STRIKE_PRICE",df.OPTION_STRIKE_PRICE.cast('decimal(15,3)'))
      df = df.withColumn("OPTION_PREMIUM_PRICE",df.OPTION_PREMIUM_PRICE.cast('decimal(15,3)'))
      df = df.withColumn("DEAL_PRICE",df.DEAL_PRICE.cast('decimal(15,3)'))
      df = df.withColumn("VALID_FROM_DATE",df.VALID_FROM_DATE.cast('date'))
      df = df.withColumn("VALID_TO_DATE",df.VALID_TO_DATE.cast('date'))
      df = df.withColumn("DEAL_EXECUTION_TIMESTAMP",df.DEAL_EXECUTION_TIMESTAMP.cast('timestamp'))
      df = df.withColumn("PRICE_SETTLE_DATE",df.PRICE_SETTLE_DATE.cast('date'))
      df = df.withColumn("BILL_OF_LADING_DATE",df.BILL_OF_LADING_DATE.cast('date'))
      df = df.withColumn("RECORD_CREATED_DTTM",df.RECORD_CREATED_DTTM.cast('timestamp'))
      df = df.withColumn("SOURCE_LAST_DATE1",df.SOURCE_LAST_DATE1.cast('timestamp'))
      df = df.select(
      col("DEAL_ATTRIBUTES_CK"),
      col("RECORD_CREATED_DTTM"),
      col("SRC_SYS_NAME"),
      col("SRC_SYS_DEAL_HEADER_KEY"),
      col("SRC_SYS_DEAL_LEG_KEY"),
      col("SRC_SYS_DEAL_SUB_LEG_KEY"),
      col("VALID_FROM_DATE"),
      col("VALID_TO_DATE"),
      col("SRC_SYSTEM_DEAL_TYPE_CODE"),
      col("SRC_SYSTEM_DEAL_SUBTYPE_CODE"),
      col("DEAL_HEADER_BUY_SELL_FLAG"),
      col("DEAL_INSTRUMENT_CLASSIFICATION"),
      col("DEAL_SPOT_TERM_IND"),
      col("DEAL_AGREEMENT_TYPE_DESCRIPTION"),
      col("HEADER_DEAL_STATUS"),
      col("PARENT_CONTRACT_NUMBER"),
      col("CONTRACT_NUMBER"),
      col("DEAL_BOOK_NAME"),
      col("DEAL_LEG_REFERENCE"),
      col("DEAL_LEG_BUY_SELL_FLAG"),
      col("SUB_LEG_DEAL_STATUS"),
      col("DEAL_EXECUTION_TIMESTAMP"),
      col("DEAL_PRICE"),
      col("PRICING_TYPE"),
      col("PRICING_COMPONENT"),
      col("PREMIUM_FLOAT_SPREAD"),
      col("INDEX_FACTOR"),
      col("PRICING_STATUS"),
      col("PRICE_SETTLE_DATE"),
      col("DEAL_SUB_LEG_REFERENCE"),
      col("SETTLEMENT_TYPE"),
      col("DEAL_LINE_TEXT"),
      col("CALL_PUT_FLAG"),
      col("OPTION_STRIKE_PRICE"),
      col("OPTION_PREMIUM_PRICE"),
      col("VESSEL_NAME"),
      col("DELIVERY_JUNCTION_NAME"),
      col("DELIVERY_METHOD_NAME"),
      col("BILL_OF_LADING_DATE"),
      col("SOURCE_LAST_DATE1")         
      )
      df.select(col("SRC_SYS_NAME"), col("DEAL_ATTRIBUTES_CK")).show()
      df.show()
      writeDatasetSynapseConnector(spark, df,"tsa_stage.dim_deal_attributes_stage")
    return metricDict

# COMMAND ----------

def writeStageTempToStageTableForDEX():
  SQL = """
    insert into [tsa_stage].[dim_deal_attributes_stage]
    SELECT DEAL_ATTRIBUTES_CK
    ,try_cast(RECORD_CREATED_DTTM as datetime)
    ,SRC_SYS_NAME
    ,SRC_SYS_DEAL_HEADER_KEY
    ,SRC_SYS_DEAL_LEG_KEY
    ,SRC_SYS_DEAL_SUB_LEG_KEY
    ,VALID_FROM_DATE
    ,VALID_TO_DATE
    ,SRC_SYSTEM_DEAL_TYPE_CODE
    ,SRC_SYSTEM_DEAL_SUBTYPE_CODE
    ,DEAL_HEADER_BUY_SELL_FLAG
    ,DEAL_INSTRUMENT_CLASSIFICATION
    ,DEAL_SPOT_TERM_IND
    ,DEAL_AGREEMENT_TYPE_DESCRIPTION
    ,HEADER_DEAL_STATUS
    ,PARENT_CONTRACT_NUMBER
    ,CONTRACT_NUMBER
    ,DEAL_BOOK_NAME
    ,DEAL_LEG_REFERENCE
    ,DEAL_LEG_BUY_SELL_FLAG
    ,SUB_LEG_DEAL_STATUS
    ,try_cast (DEAL_EXECUTION_TIMESTAMP as datetime)
    ,DEAL_PRICE
    ,PRICING_TYPE
    ,PRICING_COMPONENT
    ,PREMIUM_FLOAT_SPREAD
    ,INDEX_FACTOR
    ,PRICING_STATUS
    ,PRICE_SETTLE_DATE
    ,DEAL_SUB_LEG_REFERENCE
    ,SETTLEMENT_TYPE
    ,DEAL_LINE_TEXT
    ,CALL_PUT_FLAG
    ,OPTION_STRIKE_PRICE
    ,OPTION_PREMIUM_PRICE
    ,VESSEL_NAME
    ,DELIVERY_JUNCTION_NAME
    ,DELIVERY_METHOD_NAME
    ,BILL_OF_LADING_DATE
    ,try_cast (SOURCE_LAST_DATE1 as datetime)
    ,try_cast(SOURCE_LAST_DATE2 as datetime)
    ,try_cast (SOURCE_LAST_DATE3 as datetime)
    ,try_cast(SOURCE_LAST_DATE4 as datetime)
    ,try_cast(SOURCE_LAST_DATE5 as datetime)
    ,try_cast(SOURCE_LAST_DATE6 as datetime)
    ,try_cast(SOURCE_LAST_DATE7 as datetime)
    ,try_cast(SOURCE_LAST_DATE8 as datetime)
    ,try_cast(SOURCE_LAST_DATE9 as datetime)
    ,try_cast(SOURCE_LAST_DATE10 as datetime)
    ,try_cast(SOURCE_LAST_DATE11 as datetime)
    ,try_cast (SOURCE_LAST_DATE12 as datetime)
    ,try_cast(SOURCE_LAST_DATE13 as datetime)
    ,try_cast(SOURCE_LAST_DATE14 as datetime)
    ,try_cast(SOURCE_LAST_DATE15 as datetime)
    FROM tsa_stage.dim_deal_attributes_stage_temp
  """
  
  executePyOdbcQuery(SQL)

# COMMAND ----------

def writeStageTempToStageTableForALIGNE():
  SQL = """
    insert into [tsa_stage].[dim_deal_attributes_stage]
    SELECT DEAL_ATTRIBUTES_CK
    ,try_cast(RECORD_CREATED_DTTM as datetime)
    ,SRC_SYS_NAME
    ,SRC_SYS_DEAL_HEADER_KEY
    ,SRC_SYS_DEAL_LEG_KEY
    ,SRC_SYS_DEAL_SUB_LEG_KEY
    ,VALID_FROM_DATE
    ,VALID_TO_DATE
    ,SRC_SYSTEM_DEAL_TYPE_CODE
    ,SRC_SYSTEM_DEAL_SUBTYPE_CODE
    ,DEAL_HEADER_BUY_SELL_FLAG
    ,DEAL_INSTRUMENT_CLASSIFICATION
    ,DEAL_SPOT_TERM_IND
    ,DEAL_AGREEMENT_TYPE_DESCRIPTION
    ,HEADER_DEAL_STATUS
    ,PARENT_CONTRACT_NUMBER
    ,CONTRACT_NUMBER
    ,DEAL_BOOK_NAME
    ,DEAL_LEG_REFERENCE
    ,DEAL_LEG_BUY_SELL_FLAG
    ,SUB_LEG_DEAL_STATUS
    ,try_cast (DEAL_EXECUTION_TIMESTAMP as datetime)
    ,DEAL_PRICE
    ,PRICING_TYPE
    ,PRICING_COMPONENT
    ,PREMIUM_FLOAT_SPREAD
    ,INDEX_FACTOR
    ,PRICING_STATUS
    ,PRICE_SETTLE_DATE
    ,DEAL_SUB_LEG_REFERENCE
    ,SETTLEMENT_TYPE
    ,DEAL_LINE_TEXT
    ,CALL_PUT_FLAG
    ,OPTION_STRIKE_PRICE
    ,OPTION_PREMIUM_PRICE
    ,VESSEL_NAME
    ,DELIVERY_JUNCTION_NAME
    ,DELIVERY_METHOD_NAME
    ,BILL_OF_LADING_DATE
    ,try_cast (SOURCE_LAST_DATE1 as datetime)
    ,try_cast(SOURCE_LAST_DATE2 as datetime)
    ,try_cast (SOURCE_LAST_DATE3 as datetime)
    ,try_cast(SOURCE_LAST_DATE4 as datetime)
    ,try_cast(SOURCE_LAST_DATE5 as datetime)
    ,try_cast(SOURCE_LAST_DATE6 as datetime)
    ,try_cast(SOURCE_LAST_DATE7 as datetime)
    ,try_cast(SOURCE_LAST_DATE8 as datetime)
    ,try_cast(SOURCE_LAST_DATE9 as datetime)
    ,try_cast(SOURCE_LAST_DATE10 as datetime)
    ,try_cast(SOURCE_LAST_DATE11 as datetime)
    ,try_cast (SOURCE_LAST_DATE12 as datetime)
    ,try_cast(SOURCE_LAST_DATE13 as datetime)
    ,try_cast(SOURCE_LAST_DATE14 as datetime)
    ,try_cast(SOURCE_LAST_DATE15 as datetime)
    FROM tsa_stage.dim_deal_attributes_stage_temp_aligne
  """
  
  executePyOdbcQuery(SQL)
