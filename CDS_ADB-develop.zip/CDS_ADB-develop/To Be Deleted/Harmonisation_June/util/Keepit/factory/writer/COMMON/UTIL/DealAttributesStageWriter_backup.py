# Databricks notebook source
# MAGIC %run ./DexProcessedDFToStageTable

# COMMAND ----------

# MAGIC %run ./EndurGPNAProcessedDFToStageTable

# COMMAND ----------

# MAGIC %run ./../../../../CuratedDatasetWriter

# COMMAND ----------

def WriteToStage(df,SOURCE_ETRM, metricDict) :
        
    DELETE_DIM_DEAL_ATTRIBUTES_STAGE_SQL = """DELETE from tsa_stage.dim_deal_attributes_stage where src_sys_name = ?"""

    executePyOdbcQueryWithParam1(DELETE_DIM_DEAL_ATTRIBUTES_STAGE_SQL,SOURCE_ETRM)
    
    if (SOURCE_ETRM == 'ENDUR_GPNA'):
      
      (df,metricDict) = appendHeaderAndLegforEndurGPNA(df, metricDict)
      df = df.withColumn("VALID_FROM_DATE", lit(''))
      df = df.withColumn("VALID_TO_DATE", lit(''))
      
      df = df.withColumn("SRC_SYS_DEAL_HEADER_KEY",df.SRC_SYS_DEAL_HEADER_KEY.cast('string'))
      df = df.withColumn("PARENT_CONTRACT_NUMBER",df.PARENT_CONTRACT_NUMBER.cast('string'))
      df = df.withColumn("CONTRACT_NUMBER",df.CONTRACT_NUMBER.cast('string'))
      
      df = df.withColumn("PREMIUM_FLOAT_SPREAD",df.PREMIUM_FLOAT_SPREAD.cast('decimal'))
      df = df.withColumn("INDEX_FACTOR",df.INDEX_FACTOR.cast('decimal'))
      df = df.withColumn("OPTION_STRIKE_PRICE",df.OPTION_STRIKE_PRICE.cast('decimal'))
      df = df.withColumn("OPTION_PREMIUM_PRICE",df.OPTION_PREMIUM_PRICE.cast('decimal'))
      df = df.withColumn("DEAL_PRICE",df.DEAL_PRICE.cast('decimal'))
      
      
      df = df.withColumn("VALID_FROM_DATE",df.VALID_FROM_DATE.cast('date'))
      df = df.withColumn("VALID_TO_DATE",df.VALID_TO_DATE.cast('date'))
      df = df.withColumn("DEAL_EXECUTION_TIMESTAMP",df.DEAL_EXECUTION_TIMESTAMP.cast('date'))
      df = df.withColumn("PRICE_SETTLE_DATE",df.PRICE_SETTLE_DATE.cast('date'))
      df = df.withColumn("BILL_OF_LADING_DATE",df.BILL_OF_LADING_DATE.cast('date'))
      
      df = df.withColumn("RECORD_CREATED_DTTM",df.RECORD_CREATED_DTTM.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE1",df.SOURCE_LAST_DATE1.cast('date'))
      
      df = df.select(
      col("DEAL_ATTRIBUTES_CK"),
      col("RECORD_CREATED_DTTM"),
      col("SRC_SYS_NAME"),
      col("SRC_SYS_DEAL_HEADER_KEY"),
      col("SRC_SYS_DEAL_LEG_KEY"),
      col("SRC_SYS_DEAL_SUB_LEG_KEY"),
      col("VALID_FROM_DATE"),
      col("VALID_TO_DATE"),
      col("SRC_SYSTEM_DEAL_TYPE_CODE"),
      col("SRC_SYSTEM_DEAL_SUBTYPE_CODE"),
      col("DEAL_INSTRUMENT_CLASSIFICATION"),
      col("DEAL_SPOT_TERM_IND"),
      col("DEAL_AGREEMENT_TYPE_DESCRIPTION"),
      col("HEADER_DEAL_STATUS"),
      col("PARENT_CONTRACT_NUMBER"),
      col("CONTRACT_NUMBER"),
      col("DEAL_BOOK_NAME"),
      col("DEAL_LEG_REFERENCE"),
      col("BUY_SELL_FLAG"),
      col("SUB_LEG_DEAL_STATUS"),
      col("DEAL_EXECUTION_TIMESTAMP"),
      col("DEAL_PRICE"),
      col("PRICING_TYPE"),
      col("PRICING_COMPONENT"),
      col("PREMIUM_FLOAT_SPREAD"),
      col("INDEX_FACTOR"),
      col("PRICING_STATUS"),
      col("PRICE_SETTLE_DATE"),
      col("DEAL_SUB_LEG_REFERENCE"),
      col("SETTLEMENT_TYPE"),
      col("DEAL_LINE_TEXT"),
      col("CALL_PUT_FLAG"),
      col("OPTION_STRIKE_PRICE"),
      col("OPTION_PREMIUM_PRICE"),
      col("VESSEL_NAME"),
      col("DELIVERY_JUNCTION_NAME"),
      col("DELIVERY_METHOD_NAME"),
      col("BILL_OF_LADING_DATE"),
      col("SOURCE_LAST_DATE1")         
      )
      df.select(col("SRC_SYS_NAME"), col("DEAL_ATTRIBUTES_CK")).show()
      
      df.show()
      writeDatasetSynapseConnector(spark, df,"tsa_stage.dim_deal_attributes_stage") 
        
    if (SOURCE_ETRM == 'DEX') :
      (df,metricDict) = appendHeaderAndLegforDex(df, metricDict)
      
      df = df.withColumn("VALID_FROM_DATE", lit(''))
      df = df.withColumn("VALID_TO_DATE", lit(''))
      
      df = df.withColumn("SRC_SYS_DEAL_HEADER_KEY",df.SRC_SYS_DEAL_HEADER_KEY.cast('string'))
      df = df.withColumn("PARENT_CONTRACT_NUMBER",df.PARENT_CONTRACT_NUMBER.cast('string'))
      df = df.withColumn("CONTRACT_NUMBER",df.CONTRACT_NUMBER.cast('string'))
      
      df = df.withColumn("PREMIUM_FLOAT_SPREAD",df.PREMIUM_FLOAT_SPREAD.cast('decimal'))
      df = df.withColumn("INDEX_FACTOR",df.INDEX_FACTOR.cast('decimal'))
      df = df.withColumn("OPTION_STRIKE_PRICE",df.OPTION_STRIKE_PRICE.cast('decimal'))
      df = df.withColumn("OPTION_PREMIUM_PRICE",df.OPTION_PREMIUM_PRICE.cast('decimal'))
      df = df.withColumn("DEAL_PRICE",df.DEAL_PRICE.cast('decimal'))
      
      
      
      df = df.withColumn("VALID_FROM_DATE",df.VALID_FROM_DATE.cast('date'))
      df = df.withColumn("VALID_TO_DATE",df.VALID_TO_DATE.cast('date'))
      df = df.withColumn("DEAL_EXECUTION_TIMESTAMP",df.DEAL_EXECUTION_TIMESTAMP.cast('date'))
      df = df.withColumn("PRICE_SETTLE_DATE",df.PRICE_SETTLE_DATE.cast('date'))
      df = df.withColumn("BILL_OF_LADING_DATE",df.BILL_OF_LADING_DATE.cast('date'))
      
      df = df.withColumn("RECORD_CREATED_DTTM",df.RECORD_CREATED_DTTM.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE1",df.SOURCE_LAST_DATE1.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE2",df.SOURCE_LAST_DATE2.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE3",df.SOURCE_LAST_DATE3.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE4",df.SOURCE_LAST_DATE4.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE5",df.SOURCE_LAST_DATE5.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE6",df.SOURCE_LAST_DATE6.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE7",df.SOURCE_LAST_DATE7.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE8",df.SOURCE_LAST_DATE8.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE9",df.SOURCE_LAST_DATE9.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE10",df.SOURCE_LAST_DATE10.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE11",df.SOURCE_LAST_DATE11.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE12",df.SOURCE_LAST_DATE12.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE13",df.SOURCE_LAST_DATE13.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE14",df.SOURCE_LAST_DATE14.cast('date'))
      df = df.withColumn("SOURCE_LAST_DATE15",df.SOURCE_LAST_DATE15.cast('date'))
      
      
      
      df = df.select(
      col("DEAL_ATTRIBUTES_CK"),
      col("RECORD_CREATED_DTTM"),
      col("SRC_SYS_NAME"),
      col("SRC_SYS_DEAL_HEADER_KEY"),
      col("SRC_SYS_DEAL_LEG_KEY"),
      col("SRC_SYS_DEAL_SUB_LEG_KEY"),
      col("VALID_FROM_DATE"),
      col("VALID_TO_DATE"),
      col("SRC_SYSTEM_DEAL_TYPE_CODE"),
      col("SRC_SYSTEM_DEAL_SUBTYPE_CODE"),
      col("DEAL_INSTRUMENT_CLASSIFICATION"),
      col("DEAL_SPOT_TERM_IND"),
      col("DEAL_AGREEMENT_TYPE_DESCRIPTION"),
      col("HEADER_DEAL_STATUS"),
      col("PARENT_CONTRACT_NUMBER"),
      col("CONTRACT_NUMBER"),
      col("DEAL_BOOK_NAME"),
      col("DEAL_LEG_REFERENCE"),
      col("BUY_SELL_FLAG"),
      col("SUB_LEG_DEAL_STATUS"),
      col("DEAL_EXECUTION_TIMESTAMP"),
      col("DEAL_PRICE"),
      col("PRICING_TYPE"),
      col("PRICING_COMPONENT"),
      col("PREMIUM_FLOAT_SPREAD"),
      col("INDEX_FACTOR"),
      col("PRICING_STATUS"),
      col("PRICE_SETTLE_DATE"),
      col("DEAL_SUB_LEG_REFERENCE"),
      col("SETTLEMENT_TYPE"),
      col("DEAL_LINE_TEXT"),
      col("CALL_PUT_FLAG"),
      col("OPTION_STRIKE_PRICE"),
      col("OPTION_PREMIUM_PRICE"),
      col("VESSEL_NAME"),
      col("DELIVERY_JUNCTION_NAME"),
      col("DELIVERY_METHOD_NAME"),
      col("BILL_OF_LADING_DATE"),
      col("SOURCE_LAST_DATE1"),
      col("SOURCE_LAST_DATE2"),
      col("SOURCE_LAST_DATE3"),
      col("SOURCE_LAST_DATE4"),
      col("SOURCE_LAST_DATE5"),
      col("SOURCE_LAST_DATE6"),
      col("SOURCE_LAST_DATE7"),
      col("SOURCE_LAST_DATE8"),
      col("SOURCE_LAST_DATE9"),
      col("SOURCE_LAST_DATE10"),
      col("SOURCE_LAST_DATE11"),
      col("SOURCE_LAST_DATE12"),
      col("SOURCE_LAST_DATE13"),
      col("SOURCE_LAST_DATE14"),
      col("SOURCE_LAST_DATE15")
      )
      print("wrinting to stage schema")
      df.printSchema()
      writeDatasetSynapseConnector(spark,df,"tsa_stage.dim_deal_attributes_stage")
    
    return metricDict
