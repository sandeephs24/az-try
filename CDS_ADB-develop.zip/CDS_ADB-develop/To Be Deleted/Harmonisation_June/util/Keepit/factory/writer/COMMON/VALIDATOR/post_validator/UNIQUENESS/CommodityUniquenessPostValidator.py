# Databricks notebook source
# MAGIC %run ./UniquenessCheckUtil

# COMMAND ----------

def validateUniqueCommodity(SOURCE_ETRM):
  
  SQL = """
  select commodity_check.*,
		case when commodity_sk_count = commodity_ck_count
		and 
		commodity_ck_count=record_count
		THEN 'UNIQUESNESS TEST PASSED'
		ELSE 'UNIQUESNESS TEST FAILED' END AS TEST_STATUS
	FROM ( SELECT count(distinct commodity_sk) as commodity_sk_count,
					count(distinct commodity_ck) as commodity_ck_count,
					count(1) as record_count,
					current_timestamp as SQL_EXEC_DATETIME
				FROM [tsa_curated].[DIM_commodity]
				where src_sys_name = '{0}'
		)commodity_check
  """.format(SOURCE_ETRM)
  
  status = runSQLandCheckUniqueness(SQL)
  return status
