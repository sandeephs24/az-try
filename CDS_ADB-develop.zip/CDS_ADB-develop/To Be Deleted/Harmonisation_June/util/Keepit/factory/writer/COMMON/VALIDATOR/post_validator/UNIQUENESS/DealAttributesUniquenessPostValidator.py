# Databricks notebook source
# MAGIC %run ./UniquenessCheckUtil

# COMMAND ----------

def validateUniqueDealAttributes(SOURCE_ETRM):
  
  SQL = """
  select deal_attributes_check.*,
		case when deal_attributes_sk_count = deal_attributes_ck_count
		and 
		deal_attributes_ck_count=record_count
		THEN 'UNIQUESNESS TEST PASSED'
		ELSE 'UNIQUESNESS TEST FAILED' END AS TEST_STATUS
	FROM ( SELECT count(distinct deal_attributes_sk) as deal_attributes_sk_count,
					count(distinct deal_attributes_ck) as deal_attributes_ck_count,
					count(1) as record_count,
					current_timestamp as SQL_EXEC_DATETIME
				FROM [tsa_curated].[DIM_deal_attributes]
				where src_sys_name = '{0}'
		)deal_attributes_check
  """.format(SOURCE_ETRM)
  
  status = runSQLandCheckUniqueness(SQL)
  return status
