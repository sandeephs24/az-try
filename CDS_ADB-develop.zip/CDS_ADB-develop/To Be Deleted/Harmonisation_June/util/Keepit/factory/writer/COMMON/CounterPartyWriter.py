# Databricks notebook source
# MAGIC %run ./../DatasetWriter

# COMMAND ----------

# MAGIC %run ./VALIDATOR/pre_validator/duplicate/PartyDuplicatePreValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/duplicate/PartyDuplicatePostValidator

# COMMAND ----------

# MAGIC %run ./VALIDATOR/post_validator/UNIQUENESS/PartyUniquenessPostValidator

# COMMAND ----------

class CounterPartyWriter(DatasetWriter):
    DELETE_DIM_PARTY_STAGE_SQL = """DELETE from tsa_stage.dim_party_stage WHERE src_sys_name = ?"""
    INSERT_DIM_PARTY_SQL = """
    INSERT INTO tsa_curated.dim_party
    (
	PARTY_CK,
	RECORD_CREATED_DTTM,
	RECORD_UPDATED_DTTM,
	SRC_SYS_NAME,
	SRC_SYS_PARTY_NK,
	SRC_SYS_PARTY_SHORT_NAME,
	SRC_SYS_PARTY_LONG_NAME,
	PARTY_TYPE,
	SRC_SYS_LEGAL_ENTITY_NK,
	SRC_SYS_LEGAL_ENTITY_NAME,
	KYC_COUNTERPARTY_KEY,
	KYC_LEGAL_NAME,
	KYC_OPERATION_COUNTRY_NAME,
	KYC_OPERATION_COUNTRY_ISO_CODE,
	HIGH_RISK_OPERATION_COUNTRY_FLAG,
	EDD_OPERATION_COUNTRY_FLAG,
	GEC_OPERATION_COUNTRY_FLAG,
	KYC_LEGAL_COUNTRY_NAME,
	KYC_LEGAL_COUNTRY_ISO_CODE,
	HIGH_RISK_LEGAL_COUNTRY_FLAG,
	EDD_LEGAL_COUNTRY_FLAG,
	GEC_LEGAL_COUNTRY_FLAG,
	KYC_STATUS,
	KYC_RISK_LEVEL,
	KYC_NEXT_REVIEW_DATE,
	KYC_LAST_REVIEW_DATE,
	KYC_DUE_DILIGENCE_LEVEL,
	ENHANCED_MONITORING_FLAG,
	ENHANCED_MONITORING_REVIEW_FREQUENCY,
	NEXT_ENHANCED_MONITORING_REQUIRED_DATE,
	KYC_APPROVED_WITH_CONDITION_FLAG,
    KYC_APPROVED_WITH_CONDITION_REMARK,
    KYC_INTENDED_BUSINESS_RELATIONSHIP
    )
    SELECT party_ck,
    current_timestamp record_created_dttm,
    current_timestamp record_updated_dttm,
    src_sys_name,
    src_sys_party_nk,
    SRC_SYS_PARTY_SHORT_NAME,
	SRC_SYS_PARTY_LONG_NAME,
	PARTY_TYPE,
	SRC_SYS_LEGAL_ENTITY_NK,
	SRC_SYS_LEGAL_ENTITY_NAME,
	KYC_COUNTERPARTY_KEY,
	KYC_LEGAL_NAME,
	KYC_OPERATION_COUNTRY_NAME,
	KYC_OPERATION_COUNTRY_ISO_CODE,
	HIGH_RISK_OPERATION_COUNTRY_FLAG,
	EDD_OPERATION_COUNTRY_FLAG,
	GEC_OPERATION_COUNTRY_FLAG,
	KYC_LEGAL_COUNTRY_NAME,
	KYC_LEGAL_COUNTRY_ISO_CODE,
	HIGH_RISK_LEGAL_COUNTRY_FLAG,
	EDD_LEGAL_COUNTRY_FLAG,
	GEC_LEGAL_COUNTRY_FLAG,
	KYC_STATUS,
	KYC_RISK_LEVEL,
	KYC_NEXT_REVIEW_DATE,
	KYC_LAST_REVIEW_DATE,
	KYC_DUE_DILIGENCE_LEVEL,
	ENHANCED_MONITORING_FLAG,
	ENHANCED_MONITORING_REVIEW_FREQUENCY,
	NEXT_ENHANCED_MONITORING_REQUIRED_DATE,
	KYC_APPROVED_WITH_CONDITION_FLAG,
    KYC_APPROVED_WITH_CONDITION_REMARK,
    KYC_INTENDED_BUSINESS_RELATIONSHIP
    FROM tsa_stage.dim_party_stage stage
    WHERE NOT EXISTS
    (SELECT 1 
    FROM tsa_curated.dim_party main 
    WHERE main.party_ck = stage.party_ck ) and stage.src_sys_name = ?
    """
    
    UPDATE_DIM_PARTY_SQL = """UPDATE main_table 
    SET main_table.SRC_SYS_PARTY_SHORT_NAME = stage_table.SRC_SYS_PARTY_SHORT_NAME,
    main_table.SRC_SYS_PARTY_LONG_NAME = stage_table.SRC_SYS_PARTY_LONG_NAME,
    main_table.PARTY_TYPE = stage_table.PARTY_TYPE,
    main_table.SRC_SYS_LEGAL_ENTITY_NK = stage_table.SRC_SYS_LEGAL_ENTITY_NK,
    main_table.SRC_SYS_LEGAL_ENTITY_NAME = stage_table.SRC_SYS_LEGAL_ENTITY_NAME,
    main_table.KYC_COUNTERPARTY_KEY = stage_table.KYC_COUNTERPARTY_KEY,
    main_table.KYC_LEGAL_NAME = stage_table.KYC_LEGAL_NAME,
    main_table.KYC_OPERATION_COUNTRY_NAME = stage_table.KYC_OPERATION_COUNTRY_NAME,
    main_table.KYC_OPERATION_COUNTRY_ISO_CODE = stage_table.KYC_OPERATION_COUNTRY_ISO_CODE,
    main_table.HIGH_RISK_OPERATION_COUNTRY_FLAG = stage_table.HIGH_RISK_OPERATION_COUNTRY_FLAG,
    main_table.EDD_OPERATION_COUNTRY_FLAG = stage_table.EDD_OPERATION_COUNTRY_FLAG,
    main_table.GEC_OPERATION_COUNTRY_FLAG = stage_table.GEC_OPERATION_COUNTRY_FLAG,
    main_table.KYC_LEGAL_COUNTRY_NAME = stage_table.KYC_LEGAL_COUNTRY_NAME,
    main_table.KYC_LEGAL_COUNTRY_ISO_CODE = stage_table.KYC_LEGAL_COUNTRY_ISO_CODE,
    main_table.HIGH_RISK_LEGAL_COUNTRY_FLAG = stage_table.HIGH_RISK_LEGAL_COUNTRY_FLAG,
    main_table.EDD_LEGAL_COUNTRY_FLAG = stage_table.EDD_LEGAL_COUNTRY_FLAG,
    main_table.GEC_LEGAL_COUNTRY_FLAG = stage_table.GEC_LEGAL_COUNTRY_FLAG,
    main_table.KYC_STATUS = stage_table.KYC_STATUS,
    main_table.KYC_RISK_LEVEL = stage_table.KYC_RISK_LEVEL,
    main_table.KYC_NEXT_REVIEW_DATE = stage_table.KYC_NEXT_REVIEW_DATE,
    main_table.KYC_LAST_REVIEW_DATE = stage_table.KYC_LAST_REVIEW_DATE,
    main_table.KYC_DUE_DILIGENCE_LEVEL = stage_table.KYC_DUE_DILIGENCE_LEVEL,
    main_table.ENHANCED_MONITORING_FLAG = stage_table.ENHANCED_MONITORING_FLAG,
    main_table.ENHANCED_MONITORING_REVIEW_FREQUENCY = stage_table.ENHANCED_MONITORING_REVIEW_FREQUENCY,
    main_table.NEXT_ENHANCED_MONITORING_REQUIRED_DATE = stage_table.NEXT_ENHANCED_MONITORING_REQUIRED_DATE,
    main_table.KYC_APPROVED_WITH_CONDITION_FLAG = stage_table.KYC_APPROVED_WITH_CONDITION_FLAG,
    main_table.KYC_APPROVED_WITH_CONDITION_REMARK = stage_table.KYC_APPROVED_WITH_CONDITION_REMARK,
    main_table.KYC_INTENDED_BUSINESS_RELATIONSHIP = stage_table.KYC_INTENDED_BUSINESS_RELATIONSHIP,
    record_updated_dttm = current_timestamp
    FROM tsa_curated.dim_party main_table
    JOIN tsa_stage.dim_party_stage stage_table
    ON main_table.party_ck = stage_table.party_ck and stage_table.src_sys_name = ? """
    
    UPDATE_WATERMARK_SQL = """
    UPDATE tsa_curated.watermark SET last_offset_value =
    (
    SELECT CONVERT(varchar(20), max(source_last_update), 120)
    FROM tsa_curated.dim_party main_table,tsa_stage.dim_party_stage stage_table 
    WHERE main_table.party_ck = stage_table.party_ck
    and main_table.src_sys_name = ?
    ) 
    WHERE source_name = ?
    and source_table_name = ?
    and table_name = 'DIM_PARTY' 
    """
    
    def write(df, SOURCE_ETRM, metricDict):
        import time
        print('deleting stage records')
        executePyOdbcQueryWithParam1(CounterPartyWriter.DELETE_DIM_PARTY_STAGE_SQL,SOURCE_ETRM)
        start = time.time()
        
        df = df.withColumn("SRC_SYS_PARTY_NK",df.SRC_SYS_PARTY_NK.cast('string'))
        
        df = df.select(
          col("PARTY_CK"),
          col("RECORD_CREATED_DTTM"),
          col("SRC_SYS_NAME"),
          col("SRC_SYS_PARTY_NK"),
          col("SRC_SYS_PARTY_SHORT_NAME"),
          col("SRC_SYS_PARTY_LONG_NAME"),
          col("PARTY_TYPE"),
          col("SRC_SYS_LEGAL_ENTITY_NK"),
          col("SRC_SYS_LEGAL_ENTITY_NAME"),
          col("KYC_COUNTERPARTY_KEY"),
          col("KYC_LEGAL_NAME"),
          col("KYC_OPERATION_COUNTRY_NAME"),
          col("KYC_OPERATION_COUNTRY_ISO_CODE"),
          col("HIGH_RISK_OPERATION_COUNTRY_FLAG"),
          col("EDD_OPERATION_COUNTRY_FLAG"),
          col("GEC_OPERATION_COUNTRY_FLAG"),
          col("KYC_LEGAL_COUNTRY_NAME"),
          col("KYC_LEGAL_COUNTRY_ISO_CODE"),
          col("HIGH_RISK_LEGAL_COUNTRY_FLAG"),
          col("EDD_LEGAL_COUNTRY_FLAG"),
          col("GEC_LEGAL_COUNTRY_FLAG"),
          col("KYC_STATUS"),
          col("KYC_RISK_LEVEL"),
          col("KYC_NEXT_REVIEW_DATE"),
          col("KYC_LAST_REVIEW_DATE"),
          col("KYC_DUE_DILIGENCE_LEVEL"),
          col("ENHANCED_MONITORING_FLAG"),
          col("ENHANCED_MONITORING_REVIEW_FREQUENCY"),
          col("NEXT_ENHANCED_MONITORING_REQUIRED_DATE"),
          col("KYC_APPROVED_WITH_CONDITION_FLAG"),
          col("KYC_APPROVED_WITH_CONDITION_REMARK"),
          col("KYC_INTENDED_BUSINESS_RELATIONSHIP"),  
          col("SOURCE_LAST_UPDATE")
          )
        print("writing to stage table")
        writeDatasetSynapseConnector(spark, df,"tsa_stage.dim_party_stage")
        
        end = time.time()
        time_taken = end - start
        metricDict["party_writer_stage_load_time_taken_in_sec"] = time_taken 
        
        
        status = validateDuplicateParty(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
        
        start = time.time()
        print('updating existing records')
        row_affected = executePyOdbcQueryWithParam1(CounterPartyWriter.UPDATE_DIM_PARTY_SQL,SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["party_writer_update_sql_time_taken_in_sec"] = time_taken 
        metricDict["update_sql_rows_affected"] = row_affected
        
        start = time.time()
        print('inserting new records')
        row_affected = executePyOdbcQueryWithParam1(CounterPartyWriter.INSERT_DIM_PARTY_SQL,SOURCE_ETRM)
        end = time.time()
        time_taken = end - start
        metricDict["party_writer_insert_sql_time_taken_in_sec"] = time_taken 
        metricDict["insert_sql_rows_affected"] = row_affected
        
        
        if(SOURCE_ETRM == 'DEX'):
          SOURCE_TABLE_NAME = 'STO_CHRGACCT'
          executePyOdbcQueryWithParam3(CounterPartyWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_ETRM,SOURCE_TABLE_NAME)
          
        elif(SOURCE_ETRM == 'ENDUR_GPNA'):
          SOURCE_TABLE_NAME = 'PARTY'
          executePyOdbcQueryWithParam3(CounterPartyWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_ETRM,SOURCE_TABLE_NAME)
          
        elif(SOURCE_ETRM == 'ENDUR_SLMT'):
          SOURCE_TABLE_NAME = 'PARTY'
          executePyOdbcQueryWithParam3(CounterPartyWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_ETRM,SOURCE_TABLE_NAME)
          
        elif(SOURCE_ETRM == 'NUCLEUS'):
          SOURCE_TABLE_NAME = 'COMPANIES'
          executePyOdbcQueryWithParam3(CounterPartyWriter.UPDATE_WATERMARK_SQL,SOURCE_ETRM,SOURCE_ETRM,SOURCE_TABLE_NAME)
        
        elif(SOURCE_ETRM == 'ALIGNE'):
          print('load completed')
       
        
        status = validateUniqueParty(SOURCE_ETRM)
        if status != "SUCCESS":
          print("Uniqueness validation ....")
          raise Exception("UNIQUENESS_TEST_FAILED")
          
        print("starting duplicate SK check")
        status = validateDuplicatePartySK(SOURCE_ETRM)
        if status != "SUCCESS":
          print("duplicate validation ....")
          raise Exception("DUPLICATE_RECORDS_FOUND")
        
        print('data load completed')
        return ("SUCCESS", metricDict)

