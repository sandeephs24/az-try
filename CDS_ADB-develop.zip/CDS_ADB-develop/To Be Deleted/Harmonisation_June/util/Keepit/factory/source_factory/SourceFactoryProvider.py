# Databricks notebook source
class SourceFactoryProvider():
    mapOfSourceAndSourceFactory = {}
    mapOfSourceAndSourceFactory["ENDUR_GPNA"] = EndurGpnaSourceFactory
    mapOfSourceAndSourceFactory["DEX"] = DexSourceFactory'
    -
    mapOfSourceAndSourceFactory["REFERENCE"] = ReferenceSourceFactory
    
    @staticmethod
    def createDatasetFactory(source_name):
      print(SourceFactoryProvider.mapOfSourceAndSourceFactory)
      return SourceFactoryProvider.mapOfSourceAndSourceFactory[source_name]
