# Databricks notebook source
class DexSourceFactory(SourceFactory):
    
    mapOfDatasetAndDatasetReader = {}
    mapOfDatasetAndDatasetReader["BROKER"] = DexBrokerReader
    mapOfDatasetAndDatasetReader["TRADER"] = DexTraderReader
    mapOfDatasetAndDatasetReader["COUNTERPARTY"] = DexCounterPartyReader
    mapOfDatasetAndDatasetReader["LOCATION"] = DexLocationReader
    mapOfDatasetAndDatasetReader["COMMODITY"] = DexCommodityReader
    mapOfDatasetAndDatasetReader["DEAL_ATTRIBUTES"] = DexDealAttributesReader
    mapOfDatasetAndDatasetReader["CURRENCY"] = DexCurrencyReader
    mapOfDatasetAndDatasetReader["UNIT_OF_MEASURE"] = DexUnitOfMeasureReader
        
    mapOfDatasetAndDatasetProcessor = {}
    mapOfDatasetAndDatasetProcessor["BROKER"] = DexBrokerProcessor
    mapOfDatasetAndDatasetProcessor["TRADER"] = DexTraderProcessor
    mapOfDatasetAndDatasetProcessor["COUNTERPARTY"] = DexCounterPartyProcessor
    mapOfDatasetAndDatasetProcessor["LOCATION"] = DexLocationProcessor
    mapOfDatasetAndDatasetProcessor["COMMODITY"] = DexCommodityProcessor
    mapOfDatasetAndDatasetProcessor["DEAL_ATTRIBUTES"] = DexDealAttributesProcessor
    mapOfDatasetAndDatasetProcessor["UNIT_OF_MEASURE"] = DexUnitOfMeasureProcessor
    mapOfDatasetAndDatasetProcessor["CURRENCY"] = DexCurrencyProcessor
       
    mapOfDatasetAndDatasetWriter = {}
    mapOfDatasetAndDatasetWriter["BROKER"] = BrokerWriter
    mapOfDatasetAndDatasetWriter["TRADER"] = TraderWriter
    mapOfDatasetAndDatasetWriter["COUNTERPARTY"] = CounterPartyWriter
    mapOfDatasetAndDatasetWriter["LOCATION"] = LocationWriter
    mapOfDatasetAndDatasetWriter["COMMODITY"] = CommodityWriter
    mapOfDatasetAndDatasetWriter["DEAL_ATTRIBUTES"] = DealAttributesWriter
    mapOfDatasetAndDatasetWriter["UNIT_OF_MEASURE"] = UnitOfMeasureWriter
    mapOfDatasetAndDatasetWriter["CURRENCY"] = CurrencyWriter
    
    def createDatasetReader(dataset_name):
        return DexSourceFactory.mapOfDatasetAndDatasetReader[dataset_name]
    
    def createDatasetProcessor(dataset_name):
        return DexSourceFactory.mapOfDatasetAndDatasetProcessor[dataset_name]
    
    def createDatasetWriter(dataset_name):
        return DexSourceFactory.mapOfDatasetAndDatasetWriter[dataset_name]
    
