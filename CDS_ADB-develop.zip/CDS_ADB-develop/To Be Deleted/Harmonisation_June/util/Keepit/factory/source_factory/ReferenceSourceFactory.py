# Databricks notebook source
class ReferenceSourceFactory(SourceFactory):
    mapOfDatasetAndDatasetReader = {}
    mapOfDatasetAndDatasetReader["CURRENCY"] = ReferenceCurrencyReader
    mapOfDatasetAndDatasetReader["UNIT_OF_MEASURE"] = ReferenceUnitOfMeasureReader
    
    mapOfDatasetAndDatasetProcessor = {}
    mapOfDatasetAndDatasetProcessor["CURRENCY"] = ReferenceCurrencyProcessor
    mapOfDatasetAndDatasetProcessor["UNIT_OF_MEASURE"] = ReferenceUnitOfMeasureProcessor
       
    mapOfDatasetAndDatasetWriter = {}
    mapOfDatasetAndDatasetWriter["CURRENCY"] = CurrencyWriter
    mapOfDatasetAndDatasetWriter["UNIT_OF_MEASURE"] = UnitOfMeasureWriter
     
    def createDatasetReader(dataset_name):
        return ReferenceSourceFactory.mapOfDatasetAndDatasetReader[dataset_name]
    
    def createDatasetProcessor(dataset_name):
        return ReferenceSourceFactory.mapOfDatasetAndDatasetProcessor[dataset_name]
    
    def createDatasetWriter(dataset_name):
        return ReferenceSourceFactory.mapOfDatasetAndDatasetWriter[dataset_name]
