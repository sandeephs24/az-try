# Databricks notebook source
# MAGIC %run ./../writer/COMMON/FACT/FactWriter

# COMMAND ----------

class EndurGpnaSourceFactory(SourceFactory):
    mapOfDatasetAndDatasetReader = {}
    mapOfDatasetAndDatasetReader["BROKER"] = EndurGPNABrokerReader
    mapOfDatasetAndDatasetReader["TRADER"] = EndurGPNATraderReader
    mapOfDatasetAndDatasetReader["COUNTERPARTY"] = EndurGPNACounterPartyReader
    mapOfDatasetAndDatasetReader["LOCATION"] = EndurGPNALocationReader 
    mapOfDatasetAndDatasetReader["COMMODITY"] = EndurGPNACommodityReader
    mapOfDatasetAndDatasetReader["DEAL_ATTRIBUTES"] = EndurGPNADealAttributesReader
    mapOfDatasetAndDatasetReader["CURRENCY"] = EndurGPNACurrencyReader
    mapOfDatasetAndDatasetReader["UNIT_OF_MEASURE"] = EndurGPNAUnitOfMeasureReader
    mapOfDatasetAndDatasetReader["FACT"] = EndurGPNAFactReader
        
    mapOfDatasetAndDatasetProcessor = {}
    mapOfDatasetAndDatasetProcessor["BROKER"] = EndurGPNABrokerProcessor
    mapOfDatasetAndDatasetProcessor["TRADER"] = EndurGPNATraderProcessor
    mapOfDatasetAndDatasetProcessor["COUNTERPARTY"] = EndurGPNACounterPartyProcessor
    mapOfDatasetAndDatasetProcessor["LOCATION"] = EndurGPNALocationProcessor
    mapOfDatasetAndDatasetProcessor["COMMODITY"] = EndurGPNACommodityProcessor
    mapOfDatasetAndDatasetProcessor["DEAL_ATTRIBUTES"] = EndurGPNADealAttributesProcessor
    mapOfDatasetAndDatasetProcessor["CURRENCY"] = EndurGPNACurrencyProcessor
    mapOfDatasetAndDatasetProcessor["UNIT_OF_MEASURE"] = EndurGPNAUnitOfMeasureProcessor
    mapOfDatasetAndDatasetProcessor["FACT"] = EndurGPNAFactProcessor
    
       
    mapOfDatasetAndDatasetWriter = {}
    mapOfDatasetAndDatasetWriter["BROKER"] = BrokerWriter
    mapOfDatasetAndDatasetWriter["TRADER"] = TraderWriter
    mapOfDatasetAndDatasetWriter["COUNTERPARTY"] = CounterPartyWriter
    mapOfDatasetAndDatasetWriter["LOCATION"] = LocationWriter
    mapOfDatasetAndDatasetWriter["COMMODITY"] = CommodityWriter
    mapOfDatasetAndDatasetWriter["DEAL_ATTRIBUTES"] = DealAttributesWriter
    mapOfDatasetAndDatasetWriter["CURRENCY"] = CurrencyWriter
    mapOfDatasetAndDatasetWriter["UNIT_OF_MEASURE"] = UnitOfMeasureWriter
    mapOfDatasetAndDatasetWriter["FACT"] = FactWriter
     
    def createDatasetReader(dataset_name):
        return EndurGpnaSourceFactory.mapOfDatasetAndDatasetReader[dataset_name]
    
    def createDatasetProcessor(dataset_name):
        return EndurGpnaSourceFactory.mapOfDatasetAndDatasetProcessor[dataset_name]
    
    def createDatasetWriter(dataset_name):
        return EndurGpnaSourceFactory.mapOfDatasetAndDatasetWriter[dataset_name]
