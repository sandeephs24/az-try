# Databricks notebook source
import abc
class SourceFactory(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def getDatasetReaderFactory(self):
        pass
