# Databricks notebook source
# MAGIC %run ./connection

# COMMAND ----------

import pyodbc
synapse_url = jdbcConnection()

# COMMAND ----------

def validateMetricReaderCountVsUpdateAndInsertCount(metricDict, reader_count_metric_name, update_count_metric_name, insert_count_metric_name):
    
    reader_count = int(metricDict[reader_count_metric_name])
    
    update_count = int(metricDict[update_count_metric_name])
    
    insert_count = int(metricDict[insert_count_metric_name])
    total_count = update_count + insert_count
    
    print(reader_count)
    print(update_count)
    print(insert_count)
    print(total_count)
    if (reader_count != update_count + insert_count):
      return "FAIL"
    else:
      return "SUCCESS"
    
    

# COMMAND ----------

def validateMetricReaderCountVsUpdateAndInsertCount_new(metricDict, reader_count_metric_name,select_non_scd_count_metric_name, update_count_metric_name, insert_count_metric_name):
    
    reader_count = int(metricDict[reader_count_metric_name])
    select_count = int(metricDict[select_non_scd_count_metric_name])
    scd_reader_count = reader_count-select_count
        
    update_count = int(metricDict[update_count_metric_name])
    
    actual_reader_count = scd_reader_count + update_count
    
    insert_count = int(metricDict[insert_count_metric_name])
    total_count = update_count + insert_count
    
    print(reader_count)
    print("select metric")
    print(select_count)
    print(scd_reader_count)
    print(update_count)
    print(insert_count)
    print(total_count)
    if (actual_reader_count != update_count + insert_count):
      return "FAIL"
    else:
      return "SUCCESS"
    
    

# COMMAND ----------

def validateMetricSCDUpdateVsSCDInsertCount(metricDict, scd_update_count_metric_name, scd_insert_count_metric_name):
    print("here")
    scd_update_count = int(metricDict[scd_update_count_metric_name])
    scd_insert_count = int(metricDict[scd_insert_count_metric_name])
    
    if (scd_update_count != scd_insert_count):
      return "FAIL"
    else:
      return "SUCCESS"


# COMMAND ----------

def validateMetricReaderCountVsUpdateAndInsertCountWrapper(metricDict) :
  
  metricValidationStatus = validateMetricReaderCountVsUpdateAndInsertCount(metricDict,'reader_record_count','update_sql_rows_affected','insert_sql_rows_affected')
  
  if metricValidationStatus != 'SUCCESS':
    raise Exception("READER_COUNT_SHOULD_EQUAL_TO_INSERT_PLUS_UPDATE_COUNT_CHECK_FAILED")
