# Databricks notebook source
# MAGIC %run ./connection

# COMMAND ----------

# Function to mount ADLS
def mount_ADLS():
  
  (adls_url,configs) = fetchADLSConnectionConfig()
  #"adl://shell01eunadls1lserrccrn.azuredatalakestore.net/"
  dbutils.fs.mount(
  source = adls_url,
  mount_point = "/mnt/ADLS/",
  extra_configs = configs)

# COMMAND ----------

def unmount_ADLS():
  try:
    dbutils.fs.unmount("/mnt/ADLS/")
  except Exception as e:
    print("Could not unmount")

# COMMAND ----------

unmount_ADLS()
mount_ADLS()


# COMMAND ----------

# MAGIC %fs ls /mnt/ADLS
