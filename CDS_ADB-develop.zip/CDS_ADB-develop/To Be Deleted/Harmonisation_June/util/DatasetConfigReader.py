# Databricks notebook source
# MAGIC %run ./connection

# COMMAND ----------

# MAGIC %run ./SparkSessionBuilder

# COMMAND ----------

def getDatasetConfigForTheTable(spark,source_name,dataset_name):
  
  query = "select adls_url + adls_path as adls_full_path from tsa_curated.dataset_config a,tsa_curated.dataset_connection b where a.connection_name = b.connection_name and source_name = '{0}' and dataset_name = '{1}'".format(source_name,dataset_name)
  
  df = jdbcReaderQuery(spark,query)
  v_adls_full_path=df.select('adls_full_path').collect()[0][0]
  print(v_adls_full_path)
  
  return v_adls_full_path

# COMMAND ----------

def readDatasetConfigAndCreateTempView(spark, source_etrm, dataset_name, read_format, view_name):
  adls_path = getDatasetConfigForTheTable_new(spark,source_etrm,dataset_name)
  #print(adls_path)
  df = spark.read.format(read_format).load(adls_path)
  df.createOrReplaceTempView(view_name)

# COMMAND ----------

def readDatasetConfigAndCreateTempViewWithSCD_Lepton(spark, source_etrm, dataset_name, read_format, view_name):
  adls_path = getDatasetConfigForTheTable_new(spark,source_etrm,dataset_name)
  #print(adls_path)
  df = spark.read.format(read_format).load(adls_path)
  df.createOrReplaceTempView(view_name)
  #df.printSchema()
  df = spark.sql("select * from {0} where ACTIVE_INDICATOR = 'Y'".format(view_name))
  df.createOrReplaceTempView(view_name)
  

# COMMAND ----------

def readDatasetConfigAndCreateTempViewWithSCD_GV_WithSPN(spark, source_etrm, dataset_name, read_format, view_name):
  adls_path = getDatasetConfigForTheTable_new(spark,source_etrm,dataset_name)
  df = spark.read.format(read_format).load(adls_path)
  print(adls_path)
  df.createOrReplaceTempView(view_name)
  df = spark.sql("select * from {0} where ACTIVE_INDICATOR = 'Y'".format(view_name))
  df.createOrReplaceTempView(view_name)

# COMMAND ----------

def readDatasetConfigAndCreateTempViewWithSCD_GV_PNL_WithSPN(spark, source_etrm, dataset_name, read_format, view_name):
  adls_path = getDatasetConfigForTheTable_new(spark,source_etrm,dataset_name)
  df = spark.read.format(read_format).option("mergeSchema", "true").load(adls_path)
  print(adls_path)
  df.createOrReplaceTempView(view_name)
  df = spark.sql("select * from {0} where ACTIVE_INDICATOR = 'Y'".format(view_name))
  df.createOrReplaceTempView(view_name)

# COMMAND ----------

def readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN(spark, source_etrm, dataset_name, read_format, view_name):
  adls_path = getDatasetConfigForTheTable_new(spark,source_etrm,dataset_name)
  df = spark.read.format(read_format).load(adls_path)
  print(adls_path)
  df.createOrReplaceTempView(view_name)
  df = spark.sql("select * from {0} where ACTIVE_INDICATOR = 'Y'".format(view_name))
  df.createOrReplaceTempView(view_name)

# COMMAND ----------

def readDatasetConfigAndCreateTempViewWithSCD_Lepton_WithSPN_history(spark, source_etrm, dataset_name, read_format, view_name):
  adls_path = getDatasetConfigForTheTable_new(spark,source_etrm,dataset_name)
  df = spark.read.format(read_format).load(adls_path)
  df.createOrReplaceTempView(view_name)
  df = spark.sql("select * from {0} where ACTIVE_INDICATOR = 'NULL'".format(view_name))
  df.createOrReplaceTempView(view_name)

# COMMAND ----------

def readDatasetConfigAndCreateTempViewWithSCD_CDS(spark, source_etrm, dataset_name, read_format, view_name):
  adls_path = getDatasetConfigForTheTable(spark,source_etrm,dataset_name)
  df = spark.read.format(read_format).load(adls_path)
  df.createOrReplaceTempView(view_name)
  df = spark.sql("select * from {0} where IS_RECORD_ACTIVE = 1".format(view_name))
  df.createOrReplaceTempView(view_name)

# COMMAND ----------

def readDatasetConfigAndCreateTempViewWithSCD_CDS_WithSPN(spark, source_etrm, dataset_name, read_format, view_name):
  adls_path = getDatasetConfigForTheTable_new(spark,source_etrm,dataset_name)
  print(adls_path)
  df = spark.read.format(read_format).load(adls_path)
  df.createOrReplaceTempView(view_name)
  df = spark.sql("select * from {0} where IS_RECORD_ACTIVE = 1".format(view_name))
  df.createOrReplaceTempView(view_name)

# COMMAND ----------

def readDatasetConfigAndCreateTempView_WithSPN(spark, source_etrm, dataset_name, read_format, view_name):
  adls_path = getDatasetConfigForTheTable_new(spark,source_etrm,dataset_name)
  df = spark.read.format(read_format).load(adls_path)
  df.createOrReplaceTempView(view_name)

# COMMAND ----------

def getDatasetConfigForTheTable_new(spark,source_name,dataset_name):
  
  query = "select adls_path as adls_full_path from tsa_curated.dataset_config a,tsa_curated.dataset_connection b where a.connection_name = b.connection_name and source_name = '{0}' and dataset_name = '{1}'".format(source_name,dataset_name)
  
  print(query)
  df = jdbcReaderQuery(spark,query)
  print("Count - ", df.count())
  v_adls_full_path=df.select('adls_full_path').collect()[0][0]
  v_adls_full_path='/mnt/ADLS' + v_adls_full_path
  
  return v_adls_full_path

# COMMAND ----------

def readDatasetConfigAndCreateDeltaTable(spark, source_etrm, dataset_name, view_name):
  adls_path = getDatasetConfigForTheTable_new(spark,source_etrm,dataset_name)
  spark.sql("DROP TABLE IF EXISTS " + view_name)
  create_sql = "CREATE TABLE " + view_name + " USING delta LOCATION " + adls_path
  
  df = spark.read.format(read_format).load(adls_path)
  df.createOrReplaceTempView(view_name)
