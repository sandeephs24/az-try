# Databricks notebook source
tsaConfig = { 
  "dataSets_dev": {
    "description": "Here we define configuration of storage acoount we use for reading different files ",
    "authInfo": {
              "dbDatabase": "shell-01-eun-sqdw-qcjndxivoedifdplsoyc",
              "dbServer": "shell-01-eun-sq-ymkuptlzfbcqiajeswov.database.windows.net",
              "dbUser": "tsa_login2", 
              "kv_scope": "key-vault-scope",
              "kv_key": "curated-db-key",
              "dbJdbcPort": "1433",
              "dbJdbcExtraOptions": "encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
      },    
      "BlobInfo":{
      "config" : "fs.azure.sas.tsafiles.tcfilestoreblob.blob.core.windows.net",
      "sourceCont" : "wasbs://tsafiles@tcfilestoreblob.blob.core.windows.net",
      "tempDir" : "/tempDirsTSA",
      "accountkey" : "fs.azure.account.key.tcfilestoreblob.blob.core.windows.net",
      "token" : "poQM6Hn0SuFP34iG8lGE/G9N9U9EaLT23+TMt7Sta4V4CC2Tb5NM55SZb+StS70BRt/a0yqapyVSB+FqNN9K/Q=="
    },
      "ADLSInfo":{
        "kv_scope": "key-vault-scope",
        "kv_key": "AZ-DNA-SPN-N-DS-29824556d1874f36b011",
        "adls_url" : "adl://shell01eunadls1lserrccrn.azuredatalakestore.net/",
        "client_application_id" : "5115c531-6ce8-494d-b67d-964740500504",
        "adls_refresh_url" : "https://login.microsoftonline.com/db1e96a8-a3da-442a-930b-235cac24cd5c/oauth2/token"
      }
  },
  "dataSets_uat": {
    "description": "Here we define configuration of storage acoount we use for reading different files ",
    "authInfo": {
              "dbDatabase": "shell-01-eun-sqdw-kcwepgnmwgpalqxuhvva",
              "dbServer": "shell-01-eun-sq-yqdgvswztemplburonfj.database.windows.net",
              "dbUser": "tsa_login2", 
              "kv_scope": "key-vault-scope",
              "kv_key": "curated-db-key",
              "dbJdbcPort": "1433",
              "dbJdbcExtraOptions": "encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
      },    
   "BlobInfo":{
      "config" : "fs.azure.sas.tcfiles.tcfilestoreblob.blob.core.windows.net",
      "sourceCont" : "wasbs://tcfiles@tcfilestoreblob.blob.core.windows.net",
      "tempDir" : "/tempDirsTSA",
      "accountkey" : "fs.azure.account.key.tcfilestoreblob.blob.core.windows.net",
      "token" : "poQM6Hn0SuFP34iG8lGE/G9N9U9EaLT23+TMt7Sta4V4CC2Tb5NM55SZb+StS70BRt/a0yqapyVSB+FqNN9K/Q=="
    },
      "ADLSInfo":{
       
        "adls_url" : "adl://shell01eunadls1lserrccrn.azuredatalakestore.net/",
        "client_application_id" : "5115c531-6ce8-494d-b67d-964740500504",
        "kv_scope": "key-vault-scope",
        "kv_key": "AZ-DNA-SPN-N-DS-e3df3c00e0fd4c6bace0",
        "adls_refresh_url" : "https://login.microsoftonline.com/db1e96a8-a3da-442a-930b-235cac24cd5c/oauth2/token"
      }
  },
  "dataSets_prod": {
    "description": "Here we define configuration of storage acoount we use for reading different files ",
    "authInfo": {
              "dbDatabase": "shell-31-eun-sqdw-oafxsqnzxfsixfjdeolv",
              "dbServer": "shell-31-eun-sq-dvwczpejxqbtihnalomg.database.windows.net",
              "dbUser": "tsa_login2", 
              "kv_scope": "key-vault-scope",
              "kv_key": "curated-db-key",
              "dbJdbcPort": "1433",
              "dbJdbcExtraOptions": "encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
      },    
    "BlobInfo":{
      "config" : "fs.azure.sas.tcfiles.tcfilestoreblob.blob.core.windows.net",
      "sourceCont" : "wasbs://tcfiles@tcfilestoreblob.blob.core.windows.net",
      "tempDir" : "/tempDirsTSA",
      "accountkey" : "fs.azure.account.key.tcfilestoreblob.blob.core.windows.net",
      "token" : "poQM6Hn0SuFP34iG8lGE/G9N9U9EaLT23+TMt7Sta4V4CC2Tb5NM55SZb+StS70BRt/a0yqapyVSB+FqNN9K/Q=="
    },
      "ADLSInfo":{
        "adls_url" : "adl://shell01eunadls1lserrccrn.azuredatalakestore.net/",
        "client_application_id" : "e2ac6b59-9aca-497f-a213-bfda6daa95a5",
        "kv_scope": "key-vault-scope",
        "kv_key": "AZ-DNA-SPN-P-DS-9e63e70b8dae4f048be2",
        "adls_refresh_url" : "https://login.microsoftonline.com/db1e96a8-a3da-442a-930b-235cac24cd5c/oauth2/token"
      }
    }
}
