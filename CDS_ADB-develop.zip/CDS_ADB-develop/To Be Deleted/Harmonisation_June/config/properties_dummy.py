# Databricks notebook source
tsaConfig = { 
  "dataSets_dev": {
    "description": "Here we define configuration of storage acoount we use for reading different files ",
    "authInfo": {
              "dbDatabase": "shell-01-eun-sqdw-qcjndxivoedifdplsoyc",
              "dbServer": "shell-01-eun-sq-ymkuptlzfbcqiajeswov.database.windows.net",
              "dbUser": "tsa_login2", 
              "kv_scope": "key-vault-scope",
              "kv_key": "curated-db-key",
              "dbJdbcPort": "1433",
              "dbJdbcExtraOptions": "encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
      },    
      "BlobInfo":{
      "config" : "fs.azure.sas.tsafiles.tcfilestoreblob.blob.core.windows.net",
      "sourceCont" : "wasbs://tsafiles@tcfilestoreblob.blob.core.windows.net",
      "tempDir" : "/tempDirsTSA",
      "accountkey" : "fs.azure.account.key.tcfilestoreblob.blob.core.windows.net",
      "token" : "poQM6Hn0SuFP34iG8lGE/G9N9U9EaLT23+TMt7Sta4V4CC2Tb5NM55SZb+StS70BRt/a0yqapyVSB+FqNN9K/Q=="
    },
      "ADLSInfo":{
        "kv_scope": "key-vault-scope",
        "kv_key": "AZ-DNA-SPN-N-DS-29824556d1874f36b011",
        "adls_url" : "adl://shell01eunadls1lserrccrn.azuredatalakestore.net/",
        "client_application_id" : "5115c531-6ce8-494d-b67d-964740500504",
        "adls_refresh_url" : "https://login.microsoftonline.com/db1e96a8-a3da-442a-930b-235cac24cd5c/oauth2/token"
      }
  }
}
