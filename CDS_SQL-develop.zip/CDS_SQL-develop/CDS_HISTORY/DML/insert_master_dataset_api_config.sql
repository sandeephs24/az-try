delete from taf.master_dataset_api_config
INSERT INTO taf.master_dataset_api_config
([dataset_name],[target_table],[api_link],[tenant],[spn_key],[spn_secret],[next_api_link],[create_date],[load_mode])
VALUES
 ('trigger_details',
 'cp_data.trigger_details',
 'https://management.azure.com/subscriptions/e8f6becb-b3ab-4300-8b75-bba84984ed96/resourceGroups/shell-32-rg-zektebndzkwnghxtbdpq/providers/Microsoft.DataFactory/factories/shell-32-eun-adf-xleyhrfiybpvpmgaeld/triggers/?api-version=2018-06-01',
 'db1e96a8-a3da-442a-930b-235cac24cd5c',
 'c09c9cc8-9218-4ec4-97d3-06e87bc27d7b',
 'AZ-DNA-SPN-P-DS-823422da7a0e43678a70',
 'nextLink',
 CONVERT(datetime,'2023-04-26 10:28:40.643',121),
 'truncate_and_load')
