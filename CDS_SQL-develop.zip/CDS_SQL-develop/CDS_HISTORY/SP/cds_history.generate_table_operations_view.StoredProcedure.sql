/****** Object:  StoredProcedure [cds_history].[generate_table_operations_view]    Script Date: 9/5/2023 12:21:19 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO








CREATE procedure [cds_history].[generate_table_operations_view](
@schema_name varchar(255), 
@table_name varchar(255),
@history_schema varchar(255) , 
@history_table_name varchar(255) ,
@out_operation_query_for_table varchar(MAX) output 
)
as
begin

DECLARE @l_primary_key varchar(255)
DECLARE @history_schema_table varchar(255)
DECLARE @main_schema_table varchar(255)

select @l_primary_key = C.COLUMN_NAME FROM
INFORMATION_SCHEMA.TABLE_CONSTRAINTS T
JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE C
ON C.CONSTRAINT_NAME=T.CONSTRAINT_NAME
WHERE
C.TABLE_NAME= @table_name
and T.CONSTRAINT_TYPE='PRIMARY KEY'

SET @main_schema_table = @schema_name + '.' + @table_name
SET @history_schema_table = @history_schema + '.' + @history_table_name
DECLARE @l_find_inserts varchar(MAX)
DECLARE @l_find_updates varchar(MAX)
DECLARE @l_find_deletes varchar(MAX)



SET @l_find_inserts = 'SELECT ' +  '''' + 'INSERT' + '''' + ' as Operation,' +  '''' +@table_name + '''' + ' as table_name' + ',' + '''' + @l_primary_key + '''' + ' as primary_key,' + @l_primary_key + ' as primary_key_value ,ValidTo, ValidFrom from ' + @main_schema_table  + 
				' as main_table where not exists(select 1 from ' + @history_schema_table
				+ ' as history_table where history_table.' 
				+ @l_primary_key + ' = ' + 'main_table.' + @l_primary_key + ')'  



SET @l_find_updates = 'SELECT ' + '''' + 'UPDATE' + '''' + ' as Operation,'+ '''' +@table_name + '''' + ' as table_name' +  ',' +  '''' + @l_primary_key + '''' + ' as primary_key,' + @l_primary_key + '  as primary_key_value,ValidTo, ValidFrom from ' + @main_schema_table  + 
				' as main_table where exists(select 1 from ' + @history_schema_table 
				+ ' as history_table where history_table.' 
				+ @l_primary_key + ' = ' + 'main_table.' + @l_primary_key + ')'  



SET @l_find_deletes = 'SELECT ' + '''' + 'DELETE' + '''' + ' as Operation,' + '''' +@table_name + '''' + ' as table_name' + ',' + '''' + @l_primary_key + '''' + ' as primary_key,' + @l_primary_key 
					+ '  as primary_key_value,ValidTo, ValidFrom from ' + @history_schema_table + 
				' as history_table where not exists(select 1 from ' + @main_schema_table 
				+ ' as main_table where main_table.' 
				+ @l_primary_key + ' = ' + 'history_table.' + @l_primary_key + ')'  



DECLARE @l_all nvarchar(max)
SET @l_all = 'select operation, table_name, primary_key,primary_key_value, validTo, validFrom from(' + @l_find_inserts + ' UNION ' + @l_find_updates + ' UNION ' + @l_find_deletes +') a'

set @out_operation_query_for_table = @l_all

end
GO


