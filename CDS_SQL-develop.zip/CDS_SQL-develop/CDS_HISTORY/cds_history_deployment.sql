https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/schema.sql
https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/temporal_ddl.sql
https://github.com/sede-x/CDS_SQL/blob/main/CP_Data/SP/usp_upsert_metadata_info.sql

https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/Table/cds_history.meta_config.Table.sql
https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/dml_meta_config

https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/View/cds_history.view_unpivot_history.View.sql
https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/View/cds_history.view_unpivot_main.View.sql
https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/View/cds_history.view_cds_unpivot.View.sql
https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/View/cds_history.table_operation_view.View.sql
https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/View/cds_history.cds_table_operation_view.View.sql
https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/View/cds_history.cds_version_view.View.sql
https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/View/cds_history.what_changed_view.View.sql

https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/SP/cds_history.sp_get_unpivot_query.StoredProcedure.sql
https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/SP/cds_history.create_unpivot_views.StoredProcedure.sql

https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/SP/cds_history.generate_table_operations_view.StoredProcedure.sql
https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/SP/cds_history.create_table_operation_view.StoredProcedure.sql
https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/SP/cds_history.create_cds_table_operation_view.StoredProcedure.sql

https://github.com/sede-x/CDS_SQL/blob/main/CDS_HISTORY/SP/cds_history.sp_show_history.StoredProcedure.sql
