/****** Object:  Table [Preprocessor_schema].[adf_log_detail]    Script Date: 3/23/2023 11:38:04 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Preprocessor_schema].[adf_log_detail](
	[pipeline_run_id] [varchar](255) NULL,
	[pipeline_name] [varchar](255) NULL,
	[metric_key] [varchar](255) NULL,
	[metric_value] [varchar](255) NULL,
	[type_json] [varchar](255) NULL,
	[log_time] [datetime] NULL
) ON [PRIMARY]
GO

