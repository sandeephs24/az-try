/****** Object:  Table [Preprocessor_schema].[file_preparer_watermark]    Script Date: 3/23/2023 11:39:48 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Preprocessor_schema].[file_preparer_watermark](
	[source_name] [varchar](20) NULL,
	[source_KPI_name] [varchar](120) NULL,
	[table_name] [varchar](100) NULL,
	[offset_column] [varchar](100) NULL,
	[last_offset_value] [varchar](100) NULL
) ON [PRIMARY]
GO

