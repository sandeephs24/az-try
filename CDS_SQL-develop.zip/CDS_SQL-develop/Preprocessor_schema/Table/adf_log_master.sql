/****** Object:  Table [Preprocessor_schema].[adf_log_master]    Script Date: 3/23/2023 11:38:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [Preprocessor_schema].[adf_log_master](
	[pipeline_run_id] [varchar](255) NULL,
	[pipeline_name] [varchar](255) NULL,
	[start_date] [datetime] NULL,
	[end_date] [datetime] NULL,
	[time_taken] [int] NULL,
	[pipeline_params] [varchar](255) NULL,
	[run_status] [varchar](255) NULL,
	[log_date] [datetime] NULL,
	[log_time] [datetime] NULL,
	[error_message] [varchar](1024) NULL,
	[databricks_runPageUrl] [varchar](1024) NULL,
	[databricks_execDurationSec] [int] NULL
) ON [PRIMARY]
GO

