begin
declare @initial_value_for_allinsseq varchar(255)
select @initial_value_for_allinsseq = concat(FORMAT(DATEADD(DAY, -1, GETDATE()),'yyyy-MM-dd'),' 00:00:00')

declare @initial_value_for_alltrade varchar(255)
select @initial_value_for_alltrade = concat(FORMAT(DATEADD(DAY, -1, GETDATE()),'yyyy-MM-dd'),' 00:00:00|0|0|0')

delete from preprocessor_schema.file_preparer_watermark
where source_name = 'TRAYPORT'
and source_kpi_name in ('Epex_All_Ins_Seq_Data', 'Epex_All_Ohlcv_Trade_Data', 'Epex_AllTrade_Data')

insert into preprocessor_schema.file_preparer_watermark
(
source_name, source_kpi_name, table_name, offset_column, last_offset_value
)
values
(
'TRAYPORT', 'Epex_All_Ins_Seq_Data', null, 'OriginalTradingStart', @initial_value_for_allinsseq
)


insert into preprocessor_schema.file_preparer_watermark
(
source_name, source_kpi_name, table_name, offset_column, last_offset_value
)
values
(
'TRAYPORT', 'Epex_All_Ohlcv_Trade_Data', null, 'OriginalTradingStart', @initial_value_for_alltrade
)

insert into preprocessor_schema.file_preparer_watermark
(
source_name, source_kpi_name, table_name, offset_column, last_offset_value
)
values
(
'TRAYPORT', 'Epex_AllTrade_Data', null, 'OriginalTradingStart', @initial_value_for_alltrade
)
end