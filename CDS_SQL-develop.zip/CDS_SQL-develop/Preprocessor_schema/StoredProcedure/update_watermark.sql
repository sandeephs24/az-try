/****** Object:  StoredProcedure [Preprocessor_schema].[update_watermark]    Script Date: 3/23/2023 11:36:02 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [Preprocessor_schema].[update_watermark]
(
@source_name varchar(255),
@source_kpi_name varchar(255),
@last_offset_value varchar(255)
)
as
begin

update [preprocessor_schema].[file_preparer_watermark]
set last_offset_value = @last_offset_value
where 
source_name = @source_name and
source_kpi_name = @source_kpi_name

end
GO

