/****** Object:  StoredProcedure [Preprocessor_schema].[insert_preprocessor_metric_logs]    Script Date: 3/23/2023 11:26:15 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create procedure [Preprocessor_schema].[insert_preprocessor_metric_logs]
(
@pipeline_run_id varchar(255), 
@pipeline_name varchar(255), 
@databricksReturnJson varchar(1024)
)
as
begin


insert into [preprocessor_schema].adf_log_detail
select @pipeline_run_id,@pipeline_name, a.* , CURRENT_TIMESTAMP curr_date
from OPENJSON(@databricksReturnJson) a


end
GO

