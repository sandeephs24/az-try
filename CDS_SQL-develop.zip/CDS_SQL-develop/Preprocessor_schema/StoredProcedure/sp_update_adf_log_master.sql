/****** Object:  StoredProcedure [Preprocessor_schema].[sp_update_adf_log_master]    Script Date: 4/18/2023 12:59:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


create procedure [Preprocessor_schema].[sp_update_adf_log_master]
(
@pipeline_run_id varchar(255), 
@end_date datetime,
@time_taken int,
@run_status varchar(255),
@error_message varchar(1024),
@databricks_runpageurl varchar(1024) = '',
@databricks_execdurationsec int = 0
)
as
begin
update [preprocessor_schema].adf_log_master
set end_date = @end_date,
time_taken = @time_taken,
run_status = @run_status,
error_message = @error_message,
databricks_runPageUrl = @databricks_runpageurl,
databricks_execDurationSec = @databricks_execdurationsec
where pipeline_run_id = @pipeline_run_id

update [preprocessor_schema].adf_log_master  
set time_taken = datediff(ss, start_date ,end_date)/60
where pipeline_run_id =  @pipeline_run_id

end

GO


