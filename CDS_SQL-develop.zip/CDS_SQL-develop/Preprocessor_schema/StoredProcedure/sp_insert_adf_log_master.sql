/****** Object:  StoredProcedure [Preprocessor_schema].[sp_insert_adf_log_master]    Script Date: 3/23/2023 11:35:21 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Preprocessor_schema].[sp_insert_adf_log_master] 
(
@pipeline_run_id varchar(255), 
@pipeline_name varchar(255),
@start_date datetime,
@pipeline_params varchar(255)
)
AS
begin

insert into [preprocessor_schema].adf_log_master
(pipeline_run_id, pipeline_name, start_Date, pipeline_params, log_time)
values(@pipeline_run_id,@pipeline_name, @start_date, @pipeline_params, CURRENT_TIMESTAMP)

end
GO

