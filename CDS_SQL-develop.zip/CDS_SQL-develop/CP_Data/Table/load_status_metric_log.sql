/****** Object:  Table [cp_data].[load_status_metric_log]    Script Date: 7/24/2023 3:59:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [cp_data].[load_status_metric_log](
	[load_status_id] [int] NOT NULL,
	[project_id] [int] NULL,
	[source_id] [int] NULL,
	[batch_id] [nvarchar](50) NULL,
	[dataset] [nvarchar](255) NULL,
	[source_layer_id] [int] NULL,
	[target_layer_id] [int] NULL,
	[metric_name] [varchar](255) NULL,
	[metric_value] [varchar](max) NULL,
	[created_date] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


