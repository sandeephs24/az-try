SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [cp_data].[tsa_filepreparer_metadata](
	[source_file_name] [nvarchar](2000) NOT NULL,
	[source_file_path] [nvarchar](2000) NOT NULL,
	[land_file_path] [nvarchar](2000) NOT NULL,
	[period_type] [nvarchar](2000) NULL,
	[exchange_data_type] [nvarchar](2000) NULL,
	[source_name] [nvarchar](255) NULL
) ON [PRIMARY]
GO
