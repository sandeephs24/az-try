SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [cds_history].[meta_config](
	[schema_name] [varchar](255) NULL,
	[table_name] [varchar](255) NULL,
	[history_table_name] [varchar](255) NULL,
	[history_schema] [varchar](255) NULL
) ON [PRIMARY]
GO
