SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [cp_data].[tsa_filepreparer_dataset_config](
	[source_name] [nvarchar](2000) NOT NULL,
	[source_path] [nvarchar](2000) NOT NULL,
	[source_file_name] [nvarchar](2000) NOT NULL,
	[land_path] [nvarchar](2000) NULL,
	[last_ingestion_wm] [date] NULL,
	[exchange_data_type] [nvarchar](255) NULL
) ON [PRIMARY]
GO
