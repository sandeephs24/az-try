/****** Object:  StoredProcedure [cp_data].[update_load_status]    Script Date: 7/24/2023 4:04:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [cp_data].[update_load_status]
( 
	@Load_status_id int,
	@Project_id int,
	@Batch_id varchar(50),
	@Source_Dataset varchar(255),
	@Target_Dataset varchar(255),
	@Source_layer_id int,
	@Target_layer_id int,
--	@Load_start_time datetime,
	@Load_end_date datetime,
--	@Processing_time_in_minutes float,
	@Source_record_count int = 0,
	@Target_record_count int = 0,
	@Databytes_read float = 0,
	@Load_status varchar(20),
	@Status_description varchar(max),
/*	@Rerun_counter int,
	@Created_date datetime,
	@Created_by varchar(50)*/
	@Modified_date datetime,
	@Modified_by varchar(50),
	@Source_id int,
	@metricLogJson varchar(max) = '',
	@databricksUrl varchar(max) = '',
	@databricksExecTime int = 0
)
AS
SET NOCOUNT ON;

--DECLARE @count1 int;
DECLARE @start_time datetime;


Declare @w_watermark_id int;
DECLARE @l_dataset nvarchar(255);
DECLARE @w_dataset nvarchar(255);
DECLARE @w_source_schema nvarchar(255);
DECLARE @s_watermark_status nvarchar(255);

/*SET @count1 = (SELECT load_status_id 
				FROM cp_data.load_status
				WHERE project_id = @Project_id
					--AND batch_id = @Batch_id 
					AND source_dataset = @Source_Dataset 
					--AND target_dataset = @Target_Dataset 
					AND source_layer_id = @Source_layer_id
					AND target_layer_id = @Target_layer_id
				);
*/
SET @start_time = (SELECT load_start_time 
					FROM cp_data.load_status
					WHERE load_status_id = @Load_status_id
					);

IF EXISTS
(
	SELECT project_id, source_id, batch_id, source_dataset, target_dataset, source_layer_id, target_layer_id
	FROM cp_data.load_status 
	WHERE load_status_id = @Load_status_id
)

	BEGIN

		IF LOWER(@Load_status) = 'success'
		BEGIN
			UPDATE cp_data.load_status
				SET target_dataset = @Target_Dataset,
					load_end_date = @Load_end_date,
					processing_time_in_minutes = DATEDIFF(Minute, @start_time, @Load_end_date),
					source_record_count = @Source_record_count,
					target_record_count = @Target_record_count,
					databytes_read = @Databytes_read,
					load_status = @Load_status,
					status_description = @Status_description,
					modified_date = @Modified_date,
					modified_by = @Modified_by	
				WHERE load_status_id = @Load_status_id;

			SELECT @l_dataset = dataset
			FROM cp_data.load_status
			WHERE load_status_id = @Load_status_id;

			SELECT @w_watermark_id = watermark_id, @w_dataset = dataset, @w_source_schema = source_schema 
			FROM cp_data.watermark 
			WHERE batch_id = @Batch_id 
			AND project_id = @Project_id
			AND source_id = @Source_id
			AND dataset = @l_dataset
			
			IF @Source_layer_id = 2 and @Target_layer_id = 3
			BEGIN
			SET @s_watermark_status = 'RAW'
			END
			ELSE IF @Source_layer_id = 3 and @Target_layer_id = 4
			BEGIN
			SET @s_watermark_status = 'COMPLETE'
			END

			EXEC cp_data.usp_upsert_watermark @Project_id,  @Source_id  , @w_dataset, @w_source_schema, @s_watermark_status, @Batch_id

		END
		ELSE IF LOWER(@Load_status) = 'failed'
		BEGIN
			UPDATE cp_data.load_status
				SET target_dataset = @Target_Dataset,
					load_end_date = @Load_end_date,
					processing_time_in_minutes = DATEDIFF(Minute, @start_time, @Load_end_date),
					source_record_count = @Source_record_count,
					target_record_count = @Target_record_count,
					--databytes_read = @Databytes_read,
					load_status = @Load_status,
					status_description = @Status_description,
					modified_date = @Modified_date,
					modified_by = @Modified_by	
				WHERE load_status_id = @Load_status_id;

		END

		IF @metricLogJson <> ''
		BEGIN
			EXEC cp_data.sp_insert_load_status_metric @Load_status_id, 
														@Project_id, 
														@Batch_id, 
														@Source_id, 
														@l_dataset,
														@Source_layer_id ,
														@Target_layer_id,
														@databricksUrl,
														@databricksExecTime,
														@metricLogJson
		END
	END
GO


