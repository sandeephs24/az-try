/****** Object:  StoredProcedure [cds_history].[generate_what_changed]    Script Date: 8/10/2023 8:52:39 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE procedure [cds_history].[generate_what_changed](
@main_schema varchar(255),
@main_table varchar(255),
@history_schema varchar(255),
@history_table varchar(255),
@primary_key varchar(255))
as
begin
print('In what changed SP')
print(@main_schema)
print(@main_table) 
print(@history_schema)
print(@history_table) 
print(@primary_key) 


declare @out_unpivot_query_main varchar(max) = ''
exec [cds_history].[sp_get_unpivot_query] @main_schema,@main_table, @primary_key,@main_table, @out_unpivot_query_main OUT

declare @out_unpivot_query_history varchar(max) = ''
exec [cds_history].[sp_get_unpivot_query] @history_schema,@history_table, @primary_key,@main_table, @out_unpivot_query_history OUT

declare @where_update_records varchar(max) = ' where ' + @primary_key + ' in ' + '(select primary_key_value from cds_history.tbl_cds_history where table_name = ' + '''' +  @main_table+'''' + + 'and operation = ''UPDATE'') '

SET @out_unpivot_query_main = @out_unpivot_query_main + @where_update_records
SET @out_unpivot_query_history = @out_unpivot_query_history + @where_update_records


declare @what_changed_query nvarchar(max) = 'insert into cds_history.what_changed(main_table, primary_key_value, col_name, col_value, history_col_value)'
SET @what_changed_query =  @what_changed_query + 'select main.main_table_name,main.primary_key_value, main.col_name, main.col_value col_value, history.col_value history_col_value from ('
SET @what_changed_query =  @what_changed_query + @out_unpivot_query_main 
SET @what_changed_query =  @what_changed_query + ') main,'
SET @what_changed_query =  @what_changed_query + '('
SET @what_changed_query =  @what_changed_query + @out_unpivot_query_history
SET @what_changed_query =  @what_changed_query + ') history '
SET @what_changed_query =  @what_changed_query + 'where main.main_table_name = history.main_table_name '
SET @what_changed_query =  @what_changed_query + 'and main.primary_key_value = history.primary_key_value '
SET @what_changed_query =  @what_changed_query + 'and main.col_name = history.col_name '
SET @what_changed_query =  @what_changed_query + 'and main.col_value <> history.col_value'

print(@what_changed_query)
EXEC SP_EXECUTESQL @what_changed_query
print('IN what changed SP existing')
end


GO


