/****** Object:  StoredProcedure [cds_history].[generate_history_changes]    Script Date: 8/10/2023 8:50:30 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE procedure [cds_history].[generate_history_changes]
as
begin




DECLARE @MyCursor CURSOR;
DECLARE @schema_name varchar(max);
DECLARE @table_name varchar(max);
DECLARE @history_schema varchar(max);
DECLARE @history_table_name varchar(max);

BEGIN
    truncate table [cds_history].tbl_cds_history
	truncate table cds_history.what_changed

	SET @MyCursor = CURSOR FOR
    select schema_name, table_name, history_schema, history_table_name  from cds_history.meta_config       

    OPEN @MyCursor 
    FETCH NEXT FROM @MyCursor 
    INTO @schema_name, @table_name ,@history_schema, @history_table_name

    WHILE @@FETCH_STATUS = 0
    BEGIN
	  	
	  exec cds_history.generate_table_operations @schema_name,@table_name ,@history_schema, @history_table_name
	
	  
      FETCH NEXT FROM @MyCursor 
      INTO @schema_name, @table_name ,@history_schema, @history_table_name
    END; 

    CLOSE @MyCursor ;
    DEALLOCATE @MyCursor;

	update cds_history.tbl_cds_history
set project_name = (select project_name from cp_data.projects where project_id = cds_history.tbl_cds_history.primary_key_value)
where table_name = 'projects'


update cds_history.tbl_cds_history
set 
source_name = (select source_name from cp_data.sources 
					where source_id = cds_history.tbl_cds_history.primary_key_value),
source_alias = (select source_alias from cp_data.sources 
					where source_id = cds_history.tbl_cds_history.primary_key_value),
project_name = (select project_name from cp_data.projects 
					where project_alias = 
					(select project_alias from cp_data.sources 
					where source_id = cds_history.tbl_cds_history.primary_key_value))
where table_name = 'sources'

update cds_history.tbl_cds_history
set 
source_name = (select source_name from cp_data.sources 
					where source_id = 
					(select source_id from 
					cp_data.config_dataset 
					where config_id = cds_history.tbl_cds_history.primary_key_value)) ,
source_alias = (select source_alias from cp_data.sources 
					where source_id = 
					(select source_id from 
					cp_data.config_dataset 
					where config_id = cds_history.tbl_cds_history.primary_key_value)),
project_name = (select project_name from cp_data.projects 
					where project_id = 
					(select project_id from 
					cp_data.config_dataset 
					where config_id = cds_history.tbl_cds_history.primary_key_value)),
dataset_name = (select dataset from cp_data.config_dataset 
					where config_id = cds_history.tbl_cds_history.primary_key_value)
where table_name = 'config_dataset'


update cds_history.tbl_cds_history 
set operation_date = validFrom where operation in ('DELETE', 'INSERT')

update cds_history.tbl_cds_history 
set operation_date = validTo where operation in ('UPDATE')

END;



end

GO


