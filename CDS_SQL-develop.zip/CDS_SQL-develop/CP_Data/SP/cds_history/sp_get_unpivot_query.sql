/****** Object:  StoredProcedure [cds_history].[sp_get_unpivot_query]    Script Date: 8/10/2023 8:53:26 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE procedure [cds_history].[sp_get_unpivot_query]( 
@schema_name varchar(255), 
@table_name varchar(255),
@l_primary_key varchar(255),
@main_table varchar(255),
@out_unpivot_query varchar(max) OUTPUT
)
as
begin

print(@schema_name)
print(@table_name)
print(@l_primary_key)
print(@main_table)





select @out_unpivot_query= unpivot_query from
(
select  
case 
when @table_name like '%history%' then
'select ' + '''' + @table_name + '''' + ' as table_name,' + '''' + @main_table + '''' + ' as main_table_name,' + @l_primary_key +' as primary_key_value, col_name, col_value from ( select ' + + @l_primary_key + ',' + agg_col_cast +' from '+ @schema_name +'.'+ @table_name +' a where validTo = (select max(validTo) from ' + @schema_name + '.' + @table_name +' b where b.' + @l_primary_key +' = a.' + @l_primary_key +') ) p unpivot (col_value for col_name in (' + agg_col +')) as unpvt'
else 
'select ' + '''' + @table_name + '''' + ' as table_name,' + '''' + @main_table + '''' + ' as main_table_name,' + @l_primary_key +' as primary_key_value, col_name, col_value from ( select ' + + @l_primary_key + ',' + agg_col_cast +' from '+ @schema_name +'.'+ @table_name +' ) p unpivot (col_value for col_name in (' + agg_col +')) as unpvt'
end as unpivot_query
from
(
select table_name , string_agg(column_name, ',') agg_col,string_agg(cast_column_name, ',') agg_col_cast
from
(
SELECT table_name, column_name, 'cast(' + column_name + ' AS VARCHAR(MAX)) ' + column_name as cast_column_name
FROM INFORMATION_SCHEMA.COLUMNS
WHERE 
table_schema = @schema_name and
TABLE_NAME = @table_name
and column_name not in ('ValidFrom', 'ValidTo')
and column_name <> @l_primary_key 
) v1
group by table_name
) v2
) v3


end

GO


