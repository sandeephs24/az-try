/****** Object:  StoredProcedure [cp_data].[sp_insert_load_status_metric]    Script Date: 7/24/2023 4:03:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [cp_data].[sp_insert_load_status_metric]
( 
	@Load_status_id int,
	@Project_id int,
	@Batch_id varchar(50),
	@Source_id int,
	@dataset varchar(255),
	@Source_layer_id int,
	@Target_layer_id int,
	@databricksUrl varchar(max),
	@databricksExecDuration int,
	@metricLogJson varchar(max)
)
AS
BEGIN
	print 'here'
	insert into [cp_data].[load_status_metric_log]
	(
	[load_status_id],
	[project_id],
	[source_id],
	[batch_id],
	[dataset],
	[source_layer_id],
	[target_layer_id],
	metric_name,
	metric_value,
	[created_date]
	)
	select 
	@Load_status_id,
	@Project_id,
	@Source_id,
	@Batch_id,
	@dataset,
	@Source_layer_id,
	@Target_layer_id,
	a.[key] metric_name,
	a.[value] metric_value,
	current_timestamp created_date
	from openjson(@metricLogJson) a

	insert into [cp_data].[load_status_metric_log]
	(
	[load_status_id],
	[project_id],
	[source_id],
	[batch_id],
	[dataset],
	[source_layer_id],
	[target_layer_id],
	metric_name,
	metric_value,
	[created_date]
	)
	values( 
	@Load_status_id,
	@Project_id,
	@Source_id,
	@Batch_id,
	@dataset,
	@Source_layer_id,
	@Target_layer_id,
	'databricksUrl',
	@databricksUrl,
	current_timestamp 
	)

	insert into [cp_data].[load_status_metric_log]
	(
	[load_status_id],
	[project_id],
	[source_id],
	[batch_id],
	[dataset],
	[source_layer_id],
	[target_layer_id],
	metric_name,
	metric_value,
	[created_date]
	)
	values( 
	@Load_status_id,
	@Project_id,
	@Source_id,
	@Batch_id,
	@dataset,
	@Source_layer_id,
	@Target_layer_id,
	'databricksExecDurationInSec',
	@databricksExecDuration,
	current_timestamp 
	)


END
GO


