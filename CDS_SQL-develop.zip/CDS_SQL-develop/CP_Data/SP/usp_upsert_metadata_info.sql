/****** Object:  StoredProcedure [cp_data].[usp_upsert_metadata_info]    Script Date: 9/4/2023 2:19:19 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






-- DROP PROCEDURE [cp_data].[usp_upsert_metadata_info]




CREATE PROC [cp_data].[usp_upsert_metadata_info] 
	@config_values NVARCHAR(MAX)
	, @project_alias NVARCHAR(20) = ''
	, @source_alias_list NVARCHAR(MAX) = ''
	, @config_template_name NVARCHAR(50)
	, @config_database_schema NVARCHAR(20) = NULL  AS
BEGIN

BEGIN TRY

	-- DECLARE @config_values NVARCHAR(MAX);
	-- DECLARE @config_template_name NVARCHAR(50);
	-- DECLARE @config_database_schema NVARCHAR(20) = NULL
	-- 
	-- SET @config_template_name = 'projects';
	-- SET @config_values = N'[
    --     {
    --         "project_id": "1",
    --         "project_name": "Counter Party Data",
    --         "project_description": "Counter Party Data",
    --         "project_alias": "cp_data",
    --         "modified_by": "Emmanuel.Edegbo",
    --         "status": "Active",
    --         "config_environment": "UAT",
    --         "config_adls_store": "https://shell01eunadls1lserrccrn.azuredatalakestore.net/webhdfs/v1",
    --         "config_az_tenant_id": "db1e96a8-a3da-442a-930b-235cac24cd5c",
    --         "config_az_subscription_id": "ecb076fa-3003-44cb-bbc5-9b417e7e25da",
    --         "config_az_resource_group": "shell-01-rg-plqgsnrehdmdeajbnkjd",
    --         "config_adls_landing_path": "W00007-TS-DEV/LAND/1ST_PARTY/Gold_Tier_MI/##config_environment##",
    --         "config_adls_raw_path": "P00004-TS-DEV/RAW/SENS/1ST_PARTY/Gold_Tier_MI/##config_environment##",
    --         "config_adls_delta_path": "/RAW/W00007-TS-DEV/DELTA/NON_SENSITIVE/1stParty/GoldTier_MI",
    --         "config_sql_db_server": "shell-01-eun-sq-dyogurnmurnlyhuuodlt.database.windows.net",
    --         "config_sql_db_port": "3090",
    --         "config_sql_db_username": null,
    --         "config_sql_db_azure_kv_secret_name": null,
    --         "config_sql_dwh_server": null,
    --         "config_sql_dwh_port": null,
    --         "config_sql_dwh_username": null,
    --         "config_sql_dwh_azure_kv_secret_name": null,
    --         "config_enable_databricks_delta": "Y",
    --         "config_adls_landing_file_format": "avro",
    --         "config_adls_raw_file_format": "parquet",
    --         "config_alds_delta_file_format": "delta",
    --         "config_skip_adls_landing": "N",
    --         "config_skip_adls_raw": "N",
    --         "config_skip_adls_delta": "N",
    --         "config_skip_dwh": "N"
    --     },
    --     {
    --         "project_id": null,
    --         "project_name": null,
    --         "project_description": null,
    --         "project_alias": null,
    --         "modified_by": null,
    --         "status": null,
    --         "config_environment": null,
    --         "config_adls_store": null,
    --         "config_az_tenant_id": null,
    --         "config_az_subscription_id": null,
    --         "config_az_resource_group": null,
    --         "config_adls_landing_path": null,
    --         "config_adls_raw_path": null,
    --         "config_adls_delta_path": null,
    --         "config_sql_db_server": null,
    --         "config_sql_db_port": null,
    --         "config_sql_db_username": null,
    --         "config_sql_db_azure_kv_secret_name": null,
    --         "config_sql_dwh_server": null,
    --         "config_sql_dwh_port": null,
    --         "config_sql_dwh_username": null,
    --         "config_sql_dwh_azure_kv_secret_name": null,
    --         "config_enable_databricks_delta": null,
    --         "config_adls_landing_file_format": null,
    --         "config_adls_raw_file_format": null,
    --         "config_alds_delta_file_format": null,
    --         "config_skip_adls_landing": null,
    --         "config_skip_adls_raw": null,
    --         "config_skip_adls_delta": null,
    --         "config_skip_dwh": null
    --     }
    -- ]'

	
	-- Parameters used in stored procedure only
	DECLARE @config_table_name NVARCHAR(50) = @config_template_name;
	DECLARE @unique_columns NVARCHAR(MAX) = '';
	DECLARE @non_config_columns NVARCHAR(MAX);
	DECLARE @non_config_columns_cleaned NVARCHAR(MAX) = '';
	DECLARE @column_update_list NVARCHAR(MAX) = '';
	DECLARE @column_update_exclusion_list NVARCHAR(MAX) = '';
	DECLARE @insert_where_clause NVARCHAR(MAX) = '';
	DECLARE @merge_insert_list NVARCHAR(MAX) = '';
	DECLARE @merge_insert_exclusion_list NVARCHAR(MAX) = '';

	DECLARE @column_update_exclusion_list_new_records NVARCHAR(MAX) = '';
	
	DECLARE @upsert_query NVARCHAR(MAX);

	DECLARE @current_timestamp nvarchar(20);

	DECLARE @sql_transpose NVARCHAR(MAX) = '';
	DECLARE @sql_transpose_case NVARCHAR(MAX) = '';
	DECLARE @columns_transposed NVARCHAR(MAX);

	DECLARE @merge_join_clause NVARCHAR(MAX) = '';

	IF @config_database_schema IS NULL
	BEGIN
		SET @config_database_schema = 'cp_data';
	END

	SELECT @current_timestamp = REPLACE(convert(VARCHAR, GETDATE(), 120), ' ', 'T');

	print(@current_timestamp)
	



	-- DROP temp table if it exists
	IF OBJECT_ID('#metadata_config') IS NOT NULL DROP TABLE #metadata_config
	--GO

	
	-- Save metadata information into temp table
	SELECT * INTO #metadata_config FROM 
	(
		SELECT
			TRIM(config_json.[key]) AS [config_position]
			--, config_json.[value].[project_id] AS [config_position_value]
			, REPLACE(TRIM(config_json_value.[key]), 'updated_by', 'modified_by') AS [config_name]
			, TRIM(config_json_value.[value]) AS [config_value]
		FROM OPENJSON(@config_values) AS config_json
		CROSS APPLY OPENJSON ( config_json.value) AS config_json_value
		WHERE TRIM(config_json.[key]) IS NOT NULL OR TRIM(config_json.[key]) != ''
	) AS X
	--GO

	SELECT * FROM #metadata_config;


	-- Generate column names for the table from information schema
	SET @non_config_columns =  
		--Stuff((SELECT ','+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + ''
		Stuff((SELECT ','+quotename(Column_Name ) + ''
	FROM INFORMATION_SCHEMA.COLUMNS
	WHERE 
		TABLE_NAME=@config_table_name AND TABLE_SCHEMA=@config_database_schema
		AND Column_Name NOT IN ('source_id', 'config_id', 'config_dataset_column_id', 'config_description_id', 'created_date', 'created_by', 'modified_date','ValidTo','ValidFrom')
		ORDER BY ORDINAL_POSITION
	FOR XML PATH ('')),1,1,'')
	
	-- Remove square brackets from the table names
	SET @non_config_columns_cleaned = REPLACE(REPLACE(@non_config_columns, '[', ''), ']', '')
	PRINT('Column names: ' + @non_config_columns);
	PRINT('Column names cleaned: ' + @non_config_columns_cleaned);

	
	

	-- Generate columns update list for table from information schema	
	SET @column_update_list =  
		Stuff((SELECT ', '+quotename(REPLACE(TRIM(Column_Name), 'updated_by', 'modified_by') ) + '=new_records.'+quotename(REPLACE(TRIM(Column_Name), 'updated_by', 'modified_by') ) + ''
		--Stuff((SELECT ',new_records.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + '='+@config_database_schema+'.' + @config_table_name + '.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + ''
	FROM INFORMATION_SCHEMA.COLUMNS
	WHERE 
		TABLE_NAME=@config_table_name AND TABLE_SCHEMA=@config_database_schema
		AND Column_Name NOT IN ('project_id', 'source_id', 'config_id', 'config_dataset_column_id', 'config_description_id', 'created_date', 'created_by', 'modified_date','ValidTo','ValidFrom')
		ORDER BY ORDINAL_POSITION
	FOR XML PATH ('')),1,1,'')
	
	-- Remove square brackets from the table names
	SET @column_update_list = REPLACE(REPLACE(@column_update_list, '[', ''), ']', '')
	PRINT('Columns update list: ' + @column_update_list);




	
	-- Generate columns update list for table from information schema	
	SET @column_update_exclusion_list =  
		Stuff((SELECT ' , TRIM(existing_records.'+quotename(REPLACE(TRIM(Column_Name), 'updated_by', 'modified_by') ) + ') '
		--Stuff((SELECT ' OR existing_records.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + '!=new_records.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + ''
		--Stuff((SELECT ',new_records.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + '='+@config_database_schema+'.' + @config_table_name + '.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + ''
	FROM INFORMATION_SCHEMA.COLUMNS
	WHERE 
		TABLE_NAME=@config_table_name AND TABLE_SCHEMA=@config_database_schema
		AND Column_Name NOT IN ('project_id', 'source_id', 'config_id', 'config_dataset_column_id', 'config_description_id', 'created_date', 'created_by', 'modified_date', 'modified_by','ValidTo','ValidFrom')
		ORDER BY ORDINAL_POSITION
	FOR XML PATH ('')),1,1,'')

	-- Remove square brackets from the table names
	IF LEN(@column_update_exclusion_list) > 0
	BEGIN
		print(LEN(@column_update_exclusion_list))
		SET @column_update_exclusion_list = REPLACE(REPLACE(@column_update_exclusion_list, '[', ''), ']', '')
		SET @column_update_exclusion_list = RIGHT(@column_update_exclusion_list, LEN(@column_update_exclusion_list)-1)

		SET @column_update_exclusion_list_new_records = REPLACE(@column_update_exclusion_list, 'existing_records', 'new_records')
	END
	PRINT('Columns update exclusion list: ' + @column_update_exclusion_list);


	
	
	-- Generate columns update list for table from information schema	
	SET @merge_insert_list =  
		Stuff((SELECT ', new_records.'+quotename(REPLACE(TRIM(Column_Name), 'updated_by', 'modified_by') ) + ''
		--Stuff((SELECT ',new_records.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + '='+@config_database_schema+'.' + @config_table_name + '.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + ''
	FROM INFORMATION_SCHEMA.COLUMNS
	WHERE 
		TABLE_NAME=@config_table_name AND TABLE_SCHEMA=@config_database_schema
		AND Column_Name NOT IN ('source_id', 'config_id', 'config_dataset_column_id', 'config_description_id', 'created_date', 'created_by', 'modified_date','ValidTo','ValidFrom')
		ORDER BY ORDINAL_POSITION
	FOR XML PATH ('')),1,1,'')
	
	-- Remove square brackets from the table names
	SET @merge_insert_list = REPLACE(REPLACE(@merge_insert_list, '[', ''), ']', '')
	PRINT('MERGE INSERT list: ' + @merge_insert_list);



	-- Generate case statement for transpose query
	IF @config_template_name NOT IN ('config_dataset', 'config_dataset_columns')
		BEGIN
			SET @sql_transpose_case =  
				Stuff((SELECT ','+CONCAT(' MAX(CASE WHEN TRIM(config_name)=''', TRIM(Column_Name), ''' THEN TRIM(config_value) ELSE '''' END ) AS ', TRIM(Column_Name))
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE 
				TABLE_NAME=@config_table_name AND TABLE_SCHEMA=@config_database_schema
				AND Column_Name NOT IN ('source_id', 'config_id', 'config_dataset_column_id', 'config_description_id', 'created_date', 'created_by', 'modified_date','ValidTo','ValidFrom')
				ORDER BY ORDINAL_POSITION
			FOR XML PATH ('')),1,1,'')
		END
	ELSE
		BEGIN
			SET @sql_transpose_case =  
				Stuff((SELECT ','+CONCAT(' MAX(CASE WHEN TRIM(config_name)=''', TRIM(Column_Name), ''' THEN TRIM(config_value) ELSE '''' END ) AS ', TRIM(Column_Name))
			FROM INFORMATION_SCHEMA.COLUMNS
			WHERE 
				TABLE_NAME=@config_table_name AND TABLE_SCHEMA=@config_database_schema
				AND Column_Name NOT IN ('source_id', 'project_id', 'config_id', 'config_dataset_column_id', 'config_description_id', 'created_date', 'created_by', 'modified_date','ValidTo','ValidFrom')
				ORDER BY ORDINAL_POSITION
			FOR XML PATH ('')),1,1,'')
		END


	PRINT('Transcpose CASE statements: ' + @sql_transpose_case)

	DECLARE @update_columns NVARCHAR(MAX) = '';

	-- Define unique column identifiers
	IF @config_table_name = 'projects'
	BEGIN
		SET @merge_insert_exclusion_list = ' WHERE project_id IS NOT NULL AND project_id != '''' ';
		SET @unique_columns = ' TRIM(project_alias), TRIM(status) ';
		SET @insert_where_clause = ' WHERE TRIM(project_alias) NOT IN (SELECT DISTINCT TRIM(project_alias) FROM ' + @config_database_schema + '.' + @config_table_name + ') '
		SET @update_columns = ' TRIM(existing_records.project_alias)=TRIM(new_records.project_alias) AND existing_records.project_id=new_records.project_id ';
	END
	IF @config_table_name = 'sources'
	BEGIN
		SET @merge_insert_exclusion_list = ' WHERE source_alias IS NOT NULL AND TRIM(source_alias) != '''' ';
		-- SET @unique_columns = 'source_alias, source_type, source_type_name, source_onprem_cloud, source_internal_external, source_server, source_database_name, source_schema, status';
		SET @unique_columns = ' TRIM(source_alias), TRIM(source_type), TRIM(source_type_name), TRIM(source_onprem_cloud), TRIM(source_internal_external), TRIM(source_server), TRIM(source_database_name), TRIM(source_schema), TRIM(status) ';
		SET @insert_where_clause = ' WHERE CONCAT(TRIM(source_alias), TRIM(source_type), TRIM(source_type_name)) NOT IN (SELECT DISTINCT CONCAT(source_alias, source_type, source_type_name) FROM ' + @config_database_schema + '.' + @config_table_name + ')'
		SET @update_columns = ' TRIM(existing_records.source_alias)=TRIM(new_records.source_alias) ';
	END
	IF @config_table_name = 'config_descriptions'
	BEGIN
		SET @unique_columns = 'TRIM(config_name), TRIM(status)';
		SET @update_columns = ' TRIM(existing_records.config_name)=TRIM(new_records.config_name) ';
	END

	PRINT('Unique columns in table ''' + @config_table_name + ''': ' + @unique_columns)

		
	IF @config_template_name NOT IN ('config_dataset', 'config_dataset_columns')
	BEGIN

		IF OBJECT_ID('#metadata_nonconfig_transposed') IS NOT NULL DROP TABLE #metadata_nonconfig_transposed

		SET @sql_transpose = N' SELECT transposed_data.* FROM ( SELECT ' + @sql_transpose_case + '
		FROM #metadata_config 
		WHERE 
	 			config_name IN (SELECT TRIM(value) FROM STRING_SPLIT(''' + @non_config_columns_cleaned + ''', '',''))
		GROUP BY config_position ) transposed_data ' + @merge_insert_exclusion_list;

		PRINT('SQL transpose: ' + @sql_transpose);
		--EXEC(@sql_transpose)

		SET @upsert_query = 'MERGE ' + @config_database_schema + '.' + @config_table_name + ' AS [existing_records]
			USING (SELECT ' + @non_config_columns_cleaned + ' FROM #metadata_nonconfig_transposed) AS [new_records] 
			ON ' + @update_columns + '
			WHEN MATCHED AND EXISTS(SELECT ' + @column_update_exclusion_list + ' EXCEPT SELECT ' + @column_update_exclusion_list_new_records + ') THEN
			  UPDATE SET ' + @column_update_list + ', modified_date=''' + @current_timestamp + ''' 
			WHEN NOT MATCHED THEN
			  INSERT (' + @non_config_columns_cleaned + ', created_by, created_date, modified_date) VALUES (' + @merge_insert_list + ', new_records.modified_by, ''' + @current_timestamp + ''', ''' + @current_timestamp + ''')'

		print('UPSERT query: ' + @upsert_query)
		EXEC('
			SELECT * INTO #metadata_nonconfig_transposed FROM (' + @sql_transpose + ') AS transposed_data;' 
			+ 'SELECT * FROM #metadata_nonconfig_transposed;' 
			+ @upsert_query + ';'  
		);

	
		-- DROP temp table '#metadata_config_transposed' if it exists
		IF OBJECT_ID('#metadata_nonconfig_transposed') IS NOT NULL DROP TABLE #metadata_nonconfig_transposed

	END
	
	
	-- Extract config related columns from 'projects', 'config_dataset_columns' and 'config_dataset' worksheets
	IF @config_template_name IN ('projects', 'config_dataset', 'config_dataset_columns')
	BEGIN

		DECLARE @config_sql_query NVARCHAR(MAX) = '';
		
		PRINT(@config_template_name)
		
		IF @config_template_name = 'projects'
		BEGIN
			SET @config_table_name = 'config'
		END

		PRINT('New table name: ' + @config_table_name)
				

		-- Generate column names for the table from information schema
		SET @non_config_columns =  
			--Stuff((SELECT ','+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + ''
			Stuff((SELECT ','+quotename(TRIM(Column_Name) ) + ''
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE 
			TABLE_NAME=@config_table_name AND TABLE_SCHEMA=@config_database_schema
			AND Column_Name NOT IN ('config_id', 'config_dataset_column_id', 'config_description_id', 'created_date', 'created_by', 'modified_date','ValidTo','ValidFrom')
			ORDER BY ORDINAL_POSITION
		FOR XML PATH ('')),1,1,'')
	
		-- Remove square brackets from the table names
		SET @non_config_columns_cleaned = REPLACE(REPLACE(@non_config_columns, '[', ''), ']', '')
		PRINT('Column names2: ' + @non_config_columns);
		PRINT('Column names cleaned2: ' + @non_config_columns_cleaned);
		
		
	

		-- Generate columns update list for table from information schema	
		SET @column_update_list =  
			Stuff((SELECT ', '+quotename(REPLACE(TRIM(Column_Name), 'updated_by', 'modified_by') ) + '=new_records.'+quotename(REPLACE(TRIM(Column_Name), 'updated_by', 'modified_by') ) + ''
			--Stuff((SELECT ',new_records.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + '='+@config_database_schema+'.' + @config_table_name + '.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + ''
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE 
			TABLE_NAME=@config_table_name AND TABLE_SCHEMA=@config_database_schema
			AND Column_Name NOT IN ('config_id', 'config_dataset_column_id', 'config_description_id', 'created_date', 'created_by', 'modified_date','ValidTo','ValidFrom')
			ORDER BY ORDINAL_POSITION
		FOR XML PATH ('')),1,1,'')
	
		-- Remove square brackets from the table names
		SET @column_update_list = REPLACE(REPLACE(@column_update_list, '[', ''), ']', '')
		PRINT('Columns update list2: ' + @column_update_list);



		-- Generate columns update list for table from information schema	
		SET @column_update_exclusion_list =  
			--Stuff((SELECT ' ,  existing_records.'+quotename(REPLACE(TRIM(Column_Name), 'updated_by', 'modified_by') ) + ' COLLATE SQL_Latin1_General_CP1_CI_AS '
			Stuff((SELECT ' ,  existing_records.'+quotename(REPLACE(TRIM(Column_Name), 'updated_by', 'modified_by') ) + ' '
			--Stuff((SELECT ' OR existing_records.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + '!=new_records.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + ''
			--Stuff((SELECT ',new_records.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + '='+@config_database_schema+'.' + @config_table_name + '.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + ''
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE 
			TABLE_NAME=@config_table_name AND TABLE_SCHEMA=@config_database_schema
			--AND Column_Name NOT IN ('project_id', 'source_id', 'config_id', 'config_description_id', 'created_date', 'created_by', 'modified_date', 'modified_by')
			AND Column_Name NOT IN ('project_id', 'config_id', 'config_dataset_column_id', 'dataset', 'config_name', 'config_description_id', 'created_date', 'created_by', 'modified_date', 'modified_by','ValidTo','ValidFrom')
			ORDER BY ORDINAL_POSITION
		FOR XML PATH ('')),1,1,'')

		-- Remove square brackets from the table names
		IF LEN(@column_update_exclusion_list) > 0
		BEGIN
			print(LEN(@column_update_exclusion_list))
			SET @column_update_exclusion_list = REPLACE(REPLACE(@column_update_exclusion_list, '[', ''), ']', '')
			SET @column_update_exclusion_list = RIGHT(@column_update_exclusion_list, LEN(@column_update_exclusion_list)-1)

			SET @column_update_exclusion_list_new_records = REPLACE(@column_update_exclusion_list, 'existing_records', 'new_records')
		END
		PRINT('Columns update exclusion list: ' + @column_update_exclusion_list);


		
		-- DROP temp table '#metadata_config_transposed' if it exists
		IF OBJECT_ID('#metadata_config_transposed') IS NOT NULL DROP TABLE #metadata_config_transposed
		
		
		IF @config_template_name IN ('config_dataset', 'config_dataset_columns')
		BEGIN
			SET @merge_join_clause = ' AND existing_records.project_id=(SELECT project_id FROM ' + @config_database_schema + '.projects WHERE project_alias=''' + @project_alias + ''') AND existing_records.source_id IN (SELECT source_id FROM ' + @config_database_schema + '.sources WHERE source_alias IN (''' + REPLACE(REPLACE(@source_alias_list, ',', ''','''), ' ', '') + ''') ) ';
		END

		IF @config_table_name = 'config'
		BEGIN

			SET @unique_columns = ' project_id, config_name, status ';
			SET @update_columns = ' TRIM(existing_records.config_name)=TRIM(new_records.config_name)  COLLATE SQL_Latin1_General_CP1_CI_AS AND existing_records.project_id=new_records.project_id  COLLATE SQL_Latin1_General_CP1_CI_AS ';
		
			SET @config_sql_query = 'SELECT ' 
				+ @non_config_columns_cleaned + '
			FROM 
				#metadata_config t1
			LEFT JOIN (	
				SELECT 
					config_position,
					config_value AS project_id 
				FROM 
					#metadata_config
				WHERE 
					TRIM(config_name)= ''project_id''
			) t2 ON TRIM(t1.config_position) = TRIM(t2.config_position)
			LEFT JOIN (	
				SELECT 
					config_position,
					TRIM(config_value) AS modified_by 
				FROM 
					#metadata_config
				WHERE 
					TRIM(config_name) = ''modified_by''
			) t3 ON TRIM(t1.config_position) = TRIM(t3.config_position) 
			LEFT JOIN (	
				SELECT 
					config_position,
					COALESCE(TRIM(config_value), ''Active'') AS status 
				FROM 
					#metadata_config
				WHERE 
					TRIM(config_name) = ''status''
			) t4 ON TRIM(t1.config_position) = TRIM(t4.config_position) 
			WHERE 
				TRIM(t1.config_name) LIKE ''config_%'' ' + REPLACE(@merge_insert_exclusion_list, 'WHERE', ' AND ')
			+ ' AND project_id IS NOT NULL  '
			print(@config_sql_query)
		END
		
		IF @config_table_name IN ('config_dataset')
		BEGIN

			SET @unique_columns = ' project_id, dataset, config_name, status';
			SET @update_columns = ' TRIM(existing_records.config_name)=TRIM(new_records.config_name)  COLLATE SQL_Latin1_General_CP1_CI_AS AND existing_records.project_id=new_records.project_id AND existing_records.source_id=new_records.source_id AND TRIM(existing_records.dataset)=TRIM(new_records.dataset) COLLATE SQL_Latin1_General_CP1_CI_AS ';
			

			-- project_id,dataset,config_name,config_value,modified_by
			SET @config_sql_query = 'SELECT ' 
				+ @non_config_columns_cleaned +
			' FROM 
				#metadata_config t1
			LEFT JOIN (	
				SELECT 
					mc.config_position,
					TRIM(mc.config_value) AS project_alias,
					p.project_id
				FROM 
					#metadata_config mc
				JOIN cp_data.projects p ON TRIM(p.project_alias) = TRIM(mc.config_value)
				WHERE 
					TRIM(config_name)= ''project_alias''
			) t2 ON t1.config_position = t2.config_position 
			LEFT JOIN (	
				SELECT 
					mc2.config_position,
					TRIM(mc2.config_value) AS project_alias,
					s.source_id
				FROM 
					#metadata_config mc2
				JOIN cp_data.sources s ON TRIM(s.source_alias) = TRIM(mc2.config_value)
				WHERE 
					TRIM(config_name)= ''source_alias''
			) t6 ON t1.config_position = t6.config_position
			LEFT JOIN (	
				SELECT 
					config_position,
					TRIM(config_value) AS modified_by 
				FROM 
					#metadata_config
				WHERE 
					TRIM(config_name) = ''modified_by''
			) t3 ON t1.config_position = t3.config_position
			LEFT JOIN (	
				SELECT 
					config_position,
					TRIM(config_value) AS dataset 
				FROM 
					#metadata_config
				WHERE 
					TRIM(config_name) = ''dataset''
			) t4 ON t1.config_position = t4.config_position
			LEFT JOIN (	
				SELECT 
					config_position,
					COALESCE(TRIM(config_value), ''Active'') AS status 
				FROM 
					#metadata_config
				WHERE 
					TRIM(config_name) = ''status''
			) t5 ON t1.config_position = t5.config_position ' + REPLACE(@merge_insert_exclusion_list, 'WHERE', ' AND ')
			+ ' WHERE project_id IS NOT NULL  '
		
		END		

		IF @config_table_name IN ('config_dataset_columns')
		BEGIN
			SET @unique_columns = ' project_id, source_column_name, dataset, source_id, status';
			SET @update_columns = ' TRIM(existing_records.source_column_name)=TRIM(new_records.source_column_name)  COLLATE SQL_Latin1_General_CP1_CI_AS AND existing_records.project_id=new_records.project_id AND existing_records.source_id=new_records.source_id AND TRIM(existing_records.dataset)=TRIM(new_records.dataset) COLLATE SQL_Latin1_General_CP1_CI_AS ';
		
				
			SET @sql_transpose = N' SELECT 
										transposed_data.*
										, s.source_id
										, p.project_id 
									FROM ( 
										SELECT ' + @sql_transpose_case + '
											, MAX(CASE WHEN TRIM(config_name)=''project_alias'' THEN TRIM(config_value) ELSE '''' END ) AS project_alias
											, MAX(CASE WHEN TRIM(config_name)=''source_alias'' THEN TRIM(config_value) ELSE '''' END ) AS source_alias
										FROM #metadata_config t1
										GROUP BY t1.config_position 
									) transposed_data
									JOIN ' + @config_database_schema + '.projects p ON p.project_alias = transposed_data.project_alias 
									JOIN ' + @config_database_schema + '.sources s ON s.source_alias = transposed_data.source_alias ';


				PRINT('SQL transpose 2: ' + @sql_transpose);
				--EXEC(@sql_transpose)

			SET @config_sql_query = @sql_transpose;
		
		END

		PRINT('Config SQL query ' + @config_sql_query)
		--EXEC(@config_sql_query)

		CREATE CLUSTERED INDEX cx_configposition ON #metadata_config (config_position);
	
	
		-- Generate columns update list for table from information schema	
		SET @merge_insert_list =  
			Stuff((SELECT ', new_records.'+quotename(REPLACE(TRIM(Column_Name), 'updated_by', 'modified_by') ) + ''
			--Stuff((SELECT ',new_records.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + '='+@config_database_schema+'.' + @config_table_name + '.'+quotename(REPLACE(Column_Name, 'updated_by', 'modified_by') ) + ''
		FROM INFORMATION_SCHEMA.COLUMNS
		WHERE 
			TABLE_NAME=@config_table_name AND TABLE_SCHEMA=@config_database_schema
			AND Column_Name NOT IN ('config_id', 'config_dataset_column_id', 'config_description_id', 'created_date', 'created_by', 'modified_date','ValidTo','ValidFrom')
			ORDER BY ORDINAL_POSITION
		FOR XML PATH ('')),1,1,'')
	
		-- Remove square brackets from the table names
		SET @merge_insert_list = REPLACE(REPLACE(@merge_insert_list, '[', ''), ']', '')
		PRINT('MERGE INSERT list2: ' + @merge_insert_list);


		SET @upsert_query = 'MERGE ' + @config_database_schema + '.' + @config_table_name + ' AS [existing_records]
		USING (SELECT ' + @non_config_columns_cleaned + ' FROM #metadata_config_transposed) AS [new_records] 
		ON ' + @update_columns + @merge_join_clause + ' 
		WHEN MATCHED AND EXISTS(SELECT ' + @column_update_exclusion_list + ' EXCEPT SELECT ' + @column_update_exclusion_list_new_records + ') THEN
		  UPDATE SET ' + @column_update_list + ', modified_date=''' + @current_timestamp + ''' 
		WHEN NOT MATCHED THEN
		  INSERT (' + @non_config_columns_cleaned + ', created_by, created_date, modified_date) VALUES (' + @merge_insert_list + ', new_records.modified_by, ''' + @current_timestamp + ''', ''' + @current_timestamp + ''');'

		print('UPSERT query: ' + @upsert_query)

		--EXEC('SELECT * INTO #metadata_config_transposed FROM (' + @config_sql_query + ') AS transposed_data;'
		--);

		EXEC('SELECT * INTO #metadata_config_transposed FROM (' + @config_sql_query + ') AS transposed_data;' 
			+ 'SELECT * FROM #metadata_config_transposed;' 
			+ @upsert_query + ';'
		);
		
		
		-- DROP temp table '#metadata_config_transposed' if it exists
		IF OBJECT_ID('#metadata_config_transposed') IS NOT NULL DROP TABLE #metadata_config_transposed

	END


	
	-- DROP temp table '#metadata_config' if it exists
	IF OBJECT_ID('#metadata_config') IS NOT NULL DROP TABLE #metadata_config

END TRY 

BEGIN CATCH
	Declare @ErrorMessage nvarchar(4000);
	Declare @ErrorSeverity int;

	SELECT @ErrorMessage = error_message(), @ErrorSeverity = error_severity();
	RAISERROR(@ErrorMessage, @ErrorSeverity, 1);

END CATCH

END
GO


