ALTER TABLE cp_data.projects 
    ADD
        ValidFrom DATETIME2 GENERATED ALWAYS AS ROW START
            CONSTRAINT projects_ValidFrom DEFAULT SYSUTCDATETIME(),
        ValidTo DATETIME2 GENERATED ALWAYS AS ROW END
            CONSTRAINT projects_ValidTo DEFAULT CONVERT(DATETIME2, '9999-12-31 23:59:59.9999999'),
    PERIOD FOR SYSTEM_TIME(ValidFrom, ValidTo);

ALTER TABLE cp_data.sources    
ADD
        ValidFrom DATETIME2 GENERATED ALWAYS AS ROW START
            CONSTRAINT sources_ValidFrom DEFAULT SYSUTCDATETIME(),
        ValidTo DATETIME2 GENERATED ALWAYS AS ROW END
            CONSTRAINT sources_ValidTo DEFAULT CONVERT(DATETIME2, '9999-12-31 23:59:59.9999999'),
    PERIOD FOR SYSTEM_TIME(ValidFrom, ValidTo);

ALTER TABLE cp_data.config_dataset 
    ADD
        ValidFrom DATETIME2 GENERATED ALWAYS AS ROW START
            CONSTRAINT config_dataset_ValidFrom DEFAULT SYSUTCDATETIME(),
        ValidTo DATETIME2 GENERATED ALWAYS AS ROW END
            CONSTRAINT config_dataset_ValidTo DEFAULT CONVERT(DATETIME2, '9999-12-31 23:59:59.9999999'),
    PERIOD FOR SYSTEM_TIME(ValidFrom, ValidTo);

ALTER TABLE cp_data.config_dataset_columns 
    ADD
        ValidFrom DATETIME2 GENERATED ALWAYS AS ROW START
            CONSTRAINT config_dataset_columns_ValidFrom DEFAULT SYSUTCDATETIME(),
        ValidTo DATETIME2 GENERATED ALWAYS AS ROW END
            CONSTRAINT config_dataset_columns_ValidTo DEFAULT CONVERT(DATETIME2, '9999-12-31 23:59:59.9999999'),
    PERIOD FOR SYSTEM_TIME(ValidFrom, ValidTo);

ALTER TABLE cp_data.watermark 
    ADD
        ValidFrom DATETIME2 GENERATED ALWAYS AS ROW START
            CONSTRAINT watermark_ValidFrom DEFAULT SYSUTCDATETIME(),
        ValidTo DATETIME2 GENERATED ALWAYS AS ROW END
            CONSTRAINT watermark_ValidTo DEFAULT CONVERT(DATETIME2, '9999-12-31 23:59:59.9999999'),
    PERIOD FOR SYSTEM_TIME(ValidFrom, ValidTo);

ALTER TABLE cp_data.config
    ADD
        ValidFrom DATETIME2 GENERATED ALWAYS AS ROW START
            CONSTRAINT config_ValidFrom DEFAULT SYSUTCDATETIME(),
        ValidTo DATETIME2 GENERATED ALWAYS AS ROW END
            CONSTRAINT config_ValidTo DEFAULT CONVERT(DATETIME2, '9999-12-31 23:59:59.9999999'),
    PERIOD FOR SYSTEM_TIME(ValidFrom, ValidTo);


ALTER TABLE cp_data.projects SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = cds_history.projects_history));
ALTER TABLE cp_data.sources SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = cds_history.sources_history));
ALTER TABLE cp_data.config_dataset SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = cds_history.config_dataset_history));
ALTER TABLE cp_data.config_dataset_columns SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = cds_history.config_dataset_columns_history));
ALTER TABLE cp_data.watermark SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = cds_history.watermark_history));
ALTER TABLE cp_data.config SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = cds_history.config_history));
