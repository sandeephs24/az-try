

create view [cp_data].[trigger_view]
as
select a.*, 
case when trim(parameter_json_string) <> '' then
JSON_VALUE(trim(parameter_json_string),'$.project_alias') 
end
as project_alias,
case when trim(parameter_json_string) <> '' then
COALESCE( JSON_VALUE(trim(parameter_json_string),'$.source_list'),
JSON_VALUE(trim(parameter_json_string),'$.Source_List')
) 
end
as source_list,
case when trim(parameter_json_string) <> '' then
JSON_VALUE(trim(parameter_json_string),'$.dataset_list') 
end
as dataset_list,
case when trim(parameter_json_string) <> '' then
JSON_VALUE(trim(parameter_json_string),'$.source_list_variant') 
end
as source_list_variant
from cp_data.trigger_details a 



