/****** Object:  View [taf].[source_param_view]    Script Date: 10/31/2023 3:38:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create view [taf].[source_param_view]  as  WITH source_view  AS       (select source_id,  source_name,  source_alias,  source_server,   source_database_name,   source_port_no,    source_username,  source_azure_kv_secret_name,  s1.source_onprem_cloud,  s1.source_type,  source_endpoint_base_url,  source_endpoint_tenant_client_id,  s1.source_connection_type,  s2.linkedservice_name  from cp_data.sources s1, taf.linkedservices s2  where s1.source_type = s2.source_type  and s1.source_onprem_cloud = s2.source_onprem_cloud  and s1.source_connection_type = s2.source_connection_type)  select a2.source_id, a1.linkedservice_name,a1.param_name, a2.param_value from   taf.linkedservices_param a1,  (  select source_id, linkedservice_name,  crossapplied.param_name param_name, crossapplied.param_value param_value  from (select * from source_view   ) a   CROSS APPLY (  values  ('source_server',source_server),  ('source_database_name',source_database_name),  ('source_port_no',source_port_no),  ('source_username',source_username),  ('source_endpoint_base_url',source_azure_kv_secret_name),  ('source_azure_kv_secret_name',source_azure_kv_secret_name),  ('source_endpoint_tenant_client_id',source_azure_kv_secret_name)    ) CrossApplied(param_name, param_value)  ) a2  where a1.db_field_name = a2.param_name  and a1.linkedservice_name = a2.linkedservice_name  union  select b7.source_id, b6.linkedservice_name, b6.param_name, b7.config_value   from taf.linkedservices_param b6,(  select b4.source_id, b5.linkedservice_name, config_name, config_value   from (select source_id, config_name, config_value from(  select source_id, config_name,config_value, row_number()    over (partition by source_id, config_name order by source_id) rn   from  cp_data.config_dataset b1 where  b1.config_name in('config_source_schema')  ) a where rn = 1) b4, source_view b5  where b4.source_id = b5.source_id  ) b7 where b7.linkedservice_name = b6.linkedservice_name and  b7.config_name = b6.db_field_name
GO


