

CREATE TABLE [cp_data].[trigger_details](
	[trigger_name] [varchar](255) NULL,
	[trigger_type] [varchar](255) NULL,
	[runtimeState] [varchar](255) NULL,
	[pipelineReference_name] [varchar](255) NULL,
	[parameter_json_string] [varchar](4000) NULL,
	[recurrence_frequency] [varchar](255) NULL,
	[recurrence_interval] [varchar](255) NULL,
	[recurrence_startTime] [varchar](255) NULL,
	[recurrence_endTime] [varchar](255) NULL,
	[recurrence_timeZone] [varchar](255) NULL,
	[schedule_minutes] [varchar](255) NULL,
	[schedule_hours] [varchar](255) NULL,
	[schedule_weekDays] [varchar](255) NULL,
	[create_date] [datetime] NULL,
	[schedule_monthDays] [varchar](255) NULL,
	[schedule_monthlyOccurrences_day] [varchar](255) NULL,
	[schedule_monthlyOccurrences_occurrence] [varchar](255) NULL
) ON [PRIMARY]



