
CREATE procedure [taf].[get_source_duplicate_queries]
(@source_name varchar(255),
@dataset_name varchar(255)
)
as
begin

select v1.*,  
CASE
    WHEN v1.config_source_schema is null or v1.config_source_schema = '' 
	THEN 'select count(*) duplicate_cnt from (select ' + v1.config_value + ', count(*) cnt' +
' from ' +
v1.dataset + 
' group by ' +  v1.config_value
+ ' having count(*) > 1) v' 
    WHEN v1.config_source_schema is not null THEN 'select count(*) duplicate_cnt from (select ' + v1.config_value + ', count(*) cnt' +
' from ' +
v1.config_source_schema + '.' + v1.dataset + 
' group by ' +  v1.config_value
+ ' having count(*) > 1) v'     
END as duplicate_query_sql
from(
select b.source_name,
a.dataset, 
c.adf_lookup_pl_name,
a.config_value, 
b.source_id, 
b.source_server, 
b.source_connection_type, 
b.source_database_name,
b.source_username,
b.source_port_no,
b.source_azure_kv_secret_name,
b.source_endpoint_base_url,
b.source_endpoint_relative_url, 
b.source_endpoint_tenant_client_id,
(
select config_value from cp_data.config_dataset
where config_name = 'config_source_schema'
and dataset = a.dataset
and source_id = b.source_id
) as config_source_schema
from cp_data.config_dataset a, 
cp_data.sources b,
taf.linkedservices c
where 
a.source_id = b.source_id and
config_name = 'config_primary_keys' and 
config_value is not null and
b.source_type = c.source_type and
b.source_onprem_cloud = c.source_onprem_cloud and
exists(select 1 from cp_data.config_dataset where 
config_name = 'config_source_dataset_mask' 
and config_value is null
and dataset = a.dataset
and source_id = b.source_id
) and
b.source_connection_type = c.source_connection_type and
source_name = @source_name and
(a.dataset = @dataset_name or @dataset_name = 'ALL')
) v1

return
end

