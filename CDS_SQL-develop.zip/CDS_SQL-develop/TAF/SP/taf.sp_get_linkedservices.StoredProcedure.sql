
create procedure [taf].[sp_get_linkedservices] 
(@ls_name varchar(255), @source_type varchar(255))
as
begin
select distinct linkedservice_name from taf.linkedservices where 
linkedservice_name = IIF(upper(@ls_name)='ALL', linkedservice_name, @ls_name) 
and source_type = IIF(upper(@source_type)='ALL', source_type, @source_type) 


return

end

