
create procedure [taf].[sp_get_sources]
(
@linkedservice_name varchar(255)
)
as
begin
select top 1
a1.source_id, source_name,source_environment,source_alias, 
linkedservice_name,param_list
from
cp_data.sources a1,
(select source_id, linkedservice_name, string_agg(json1, '') param_list 
from taf.source_view a group by source_id, linkedservice_name) a2 
where a1.source_id = a2.source_id
and a2.linkedservice_name = @linkedservice_name
return
end


