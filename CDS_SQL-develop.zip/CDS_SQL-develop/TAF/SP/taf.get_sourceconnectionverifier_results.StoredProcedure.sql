
create procedure [taf].[get_sourceconnectionverifier_results]
@pipeline_run_id varchar(255)
as
begin
DECLARE @html nvarchar(MAX);
DECLARE @query_result nvarchar(MAX);

set @query_result = 
N'select 
pipeline_run_id,
verifier_name,
start_date,
end_Date,
applied_on source_id,
param2 source_name,
param1 linkedservice_name,
check_result,
check_result_details
from taf.taf_log_detail'

set @query_result = @query_result + ' where pipeline_run_id = ' + '''' + @pipeline_run_id + ''''
--set @query_result = @query_result + ' and check_result in ' + '(''False'', ''Error'')' 

print @query_result

EXEC taf.spQueryToHtmlTable 
@html = @html OUTPUT,  
@query = @query_result, @orderBy = N'ORDER BY end_date desc';

declare @email_to varchar(100)
select @email_to = config_value from 
taf.taf_config where config_key = 'email_to'


declare @email_json varchar(4000)

set @email_json = '{'
set @email_json = @email_json + '"To" :' + '"' +  @email_to + '"' + ','
set @email_json = @email_json + '"CC" :' + '"' + @email_to + '"' + ','
set @email_json = @email_json + '"Subject" :' + '"' + 'SourceConnectionVerifier Results' + '"' + ','
set @email_json = @email_json + '"Message" :' + '"' + replace(@html,'"','\"') + '"'


set @email_json = @email_json + '}'


select @email_json as email_json, (select count(*) cnt 
from taf.taf_log_detail 
where pipeline_run_id = @pipeline_run_id 
--and check_result in ('False', 'Error')
) as cnt


end

