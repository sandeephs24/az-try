
create procedure [taf].[sp_get_sources_ls]
(
@linkedservice_name varchar(255),
@linkedservice_body varchar(4000),
@flag_test_one_source varchar(10)
)
as
begin
DECLARE @source_id INT, @source_name VARCHAR(255), @source_alias VARCHAR(255) 
DECLARE @linkedservice_name1 varchar(255)
DECLARE @replaced_linkedservice_body varchar(4000)
 
IF OBJECT_ID('tempdb..#temp_sp_get_sources_ls') IS NOT NULL
	drop table #temp_sp_get_sources_ls
	create table #temp_sp_get_sources_ls(
	source_id int, source_name VARCHAR(255), 
	source_alias VARCHAR(255), 
	linkedservice_name VARCHAR(255),
	linkedservice_body VARCHAR(4000)
	)

DECLARE source_cursor CURSOR FOR
select 
a1.source_id, a1.source_name,a1.source_alias, 
a2.linkedservice_name
from
cp_data.sources a1,
taf.linkedservices a2
where a1.source_type = a2.source_type
and a1.source_connection_type = a2.source_connection_type
and a1.source_onprem_cloud = a2.source_onprem_cloud
and a2.linkedservice_name = @linkedservice_name




OPEN source_cursor

FETCH NEXT FROM source_cursor
INTO @source_id, @source_name, @source_alias, @linkedservice_name1
WHILE @@FETCH_STATUS = 0
BEGIN

	set @replaced_linkedservice_body = @linkedservice_body
	
	print @source_id
	declare @param_name varchar(255), @param_value varchar(255)
	declare param_cursor CURSOR FOR
	select param_name , param_value from taf.source_param_view where source_id = @source_id 
	and linkedservice_name = @linkedservice_name

	open param_cursor

	FETCH NEXT FROM param_cursor
	INTO @param_name, @param_value
	WHILE @@FETCH_STATUS = 0
	BEGIN
		print @param_name
		print @param_value
		print 'replacing...'
		print '$.properties.parameters.' + @param_name + '.defaultValue'
		set @replaced_linkedservice_body = 
		JSON_MODIFY(
		@replaced_linkedservice_body,
		'$.properties.parameters.' + @param_name + '.defaultValue', 
		@param_value) 
		
	
		FETCH NEXT FROM param_cursor
		INTO @param_name, @param_value
	END
	CLOSE param_cursor
	DEALLOCATE param_cursor

	set @replaced_linkedservice_body = '{"linkedService":' + @replaced_linkedservice_body + '}'

	print @replaced_linkedservice_body
	insert into #temp_sp_get_sources_ls(source_id, source_name, source_alias, linkedservice_name, linkedservice_body)
	select @source_id,  @source_name, @source_alias, @linkedservice_name1, @replaced_linkedservice_body
	
	if (@flag_test_one_source = 'false')
		FETCH NEXT FROM source_cursor
		INTO @source_id, @source_name, @source_alias, @linkedservice_name1

END

CLOSE source_cursor
DEALLOCATE source_cursor

select source_id, source_name, source_alias, linkedservice_name, linkedservice_body
from #temp_sp_get_sources_ls

return
END

