

create procedure [taf].[sp_update_taf_log_detail_json]
(@pipeline_run_id varchar(255), 
@databricksReturnJson varchar(MAX),
@source_id varchar(255),
@source_name varchar(255),
@source_alias varchar(255)
)
as
begin


declare @checkdata_json varchar(MAX)
declare @metricdata_json varchar(MAX)


SELECT @checkdata_json  = [value] 
FROM OPENJSON(@databricksReturnJson) where [key] = 'checkData' 

SELECT @metricdata_json  = [value] 
FROM OPENJSON(@databricksReturnJson) where [key] = 'metricData' 

insert into taf.taf_log_detail
(
pipeline_run_id,
verifier_name,
start_date,
end_date,
time_taken,
pipeline_params,
applied_on,
check_result,
check_result_details,
log_time,
applied_on_type,
param1,
param2,
param3,
param4,
param5,
child_pipeline_run_id,
source_id,
source_name,
source_alias
)
select 
@pipeline_run_id,
'IngestionRealBasedVerifier' verifier_name,
CURRENT_TIMESTAMP as start_date,
CURRENT_TIMESTAMP as end_date,
0 as time_taken,
'' as pipeline_params,
dataset as applied_on,
case when failed_count > 0 then 'Failed' else 'Passed' end as check_result,
check_result_json,
CURRENT_TIMESTAMP as log_time,
'DATASET' applied_on_type,
'' as param1,
'' as param2,
'' as param3,
'' as param4,
metric_json,
'' child_pipeline_run_id,
@source_id,
@source_name,
@source_alias
from(
select a.[key] as dataset,a.[value] check_result_json, b.[value] metric_json ,
(select count(1) from OPENJSON(a.[value]) where [value] = 'Failed') failed_count
from OPENJSON(@checkdata_json) a, OPENJSON(@metricdata_json) b where a.[key] = b.[key]
) x

insert into taf.taf_log_check_detail
(
pipeline_run_id,
verifier_name,
source_id,
source_name,
source_alias,
dataset_name,
check_name,
check_result
)
select 
pipeline_run_id, 
verifier_name,
source_id, 
source_name, 
source_alias,
applied_on,
a.[key] check_name,
a.[value] check_result
from taf.taf_log_detail cross apply
OPENJSON(check_result_details) a
where 
pipeline_run_id = @pipeline_run_id

insert into taf.taf_log_metric_detail
(
pipeline_run_id,
verifier_name,
source_id,
source_name,
source_alias,
dataset_name,
check_name,
metric_name,
metric_value
)
select 
pipeline_run_id, 
verifier_name,
source_id, 
source_name, 
source_alias,
applied_on, 
'' check_name,
a.[key] metric_name,
a.[value] metric_value
from taf.taf_log_detail cross apply
openjson(param5) a
where 
pipeline_run_id = @pipeline_run_id


end




