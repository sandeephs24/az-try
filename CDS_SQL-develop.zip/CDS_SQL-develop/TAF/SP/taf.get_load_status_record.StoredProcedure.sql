	
		create procedure [taf].[get_load_status_record]
		(@source_name varchar(255), 
		@dataset varchar(255), 
		@source_layer_id varchar(255), 
		@modified_date datetime
		)
		as
		begin

		select a.*
		from [cp_data].[load_status] AS a
		left outer join [cp_data].[sources] AS b ON
		a.source_id = b.source_id
		where 
		b.source_name = @source_name
		AND dataset = @dataset
		--AND cast(a.modified_date as date) >= @modified_date
		AND source_layer_id = @source_layer_id
		order by modified_date DESC

		return
		end

