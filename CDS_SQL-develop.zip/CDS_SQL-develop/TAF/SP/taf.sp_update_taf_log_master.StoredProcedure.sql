

CREATE PROCEDURE [taf].[sp_update_taf_log_master] 
(
@pipeline_run_id varchar(255), 
@end_date datetime,
@time_taken int
)
AS
begin
update taf.taf_log_master set end_date = @end_date, time_taken = @time_taken where pipeline_run_id = @pipeline_run_id
end

