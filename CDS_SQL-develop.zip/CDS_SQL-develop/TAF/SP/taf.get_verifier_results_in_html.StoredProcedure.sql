
create procedure [taf].[get_verifier_results_in_html]
@pipeline_run_id varchar(255),
@status_list varchar(255),
@sql_query varchar(1024),
@verifier_name varchar(255),
@header varchar(255)
as
begin
DECLARE @html nvarchar(MAX);
DECLARE @query_result nvarchar(MAX);

set @query_result = @sql_query


set @query_result = @query_result + ' where pipeline_run_id = ' + '''' + @pipeline_run_id + ''''
set @query_result = @query_result + ' and check_result in (SELECT value FROM STRING_SPLIT( ' + '''' + @status_list + '''' + ', '',''))' 



print @query_result

EXEC taf.spQueryToHtmlTable 
@html = @html OUTPUT,  
@query = @query_result, @orderBy = N' ORDER BY end_date desc';

print 'here 1'

declare @email_to varchar(100)
select @email_to = config_value from 
taf.taf_config where config_key = 'email_to'

declare @email_cc varchar(100)
select @email_cc = config_value from 
taf.taf_config where config_key = 'email_cc'
print 'here 2'

declare @email_json varchar(4000)

set @email_json = '{'
set @email_json = @email_json + '"To" :' + '"' +  @email_to + '"' + ','
set @email_json = @email_json + '"CC" :' + '"' + @email_cc + '"' + ','
set @email_json = @email_json + '"Subject" :' + '"' + @verifier_name + ' Results' + '"' + ','
set @email_json = @email_json + '"Message" :' + '"' + replace(@html,'"','\"') + '"'
print 'here 3'

set @email_json = @email_json + '}'


select @email_json as email_json, (select count(*) cnt 
from taf.taf_log_detail 
where pipeline_run_id = @pipeline_run_id 
and check_result in (SELECT value FROM STRING_SPLIT(@status_list, ','))
) as cnt

print 'here 4'

end

