
CREATE PROCEDURE [taf].[sp_insert_taf_log_master] 
(
@pipeline_run_id varchar(255), 
@verifier_name varchar(255),
@start_date datetime,
@pipeline_params varchar(255)
)
AS
begin

insert into taf.taf_log_master(pipeline_run_id, verifier_name, start_Date, pipeline_params, log_time)
values(@pipeline_run_id,@verifier_name, @start_date, @pipeline_params, CURRENT_TIMESTAMP)

end

