
CREATE procedure [taf].[get_taf_config]
as
begin
DECLARE @SQLQuery NVARCHAR(MAX)
DECLARE @colList NVARCHAR(MAX)

select @colList= string_agg(config_key,',')
from taf.taf_config

SET @SQLQuery =
'select * from(
select config_key, config_value
from taf.taf_config) as tble
pivot
(
min(config_value)
for config_key in('+@colList+')
) as pvt'

EXEC(@SQLQuery)
return 
end

