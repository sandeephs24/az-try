

CREATE PROCEDURE [taf].[sp_insert_taf_log_detail] 
(
@pipeline_run_id varchar(255), 
@verifier_name varchar(255),
@start_date datetime,
@applied_on varchar(255),
@applied_on_type varchar(255),
@check_result varchar(255),
@check_result_details varchar(255),
@child_pipeline_run_id varchar(255) = '',
@source_id varchar(255),
@source_name varchar(255),
@source_alias varchar(255)
)
AS
begin

insert into taf.taf_log_detail(
pipeline_run_id, 
verifier_name, 
start_Date, 
applied_on,
applied_on_type,
check_result,
check_result_details,
log_time,
child_pipeline_run_id,
source_id,
source_name,
source_alias
)
values(
@pipeline_run_id,
@verifier_name, 
@start_date, 
@applied_on,
@applied_on_type,
@check_result,
@check_result_details,
CURRENT_TIMESTAMP,
@child_pipeline_run_id,
@source_id,
@source_name,
@source_alias
)
end

