

CREATE procedure [taf].[get_sources_for_sourceTypes]
(
@sourceTypeList varchar(1024), 
@sourceAliasList varchar(1024)
)
as
begin

select source_name , source_id ,a.source_type,project_alias,a.source_alias,
(select count(*) cnt from cp_data.config_dataset
where source_id = a.source_id and config_name = 'dataset' and status = 'Active') dataset_count
from 
cp_data.sources a, taf.linkedservices b
where a.source_type = b.source_type
and a.source_onprem_cloud = b.source_onprem_cloud
and a.source_connection_type = b.source_connection_type
and status = 'Active'
and (@sourceTypeList = 'ALL' or a.source_type in (SELECT value FROM STRING_SPLIT(@sourceTypeList, ',')))
and (@sourceAliasList = 'ALL' or a.source_alias in (SELECT value FROM STRING_SPLIT(@sourceAliasList, ',')))

end

