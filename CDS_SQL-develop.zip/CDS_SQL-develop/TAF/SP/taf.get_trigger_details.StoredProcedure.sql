
create procedure [taf].[get_trigger_details]
as
begin

select * from cds.TRIGGER_DETAILS
FOR JSON AUTO

end

