

create procedure [taf].[flatten_single_json]
(@json_input varchar(MAX), @target_table varchar(255))
as
begin


DECLARE @MyCursor CURSOR;
DECLARE @column_name varchar(255);
DECLARE @extractor_function nvarchar(255);
DECLARE @extractor_expression nvarchar(255);
DECLARE @sqlCommand nvarchar(max);
declare @extracted_value nvarchar(MAX);
declare @insertSqlCommand nvarchar(MAX) = N'';
declare @insertSqlColList nvarchar(MAX) = N'';
declare @insertSqlValList nvarchar(MAX) = N'';



	set @insertSqlCommand = N'insert into ' + @target_table
	
    SET @MyCursor = CURSOR FOR
    select column_name, extractor_function,extractor_expression
	from taf.flatten_json_config
	where target_table = @target_table

    OPEN @MyCursor 
    FETCH NEXT FROM @MyCursor 
    INTO @column_name, @extractor_function, @extractor_expression

    WHILE @@FETCH_STATUS = 0
    BEGIN
	  
	  
	  set @sqlCommand = N'select @valOUT = ' + 
	  @extractor_function + 
	  '(@json_input,' + '@extractor_expression'  + ')'
	  
	  EXECUTE sp_executesql @sqlCommand, 
	  N'@json_input nvarchar(MAX),@extractor_expression nvarchar(255),@valOUT nvarchar(MAX) OUTPUT ', 
	  @json_input = @json_input, 
	  @extractor_expression = @extractor_expression,
	  @valOUT = @extracted_value OUTPUT 

	  
	  set @insertSqlColList = @insertSqlColList + @column_name +','
	  set @insertSqlValList = @insertSqlValList + '''' + COALESCE(@extracted_value,'') + '''' +','





      FETCH NEXT FROM @MyCursor 
      INTO @column_name, @extractor_function, @extractor_expression
    END; 

    CLOSE @MyCursor ;
    DEALLOCATE @MyCursor;

	print('here1')
	print( @insertSqlCommand)
	print( @insertSqlColList)
	print( @insertSqlValList)

	set @insertSqlColList = substring(@insertSqlColList,1, len(@insertSqlColList)-1)
	set @insertSqlValList = substring(@insertSqlValList,1, len(@insertSqlValList)-1)
	print('here2')
	print( @insertSqlColList)
	print( @insertSqlValList)

	set @insertSqlCommand = @insertSqlCommand + '('
	set @insertSqlCommand = @insertSqlCommand + @insertSqlColList
	set @insertSqlCommand = @insertSqlCommand + ') values('
	set @insertSqlCommand = @insertSqlCommand + @insertSqlValList
	set @insertSqlCommand = @insertSqlCommand + ')'
	
	print('here3')

	print( @insertSqlCommand)
	
	EXECUTE sp_executesql @insertSqlCommand
	

end
