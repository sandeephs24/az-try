
create procedure [taf].[get_ingestion_verifier_configs](@sourceTypeList varchar(255), @sourceName varchar(255))
as
begin

select project_alias,source_name,source_variant_name,string_agg(dataset_name,',') dataset_list
from taf.ingestion_verifier_config a
where 
(@sourceTypeList = 'ALL' or a.source_type in (SELECT value FROM STRING_SPLIT(@sourceTypeList, ',')))
and (@sourceName = 'ALL' or a.source_name = @sourceName)
and status = 'Active'
group by project_alias,source_name,source_variant_name


end

