
		create procedure [taf].[get_load_status_record_for_datasets]
		(
		@source_name varchar(255),
		@source_id int,
		@datasetList varchar(1024), 
		@source_layer_id int,
		@target_layer_id int
		)
		as
		begin

		/* need to modify load status proc for test based to take care of source id, and return latest record for that dataset*/


		select y.*,z.avg_Record_count ,(y.target_record_count - z.avg_Record_count) diff_between_current_and_lastNRunAvg_count,
case 
when z.avg_Record_count > 0 then
	ABS(ROUND(CAST(((y.target_record_count - z.avg_Record_count) * 100.0 / z.avg_Record_count) AS FLOAT), 2) )
else null end as var_per  ,
(select '{' + STRING_AGG (config,',') + '}'
from(
select  '"' + config_key + '"' + ':' + '"' + config_value + '"' as config
from taf.taf_config
where config_key in 
(
'ingestion_trend_check_periods',
'ingestion_trend_check_variation_percent'
)
) x) as config_json,
z1.target_dataset prev_success_run_target_dataset,
z1.target_record_count prev_success_run_target_record_count
from (
select x.* from (
select a.*, 
			Row_number() over (partition by a.source_id, a.dataset order by a.modified_date desc) as row_num
			from [cp_data].[load_status] AS a
			left outer join [cp_data].[sources] AS b ON
			a.source_id = b.source_id
			where 
			b.source_name = @source_name
			and b.source_id = @source_id
			and (@datasetList = 'ALL' or dataset in (SELECT value FROM STRING_SPLIT(@datasetList, ',')))
			and source_layer_id = 1
			and target_layer_id = 2 ) x where row_num = 1 ) y 
			left join
			(
			select dataset , AVG(target_record_count) as avg_Record_count  from  (
select a.*, 
			Row_number() over (partition by a.source_id, a.dataset order by a.modified_date desc) as row_num
			from [cp_data].[load_status] AS a
			left outer join [cp_data].[sources] AS b ON
			a.source_id = b.source_id
			where 
			b.source_name = @source_name
			and b.source_id = @source_id
			and (@datasetList = 'ALL' or dataset in (SELECT value FROM STRING_SPLIT(@datasetList, ',')))
			and source_layer_id = 1
			and target_layer_id = 2 ) x where row_num >1 and row_num <= 8
			and target_record_count > 0 and load_status = 'Success'
			group by dataset ) z
			on y.dataset=z.dataset
			left join
			(
			select  x.* from  (
			select a.*, 
			Row_number() over (partition by a.source_id, a.dataset order by a.modified_date desc) as row_num
			from [cp_data].[load_status] AS a
			left outer join [cp_data].[sources] AS b ON
			a.source_id = b.source_id
			where 
			b.source_name = @source_name
			and b.source_id = @source_id
			and (@datasetList = 'ALL' or dataset in (SELECT value FROM STRING_SPLIT(@datasetList, ',')))
			and source_layer_id = 1
			and target_layer_id = 2 
			and load_status = 'Success'
			) x where row_num = 2
			 ) z1
			on y.dataset=z1.dataset
			



		return
		end

