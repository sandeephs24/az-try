
create procedure [taf].[flatten_json](@json_input varchar(MAX),
@target_table varchar(255)
)
as
begin



declare @root_json varchar(max)
select @root_json = json_query(@json_input,'$.value')

DECLARE @MyCursor CURSOR;
DECLARE @MyField varchar(max);
BEGIN
    SET @MyCursor = CURSOR FOR
    select [value] from openjson(@root_json)      

    OPEN @MyCursor 
    FETCH NEXT FROM @MyCursor 
    INTO @MyField

    WHILE @@FETCH_STATUS = 0
    BEGIN
	  	
	  exec taf.flatten_single_json @MyField ,@target_table

      FETCH NEXT FROM @MyCursor 
      INTO @MyField 
    END; 

    CLOSE @MyCursor ;
    DEALLOCATE @MyCursor;
END;



end


