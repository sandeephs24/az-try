
CREATE PROCEDURE [taf].[sp_update_taf_log_detail] 
(
@pipeline_run_id varchar(255), 
@end_date datetime,
@time_taken int,
@applied_on varchar(255),
@check_result varchar(255),
@check_result_details varchar(255),
@param1 varchar(255),
@param2 varchar(255),
@param3 varchar(255),
@param4 varchar(255),
@param5 varchar(4000),
@child_pipeline_run_id varchar(255) = ''
)
AS
begin
update taf.taf_log_detail 
set end_date = @end_date, 
time_taken = @time_taken,
check_result = @check_result,
check_result_details = @check_result_details,
param1 = @param1,
param2 = @param2,
param3 = @param3,
param4 = @param4,
param5 = @param5,
child_pipeline_run_id = @child_pipeline_run_id
where pipeline_run_id = @pipeline_run_id
and applied_on = @applied_on
end

