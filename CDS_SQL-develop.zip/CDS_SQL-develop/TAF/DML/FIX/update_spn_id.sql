update taf.taf_config
set 
config_value = 'c09c9cc8-9218-4ec4-97d3-06e87bc27d7b'
where config_key = 'spn_id'
