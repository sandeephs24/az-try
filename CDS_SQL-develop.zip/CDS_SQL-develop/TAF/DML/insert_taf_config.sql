INSERT INTO taf.taf_config
([config_key],[config_value])
VALUES
 ('adf_resource_id','shell-32-eun-adf-xleyhrfiybpvpmgaeld')
,('adf_rg','shell-32-rg-zektebndzkwnghxtbdpq')
,('adf_subscription_id','e8f6becb-b3ab-4300-8b75-bba84984ed96')
,('api_version','2018-06-01')
,('email_cc','Vinay.Kumar4@shell.com,')
,('email_to','b.choudhary@shell.com, Rima.Saha@shell.com')
,('ingestion_trend_check_periods','7')
,('ingestion_trend_check_variation_percent','15')
,('spn_id','c09c9cc8-9218-4ec4-97d3-06e87bc27d7b')
,('spn_key_akv_secret','AZ-DNA-SPN-P-DS-823422da7a0e43678a70')
,('spn_tenant','db1e96a8-a3da-442a-930b-235cac24cd5c')
